## 2026-11-16 11:55 CET — retain actual scope history inside the induction

The existing ActualFrameLedger indexes a resource scope. It does not tie that scopeBefore to the scope recorded by ActualSourceOrigin. In particular, captured frame identity contains only edge, residual, caller and queries. Do not infer root.before-to-scope history from ledger inversion. No false-target theorem or actual-source counterexample is claimed.

Carry a concrete past receipt for each ACTUALLY generated ledger node: HeldFragmentHistory from root.before to scopeBefore, avoidance for all original scope inputs, and the same receipt for each selected parent. Derive it at actual captured entry and selected entry. Restore the parent receipt on selected return. This is internal induction data. Do not add it to the external original906 header or use a future output-law supplier. The v1 fixed-root task dispatcher remains provisional and open; its conditional forwarding lemmas are not the missing whole-worker producer.

The published baseline remains checkpoint cae9462bd33f3f9b187b6d1b42c3b79866e0ac2c / checked Source6399e5b69e6c9a6dd121eb762728e5a709cc5fd4. Two residual laws passed their strict local check and await public gates. The later component checks remain unpromoted: preserve their diagnostics and raw inputs. No Haskell change or defect is claimed. Record every future Haskell fix in FINDINGS.md.

---

