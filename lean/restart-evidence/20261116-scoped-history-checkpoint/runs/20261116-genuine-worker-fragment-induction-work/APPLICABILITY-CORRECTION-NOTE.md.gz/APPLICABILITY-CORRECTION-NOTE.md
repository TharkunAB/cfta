## 2026-11-16 11:29 CET — captured-path applicability correction

The main captured path uses SharedPreparedChildPolicy.runWithChild and SelectedPreparation.run. SourcePruningEnumerationSharedEagerReservation.real_actual_successful_prepared_emitted_complete_at_any_budget (line20734) keeps decoded and prepared value distinct. Entry.enter returns decoded. SelectedValue.run may unfold a Mu or expose a Union and return an ordinary node. Thus an ordinary prepared parent does not establish an ordinary Entry.enter result. The checked ordinary-entry separation lemma remains valid under its exact premise. It is not the missing main captured-case producer. The earlier handoff instruction to recover this ordinary entry from NativeOrdinary.run does not apply to this main route.

Use the original packet_restart_ne or prefix_isolated_at_original_budget to derive captured uv≠held from the original restart decision, current isolated boundary and actual native read. The same captured uv persists through the row scan. Keep decoded and prepared separate. The real selected-preparation receipt also retains their actual native relation. This is an applicability correction in the formal proof plan. No Haskell defect, fix or actual-source counterexample is established.

The active task companion uses one fixed past root.before anchor. A current-point-only isolation statement loses deferred fragments and parent-scope history. Its internal premises must retain genuine past root Packet/query/Ready/stored root.scs/IncomingAvoid, captured uv≠held, and genuine smaller task/depth IHs. These are not new external premises of original906. Whole906 and joint historical compatibility remain open.

New strict checks prove actual same-fuel residual/finalize commutation and structural-history preservation through residual recording. These laws are added to the existing owner with its entire prior byte prefix retained. Public publication checks are pending. The checked/pushed baseline remains Source6399e5b69e6c9a6dd121eb762728e5a709cc5fd4 at checkpointcae9462bd33f3f9b187b6d1b42c3b79866e0ac2c. The full specification in the preserved prefix below is unchanged. Every future Haskell fix must still be recorded here.

---

