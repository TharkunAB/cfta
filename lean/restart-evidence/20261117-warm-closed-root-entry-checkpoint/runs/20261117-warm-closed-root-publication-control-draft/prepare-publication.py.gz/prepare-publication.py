from pathlib import Path
import hashlib
import json
import re
import shlex
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
work = base / '20261117-warm-closed-root-entry-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this candidate into the active Work directory'
prior_run = base / '20261117-original-optional-no-new-mu-publication'
prior_archive = base / '20261117-original-optional-no-new-mu-checkpoint'
runtime = base / '20261117-warm-closed-root-entry-publication'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
cold_name = 'lean/MicroCFTA/SourceSynthesisCurrentUniverseColdBoundaryAtoms.lean'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
prior_commit = '890d2ac6484b1516bfa78190673dbe1991cbef26'
expected_theorems = {
    'SourceCurrentAllocatedNativeSourceEmptyEnterOperands':
        ['query_enter_closed_operands_of_closed_root', 'closed_root_enter_identities'],
    'SourceCurrentAllocatedNativeSourceEnterFullOperands': ['closed_root_old_new_full_operands'],
    'SourceCurrentAllocatedNativeSourceCanonicalOldEntry': ['closed_root_canonical_old_entry'],
    'SourceCurrentAllocatedNativeSourceIssuedDomainEnterOrigin': ['closed_root_issued_domain_enter_origin'],
    'SourceCurrentAllocatedNativeSourceWarmEntry': ['closed_root_issued_authentic_entry_at'],
    'SourceSynthesisCurrentUniverseStartupAtoms': ['current_stored_universe_closed_atoms_after_no_new_mu'],
    'SourceSynthesisCurrentUniverseColdBoundaryAtoms': ['original_source_cold_query_closed_boundary_atoms']}
expected_raw_hashes = {'SourceCurrentAllocatedNativeSourceEmptyEnterOperands': '79bd8e961f1feefa67d84bf504bdcb50277907e45b3836fe75c22b94d1a77cda', 'SourceCurrentAllocatedNativeSourceEnterFullOperands': '6e7c4dea8eeb05fa8db27f681d5234f081f7cb2c9dea2d36e46cd646cd6507bd', 'SourceCurrentAllocatedNativeSourceCanonicalOldEntry': '1c5da5cf3b45b07e7199b9d6535dfd499932c607d11cdc0f31063d35de6e52c5', 'SourceCurrentAllocatedNativeSourceIssuedDomainEnterOrigin': 'f5e063d5cf3fbf179b0e739997aaf923bba54410085397173a431b543f3bcbbb', 'SourceCurrentAllocatedNativeSourceWarmEntry': 'aff38d9ae673f8205eaa484a27c3f600266ca0885680e87e8ffde28f2d16cddd', 'SourceSynthesisCurrentUniverseStartupAtoms': 'd78a1c826cbaf6b6aa8a6910e1570e9a2049a61a54059deaa3aa4e43bd60c421', 'SourceSynthesisCurrentUniverseColdBoundaryAtoms': '6bbc4e1253d1ae7ca59af03fc866492d9bc5b6534afea8205c06be4b692f344d'}
stage = json.loads((work / 'SOURCES-NORMAL-STAGING.json').read_text())
components = stage['components']
assert [item['module'] for item in components] == list(expected_theorems)
for component in components:
    module = component['module']
    assert component.get('namespace', module) == module
    assert component['source_path'] == 'lean/MicroCFTA/' + module + '.lean'
    assert component['theorems'] == expected_theorems[module]
    assert component['raw_sha256'] == expected_raw_hashes[module]
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports']) == (6251, 5251, 668)
assert stage['new_normal_modules'] == 1 and stage['new_public_theorems'] == 8
assert stage['new_private_theorems'] == 1 and stage['new_private_predicates'] == 0
assert (stage['fresh_strict_reports'], stage['inherited_bound_reports'], stage['combined_component_reports']) == (9, 452, 461)
assert stage['old_reports_replaced'] == 0
assert stage['old_non_audit_non_changed_owner_sources_exact'] == 6243
assert stage['all_six_old_owner_prefixes_exact'] and stage['all_old_proof_bodies_and_limits_unchanged']
for key in ['physical_closed_root_factor_staged', 'closed_root_warm_entry_chain_staged',
            'authentic_initial_source_heap_equality_required', 'source_cold_query_boundary_atoms_proved',
            'actual_execute_and_every_bounded_prefix_proved', 'initial_Ready_derived_from_source_build',
            'physical_warm_entry_bridge_only']:
    assert stage[key], key
for key in ['future_OnlyU_Profile_or_Result_supplier', 'global_inherited_cell_semantics_proved',
            'mixed_qualification_semantic_fields_produced', 'independent_query_inherited_warm_tables_proved',
            'source_type_marker_class_consistency_proved', 'all_native_inhabitance_proved',
            'joint_finite_completion_proved', 'compiled_haskell_correspondence_proved', 'haskell_changed']:
    assert not stage[key], key
prior = json.loads((prior_run / 'checked.json').read_text())
assert len(prior['checks']) == 5 and all(c['exit'] == 0 and not c['nonstandard_axioms']
    and not c['diagnostics'] and not c['sorryAx'] for c in prior['checks'])
assert (prior['source_files'], prior['independent_reports'], prior['resource_and_component_probes']) == (6250, 255, 452)
assert prior['whole_worker_program_slots_proved'] and prior['whole_worker_roles_proved']
assert prior['owner_resource_probes'] == 264
assert prior['optional441e_proved'] and prior['cold_whole_query_no_new_mu_proved']
assert prior['source_admission_cold_root_scope']
baseline = json.loads((work / 'baseline-source-pins.json').read_text())
assert len(baseline) == 6250 and cold_name not in baseline
assert {str(path.relative_to(root)) for path in (root / 'lean/MicroCFTA').glob('*.lean')} == set(baseline) | {cold_name}
old_sources = {}
for component in components[:-1]:
    module = component['module']
    name = component['source_path']
    old = (work / (module + '-BEFORE.lean.txt')).read_bytes()
    assert sha(old) == baseline[name], name
    current = (root / name).read_bytes()
    assert current.startswith(old), name
    assert [line for line in current.splitlines() if line.startswith(b'import ')] == [
        line for line in old.splitlines() if line.startswith(b'import ')], name
    old_sources[name] = old
assert len(old_sources) == 6
old_audit = (work / 'Audit-BEFORE.lean.txt').read_bytes()
assert old_audit.count(b'#print axioms ') == 660
for name, digest in baseline.items():
    data = old_audit if name == audit_name else old_sources.get(name, (root / name).read_bytes())
    assert sha(data) == digest, name
assert len(set(baseline) - set(old_sources) - {audit_name}) == 6243
assert sha((root / owner_name).read_bytes()) == owner_sha
for component in components:
    assert sha((root / component['source_path']).read_bytes()) == component['raw_sha256']
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
qnames = ['MicroCFTA.' + item.get('namespace', item['module']) + '.' + theorem
          for item in components for theorem in item['theorems']]
assert len(qnames) == 8
assert public == ''.join('#check ' + q + '\n#print axioms ' + q + '\n' for q in qnames).encode()
new_import = b'import MicroCFTA.SourceSynthesisCurrentUniverseColdBoundaryAtoms\n'
audit = (root / audit_name).read_bytes()
assert audit == new_import + old_audit + b'\n' + public
assert sum(line.startswith(b'import ') for line in audit.splitlines()) == 5251
assert audit.count(b'#print axioms ') == 668
chain = base / '20261117-closed-root-warm-entry-chain-metadata-repair'
inventory = base / '20261117-source-inventory-cold-boundary-atoms-draft'
header_specs = [
    (components[0], 'query_enter_closed_operands_of_closed_root', base / '20261117-closed-root-enter-physical-factor-draft/FIRST-HEADER.lean.txt'),
    (components[0], 'closed_root_enter_identities', chain / 'IDENTITY-FIRST-HEADER.lean.txt'),
    (components[1], 'closed_root_old_new_full_operands', chain / 'FULL-FIRST-HEADER.lean.txt'),
    (components[2], 'closed_root_canonical_old_entry', chain / 'CANONICAL-FIRST-HEADER.lean.txt'),
    (components[3], 'closed_root_issued_domain_enter_origin', chain / 'ORIGIN-FIRST-HEADER.lean.txt'),
    (components[4], 'closed_root_issued_authentic_entry_at', chain / 'WARM-FIRST-HEADER.lean.txt'),
    (components[5], 'current_stored_universe_closed_atoms_after_no_new_mu', inventory / 'INVENTORY-FIRST-HEADER.lean.txt'),
    (components[6], 'original_source_cold_query_closed_boundary_atoms', inventory / 'COLD-FIRST-HEADER.lean.txt')]
for component, theorem, path in header_specs:
    text = (root / component['source_path']).read_text()
    declaration = 'theorem ' + theorem
    start = text.index(declaration)
    header = path.read_text()
    assert text[start:text.index(' := by', start)].rstrip() == header[header.index(declaration):].rstrip(), theorem
assert '(sourceStart : machine.heap = sourceHeap)' in (inventory / 'COLD-FIRST-HEADER.lean.txt').read_text()
boundary_verified_path = work / 'COLD-BOUNDARY-FIRST-VERIFIED.json'
boundary_verified = json.loads(boundary_verified_path.read_text())
assert boundary_verified['actual_terminal_exit'] == 0
assert boundary_verified['authentic_initial_source_heap_equality_required']
assert boundary_verified['actual_execute_and_every_bounded_prefix_proved']
assert boundary_verified['initial_Ready_derived_from_source_build']
assert not boundary_verified['future_OnlyU_Profile_or_Result_supplier']
checked_inputs = [boundary_verified_path]
for component in components:
    normal_check = base / component['actual_normal_check']
    normal_checked = json.loads((normal_check / 'checked.json').read_text())
    assert normal_checked['normal_module_checked'] and all(normal_checked['passed'])
    assert normal_checked['source_pins_unchanged']
    assert normal_checked['checks'][1]['total_axiom_reports'] == component['actual_normal_check_reports']
    if component['source_path'] == cold_name:
        assert boundary_verified['run'] == component['actual_normal_check']
        assert boundary_verified['checks'] == normal_checked['checks']
    assert all(item['exit'] == 0 and not item['nonstandard_axioms'] and not item['diagnostics']
               and not item['sorryAx'] for item in normal_checked['checks'])
    checked_source = normal_check / 'source/MicroCFTA' / (component['module'] + '.lean')
    assert checked_source.read_bytes().startswith((root / component['source_path']).read_bytes())
    checked_inputs += [normal_check / name for name in ['checked.json', 'selection.json', 'normal-module.txt', 'source-pins.json']]
    checked_inputs.append(checked_source)
# Validation above is read-only. Only Root may create the publication run.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-warm-closed-root-publication-'))
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
(runtime / 'PUBLIC-PROBES.lean.txt').write_bytes(public)
commands = []
strict_sources = []
fresh_count = 0
for component in components:
    normal = root / component['source_path']
    namespace = component.get('namespace', component['module'])
    if component['source_path'] == cold_name:
        helpers = re.findall(r'^private theorem ([A-Za-z0-9_]+)', normal.read_text(), re.M)
        assert helpers == ['trace_physical']
    else:
        helpers = []
    names = helpers + component['theorems']
    probes = ''.join('#check @MicroCFTA.' + namespace + '.' + name + '\n#print axioms MicroCFTA.'
                     + namespace + '.' + name + '\n' for name in names)
    fresh_count += len(names)
    source = runtime / 'source/MicroCFTA' / normal.name
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_bytes(normal.read_bytes() + b'\n' + probes.encode())
    (runtime / (component['module'] + '-PROBES.lean.txt')).write_text(probes)
    strict_sources.append(source)
    commands.append(['lake', 'env', 'lean', '-j1', '-DwarningAsError=true', '-R',
        str(source.parent.parent), '-o', str(objects / (component['module'] + '.olean')), str(source)])
assert fresh_count == 9
independent = runtime / 'IndependentProbes.lean'
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert new_import not in prior_independent
assert prior_independent.count(b'#print axioms ') == 255
independent.write_bytes(new_import + prior_independent + b'\n' + public)
assert independent.read_bytes().count(b'#print axioms ') == 263
selection = {'prior_checkpoint': prior_commit,
    'prior_archive_manifest_sha256': sha((prior_archive / 'manifest.json').read_bytes()),
    'prior_checked_sha256': sha((prior_run / 'checked.json').read_bytes()),
    'prior_pins_sha256': sha((prior_run / 'source-pins.json').read_bytes()),
    'baseline_sha256': sha((work / 'baseline-source-pins.json').read_bytes()),
    'stage_sha256': sha((work / 'SOURCES-NORMAL-STAGING.json').read_bytes()),
    'old_audit_sha256': sha(old_audit),
    'old_owner_snapshots': {item['source_path']: {
        'snapshot': item['module'] + '-BEFORE.lean.txt',
        'sha256': sha(old_sources[item['source_path']]), 'bytes': len(old_sources[item['source_path']])}
        for item in components[:-1]},
    'unchanged_resource_owner_sha256': owner_sha,
    'prior_source_files': 6250, 'prior_combined_reports': 452,
    'replaced_old_reports': 0, 'inherited_reports': 452,
    'fresh_reports': 9, 'combined_reports': 461,
    'new_theorem_declarations': 9, 'new_public_theorems': 8, 'new_private_theorems': 1,
    'old_normal_sources_byte_exact_except_audit_and_six_owners': 6243,
    'six_old_owners_are_exact_prefixes_without_new_imports': True,
    'old_audit_bytes_retained_after_one_import': True,
    'owner_preflight_reports_fresh_this_batch': 0, 'owner_reports_inherited': 264,
    'old_toolchain_and_proof_inputs_reverified': True, 'axiom_strings_replayed': False}
(runtime / 'INHERITANCE-SELECTION.json').write_text(json.dumps(selection, indent=2) + '\n')
STRICT_BINDING_TEMPLATE = '''from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/home/tritlo/Code/mcfta')
runtime = Path(__file__).parent
prior = root / 'lean/restart-evidence/20261117-original-optional-no-new-mu-publication'
archive = root / 'lean/restart-evidence/20261117-original-optional-no-new-mu-checkpoint'
work = root / 'lean/restart-evidence/20261117-warm-closed-root-entry-work'
sha = lambda data: hashlib.sha256(data).hexdigest()
selection = json.loads((runtime / 'INHERITANCE-SELECTION.json').read_text())
assert sha((archive / 'manifest.json').read_bytes()) == selection['prior_archive_manifest_sha256']
committed = subprocess.check_output(['git', 'show', selection['prior_checkpoint'] + ':'
    + str((archive / 'manifest.json').relative_to(root))], cwd=root)
assert committed == (archive / 'manifest.json').read_bytes()
subprocess.run(['python3', str(archive / 'verify.py')], check=True)
records = json.loads((archive / 'archived-inputs.json').read_text())
for name in ['checked.json', 'source-pins.json']:
    path = prior / name
    record = next(item for item in records if item['original'] == str(path))
    archived = (archive / record['archived']).read_bytes()
    if record['gzip']:
        archived = gzip.decompress(archived)
    assert archived == path.read_bytes()
assert sha((prior / 'checked.json').read_bytes()) == selection['prior_checked_sha256']
assert sha((prior / 'source-pins.json').read_bytes()) == selection['prior_pins_sha256']
assert sha((work / 'baseline-source-pins.json').read_bytes()) == selection['baseline_sha256']
assert sha((work / 'SOURCES-NORMAL-STAGING.json').read_bytes()) == selection['stage_sha256']
assert sha((work / 'Audit-BEFORE.lean.txt').read_bytes()) == selection['old_audit_sha256']
for item in selection['old_owner_snapshots'].values():
    data = (work / item['snapshot']).read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256']
for name, digest in json.loads((prior / 'source-pins.json').read_text()).items():
    if name == 'lean/MicroCFTA/Audit.lean':
        data = (work / 'Audit-BEFORE.lean.txt').read_bytes()
    elif name in selection['old_owner_snapshots']:
        data = (work / selection['old_owner_snapshots'][name]['snapshot']).read_bytes()
    else:
        data = (root / name).read_bytes()
    assert sha(data) == digest, name
assert sha((root / 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean').read_bytes()) == selection['unchanged_resource_owner_sha256']
print(json.dumps({'inherited_component_reports_verified': 452,
                  'fresh_component_reports_expected': 9,
                  'fresh_owner_preflight_reports': 0,
                  'unchanged_owner_reports_inherited': 264,
                  'old_sources_and_toolchain_byte_exact': True}), flush=True)
'''
strict = runtime / 'strict-new-and-bind.py'
strict.write_text(STRICT_BINDING_TEMPLATE + '\ncommands = ' + repr(commands)
    + '\nfor command in commands:\n    subprocess.run(command, check=True)\n')
template = (prior_run / 'check.py').read_text()
driver = template[:template.index('\njobs =')]
jobs = [('public-build', 'exec lake build', 0),
    ('strict-new-components-and-prior-bindings', 'exec python3 ' + shlex.quote(str(strict)), 9),
    ('independent-imports', 'exec lake env lean -j1 -DwarningAsError=true ' + shlex.quote(str(independent)), 263),
    ('audit-build', 'exec lake build MicroCFTA.Audit', 0),
    ('audit-strict', 'exec lake env lean -j1 -DwarningAsError=true MicroCFTA/Audit.lean', 668)]
driver += '\njobs = ' + repr(jobs) + '''
for name, command, count in jobs:
    run(name, command, count)
assert len(checks) == 5
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx']
           and (not job[2] or c['total_axiom_reports'] == job[2]) for c, job in zip(checks, jobs))
match = re.search(r'Checked axiom dependencies of (\\d+) MicroCFTA theorems\\.', (runtime / 'audit-strict.txt').read_text())
assert match
'''
report = dict(prior)
for name in ['checks', 'limits', 'at', 'audited_theorems', 'checked_code', 'owner_preflight_evidence',
             'legacy_new_private_reports', 'legacy_new_private_reports_caveat', 'new_owner_export_maxHeartbeats',
             'replaced_old_native_reports', 'old_native_reports_rechecked',
             'fresh_native_strict_reports', 'fresh_cold_strict_reports',
             'old_native_exact_bytes', 'old_native_exact_offset',
             'old_native_bytes_preserved_contiguously']:
    report.pop(name, None)
for name in list(report):
    if name.startswith('old_non_audit_'):
        report.pop(name)
report.update(source_files=6251, direct_audit_imports=5251, individual_reports=668,
    independent_reports=263, resource_and_component_probes=461,
    inherited_resource_component_reports=452, fresh_resource_component_reports=9,
    replaced_old_reports=0, fresh_owner_preflight_reports=0,
    fresh_strict_normal_reports=9, actual_publication_strict_reports=9,
    resource_component_evidence='9 actual fresh strict reports (8new public and1new private) and452 inherited reports bound to the committed prior archive; no old report replacement, resource-owner recompile, fresh owner preflight or axiom-string replay',
    new_component_reports=9, new_theorem_reports=9, new_modules=1, new_public_theorems=8,
    new_private_component_reports=1, new_public_component_reports=8, new_private_predicates=0,
    new_relation_declaration_checks=0, new_relation_declaration_reports=0,
    owner_resource_probes=264, previous_owner_resource_probes=264,
    owner_recompiled_in_publication_strict_gate=False, fresh_owner_preflight_evidence=None,
    inherited_owner_preflight_evidence={'prior_run': str(prior_run), 'reports': 264,
        'normal_owner_sha256': owner_sha, 'fresh_this_batch': False, 'included_in_inherited_452': True},
    old_non_audit_non_changed_owner_source_files_byte_exact=6243,
    old_non_audit_source_files_byte_exact=6243, entire_previous_resource_owner_byte_exact=True,
    old_resource_owner_sha256=owner_sha,
    changed_existing_owners=6, all_six_old_owner_bytes_preserved_as_prefixes=True,
    new_imports_to_changed_old_owners=False,
    old_audit_bytes_preserved_after_one_import=True, all_old_proof_bodies_and_limits_unchanged=True,
    closed_root_physical_entry_factor_proved=True,
    closed_root_physical_entry_chain_proved=True, physical_two_stored_slot_requirement_removed=True,
    authentic_warm_entry_at_from_actual_closed_root_proved=True,
    source_inventory_no_new_mu_closed_boundary_transport_proved=True,
    original_source_cold_closed_boundary_atoms_proved=True,
    closed_resident_boundary_atoms_only_original_U_proved=True,
    authentic_initial_source_heap_equality_required=True,
    source_initial_ready_and_no_new_mu_derived_internally=True,
    arbitrary_initial_mu_inventory_coverage_proved=False,
    cold_boundary_scope={'initial_heap': 'literal machine.heap = authentic sourceHeap',
        'inventory': 'derived from accepted original source construction and stored full U',
        'values': 'closed values Available at actual execute outcome or bounded trace prefix',
        'result': 'boundary atoms are the same original Mu identity only; no inhabitance'},
    warm_physical_entry_scope={'start': 'actual warm Checked start and closed original root operands',
        'result': 'AuthenticEntryAt physical event and exact same-cache canonical entry',
        'not_derived': 'MixedQualifiedAt Profile/height/orientation and inherited-cell semantic chronology'},
    mixed_qualified_profile_height_orientation_derived=False,
    inherited_cell_semantic_chronology_proved=False,
    independent_query_inherited_warm_tables_proved=False, warm_across_independent_queries_proved=False,
    joint_finite_completion_proved=False, all_native_inhabitance_proved=False,
    source_terminal_marker_native_inhabitance_proved=False, source_type_marker_class_consistency_proved=False,
    compiled_haskell_correspondence_proved=False, haskell_changed=False,
    same_original_runtime_fuels=True, whole_worker_roles_proved=True,
    whole_worker_program_slots_proved=True, whole_worker_program_slots_fixed_marks_proved=True,
    proof_limits='unchanged defaults; unchanged owner proof settings inherited',
    prior_checkpoint=prior_commit, prior_immutable_archive=prior_archive.name, public_run=str(runtime))
driver += 'report = ' + repr(report) + '\n'
driver += '''report.update(checks=checks, limits=limits, at=datetime.datetime.now().astimezone().isoformat(),
              audited_theorems=int(match.group(1)))
(runtime / 'checked.json').write_text(json.dumps(report, indent=2) + '\\n')
print(json.dumps(report), flush=True)
'''
(runtime / 'check.py').write_text(driver)
files = list((root / 'lean/MicroCFTA').glob('*.lean'))
files += [root / name for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']]
files += [p for p in runtime.iterdir() if p.is_file()] + strict_sources
files += [Path(__file__), work / 'SOURCES-NORMAL-STAGING.json', work / 'baseline-source-pins.json',
    work / 'Audit-BEFORE.lean.txt'] + checked_inputs
files += [work / (item['module'] + '-BEFORE.lean.txt') for item in components[:-1]]
files += [item[2] for item in header_specs]
(runtime / 'source-pins.json').write_text(json.dumps(
    {str(p.relative_to(root)): sha(p.read_bytes()) for p in files}, indent=2) + '\n')
print(json.dumps({'run': str(runtime), 'gates': 5, 'fresh_component_reports': 9,
    'inherited_component_reports': 452, 'combined_component_reports': 461,
    'replaced_old_reports': 0, 'fresh_owner_preflight_reports': 0,
    'inherited_owner_reports': 264, 'independent_reports': 263,
    'audit_reports': 668, 'objects': str(objects)}))
