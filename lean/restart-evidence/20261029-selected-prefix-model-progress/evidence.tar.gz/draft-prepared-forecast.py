from pathlib import Path
import json

root = Path('/home/tritlo/Code/mcfta')
area = Path('/tmp/mcfta-selected-prefix-model-progress-20261029')
source = (root / 'lean/MicroCFTA/SourcePruningEnumerationConstructorCallback.lean').read_text()
old_name = 'accepted_prepared_constructor_callback'
start = source.index('theorem ' + old_name + '\n')
header = source[start:source.index(' := by\n', start)]
inputs, result = header.split(' :\n    ∃ ', 1)
prefix = source[source.index('namespace MicroCFTA.SourcePruningEnumerationConstructorCallback'):source.rfind('/--', 0, start)]
prefix = prefix.replace('namespace MicroCFTA.SourcePruningEnumerationConstructorCallback', 'namespace MicroCFTA.SourcePruningEnumerationPreparedConstructorForecast', 1)
inputs = inputs.replace('theorem ' + old_name, 'theorem accepted_constructor_callback', 1)
remove = '''    (tries : List EqualityTrie.Trie) (residual : Option Constraint)
    (projected : SourcePruningEnumerationConstraint.project edge.entry.key.constraint = some (tries, residual))
'''
assert inputs.count(remove) == 1
inputs = inputs.replace(remove, '', 1)
old_reserved = '    (reserved : Reserved bits seed (SourcePruningEnumerationSelectedEdge.cost edge scs before.core.counter tries))\n'
new_reserved = '''    (inherited : Nat) (inheritedLength : scs.length ≤ inherited)
    (reserved : Reserved bits seed (SourcePruningEnumerationRecursiveReservation.edgeCount seed inherited))
'''
assert inputs.count(old_reserved) == 1
inputs = inputs.replace(old_reserved, new_reserved, 1)
result = '    ∃ ' + result
body = '''  have inheritedModel : ∀ sc ∈ scs, Suspended.Holds assignment term sc := by
    have model := satisfied.1.2 target
    simp only [heap, stored, Option.getD_some, slot, Fragments.slotSatisfies,
      List.forall_mem_map] at model
    intro sc member
    simpa only [parentValue] using model.2 sc member
  obtain ⟨tries, residual, _terms, projected, _valid, _termShape, _children,
    _length, allowed, _ownEqualities, _residualHolds⟩ :=
    SourcePruningEnumerationSelectedEdgeAdmission.selected_admission formulas solver inventory caller memos
      parentEntry edges depth free edge scs packet.context parentAvailable selected ambient assignment
      term accepted inheritedModel
  obtain ⟨children, own⟩ := SourcePruningEnumerationRecursiveReservation.edge_shape_from_packet
    seed formulas solver inventory caller memos metadata before packet fits known
    parentEntry edges depth free parentAvailable edge selected
  have costBound := SourcePruningEnumerationRecursiveReservation.edge_cost_le seed inherited scs
    before.core.counter edge children own inheritedLength
  have actualCost : SourcePruningEnumerationNativeBranchCompletion.edgeCost scs before.core.counter edge =
      SourcePruningEnumerationSelectedEdge.cost edge scs before.core.counter tries := by
    simp only [SourcePruningEnumerationNativeBranchCompletion.edgeCost, allowed, ↓reduceIte, projected]
  have actualReserved : Reserved bits seed
      (SourcePruningEnumerationSelectedEdge.cost edge scs before.core.counter tries) := by
    simpa only [actualCost] using reserved.prefix costBound
  refine ⟨tries, residual, projected, actualReserved, ?_⟩
  exact SourcePruningEnumerationConstructorCallback.accepted_prepared_constructor_callback
    seed formulas solver inventory caller before checkEmpty parentEntry edges depth free edge scs memos
    metadata packet proper target handle ready incoming stored parentAvailable parentClosed selected
    ambient assignment term parentValue satisfied accepted tries residual projected fits actualReserved known
    graph templates refuted avoids encoded
'''
text = '''import MicroCFTA.SourcePruningEnumerationConstructorCallback
import MicroCFTA.SourcePruningEnumerationRecursiveReservation

''' + prefix + '''/-- An original resource forecast derives the projection and full prepared callback progress. -/
''' + inputs + ''' :
    ∃ (tries : List EqualityTrie.Trie) (residual : Option Constraint),
      SourcePruningEnumerationConstraint.project edge.entry.key.constraint = some (tries, residual) ∧
      Reserved bits seed (SourcePruningEnumerationSelectedEdge.cost edge scs before.core.counter tries) ∧
''' + result + ' := by\n' + body + '\nend MicroCFTA.SourcePruningEnumerationPreparedConstructorForecast\n'
path = root / 'lean/MicroCFTA/SourcePruningEnumerationPreparedConstructorForecast.lean'
assert not path.exists()
path.write_text(text)
modules = json.loads((area / 'modules.json').read_text()); modules.append(path.stem)
(area / 'modules.json').write_text(json.dumps(modules, indent=2)+'\n')
declaration = path.stem + '.accepted_constructor_callback'
for name in ['new-public-declarations.json', 'public-declarations.json']:
    values = json.loads((area / name).read_text()); values.append(declaration)
    (area / name).write_text(json.dumps(values, indent=2)+'\n')
(area / 'prepared-forecast-v1.json').write_text(json.dumps([['lake', 'prepared-forecast-v1-build', 'MicroCFTA.'+path.stem], ['strict', 'prepared-forecast-v1-strict', path.stem]], indent=2)+'\n')
(area / 'forecast-contract-recovery.json').write_text(json.dumps(dict(entire_callback_result_literal=result in text, callback_result_bytes=len(result.encode()), new_inputs='Original inherited length bound and seed edgeCount reservation replace the supplied projection and exact selected-edge reservation.'), indent=2)+'\n')
print(path.stem, len(text.encode()), len(text.splitlines()))
