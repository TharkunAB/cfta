# Prepared constructor forecasts

The full formalization goal remains ACTIVE.
Read final-documents/lean/notes-current-prepared-constructor-forecast.md first.
Original local acceptance and seed forecasts derive the actual projection and
exact edge reservation. The full same-model constructor/callback progress,
recursive Packet and common local work result remain. All old APIs remain.
The actual ordered worker can stop at an earlier hook before the chosen edge.
Global resources/neutral work, unfolding/public coverage, exact public order
and stops, and Haskell correspondence remain in the full objective.

Every regular file is archived without filtering. Keep this tree and every
reconstruction immutable. Continue in a fresh writable area. Historical labels
and evidence corrections remain. Five strict mappings identify final sources.
Use final-strong-sources.json with471 current identities for the next baseline.
Verification executes no Lean or Haskell code.
