
{- | Keep an ordinary child in a slot until the ready-hole loop selects it.
Install its full suspended constraints through the existing waiting counter.
Terminal endpoints still merge through the existing node-preparation path.
-}
prepareShallowChild ::
    (Hashable symbol, Typeable symbol) =>
    Seq SuspendedConstraint -> Node symbol -> EnumerateM symbol (TermFragment symbol)
prepareShallowChild scs n@(Node _)
    | not (any (isTerminalPathTrie . scGetPathTrie) scs) = do
        uv <- addUVarValue (Just n)
        setUVarValue uv (UVarUnenumerated (Just n) scs)
        pure (TermFragmentUVar uv)
prepareShallowChild scs n = enumerateNode scs n
