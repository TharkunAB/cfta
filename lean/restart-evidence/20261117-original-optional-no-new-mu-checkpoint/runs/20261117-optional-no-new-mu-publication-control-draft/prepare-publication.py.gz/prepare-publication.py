from pathlib import Path
import hashlib
import json
import re
import shlex
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
work = base / '20261117-original-optional-no-new-mu-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this candidate into the active Work directory'
prior_run = base / '20261117-native-source-admission-publication'
prior_archive = base / '20261117-native-source-admission-checkpoint'
runtime = base / '20261117-original-optional-no-new-mu-publication'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
native_name = 'lean/MicroCFTA/SourceSynthesisCurrentUniverseNativeAllocation.lean'
cold_name = 'lean/MicroCFTA/SourceSynthesisCurrentUniverseColdNoNewMu.lean'
native_sha = '136dfc05f774d575363d82768582b0db637f0a6c2a79f2e198baa10ef15093e3'
cold_sha = '357eb2906f74f71372fd06721300d720f2ae2666d3b546d1bf068999b48779db'
old_native_sha = '6ad6a65a49512b891fb043b8185c57650e280f4011f1c35ecf6235d994e7af9f'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
prior_commit = 'b8f734b528e7fadee83e47bb90625bcd9519553a'
stage = json.loads((work / 'SOURCES-NORMAL-STAGING.json').read_text())
components = stage['components']
assert len(components) == 2
expected_components = [
    {'module': 'SourceSynthesisCurrentUniverseNativeAllocation',
     'namespace': 'SourceSynthesisCurrentUniverseNativeAllocation',
     'source_path': native_name, 'raw_sha256': native_sha,
     'theorems': ['original_universe_mu_query_prefix_admission', 'original_universe_optional_prefix_no_new_mu']},
    {'module': 'SourceSynthesisCurrentUniverseColdNoNewMu',
     'namespace': 'SourceSynthesisCurrentUniverseNativeAllocation',
     'source_path': cold_name, 'raw_sha256': cold_sha,
     'theorems': ['original_universe_cold_query_no_new_mu']}]
assert [{key: component[key] for key in expected}
        for component, expected in zip(components, expected_components)] == expected_components
assert re.fullmatch(r'[0-9a-f]{64}', components[1]['raw_sha256'])
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports']) == (6250, 5250, 660)
assert stage['new_normal_modules'] == 1 and stage['new_public_theorems'] == 2
assert stage['new_private_theorems'] == 7 and stage['new_private_predicates'] == 0
assert stage['optional441e_proved'] and stage['cold_whole_query_no_new_mu_proved']
assert stage['source_admission_cold_root_scope']
assert (stage['fresh_strict_reports'], stage['inherited_bound_reports'], stage['combined_component_reports']) == (46, 406, 452)
assert stage['old_native_reports_replaced'] == 37
assert stage['old_owner_exact_offset'] == 55 and stage['old_owner_exact_bytes'] == 126437
assert stage['all_old_proof_bodies_and_limits_unchanged']
assert stage['original_fuel_and_all_prefixes_retained'] and stage['terminal_blocked_effects_retained']
assert not stage['independent_query_inherited_warm_tables_proved']
assert not stage['joint_finite_completion_proved'] and not stage['haskell_changed']
assert not stage['all_native_inhabitance_proved'] and not stage['source_type_marker_class_consistency_proved']
assert not stage['compiled_haskell_correspondence_proved']
prior = json.loads((prior_run / 'checked.json').read_text())
assert len(prior['checks']) == 5 and all(c['exit'] == 0 and not c['nonstandard_axioms']
    and not c['diagnostics'] and not c['sorryAx'] for c in prior['checks'])
assert (prior['source_files'], prior['independent_reports'], prior['resource_and_component_probes']) == (6249, 253, 443)
assert prior['whole_worker_program_slots_proved'] and prior['whole_worker_roles_proved']
assert prior['owner_resource_probes'] == 264 and prior['native_source_admission_proved']
assert prior['fresh_resource_component_reports'] == 38 and prior['inherited_resource_component_reports'] == 405
assert prior['source_admission_cold_root_scope']
baseline = json.loads((work / 'baseline-source-pins.json').read_text())
assert len(baseline) == 6249 and cold_name not in baseline
assert {str(path.relative_to(root)) for path in (root / 'lean/MicroCFTA').glob('*.lean')} == set(baseline) | {cold_name}
old_native = (work / 'NATIVE-OWNER-BEFORE.lean.txt').read_bytes()
old_audit = (work / 'AUDIT-BEFORE.lean.txt').read_bytes()
assert len(old_native) == 126437 and sha(old_native) == old_native_sha
assert old_audit.count(b'#print axioms ') == 658
for name, digest in baseline.items():
    data = old_audit if name == audit_name else old_native if name == native_name else (root / name).read_bytes()
    assert sha(data) == digest, name
assert len(set(baseline) - {audit_name, native_name}) == 6247
assert sha((root / owner_name).read_bytes()) == owner_sha
assert (root / native_name).read_bytes()[55:55 + len(old_native)] == old_native
for component in components:
    assert sha((root / component['source_path']).read_bytes()) == component['raw_sha256']
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
qnames = ['MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation.original_universe_optional_prefix_no_new_mu',
          'MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation.original_universe_cold_query_no_new_mu']
assert public == ''.join('#check ' + q + '\n#print axioms ' + q + '\n' for q in qnames).encode()
new_import = b'import MicroCFTA.SourceSynthesisCurrentUniverseColdNoNewMu\n'
audit = (root / audit_name).read_bytes()
assert audit == new_import + old_audit + b'\n' + public
assert sum(line.startswith(b'import ') for line in audit.splitlines()) == 5250
assert audit.count(b'#print axioms ') == 660
optional_header_path = base / '20261117-original-universe-optional-no-new-mu-proof-draft/PUBLIC-DECLARATION.lean.txt'
cold_header_path = base / '20261117-original-universe-cold-query-no-new-mu-draft/PUBLIC-HEADER.lean.txt'
for path, header_path, theorem in [
    (root / native_name, optional_header_path, 'original_universe_optional_prefix_no_new_mu'),
    (root / cold_name, cold_header_path, 'original_universe_cold_query_no_new_mu')]:
    source_text = path.read_text()
    declaration = 'theorem ' + theorem + '\n'
    start = source_text.index(declaration)
    header = header_path.read_text()
    assert source_text[start:source_text.index(' := by', start)].rstrip() == header[header.index(declaration):].rstrip()
cold_verified_path = work / 'COLD-QUERY-FIRST-VERIFIED.json'
cold_verified = json.loads(cold_verified_path.read_text())
assert cold_verified['actual_terminal_exit'] == 0
assert cold_verified['original_fuel_and_all_prefixes_retained']
assert cold_verified['terminal_blocked_effects_retained']
assert not cold_verified['semantic_or_future_result_law_supplier']
checked_inputs = [cold_verified_path]
for component, expected_count in zip(components, [43, 3]):
    normal_check = base / component['actual_normal_check']
    normal_checked = json.loads((normal_check / 'checked.json').read_text())
    assert normal_checked['normal_module_checked'] and all(normal_checked['passed'])
    assert normal_checked['source_pins_unchanged']
    assert normal_checked['checks'][1]['total_axiom_reports'] == expected_count
    assert all(item['exit'] == 0 and not item['nonstandard_axioms'] and not item['diagnostics']
               and not item['sorryAx'] for item in normal_checked['checks'])
    checked_source = normal_check / 'source/MicroCFTA' / (component['module'] + '.lean')
    assert checked_source.read_bytes().startswith((root / component['source_path']).read_bytes())
    if component['source_path'] == cold_name:
        assert cold_verified['run'] == component['actual_normal_check']
        assert cold_verified['checks'] == normal_checked['checks']
    checked_inputs += [normal_check / name for name in ['checked.json', 'selection.json', 'normal-module.txt', 'source-pins.json']]
    checked_inputs.append(checked_source)
# Validation above is read-only. Only Root may create the publication run.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-optional-no-new-mu-publication-'))
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
(runtime / 'PUBLIC-PROBES.lean.txt').write_bytes(public)
commands = []
strict_sources = []
fresh_count = 0
for component in components:
    normal = root / component['source_path']
    namespace = component.get('namespace', component['module'])
    helpers = re.findall(r'^private theorem ([A-Za-z0-9_]+)', normal.read_text(), re.M)
    predicates = re.findall(r'^private def ([A-Za-z0-9_]+)', normal.read_text(), re.M)
    if component['source_path'] == native_name:
        assert len(helpers) == 41
        assert predicates == ['NodeAdmission', 'EdgeAdmission', 'CodeAdmission', 'ControlAdmission']
        public_names = ['original_universe_mu_query_prefix_admission', 'original_universe_optional_prefix_no_new_mu']
    else:
        assert len(helpers) == 2 and not predicates
        public_names = component['theorems']
    names = helpers + public_names
    probes = ''.join('#check @MicroCFTA.' + namespace + '.' + name + '\n#print axioms MicroCFTA.'
                     + namespace + '.' + name + '\n' for name in names)
    probes += ''.join('#check @MicroCFTA.' + namespace + '.' + name + '\n' for name in predicates)
    fresh_count += len(names)
    source = runtime / 'source/MicroCFTA' / normal.name
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_bytes(normal.read_bytes() + b'\n' + probes.encode())
    (runtime / (component['module'] + '-PROBES.lean.txt')).write_text(probes)
    strict_sources.append(source)
    commands.append(['lake', 'env', 'lean', '-j1', '-DwarningAsError=true', '-R',
        str(source.parent.parent), '-o', str(objects / (component['module'] + '.olean')), str(source)])
assert fresh_count == 46
independent = runtime / 'IndependentProbes.lean'
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert b'import MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation\n' in prior_independent
assert new_import not in prior_independent
assert prior_independent.count(b'#print axioms ') == 253
independent.write_bytes(new_import + prior_independent + b'\n' + public)
assert independent.read_bytes().count(b'#print axioms ') == 255
selection = {'prior_checkpoint': prior_commit,
    'prior_archive_manifest_sha256': sha((prior_archive / 'manifest.json').read_bytes()),
    'prior_checked_sha256': sha((prior_run / 'checked.json').read_bytes()),
    'prior_pins_sha256': sha((prior_run / 'source-pins.json').read_bytes()),
    'baseline_sha256': sha((work / 'baseline-source-pins.json').read_bytes()),
    'stage_sha256': sha((work / 'SOURCES-NORMAL-STAGING.json').read_bytes()),
    'old_audit_sha256': sha(old_audit), 'old_native_sha256': sha(old_native),
    'unchanged_resource_owner_sha256': owner_sha,
    'prior_source_files': 6249, 'prior_combined_reports': 443,
    'replaced_old_native_reports': 37, 'inherited_reports': 406,
    'fresh_reports': 46, 'combined_reports': 452,
    'new_native_strict_reports': 43, 'new_cold_strict_reports': 3,
    'new_theorem_declarations': 9,
    'old_normal_sources_byte_exact_except_audit_and_native': 6247,
    'old_native_bytes': 126437, 'old_native_exact_offset': 55,
    'old_audit_bytes_retained_after_one_import': True,
    'owner_preflight_reports_fresh_this_batch': 0, 'owner_reports_inherited': 264,
    'old_toolchain_and_proof_inputs_reverified': True, 'axiom_strings_replayed': False}
(runtime / 'INHERITANCE-SELECTION.json').write_text(json.dumps(selection, indent=2) + '\n')
STRICT_BINDING_TEMPLATE = '''from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/home/tritlo/Code/mcfta')
runtime = Path(__file__).parent
prior = root / 'lean/restart-evidence/20261117-native-source-admission-publication'
archive = root / 'lean/restart-evidence/20261117-native-source-admission-checkpoint'
work = root / 'lean/restart-evidence/20261117-original-optional-no-new-mu-work'
sha = lambda data: hashlib.sha256(data).hexdigest()
selection = json.loads((runtime / 'INHERITANCE-SELECTION.json').read_text())
assert sha((archive / 'manifest.json').read_bytes()) == selection['prior_archive_manifest_sha256']
committed = subprocess.check_output(['git', 'show', selection['prior_checkpoint'] + ':'
    + str((archive / 'manifest.json').relative_to(root))], cwd=root)
assert committed == (archive / 'manifest.json').read_bytes()
subprocess.run(['python3', str(archive / 'verify.py')], check=True)
records = json.loads((archive / 'archived-inputs.json').read_text())
for name in ['checked.json', 'source-pins.json']:
    path = prior / name
    record = next(item for item in records if item['original'] == str(path))
    archived = (archive / record['archived']).read_bytes()
    if record['gzip']:
        archived = gzip.decompress(archived)
    assert archived == path.read_bytes()
assert sha((prior / 'checked.json').read_bytes()) == selection['prior_checked_sha256']
assert sha((prior / 'source-pins.json').read_bytes()) == selection['prior_pins_sha256']
assert sha((work / 'baseline-source-pins.json').read_bytes()) == selection['baseline_sha256']
assert sha((work / 'SOURCES-NORMAL-STAGING.json').read_bytes()) == selection['stage_sha256']
assert sha((work / 'AUDIT-BEFORE.lean.txt').read_bytes()) == selection['old_audit_sha256']
assert sha((work / 'NATIVE-OWNER-BEFORE.lean.txt').read_bytes()) == selection['old_native_sha256']
for name, digest in json.loads((prior / 'source-pins.json').read_text()).items():
    if name == 'lean/MicroCFTA/Audit.lean':
        data = (work / 'AUDIT-BEFORE.lean.txt').read_bytes()
    elif name == 'lean/MicroCFTA/SourceSynthesisCurrentUniverseNativeAllocation.lean':
        data = (work / 'NATIVE-OWNER-BEFORE.lean.txt').read_bytes()
    else:
        data = (root / name).read_bytes()
    assert sha(data) == digest, name
assert sha((root / 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean').read_bytes()) == selection['unchanged_resource_owner_sha256']
print(json.dumps({'inherited_component_reports_verified': 406,
                  'fresh_component_reports_expected': 46,
                  'fresh_owner_preflight_reports': 0,
                  'unchanged_owner_reports_inherited': 264,
                  'old_sources_and_toolchain_byte_exact': True}), flush=True)
'''
strict = runtime / 'strict-new-and-bind.py'
strict.write_text(STRICT_BINDING_TEMPLATE + '\ncommands = ' + repr(commands)
    + '\nfor command in commands:\n    subprocess.run(command, check=True)\n')
template = (prior_run / 'check.py').read_text()
driver = template[:template.index('\njobs =')]
jobs = [('public-build', 'exec lake build', 0),
    ('strict-new-components-and-prior-bindings', 'exec python3 ' + shlex.quote(str(strict)), 46),
    ('independent-imports', 'exec lake env lean -j1 -DwarningAsError=true ' + shlex.quote(str(independent)), 255),
    ('audit-build', 'exec lake build MicroCFTA.Audit', 0),
    ('audit-strict', 'exec lake env lean -j1 -DwarningAsError=true MicroCFTA/Audit.lean', 660)]
driver += '\njobs = ' + repr(jobs) + '''
for name, command, count in jobs:
    run(name, command, count)
assert len(checks) == 5
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx']
           and (not job[2] or c['total_axiom_reports'] == job[2]) for c, job in zip(checks, jobs))
match = re.search(r'Checked axiom dependencies of (\\d+) MicroCFTA theorems\\.', (runtime / 'audit-strict.txt').read_text())
assert match
'''
report = dict(prior)
for name in ['checks', 'limits', 'at', 'audited_theorems', 'checked_code', 'owner_preflight_evidence',
             'legacy_new_private_reports', 'legacy_new_private_reports_caveat', 'new_owner_export_maxHeartbeats']:
    report.pop(name, None)
for name in list(report):
    if name.startswith('old_non_audit_'):
        report.pop(name)
report.update(source_files=6250, direct_audit_imports=5250, individual_reports=660,
    independent_reports=255, resource_and_component_probes=452,
    inherited_resource_component_reports=406, fresh_resource_component_reports=46,
    replaced_old_native_reports=37, old_native_reports_rechecked=37,
    fresh_native_strict_reports=43, fresh_cold_strict_reports=3,
    fresh_owner_preflight_reports=0, fresh_strict_normal_reports=46, actual_publication_strict_reports=46,
    resource_component_evidence='46 actual fresh strict reports (43 native including the replaced old37, plus3 cold whole-query reports) and406 inherited reports (443 prior minus37 old native); no owner recompile or axiom-string replay',
    new_component_reports=9, new_theorem_reports=9, new_modules=1, new_public_theorems=2,
    new_private_component_reports=7, new_public_component_reports=2, new_private_predicates=0,
    new_relation_declaration_checks=4, new_relation_declaration_reports=0,
    owner_resource_probes=264, previous_owner_resource_probes=264,
    owner_recompiled_in_publication_strict_gate=False, fresh_owner_preflight_evidence=None,
    inherited_owner_preflight_evidence={'prior_run': str(prior_run), 'reports': 264,
        'normal_owner_sha256': owner_sha, 'fresh_this_batch': False, 'included_in_inherited_406': True},
    old_non_audit_non_native_source_files_byte_exact=6247,
    old_non_audit_source_files_byte_exact=6247, entire_previous_resource_owner_byte_exact=True,
    old_resource_owner_sha256=owner_sha, old_native_exact_bytes=126437, old_native_exact_offset=55,
    old_native_bytes_preserved_contiguously=True,
    old_audit_bytes_preserved_after_one_import=True, all_old_proof_bodies_and_limits_unchanged=True,
    normal_source_optional441e_staged=True, cold_whole_query_no_new_mu_staged=True,
    optional441e_proved=True, original441e_public_declaration_exact=True,
    original_cold_query_public_declaration_exact=True,
    cold_whole_query_no_new_mu_proved=True, cold_every_bounded_trace_prefix_no_new_mu_proved=True,
    actual_execute_outcome_heap_including_blocked_and_pending_retained=True,
    native_source_admission_proved=True, source_active_mu_admission_proved=True,
    source_admission_cold_root_scope=True, same_original_runtime_fuels=True,
    no_future_OnlyU_body_or_result_law_supplier=True,
    source_admission_scope={'source': 'accepted firstOrderRaw original build and its stored full U',
        'root': 'literal emptyDomain; both native memo families initially empty',
        'operands': 'both original root operands satisfy Profile(entry.identity)',
        'trace': 'same original checked rooted execution, its actual execute outcome heap and every bounded Trace prefix; all supplied fuels retained',
        'plans': 'original InputsThrough and FieldsThrough remain explicit physical premises',
        'result': 'NoNewMu at actual outcome and every bounded trace prefix; optional441e handles pending outcomes'},
    independent_query_inherited_warm_tables_proved=False, warm_across_independent_queries_proved=False,
    joint_finite_completion_proved=False, all_native_inhabitance_proved=False,
    source_terminal_marker_native_inhabitance_proved=False, source_type_marker_class_consistency_proved=False,
    compiled_haskell_correspondence_proved=False, haskell_changed=False,
    whole_worker_roles_proved=True, whole_worker_program_slots_proved=True,
    whole_worker_program_slots_fixed_marks_proved=True,
    proof_limits='unchanged defaults; unchanged owner proof settings inherited',
    prior_checkpoint=prior_commit, prior_immutable_archive=prior_archive.name, public_run=str(runtime))
driver += 'report = ' + repr(report) + '\n'
driver += '''report.update(checks=checks, limits=limits, at=datetime.datetime.now().astimezone().isoformat(),
              audited_theorems=int(match.group(1)))
(runtime / 'checked.json').write_text(json.dumps(report, indent=2) + '\\n')
print(json.dumps(report), flush=True)
'''
(runtime / 'check.py').write_text(driver)
files = list((root / 'lean/MicroCFTA').glob('*.lean'))
files += [root / name for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']]
files += [p for p in runtime.iterdir() if p.is_file()] + strict_sources
files += [Path(__file__), work / 'SOURCES-NORMAL-STAGING.json', work / 'baseline-source-pins.json',
    work / 'AUDIT-BEFORE.lean.txt', work / 'NATIVE-OWNER-BEFORE.lean.txt', optional_header_path,
    cold_header_path] + checked_inputs
(runtime / 'source-pins.json').write_text(json.dumps(
    {str(p.relative_to(root)): sha(p.read_bytes()) for p in files}, indent=2) + '\n')
print(json.dumps({'run': str(runtime), 'gates': 5, 'fresh_component_reports': 46,
    'inherited_component_reports': 406, 'combined_component_reports': 452,
    'replaced_old_native_reports': 37, 'fresh_owner_preflight_reports': 0,
    'inherited_owner_reports': 264, 'independent_reports': 255,
    'audit_reports': 660, 'objects': str(objects)}))
