PASS: completed child-traversal stability contract review

Created 2026-10-28 20:28:49 CET. The installed 48-line, 2,795-byte primary source matches SHA256 a4e395d59e0519f527b8fa8d4ecc6a105a82ba5b0556688b0bc152e72348b379. All three assigned/relevant sources were read whole. No compiler, native execution, Git, network, board or repository edit was used.

Public contracts

Trace.moreBounds takes one ACTUAL complete Trace at primitive bounds r,n,p,h,k and five independent coordinatewise inequalities r<=R,n<=N,p<=P,h<=H,k<=K. It returns the same Trace at R,N,P,H,K. The input list, checkEmpty flag, original caller/cache/queries, exact fragment list and final caller/cache/queries are unchanged.

run_complete_moreBounds takes a literal run(...)=Result.complete fragments afterCaller afterQueries after observation and the same five inequalities. It concludes the identical literal complete result at the larger primitive bounds. It adds no resource, model, Packet, typing, native Heap, original source equality or output-existence premise. Width remains the same arbitrary Nat index. Equality holds for the full caller and Cached structures, including their component fields and both cache indexes; there is no quotient or source/prepared cast.

Proof route and exact endpoint alignment

ChildTraversal.Trace.cons records a literal child run whose raw result is exactly one successful row, whose returned core equals the actual middle cache core, and whose optional cache is some middle. Its tail starts from that SAME middle caller/cache/query endpoint.

Trace.moreBounds uses ChildDispatch.run_singleton_stable for each actual head observation, then the tail induction hypothesis. The child helper preserves every field of that head tuple: fragment, returned core, caller, queries, outer core, waiting map and some cache. Hence the same intermediate state is available to the next child without an added relation or future endpoint assumption.

run_complete_moreBounds first derives the trace using the existing complete_trace theorem, lifts it, then reconstructs the exact run using trace_complete. complete_trace itself examines the actual run. A raw error, no raw result, empty raw list, multiple rows, missing cache or stopped tail cannot produce Result.complete. For a singleton with some cache it uses the actual ChildDispatch.singleton_core fact to align the returned raw core with that cache. No admission premise is needed to obtain the trace from an observed completion.

Scope and limits

The theorem preserves an already observed COMPLETE traversal. It does not assert completion exists at any original bound. It does not upgrade an exhausted or stopped observation, prove stability for arbitrary errors/stops or provide a recursion-depth completion result. A malformed input can satisfy the theorem only if its actual runtime observation already is complete; no resource validity is inferred from that observation.

ChildDispatchStability has separately gated helper statements. Its run_some_stable handles a literal some cache with raw=[] or a singleton successful row. The traversal theorem uses only the singleton specialization. It does not silently import the helper's empty-rejection case as a successful child traversal.

For inputs=[], the nil trace returns the same original endpoint and empty fragment list at every bound. For nonempty inputs, all head observations must be singleton successes with actual caches. Tail order is preserved, so fragment order and complete endpoints are exact.

Review evidence

sources/ preserves all three complete input files and hashes. signatures/ preserves the two reviewed public declarations plus the three supporting declarations, all as literal source statements. source-manifest.json records byte counts, line counts, hashes and read scope. Root reported default+strict PASS for the two new exports; this review independently checks their source contracts and does not run those checks or replace the public axiom readback.

No concern was found in this bounded review. All previous frozen directories remain unchanged.
