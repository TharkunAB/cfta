# Original resources through an actual child prefix

Date: 2026-10-28T20:38:21+01:00.

Root's exact 100-line candidate passes its first default and strict checks without repair. It proves preservation through an actual ordered child prefix. It also retains all original admissions for an untouched suffix. The child did not run a compiler.

## Exact statement and original gates

Module: `SourcePruningEnumerationTraversalPrefixProjectionHeap`.

Theorem: `TraversalCompletion.trace_prefix_resources_projection_heap`.

The actual `ChildTraversal.Trace` consumes `inputs` at fixed supplied bounds. The original genuine-input condition and mixed reservation cover the original list `inputs ++ rest`. The original local caller supplies Context, Safe, roots, waiting counts, native flags, pending realization, Fits, Known, and projection heap.

`memos.query = queries` attaches the supplied original full Memos to the actual trace's initial query endpoint. It is reflexivity when the trace comes from the actual original call. No future Memos, Context, heap or model is supplied.

The result derives an actual next Inventory, full final Memos, and roots. Its Post links the original and actual reached native caller. The final Memos query equals the trace's actual saved endpoint. The reached cache has Safe, roots/counts/flags, and pending realization. Every untouched suffix input retains actual availability, closure, variable bounds and pending admission there.

The same reached caller has Fits and Known at `advance seed (cost inputs)`. The untouched suffix retains `Reserved bits (advance seed (cost inputs)) (cost rest)`. Every resident edge constraint in the reached native heap projects. The projection input applies only to the original local heap.

## Constructive induction

The empty trace uses the original current packet and `Post.refl`.

For a cons trace, the actual head call feeds the checked next-entry adapter. That adapter identifies the original producer's actual caller/cache/full Memos with the supplied singleton. It derives the next original traversal admissions and projection heap. The induction then processes the actual tail trace at that same returned caller and full Memos. `Post.trans` composes the physical histories. `advance_add` composes the original numeric/alphabet schedule.

No generic future-child supplier is introduced. No projection invariant is inferred from arbitrary native heap growth. The old existential traversal producer and all old source bytes remain unchanged.

## Completion and stop attachment

For an actual `.complete` return, existing `ChildTraversal.complete_trace` derives its exact ordered trace. Set `rest = []` and simplify `inputs ++ []`. The prefix theorem then supplies the actual returned Post, full final Memos, resource bounds and projection heap. It does not assert that such a completion exists.

For an actual `.stopped` return, existing `stopped_trace` supplies an actual completed-prefix trace and the exact next stopping call. Keep that stopping input and the later inputs as the untouched suffix. The prefix theorem derives all current original admissions at the actual stopping caller. The checked child observation theorem can then derive the stopping call's reached heap when its outer result is `.ok`, including missing cache, missing action and empty raw rejection.

This candidate does not include that separate final stopped-call wrapper. It does not claim projectability at a stopping call's outer native error endpoint. No counterexample to that further property is asserted. The distinction retains the actual reached native effects without assuming them away.

## Claim limits

The trace contains literal actual child calls. It is execution evidence, not an oracle that a future execution completes. The theorem supplies no output-existence, global recursive depth, uniform progress, complete coverage, rendering, Haskell correspondence or whole-driver proof. It adds no source/prepared identity premise, desired future heap, model, custom axiom, resource limit or linter setting. No Haskell code changed.

## Checked and frozen evidence

Candidate and installed source: 7,118 bytes, 100 lines. SHA256: `48ad9138209519842c0d8523bc1db0e24b8d2811182caeefe4183e95b5dec529`. Exact byte comparison passes. Root made no repair.

The complete default raw log has 573 bytes, SHA256 `57672d869dcde6b735a66a36b93f0e596a6e4239a6b4fcae0530d3b7ef64b530`. It reports a successful 1,990-job build. It also replays an unrelated old-module warning. The exact strict raw log is empty, SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. Root reported strict PASS. Both logs are copied whole. No linter suppression was added.

Eight whole source reads are preserved with hashes. Five were read in this bounded task. Three earlier whole reads are rebound to current source by exact byte equality with their frozen copies. These include the actual trace, cost definition, checked next-entry adapter, Post/context composition, resource schedule, and earlier induction patterns. The installed prefix source is copied separately and is identical to the candidate.

The full Audit was still running in Root's 20:35 update. This report does not assert its outcome. The candidate, copied evidence, manifest and report are frozen. No next proof task is included.
