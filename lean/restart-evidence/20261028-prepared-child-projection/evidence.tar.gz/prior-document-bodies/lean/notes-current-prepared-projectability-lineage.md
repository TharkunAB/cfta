# Current prepared projectability preservation

Verified update: 2026-10-28, Europe/Stockholm.
Source: `dbc7c240c0ee313467681bab22586c50437459b0` on `formalize`.
The full formalization goal remains active.

The Lean terminal operation now preserves projectability of its actual returned
native heap, together with its original resource bounds. This includes supported
returns with no outputs. The ordered fold derives every next current admission
from its actual completed predecessor. It does not assume a later heap property.

Projectability means that every resident native edge constraint has a supported
projection through `SourcePruningEnumerationConstraint.project`. This is a
structural property. It does not assert a satisfying model or an emitted output.
The original operation caller's whole ProjectionHeap remains explicit. The
existing checked-source construction can supply the initial heap. The new local
theorems preserve it through actual operations. Bare Packet, Fits and Known do
not imply it. In particular, forecast alphabet membership is not projectability.

The earlier strongest semantic results remain unchanged. The original-resource
finite prepared worker preserves its resource, history, canonical and arity
certificates under their explicit original conditions. Checked rendered outputs
that meet the fixed-PCS and whole-Discharged conditions have the original native
root meaning and satisfy the original suspended constraints. At fixed work fuel
and other inputs, greater recursive depth retains every earlier full output
record in order, including outputs from stopped runs. Two originally admitted
resource depths also have stable actual results with the same prefix relation.
None of these results proves that an output exists.

## Full goal and remaining gaps

Continue the intended CFTA formalization and its correspondence with the
optimized interned implementation. Preserve all proofs, counterexamples,
repairs and marked drafts. Keep older constructor and equality work as secondary
targets. Include the public language operations and count/rank/unrank/sample
integration in the full goal.

The main gap remains an actual model-preserving emitted output and an original
finite recursive depth for all earlier ordered allocating callbacks and the
chosen continuation. Completed-result stability and output-prefix preservation
do not prove that bound. Reservations indexed by a requested depth do not derive
the depth from the original source. No admitted all-depth runtime counterexample
has been established by the recent bounded audits.

Projectability now passes through the local native query, incoming write,
dispatcher, ordered fold and terminal operation. It must still pass through
ChildDispatch, ordered child traversal, captured finalization, callback recording
and the whole finite recursive producer. Original source/key ancestry and the
finite original inventory budget must also survive actual merges, fresh own tries
and later callbacks. The new assimilation lemma is one local preservation step.

Complete selector and policy coverage, semantic origin preservation, public input
and acceptance adapters, and physical optimized Haskell correspondence remain
open. Selected-row membership/length bounds permit an empty selector. DONE does
not imply Discharged. Intended partial outputs remain in scope.

## Six exact new contracts

Six new modules contain six public theorems and no new definitions. Their final
source contains 808 lines and 48,830 bytes. There is one private proof helper.
All earlier declarations remain unchanged.

`SourcePruningEnumerationIncomingQueryProjectionHeap` exports
`IncomingQuery.raw_done_resources_projection_heap`.
It keeps the original Context, operand availability and closure, Fits, Room and
Known premises of raw_done_resources. It adds only the original caller's whole
ProjectionHeap. Its observations are the actual native intersection .done and
actual optional Empty .done, at arbitrary supplied successful bounds. It keeps
the exact old Fits/Known pair and derives ProjectionHeap at checkedAfter plus
`Annotated projectable (if answer then .empty else query)`.

The original complete_resources producer supplies the rich native receipt.
Its actual trace preserves the original heap property. Disabled and skipped
Empty phases keep that heap. A performed phase uses its actual conjunction call.
Produced Post-linked records and produced replacement availability derive the
replacement annotation property. Native completed_unique and optional_done_unique
identify the produced values and complete checked states with the supplied
observations. No future Heap, model, output or child-support premise is used.

`SourcePruningEnumerationIncomingNodeProjectionHeap` exports
`IncomingNode.observed_resources_projection_heap`.
It retains all original observed_resources inputs and its Fits/Known pair. It
adds originalProjection and derives ProjectionHeap at the exact returned caller.
The actual outer .ok scope includes absent results, inner representative/slot
errors, missing lookups, failed encoding and Empty rejection. Native and optional
Empty outer errors cannot satisfy the observer. The theorem does not claim
invariants for arbitrary failed native prefixes.

The existing run_complete_resources already returns the actual replacement,
its Available, encode and lookup witnesses, and Post at the same caller. Its
base-fuel observation supplies the new theorem's observation. Combine the derived
heap with its existing linked records and replacement availability to obtain
replacement Annotated support. The new adapter does not duplicate the large
producer tuple or add an all-future-lookups supplier.

`SourcePruningEnumerationDispatchProjectionHeap` exports
`Dispatch.observed_resources_projection_heap`.
It retains the same original resource inputs and pair, adds originalProjection,
and derives the actual outer successful dispatch caller's ProjectionHeap. Equal
slots, missing slots or handles, eliminated sources and failed lookups keep the
caller. In the actual two-handle branch, PendingRealized derives both operands'
availability and closure. The query adapter supplies the reached heap at the
literal native and optional-check observations. A missing action remains in
scope. Arbitrary outer native errors remain outside the .ok observer.

`SourcePruningEnumerationFoldProjectionHeap` exports
`Fold.observed_resources_projection_heap`.
It keeps the original resource conclusion at `advance seed sources.length` and
appends the reached ProjectionHeap. It preserves source order. Each dispatch
derives the actual reached heap before the fold inspects its action. Missing,
empty, error and non-singleton raw actions stop at that same reached caller.
An exact singleton uses the existing observed_singleton producer to derive the
next inventory, complete Memos, Post.context, query equality, pending facts,
Fits and Known. The induction receives the separately derived projection heap
at that exact caller. No future-step preservation supplier is an input.

`SourcePruningEnumerationTerminalProjectionHeap` exports
`Terminal.observed_resources_projection_heap`.
It keeps every original argument and the original Fits/Known pair at
`advance seed ((first :: rest).length + 1)`. It adds only originalProjection and
derives the actual returned heap property. The literal prefix derives recorded
sources, winner and joined pending facts. Their exact length derives the fold
reservation. The fold theorem supplies its actual reached heap. For an exact
singleton fold, original Fold.run_complete plus ok_unique identifies the same
caller, core and queries. Its Post.context and effects preserve the incoming
operand's availability. The incoming-node theorem then derives the final heap.
Empty input and supported missing/empty returns retain their actual heap effects.
Outer errors are excluded by the literal .ok observation.

`SourcePruningEnumerationCachedAssimilationAncestry` exports
`CachedAssimilation.finish_ancestry`.
Its sole explicit premise is the actual successful finish observation. Every key
at every original raw slot remains at that same returned raw slot. When
`merged ≠ some 0`, every original source key also belongs to the returned target.
The Empty branch returns the original cache and performs no transfer. The private
helper derives ancestry equality from each actual NativeIndex.write. The final
update retains target and source membership through eraseDups of source++target.
No Packet, model, resource, source-distinctness or future-completion input is
required for this local statement.

CachedAssimilation.finish is the checked companion cached computation. Existing
CachedDispatch.complete retains its literal finish observations and aligns its
rows with the actual dispatch action. The new point lemma does not reprove that
alignment, bound keys, or prove global termination.

## Ancestry audit clarification

Plain raw unenumerated storage does not imply a live representative. The proposed
completed-head fresh-pending interface already includes completed.safe. Safe
contains LiveRoots, so that original completed receipt derives the representative
fact. No new root admission is needed. A live pending Mu/Union with an empty
bucket can still be excluded from candidates by the actual native candidate rule.

Actual assimilation writes the absorbed source to eliminated. It retains the
source's ancestry and transfers source keys to the target. Finalize clears only
expansionAncestry. The complete head-wide fresh-pending ancestry conclusion is
still unproved. Its original source handle must remain separate from the prepared
ordinary parent. Local key retention does not derive an original finite key set.

The earlier source-grounded measure test cases remain without a full checked
Context/Trace replay. This checkpoint does not strengthen them into operational
counterexamples or Haskell defects.

## Verification and preservation

Lean 4.34.1. All six modules and Audit pass seven exact final strict source checks
with warningAsError and linter.all. Audit passes 4,519 jobs and 81,661 theorem
dependency checks. That total includes generated and private theorems.
No proof budget increased. No placeholder, custom axiom, native proof evaluation
axiom or linter suppression was added. The unchanged old unused-variable warning
still appears during replay of InternedFreshOrdinaryClosedCompletion.

Public readback contains 701 theorem signatures/axiom lists and 60 definition
bodies. Its size is 3,100,926 bytes. SHA-256:
`d50f9f8864e9fdf5ded1231ae150a8832135c75ee3322d6d0c74dade00d99247`.
The previous 3,080,208 bytes remain an exact prefix. Root read all 20,718 new
emitted bytes and all six final new sources whole. Only propext,
Classical.choice and Quot.sound occur in the new axiom lists.

The matrix preserves fifteen compiler commands: fourteen pass and one failed
ancestry proof attempt. All final checks pass. The full failed diagnostic is
4,640 bytes. It reports deprecated if_pos/if_neg names and two membership goals
whose if True expressions did not reduce. The five-line repair uses
ite_eq_left/ite_eq_right and explicit conditional reduction. It changes no public
premise or conclusion. The original candidate, exact failed input and diagnostic
remain preserved. This is a Lean proof repair.

Every compiler command measured memory.max/high at 4,294,967,296 bytes and swap
at zero. Serial heavy-management scopes used 4 GiB and five minutes. All raw
outputs, command input snapshots, candidates, dependency/read-scope records,
public blocks, review reports, measurements and Git receipts are retained.

All 4,512 prior non-Audit Lean files, 361 prior stronger proof sources and
817 Haskell/Cabal files retain their recorded SHA-256 values. Audit prepends only
six imports to its exact old body. Fourteen earlier document bodies remain exact
suffixes. Earlier archives and frozen proof areas remain unchanged.

Source commits are `92b0d065f1a93d08705935e8e867cae423a07c19`,
`3795a659a6d4bea34f92c1d78b3d7b5f9e08a092`,
`67d85a181406585d5af3aebe4920817af54abc83`, and
`dbc7c240c0ee313467681bab22586c50437459b0`. They were pushed normally to the
authorized formalize branch. The exact remote source head was read back.
Upstream was refreshed at the start of this continuous proof work.
origin/main remains an ancestor. No older proof, draft or Haskell source changed.

Current proof area: `/tmp/mcfta-prepared-projectability-lineage-20261028`.
Complete committed evidence after publication:
`lean/restart-evidence/20261028-prepared-projectability-lineage/`.
Use its manifest and verifier to reconstruct every payload in a fresh directory.
Keep sealed and reconstructed data immutable. Continue in a new writable area.
Documentation and publication receipts follow the source receipts.

Board sequence 705 has ID `c82b5dde-8043-4084-a2dc-65c820c70f59` in thread
`1c1333d7-46ea-4f46-a9a1-b5d13e577337`. The exact request was stored before
writing. Author, content and metadata were read back and compared. Full board
readbacks remain in the archive.

## Next bounded work and Haskell handoff

A source-only ChildDispatch adapter is ready in the separate writable proof area
`/tmp/mcfta-prepared-child-projection-20261028/child/`.
Its module is SourcePruningEnumerationChildProjectionHeap. Candidate SHA-256:
`9a7c5a4f4586073aa9cd61bdf54a0866bd9775bbfc117b3d5688b012fbcefc45`.
It has not been installed or compiled at this checkpoint. The frozen child
candidate, report and read-scope evidence are copied under next-draft-child in
this archive. Keep its UNTESTED status. Review it whole before installation.

Then carry the invariant through actual ordered child traversal and captured
finalization, actual callback recording, and the finite prepared producer.
Use original Context/Post and the actual returned full memo witnesses. Include
aggregate callers on no-output branches. Do not add future Heap, child support,
model, emitted-output or generic preservation suppliers to the original producer.
Do not duplicate the existing model/origin accepted-head and restart bridges.
Keep source/key ancestry and the original finite-depth measure as separate open
obligations until their actual compositions are proved.

No Haskell source changed. No Haskell check ran. No new Haskell defect or fix was
established. FINDINGS.md retains every earlier external repair record, including
the earlier integrated upstream fixes. The five-line ancestry repair concerns
Lean only. It requires no Haskell change.

Keep the full goal active. Continue without asking whether to continue. Normal
pushes to git@github.com:TharkunAB/cfta.git refs/heads/formalize remain explicitly
authorized. Keep all prior sources and evidence.
