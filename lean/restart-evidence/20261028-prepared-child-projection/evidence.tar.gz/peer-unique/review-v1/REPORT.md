[2026-10-28 20:23:38 CET] Source review PASS. No concern found.

I read the entire 53-line ChildDispatchUnique module and the entire 112-line ChildDispatchStability dependency. Their source hashes are c2c6df58cf63a3dc7aaafa676ce07a90b95f2a66cfb74666c9f3aabd228d69ae and 7af44220d3f72c2533e8667baa98758989bbe3af49740de2bff1f4812cbc6b99. The manifest preserves whole bytes, exact exported declarations and honest dependency read ranges.

run_some_unique compares two literal actual run observations. They share checkEmpty, width, suspended inputs, incoming value, initial Caller, initial Cached state and initial Queries. The five fuels may differ independently. The theorem does not assume an ordering between the two points. Each observation must return outer .ok, a present raw list, and a present cache. Each raw list must be empty or an exact singleton .ok containing a fragment and returned core.

The exact run_some_stable dependency has the same successful-row and some-cache requirements. Its only additional gates are the five Nat inequalities for larger representative, native, p, h and index fuels. It retains every literal output field at those larger bounds. There is no model, resource profile, Heap, future support, or completion-existence premise in either declaration.

The proof lifts the first observation to max r R, max n N, max p P, max h H and max k K with Nat.le_max_left. It lifts the second observation to those identical bounds with Nat.le_max_right. Both larger executions have literally identical inputs. Their equalities therefore imply equality of the two original result tuples.

The subsequent injectivity steps match the actual nested product layout. The outer product gives observation equality and some-cache equality. The observation product gives the outer Except equality and remaining Caller/Queries/Core/Waiting tuple. Further product injections recover full Caller, full Queries, outer Core and Waiting equality. Except.ok and Option.some injectivity recover the complete raw-list equality. The final Option.some injection recovers complete Cached equality. These are exact values, including physical and metadata fields; they are not only semantic equivalences.

The statement does not identify arbitrary external full Memos witnesses. Queries is the memo value returned by run. The entire returned Caller and Cached state agree because they occur in the actual result tuple.

I also checked the direct cached-terminal and cached-prepare stability declarations. Terminal requires the same supported raw rows and some-cache observation, plus the same five inequalities. Cached preparation requires its actual some rows observation and only the index-fuel inequality. The ChildDispatchStability proof follows the literal partition. Its empty branch is unchanged. Its terminal branch invokes the actual cached-terminal stability theorem. Its shallow branch keeps the raw observation through erasure and uses cached-prepare stability at the same physical heap. A missing cached preparation contradicts its supplied some-cache observation.

The supported-row requirement excludes representative-fuel error rows, every other raw error and multiple rows. Missing actions, absent raw results, absent caches and outer failures are outside this theorem. No claim is made about their fuel stability or agreement. The theorem does not prove that either successful observation exists, that all runs complete, or that outputs cover any model.

I wrote only this new review directory. I changed no repository or Haskell source and ran no compiler, proof evaluator, Git, network or board command. Root reported default and exact strict PASS on the first check. The review confirms source scope and composition; compiler evidence remains Root's responsibility.
