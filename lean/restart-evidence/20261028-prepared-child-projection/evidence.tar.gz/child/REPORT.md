# Actual child projection heap adapter

Date: 2026-10-28T20:03:14+01:00.

The candidate adds one local theorem for the actual `ChildDispatch.run` return. It derives the reached projection heap from the original local caller projection heap and the original observed-resource premises. No additional state interface is missing for this local lift. The child did not compile it. Root owns installation and checks.

## Exact public interface

Module: `SourcePruningEnumerationChildProjectionHeap`.

Theorem: `SourcePruningEnumerationChildDispatch.observed_resources_projection_heap`.

The theorem retains every argument of `ChildDispatch.observed_resources`, defined in `SourcePruningEnumerationChildObservedResources.lean`. It adds only `originalProjection` at the original `beforeCaller`, after `known`. Literal signature comparison passes after removing that one input and restoring the old theorem name.

The actual observer retains the supplied representative, native, Empty and cache bounds. Its tuple includes the raw Option result, returned native caller, saved query endpoint, outer enumeration core, waiting table, and arbitrary Option cache. No premise requires a present cache or a successful raw singleton.

The result is the exact old Fits/Known pair at `advance seed (bucket.length + 1)`, followed by `ProjectionHeap` at the same actual returned caller. The proof obtains the old pair once from `ChildDispatch.observed_resources`. It proves only the appended heap property.

## Actual branches

`ChildDispatch.erase` identifies the raw observation of this same call at the same supplied bounds. It preserves the native caller independently of the Option cache.

For Empty input, the observation returns the original native caller. For a partition with no terminal inputs, both missing and present shallow actions also return the original native caller. This holds regardless of the shallow action's raw rows and cache result.

For a nonempty terminal partition, `partition_subsets` derives the active variable bounds and pending-input facts from the original bucket. `terminal_length_le` derives the terminal reservation from the original mixed reservation. These helpers are declared in the `ChildCompletion` namespace in the actual file `SourcePruningEnumerationChildAdmission.lean`.

The actual erased child observation is then exactly `Terminal.run` on that partition. `Terminal.observed_resources_projection_heap` derives its returned heap. Its `.2.2` projection is the child theorem's remaining conclusion. This uses the actual query and fold effects; it does not transfer a heap invariant through arbitrary native growth.

## Premise and claim boundaries

Original incoming availability and closure remain unchanged resource premises. There is no new assumed projected child annotation, future heap, future model, preservation supplier, or termination certificate. The projection premise applies only to the original local caller. Bare Packet or alphabet membership is not asserted to derive it.

The theorem includes missing raw actions, empty rejection, inner errors retained under outer `.ok`, and absent cache candidates. Outer terminal/native errors remain outside the observer. It makes no claim that they preserve the heap, and it asserts no successful output existence.

The theorem does not establish complete enumeration coverage, finite recursive progress, rendering, whole-driver closure, or Haskell correspondence. It assumes no identity between stored source syntax and a prepared parent. It introduces no producer family and changes no original resource tuple. No Haskell code changed.

## Frozen evidence

Candidate: 6,862 bytes, 112 lines. SHA256: `9a7c5a4f4586073aa9cd61bdf54a0866bd9775bbfc117b3d5688b012fbcefc45`.

`manifest.json` records four complete source reads and the literal ChildDispatch cut at lines 1 through 114. That cut includes the complete actual observe, run and erase definitions. It does not claim a whole ChildDispatch file read. The exact copied bytes and hashes are retained.

Root reported exact strict PASS for the six earlier projection modules at 20:00 CET. That report covers the terminal dependency, not this untested child candidate. This candidate and all child evidence are frozen. No further proof work is included.
