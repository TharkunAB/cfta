# Actual next-entry bridge for child traversal

Date: 2026-10-28T20:26:56+01:00.

The bounded result is one actual next-entry adapter. Root accepted this scope at 20:22 CET. It connects an arbitrary successful singleton/cache call to the original child resource producer. It does not clone the full traversal producer. Root's one-line repaired version passes its default build.

## Public interface

Module: `SourcePruningEnumerationTraversalProjectionHeap`.

Theorem: `TraversalCompletion.observed_singleton_resources_projection_heap`.

The premises retain the original traversal admissions with `inputs = (incoming, bucket) :: rest`: native Context, Safe core, representative roots, waiting counts, native candidate flags, pending realization, every original input's availability/closure/variable bounds/pending references, Fits, complete original mixed reservation, and Known. The added projection premise is only at the original local caller.

The observer is the literal actual child `.ok (some [.ok (fragment, returned)])` plus `some after` cache at arbitrary supplied representative/native/Empty/index bounds. This is the branch where `ChildTraversal.run` executes the next child. The raw returned core is not assumed equal to the cache core in the input.

The conclusion derives an actual next Inventory, full endpoint Memos, and roots. It retains the original child Fits/Known at `advance seed (bucket.length + 1)`. It also derives actual Post, exact final query equality, Safe returned core, roots/counts/flags, pending realization, every suffix input's original admission at the reached state, the remaining original mixed reservation, and the reached whole projection heap.

## Receipt attachment

The old child `complete_with_fragments_resources` producer runs once under original input admissions. Its own original shape gives either rejection or a successful singleton. Root's checked `ChildDispatch.run_some_unique` compares this produced successful supported point with the arbitrary actual singleton point. It derives equal raw rows, native caller, query endpoint, outer core, waiting table, and complete cache at independently chosen bounds.

Those actual equalities attach the produced Post and complete Memos to the actual returned caller and cache. The actual nonempty singleton excludes produced rejection and supplies Safe for that cache. The actual Post retains suffix input availability. Counter growth retains suffix variable bounds. Original enumerated origins and protected roots retain suffix pending admissions. The original reservation splits at the consumed bucket's cost.

The checked `ChildDispatch.observed_resources_projection_heap` gives the actual returned Fits/Known and projection heap directly from the original caller projection. No heap property is inferred from arbitrary Post growth. No future child Context, heap, model, or projected support is supplied as a premise.

## Compiler repair and exact evidence

Candidate v1 is frozen at 8,614 bytes, 128 lines, SHA256 `cdd1d7acffa979c821d41ac5fea75ecf9b6d1add0d70f02534d04f7b29f2dcdd`.

Root's first default check found one bookkeeping error: `Unknown identifier querySame` at line 125. The tactic `subst producedQueries` can consume the final-query equality instead of the intended point equality. Root changed only this line to `cases queriesSame`. This preserves the intended full Memos/query endpoint equality. No theorem premise or conclusion changed.

The installed root v2 is 8,610 bytes, 128 lines, SHA256 `b26fab97b1f30583916125f7f2f12b790bf30c0ea099ecc93d1bb0a84f798867`. Exact byte comparison confirms that single replacement. Root's second default build passes. Both complete raw logs are copied under `evidence-v1/diagnostics`, including the failed 1,454-byte log. The passing log has 567 bytes. Both include an unrelated replayed warning from an old module; no linter suppression was added.

The child ran no compiler. Strict checks remain owned by Root. The root v2 whole source is copied separately; candidate v1 remains unchanged.

## Remaining scope

This theorem supplies the missing loop entry for actual completed-prefix induction. `ChildTraversal.complete_trace` and `stopped_trace` already extract actual ordered prefix traces. A separate trace induction can now propagate the derived current Context and full Memos, all original suffix admissions, resource bounds, and projection heap. That final traversal theorem is not part of this bounded result.

The observer requires an actual singleton and cache because the traversal continues only on that branch. Missing caches, missing actions, rejection, and outer errors do not assert another iteration. The broader child heap adapter remains available for supported stopped observations. No successful output existence, complete enumeration coverage, global depth, termination, rendering, Haskell correspondence, or whole-driver closure is claimed.

No Haskell code changed. No new producer family, source/prepared cast, future preservation supplier, resource limit, axiom, or linter setting was added.

## Read scope

Eight existing sources were read whole and copied with byte/hash identities. They include the literal ordered child traversal, both original traversal resource routes, the original child resource packet, the stability and uniqueness lemmas, and the checked child heap adapter. The first combined source output was truncated. The relevant files were reread completely before use. The report and manifest distinguish those reads from the failed batch. The installed root v2 and both compiler logs were also read whole.

This report, original candidate, repaired-source copy, diagnostics and read evidence are frozen.
