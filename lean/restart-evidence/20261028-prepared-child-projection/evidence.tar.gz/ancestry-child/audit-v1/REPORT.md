Bounded actual child allocation ancestry candidate

Created 2026-10-28 20:23:59 CET. No compiler, native execution, Git, network, board or repository write. Previous areas remain unchanged.

One immutable candidate

../candidate-v1/MicroCFTA/SourcePruningEnumerationCachedChildAncestry.lean

Public export: MicroCFTA.SourcePruningEnumerationCachedChild.allocate_ancestry.
Explicit argument order: aligned, observed. Every type, heap, optional node, input/output cache and actual fresh name index is implicit.

The original aligned premise is before.core.counter=before.core.values.length. The actual point observation is CachedChild.allocate heap node before=some(fresh,after). The exact six returned facts are:

1. fresh equals the original counter.
2. The returned counter is original counter+1.
3. Expansion ancestry is unchanged.
4. The returned raw fresh slot stores .unenumerated node [].
5. For each slot strictly below the original counter, every original recursion key remains in that same slot's returned ancestry.
6. Every original expansion key is in the actual fresh slot's returned ancestry.

The strict old-slot bound is explicit. The theorem makes no assertion about preservation at arbitrary unallocated indices. The original alignment is needed for the raw stored-slot result. The remaining ancestry facts follow from the actual allocation update. No Heap, native Context, model, desired final endpoint, future completion, finite key universe or termination supplier is added.

The optional node is retained literally. With node=some handle, the raw witness is an actual fresh native pending slot. With node=none, it is a fresh pure equality slot. Neither raw witness alone asserts a live representative or candidate. Existing original Safe/forest facts can establish those separate properties where applicable.

Proof route

CachedChild.allocate maps the actual NativeIndex.candidate result to the returned pair. The proof extracts that actual successful map observation. Pair projections identify fresh and after.core. The core is exactly EnumerationState.allocated node before.core. Existing allocated_slot supplies the raw storage fact under the original alignment. The ancestry update preserves the old slots by slot<counter and appends original expansion ancestry at the fresh index before eraseDups.

Connection to actual shallow children

CachedPrepare.prepareChild uses this allocation in both supported nonterminal branches. The ordinary branch calls CachedChild.prepareOrdinary, which allocates and then writes the inherited bucket. The Mu/Union branch allocates directly and leaves an empty bucket. The new theorem applies at that actual allocation point. It does NOT claim that the subsequent ordinary write, full shallow row or whole ChildDispatch has already been covered by this module.

Empty input returns some[] before allocation. A reference returns none. A terminal bucket prevents the shallow ordinary or boundary branch from allocating. Missing encodings or candidate classifications can also return none. No fresh slot is inferred for these failed or no-output cases. The point theorem requires the actual successful allocation pair.

ChildDispatch.observe/run routes a nonempty terminal partition into Terminal/CachedTerminalAdapter. It routes a nonterminal partition through the shallow/cached preparation described above. Raw rejection, missing raw results and singleton rows remain distinct. The candidate does not replace those observations with a generic success premise.

Terminal counter verification

Existing CachedTerminalAdapter.observed_cache_bounds in TerminalCacheBounds proves after.core.counter=before.core.counter for EVERY actual returned terminal cache (.2=some after), including a rejected fold's retained cache. It also retains the exact suspended-mass bound. Its proof follows actual prefix, fold and incoming-cache observations. PrefixBounds.observed_counter_mass and FoldCacheBounds.observed_counter_mass preserve the counter at their actual observations. The incoming operation changes values and ancestry but has no allocation operation.

Thus the terminal returned-cache path has an existing exact counter-preservation theorem. The shallow allocation path has counter+1. This report does not extrapolate the returned-cache theorem to observations with no cache or claim fresh-slot properties for terminal errors.

Status and scope

The 43-line candidate is source-only and uncompiled here. It has one theorem and no runtime definition, custom axiom, sorry/admit, native_decide, linter suppression or budget change. Root must compile and review it. No whole-head ancestry or global termination result is claimed.

source-manifest.json preserves whole source and exact cut identities. Earlier frozen evidence and installed sources were not edited.
