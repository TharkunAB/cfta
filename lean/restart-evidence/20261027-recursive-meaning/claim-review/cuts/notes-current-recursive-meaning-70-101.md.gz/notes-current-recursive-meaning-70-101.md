## Exact meaning of native narrowing and recursion checks

SourcePruningNativeMeaning reads the actual narrowing observation. Its
narrowAt_edges theorem retains the literal exposure and node-construction
equations. The result accepts exactly the filtered exposed edges with their
full symbols, guards and ordered child languages. narrowAt_sound combines
that result with the independent guarded reader soundness theorem. Arbitrary
filter decisions preserve this direction of language inclusion.

SourcePruningOuterNarrow.narrow_sound includes the actual Mu and typed skips.
It covers the actual filtering route at its own input heap. Independent
guarded probes are a genuine premise of native reader soundness. A current
Context supplies them through initial.ready.semantic.guarded. The raw Ready
comes from initial.ready.semantic.ready. Context.probes has a different probe
invariant and must not be substituted for the independent language premise.
This soundness result does not establish pruning coverage.

SourcePruningEnumerationParkedLanguage proves an exact assignment equivalence
for a real stored-bucket clear and for an ACTUAL repeated recursion check.
The native option/domain stays present. The original assignment is equivalent
to the reached assignment AND every removed Suspended.Holds constraint at the
same selected variable. A nonrepeated check preserves all assignments.

SourceFlatPruningRecursionMeaning proves the same law for an ACTUAL flat
successful check. The ordered result relation derives a sufficient earlier
check bound and supplies that success's related earlier endpoint. The theorem
requires the genuine earlier Ready and stored bucket. It assumes no future
successful execution. A repeated ancestry key is operational data. No current
theorem recovers the cleared constraints from that key alone.

## Traversal language from original finite resources

