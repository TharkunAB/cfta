from pathlib import Path
import ast
import hashlib
import json
import re
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
control = base / '20261117-third-query-six-seed-publication-control-draft'
work = base / '20261117-third-query-node-seed-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this controller.'
archive_control = base / '20261117-third-query-six-seed-checkpoint-control-draft'
assert Path(__file__).read_bytes() == (archive_control / 'prepare-checkpoint-controls.py').read_bytes()
runtime = base / '20261117-third-query-six-seed-publication'
assert runtime.is_dir(), 'The checked publication must exist.'
prior_run = base / '20261117-warm-full-admission-identity-publication'
prior_archive = base / '20261117-warm-full-admission-identity-checkpoint'
prior_commit = 'c894b4e3fda56e1f8c275f02653f0bba3be7167a'
prior_manifest = '3def8e9ca8cd34af38b886efdb00295ac5599c9a53f71b3854a43763990e7160'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
bound = set()


def verify(path, record):
    data = path.read_bytes()
    digest = record['sha256'] if isinstance(record, dict) else record
    assert sha(data) == digest, str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data


def items(value):
    return list(value.items()) if isinstance(value, dict) else [(item['path'], item) for item in value]


def manifest_records(manifest):
    return [(item['path'], item) for item in manifest['artifacts']] if 'artifacts' in manifest else items(manifest['files'])


for name, record in json.loads((control / 'MANIFEST.json').read_text())['files'].items():
    verify(control / name, record)
bound.add(control / 'MANIFEST.json')
staging_control = base / '20261117-third-query-six-seed-staging-control-draft'
verify(staging_control / 'MANIFEST.json', 'f471e45e788bd4be7d6e7208ac8ffd364a1504a35245b249498c942539056f15')
for name, record in json.loads((staging_control / 'MANIFEST.json').read_text())['files'].items():
    verify(staging_control / name, record)
for name, record in json.loads((staging_control / 'SOURCE-PINS.json').read_text()).items():
    verify(root / name, record)
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage = json.loads(stage_path.read_text())
assert stage == json.loads((control / 'EXPECTED-STAGE.json').read_text())
assert stage['prior_checkpoint'] == prior_commit
expected = stage['components']
overrides = {audit_name: str((work / 'Audit-BEFORE.lean.txt').relative_to(root))}
overrides.update({item['source_path']: item['old_snapshot'] for item in expected if item['kind'] == 'existing_owner_EOF'})
assert len(overrides) == 4 and stage['baseline_overrides'] == overrides
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6270, 5270, 709, 304)
assert (stage['new_modules'], stage['new_public_theorems'], stage['new_private_helpers'], stage['new_theorem_declarations'], stage['new_prop_definitions']) == (3, 7, 6, 13, 0)
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (7, 496, 503)
baseline_path = work / 'baseline-source-pins.json'
baseline = json.loads(baseline_path.read_text())
assert len(baseline) == 6267 and len(expected) == 6
new_names = {item['source_path'] for item in expected if item['kind'] == 'new_module'}
assert len(new_names) == 3 and not new_names.intersection(baseline)
current = sorted((root / 'lean/MicroCFTA').glob('*.lean'))
assert {str(path.relative_to(root)) for path in current} == set(baseline) | new_names


def prior_bytes(name):
    path = root / overrides.get(name, name)
    bound.add(path)
    return path.read_bytes()


def verify_prior_pins(path):
    bound.add(path)
    for name, record in items(json.loads(path.read_text())):
        data = prior_bytes(name)
        assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), name
        if isinstance(record, dict) and 'bytes' in record:
            assert len(data) == record['bytes'], name


for name, digest in baseline.items():
    assert sha(prior_bytes(name)) == digest, name
assert len(set(baseline) - set(overrides)) == 6263
old_audit = prior_bytes(audit_name)
assert len(old_audit) == stage['old_audit_bytes'] == 430643
assert sha(old_audit) == stage['old_audit_sha256'] == '760bbc31e363594987a026403384eeb0ee425456c091b6ed0a8e265cd270509b'
assert old_audit.count(b'#print axioms ') == 702
verify(root / owner_name, owner_sha)
prior = json.loads((prior_run / 'checked.json').read_text())
assert (prior['source_files'], prior['independent_reports'], prior['resource_and_component_probes']) == (6267, 297, 496)
assert len(prior['checks']) == 5 and all(item['exit'] == 0 and not item['diagnostics'] and not item['sorryAx'] and not item['nonstandard_axioms'] for item in prior['checks'])
verify(prior_archive / 'manifest.json', prior_manifest)
verify_prior_pins(prior_run / 'source-pins.json')
bound.add(prior_run / 'checked.json')
private_control = base / stage['private_control']
selected = json.loads((private_control / 'SELECTION.json').read_text())
private_run = base / stage['private_run']
assert selected['runtime'] == private_run.name
checked_path = private_run / 'checked.json'
checked = json.loads(checked_path.read_text())
receipt_path = work / stage['private_check_verified_receipt']
receipt = json.loads(receipt_path.read_text())
assert receipt['actual_session'] == stage['actual_private_session'] == 37551
assert receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
assert receipt['checks'] == checked['checks'] and checked['all_six_components_checked'] and checked['proof_credit']
assert len(checked['checks']) == 6 and all(checked['passed'])
assert [item['name'] for item in checked['checks']] == stage['compile_order']
assert [item['total_axiom_reports'] for item in checked['checks']] == [2, 1, 1, 1, 1, 1]
assert checked['actual_new_public_axiom_reports'] == 7 and checked['actual_definition_declaration_checks'] == 0
assert checked['new_private_helpers_compiled_transitively'] == 6 and checked['fresh_credit_for_old_owner_theorems'] == 0
assert checked['all_selected_first_headers_exact'] and checked['all_three_old_owner_prefixes_byte_exact']
assert checked['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
verify_prior_pins(private_run / 'source-pins.json')
bound.update([checked_path, private_run / 'results.json', receipt_path])
for item in checked['checks']:
    bound.add(private_run / (item['name'] + '.txt'))
# Preserve rejected reports without giving their partial outputs proof credit.
for receipt_name, session in [('FIRST-CHECK-REJECTED.json', 29139),
                              ('SIX-SEED-FIRST-CHECK-REJECTED.json', 54344)]:
    rejected_path = work / receipt_name
    rejected = json.loads(rejected_path.read_text())
    failed_run = base / rejected['runtime']
    failed = json.loads((failed_run / 'results.json').read_text())
    assert rejected['actual_session'] == session and rejected['actual_terminal_exit'] == 1
    assert rejected['checks'] == failed['checks'] and not rejected['proof_credit'] and not failed['proof_credit']
    assert not (failed_run / 'checked.json').exists()
    if session == 29139:
        assert rejected['generated_sorryAx_public_report_rejected'] and failed['checks'][1]['sorryAx']
    else:
        assert rejected['checker_transitive_import_order_failure'] and not rejected['candidate_proof_bytes_changed']
    verify_prior_pins(failed_run / 'source-pins.json')
    bound.update([rejected_path, failed_run / 'results.json'])
    bound.update(failed_run / (item['name'] + '.txt') for item in failed['checks'])

chosen = {item['module']: item for item in selected['components']}
assert len(chosen) == 6
normal_sources = []
probes = []
public_names = []
definition_names = []
for item in expected:
    for key, value in chosen[item['module']].items():
        assert item[key] == value, (item['module'], key)
    packet = base / item['packet']
    verify(packet / 'MANIFEST.json', item['manifest_sha256'])
    for name, record in manifest_records(json.loads((packet / 'MANIFEST.json').read_text())):
        verify(packet / name, record)
    # The actual passed check parsed each dependency schema. Bind its exact artifact
    # and preserve historical old Node records instead of equating different raws.
    for pin_file in ['SOURCE-PINS.json', 'ADDITIONAL-SOURCE-PINS.json']:
        if (packet / pin_file).exists():
            verify_prior_pins(packet / pin_file)
    raw = verify(packet / item['source'], {'sha256': item['raw_sha256'], 'bytes': item['raw_bytes']})
    assert raw == (root / item['source_path']).read_bytes()
    declarations = raw
    if item['kind'] == 'existing_owner_EOF':
        before = prior_bytes(item['source_path'])
        assert len(before) == item['old_bytes'] and sha(before) == item['old_sha256']
        appended = verify(packet / item['append'], item['append_sha256'])
        assert raw == before + appended and item['append_offset'] == len(before)
        declarations = appended
    for header in item['headers']:
        assert verify(packet / header['file'], header['sha256']).rstrip(b'\n') in declarations
    probe = verify(packet / item['probe'], item['probe_sha256'])
    assert (private_run / 'source/MicroCFTA' / (item['module'] + '.lean')).read_bytes() == raw + b'\n' + probe
    assert re.findall(r'^private theorem (\w+)', declarations.decode(), re.M) == item['new_private_helper_names']
    assert re.findall(r'^private def (\w+)', declarations.decode(), re.M) == item['new_private_prop_names'] == []
    assert re.findall(r'^#print axioms (\S+)', probe.decode(), re.M) == item['names']
    assert probe.count(b'#print axioms ') == item['expected_axiom_reports']
    assert probe.count(b'#check ') == item['expected_declaration_checks'] == 0
    normal_sources.append(raw)
    probes.append(probe)
    public_names.extend(item['names'])
assert len(public_names) == len(set(public_names)) == 7 and not definition_names
assert sum(len(item['new_private_helper_names']) for item in expected) == 6
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
imports = (work / 'IMPORTS.lean.txt').read_bytes()
assert public == b''.join(probes)
assert imports == (control / 'EXPECTED-IMPORTS.lean.txt').read_bytes()
assert len(imports) == stage['old_audit_exact_offset'] == 195 and imports.count(b'import ') == 3
assert (root / audit_name).read_bytes() == imports + old_audit + b'\n' + public
assert sum(line.startswith(b'import ') for line in (root / audit_name).read_bytes().splitlines()) == 5270
assert (root / audit_name).read_bytes().count(b'#print axioms ') == 709
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 297
for item in expected:
    imported = ('import MicroCFTA.' + item['module'] + '\n').encode()
    assert (imported in prior_independent) == (item['kind'] == 'existing_owner_EOF')
for name in ['strict-bind.py.txt', 'publication-driver.py.txt', 'shadow-compile.py.txt']:
    ast.parse((control / name).read_text())
normal_objects = root / 'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()

# Only Root executes these archive and Git controls after review.
import gzip
import subprocess

ROOT = root
BASE = base
WORK = work
PUBLIC = runtime
ARCHIVE = '20261117-third-query-six-seed-checkpoint'
BOARD_PREFIX = 'current-board-third-query-six-seed-'
read = lambda path: json.loads(path.read_text())
GIT = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
for name, record in read(archive_control / 'MANIFEST.json')['files'].items():
    verify(archive_control / name, record)
for name, record in read(archive_control / 'SOURCE-PINS.json').items():
    verify(ROOT / name, record)
bindings = read(WORK / 'prior-bindings.json')
assert bindings['prior_checkpoint'] == prior_commit
commit = read(WORK / 'SOURCE-COMMIT.json')
code = commit['source_commit']
assert re.fullmatch('[0-9a-f]{40}', code)
assert commit['parent'] == prior_commit and commit['actual_terminal'] and commit['actual_terminal_exit'] == 0
assert commit['private_actual_session'] == 37551 and commit['publication_actual_session'] == 60614
assert commit['all_seven_original_public_FIRST_headers_exact'] and commit['all_three_old_owner_prefixes_byte_exact']
assert not commit['joint_finite_completion_proved'] and not commit['haskell_changed']
assert GIT('rev-parse', 'HEAD').decode().strip() == code
assert GIT('rev-parse', code + '^').decode().strip() == prior_commit
assert GIT('branch', '--show-current').decode().strip() == 'formalize'
assert not GIT('status', '--porcelain', '--untracked-files=no')
changed = {item['source_path'] for item in expected} | {audit_name}
assert len(changed) == 7 and set(commit['files']) == changed
assert set(GIT('diff', '--name-only', prior_commit, code).decode().splitlines()) == changed
for name in changed:
    assert GIT('show', code + ':' + name) == (ROOT / name).read_bytes(), name
for name in changed - new_names:
    assert GIT('show', prior_commit + ':' + name) == prior_bytes(name), name
# Check all three documents before any archive output. Finalize repeats this check.
for name in ['NEXT-PROMPT.md', 'HANDOFF.md', 'FINDINGS.md']:
    assert (ROOT / name).read_bytes() == GIT('show', code + ':' + name), name
source_control = BASE / '20261117-third-query-six-seed-source-commit-control-draft'
verify(source_control / 'MANIFEST.json', '0b9bba12ed8b26a6656f18f525cd3a485d34e5f456a6332a21cb49f75025664a')
for name, record in read(source_control / 'MANIFEST.json')['files'].items():
    verify(source_control / name, record)
report = read(PUBLIC / 'checked.json')
verified = read(WORK / 'PUBLICATION-VERIFIED.json')
assert verified['actual_session'] == 60614 and verified['actual_terminal'] and verified['actual_terminal_exit'] == 0
assert verified['checks'] == report['checks']
assert [c['total_axiom_reports'] for c in report['checks']] == [709, 7, 304, 709, 709]
assert [(c['axiom_groups'], c['axiom_free_reports']) for c in report['checks']] == [
    (703, 6), (7, 0), (301, 3), (703, 6), (703, 6)]
assert all(c['declaration_checks'] == 0 for c in report['checks'])
assert all(c['exit'] == 0 and not c['diagnostics'] and not c['nonstandard_axioms'] and not c['sorryAx'] for c in report['checks'])
for name, value in {'source_files': 6270, 'direct_audit_imports': 5270,
        'individual_reports': 709, 'independent_reports': 304,
        'fresh_resource_component_reports': 7, 'inherited_resource_component_reports': 496,
        'resource_and_component_probes': 503, 'new_modules': 3, 'changed_existing_owners': 3,
        'new_public_theorems': 7, 'new_private_helpers': 6, 'new_private_theorems': 6,
        'new_private_predicates': 0, 'new_theorem_declarations': 13,
        'new_prop_definitions': 0, 'new_definition_declaration_checks': 0,
        'actual_publication_strict_reports': 7, 'new_private_component_reports': 0,
        'fresh_owner_preflight_reports': 0, 'replaced_old_reports': 0,
        'old_source_files_byte_exact': 6263, 'old_audit_exact_offset': 195,
        'audited_theorems': 100129, 'fresh_credit_for_old_owner_theorems': 0}.items():
    assert report[name] == value, name
for name in ['all_seven_original_public_FIRST_headers_exact', 'all_three_old_owner_prefixes_byte_exact',
        'all_six_third_query_cache_seeds_proved', 'exact_b4_joint_composition_checked',
        'joint_middle_source_inventory_and_all_six_third_history_cache_seeds_proved',
        'node_original_public_proof_byte_exact', 'node_repair_only_two_private_identifier_occurrences',
        'topological_checker_repair_changes_no_candidate_source',
        'original_parser29139_and_import_setup54344_failures_preserved',
        'current_public_pins_use_new_source_bytes',
        'prior_and_private_source_pins_use_three_owner_before_snapshots_and_Audit',
        'existing_next_warm_NoNewMu_scope_unchanged']:
    assert report[name], name
for name in ['all_new_formal_proof_checks_first_pass', 'first_check_passed_without_repair',
        'private_helpers_counted_as_explicit_fresh_reports', 'owner_recompiled_in_publication_strict_gate',
        'all_six_cache_meanings_proved', 'arbitrary_independent_warm_query_sequence_proved',
        'every_warm_worker_call_qualification_proved', 'native_inhabitance_proved',
        'joint_finite_completion_proved', 'compiled_haskell_correspondence_proved', 'haskell_changed']:
    assert not report[name], name
assert report['inherited_owner_preflight_evidence']['reports'] == 264
assert report['inherited_owner_preflight_evidence']['included_in_inherited_496']
assert report['baseline_overrides'] == overrides
assert report['owner_base_bytes'] == [12329, 19285, 16258]
assert report['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
pins = read(PUBLIC / 'source-pins.json')
for name, digest in pins.items():
    assert sha((ROOT / name).read_bytes()) == digest, name
assert verified['pins_independently_reverified'] == len(pins) == 7160
source_pins = {name: digest for name, digest in pins.items()
    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
assert len(source_pins) == 6270 and set(source_pins) == set(baseline) | new_names
prior_path = BASE / bindings['prior_archive']
for name, key in [('manifest.json', 'prior_manifest_sha256'), ('checkpoint.json', 'prior_checkpoint_json_sha256')]:
    data = (prior_path / name).read_bytes()
    assert sha(data) == bindings[key]
    assert GIT('show', prior_commit + ':' + str((prior_path / name).relative_to(ROOT))) == data
old_checkpoint = read(prior_path / 'checkpoint.json')
assert old_checkpoint['resource_and_component_probes'] == 496
assert old_checkpoint['checked_code'] == bindings['prior_source_commit']
assert old_checkpoint['checked_code'] == GIT('rev-parse', prior_commit + '^').decode().strip()
prior_files = {item['path']: item for item in read(prior_path / 'manifest.json')['files']}
for name in ['source-pins.json.gz', 'verification.json', 'archived-inputs.json']:
    data = (prior_path / name).read_bytes()
    assert len(data) == prior_files[name]['bytes'] and sha(data) == prior_files[name]['sha256']
    assert GIT('show', prior_commit + ':' + str((prior_path / name).relative_to(ROOT))) == data
old_pins = json.loads(gzip.decompress((prior_path / 'source-pins.json.gz').read_bytes()))
assert baseline == {name: digest for name, digest in old_pins.items()
    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
for name, digest in old_pins.items():
    assert sha(prior_bytes(name)) == digest, name
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    assert old_pins[name] == pins[name], name
request = read(WORK / (BOARD_PREFIX + 'request.json'))
canonical = read(WORK / (BOARD_PREFIX + 'canonical.json'))
assert canonical['verified']
post = canonical.get('post', canonical)
assert post['id'] == request['request_id'] == '281545fd-7568-4635-9e1d-a737f6b6eddd'
assert post['sequence'] == 1513
for key, value in [('author', request['username']), ('thread_id', request['thread_id']),
        ('post_type', request['post_type']), ('content', request['content']), ('metadata', request['metadata'])]:
    assert post[key] == value, key
assert post['metadata']['source'] == code
cleanup = read(WORK / 'combined-terminal-cleanup-result.json')
preview = read(WORK / 'TMP-CLEANUP-PREVIEW.json')
assert cleanup['all_owned_terminal_only'] and cleanup['all_five_current_batch_actual_runs_terminal']
assert cleanup['unknown_tmp_entries_preserved'] and cleanup['normal_lake_symlink_targets_preserved']
assert not cleanup['symlink_target_bytes_counted'] and not cleanup['live_process_references']
paths = [item['path'] for item in cleanup['removed_targets']]
assert len(paths) == len(set(paths)) == 5
assert all(not Path(path).exists() and not Path(path).is_symlink() for path in paths)
actual_runs = [(29139, '20261117-third-query-node-seed-check'),
    (32348, '20261117-third-query-node-seed-prefix-identifier-repair-check'),
    (54344, '20261117-third-query-six-seed-check'),
    (37551, '20261117-third-query-six-seed-topological-order-repair-check'),
    (60614, '20261117-third-query-six-seed-publication')]
for item, (session, run) in zip(cleanup['removed_targets'], actual_runs):
    assert item['actual_session'] == session and item['run'] == run
    assert item['path'] == read(BASE / run / 'objects.json')['path']
    assert not item['symlink_target_bytes_counted']
assert cleanup['removed_targets'] == preview['owned_terminal_targets']
assert preview['all_five_actual_runs_terminal'] and preview['terminal_sessions'] == [29139, 32348, 54344, 37551, 60614]
assert cleanup['removed_bytes'] == sum(item['bytes'] for item in cleanup['removed_targets']) == 15873248
assert cleanup['removed_symlinks'] == sum(item['symlinks'] for item in cleanup['removed_targets']) == 31494
assert cleanup['prior_cumulative_removed_bytes'] == 6477338797
assert cleanup['prior_cumulative_removed_bytes'] + cleanup['removed_bytes'] == cleanup['cumulative_removed_bytes'] == 6493212045
assert cleanup['normal_cache_target_count'] == preview['normal_cache_target_count'] == 6304
assert cleanup['tmp_readable_regular_file_bytes_after'] == 5826234367
assert len(cleanup['tmp_census_errors']) == 7
assert sum('Permission denied' in item['error'] for item in cleanup['tmp_census_errors']) == 6
assert sum('No such file' in item['error'] for item in cleanup['tmp_census_errors']) == 1
start = read(WORK / 'START.json')
batch = read(WORK / 'BATCH-SCOPE-UPDATE.json')
resume = read(WORK / 'RESUME-AUTHORIZATION.json')
assert start['manual_work_explicitly_authorized'] and start['usage_pause_lifted']
assert start['persistent_goal_control_status'] == 'paused'
assert start['expected_commands'] == 2 and start['expected_public_reports'] == 3
assert not start['joint_finite_completion_proved']
assert batch['original_key_node_private_check_retained']
assert (batch['expected_full_chain_commands'], batch['expected_full_chain_public_reports']) == (6, 7)
assert batch['expected_combined_reports'] == 503 and batch['expected_source_files_after_staging'] == 6270
assert batch['normal_Source_changed'] is False and batch['all_six_fields_proved'] is False
# START and BATCH record their original times; final checked receipts establish success.
assert resume['user_instruction'] == "Keep going. We'll use a reset if needed."
assert resume['user_explicitly_resumed'] and resume['earlier_usage_pause_lifted'] and resume['work_authorized']
assert resume['persistent_goal_control_at_resume'] == 'paused' and resume['no_goal_resume_operation_available']
usage = read(WORK / 'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int, float] and 0 <= percent <= 100
assert usage['earlier_usage_pause_lifted_by_user_resume']
assert usage['current_usage_not_measured'] and usage['historical_snapshot_copied_at'] > usage['checked_at']
assert usage['snapshot_source'] == 'lean/restart-evidence/20261117-warm-full-admission-identity-work/USAGE.json'
assert '17:53:' in usage['checked_at'] and percent == 81
roots = read(WORK / 'selection-roots.json')
assert len(roots) == len(set(roots)) == 22
assert source_control.name in roots
additional = read(WORK / 'archive-additional-roots.json')
assert len(additional) == 4
for item in additional:
    assert re.fullmatch(r'20261117-[a-z0-9-]+', item['root'])
    assert item['manifest'] == 'MANIFEST.json' and item['current_batch_theorem_credit'] == 0
    packet = BASE / item['root']
    manifest = read(packet / 'MANIFEST.json')
    verify(packet / 'MANIFEST.json', item['sha256'])
    for name, record in manifest_records(manifest):
        verify(packet / name, record)
    assert not item['private_runtime_selected'] and 'FROZEN' in manifest['status'].upper()
    roots.append(item['root'])
assert len(roots) == len(set(roots)) == 26
assert all((BASE / name).is_dir() and not (BASE / name).is_symlink() for name in roots)
# Future numerical Work, checker controls and runtimes are outside this exact allowlist.
assert not any('numerical' in name and name not in {
    '20261117-numerical-body-first-source-callbacks-draft',
    '20261117-numerical-coherent-source-callbacks-draft'} for name in roots)
for name in roots:
    run = BASE / name
    if (run / 'check.py').exists():
        result = read(run / ('checked.json' if (run / 'checked.json').exists() else 'results.json'))
        assert result['checks'] and all(type(item['exit']) is int for item in result['checks']), name
for item in read(WORK / 'original-header-files.json'):
    assert sha((ROOT / item['path']).read_bytes()) == item['sha256']
    assert sha((ROOT / item['original']).read_bytes()) == item['sha256']
selected_roots = sorted(str((BASE / name).relative_to(ROOT)) for name in roots)
assert not (BASE / ARCHIVE).exists()
tree = hashlib.sha256()
for name, digest in sorted(source_pins.items()):
    tree.update(name.encode() + b'\0' + digest.encode() + b'\n')
config = dict(report)
config.update(checked_code=code, prior_checkpoint=prior_commit, public_run=str(PUBLIC), public_gates=5,
    explicit_reports=report['individual_reports'], board_prefix=BOARD_PREFIX,
    board_post_id=post['id'], board_sequence=post['sequence'], source_tree_sha256=tree.hexdigest(),
    old_non_audit_source_files_byte_exact=6263,
    old_audit_contiguous_bytes_preserved=430643, old_audit_exact_offset=195,
    ordinary_audit_import_bytes=195, new_audit_imports=3, old_audit_is_prefix=False,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],
    cleanup_receipt='combined-terminal-cleanup-result.json', removed_symlinks=cleanup['removed_symlinks'],
    symlink_target_bytes_counted=False, normal_lake_symlink_targets_preserved=True,
    tmp_readable_regular_file_bytes_after=cleanup['tmp_readable_regular_file_bytes_after'],
    tmp_census_errors=cleanup['tmp_census_errors'], unknown_tmp_entries_preserved=True,
    historical_primary_usage_percent=percent, historical_primary_usage_checked_at=usage['checked_at'],
    historical_usage_snapshot=True, current_usage_not_measured=True,
    prior_immutable_archive=bindings['prior_archive'], prior_manifest_sha256=bindings['prior_manifest_sha256'],
    fresh_strict_reports=7, inherited_component_reports=496,
    all_new_formal_proof_checks_first_pass=False, first_check_passed_without_repair=False,
    all_seven_original_public_FIRST_headers_exact=True, all_three_old_owner_prefixes_byte_exact=True,
    historical_failed_proofs_preserved_in_prior_immutable_chain=True,
    additional_frozen_roots=additional, additional_frozen_roots_theorem_credit=0,
    future_numerical_Work_checkers_and_runtimes_excluded=True,
    third_history_scope=verified['scope'], inventory_snapshot='middleSnapshot before third history',
    third_execute_outcome_inventory_proved=False, third_all_prefix_inventory_proved=False,
    third_all_prefix_returned_laws_proved=False, arbitrary_independent_warm_query_sequence_proved=False,
    every_warm_worker_call_qualification_proved=False,
    user_explicitly_resumed=True, earlier_usage_pause_lifted=True,
    work_authorized_by_explicit_user_resume=True, persistent_goal_control_status='paused',
    goal_resume_operation_performed=False, goal_completion_claimed=False, goal_active=False,
    joint_finite_completion_proved=False, compiled_haskell_correspondence_proved=False, haskell_changed=False)
skipped = sorted(str(path.relative_to(ROOT)) for path in BASE.iterdir()
    if path.is_dir() and path.name.startswith('20261117-') and str(path.relative_to(ROOT)) not in selected_roots)
review = {'prior_checkpoint': prior_commit, 'selected_roots': len(selected_roots), 'base_roots': 22,
    'additional_frozen_roots': additional, 'additional_frozen_roots_theorem_credit': 0,
    'fresh_reports_this_batch': 7, 'inherited_reports': 496, 'combined_reports': 503,
    'new_public_theorems': 7, 'new_private_helpers': 6, 'new_theorem_declarations': 13,
    'new_prop_definitions': 0, 'definition_checks': 0, 'definition_axiom_reports': 0,
    'new_private_explicit_reports': 0, 'private_helpers_counted_as_explicit_reports': False,
    'all_current_component_first_checks_passed': False, 'inherited_owner_reports': 264,
    'all_seven_original_public_FIRST_headers_byte_exact': True, 'all_three_old_owner_prefixes_byte_exact': True,
    'parser29139_and_setup54344_failures_preserved': True, 'node_retry32348_and_full_retry37551_preserved': True,
    'future_numerical_Work_checkers_and_runtimes_excluded': True,
    'inventory_snapshot': 'middleSnapshot before third history',
    'six_fields_scope': 'initial cache laws qualified by ONE fixed full third history',
    'third_execute_outcome_inventory_proved': False, 'third_all_prefix_inventory_proved': False,
    'all_six_cache_meanings_proved': False, 'every_warm_worker_call_qualification_proved': False,
    'arbitrary_independent_warm_query_sequence_proved': False,
    'joint_finite_completion_proved': False, 'haskell_changed': False, 'goal_completion_claimed': False}
note = (WORK / 'checkpoint-note.md').read_text()
for key, value in {'THEOREMS': report['audited_theorems'], 'REMOVED': cleanup['removed_bytes'],
                   'SYMLINKS': cleanup['removed_symlinks'],
                   'CLEANUP': cleanup['cumulative_removed_bytes'], 'USAGE': percent}.items():
    note = note.replace('{{' + key + '}}', str(value))
assert set(re.findall(r'\{\{(.*?)\}\}', note)) == {'TIME', 'TREE', 'CODE'}
assert 'historical' in note.lower() and 'current usage was not measured' in note.lower()
outputs = {'checkpoint-config.json': config, 'archive-roots.json': selected_roots,
           'skipped-published-roots.json': skipped, 'selection-review.json': review}
assert all(not (WORK / name).exists() for name in outputs)
# No mutation occurs before every proof, source, document, board and cleanup guard above passes.
for name, value in outputs.items():
    (WORK / name).write_text(json.dumps(value, indent=2) + '\n')
(WORK / 'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code': code, 'packet': ARCHIVE, 'roots': len(selected_roots),
    'board_sequence': post['sequence'], 'fresh_reports': 7, 'inherited_reports': 496,
    'combined_reports': 503, 'future_root_credit': 0, 'current_usage_not_measured': True}))
