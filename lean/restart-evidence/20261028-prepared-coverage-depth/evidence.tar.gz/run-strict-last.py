import os, subprocess, sys
from pathlib import Path
area=Path('/tmp/mcfta-prepared-coverage-20261028')
for label,module in [('strict-depth-final','SourcePruningEnumerationPreparedRecursiveDepth'),('strict-parked-final','SourcePruningEnumerationParkedProgress'),('strict-audit-final','Audit')]:
 command=['/home/tritlo/Code/heavy-management/bin/capped','--mem','4G','--time','5m',sys.executable,str(area/'check-installed.py'),'strict',label,module]
 result=subprocess.run(command,env=os.environ.copy())
 if result.returncode: raise SystemExit(result.returncode)
