from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/tritlo/Code/mcfta');area=Path('/tmp/mcfta-prepared-coverage-20261028')
head=(area/'source-head.txt').read_text().strip()
old=json.loads(Path('/tmp/mcfta-prepared-producer-arity-20261028/final-documents.json').read_text())
paths=[record['path'] for record in old]
prior=[]
for relative in paths:
 data=(root/relative).read_bytes();target=area/'prior-documents'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);prior.append(dict(path=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(area/'prior-documents.json').write_text(json.dumps(prior,indent=2)+'\n')
header=f'''# Current checkpoint: prepared projection, parking and completed depth

Source: `{head}` on `formalize`.
Read [lean/notes-current-prepared-coverage-depth.md](lean/notes-current-prepared-coverage-depth.md)
from the repository root. The full formalization goal remains open and active.
Normal pushes to `origin/formalize` remain authorized.

The earlier conditional rendering soundness and finite resource/history results
remain unchanged. A fully discharged output with successful checked rendering
satisfies its original formalized native language and suspended constraints.
The original Packet, resources, genuine arity and observer gates remain explicit.

New proofs derive guard projection support at the actual prepared node from
original physical projectability. An actual pending task gives some ready
selection under the original proper model and no stop rule. Actual invoked
hook outputs remain in the sibling scan. A completed actual prepared run now
retains its exact outputs, final caller and queries at every greater recursive
depth, with work fuel and all inputs fixed. This assumes the original run is
complete. It does not derive a sufficient depth.

A selected successful repeated-key park keeps the allocation counter fixed,
disables only the selected candidate flag and strictly reduces the full
candidate count. This bounds consecutive such parks. Later allocations can
add work. Global accepted-output coverage still needs a model-preserving
emitted output and one finite bound for earlier ordered callbacks and the
chosen continuation. Selection membership and length alone do not give row
coverage. DONE does not imply Discharged. Partial outputs remain in scope.

All eight new modules and Audit pass nine exact strict checks. The combined
Audit passes 4,509 jobs and 81,597 theorem dependency checks. Public readback
has 687 theorems and 60 definitions. The prior 3,016,159-byte readback and the
intermediate 3,034,447-byte readback remain exact prefixes of 3,052,362 bytes.
All thirteen new public theorem blocks have complete source/signature review.
All 4,500 prior non-Audit Lean files, 349 stronger proof sources and 817
Haskell/Cabal files retain their hashes.

No new Haskell defect or fix was established. No Haskell file changed or check
ran. The candidate import, name, pattern and simplifier repairs are Lean proof
repairs. Earlier Haskell findings remain below for external implementation work.
Durable evidence: `lean/restart-evidence/20261028-prepared-coverage-depth`.
Use a new writable area after this checkpoint. Keep sealed evidence immutable.
Run compiler jobs serially under measured 4 GiB limits. No old build handle is
live. Keep the optimized interned core and older secondary proof targets.

The earlier document body follows unchanged.

'''
for relative in paths:
 target=root/relative;target.write_bytes(header.encode()+(area/'prior-documents'/relative).read_bytes())
note=f'''# Prepared coverage prerequisites and completed depth: 2026-10-28

Source checkpoint: `{head}` on `formalize`.
The full formalization goal remains open and active.
Normal pushes to `origin/formalize` remain authorized.

## Full target

For supported public inputs and the stated solver and resource conditions,
prove that each accepted rendered term belongs to its requested constrained
language. Prove operation preservation and accepted-output coverage. Connect
counting, ranking, unranking and sampling to that language. Compare the Lean
source model with optimized interned Haskell. Retain the older constructor and
equality targets as secondary targets.

## Strongest semantic statement

The prepared finite worker has an actual outcome that is stable at every
larger work bound, at each reserved finite recursive depth. Original Packet,
Fits, known guard Heap, selection membership/length and suspended-mass gates
remain explicit. Genuine original arity gives arity at all exposed aggregate
endpoints and every output, including callbacks with empty output lists.
Canonical initial equality storage gives canonical output storage. The same
original histories, work bound and outcome remain available.

For every fully discharged output, a satisfying output assignment restores
the whole original model. Actual rendering and checked residual guards derive
that output assignment. For an original pending root with its exact stored
handle and native lookup, the rendered term has the original native meaning
and satisfies every suspended restriction in the original root bucket.
The fixed guard and residual interpretation is SourceEqualityPCSGuard.holds.
The full initial Packet, resources, selection, canonical storage and genuine
arity remain producer gates. Whole-cache Discharged, actual rendering Success
and checked PCS residuals remain observer gates. Rendering alone does not give
Discharged. Free equality variables with no handle and an empty bucket remain
permitted by Discharged.

This statement concerns the formalized native language. Public input and
acceptance adapters, the remaining PCS/public language connection and physical
optimized Haskell correspondence remain separate targets.

## New checked results

1. SourcePruningEnumerationRestart.expand_of_pending uses original CacheValid,
   Safe, ProperState, a whole model and one live pending native slot. With no
   stop rule, the actual order selects some ready root with IncomingAvoid.
   The selected root need not be the supplied slot. The result gives neither
   fairness nor termination. ProperState is separate from Packet.
2. SourcePruningEnumerationSelectedValue.run_projectable_heap preserves the
   full physical edge projection invariant through the actual normalization.
   It covers every actual endpoint, including pending or exhausted results.
   It assumes original Ready, Available, closure and the original heap
   invariant. It does not claim stability of failed observations.
3. SelectedPreparation.run_projectable_heap attaches that fact to the literal
   actual entry/preparation row. complete_projectable_heap identifies a stable
   completed endpoint. complete_rows_projectable derives projection support
   for every row of that actual prepared node. The original decoded source
   and prepared parent remain distinct. No final projectability or model is
   an input. Existing checked-source construction supplies initial physical
   projectability. This does not yet carry it through the entire recursive
   worker at every newly selected input.
4. HookInvocation.Invocation.output_mem retains the same literal output in
   the full actual sibling scan. It handles stopped hooks and later stopped
   suffixes. It assumes the hook emitted that output. It does not construct
   the output or remove an earlier stopped hook.
5. NativeContinuations.run_complete_congr, ReceiptContinuation.run_complete_congr,
   SelectedContinuations.run_complete_congr and PreparedRecursive.continueWith_complete_congr
   retain exact completed results under directional agreement on completed
   hooks or recursive calls. Agreement is global over those inputs. No
   agreement on stopped calls is required. The helpers supply no existence
   result. Output and reason universes remain independent where applicable.
6. PreparedRecursive.resume_complete_moreDepth and run_complete_moreDepth
   preserve a complete actual result at any greater recursive depth. They
   keep work fuel and all other inputs fixed. Outputs, final Caller and
   final query state are exactly equal. They require no Packet, resources,
   model or language premise. They do require an ACTUAL complete result at
   the original depth. They do not establish a first sufficient depth or
   upgrade a stopped result.
7. ParkedRestart.selected_complete_with_parking_progress constructs the
   actual stable read and recursion-check observations from original Safe,
   CacheValid and a literal expansion decision. It retains CacheValid and
   Safe at that exact endpoint. If the check returns true, the counter stays
   fixed, only the selected candidate flag is disabled and the candidate
   list length strictly decreases. The list includes blocked candidates.
   Clearing references can unblock another candidate while the full list
   still gets shorter. Only consecutive successful repeated-key parking
   transitions are bounded. Later allocations remain outside this measure.

All names above have the MicroCFTA prefix.

## Largest remaining gap

Global accepted-output coverage must derive an actual emitted output and an
assignment that satisfies that output at its own caller and cache. The new
assignment must agree below the original allocation counter. The proof must
start from the original accepted assignment, actual resource admission and
source-grounded complete selection and pruning policies. It must permit
intended opaque and partial outputs. Discharged is not a general coverage
premise.

Existing prepared prefix/head/parent/sibling and origin-policy theorems already
construct accepting captured models. The chosen callback can reach an exact
model-preserving restart under its original Refutes, Avoids and ProgramEncoding
conditions. OriginPolicies covers the structural original subtrees. A root
ProgramAt condition alone does not inspect annotation children. Do not add a
new wrapper that assumes the desired future output or model.

The ordered scan needs a finite depth for earlier callbacks as well as the
chosen continuation. An earlier complete callback can emit no output and still
allow the suffix. An exhausted earlier callback stops the suffix. The existing
sibling theorem retains the exact chosen-event OR earlier-stopped-hook
alternative. A chosen finite term's height does not bound those earlier
executions. Completed-depth stability and candidate decrease for consecutive
parking do not supply the missing bound for allocating continuations.
No admitted all-depth divergence example was established.

Projection support for all current prepared rows now follows from the original
physical heap. It can be reused across callbacks because the literal selected
row guards do not change. Newly selected recursive inputs still need checked
projectability preservation. Generic Post growth is insufficient. The forecast
NativeGuardAlphabet.step includes unchecked conjunction combinations. Known
membership alone does not show that the whole forecast alphabet projects.

The selector must also include the accepted row. Existing permutation and
canonical-row correspondence routes remain available. selectionMembers and
selectionLength permit the constant-empty selector, so they do not give coverage.

## Next bounded proof sequence

1. Consider output retention at greater recursive depth for stopped results.
   Reuse exact completed-branch stability to preserve subsequent sibling
   endpoints. Prove literal membership for old outputs. Do not infer output
   existence. Combine with existing work-bound stability at a common bound.
2. Carry projectability through the actual recursive producer, including
   aggregate endpoints from empty-output callbacks. Use actual checked native
   query and parent receipts. Avoid a second copy of the entire arity family
   when a shared local preservation argument suffices.
3. Establish a genuine original progress or finite-search condition that
   bounds every earlier allocating callback and the chosen continuation.
   Prove the model-preserving emitted output by induction on that condition.
   Keep opaque output semantics and origin/policy propagation explicit.
4. Attach complete selector and public input/acceptance adapters. Connect the
   fixed PCS interpretation to the remaining public language interface.
5. Complete counting/ranking/unranking/sampling integration and physical
   optimized interned Haskell correspondence.

## Approaches and boundaries retained

The existing checked-source construction already proved initial projectability.
The existing prepared model/origin bridges already proved accepted callback
entry models. Neither needed a duplicate wrapper. Arity alone does not imply
successful projection. The existing raw Ready/cached-equality counterexample
is not a checked public construction and is not a Haskell defect.

The existing empty-bucket recursive-boundary example proves DONE without
Discharged and permits marker rendering. Preserve it. The sketch A=f(A)|a is
not an admitted all-depth obstruction without accounting for actual boundary
classification and repeated-key parking. Recursive depth zero gives an actual
exhausted result at an expansion. This only refutes unconditional fixed-depth
output existence.

## Verification and evidence

All eight new modules and Audit pass nine exact strict Lean 4.34.1 checks with
warningAsError and linter.all. The final matrix binds every current source hash.
The combined Audit passes 4,509 jobs and 81,597 theorem dependency checks.
No placeholder, custom axiom, native evaluation axiom, proof-budget increase
or linter suppression was added. An old unused-variable warning remains only
in its unchanged old source and default Lake replay.

Public readback has 687 theorem signatures/axiom checks and 60 definitions.
All thirteen new theorem blocks have whole source and emitted-block review.
The prior 3,016,159-byte and intermediate 3,034,447-byte readbacks remain exact
prefixes of 3,052,362 bytes. Final SHA-256:
`89539665e3e9d5bcf45b85e902481ef2f3f39f5b7e5557deb2a1d6b9e6a9d832`.
Only propext, Classical.choice and Quot.sound occur in the new axiom lists.

All 4,500 prior non-Audit Lean sources, 349 stronger sources and 817 Haskell/Cabal
files keep their recorded identities. All twelve prior document bodies remain
exact suffixes. The archive preserves every current regular evidence file.
It includes all candidates, source scopes, reviews, exact command inputs, raw
outputs, public readbacks, peak measurements, Git receipts and board readback.
All 26 compiler/build/readback commands used measured memory.max and memory.high
of 4,294,967,296 bytes, with swap.max=0. Twenty-one pass and five failed attempts
remain preserved. All final checks pass.

The failed diagnostics retain 4,745 bytes for import/qualification fixes,
376 bytes for a remaining unused simp argument, and 13,185, 11,434 and 40,816
bytes for depth-proof elaboration. Repairs expose callback pattern cases,
reduce depth-zero nonexpansion, avoid a reserved identifier, identify caller
width and expose local hook definitions to rewriting. The final depth proof
shares duplicated dispatch cases and has 214 lines. No theorem premise was
weakened to obtain a result. The long diagnostic's truncated display was
replaced with an overlapping byte-range read. Full raw files remain intact.

No Haskell source changed. No Haskell check ran. No new Haskell defect or fix
was established. Keep all earlier Haskell repair entries in FINDINGS.md for
external implementation work. Current fixes concern Lean proof sources only.

Durable archive: `restart-evidence/20261028-prepared-coverage-depth`.
Use its verifier with a fresh extraction directory. Keep this sealed area and
all earlier archives and reconstructed areas immutable. Continue in a new
writable area. The full goal remains active. No compiler or Git handle stays
live after publication. Publication receipts are stored outside the sealed area.
'''
new='lean/notes-current-prepared-coverage-depth.md';(root/new).write_text(note);paths.append(new)
final=[]
for relative in paths:
 data=(root/relative).read_bytes();target=area/'final-documents'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);final.append(dict(path=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
for record in prior:
 assert (root/record['path']).read_bytes().endswith((area/'prior-documents'/record['path']).read_bytes())
(area/'final-documents.json').write_text(json.dumps(final,indent=2)+'\n')
print(json.dumps(dict(updated_prior_documents=len(prior),final_documents=len(final),prior_bytes=sum(r['bytes'] for r in prior))))
