# Installed coverage additions: bounded source review

[2026-10-28 18:41 CET]

PASS for the stated local contracts. No source correction is requested. This is a source review. Root owns compiler, strict linter, signature and axiom validation.

The review covers all four assigned sources in full: 18,478 bytes. It also covers three directly used dependencies in full: 22,357 bytes. `inputs.json` preserves every SHA256 identity and six exact exported source-declaration signatures. The complete module context is copied beside each signature. These are source signatures, not compiler-generated public readback.

## Strongest honest statements

1. `SelectedValue.run_projectable_heap` preserves the original full physical projectability invariant at the actual native operation endpoint. Ready, availability, closure and the original invariant remain explicit. Native pending and exhausted endpoints are included. It makes no exhausted-result stability claim.
2. `SelectedPreparation.run_projectable_heap` attaches that fact to the literal actual preparation row. Its entry must be the stated successful singleton, and its native result must be `some outcome`. It obtains availability and closure from the original Packet's realization of the exact stored source handle. It extracts the actual native run from the observed pair. No final Heap or model is an input.
3. `SelectedPreparation.complete_projectable_heap` gives the invariant at a stated stable actual completed preparation. Its `running` premise is a literal operational observation for all `bound+extra`, not a desired language law. The existing producer supplies such observations. `identify_complete` aligns the exact observed fields with that producer.
4. `SelectedPreparation.complete_rows_projectable` gives projection success for every row of the actual prepared node. It first derives the full returned heap invariant. It derives result availability and linked facts through the actual completion identification. It then obtains the annotation facts from those actual resident records. The original decoded source and returned prepared parent remain distinct. Arity, accepted models and desired output facts are not added as premises.
5. `Restart.expand_of_pending` gives some actual ready selection when a graph-bearing original slot has nonboundary native work or a nonempty suspended bucket. It requires the original CacheValid, Safe, ProperState and whole satisfying assignment. It disables the stop rule. It does not select the supplied slot specifically, prove fairness, or cover an empty-bucket recursive boundary. `ProperState` is a separate original gate; the proof does not infer it from Packet.
6. `HookInvocation.Invocation.output_mem` preserves every output emitted by an actual invoked hook in the full same-fuel sibling scan. Both complete and stopped results retain their output lists. The induction follows exact captured-head observations and actual earlier callback endpoints. A later stop preserves an earlier output. The theorem does not assert that any callback emits an output.

## Gate and proof checks

- Projectability is supplied only at the original heap. The wrappers derive it at the actual output. They do not use a forward Post rule for new records.
- The universal row claim can be empty when the actual returned row list is empty. This is the correct local invariant. The theorem does not use it to infer an accepted row. Acceptance and selector inclusion remain separate coverage obligations.
- Selection progress uses an original satisfying assignment to exclude a blocked dependency cycle. It also excludes done through the supplied live-work slot. It preserves the exact no-stop scope. It does not change the known empty-boundary done behavior.
- Hook retention has an explicit output-membership antecedent. Its useful conclusion is conditional retention. It does not remove the earlier stopped-hook alternative in recursive coverage.
- The hook invocation type records actual earlier completed callbacks or actual handled noncomplete receipt endpoints. It does not assume a future recursive model. The output theorem uses exactly the same five fuels and captured cache as that certificate.
- None of the assigned modules claims whole-driver completeness, unconditional Discharged, a model after arbitrary callback completion, or source/prepared equality.

## Input identities and small source differences

`SelectedValueProjectionHeap`: 2,923 B, SHA256 `69d0a0b054baf37b720e7b48486c70a95c52143e84854c47e1c00f84d0187090`.

`SelectedPreparationProjectionHeap`: 6,882 B, SHA256 `e1f2c674b35a927b69c5d2a665d8af76cf44b926845d5fea427db5a40be9b1b2`.

`NativeSelectionProgress`: 3,761 B, SHA256 `f02438919eca8506257cf1600b2962f36988acfe1f74a2e9084790ec2cbda0a2`.

`HookInvocationCoverage`: 4,912 B, SHA256 `90e0971e1e1ce67060ed050ba4cc9e2398459f65473d87421d9960adf24d1019`.

The installed selected-value module differs from the frozen 2,871-byte candidate by one explicit Constraint import. Its entire namespace, theorem and proof are byte-identical. The exact difference is preserved in `candidate-to-installed.diff`.

The reviewed hook source includes root's unused-simp repair: the completed constructor's first `simp only` uses `[foldOutputs, List.mem_append]`. The later explicit use of `following` remains. The complete repaired file was reread. The pre-repair 4,923-byte file is not the final review input.

## Limits and status

No compiler, native evaluation, Git, network, board or repository mutation was used. Root reported default-build success; this review does not independently verify build or strict logs. It does not audit the full imported proof closure or extract kernel axiom sets. All seven inspected source hashes are rechecked against the final copied bytes before freeze. Old candidate and audit areas remain unchanged.

No Haskell code changed. No Haskell defect or fix is claimed.
