# Final prepared recursive-depth source review

PASS for the exact completed-result preservation contract. No correction is requested.

Reviewed source: `SourcePruningEnumerationPreparedRecursiveDepth.lean`, 214 lines, SHA256 `7a6edb1a238ab4e5efd679bfebb5fa5e565bf409696fdaff1a20b9f7b08731df`. The whole final source and actual `PreparedRecursive` worker were read. Their exact bytes are copied. The earlier two congruence modules and their three operational dependencies retain the exact frozen first-review identities. `inputs.json` records all identities and three complete exported source signatures with their full module context.

## Strongest statement

If the actual prepared worker returns `.complete` at recursive depth d, then every depth D >= d returns exactly the same complete result when the work fuel and every other input stay fixed.

The result includes the full output list and its order, all fields of every output, the final native caller and the final query state. A `.complete` result can contain no outputs. It can also contain an intended partial output from a stop or native done boundary. This statement does not imply whole Discharged or an accepted rendered output.

## Public contracts

`continueWith_complete_congr` is conditional transport between recursive continuation functions. Its `same` premise is directional and global over metadata, caller, query state, captured cache, next decision and returned output endpoint. It requires agreement only when the first recursive function actually returns COMPLETE. The callback graph, templates, stop rule, order, callback fuel, original metadata, target, fragment, caller, queries and cache are identical. Actual recordTypes pruning retains its empty result directly. The exact successful nonpruned singleton uses the actual framed callback core and the exact computed restart. Malformed or error callbacks do not invoke either continuation. The premise asserts no existence or future language model.

`resume_complete_moreDepth` requires only d <= D and an actual COMPLETE result of the smaller-depth prepared resume. It quantifies over all original metadata, caller, queries, cache, supplied next decision, output list and final native endpoint. It needs no Packet, arity, physical projectability, model, Canonical, ProperState, reserved resources, final Heap or desired final semantics. It is structural preservation of an observed result. Work fuel, program functions, graph, templates, selector, stop and order all remain fixed.

`run_complete_moreDepth` applies that result to the actual initial `Restart.decision stop order metadata before`. The decision is fixed by the same original input. It preserves exactly the stated `.complete outputs finalCaller finalQueries` value. It does not transport a selected decision from a different state or worker.

## Proof path against the actual worker

- At depth zero, none, done and stuck decisions are independent of depth. An expansion is stopped with exhausted and cannot satisfy the COMPLETE antecedent.
- At successor depth, the prefix observation is the same actual `runPrefix` at the same six work fuels and original input. Static pruning and unsupported paths do not acquire new behavior merely from a larger recursive depth.
- The parked singleton branch uses the exact updated metadata, original caller and queries, actual parked cache, framed core and following decision from that prefix. The induction hypothesis preserves its complete recursive result. Empty and malformed parked rows follow the exact worker branches.
- In the narrowed branch, the action case split preserves the worker's earlier empty-action pruning priority. The shared proof for action none and nonempty action changes no branch condition. The right callback result, actual candidate cache and ordinary field stay fixed.
- A genuine continuation branch builds hooks with the smaller and larger recursive depth. The smaller-depth induction hypothesis derives their global agreement on actual COMPLETE results through `continueWith_complete_congr`. No desired semantic property is assumed to obtain this agreement.
- The selected-dispatch congruence then preserves the entire actual completed fold, including processed receipts and outputs, at its exact prepared caller and captured cache. `finish` returns the same final complete output/caller/query result. A stopped fold cannot satisfy the old COMPLETE result.

The result uses the actual `PreparedRecursive.Failure width Typing`, declared in `Type 1`, for both depths. The generic congruence helpers preserve independent Output and Reason universes. No old failure type or old worker is substituted. The original decoded source and newly prepared value are not equated or cast.

## Remaining scope

The theorem stabilizes completed results. It does not prove that any completed result exists. It gives no upgrade from exhausted or stopped to complete, no guarantee of nonempty outputs, and no monotonicity when work/native fuel changes. It does not establish accepted-language coverage or the existence of a common finite depth for callbacks that are not already known to complete.

It can combine finitely many known completed-depth observations by raising them to a maximum depth, provided the observations use the same required work fuel and exact inputs. Finding those finite completion bounds, and handling the earlier stopped-hook alternative in coverage, remain separate obligations.

Root reported the final source default-build PASS. Strict checking and compiler-generated public/axiom readback remain root-owned. This review did not run or independently inspect those checks. No compiler, native evaluation, Git, network, board, repository mutation or older-evidence mutation was used. No Haskell defect or fix is claimed.
