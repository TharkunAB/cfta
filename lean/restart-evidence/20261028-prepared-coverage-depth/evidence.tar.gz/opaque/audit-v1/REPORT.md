# Opaque, normalization and checked projection coverage audit

Status: bounded source audit. One additive source-only candidate. Root owns compilation and repository changes.

## Result

Accepted original pending values already reach an actual prepared accepted value. Existing prepared opaque coverage then reaches an actual accepted callback entry. Ordinary coverage reaches an accepting captured head, subject to selection coverage and support of earlier rows. Prepared sibling coverage can instead report an exact strictly earlier stopped recursive hook. None of these statements yet gives a recursive output for every original accepted term at some uniform finite depth.

The useful local addition is whole physical projectability through actual selected-value preparation. Checked source construction already supplies projectability. Checked native queries and actual parent construction already preserve it. The candidate connects actual Mu unfolding and Union exposure to those facts. It does not prove the remaining recursive producer or coverage theorem.

## Existing forward route

1. `SourcePruningEnumerationSelectedPreparation.complete` fixes its actual stable run and retained resource packet before its semantic observer. It preserves the stored original handle and bucket. It returns a separately available and closed prepared result. Its universal observer gives exact guarded-language equivalence and transports an original whole model to the entered cache. This uses the actual reached native heap and full memos.
2. `SelectedValue.run` leaves empty, reference and ordinary node values unchanged. It unfolds Mu once. That result can still be Mu or Union. It exposes Union through the actual finite cold reader and constructs a node from the returned rows. Its completion contract supplies stable actual `.done` observations. It does not infer stability for arbitrary exhausted errors.
3. `MergedOrdinaryHeight.recursiveBoundary` marks Mu and Union. `ordinary_operand` gives empty or an ordinary node when the value is closed and the boundary flag is false. Acceptance excludes empty. A bare reference has a nonempty free-variable list, so the original closed-value admission excludes it. This is not a completeness claim for arbitrary open references.
4. `SourceEqualityProjectionRead.Read.exact`, used in `NativeView.narrowAt_accepting`, already relates actual completed exposure to the independent Mu/Union row language. An accepted ordinary node therefore supplies an accepted resident row. A selector must include that row. A permutation of stored rows is sufficient. Global `selectionMembers` and `selectionLength` alone do not imply this inclusion.
5. `PreparedNativeHookResources.head_finite_complete_resources_accepting` retains an actual prepared captured head and an extended whole model. Its prepared parent availability and closure remain separate from the original pending handle. `NativeHeadCoverage`, `NativeBranchCoverage.complete_with_history_resources_accepting` and `NativeParentCoverage.parent_complete_resources` retain the native resource producer and exact captured receipt. They do not prove a model after its recursive callback.
6. `PreparedNativeHookResources.opaque_finite_complete_resources_models` already handles the actual opaque or terminal dispatch. Original full `Satisfies` plus acceptance of the actual incoming value yields an assignment extension, the same completed receipt, the correct fragment fill, and a whole model at that receipt's own caller and cache. No desired final model is an input. No `ProperState` premise is added. Do not duplicate this theorem.
7. `ChildCompletion.complete_with_fragments_resources_terminal_accepting` retains the original complete child resource packet. Under `bucket.any isTerminal = true`, original whole satisfaction, incoming acceptance, and every original suspended restriction, it forces the same actual singleton and the same satisfying assignment. The more general child coverage also handles nonterminal opaque values by assigning the chosen accepted term to the fresh slot. This establishes the intended partial-output model. It does not validate every later assignment to that slot.
8. Parked recursion is covered by `Recursion.checkRepeated_true_satisfies`: original whole satisfaction is equivalent to parked satisfaction together with the removed suspended restrictions. Original acceptance supplies those restrictions in the forward direction. The false check has an exact frame law. Neither branch alone proves successful recursive continuation.

## Exact policy gates

`NativeView.keeps_of_accepted`, `narrowAt_accepting`, `OuterNarrow.narrow_accepting` and `SelectedStep.prefix_accepting` retain the actual policy tests. For the selected term, their sufficient conditions are:

- For a unary term, every accepting first-child annotation passes `admits`, and the symbol passes `fits`.
- For exact label `("app", Formula.top)` with four children, every accepting first-child annotation passes `admits`.
- For exact label `("filter", Formula.top)` with two children, every accepting first-child annotation passes `admits`.

Other arities and labels follow the actual `keeps` branches. The outer type-marked and Mu cases use their actual skip branches. Generic native acceptance, `Packet`, or arity facts do not imply these policy conditions.

`PreparedRecursive.callback_finite_complete_resources_models` has separate original callback conditions. It requires `Refutes` for every original metadata pending group, template `Avoids` for the filled fragment, and `ProgramEncoding` for every `ProgramAt` of that term. These imply no record-types rejection and preserve the original model in the actual framed restart. They do not imply a model at a returned recursive output. Native acceptance alone does not imply these template and encoding policies.

Coverage remains relative to the exact fixed `SourceEqualityPCSGuard.holds formulas solver`. The existing original `Context`, cache coverage and memo conditions stay in place. The projectability lemma below needs no solver completeness assumption. The audit does not replace unsupported or unproved solver behavior with success.

## Projectability: existing original producer and preservation

Use `projectable c := SourcePruningEnumerationConstraint.project c != none`, where the Lean proposition is `≠ none`.

`CheckedSyntaxOrigins.SourceChecked` requires both cached original equalities and the literal checked edge acceptance test at each syntactic child count. It includes every nested child, union member and binder body. This is stronger than the current generic Packet plus arity premise.

The original startup bridge already exists:

- `ProjectionHeap.source_allowed` derives generic annotation construction admission.
- `build_projectable` preserves whole physical projectability through every actual build outcome.
- `constructed_projectable` derives it for an actual successful build from the empty heap.
- `closed_projectable` constructs the actual closed result, its whole projectable heap, and its annotated value.

Existing preservation is genuine actual-producer preservation:

- `CheckedProjection.accepted_projectable` derives successful projection from the actual checked constructor acceptance test.
- Allocated MkEdge accepted and rejected receipts, and allocated ParentEdge receipts, give projectability of their actual returned guard. The rejected branch uses the actual Top sentinel.
- `CheckedProjectionHeap.work_heap` and `build_heap`, allocated `build_projectable_heap`, `Receipt.preserves_projection_heap`, and `reject_projectable_heap` preserve the full physical heap.
- `ParentProjectionHeap.parent_heap`, `verified_projection_heap` and `finite_projection_heap` follow actual parent `Reads`. Their original ready, admitted, live-input, ranges, validity and memo/cache gates remain explicit. The same returned result and endpoint are retained.
- `NativeQueryProjectionHeap.node_query_heap` and `edge_query_heap` follow the actual complete `Trace` from request to pure return. They require original `Good`, original projectable Heap and that actual trace. Their proof inducts on actual shorter requests. `node_query_edge_memo_projectable` then reads the actual resident returned memo record.

A generic `Post` or growth relation cannot establish projectability of newly allocated records. Use these actual constructor, query and parent lemmas.

## The one candidate

File: `candidate-v1/MicroCFTA/SourcePruningEnumerationSelectedValueProjectionHeap.lean`.
Export: `MicroCFTA.SourcePruningEnumerationSelectedValue.run_projectable_heap`.
Explicit argument order: `fuel value before ready available closed heap`.

Premises: original `SourceEqualityRequiredCache.Ready before`; actual original value `Available before value`; `value.free = []`; whole original annotation Heap for `project ≠ none`.
Conclusion: the same whole annotation Heap at `(SelectedValue.run fuel value before).state`.

The result covers the actual returned state even when the operation is pending. Empty/reference/node keep the heap. Mu uses `SourceEqualityAnnotationUnfold.unfold`. Union uses `SourceEqualityAnnotationExposure.nodeEdges_heap`, then the actual `makeNode`. It uses no final Heap premise, language equivalence premise, oracle, source/prepared cast or custom axiom. It adds no old-source edits. The original completion theorem can identify a successful result with this actual endpoint.

The candidate is 2,871 bytes and 51 lines. SHA256: `59f8f390418990d84ac2387e31bd49f5a664b9f3fb14049f9aa0bf0cc643cb98`. It is uncompiled by this agent. Root must establish the checked status separately.

## What the heap removes, and what it does not remove

At one prepared ordinary parent, full projectability discharges current row support before any callbacks. Use actual parent availability, `Ready` linked facts, and `InternedEdgeResidency.resident_edges` to obtain resident rows. Apply the physical projectable Heap to each row. `selectionMembers` then gives projection success for every literal selected row. Membership in `take index` gives the exact earlier-prefix gate:

`∀ earlier ∈ selectedEdges.take index, arityAllows earlier.children.length scs = true → project earlier.entry.key.constraint ≠ none`.

This is stronger than that gate. It uses no arity implication. The literal selected edge guards do not change after earlier callbacks. Therefore this current-parent support fact can be reused without deriving a whole heap at every intermediate callback merely for this purpose.

For global recursive coverage, newly selected recursive inputs still need supported native values. The producer must carry projectability, or an equally precise checked annotation origin, through the actual prefix, preparation, native work, callback aggregate endpoints and suffix. Empty-output callbacks also change the aggregate caller. A per-returned-output certificate alone does not cover that aggregate endpoint. This global attachment is not supplied by the single candidate.

Arity alone does not remove support. `ArityOrigins.Fits` only constrains successful projections. `project = none` makes it vacuous. `CheckedProjection.raw_ready_counterexample` constructs a Ready raw native heap with cached equalities and an actual resident zero-child edge whose projection is none; its arity test against the empty bucket succeeds. The theorem itself states Ready, cached equality Heap, actual resident edge and projection failure. The vacuity of that edge's arity follows separately from the definition of Fits. It is a raw interner example, not a checked public constructor execution and not a demonstrated Haskell defect.

## Remaining coverage boundary

`PreparedFiniteSiblingResources.alternatives_finite_complete_resources_accepting` retains two exact outcomes for an accepting chosen index. It either reaches that index with the accepted extended model, or reaches a strictly smaller event index whose actual recursive hook stops. The latter includes the exact stopped hook result, original whole resource packet and actual scan result. It is not removed by projectability. It is not removed by large native/work fuel with recursive depth fixed.

A next coverage proof must supply one finite recursive depth that handles all relevant earlier callbacks and the accepted chosen continuation, under the original actual policies and checked source lineage. It must also preserve those policies and supported origins at newly selected inputs. The present local results do not establish that uniform depth. No impossibility or actual diverging admitted family is claimed here.

`DischargeBoundary.initial_boundary_done` is an existing legacy-worker theorem. Its shared actual startup has a full Packet, Canonical and ProperState, a graph-bearing root, no selected candidates, successful marker rendering, and NOT Discharged; its legacy run reports done at every work and recursive fuel. This audit does not cast that run or its history to the prepared worker. It records the shared native classification and rendering boundary. Partial or truncated output remains an intended scope. Arbitrary rendering cannot be used as a proof of whole Discharged.

No Haskell code was changed. No new Haskell defect or fix was established. There is no new Haskell fix to add to FINDINGS in this bounded audit.

## Read scope and frozen evidence

`source-identities.json` records 37 whole sources, 388,586 source bytes, with exact preserved copies and SHA256 identities. It separately records a literal lines 1–188 cut of prepared sibling coverage. That cut includes its whole exported statement and the start of the proof; no whole-file read is claimed for it. The source-only candidate remains immutable. No compiler, native evaluation, Git, network or board call was made. No repository or older frozen-area file was written.
