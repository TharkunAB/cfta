# Scheduling and discharge audit

This audit uses the live repository sources. Root supplied checkpoint 130d0a819 and reported the pull. This agent did not call Git, Lean, lake, native code, the network, or the board. Root reported default build PASS for NativeSelectionProgress after qualifying Ready and IncomingAvoid. The proof candidate remains separate from compiler evidence.

## Exact local result

Candidate-v2 adds only Restart.expand_of_pending. It uses the original CacheValid, Safe, ProperState, a literal pending native slot, its actual lookup, and a whole current finite assignment. The pending slot is ordinary, or its suspended bucket is nonempty. With stop=none, every order produces an actual expand decision for some ready root that has IncomingAvoid. It does not require a future model, a future Discharged state, or a selection-result oracle. The proof composes existing done_pending_boundary, not_stuck_of_proper, and selected. It does not promise selection of the supplied slot or fairness over an unbounded sequence.

The actual order hint needs no membership policy. pickNext checks membership and otherwise chooses the first offered candidate. A configured stop rule can return none when every nonempty candidate passes the rule. stop=none is a sufficient local progress policy. A rule that is false at some actual candidate also prevents that early return. This latter variant is observed from decision; it is not an added theorem.

## Done and unrestricted values

The WHOLE existing DischargeBoundary module already proves the important counterexample. An original available closed recursive boundary starts with a full Packet, ProperState, Canonical, and carriers. The actual run emits a singleton DONE cache at every work and recursive fuel. The cache is not Discharged, and the actual renderer emits the recursion marker. Increasing fuel does not change that intended opaque output. No duplicate counterexample was added.

Discharged permits `.unenumerated none []`. Those free equality variables are not missing work. ProperState separately forces none-bearing pending buckets to be empty; Packet does not contain ProperState. Existing done_discharged_of_nonrecursive_pending keeps that distinction explicit. It proves discharge only with ProperState and a separate original nonrecursive-pending restriction. That restriction is not suitable as a general coverage policy for intended opaque outputs.

## Parking and depth

The actual repeated check tests a native boundary and an ancestry key. Its fuel resolves representatives; it is not an outer enumeration depth limit. A repeated key clears the selected suspended bucket and retains the same handle. Native write disables that candidate and removes the old waiting counts. The actual restart retains the caller and query state. The parked resource-history arm consumes one outer recursive step and then records the literal restart observation.

ParkedLanguage.checkRepeated_true_satisfies already gives forward model preservation: apply its forward implication and take the first conjunct. Its converse requires every removed suspended constraint. A later parked model alone cannot supply those old constraints. For a genuinely selected parked slot, the native write preserves every other candidate flag and the counter. Thus the finite candidate count decreases. This last quantitative statement follows from the displayed write and selection receipts; this audit did not add a second lemma for it.

The finite prepared worker still returns `.stopped [] (.exhausted uv metadata before) ...` when recursiveFuel=0 and an expansion is selected. Stable finite work fuel at a fixed recursive depth does not remove that result. The resource contract permits it and retains histories only for outputs that were actually emitted. ResourceHistory.done and stopped retain supplied decision tags; policy claims must also retain the literal actual initial decision and run, as the complete producer does.

## Concrete remaining coverage interface

The missing coverage result must start with an original accepted finite assignment and derive an actual emitted output plus a corresponding final assignment. The final assignment must satisfy the output's own native heap/cache and agree with the original assignment at every original allocated variable. Partial opaque outputs must be allowed. Discharged is a separate condition for concrete rendering and is not a coverage premise.

A suitable target shape is:

    original Packet/resources + original ProperState/Canonical/arity
    + original Satisfies(native PCS handles, fixed residual meaning, assignment, before)
    + source-grounded complete edge/pruning policy
    ==> derived finite recursive depth and stable work bound,
        actual outcome and emitted output,
        final Satisfies at output.caller/output.cache,
        and agreement of assignments below before.core.counter.

This is an unproved target, not a proposed assumed contract. Existing edge member/length gates are only upper bounds. They do not say that edgesOf includes the edge that supports a supplied model. Such row coverage and any admissibility/pruning policy must be stated from original source data.

There is also an ordered-search obligation. NativeContinuations stops the suffix when a head continuation stops. A model path whose own depth is finite does not by itself bound all earlier siblings. A coverage proof must derive a finite bound for each preceding continuation, or prove the required result under a genuine original finite-search condition. It must not assume no future exhaustion. This audit does not claim that the existing general premises imply that additional bound.

Root has now assigned a narrower next theorem: a complete actual resume at fixed work fuel remains exactly the same at greater recursive fuel. This does not assert existence of a complete run. That theorem can preserve all outputs/caller/query while this coverage obligation remains open.

## Scope and evidence

The manifest preserves whole source snapshots and labels exact whole or partial read scopes. Early combined tool outputs were truncated; all sources labelled WHOLE were then read again in full without truncation. No Haskell file changed. This audit establishes no new Haskell fix for FINDINGS.
