# Complete recursive-depth stability candidates

This bounded task writes only new schedule version directories. It uses no compiler, native code, Git, network, or board call. Source snapshots and the manifest preserve exact bytes. Every source in this evidence manifest was read whole without truncation. The two candidate modules were also read whole.

The installed generic NativeContinuations.run_complete_congr transports a complete ordered native scan when a replacement hook preserves every actual complete hook result. Root reported default and strict checks. The helper preserves processed receipts, output order, final caller, and query cache. Stopped hooks need not agree.

The first candidate module adds the corresponding complete-result transport for one ReceiptContinuation and for actual SelectedContinuations.run. Native preparation, entered core, target, suspended buckets, native caller, captured cache, and all work fuels remain fixed. The selected theorem binds the literal actual second projection to `some (.complete processed outputs finalCaller finalQueries)`.

Root reported default and strict PASS for the installed helper after removing redundant decrease-Ite simplifiers in the two terminal branches. The source diff preserves those exact proof-only repairs. The helper's exported statements did not change.

The second candidate adds actual callback continuation congruence and actual prepared resume/run stability. It takes originalDepth <= largerDepth. A literal complete result at the original depth implies the exact same outputs, final caller, and final query cache at the larger depth. Work fuel, stop/order policy, all original source functions, initial metadata, caller, query state, and cache remain identical. Output lists retain each branch's own cache, caller, query state, and metadata through exact list equality.

The proof uses induction on the original recursive depth. An original depth-zero expansion cannot have a complete result. Done, supplied stop, stuck, pruned, and unsupported branches either stay identical or contradict the given complete result. The parked singleton uses the induction hypothesis at its literal framed core. A selected continuation uses callback congruence and the installed selected complete-result transport. The two action cases preserve the source match priority.

No resource, semantic model, Discharged condition, source/prepared identity cast, or assumed family of fuel stability appears in the depth theorem. Actual COMPLETE is an evaluation premise at the original point. The theorem asserts no existence of a complete run and says nothing about stability of an exhausted or otherwise stopped result.

Current validation: the generic and installed selected helpers are strict PASS as reported by Root. The new depth candidate was delivered for Root's compiler check; this agent has not compiled it. Compiler status is deliberately not inferred from source review. No Haskell file changed and no Haskell fix was established.
