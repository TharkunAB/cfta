# Prepared ordinary coverage audit

Audit complete at 2026-10-28 18:40:40 CET. Global accepted-output coverage remains open.

Read scope: 25 whole source files, 325,599 bytes and 4,738 lines. Literal copies, hashes and five complete exported interface cuts are retained. The manifest lists all read scopes. The initial truncated sibling read was replaced with complete reads of lines 1–240 and 241–475. Discovery search truncation is not used as proof evidence.

## What is genuinely constructive already

PreparedFiniteHeadCoverage.head_finite_complete_resources_accepting does more than preserve a possibility. From an original model and an accepted actual edge, it derives the actual successful projection and inherited arity check, constructs a fresh assignment extension, identifies the SAME actual captured receipt at a common work bound, fills its fragment with the original term, and proves the model at that receipt's actual native heap and cache. It preserves all old allocated assignment entries. No source/prepared-parent identity is required. The model stops at callback entry.

PreparedFiniteHeadOrigins adds original structural paths for every allocated variable. PreparedFiniteSiblingOrigins preserves those facts while following the actual scan endpoints. PreparedFiniteParentOrigins already composes the actual row permutation with SelectorLanguage.selected_accepting_of_perm. It chooses a concrete accepting edge and index before extra work fuel. PreparedPrefixOrigins already supplies normalization, model transport and original paths at the actual prepared parent. A new wrapper of these existing facts would not close the coverage gap.

## Five exact gates

1. **Callback recording.** Actual continueWith maps singleton recordTypes true to complete [] and never calls resume. A chosen head can therefore be genuinely accepted and reached without emitting an output. Earlier rejection is different: complete [] still allows the next sibling. PreparedCallbackModels, PreparedFiniteReceiptModels and the Origins variants already exclude rejection for the chosen permitted model. They require pending Refutes and local Avoids/ProgramEncoding. OriginPolicies supplies the latter at ALL structural original subtrees. It is stronger than a policy over ProgramAt at the root alone, because ProgramAt does not inspect annotation children. Packet.bounded and pending_refutes_extension retain original pending Refutes under fresh assignment agreement. The recording Frame preserves the exact complete model and original paths. The resulting actual resume outcome is retained, but no recursive-output model is asserted.

2. **Supported earlier rows.** The sibling theorem takes exactly: for every earlier row in take index, arityAllows its child length scs = true implies project its own constraint is not none. Acceptance derives this condition for the chosen row, not for arbitrary earlier rows. Arity-rejected rows can advance without a hook. An allowed unsupported row produces unhandled and stops the suffix. The current proof needs this supported-prefix input; this audit does not claim it follows from the full original admission.

3. **Stopped hooks.** SiblingCoverage and SiblingOrigins conclude chosen event OR strictly earlier stopped hook. Both alternatives retain real receipts, outputs, reasons and endpoints. The stopped alternative supplies resources, not a target model. At the chosen index, the theorem reaches the actual head even if its later hook stops or completes with zero outputs. Neither case supplies the missing model-preserving emitted output. An earlier stop can only discharge a coverage goal if its actual emitted outputs already cover the target model; resource evidence alone does not show that.

4. **Selector coverage.** selectionMembers and selectionLength only restrict membership and size. The constant-empty selector satisfies both and omits all accepting rows. The actual permutation route is already proved and must be attached to the intended selector. Raw interned rows have an existing accepting-edge theorem. Canonical selection has an existing theorem under its actual map/fallback row correspondence; construction of that correspondence remains separate.

5. **Same assignment and native growth.** The scan reuses the captured enumeration input and metadata for siblings. Earlier callbacks change the native caller and full saved queries before the next sibling. Existing satisfies_keeps, using PendingRealized from Packet.valid and actual Post.effects.keeps, transports the SAME original assignment for that unchanged captured cache. EdgeMeaning is independent of this caller growth. The chosen head then constructs an extension for its own fresh variables. No model of an earlier branch's distinct cache is needed to run a later sibling, and raw heap growth does not imply the required model fact.

## Smallest remaining semantic bridge

The existing chain reaches the actual chosen callback, proves nonrejection from original policies, and reaches its actual prepared resume. It does not prove that this resume emits an output whose actual cache and native caller satisfy a model extending that callback-entry assignment. That is the next genuine semantic conclusion to prove. It must retain agreement on old allocated variables and original paths so the model can be used by later callbacks. It must come from an original progress/depth invariant and induction on the actual worker. Adding an assumed future-output/model contract would leave the gap unchanged.

To reach that branch in the full ordered scan, one must also control every earlier reachable callback. A sufficient route proves their operational completion, allowing complete [] pruning. The minimal alternative permits an earlier stopped hook only when its own actual outputs already cover the target model. Policies for the chosen original model and its height do not by themselves bound unchosen earlier executions. No admitted all-depth counterexample was established. In particular, the parent-reported A=f(A)|a sketch is not used as evidence; actual empty-bucket Mu parking and repeated-key behavior must be included. Fixed recursive fuel 0 directly gives stopped [] at an expansion, which only refutes an unconditional fixed-depth existence claim.

## One bounded additive draft

candidate-v1/MicroCFTA/SourcePruningEnumerationHookInvocationCoverage.lean adds only Invocation.output_mem. It is the forward counterpart to run_output_invocation. An actual invocation plus literal hook-output membership implies membership of that SAME payload in the actual whole sibling result. The proof follows all three Invocation constructors and retains outputs from stopped hooks and stopped suffixes. It needs no Packet, model, arity, resource or future-endpoint premise.

This draft is untested by this audit. Root owns compilation. It is useful once a real recursive model-output witness is proved. It does not construct that witness, select the chosen branch, eliminate an earlier stop or establish global coverage. Applying it to an unrelated earlier hook cannot replace the target model requirement.

The candidate is 4,923 bytes and 81 lines. SHA256: 519bce55d4f5a4463a4bf0f83e18d1fd15bae2f27ba96ba9d33c37a5565fa2c0.

No Haskell modification or implementation fix was made. No compiler, native execution, Git, network or board operation was run. All earlier sealed evidence areas remain unchanged.
