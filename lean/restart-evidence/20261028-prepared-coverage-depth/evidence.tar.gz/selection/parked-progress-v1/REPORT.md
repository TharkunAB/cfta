# Actual selected parking progress

One additive draft is ready at 2026-10-28 18:55:08 CET. It is untested here. Root owns compilation. The candidate and this evidence are frozen.

The theorem is selected_complete_with_parking_progress in SourcePruningEnumerationParkedRestart. Its only inputs are the original caller/cache, preference, selected uv, original Safe, original native CacheValid and the actual pure selection result. It returns the real stored handle and bucket, the stable successful getValue family, the stable successful native checkRepeated family, and the actual returned CacheValid/Safe. If that actual returned repeated flag is true, it concludes:

- The allocation counter is unchanged.
- The expandable function changes only at the selected uv, where it becomes false.
- EnumerationIndexSelection.candidates after is strictly shorter than candidates before.

The proof uses selected_complete_with_order once. That original producer derives actual Ready from selection and the source flags. On the repeated branch, its real representative Frame and setValue receipt prove that only the selected stored value changed. The original source flag equations and the returned source flag equations then derive the whole flag function. Those returned equations are producer conclusions, not new assumptions. The existing parked_order proof derives counter equality from the actual clear write.

Selection.offered proves that uv was an allocated true candidate. With the fixed counter and exact flag update, the new candidate list is the old list filtered by inequality to uv. Standard finite-list lemmas prove the strict length decrease. No final flag-change or decrease oracle is assumed. The candidate also does not need an arity heap, a model, or a new native word reservation.

The measure includes every cached candidate before waiting-key exclusion. Parking removes suspended references and can unblock other existing candidates. The complete candidate list still decreases. The result bounds consecutive parking steps at the unchanged native heap. It does not bound subsequent ordinary allocation, re-enabled flags, callback trees or whole-driver recursive depth.

This is a constructive actual-result family. It does not assert a property about an unrelated supplied future cache. The existing clear producer already derives the full flag update. The recursion wrapper retains only the disabled selected flag and the actual write receipt, so this candidate recovers the complete update at that exact endpoint. It preserves source/prepared distinctions and all existing source bytes.

Whole read scope: 7 source files, 85,570 bytes and 1,371 lines. Literal whole source copies and hashes are in evidence/sources and manifest.json. The exact Lean 4.34.1 list-lemma cuts are copied separately. An initial lookup of the old 4.26.0 list file was replaced with reads of the current recorded toolchain definitions. No claim relies on an unread or truncated source. The targeted duplicate search found no existing candidates-length relation in *Enumeration*.lean.

Candidate: 5,255 bytes, 90 lines. SHA256: a9119182758ebebe9deb80d46f9a7829c7eb45a8739e42c9cd69822ba380c225.

No compiler, native execution, Git, network or board operation was run. All writes stay in this new parked-progress-v1 directory.
