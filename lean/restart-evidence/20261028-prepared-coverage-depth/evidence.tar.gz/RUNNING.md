# Superseded by root-progress-final.json and the committed detailed handoff

All final checks pass. See lean/notes-current-prepared-coverage-depth.md.
The original running note follows unchanged.

# Open proof area: prepared coverage and depth

Status: PROGRESS. The full formalization goal is active.
This is mutable work. No checkpoint seal exists yet.

Repository: /home/tritlo/Code/mcfta. Branch: formalize.
Base: 130d0a819b73437fa7dcf1283c6ba827923f61f0.
Pull at startup: Already up to date.
Published current head: be64293c269700d41da3abab97eeb365fa49842e.
The exact four-commit push and remote verification are in push-first.json.
Normal pushes to origin/formalize remain authorized.

## Verified additions

Five installed modules give seven public theorems. Each passes exact strict
Lean 4.34.1 with warningAsError and linter.all. The combined Audit passes
4,506 jobs and checks 81,571 theorem dependencies. The 681-theorem public
readback is 3,034,447 bytes. The previous 3,016,159-byte readback is an exact
prefix. Read public-first/prefix-verification.json and root-review/public-first.json.
Only propext, Classical.choice and Quot.sound occur in those axiom lists.

- NativeSelectionProgress derives an actual ready root from original Safe,
  ProperState, CacheValid, a whole model and live native work with stop=none.
- SelectedValueProjectionHeap retains full physical guard projectability at
  every actual normalization endpoint, including failed endpoints.
- SelectedPreparationProjectionHeap attaches that result to actual entry and
  preparation rows. Every row of its completed node has successful projection.
- HookInvocationCoverage retains a literal invoked hook output in the actual
  sibling scan, including later stopped suffixes. It does not supply an output.
- NativeContinuationCompletedCongruence retains a completed actual sibling
  scan under agreement on completed hooks. It makes no completion claim.

All 4,500 prior non-Audit Lean sources, 349 stronger sources and 817 Haskell
files pass exact source identity checks. See preservation-first.json.
No Haskell source changed. No Haskell check ran. No new Haskell fix or defect
was established. Keep earlier FINDINGS repair records.

## Open additions

SelectedContinuationCompletedCongruence is installed and uncommitted.
Its two exact dispatch congruence theorems pass strict-selected-congruence-2.
The first strict repair removed a redundant simp argument from the other
branch. The remaining false-branch linter then failed. The targeted repair
passes. Both sources and complete diagnostics remain available.

history_canonical drafts PreparedRecursiveDepth. It must preserve exact
completed outputs, caller and queries at fixed work fuel when recursive depth
increases. This is conditional on an actual complete run. It must not assert
that a sufficient recursive depth exists.

ordinary_gates attempts one bounded native parking candidate-count decrease
lemma. This can bound consecutive parking steps only.

opaque_meaning reviews the two completed-congruence modules. A final depth
source review remains pending.

No compiler, native or Git handle is live at this note's creation.
Root owns every compiler, repository edit, Git and board operation.
Agents write only new owned directories under selection, schedule and opaque.

## Main gap

Existing prepared head, prefix, sibling, parent and origin-policy theorems
already construct accepting captured models. Do not duplicate those wrappers.
The missing result derives an actual recursive emitted output with a model
that agrees below the original counter. It must also derive one finite depth
that handles all earlier reachable callbacks in the ordered scan. An earlier
callback can complete with no outputs and still allow the chosen row. An
exhausted earlier callback stops the suffix. The chosen term height alone does
not bound those earlier callbacks. No admitted all-depth divergence example
has been established.

The current prepared parent has row support derived from its physical heap.
Projectability at every newly selected recursive input still needs actual
checked operation preservation. Generic Post growth does not prove it.
NativeGuardAlphabet.step includes unchecked conjunction forecasts, so Known
membership alone does not prove projectability of that whole alphabet.

Preserve intended opaque and partial output semantics. DONE does not imply
Discharged. The existing boundary example is real. Do not require Discharged
as a general accepted-model coverage premise. Concrete checked rendering uses
Discharged as a separate observer condition.

Public source/acceptance and PCS-language adapters, counting/ranking/sampling
connections and optimized Haskell correspondence remain open.

## Evidence and next work

The first failed build is build-selection-normalization-1. Its full 4,745-byte
raw diagnostic was read. It identified an explicit Constraint import and
qualified Ready/IncomingAvoid names. The repaired build passes. The hook's
unused simp argument was removed before its strict check. All candidate
versions and raw outputs remain. There are currently two compiler failures:
that first build and strict-selected-congruence-1.

Run compiler jobs serially through check-installed.py under heavy-management
bin/capped --mem 4G --time 5m. Set the task HEAVY_PEAKS file in peaks/records.log.
The runner asserts measured memory.max=memory.high=4294967296 and swap.max=0.
Do not add proof axioms, placeholders, budgets or linter suppression.

Finish the bounded depth and parking additions. Review full source and public
blocks. Update Audit. Run final strict checks and public readback. Preserve old
public bytes as an exact prefix. Update FINDINGS and restart documents with
precise limits. Post useful verified board knowledge. Freeze this area only
after all mutable evidence and receipts are saved. Package every regular file
with the existing verifier, verify fresh reconstruction, and push reviewable
commits. Keep every prior frozen area immutable. Do not pause or complete the
full goal at this checkpoint.
