# Restored module and unique-name validation addendum

The final proof is `lean/MicroCFTA/SourcePruningEnumerationParkedActiveCount.lean`. Its 12003 bytes are identical to the previously reviewed proof and the new passing strict-check copy. SHA256: bf1c840846f5652df0b8cf99002c9c8bc365347e459dad7ee3aba3987e283faf. The earlier wrong-filename checks are historical evidence, not the final validation.

Root had temporarily overwritten the tracked `SourcePruningEnumerationParkedProgress.lean` while the changes were uncommitted. Root restored it and moved the new proof to the unique filename. `evidence/collision-repair.json` records the repair. This owner changed no repository or prior-bundle file and ran no compiler, evaluator, native, Git, network or board command.

## Restoration and scope correction

The restored original has 5251 bytes and 90 measured physical lines. Its SHA256 is 66e2ddc2cb2947f1c2d67de256b314583f3dd9029425d937796025efc54e6cdc. Its bytes match Root's pinned HEAD extraction at b1d02119e953a627b13f0dfc8e1aaab4ddefbad2 and both the prior 4675-source and protected 476-source manifests. `IDENTITY.json`, `GUARDS.json` and `evidence/restored-original-HEAD.json` record these checks. The HEAD extraction was performed by Root. This owner directly compared its bytes to the restored file.

The original theorem `selected_complete_with_parking_progress` already proves model-independent strict candidate decrease, unchanged allocation counter and exact functional replacement of the selected expandable flag. It uses the original Safe, CacheValid and actual selected-expand inputs. The complete old theorem and proof are pinned in the exact source cut22–90. It must remain preserved.

The new result strengthens that existing progress. It proves exact +1 candidate consumption and retains both the complete old order interface and the exact configured restart interface with the same actual witnesses. It adds no top-level premise or semantic model. It is not the first proof of model-independent strict parking progress. The earlier review's wording that described this as a newly closed parking gap is superseded by this correction.

The source-level contract recovery and same-witness analysis in the frozen `contract-review` bundle still apply, because the new source bytes are identical. This addendum supplies the final unique-name validation and restoration evidence. The old bundle remains immutable.

## Final passing checks

All final checks use the restored original and unique new proof:

- `unique-v1-build`: exit0, 1365 jobs.
- `unique-v1-strict`: exit0, warningAsError=true, linter.all=true, empty log. Its pinned source matches the reviewed/current unique proof exactly.
- `audit-restored-build`: exit0, 4676 jobs, including the restored original module.
- `audit-restored-strict`: exit0 and 82398 checked theorem dependencies. Its source hash matches current Audit.
- `public-restored`: exit0; the declaration and definition inventories contain 986 and 79 entries.

The small reports and logs are copied under evidence. The 4194611-byte public raw log is verified against its report and pinned by origin, byte count and SHA256 in EVIDENCE.json. It is not duplicated here. Root retains the full phase evidence. The build logs replay an old unused-variable warning; the unique leaf strict log is empty.

## Identity guards and remaining goal

This owner independently checked current bytes against all three prior manifests. All 476 protected source identities and all 835 Haskell/build source identities match. Of the prior 4675 Lean files, only Audit differs. The unique new filename is absent from the prior manifests. These are checks against this phase's baselines. They do not erase the earlier main integration history.

No Haskell source fix or new Haskell defect was established here. Global ordinary/opaque control, bounds for unproductive earlier alternatives, the distinct Recursive and PreparedRecursive compositions, full public/unfolding coverage and Haskell correspondence remain active. This addendum does not review the separate new path-carrier work.

## Acquisition and seal

Only one old semantic source cut was acquired, at exact requested/actual lines22–90. No whole old source was semantically acquired. Existing proof bodies were reused by byte identity. Whole copies of the reviewed task proof and its new strict snapshot are retained for exact validation. Metadata and opaque hash checks are separately labelled. No source output was truncated or EOF-clamped.

The prior frozen review and all earlier bundles remain unchanged. VALIDATION.json records the measured final identity checks. pins.json and FROZEN.json seal only this small restored-review addendum.
