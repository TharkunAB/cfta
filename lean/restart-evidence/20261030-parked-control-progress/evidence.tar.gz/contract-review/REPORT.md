# Independent parked progress review

Verdict: the implemented public contracts preserve the old interfaces and add exact candidate consumption. The reviewed final source is 184 lines and 12003 bytes. Its SHA256 is bf1c840846f5652df0b8cf99002c9c8bc365347e459dad7ee3aba3987e283faf. Root's matching v2 build and strict checks pass. This owner performed source review only. This owner ran no compiler, evaluator, native, Git, network or board command and changed no repository source.

## Contract recovery

The full statements of `selected_complete_with_order_progress` and `selected_complete_with_restart_progress` recover their old statements literally. The recovery removes only the appended original true flag and the repeated-case exact flags/count conjunction, then restores each old theorem name. No input, existential witness binder or original result clause is removed or rewritten.

| Contract | Complete old header bytes | Old and recovered header SHA256 |
| --- | --- | --- |
| selected_complete_with_order | 3332 | c7f6e6121e5e859e9c71da0f36609568aed532b51dd08fddf3bdafceb0d18290 |
| selected_complete_with_restart | 1969 | 584eeb22cad7d9004a4281501f4f47871e9cae9acb61aa7a8025fede549ae856 |

The saved `order-old-header.txt` and `restart-old-header.txt` contain the complete original headers. Each has a matching `*-recovered-header.txt`. `HEADER_RECOVERY.json` records the new and recovered sizes and hashes.

Every old unconditional clause remains unconditional. Every old branch implication retains its original scope. The old final branch implication is closed before the added outer conjunction. The new original selected-flag fact is unconditional. Only the new actual after-flags and numerical decrease are conditional on repeated=true. No old field is placed below this new implication.

There is no new semantic model premise, recursive worker supplier, resource supplier, candidate bound or asserted rank in either public interface. The lower proof derives the required original true flag and allocated index from the old actual `.expand uv` selection, using the existing `SourcePruningEnumerationSelection.offered` theorem.

## Same actual witnesses and write

The order-progress proof calls the existing `selected_complete_with_order` once at source lines95–100. It returns the same readFuel, handle, suspended list, native value, readAfter, checkFuel, repeated flag and after cache. Its refine at lines101–103 returns all old clauses directly, including the same original parked receipt. It does not obtain a second existential run or replace the actual after cache with a constructed cache that only has the requested measure.

Inside repeated=true, the proof extracts that same parked receipt. It specializes `indexed` at extra=0. The decoded value and boundary result show that clearing the pending bucket gives candidate=false. The actual `NativeIndex.write` receipt then gives, for every index:

```lean
after.expandable other =
  if other = uv then false else before.expandable other
```

The removed waiting-count operation remains part of the actual successful write. Its none result is impossible because the recorded indexed write returns some after. In the some branch, congrArg projects the flags from the exact returned cache equality. The proof does not infer the off-slot equation merely from the selected flag being false or from abstract cache validity.

The original order receipt supplies `after.core.counter = before.core.counter`. The original selection supplies `uv < before.core.counter` and `before.expandable uv = true`. The private candidate-count lemma at lines19–42 uses the existing candidate definition, the no-duplicate finite range, membership of uv and the exact flag equation. It proves that after.candidates is before.candidates with uv erased, then derives:

```lean
(EnumerationIndexSelection.candidates after).length + 1 =
  (EnumerationIndexSelection.candidates before).length
```

This reasoning is independent of an accepting assignment or accepted term.

## Configured restart remains exact

The restart-progress proof destructs the original CacheValid resources and calls the stronger order producer once. It uses its same selected state, read and check observations, native cache facts, order receipt, actual parked write and new progress facts.

It reconstructs the old CacheValid and Safe results exactly as the original restart producer did. It obtains the same countFuel receipt and uses `run_parked_after_write` with the actual readExact0, checkExact0, written and indexed extra observations. The quantifiers over extra work, stop function, order function and metadata remain unchanged.

The old exact configured result remains present: a stuck restart gives the empty list; every other decision gives the original metadata, exact restart decision and same after.core. The new theorem does not convert this into a weaker success-only existential or change configured stopping behavior.

## Failed first build and final evidence

The first build failed with an unsolved none branch. Its local hypothesis was `observed : none = some after`. The final v2 adds `cases observed` after simplifying that impossible branch. `v1-v2.diff` records the complete source difference. The only source change expands this none branch to perform the elimination. Both complete public headers are identical between v1 and v2.

The exact v1 failure log, report, source snapshot and v2 evidence are preserved. The v1 report has exit_code1. It is not presented as a passing result.

The final v2 module build has exit_code0 and reports 1365 jobs. The build log replays an existing unused-variable warning in InternedFreshOrdinaryClosedCompletion. The targeted strict check has exit_code0 and an empty raw log. It uses warningAsError=true and linter.all=true. Both passing task source snapshots are byte-identical to the reviewed source and current repository file. The strict report also records the exact reviewed source SHA256.

The strict raw log has zero bytes and SHA256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855. The reports and logs were copied and their recorded byte counts and hashes checked. This review does not claim the separate aggregate Audit or public theorem checks have completed.

## Scope and remaining goal

This result closes the single actual parked-transition measure obligation. It shows exact model-independent consumption of one candidate while preserving the operational contract. A bound for a consecutive parked-only chain follows from this equation, but this module does not itself define or prove a chain theorem.

The result does not provide a global neutral rank for ordinary or opaque continuations. It does not bound all unproductive earlier alternatives, prove global sufficient recursive depth or establish full unfolding/public coverage. Recursive and PreparedRecursive remain distinct workers. Their complete end-to-end operational compositions and the Haskell correspondence objective remain active.

No Haskell source change, new Haskell defect or Haskell fix was established by this review. Parent retains responsibility for the main integration and required FINDINGS updates.

## Acquisition limits and pins

`source-scope.json` records requested and actual endpoints, complete source and saved-copy byte counts and hashes, and reuse origins. The owner read the whole new task source. It reused two current verified old producer cuts from Root's root-source-reads and three current verified dependency cuts from the frozen neutral-control bundle. It acquired zero whole OLD Lean sources, below the limit of two. The v1 and passing task snapshots are separately classified as whole task sources.

All source displays and exact cuts used for this review were untruncated. No EOF-clamped whole read was relabelled. Every reused old cut was checked against the current full-source identity and exact current source endpoints before use. Full source byte reads for hashing do not expose additional semantic source scopes.

`EVIDENCE.json` pins report and log origins. `VALIDATION.json` records the final measured validation time, source identity checks, exact header recovery, passing snapshot identities and evidence integrity. `pins.json` and `FROZEN.json` seal only this owner bundle. All prior bundles remain unchanged.
