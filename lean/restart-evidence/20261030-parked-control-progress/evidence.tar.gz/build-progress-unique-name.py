from pathlib import Path
import json
root=Path('/home/tritlo/Code/mcfta');area=Path('/tmp/mcfta-parked-control-progress-20261030');old=(root/'lean/MicroCFTA/SourcePruningEnumerationParkedRestart.lean').read_text()
addition=''' ∧
      before.expandable uv = true ∧
      (repeated = true →
        (∀ other, after.expandable other =
          if other = uv then false else before.expandable other) ∧
        (EnumerationIndexSelection.candidates after).length + 1 =
          (EnumerationIndexSelection.candidates before).length)'''
def header(name):
 start=old.index('theorem '+name+'\n');end=old.index(' := by',start);h=old[start:end];return h.replace('theorem '+name+'\n','theorem '+name+'_progress\n',1)+addition+' := by\n'
prefix='''import MicroCFTA.SourcePruningEnumerationParkedRestart
import MicroCFTA.EnumerationIndexSelection

/-!
# Exact candidate consumption at an actual parked restart

The original selected flag is true. The actual parked write disables that
flag and keeps every other flag. The allocation counter stays fixed.
The existing finite candidate count therefore decreases by exactly one.
Every original parked receipt and configured restart result remains.
-/
namespace MicroCFTA.SourcePruningEnumerationParkedRestart
open EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationCompressionFrame
open InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes SourcePruningEnumerationObservation
local notation "Symbol" => SourcePruningTemplates.Symbol
variable {EnumGuard NativeGuard : Type}

private theorem candidates_clear_count
    (before after : EnumerationExpandableIndex.Cached Symbol EnumGuard) (uv : Nat)
    (counter : after.core.counter = before.core.counter)
    (inside : uv < before.core.counter) (selected : before.expandable uv = true)
    (flags : ∀ other, after.expandable other =
      if other = uv then false else before.expandable other) :
    (EnumerationIndexSelection.candidates after).length + 1 =
      (EnumerationIndexSelection.candidates before).length := by
  have unique : (EnumerationIndexSelection.candidates before).Nodup :=
    List.nodup_range.filter _
  have present : uv ∈ EnumerationIndexSelection.candidates before := by
    exact List.mem_filter.mpr ⟨List.mem_range.mpr inside, selected⟩
  have removed : EnumerationIndexSelection.candidates after =
      (EnumerationIndexSelection.candidates before).erase uv := by
    rw [unique.erase_eq_filter]
    unfold EnumerationIndexSelection.candidates
    rw [counter, List.filter_filter]
    apply congrArg (fun predicate => (List.range before.core.counter).filter predicate)
    funext other
    rw [flags]
    by_cases same : other = uv <;> simp [same]
  rw [removed, List.length_erase_of_mem present]
  have positive := List.length_pos_of_mem present
  omega

/-- Original selection consumes one candidate on the actual parked branch without a model. -/
'''
body='''  obtain ⟨inside, selected, _unblocked⟩ :=
    SourcePruningEnumerationSelection.offered before preference uv selection
  obtain ⟨readFuel, handle, scs, value, readAfter, checkFuel, repeated, after, stored, decoded,
    available, closed, readExact, readFrame, checkExact, afterReady, afterPaths, afterRealized,
    afterCounts, afterFlags, incoming, pending, continued, orderPreserved, parked⟩ :=
    selected_complete_with_order heap before preference uv roots safe selection realized paths counts flags
  refine ⟨readFuel, handle, scs, value, readAfter, checkFuel, repeated, after, stored, decoded,
    available, closed, readExact, readFrame, checkExact, afterReady, afterPaths, afterRealized,
    afterCounts, afterFlags, incoming, pending, continued, orderPreserved, parked, selected, ?_⟩
  intro repeatedTrue
  obtain ⟨boundary, _cleared, _disabled, _waiting, resolved, countFuel, _frame, _readRoot,
    _seen, _written, indexed⟩ := parked repeatedTrue
  have actualFlags : ∀ other, after.expandable other =
      if other = uv then false else before.expandable other := by
    have observed := indexed 0
    simp only [Nat.add_zero, SourcePruningEnumerationNativeIndex.write,
      SourcePruningEnumerationNativeIndex.candidate, decoded, Option.map_some,
      boundary, List.isEmpty_nil, Bool.true_and, Bool.not_true, Option.bind_some,
      EnumerationExpandableIndex.frame] at observed
    cases counted : SourcePruningEnumerationNativeIndex.count countFuel resolved.representatives
        (-1) scs before.waiting with
    | none => simp only [counted, Option.bind_none] at observed
    | some waiting =>
        simp only [counted, Option.bind_some, SourcePruningEnumerationNativeIndex.count,
          Option.some.injEq] at observed
        intro other
        exact (congrArg (fun cache => cache.expandable other) observed).symm
  exact ⟨actualFlags, candidates_clear_count before after uv
    (orderPreserved repeatedTrue).1 inside selected actualFlags⟩

local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Metadata" => SourcePruningRecordTypes.Metadata
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
variable {Typing : Type} {width : Nat}

/-- The exact configured parked restart also consumes one candidate without a model. -/
'''
restart=old[old.index(' := by',old.index('theorem selected_complete_with_restart\n'))+len(' := by\n'):]
restart=restart[:restart.index('\n\nend ')]
restart=restart.replace('orderPreserved, parked⟩ :=','orderPreserved, parked, selected, progress⟩ :=',1).replace('    selected_complete_with_order caller.checked','    selected_complete_with_order_progress caller.checked',1).replace('afterReady.safe, pending, ?_⟩','afterReady.safe, pending, ?_, selected, progress⟩',1)
source=prefix+header('selected_complete_with_order')+body+header('selected_complete_with_restart')+restart+'\n\nend MicroCFTA.SourcePruningEnumerationParkedRestart\n';destination=root/'lean/MicroCFTA/SourcePruningEnumerationParkedActiveCount.lean'; assert not destination.exists(); destination.write_text(source)
(area/'leaf-v1.json').write_text(json.dumps([['lake','parked-v1-build','MicroCFTA.SourcePruningEnumerationParkedProgress'],['strict','parked-v1-strict','SourcePruningEnumerationParkedProgress']],indent=2)+'\n')
print('Generated',len(source.splitlines()),'lines; appended only the new flag/count conclusion to both old headers.')
