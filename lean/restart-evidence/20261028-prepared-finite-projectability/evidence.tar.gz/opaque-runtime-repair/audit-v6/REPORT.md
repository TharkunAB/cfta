[2026-10-28 22:02:37 CET] Source-only actual-runtime repair v6. UNTESTED.

Candidate: /tmp/mcfta-prepared-finite-projectability-20261028/opaque-runtime-repair/candidate-v6/MicroCFTA/SourcePruningEnumerationSelectedOpaqueProjectionHeap.lean
SHA256: f6bbc3c6980485e1920ac70bd137dcdf32f91cd0deb86ff80a1579abf780090c
Size: 6321 bytes; 116 lines.

The complete preamble and exported run_projection_heap declaration are
byte-identical to root-v5. Only the proof body changes.

Whole failed-raw diagnosis

The 19405-byte v5 raw contains nine proof errors. The second split at observed
splits the native value match inside the deferred guard. It does not split the
outer Bool conditional. The node branch still has an unresolved terminal Bool
conditional. The other branch still has false = true in that conditional.

The child row rcases rewrites the goal. It does not rewrite the independently
held observed hypothesis. The raw shows observed still contains the literal
ChildDispatch.run call after childRun has been obtained. Therefore rewriting
the goal by observed restores that unspecialized call. Finalizer simp cannot
find the actual finalizer call before that child observation is rewritten.

One bounded repair

The proof retains one actual run equality. It first uses explicit native value
constructors and the node terminal Bool. Each branch simplifies the ORIGINAL
run only at observed. Empty rejection and ordinary deferral finish directly.
All remaining constructor branches share one all_goals child proof.

A local let originalValue := value precedes the constructor cases. It supplies
one definitional name for the original actual incoming value in the shared
child call. It is not a new input, source/parent equation or future supplier.
The existing Available and closed proofs elaborate at that same value.

The shared child loop obtains the literal childRun equation, then explicitly
rw [childRun] at observed. This specializes the ORIGINAL runtime matcher.
There is no separately restated child matcher and no duplicate result property.
The installed child projection observer derives the reached native heap from
the original Packet/resource gates. Raw none, empty, errors, multiple rows and
absent child cache retain the actual outer successful caller. A named finished
equation rewrites the actual finalizer inside observed in the singleton/cache
branch. Finalization retains the same reached caller.

Contract and scope

No argument, premise, result arm or scope gate changes. The original stored
source remains separate from the prepared value. ProperState and future
endpoint Heap/model/completion assumptions are absent. This observer concerns
literal local native endpoints. It does not prove whole recursive completion,
termination, whole Discharged, language equivalence or a finite key universe.

Read scope and verification

The whole root-v5 source and its entire failed raw are preserved, as is the
whole installed child projection observer. The exact 30-47 cut preserves the
complete actual opaque run definition. Every input has a complete source SHA;
cut scopes are explicit. The original public declaration and proof-only diff
are preserved. Source identity and unchanged-export checks passed.

This author did not run Lean, Lake, native code, Git, network or board commands
and did not edit the repository. Root must build and run strict checks.
Earlier candidates, failed logs and reports remain unchanged. No previous
failed build or duplicate strict batch is presented as successful evidence.
