[2026-10-28 21:41:57 CET] Source-only candidate. UNTESTED.

The candidate adds one observer. It does not add a producer or change an existing source.

Candidate: /tmp/mcfta-prepared-finite-projectability-20261028/opaque-projection/candidate-v1/MicroCFTA/SourcePruningEnumerationSelectedOpaqueProjectionHeap.lean
SHA256: 974881001c981d0a16b5b1d1aa3a0a164f81b315e1baae1141591fa227f90216
Size: 5477 bytes; 98 lines.

Public interface

Import MicroCFTA.SourcePruningEnumerationSelectedOpaqueProjectionHeap.
Namespace MicroCFTA.SourcePruningEnumerationSelectedOpaqueDispatch.
Export run_projection_heap.
Explicit argument order: seed, packet, stored, available, closed, fits, reserved,
known, originalProjection, r, n, p, h, k. All other indices are implicit.
The complete declaration is preserved in signatures/run_projection_heap.txt.

Original gates

The input Packet is the existing whole Packet for the invocation's input caller,
full Memos, metadata and attached cache. The original selected slot stores its
originalHandle and suspended bucket scs. The independently supplied prepared
value is Available and closed in that same input caller. Fits seed.2, Reserved
bits seed (scs.length + 1), the original known-guard Heap and the input caller's
ProjectionHeap are explicit.

The proof derives bucket bounds from Packet.safe and the literal stored row.
It derives InputsPending from Packet.pending and that same row. It reads roots,
paths, realized and waiting counts from Packet.valid. Ready is unnecessary for
this observer. ProperState is unnecessary. There is no equality that identifies
the prepared value with the original handle's decoded source.

Exact result scope

The conclusion is an inline match on the literal actual SelectedOpaqueDispatch.run
at the given primitive bounds. A complete result and a rejected result retain
ProjectionHeap at that result's exact native caller. A stopped result with an
outer .ok observation retains ProjectionHeap at that observation's exact caller.
The raw Option inside that .ok and the attached optional cache are unrestricted.
All other results yield True. This includes none, unhandled and native outer
errors. The observer makes no existence claim for any result.

Actual proof route

The empty input branch returns rejected at the original caller. The ordinary
nonterminal branch returns none. The remaining branch splits the literal actual
ChildDispatch.run observation. For every outer .ok observation, the already
installed ChildDispatch.observed_resources_projection_heap derives projection
at the exact reached caller from the original gates. No raw success shape or
future cache is assumed by that point theorem.

The exact singleton .ok row with some attached child cache uses the actual
Finalize.run call. Its map constructs complete with that same reached caller.
If finalization returns none, the conclusion is True. Every other child row is
retained as the actual stopped observation. Native outer errors yield True.
This covers raw none, an empty raw list, raw errors, multiple raw rows and an
absent child cache whenever the outer observation is .ok.

Limits and next check

This is an uncompiled source-only draft. Root must build the module and run its
strict checks before claiming a proved export. This author did not run Lean,
Lake, native code, Git, network or board commands and did not edit the repository.

The observer proves native heap projection at literal local endpoints. It does
not prove a whole recursive return, completion, language equivalence, whole
Discharged, finite key universe, depth bound or termination. The prepared value
remains separate from the original stored source. No future endpoint Heap,
model or completion certificate is an input.

Read scope

The manifest preserves ten whole source files and three exact literal cuts.
Each record includes the live source's complete byte identity. Cut-only reads
are labeled as such. The public candidate declaration is preserved separately.
Failed guessed paths and searches with no matching finishedChild export are
recorded in the manifest. No source beyond the recorded ranges is claimed as
whole-read evidence.
