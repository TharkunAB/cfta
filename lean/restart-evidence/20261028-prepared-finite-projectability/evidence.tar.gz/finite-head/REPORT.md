# Projection through the actual prepared finite head

Time: 2026-10-28 21:44 CET.
Status: immutable candidate-v1. UNTESTED by this child.
Root owns dependency integration and compiler checks.

The additive candidate is
`MicroCFTA.SourcePruningEnumerationPreparedFiniteHeadProjectionHeap`.
Its public theorem is
`PreparedNativeHookResources.head_finite_complete_resources_projection_heap`.

The theorem keeps every original finite-head input in its original order.
Its smaller-depth recursive contract is `CompleteWithProjectionHeap`.
`originalProjection` at the original native caller is the final explicit input.
The stored source handle and the available closed prepared parent remain
separate. No source-to-parent decode equality is introduced.

The result keeps the same six witnesses: common work bound, native receipt,
native middle caller, saved queries, full middle Memos and middle Inventory.
It retains the exact native stable observation, Post, query equation,
admission, pending references, fragment history, cache bounds, advanced Fits
and guard membership. Unsupported receipts keep the original unsupported
branch. Handled receipts retain their same callback outcome, exact advance
observation and stable callback observation.

The handled outcome retains the unchanged original `OutcomeResources` and the
complete callback's captured sibling packet at its actual returned caller and
full memo state. Pure `OutcomeProjectionHeap outcome` is the final field of
that handled branch. Projection at the native middle caller is the final outer
field. These are distinct facts: a recursive callback can change its caller.

## Actual proof route

The original packet gives roots, realized storage, counts and flags. Existing
resource facts derive the child/guard widths, bounded edge cost and pending
inputs. The candidate calls the native prepared head resource adapter once.
That adapter retains all old native resource fields and appends projection at
its actual native middle caller.

The candidate retains the old cache-bound derivation, resource padding and
common native work bound. Projection does not depend on resource padding.
For a handled receipt, the installed receipt projection theorem consumes the
actual native middle heap. Existing head cache bounds supply the original
callback mass ceiling and reservation. Its result supplies pure projection for
the same actual callback outcome.

Only original `OutcomeResources` uses `.post headPost`. Pure projection passes
directly from the callback result. No pure `.post`, `.mono` or `.forget` method
is assumed or defined. The complete callback's sibling packet is extracted by
the existing `completed_captured_packet` theorem, with the original full Memos
and original enumeration cache. Existing arithmetic aligns native and callback
observations at one work bound.

A handled stopped-child receipt can emit an empty callback completion at the
native middle caller. It remains covered by the native middle projection and
the actual receipt theorem. An absent recursive stopped endpoint remains
absent; no caller is fabricated. No property of an arbitrary outer native-error
endpoint is claimed.

## Dependency boundary

The candidate imports the announced
`SourcePruningEnumerationNativePreparedProjectionHeap`. It calls
`NativeBranchCompletion.head_complete_resources_prepared_projection_heap`
with the exact old native producer arguments through `known`, followed by
`originalProjection`. The expected return is the exact old native tuple plus
reached projection last. At this report's freeze, the peer dependency is still
an announced interface. Its implementation is not included in the read ledger
and this report makes no compilation claim for it.

The installed receipt projection module and both new root contract modules
were read whole. Root reported default PASS for the earlier three callback
candidates at 21:42 CET. No compiler was run by this child. The final smaller
depth contract must still be discharged by root's complete finite induction.
This local theorem does not assert a future heap supplier or whole-driver
completion, semantic coverage, sufficient recursive depth or Haskell
correspondence.

## Evidence and freeze

The candidate was read back whole: 175 lines and 13,076 bytes. SHA256:
`82ae0314cd7f601b6489decd2377218c3bf5e94524faff9c1f55e41a97b5eb6e`.

A textual comparison removes only the new original projection input, pure
callback projection and final native middle projection. It replaces the
internal stronger recursive contract and removes the match parentheses needed
for the added conjunction. The resulting public statement is byte-for-byte
the original finite-head resource statement. This comparison passed.

Six complete installed source files are copied in `inputs-v1/`: 844 lines and
59,149 bytes. Their original paths, full scopes and SHA256 hashes are recorded
in `manifest-v1.json`. A short truncated native resource read was recovered by
a separate complete read. No read claim relies on truncated output.

No repository, frozen area or previous candidate was written. No compiler,
native evaluator, Git, network or board operation was run. No Haskell fix was
made or identified. Candidate, input copies and this report are frozen. A
repair requires a new version or a root-owned artifact.
