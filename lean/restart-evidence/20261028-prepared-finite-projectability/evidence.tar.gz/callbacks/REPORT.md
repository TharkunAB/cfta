# Prepared zero, callback and receipt projection candidates

Time: 2026-10-28 21:41 CET.
Status: immutable candidate-v1. UNTESTED by this child.
Root owns all repository integration and compiler checks.

Three additive modules provide the requested local finite projection steps.
They use the exact installed `OutcomeProjectionHeap` and
`CompleteWithProjectionHeap`. They leave `OutcomeResources` unchanged and keep
its full native resources separate from the pure projection observation.

## Interfaces and proof scope

`SourcePruningEnumerationPreparedZeroOutcomeProjectionHeap.lean` exports:

- `resume_zero_outcome_resources_projection_heap`.
- `zero_complete_with_projection_heap`.

The first theorem appends the original caller's `initialProjection` after all
old inputs. It returns one outcome, its exact stable zero-depth observation,
the original resources and `OutcomeProjectionHeap` for that same outcome.
The proof retains the old resource witnesses. The existing zero producer gives
caller equalities for completed results and outputs. Exhaustion gives an empty
output list and the exact original caller endpoint. These facts transfer the
original heap property. The second theorem closes the new zero-depth contract
with the same original gate order and the same original work bound.

`SourcePruningEnumerationPreparedFiniteCallbackProjectionHeap.lean` exports
`callback_finite_complete_resources_projection_heap`.

It retains every old callback input, four returned witnesses and output field.
The internal recursive input is `CompleteWithProjectionHeap` at smaller depth.
`initialProjection` is the final explicit argument. The return still includes
the original packet, render/frame evidence, metadata equations, exact
`recordTypes` Success and singleton observation, universal callback equation,
one common stable work bound and original `OutcomeResources`. It then appends
pure projection for the same outcome.

The callback keeps its caller during recording. The true record flag returns
`.complete [] caller memos.query`. Original resources use their existing
forecast padding; projection remains at that exact caller. The false flag
calls the supplied smaller-depth contract at the same caller and the actual
framed cache. The frame preserves the original suspended-mass bound. The
existing work-fuel addition aligns the actual callback with that recursive
result. Projection of the recursive return passes directly to the result.
No old/prepared `Failure` cast is used. The shared record theorem supplies only
the actual record observation and packet. The proof reconstructs the prepared
`continueWith` equation from that observation.

`SourcePruningEnumerationPreparedFiniteReceiptProjectionHeap.lean` exports
`receipt_finite_complete_resources_projection_heap`.

It retains all old receipt inputs, original packet, actual `Post`, `advance`
observation, admissibility, pending and fragment history, mass and reservation.
The internal contract changes to `CompleteWithProjectionHeap`.
`initialProjection` is the final explicit argument and concerns the receipt's
actual reached caller. The native head producer must derive that local fact
from its own original heap. This theorem does not derive it from arbitrary
`Post`, and does not introduce it into the final public driver contract.

A complete receipt identifies its actual caller and saved queries through the
literal `advance` result. Existing receipt evidence derives its actual callback
packet. The new callback theorem then supplies resources and projection for
the same callback outcome. Rejected or stopped handled receipts produce
`.complete [] reached final.query`. Their resource witnesses and projection
both refer to this actual native reached caller. An unhandled receipt cannot
satisfy the supplied `advance` observation.

## Preserved boundaries

`OutcomeProjectionHeap` has no hidden resource witness. A completed outcome
retains projection at its exact aggregate caller and every output caller.
A stopped outcome retains projection only when its actual endpoint is present.
The absent-endpoint branch remains `True`; no caller is inserted.

Only original `OutcomeResources` uses `.mono`. No `.forget`, `.post` or `.mono`
is added to pure projection. Projection passes directly across resource padding
and earlier Posts. Native growth alone is never used to derive a later heap.

The internal smaller-depth contract must be discharged by root's finite depth
induction. These three modules do not prove the whole induction, output
existence, semantic coverage, source-derived sufficient depth, rendering or
Haskell correspondence. No desired future heap or model supplier was added.

## Readback and verification

All three candidate source files were read back whole. A textual statement
comparison checked each main theorem against its original resource theorem.
After removing only the appended original projection input and same-result
projection conclusion, and replacing the internal recursive contract, each
public statement matches the original exactly. All three comparisons passed.

The read ledger contains eleven whole Lean files: 1,091 lines and 69,604 bytes.
The exact installed contracts, old zero resource producer, original and arity
callback/receipt proofs, original outcome resources and record callback theorem
are copied in `inputs-v1/`. Their paths and complete SHA256 hashes are recorded
in `manifest-v1.json`. A short truncation in a batched callback read was
recovered by a separate complete read. No scope claim relies on truncated text.

Candidate hashes:

- Zero: `719426cba80cf1aa129eabfe38be29c3451ec3c10b06860ce8e91534ba3d073e`.
- Callback: `72932dd61cad7a4ff5f0b4ec1165c0a9cd4ad4100355d83167ffba0fecce2165`.
- Receipt: `8c6f6385f24a26c3b0d7a6250b9cee63256c9a96f2551e0e7e2bcf45070bdd56`.

No compiler, native evaluator, Git, network or board action was run. No
repository or frozen checkpoint was written. No Haskell change or fix was
identified. All candidates and this report are frozen. Any repair requires a
new version directory or a root-owned artifact.
