import MicroCFTA.SourcePruningEnumerationPrefixResources
import MicroCFTA.SourcePruningEnumerationAction
import MicroCFTA.SourceEqualityAnnotationExposure

/-!
# Projection at the actual selected-prefix caller

Original realized storage supplies the available closed value read by narrowing.
The actual cold reader retains every physical edge annotation.
Filtering retains complete rows and adds no edge key.
-/
namespace MicroCFTA.SourcePruningEnumerationSelectedStep
open EnumerationState EnumerationCorrectness EnumerationSchedule InternedConstructorTemplates
open InternedProbeProvenance SourcePruningEnumerationNodes SourcePruningEnumerationObservation
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Context)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Metadata" => SourcePruningRecordTypes.Metadata
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "projectable" =>
  (fun constraint : Constraint => SourcePruningEnumerationConstraint.project constraint ≠ none)
local notation "ProjectionHeap" => SourceEqualityAnnotationHeap.Heap projectable
variable {Typing Key : Type} {width : Nat}
variable [DecidableEq (EdgeKey Symbol Constraint)]

private theorem narrowAt_projection_heap
    (fits : Key → Symbol → Bool) (admits : Key → Node → Bool) (key : Key)
    (fuel : Nat) (value : Node) (before : State Symbol Constraint)
    (ready : SourceEqualityRequiredCache.Ready before)
    (heap : ProjectionHeap before) (available : Available before value) (closed : value.free = []) :
    ProjectionHeap (SourcePruningNativeView.narrowAt fits admits fuel key value before).state := by
  have retained := SourceEqualityAnnotationExposure.nodeEdges_heap projectable fuel value before
    ready.semantic ready.covered heap available closed
  cases actual : MergedFreshOrdinaryExposure.nodeEdges fuel value before with
  | done rows middle =>
      have middleHeap : ProjectionHeap middle := by
        simpa only [actual, MergedSourceExposure.Result.state] using retained
      simpa only [SourcePruningNativeView.narrowAt, actual, MergedSourceComparison.Result.state] using
        SourceEqualityAnnotationHeap.run projectable
          (makeNode (rows.filter (SourcePruningNativeView.keeps fits admits key)))
          (SourceEqualityAnnotationHeap.makeNode projectable
            (rows.filter (SourcePruningNativeView.keeps fits admits key))) middle middleHeap
  | unresolved name after | pending pendingKey after | exhausted after =>
      simpa only [SourcePruningNativeView.narrowAt, actual, MergedSourceExposure.Result.state,
        MergedSourceComparison.Result.state] using retained

private theorem outer_narrow_projection_heap
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool)
    (admits : Key → Node → Bool) (metadata : Metadata Typing)
    (fuel uv : Nat) (value : Node) (before : State Symbol Constraint)
    (ready : SourceEqualityRequiredCache.Ready before)
    (heap : ProjectionHeap before) (available : Available before value) (closed : value.free = []) :
    ProjectionHeap (SourcePruningOuterNarrow.narrow holeKey fits admits metadata fuel uv value before).state := by
  cases value with
  | mu => exact heap
  | empty | reference | node | union =>
      by_cases typed : uv ∈ metadata.types
      · simpa [SourcePruningOuterNarrow.narrow, typed, MergedSourceComparison.Result.state] using heap
      · simpa [SourcePruningOuterNarrow.narrow, typed, MergedSourceComparison.Result.state] using
          narrowAt_projection_heap fits admits (holeKey metadata.typing uv) fuel _ before
            ready heap available closed

variable [DecidableEq Symbol] [DecidableEq Node]

private theorem finish_retains_projection_caller
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (r n p h k uv : Nat) (observed : Result width Typing) :
    match observed with
    | .stopped _ _ | .parked _ _ _ => finish checkEmpty edgesOf r n p h k uv observed = observed
    | .narrowed checked prepared reached queries action candidate right _ =>
        ∃ ordinary, finish checkEmpty edgesOf r n p h k uv observed =
          .narrowed checked prepared reached queries action candidate right ordinary := by
  cases observed with
  | stopped _ _ => rfl
  | parked _ _ _ => rfl
  | narrowed checked prepared reached queries action candidate right ordinary =>
      dsimp only
      unfold finish
      split <;> simp_all only [Result.narrowed.injEq] <;> subst_vars <;>
        simp only [true_and] <;> exact ⟨_, rfl⟩

/-- The original prefix inputs derive projection at the actual narrowed caller. -/
theorem prefix_projection_heap
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (fuel uv : Nat) (caller : Caller width) (before : Cached) (memos : Memos)
    (initial : Context formulas solver inventory caller memos)
    (realized : PendingRealized caller.checked.native.machine.heap before.core)
    (heap : ProjectionHeap caller.checked.native.machine.heap)
    (observed : Result width Typing)
    (valid : PrefixValid holeKey fits admits graph templates checkEmpty edgesOf stop order metadata
      formulas solver inventory fuel uv caller before memos observed) :
    match observed with
    | .narrowed _ _ reached _ _ _ _ _ => ProjectionHeap reached.checked.native.machine.heap
    | _ => ProjectionHeap caller.checked.native.machine.heap := by
  have full := valid.2.1
  cases observed with
  | stopped _ _ | parked _ _ _ => exact heap
  | narrowed checked prepared reached queries action candidate right ordinary =>
      obtain ⟨_next, finished⟩ := finish_retains_projection_caller checkEmpty edgesOf 0 0 0 0 0 uv
        (.narrowed checked prepared reached queries action candidate right ordinary)
      rw [finished] at full
      obtain ⟨oldHandle, scs, readAfter, reading, _checking, oldValue, value, nextHeap,
        _selectedAction, _final, decoded, narrowed, _prepared, _samePrepared, reachedAt,
        _queries, _post, _saved, _shape⟩ := full
      have readSuccess : Success (getValue fuel uv) before.core
          (.unenumerated (some oldHandle) scs) readAfter := by
        rw [Success, reading]
        exact List.mem_singleton_self _
      obtain ⟨found, _lookup, stored, _readState⟩ :=
        (getValue_success fuel uv before.core readAfter (.unenumerated (some oldHandle) scs)).mp readSuccess
      obtain ⟨old, oldLookup, available, closed⟩ := realized found.representative oldHandle scs stored
      have same : old = oldValue := Option.some.inj (oldLookup.symm.trans decoded)
      subst old
      have retained := outer_narrow_projection_heap
        holeKey fits admits metadata fuel uv oldValue caller.checked.native.machine.heap
        initial.ready.semantic.ready heap available closed
      rw [narrowed] at retained
      change ProjectionHeap reached.checked.native.machine.heap
      rw [reachedAt]
      exact retained

end MicroCFTA.SourcePruningEnumerationSelectedStep
