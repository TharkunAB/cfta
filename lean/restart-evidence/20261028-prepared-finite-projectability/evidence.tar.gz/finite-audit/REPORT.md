# Prepared finite projection route audit

Time: 2026-10-28 21:33 CET.
Status: source-only audit. The whole finite projection result is not proved.
No compiler or repository action was run by this child.

The checked finite arity induction supplies the correct control-flow pattern.
The projection extension must retain both the actual aggregate caller and each
output caller. A completed-head fact alone does not cover recursive returns or
handled stopped-child receipts. No new callback-entry wrapper is needed.

## Existing public contracts

`PreparedFiniteContract.Complete` quantifies the original inventory, caller,
full Memos, cache, metadata, seed and mass ceiling. Its original premises are:

- The original `Packet`.
- `Fits seed.2 caller.checked`.
- Physical guard membership in `seed.1`.
- Global `selectionMembers` and `selectionLength` policies for `edgesOf`.
- The initial suspended-mass bound.
- `PreparedReservation.Reserved bits recursiveFuel seed ceiling`.

It returns one `bound` and actual prepared `outcome`. Every larger common work
fuel returns that same outcome. `OutcomeResources` retains its original resource
certificate at the original finite forecast.

`PreparedOutcomeResources.OutcomeResources` uses the actual prepared `Failure`.
It has one aggregate witness `reached`, inventory and full final Memos, with
`Post`, `Fits` and guard membership. Completed results identify their caller and
queries with this witness. Stopped results retain either an absent endpoint or
that same endpoint. Each output has its own complete original `OutputResources`.

The projection target must preserve these data and append projection at that
same aggregate witness and every output caller. Its added input belongs to the
original caller. No future heap, child support, model or step supplier is needed
as a public premise. Internal smaller-depth hypotheses must be discharged by
the final natural-number induction.

`PreparedOutcomeResourcesArity.OutcomeResourcesWithArity` already has this exact
aggregate/output layout for arity. Its `forget`, `post` and `mono` proofs show how
to retain the old witnesses. Here, `post` changes the original endpoint of the
resource relation; it retains an already-derived reached heap property. It does
not derive that property from arbitrary forward native growth.

`PreparedFiniteArityContract.CompleteWithArity` appends original caller arity to
the original input premises and returns old resources plus stronger resources
for the same outcome. `PreparedFiniteResourcesArity.finite_complete_with_arity`
discharges its smaller-depth hypothesis. These concrete declarations cannot be
used by renaming the predicate: `ArityOrigins.Fits` is conditional on a
successful projection. It does not assert that projection succeeds. Projection
must remain a separate invariant. The projection route does not need a new
original arity premise merely to copy this proof pattern.

## Already closed original-input boundaries

The prefix boundary is already generic. `SelectedStep.prefix_resources` in
`SourcePruningEnumerationPrefixResources.lean` takes an arbitrary
`property : Constraint → Prop`. Instantiate that property with:

```lean
fun constraint => SourcePruningEnumerationConstraint.project constraint ≠ none
```

Pass the original `ProjectionHeap` as `known` and the already-required original
`Fits` as `bounded`. The result's second component gives projection at the exact
narrowed caller. Other result shapes retain the original caller. The existing
`PrefixValid` certificate is supplied by the actual prefix producer from the
original context, safe storage, pending references and cache validity. No future
projection certificate is added.

Actual selected preparation also has
`SelectedPreparation.run_projectable_heap` and `complete_projectable_heap`.
They derive the prepared physical heap from the original local caller heap and
the literal preparation result. The prepared caller's physical heap is that
same returned heap.

The new checked `CapturedEdge.run_prepared_projection_heap` covers literal
completed returns and stopped outer `.ok` returns. It uses the original stored
slot and the separately available closed prepared parent. The distinct prepared
`CompletedHeadReceipt.projection_heap` gives its supplied completed head's exact
reached heap. No source-to-prepared decode equality or receipt cast is used.

Original checked source construction supplies an initial physical projection
heap through `ProjectionHeap.constructed_projectable`. Bare `Packet` is not
used as a replacement for that original source condition.

## Minimum actual finite induction route

1. **Zero and terminal decisions.** Follow
   `PreparedZeroOutcomeResourcesArity.resume_zero_outcome_resources_arity` and
   `zero_complete_with_arity`. Stop, done, stuck and exhausted decisions retain
   the original caller. Their existing caller equalities transfer projection to
   the aggregate and each emitted output. Preserve an absent endpoint as absent.

2. **Positive selected prefix.** Follow
   `PreparedFiniteExpansionResourcesArity.selected_finite_complete_resources_arity`.
   Use the existing generic `prefix_resources` for both Empty rejection and
   accepted narrowing. The rejected result may have no outputs but has an
   advanced native caller. Projection is required there. The parked route uses
   `PreparedFiniteParkedResourcesArity`: caller and full Memos are unchanged,
   and the smaller-depth induction handles the next actual restart.

3. **Preparation.** At the accepted narrowed caller, use the existing literal
   preparation projection fact. Retain the actual preparation packet, source
   lookup, available closed result, stable run and resource witnesses. Follow
   `PreparedOrdinaryResourcesArity.complete_resources_arity` for the case split.
   An ordinary prepared parent is distinct from the original stored source.

4. **Every ordinary native head shape.** Follow
   `NativePreparedResourcesArity.head_complete_resources_prepared_arity`.
   Unsupported and arity-rejected branches retain the original caller. Supported
   producer shapes are complete or stopped outer `.ok`; apply the new prepared
   captured observer at the producer's actual run. Keep projection at the same
   produced native caller. A completed-head-only theorem is insufficient here.

5. **Opaque and terminal native heads.** Follow
   `PreparedOpaqueResourcesArity.opaque_complete_resources_arity`.
   The empty branch keeps the original caller. Other branches already extract
   an actual `ChildDispatch.run` with outer `.ok`, its exact reached caller and
   full resource packet. The checked child projection observer supplies that
   reached heap. Finalization changes the enumeration cache and keeps the
   native caller. A projection attachment to this producer is still needed;
   `SelectedOpaqueArity.complete_heap` alone only covers literal completions.

6. **Receipt and callback.** Follow
   `PreparedFiniteReceiptResourcesArity.receipt_finite_complete_resources_arity`
   and `PreparedFiniteCallbackResourcesArity.callback_finite_complete_resources_arity`.
   The actual receipt supplies its callback packet and original mass/reservation
   data. Recording keeps the native caller and full Memos. A true record returns
   an empty completion at that caller. A false record invokes the smaller-depth
   induction at the same caller and its actual updated metadata/framed cache.
   The recursive result must carry projection at its aggregate returned caller
   and each output caller. Keep the existing common-fuel alignment.

7. **Finite head plus recursive callback.** Follow
   `PreparedFiniteHeadResourcesArity.head_finite_complete_resources_arity`.
   Retain two different facts: projection at the native receipt caller and
   projection at the callback's aggregate returned caller. Compose the original
   Post and preserve the same full Memos and Inventory. These callers may differ.
   `PreparedOpaqueFiniteResourcesArity` needs the same actual receipt/callback
   composition for its opaque or terminal head.

8. **Ordered siblings.** Follow
   `PreparedFiniteSiblingResourcesArity.alternatives_finite_complete_resources_arity`.
   In its completed callback branch, extract projection at `hookCaller` from the
   aggregate witness and its caller equality. This works when `headOutputs=[]`.
   Pass that heap, the actual captured packet and full hook Memos into the suffix
   induction. Transport the original prepared parent's availability with the
   actual hook Post, as the existing proof already does. Retain original global
   selection policies and reservations.

   A stopped-child native receipt can be handled by `advance`. Its receipt
   callback returns `.complete []` at the native reached caller and the next
   sibling still executes. Projection at this changed native caller is required
   even though no fragment output exists. This is why the captured observer's
   stopped outer `.ok` case is essential. A genuinely stopped recursive callback
   does not execute the suffix; retain its actual aggregate/output facts and
   its exact optional endpoint.

9. **Finish, expansion and depth closure.** Follow
   `PreparedFiniteSiblingFinishResourcesArity`, the ordinary and opaque finite
   adapters, `PreparedFiniteExpansionResourcesArity`,
   `PreparedFiniteRunStepArity`, then `PreparedFiniteResourcesArity`.
   Keep one actual outcome, all original witnesses and the existing resource
   padding. Apply the stronger invariant at smaller recursive depth and at the
   actual suffix endpoint. The final depth induction must leave only the
   original inputs and original projection premise in the public result.

This is an implementation route, not an additional proved finite theorem. The
existing arity control flow can be reused. Its concrete heap predicates do not
directly provide the projection result. No new future assumption is justified
by the missing proof.

## Withdrawn local candidate and scope limits

One 132-line candidate was drafted before the generic prefix resource interface
was read whole. It drops `Fits` from a standalone prefix observation, but the
finite producer already has `Fits`. It is therefore unnecessary for this task.
It remains immutable, UNTESTED and withdrawn from the integration recommendation:

`candidate-v1/MicroCFTA/SourcePruningEnumerationPrefixProjectionHeap.lean`,
7,796 bytes, SHA256
`136d29d0547bf039487e1eea952b7f6199341ac86a2bb2c2546244410c83f951`.

Root confirmed that it was neither installed nor compiled. No second candidate,
new producer family, giant tuple clone or definition-only substitute was added.
The useful audit correction is the existing generic `prefix_resources`
instantiation. The genuine missing result is the full finite aggregate/output
projection induction described above.

Thirty-five source files were read whole and copied: 5,060 lines and 336,011
bytes. `manifest-v1.json` binds every source path, byte count and SHA256. Batched
truncations were recovered by complete rereads. The sibling induction was also
read back whole from its copied input. No whole-read claim relies on a truncated
output. The three generic secondary/parent projection modules were exploratory
reads; they are not a new prefix dependency.

The candidate and copied input hashes were checked without Lean execution. No
repository, earlier checkpoint or frozen child area was written. No compiler,
native evaluator, Git, network or board command was run. No Haskell fix was made
or identified. Root reported published checkpoint
`0671beaec62212cff61bbeaec0112ff2cc7c68e0`; this child did not verify Git state.

General semantic coverage, a source-derived sufficient recursive depth and
Haskell correspondence remain open. The audit and all its artifacts are now
frozen. Root retains the active full goal and owns the next proof work.
