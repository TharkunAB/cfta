[2026-10-28 21:46:31 CET] Source-only finite prepared opaque projection adapter. UNTESTED.

Candidate: /tmp/mcfta-prepared-finite-projectability-20261028/opaque-finite/candidate-v1/MicroCFTA/SourcePruningEnumerationPreparedOpaqueFiniteProjectionHeap.lean
SHA256: 15d9c2dd0c0fca186e05ee65dfba645ecb5a013658e0e7f424b2aebdb90888a3
Size: 16131 bytes; 238 lines.

Interface and exact retained contract

Import MicroCFTA.SourcePruningEnumerationPreparedOpaqueFiniteProjectionHeap.
Export PreparedNativeHookResources.opaque_finite_complete_resources_projection_heap.
The old opaque_finite_complete_resources argument order remains intact.
The recursive argument becomes CompleteWithProjectionHeap at its old position.
The input caller's initialProjection is the last argument, after HeadReserved.
The return preserves every old existential witness and every old field, in the
same order. It appends OutcomeProjectionHeap (finish target folded).

Mechanical declaration comparison passed. After the two input changes above,
the old original input gate block matches exactly, modulo whitespace. The entire
old returned field block matches exactly before the appended pure projection.
Both complete declarations and a source diff are preserved.

Actual producer route

The adapter calls old opaque_complete_resources exactly once. It does not call
an arity producer, the old full finite producer or an extra opaque adapter.
The old head producer fixes the exact receipt, reached caller, query, full memos,
inventory, Post, admitted/pending/history certificates, resource bounds and shape.

The adapter applies SelectedOpaqueDispatch.run_projection_heap at headBound in
all five primitive coordinates. It rewrites using the same headRun 0. The
existing complete and stopped outer .ok shape witnesses identify middleCaller.
In the rejected shape, the actual advance equality identifies the unchanged
original caller with middleCaller. No later endpoint Heap is supplied.

The exact same old reservation pays scs.length + 1 and the old padding pays the
callback. The actual complete shape supplies its original mass ceiling. The
installed receipt_finite_complete_resources_projection_heap consumes the
derived middleProjection and the smaller-depth CompleteWithProjectionHeap.
The old resource certificate composes through resources.post headPost.
The pure OutcomeProjectionHeap does not use Post, mono or forget.

The original callback bound alignment and literal ReceiptContinuation.run
alignment remain intact. finish retains the callback's exact output list and
native endpoint. The appended projection applies to that same finished result.
It covers the actual aggregate caller even if the callback emits no outputs;
each emitted output retains its own native caller projection. A stopped outcome
with no endpoint adds no aggregate caller claim.

Original gates and limits

The whole original Packet/full Memos and literal stored source row remain.
The prepared value has its own Available/closed premises. No equation identifies
that prepared value with the source handle's decoded node. Ready, IncomingAvoid,
dispatch, Fits, known guards, both original global selection gates, original
mass/inherited bounds and HeadReserved all remain unchanged.

This is an internal finite induction adapter. Its smaller-depth contract is
explicit; root must discharge it in the finite overlay. There is no future
Heap, model, endpoint supplier, ProperState, language-equivalence premise or
termination certificate. There is no global finite-key or whole unbounded
completion claim.

Verification and read scope

This author did not run Lean, Lake, native code, Git, network or board commands
and did not edit the repository. Root must compile and run strict checks.

Nine whole source files and two exact literal cuts are preserved with complete
live-source hashes. The current installed SelectedOpaqueProjectionHeap was
read after root's explicit guard-case repair; its public interface is unchanged.
The original finite resource source has 206 lines and its arity variant has
210 lines at the audited identities. This adapter adds 32 lines while retaining
all original fields. No child/finalizer semantic producer is duplicated.
