# Prepared finite projection closure candidates

Time: 2026-10-28 21:52 CET.
Status: three immutable candidate-v1 modules. UNTESTED by this child.
Root owns dependency integration and compiler verification.

The candidates adapt the existing parked, positive-step and finite-depth
resource proofs. They add no definition and keep all original finite input
gates, global selection policies, mass bounds and reservation parameters.
Original `OutcomeResources` remains separate from pure `OutcomeProjectionHeap`.

## Declarations and control flow

`SourcePruningEnumerationPreparedFiniteParkedProjectionHeap` exports
`parked_finite_complete_resources_projection_heap`.

The original stable parked prefix supplies its checked packet and retained
suspended-mass bound. Parking keeps the native caller and full Memos. A stuck
restart returns `.complete []` at that caller. Its old resources receive the
existing forecast padding; projection follows from the original caller heap.
Other parked restarts invoke the smaller-depth contract at the same caller,
the actual checked cache and the original derived parked seed and mass bound.
Only old resources use `.mono`. Pure projection for the same actual returned
outcome passes directly to the conclusion. Existing literal parked execution
and common work-fuel arithmetic identify the runtime result.

`SourcePruningEnumerationPreparedFiniteRunStepProjectionHeap` exports
`run_finite_succ_complete_resources_projection_heap`.

For an expansion decision, it consumes the actual selected Expansion producer
with the same original gates and the final original projection input. The
actual `run` and `resume` observations agree through that literal decision.
For stop, done and stuck decisions, it uses the installed zero-depth observer.
The existing decision split excludes expansion from this second branch.
Resource padding changes only the old resource certificate. Pure projection
remains a fact about the same exact result.

`SourcePruningEnumerationPreparedFiniteProjectionHeap` exports:

- `finite_complete_with_projection_heap`.
- `run_finite_complete_resources_with_projection_heap`.

The first theorem proves `CompleteWithProjectionHeap` by natural-number
induction on the supplied recursive capacity. The installed zero theorem
handles the base. The positive-step theorem consumes the actual induction
hypothesis at smaller depth. The second theorem applies this proved contract
to the original inventory, caller, full Memos, cache, metadata, seed, ceiling,
packet, Fits, guard membership, global selection policies, initial suspended
mass and reservation. Original caller projection is its final explicit input.

Its result has one work bound and one actual outcome. Every larger common
work fuel returns that same outcome at the supplied recursive capacity. The
outcome retains the original complete resource certificate at the unchanged
finite forecast. Pure projection holds at its actual aggregate caller when
an endpoint is present, and at every emitted output's own caller.

No internal recursive completion hypothesis remains in the final public
theorem. No future caller heap, future step, model or output supplier is an
input. A stopped result with no endpoint retains the pure predicate's `True`
branch. No caller or output is inserted.

## Dependency and claim limits

The run-step module imports root's announced
`SourcePruningEnumerationPreparedFiniteExpansionProjectionHeap` and calls
`selected_finite_complete_resources_projection_heap`. Its expected inputs are
the exact original selected Expansion gates plus original caller projection
last. Its result is the same stable outcome, old resources and pure projection.
The Expansion body was not part of this read scope. This report makes no claim
that the pending dependency or these candidates have compiled.

The installed zero observer and exact new root contract were read whole.
Root reported their default and strict PASS. This child did not execute Lean.
No pure `.post`, `.mono` or `.forget` is assumed or defined. Arbitrary native
growth is never used to infer projection at a later caller.

The result concerns each supplied finite capacity and original reservation.
It does not supply a depth sufficient for acceptance or output. It does not
prove semantic coverage, rendering, arbitrary native-error endpoint projection
or Haskell correspondence.

## Evidence and freeze

All three candidate files were read back whole: 255 lines and 18,676 bytes.
The explicit original public signatures account for most of their size.
The proof structure remains the existing three bounded local patterns.

- Parked: 113 lines, SHA256
  `7abe66e80159c520f0a12312dfb1a7de46eec0b770a4a66c076bb71350ae1ec4`.
- Run-step: 72 lines, SHA256
  `019fcf8bbdcae9d84ba21d79fc620cde25cd620145225c6dd345d55d2c52947c`.
- Finite closure: 70 lines, SHA256
  `7f748929f26c06b21cba987fed3774b251155b830a2fb2f7d8539aa6e3eb18e3`.

Nine whole installed source files were copied: 758 lines and 50,333 bytes.
The original and arity parked, run-step and finite modules, exact new contract,
zero observer and pure outcome definition are in `inputs-v1/`. Complete hashes
and source paths are in `manifest-v1.json`. No source read was truncated.

Four complete public statements were compared with the original resource
statements. Removing only the original projection input and pure projection
conclusion, and replacing the internal stronger contract, gives exact matches.
All four comparisons passed. The first metadata script matched `bits := bits`
as a proof separator. The corrected parser requires the separator's newline.
This repair changed no candidate or source byte.

No compiler, native evaluator, Git, network or board action was run. No
repository, earlier candidate or frozen area was written. No Haskell fix was
made or identified. All candidate files, copied sources and this report are
frozen. A repair requires a new version or a root-owned artifact.
