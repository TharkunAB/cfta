[2026-10-28 21:50:31 CET] Source-only observer repair v3. UNTESTED.

Candidate: /tmp/mcfta-prepared-finite-projectability-20261028/opaque-repair/candidate-v3/MicroCFTA/SourcePruningEnumerationSelectedOpaqueProjectionHeap.lean
SHA256: aad2979121fcadeacae4f458a9f2a11aec9de780f6587a70e69d4b822252610c
Size: 6548 bytes; 113 lines.

The whole exported declaration and preamble are byte-identical to root v2.
Only the theorem proof changes. The retained contract has no new premise,
future heap, model, completion or source/prepared parent equation.

Diagnosis from the whole failed raw

The 22509-byte raw contains nine proof errors. All nine goal states retain
the actual deferred native-value guard inside the returned-result property.
The independently elaborated deferred match in the by_cases premise does not
rewrite the runtime matcher. The positive deferred branch therefore does not
reach True. All child branches retain that same unresolved conditional.

The raw also marks childRun and finished as unused simp arguments at the two
plain simp calls and the finalizer none branch. The dependent rcases/cases
already rewrites those actual observations in the goal. These facts support
a proof structure with direct result extraction after each actual row case.

Repair

The v3 proof first establishes a local property of ONLY the literal child and
finalizer match. It excludes both native-value guards from that local goal.
The actual outer .ok child call obtains reachedProjection through the existing
observed_resources_projection_heap theorem under the original input gates.
The dependent row cases use exact reachedProjection. Native outer errors and
an absent finalizer result use True. No childRun or finished simp argument is
needed. The finalizer still uses the same reached caller as the actual child.

The outer proof then splits the actual native value constructor. Empty reduces
to rejection at the original caller. Reference, Mu and Union use the local child
property. A node splits the exact terminal Bool: false reduces the actual run
to none; true reduces it to that same child match. This uses the existing
explicit-constructor pattern from complete_heap and avoids independently
elaborated value-match equalities.

Verification and limits

The original preamble and exported statement match byte-for-byte. The candidate
contains no sorry, admit, custom axiom, native_decide or option change. This is
source-text verification. This author did not run Lean, Lake, native code, Git,
network or board commands and did not edit the repository. Root must build and
run strict checks. No check result is inferred from a previous failed batch.

The complete root-v2 source and complete failed raw are copied with exact hashes.
The public declaration and proof-only diff are preserved. Earlier candidate
and audit areas remain unchanged. This repair adds no producer or global claim.
