# Captured-edge native Stored proof handoff

2026-10-31 01:49 CET. SOURCE-ONLY. The candidate is UNCOMPILED.
This owner is next-phase evidence outside Root's final R11 production scope.

## Deliverable

NativeStoredCapturedEdge-v1-UNCOMPILED.lean contains one public theorem,
captured_edge_native_stored. Its header is copied exactly from the second
frozen inventory target. EXACT-PUBLIC-HEADER.md retains the same header.
A text comparison confirmed exact agreement with that frozen header.
Root must check the candidate. The child does not claim that it elaborates.

The theorem directly inspects the actual CapturedEdge.run result. Rejected,
stopped, and complete receipts certify their exposed caller. None and
unhandled return True. True proves no native property of hidden mutations,
unexposed endpoints, or discarded finalizer states.

## Existing current admission

The header retains the existing current NativeBranchResources head admission:
Context, EnumerationDriver.Ready at the selected slot, exact original
unenumerated-slot lookup, exact decoded-parent heap lookup, PendingRealized,
selected edge membership, Roots, correct waiting counts, exact current cache
candidate flags, InputsPending, Fits, current conditional edgeCost reservation,
known annotation heap, and separate entry native Stored. Actual r/n/p/h/k
are arbitrary. The header adds no future completion, Trace, Ranges, Ready,
parent availability, closedness, output certificate, or transition supplier.

## Actual derivation

1. PendingRealized applied to the exact original slot lookup gives the actual
   available closed value and its heap lookup. Equality with the actual
   decoded-parent lookup identifies that value with the selected parent node.
   This derives parent availability and free=[] inside the proof.
2. EnumerationDriver.Ready supplies Safe. Its stored-value bound derives
   the current bounded suspended inputs from the exact original slot lookup.
3. The proof splits the actual current arity test. Rejected arity uses the
   existing actual arity_rejected equality. It returns the original caller,
   so entry native Stored supplies the exposed result property.
4. For accepted arity, the proof splits the actual current constraint
   projection. Unsupported projection uses the existing actual unsupported
   equality. Its unhandled observation proves only True.
5. A successful current projection determines actual tries and residual.
   Unfolding current edgeCost derives its equality with the exact selected
   child cost. The existing conditional reservation therefore supplies the
   selected-edge reservation. No future numeric fact is requested.
6. The checked SelectedEdge law applies to these derived current facts and
   the original current resource gates. The proof inspects the actual
   SelectedEdge result. Rejected/stopped callers are retained literally.
7. On actual SelectedEdge completion, the proof inspects actual Finalize.run.
   A successful finalizer maps only the returned cache and retains the exact
   reached caller. The exposed complete result therefore uses the checked
   SelectedEdge certificate. Finalizer none proves only True.

No canonical future completed execution or supplied actual-subcall equation
is needed. The observations are obtained by cases on the actual expressions.

## No hidden endpoint claim

CapturedEdge.none can occur after an actual selected edge completed and its
cache finalization failed. The actual wrapper discards that reached caller.
The theorem does not expose it, introduce a carrier, or certify it through
True. It does not establish native-state rollback. The preceding inventory's
NONE-BOUNDARY.md is retained unchanged as exact provenance.
No NativeBranches or whole-parent-worker law is drafted in this task.

## Checked dependency

The exact installed SourceCurrentAllocatedNativeStoredSelectedEdge.lean is
retained as an explicit checked NEW reuse, 88 lines, SHA256
716d4f08f64e0ee7fb5bcf58f51454bcca63e91b3831ecf13c90d4db9d6bd1d2.
Root reports its exact 89-line owner draft passed the first strict probe
unchanged. Installation removes only the status line. Installed default and
strict checks passed. The child did not execute a checker.

## Source scope and provenance

No OLD whole or near-whole source was acquired. The six OLD source records
are bounded named cuts. Their cumulative unions are SelectedEdge 107/319,
CapturedEdge 9/258, NativeBranchResources 112/419, and CapturedEdgeResources 70/258.
Five cuts are exact frozen reuses. The only new OLD cut is SelectedEdge lines 94-107,
which contains the actual arity_rejected and unsupported theorem headers.
The seventh source record is the explicit checked NEW SelectedEdge (88 lines) reuse.
Both permitted OLD whole slots remain unused.

Every frozen source-copy pin and current full-source pin matched.
acquisitions.json retains all source paths, full SHA, line/byte counts, exact
acquired ranges, retained-copy pins, and classifications.
CUMULATIVE-SOURCE-UNIONS.json retains the exact cumulative line unions.
metadata-reuses.json retains four exact prior inventory/provenance copies.
The prior owner manifest is
34b13577641ed12eb03d197b4d9060c6d13360e09b2c25a7a8ca39ee67ea11c8.
Old inventory status notices remain unchanged as historical evidence.
Root's newer exact checked dependency confirmation supersedes those notices.
No prior frozen owner or production file changed.

## Validation and remaining boundary

The child checked source and retained-copy pins, repeated-source consistency,
exact header text, and bounded acquisition unions. No command failure,
missing file, source drift, or output truncation occurred. No compiler,
evaluator, native execution, Git, network, board, or production mutation ran.

This candidate concerns only exposed captured-edge observations under current
entry gates. It does not prove preservation of hidden states, admission from
an original public request, sufficient original depth/capacity, whole-worker
enumeration, finite global coverage, or Haskell correspondence. Native Stored
remains separate from merge.Context Stored. No Haskell execution, defect, or
fix was established. No Haskell FINDINGS entry is added.
