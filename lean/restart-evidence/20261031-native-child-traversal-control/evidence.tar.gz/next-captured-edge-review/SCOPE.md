# Captured-edge native Stored proof scope

Started 2026-10-31 01:47 CET. Source-only proof task. Root owns execution.
Implement the frozen CapturedEdge.run observation header using existing
current slot/context/resource gates plus separate entry native Stored.
None and unhandled expose no caller. True proves no hidden native property.
This is next-phase evidence outside the final R11 production scope.
No compiler, evaluator, native execution, Git, network, board, production edits, or spawning.

No OLD whole or near-whole acquisition is planned. Named bounded cuts:
- SelectedEdge lines 1-93, then exact arity/unsupported headers 94-107.
- CapturedEdge lines 25-33.
- NativeBranchResources lines 35-100 and 101-146.
- CapturedEdgeResources lines 33-102.

Explicit checked NEW whole reuse: SourceCurrentAllocatedNativeStoredSelectedEdge.lean,
88L SHA 716d4f08f64e0ee7fb5bcf58f51454bcca63e91b3831ecf13c90d4db9d6bd1d2.
Root reports FIRST strict probe PASS unchanged; installed status-only removal;
default and strict PASS. The child will not run checks.
