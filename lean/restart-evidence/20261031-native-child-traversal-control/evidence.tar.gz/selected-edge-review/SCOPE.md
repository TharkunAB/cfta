# Selected-edge native Stored proof scope

Started 2026-10-31 01:39 CET. Source-only proof task. Root owns all execution.
Implement the exact selected_edge_native_stored observation header from current
SelectedEdgeResources gates plus entry native Stored. No CapturedEdge draft.
Unhandled exposes no caller; True establishes nothing about hidden states.
No compiler, evaluator, native execution, Git, network, board, production edits, or spawning.

The two named OLD whole acquisitions are frozen exact reuses:
1. SourcePruningEnumerationSelectedEdgeResources.lean, 254 lines.
2. SourcePruningEnumerationEdgeInputs.lean, 133 lines.
Other OLD sources remain bounded exact inventory cuts.
Explicit NEW checked whole reuse: SourceCurrentAllocatedNativeStoredChildTraversal.lean,
147L SHA c5642a69e8e2364d7ab5335882859865a87d9bae4b6693301cebd9c35c9d5390.
Root reports FIRST strict probe PASS after only one local binder rename.
The installed source removes the draft status line. The public header is unchanged.
