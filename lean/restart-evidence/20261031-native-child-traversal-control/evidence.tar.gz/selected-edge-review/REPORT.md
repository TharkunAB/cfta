# Selected-edge native Stored proof handoff

2026-10-31 01:40 CET. SOURCE-ONLY. The candidate is UNCOMPILED.

## Deliverable

NativeStoredSelectedEdge-v1-UNCOMPILED.lean contains one public theorem,
selected_edge_native_stored, with the exact frozen first inventory header.
EXACT-PUBLIC-HEADER.md retains that header separately. A text comparison
confirmed that the proof module's header is identical to the frozen header.
Root must check the draft. The child does not claim that it elaborates.

The conclusion directly inspects the actual SelectedEdge.run result.
Complete and rejected results certify their exposed caller. Stopped results
certify the caller in their exact retained child observation. Unhandled is
True because it exposes no caller. True proves nothing about hidden native
mutations, unexposed endpoints, or later parent-worker states.

## Current admission and derivation

The theorem retains the existing SelectedEdgeResources current gates:
Context, available and closed selected parent, edge membership, Safe,
PendingRealized, Roots, correct waiting counts, exact current candidate flags,
bounded/pending bucket, allowed arity, current successful constraint
projection, Fits, the exact selected-edge child-cost reservation, known heap,
and separate entry native Stored. The five actual bounds are arbitrary.
There is no future traversal Ready, Realized, Paths, Fits, reservation,
Trace, completion witness, output Stored, or general transition supplier.

EdgeInputs.complete derives the actual own-prefix cache equality directly
from those current facts. Its exported facts give the own cache's Safe,
Roots, Realized, waiting counts, candidate flags, and genuine child inputs.
These include incoming availability/closedness and each exact child bucket's
bounds and pending facts. The native caller stays the original caller.
The original Fits, known heap, and entry native Stored therefore supply the
traversal's native entry facts. The original reservation has the exact cost
of the actual children list by the existing SelectedEdge.cost definition.

The proof uses the existing map-map readback to identify the projected staged
inputs with EdgeInputs.children. It applies the checked child-traversal law
at the actual original five bounds and current own-cache entry. It then
rewrites the actual SelectedEdge.run using the exact prepare equality.
The traversal complete branch retains its reached caller while finish changes
only the cache. The traversal stopped branch retains its exact observation.
The proof uses no future completed execution to establish traversal admission.

## Checked dependency

The exact installed SourceCurrentAllocatedNativeStoredChildTraversal.lean
is retained as an explicit checked NEW whole reuse, 147 lines, SHA256
c5642a69e8e2364d7ab5335882859865a87d9bae4b6693301cebd9c35c9d5390.
Root reports the first strict probe passed after one local stopped-binder
rename. The public header is unchanged. Installation removes only the draft
status line. The child did not run any checker.

The prior inventory metadata retains its original UNCOMPILED traversal
notice unchanged. Root's newer exact installed confirmation supersedes that
historical notice. The prior CapturedEdge inventory header is retained only
as immutable provenance. This task drafts no CapturedEdge theorem.

## Source scope

The two OLD whole modules were named before acquisition. They are exact
frozen reuses of SelectedEdgeResources (254 lines) and EdgeInputs (133 lines). Their retained
copy pins and current full-source pins match the frozen owner ledger.
The other OLD source is the exact SelectedEdge lines 1-93 cut from 319 lines.
The fourth source record is the explicit checked NEW traversal (147 lines) reuse.
No additional source search or third OLD whole acquisition occurred.

acquisitions.json records all four sources with original source path, full
SHA, line/byte counts, exact range, retained-copy pin, and acquisition class.
CUMULATIVE-SOURCE-UNIONS.json records the exact cumulative scope.
metadata-reuses.json records all five exact frozen inventory/provenance copies.
The old owner manifest is 34b13577641ed12eb03d197b4d9060c6d13360e09b2c25a7a8ca39ee67ea11c8.
No old frozen bundle or production file changed.

## Validation and remaining boundary

The child checked source and retained-copy hashes, exact public header text,
source-count consistency, and the two-OLD-whole scope. No command failure,
missing file, source drift, or output truncation occurred. No compiler,
evaluator, native execution, Git, network, board, or production mutation ran.

This candidate concerns only exposed selected-edge observations under their
current entry gates. It proves no property about a discarded finalizer
endpoint or CapturedEdge.none. It does not establish original sufficient
depth/capacity, admission from the full public request, whole parent-worker
enumeration, finite global coverage, or Haskell correspondence. Native Stored
remains separate from merge.Context Stored. No Haskell execution, defect,
or fix was established. No Haskell FINDINGS entry is added.
