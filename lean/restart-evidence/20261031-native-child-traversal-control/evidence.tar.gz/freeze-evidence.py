from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,subprocess

r=Path('/tmp/mcfta-native-child-traversal-control-20261031')
assert not (r/'FROZEN.json').exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head==json.loads((r/'docs-commit.json').read_text())['commit']
assert not subprocess.check_output(['git','status','--porcelain=v1'])
publication=json.loads((r/'checkpoint-publication.json').read_text())
assert publication['head']==head and publication['readback_exact'] and publication['tracking_exact']
assert publication['refs']['refs/heads/main']=='bd5a406a6a3f84b7e3ae0906082783911509df83'
summary=json.loads((r/'verification-summary.json').read_text())
assert summary['commands']==15 and summary['passed']==15 and summary['failed']==0
assert summary['input_snapshots']==42 and summary['public_checks']==1230 and summary['all_new_axioms_standard']
assert json.loads((r/'owned-verification.json').read_text())['status']=='pass'
assert 'public-review' in json.loads((r/'owned-verification.json').read_text())['owners']
assert json.loads((r/'document-verification.json').read_text())['all_current_pins']=='pass'
for p in r.iterdir():
    if p.is_dir() and not p.name.startswith('prior-') and (p/'started-command.json').exists():
        assert (p/'report.json').exists()
rows=[]
for p in sorted(r.rglob('*')):
    if p.is_file():
        assert not p.is_symlink();b=p.read_bytes()
        rows.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
seal={'created_at':datetime.now(ZoneInfo('Europe/Stockholm')).isoformat(),'write_halt':True,
      'goal_turn':'progress','full_goal_complete':False,'goal_controller_observed_status':'blocked',
      'work_continues_under_user_instruction':True,
      'traversal_source_head':'9b67abbd261ec0abafb81aa13084a9160bf978f4',
      'selected_source_head':'a10bf2d2aad35061a93d5a06938e5bd36571be55',
      'source_head':'dd33ab557bd76f9f340f348743c3253777703d03','docs_head':head,
      'main_head':'bd5a406a6a3f84b7e3ae0906082783911509df83','latest_prior_board_sequence':794,
      'compiler_commands':15,'passed_commands':15,'repaired_failed_commands':0,'input_snapshots':42,
      'new_laws':3,'public_checks':1230,'public_definitions':118,
      'root_source_lines':328,'root_public_lines':163,
      'future_contracts':'complete CapturedEdge108L V1 retained UNCOMPILED with full owner',
      'next_source_tasks':'sufficient ORIGINAL-depth producer inventory and CapturedEdge check; no future108L Root check claimed',
      'payload_count_excluding_seal':len(rows),'payloads':rows}
(r/'FROZEN.json').write_text(json.dumps(seal,indent=2)+'\n')
for p in r.rglob('*'):
    if p.is_file():p.chmod(p.stat().st_mode&~0o222)
assert all(not(p.stat().st_mode&0o222) for p in r.rglob('*') if p.is_file())
print(json.dumps({'sealed':True,'payloads_excluding_seal':len(rows),
 'raw_bytes_excluding_seal':sum(a['bytes'] for a in rows),'source_head':seal['source_head'],'docs_head':head}))
