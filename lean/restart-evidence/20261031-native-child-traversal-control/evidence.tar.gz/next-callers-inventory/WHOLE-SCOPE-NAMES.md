# Named OLD whole scope

Slot 1 named before acquisition at 2026-10-31 01:26 CET:
SourcePruningEnumerationSelectedEdgeResources.lean, 254L.
Slot 2 named before acquisition at 2026-10-31 01:27 CET:
SourcePruningEnumerationEdgeInputs.lean, 133L.
Both OLD whole slots are used.
