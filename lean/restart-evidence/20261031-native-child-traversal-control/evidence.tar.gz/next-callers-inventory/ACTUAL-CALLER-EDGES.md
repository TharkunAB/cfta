# Actual caller edges

All entries below refer to the acquired modeled Lean definitions. They do not
establish correspondence with the Haskell runtime.

1. SelectedEdge.run lines69-82 calls CachedOwn.prepare with the current native
   heap as a read-only value. Its one supported singleton branch calls
   ChildTraversal.run with the exact prepared cache, original caller, and
   original query memos. A stopped traversal observation is retained exactly.
   A complete traversal result retains its caller and changes only the cache
   through SelectedEdge.finish.
2. CachedOwn.prepare lines23-42 tests current arity, projects the current edge
   constraint, suspends own classes in the enumeration cache, and captures
   ordered child actions. It has no returned native caller.
3. EdgeInputs.complete25-133 derives the actual prepare equality and all current
   traversal entry facts from the original selected-parent admission. Its
   children list uses every actual edge child and the full inherited plus fresh
   own-class descended bucket. Its exported prepare equality fixes the cache
   at the actual call. No future entry supplier is required.
4. SelectedEdgeResources48-190 already composes EdgeInputs.complete and the
   current traversal resource producer. Its map-map readback identifies the
   actual staged input projection with EdgeInputs.children. The exact current
   cost is TraversalCompletion.cost of that list, including complete bucket
   lengths. Fits/known/native Stored need no transport across own preparation
   because the native caller is unchanged.
5. CapturedEdge.run25-33 invokes SelectedEdge.run. On complete, it invokes
   Finalize.run with that reached caller's heap and maps only the returned
   cache. Other SelectedEdge results are retained as some result. A failed
   finalizer returns none and does not expose the reached caller.
6. CapturedEdgeResources33-102 derives parent Available/closed and bounded inputs
   from the original pending-slot lookup, decoded node equality, PendingRealized,
   and EnumerationDriver.Ready. Thus these semantic facts need not become
   additional premises for the captured wrapper's slot-based target.
7. NativeBranches.run31-44 invokes CapturedEdge.run for each original edge while
   restoring the captured enumeration cache for each alternative. It threads
   native caller and queries only through advance receipt = some endpoint.
   A CapturedEdge none stops immediately with .stopped [] none. Recursive
   callers prepend earlier processed receipts but add no final caller field.
8. NativeBranches.advance22-26 continues complete, rejected, and the exact valid
   stopped-empty/cache-present receipt. It discards no caller on those routes.
   Unsupported or other stopped receipts return none while retaining that
   receipt in the actual stopped result.
9. SelectedOrdinaryDispatch.run32-49 invokes NativeBranches.run only after an
   actual done selected-value observation, a successful singleton preparation,
   no terminal inputs, and a node value. It frames the entered enumeration core
   and advances the caller to the returned heap before invoking native branches.
10. SelectedDispatch.run33-50 retains the ordinary native-branches result as its
    left alternative. Its separate fallback invokes SelectedOpaqueDispatch.
    This inventory does not extend the opaque route's semantic admission.

SelectedValueCaller.advance27-29 is an additional concrete frame before these
outer calls. Its exact definition is retained. This inventory does not prove
its native Stored law or derive complete SelectedDispatch admission from an
original public request.
