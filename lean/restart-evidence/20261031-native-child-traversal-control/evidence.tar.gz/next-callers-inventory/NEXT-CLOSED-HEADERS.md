# Proposed closed caller headers

INVENTORY ONLY. Neither theorem is proved or drafted here. Traversal V2 (148 lines)
remains UNCOMPILED until Root confirms. These targets must wait for that check.
Symbol, Constraint, Node, Caller, Cached, Heap, Seed, Inventory, Context, Memos,
and Stored use the exact notations in SelectedEdgeResources and the native
Stored modules. These are only abbreviations for the existing concrete types.

## Nearest actual handler

This header uses the exact current SelectedEdgeResources entry interface plus
arbitrary actual bounds and separate native Stored. True on unhandled states
no fact about an unexposed caller or hidden native mutation.

```lean
theorem selected_edge_native_stored
    {bits : Nat}
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
    (seed : Seed)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (caller : Caller (bits + 2)) (before : Cached)
    (checkEmpty : Bool) (r n p h k : Nat)
    (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
    (edges : List (EdgeValue Symbol Constraint)) (depth : Nat)
    (free : List InternedBinderProtocol.Reference)
    (edge : EdgeValue Symbol Constraint) (scs : List Suspended)
    (roots : Nat → Nat) (memos : Memos)
    (initial : Context formulas solver inventory caller memos)
    (parentAvailable : Available caller.checked.native.machine.heap (.node parentEntry edges depth free))
    (parentClosed : free = []) (selected : edge ∈ edges)
    (safe : Safe before.core) (realized : PendingRealized caller.checked.native.machine.heap before.core)
    (paths : Roots before.core.representatives roots)
    (counts : EnumerationCanonicalWaiting.Correct roots before.core.values before.waiting)
    (flags : ∀ slot, SourcePruningEnumerationNativeIndex.candidate caller.checked.native.machine.heap
      ((before.core.values[slot]?).getD .eliminated) = some (before.expandable slot))
    (bounded : ∀ sc ∈ scs, sc.var < before.core.counter)
    (pending : InputsPending before.core scs)
    (allowed : arityAllows edge.children.length scs = true)
    (tries : List EqualityTrie.Trie) (residual : Option Constraint)
    (projected : SourcePruningEnumerationConstraint.project edge.entry.key.constraint = some (tries, residual))
    (fits : Fits seed.2 caller.checked)
    (reserved : Reserved bits seed
      (SourcePruningEnumerationSelectedEdge.cost edge scs before.core.counter tries))
    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)
    (nativeStored : Stored caller.checked.native) :
    match SourcePruningEnumerationSelectedEdge.run checkEmpty r n p h k scs edge caller before memos.query with
    | .unhandled => True
    | .rejected reached _ _ => Stored reached.checked.native
    | .stopped _ observation _ => Stored observation.2.1.checked.native
    | .complete _ reached _ _ => Stored reached.checked.native
```

## Next captured wrapper from current slot admission

This header uses the exact current NativeBranchResources.head_complete_resources
entry interface plus arbitrary actual bounds and separate native Stored.
It handles current rejected arity and unsupported projection through edgeCost.
True on none or unhandled makes no claim about discarded native endpoints.
In particular, none can follow a completed edge with a failed finalization.

```lean
theorem captured_edge_native_stored
    {bits : Nat}
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
    (seed : Seed)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (caller : Caller (bits + 2)) (before : Cached)
    (checkEmpty : Bool) (r n p h k uv handle : Nat) (scs : List Suspended)
    (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
    (edges : List (EdgeValue Symbol Constraint)) (depth : Nat)
    (free : List InternedBinderProtocol.Reference)
    (edge : EdgeValue Symbol Constraint) (roots : Nat → Nat) (memos : Memos)
    (initial : Context formulas solver inventory caller memos)
    (ready : EnumerationDriver.Ready uv before.core)
    (stored : before.core.values[uv]? = some (.unenumerated (some handle) scs))
    (decoded : lookupNode caller.checked.native.machine.heap handle = some (.node parentEntry edges depth free))
    (realized : PendingRealized caller.checked.native.machine.heap before.core)
    (selected : edge ∈ edges)
    (paths : Roots before.core.representatives roots)
    (counts : EnumerationCanonicalWaiting.Correct roots before.core.values before.waiting)
    (flags : ∀ slot, SourcePruningEnumerationNativeIndex.candidate caller.checked.native.machine.heap
      ((before.core.values[slot]?).getD .eliminated) = some (before.expandable slot))
    (pending : InputsPending before.core scs)
    (fits : Fits seed.2 caller.checked)
    (reserved : Reserved bits seed
      (SourcePruningEnumerationNativeBranchCompletion.edgeCost scs before.core.counter edge))
    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)
    (nativeStored : Stored caller.checked.native) :
    match SourcePruningEnumerationCapturedEdge.run checkEmpty r n p h k uv scs edge caller before memos.query with
    | none => True
    | some .unhandled => True
    | some (.rejected reached _ _) => Stored reached.checked.native
    | some (.stopped _ observation _) => Stored observation.2.1.checked.native
    | some (.complete _ reached _ _) => Stored reached.checked.native
```
