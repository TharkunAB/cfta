# Traversal caller native Stored inventory

2026-10-31 01:30 CET. SOURCE INVENTORY ONLY. No proof draft was created.
This task is next-phase evidence outside Root's frozen R10 checkpoint.
Traversal V2 (148 lines) remains UNCOMPILED until Root confirms its checks.

## Nearest next target

The nearest actual parent of ChildTraversal.run is SelectedEdge.run lines 69-82.
Its current selected-parent admission is already stated in
SelectedEdgeResources.complete_with_fragments_resources lines 48-99. The exact
closed next header is retained in NEXT-CLOSED-HEADERS.md. It adds only
arbitrary actual r/n/p/h/k and separate entry native Stored to that interface.

The required current gates are Context, available/closed selected parent,
selected edge membership, Safe, PendingRealized, Roots, correct waiting
counts, exact current cache candidate flags, bounded/pending input bucket,
allowed current arity, successful current constraint projection, Fits,
Reserved(cost of actual child buckets), known annotation heap, and separate
entry native Stored. No future traversal entry fact is supplied.

EdgeInputs.complete derives the actual own-prefix prepare equality and its
current Safe/Roots/waiting/flags/Realized/genuine traversal input facts.
The existing SelectedEdgeResources proof already supplies the precise map-map
readback for those actual inputs and their exact current cost. The native
caller is unchanged during this cache preparation. After a completed child
traversal, finish changes only cache obligations and retains the caller.
A stopped traversal observation is retained exactly by SelectedEdge.run.

The planned dependency on TraversalV2 is unverified in this inventory. The
handler proof must wait until Root confirms that module. No proposed law is
reported as achieved.

## Next wrapper and current slot admission

CapturedEdge.run lines 25-33 is the next direct wrapper. The second closed header
uses the existing current NativeBranchResources.head_complete_resources
entry gates. These include current EnumerationDriver.Ready, exact original
unenumerated-slot lookup, decoded parent lookup, PendingRealized, edge
membership, Roots/counts/flags, InputsPending, Fits, conditional edgeCost
reservation, known heap, Context, and separate native Stored.

The current slot gates derive parent availability/closedness and bucket bounds
through the exact CapturedEdgeResources lines 33-102 derivation. No stronger slot
semantic premise is needed. The conditional current edgeCost handles arity
rejection and unsupported projection before a traversal is reached.
Finalization receives the reached caller heap as a read-only value and
returns only a cache. Successful finalization retains the exposed caller.

## Result visibility limit

CapturedEdge.none can occur after SelectedEdge completed and exposed a reached
caller, followed by failed cache finalization. The wrapper discards that
caller in none. NativeBranches.run stops immediately with .stopped [] none.
It neither resumes from beforeCaller nor threads the discarded endpoint
through none. Earlier processed receipts do not recover the failed
alternative's reached endpoint. SelectedOrdinaryDispatch and SelectedDispatch
retain that stopped result without adding an endpoint.

SelectedEdge.run itself is an existing actual observation of the lower-stage
reached caller before finalization. The outer none does not retain it.
NativeBranches.Trace records only some receipt plus a continuing endpoint;
it does not expose the none path. NONE-BOUNDARY.md states the exact code
boundary and an unproved readback header using existing actual subcall
equations. It creates no artificial carrier or certificate supplier.

True in the proposed none/unhandled cases proves no native property of hidden
or unexposed states. The proposed outer law certifies only exposed callers.
It must not be reported as preservation of every hidden native endpoint.

## Source and provenance

The two OLD whole modules were named before acquisition: SelectedEdgeResources
254 lines and EdgeInputs 133 lines. Every other OLD acquisition is a named bounded cut
or exact locator line. The largest other cumulative fraction is NativeBranches
63/116 lines. No third OLD whole or near-whole module was acquired.

The exact frozen traversal CLOSED-HEADER and SUCCESSOR-GATES maps were reused
with their original manifest/source-copy pins. The prior frozen manifest SHA
is 8be0e8fde7d21e77649e967fe2e6eefe963836ee189a50981b9e28e83715c8d6.
metadata-reuses.json retains all four map/provenance copies and exact pins.
No prior frozen payload changed. No production file changed.

There are 66 source acquisition records over 52 files. Most are only the
initial 109 exact caller-reference locator lines over 40 files. Full stdout and
stderr are retained. acquisitions.json records every source SHA, full line
and byte counts, exact acquired ranges or line numbers, copy pins, and scope.
CUMULATIVE-SOURCE-UNIONS.json records each acquired line per source.
ACTUAL-CALLER-EDGES.md lists the exact immediate call and producer edges.
PATH-LOCATORS.md records the bounded search scope.

No command failure, missing file, source drift, or output truncation occurred.
The child ran no compiler, evaluator, native execution, Git, network, board,
or production mutation. It produced no Lean proof draft.

## Remaining boundary

This inventory identifies a concrete next handler target and its existing
current admission route. It proves neither that handler nor the traversal
draft. It does not establish admission from an original public request,
original sufficient depth/capacity, full parent-worker enumeration, global
finite coverage, or Haskell correspondence. Native Stored remains separate
from merge.Context Stored. No Haskell execution, defect, or fix was
established, so no Haskell FINDINGS entry is added.
