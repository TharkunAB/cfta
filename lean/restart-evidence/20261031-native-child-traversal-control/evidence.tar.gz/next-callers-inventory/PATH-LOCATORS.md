# Bounded locators

The initial exact source-text locator was:
rg -n 'SourcePruningEnumerationChildTraversal\.run' lean/MicroCFTA
  -g 'SourcePruningEnumeration*.lean'

It returned 109 reference lines in 40 source files. The complete stdout/stderr
and each file's exact selected lines are retained. This found SelectedEdge.run
as the immediate concrete call in the selected-edge route. It does not prove
an exhaustive call graph under aliases or Haskell correspondence.

Name-only bounded families are retained in selected-source-paths.txt,
native-branch-source-paths.txt, and captured-edge-source-paths.txt.
Declaration locators then inspected only the named current handler, admission,
resource, own-prefix, finalization-wrapper, and immediate outer dispatch files.
Each locator has full-source metadata and exact selected line numbers.
No broad parent-worker implementation search occurred.
