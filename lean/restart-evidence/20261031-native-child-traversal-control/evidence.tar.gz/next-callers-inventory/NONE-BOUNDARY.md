# Discarded caller on failed cache finalization

SelectedEdge.run is an existing actual lower-stage observation that exposes
its reached caller in the complete constructor. CapturedEdge.run consumes
that observation and maps Finalize.run. If finalization returns none, the
CapturedEdge result is none. It contains no native caller or query endpoint.

NativeBranches.run handles that none by stopping immediately. It does not
resume from beforeCaller and does not thread the discarded caller through
none. The result is .stopped [] none at that level. If earlier alternatives
ran, enclosing recursion retains their processed receipts but still returns
no endpoint for the failed finalizing alternative. This is no rollback claim.
SelectedOrdinaryDispatch and SelectedDispatch retain that stopped result.

The existing NativeBranches.Trace carrier has only nil and cons constructors.
Its cons requires CapturedEdge.run = some receipt and advance receipt = some
endpoint. It records continuable alternatives. It does not represent the
failed-finalization none branch or recover its discarded native endpoint.

The next headers use True for none/unhandled because those results expose no
reached caller. True establishes no fact about hidden native mutations or an
unexposed endpoint. It must not be reported as whole-worker preservation of
all native states. The observed SelectedEdge complete state is a separate,
concrete program subcall. It can be named by its actual equation in a proof;
that equation is not retained by the existing outer result type.

The following is a proposed source readback header only. No proof is drafted
or checked here, and no existing export of this exact inverse was located in
the inspected interfaces. It adds no carrier or certificate input. Its
witnesses are the actual existing SelectedEdge and Finalize subcall equations.
It would permit later proofs to discuss the discarded endpoint explicitly.
It would not cause the actual outer worker to return that endpoint.

```lean
theorem captured_edge_none_readback
    {width : Nat}
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
    (checkEmpty : Bool) (r n p h k target : Nat) (scs : List Suspended)
    (edge : EdgeValue Symbol Constraint) (caller : Caller width)
    (before : Cached) (queries : SourceEndpointMemo.Memos)
    (observed : SourcePruningEnumerationCapturedEdge.run checkEmpty r n p h k target
      scs edge caller before queries = none) :
    ∃ fragment reached saved after,
      SourcePruningEnumerationSelectedEdge.run checkEmpty r n p h k scs edge caller before queries =
        .complete fragment reached saved after ∧
      SourcePruningEnumerationFinalize.run reached.checked.native.machine.heap k target fragment after = none
```

This source-level result-shape boundary does not establish a Haskell defect.
No admitted actual Haskell execution occurred in this inventory.
