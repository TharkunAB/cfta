from pathlib import Path
import json,hashlib,subprocess,datetime
r=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def j(p):return json.loads((r/p).read_text())
coverage={}
for x in j('read-ledger.json'):
 assert x['read_complete'];b=(r/x['source']).read_bytes();assert sha(b)==x['source_sha256'];lo,hi=x['actual'];cut=b''.join(b.splitlines(keepends=True)[lo-1:hi]);assert cut==(r/x['copy']).read_bytes() and sha(cut)==x['copy_sha256'];coverage.setdefault(x['source'],set()).update(range(lo,hi+1))
for name,n in [('inputs/installed-child-traversal.lean',147),('inputs/installed-selected-edge.lean',88),('inputs/installed-count.lean',93),('inputs/public-traversal-tail.log',63),('inputs/public-final-new-tail.log',163)]:assert coverage[name]==set(range(1,n+1))
for name in ['acquisitions.json','candidate-version-metadata.json','old-source-cut-ledger.json']:
 for x in j(name):
  assert sha((r/x['copy']).read_bytes())==x['copy_sha256'];assert subprocess.check_output(['sha256sum',x['source_path']],text=True).split()[0]==x['source_sha256']
  if name=='old-source-cut-ledger.json':
   assert x['read_complete'];lo,hi=x['actual'];assert subprocess.check_output(['sed','-n',f'{lo},{hi}p',x['source_path']])==(r/x['copy']).read_bytes()
   if 'reuse_from' in x:assert sha(Path(x['reuse_from']).read_bytes())==x['reuse_from_sha256']
for x in j('old-source-locator-ledger.json'):
 assert sha((r/x['copy']).read_bytes())==x['copy_sha256'];assert subprocess.check_output(['sha256sum',x['source_path']],text=True).split()[0]==x['source_sha256']
for x in j('candidate-diffs.json'):assert x['read_complete'] and sha((r/x['diff']).read_bytes())==x['sha256']
for x in j('installed-identities.json'):
 assert sha((r/x['before']).read_bytes())==x['before_sha256'];assert sha((r/x['after']).read_bytes())==x['after_sha256'];assert x['all_other_bytes_exact']
u=j('old-source-unions.json');assert u['whole_or_near_whole_acquisitions']==0 and u['source_paths']==13 and u['cuts']==17 and u['cut_lines']==412 and u['reused_cuts']==2;assert all(x['fraction']<0.444 for x in u['entries'])
assert (r/'inputs/public-final-new-tail.log').read_bytes().startswith((r/'inputs/public-traversal-tail.log').read_bytes())
validation={'status':'PASS','current_source_lines':328,'final_public_lines':163,'combined_diff_review_lines':146,'all_three_complete_public_contracts_and_standard_only_reports_read':True,'source_versions':12,'adjacent_diffs':9,'old_whole_or_near_whole_acquisitions':0,'old_cuts':17,'old_cut_lines':412,'old_source_paths_including_locators':13,'explicit_prior_reuse_cuts':2,'source_copy_range_hash_and_identity_checks':'PASS','prior_bundles_changed':False,'reviewer_compiler_evaluator_native_Git_network_board_production_spawn_actions':0,'Haskell_defect_or_fix_established':False}
(r/'verification.json').write_text(json.dumps(validation,indent=2)+'\n')
files=[]
for p in sorted(r.rglob('*')):
 if p.is_file() and p.name not in ['MANIFEST.json','pins.json']:
  b=p.read_bytes();files.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':sha(b)})
m={'schema':1,'status':'PASS; frozen independent source/public review','created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':str(r),'payload_count':len(files),'payload_bytes':sum(x['bytes'] for x in files),'files':files};(r/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');pins={x['path']:x['sha256'] for x in files};pins['MANIFEST.json']=sha((r/'MANIFEST.json').read_bytes());(r/'pins.json').write_text(json.dumps({'pins':pins},indent=2)+'\n')
actual={str(p.relative_to(r)) for p in r.rglob('*') if p.is_file()};assert actual==set(pins)|{'pins.json'}
for name,h in pins.items():assert sha((r/name).read_bytes())==h
for p in r.rglob('*'):
 if p.is_file():p.chmod(0o444)
for p in sorted((p for p in r.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
r.chmod(0o555);assert all(not(p.stat().st_mode&0o222) for p in r.rglob('*'))
print(json.dumps({'status':'FROZEN PASS','payload_count':len(files),'total_files':len(actual),'payload_bytes':m['payload_bytes'],'total_bytes':sum(p.stat().st_size for p in r.rglob('*') if p.is_file()),'MANIFEST_sha256':pins['MANIFEST.json'],'pins_sha256':sha((r/'pins.json').read_bytes()),'REPORT_sha256':pins['REPORT.md']},indent=2))
