from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).parent;repo=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA');prior=Path('/tmp/mcfta-terminal-prefix-public-review-20261031')
tasks=[('SourcePruningEnumerationChildTraversal.lean',15,58,None),('SourcePruningEnumerationChildDispatchUnique.lean',23,36,None),('SourcePruningEnumerationChildResources.lean',34,80,None),('SourcePruningEnumerationTraversalResources.lean',31,87,None),('SourcePruningEnumerationIncomingReservation.lean',101,111,None),('SourceCurrentAllocatedNativeStoredChildDispatch.lean',29,50,'inputs/installed-child.lean'),('SourceCurrentAllocatedFiniteOrdinaryStored.lean',24,38,'old-cuts/SourceCurrentAllocatedFiniteOrdinaryStored.lean-L24-L38.txt'),('SourcePruningEnumerationSelectedEdge.lean',69,94,None),('SourcePruningEnumerationSelectedEdge.lean',21,29,None),('SourcePruningEnumerationEdgeInputs.lean',25,69,None),('SourcePruningEnumerationSelectedEdgeResources.lean',32,35,None),('SourcePruningEnumerationSelectedEdgeResources.lean',48,95,None)]
ledger=[];pc=json.loads((prior/'old-source-cut-ledger.json').read_text())
for name,lo,hi,reuse in tasks:
 p=repo/name;meta=subprocess.check_output(['wc','-lc',str(p)],text=True).split();assert hi<=int(meta[0]);h=subprocess.check_output(['sha256sum',str(p)],text=True).split()[0];b=subprocess.check_output(['sed','-n',f'{lo},{hi}p',str(p)]);rel=f'old-cuts/{name}-L{lo}-L{hi}.txt';dest=r/rel
 if dest.exists():assert dest.read_bytes()==b
 else:dest.write_bytes(b)
 x={'source_path':str(p),'source_lines':int(meta[0]),'source_bytes':int(meta[1]),'source_sha256':h,'actual':[lo,hi],'copy':rel,'copy_sha256':hashlib.sha256(b).hexdigest(),'read_complete':False,'classification':'bounded OLD actual definition or complete producer header'}
 if reuse:
  saved=prior/reuse;data=saved.read_bytes()
  if reuse.startswith('inputs/'):
   assert hashlib.sha256(data).hexdigest()==h;start=1
  else:
   prev=next(t for t in pc if t['copy']==reuse);assert prev['source_sha256']==h;start=prev['actual'][0]
  assert b''.join(data.splitlines(keepends=True)[lo-start:hi-start+1])==b;x.update(classification='explicit bounded prior NEW-source/cut reuse; counted against ORIGINAL source path',reuse_from=str(saved),reuse_from_sha256=hashlib.sha256(data).hexdigest(),reuse_origin_range_start=start)
 ledger.append(x);(r/'old-source-cut-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
print('Acquired',len(ledger),'bounded OLD cuts; no whole source.')
