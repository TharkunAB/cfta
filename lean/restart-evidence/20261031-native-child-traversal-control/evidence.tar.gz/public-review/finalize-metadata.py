from pathlib import Path
import subprocess,json,hashlib,difflib
r=Path(__file__).parent;root=Path('/tmp/mcfta-native-child-traversal-control-20261031');repo=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,x):(r/p).write_text(json.dumps(x,indent=2)+'\n')
for f in ['read-ledger.json','old-source-cut-ledger.json']:
 a=json.loads((r/f).read_text())
 for x in a:x['read_complete']=True
 save(f,a)
old=json.loads((r/'old-source-cut-ledger.json').read_text());paths=sorted(set([Path(x['source_path']) for x in old]+[repo/'SourcePruningEnumerationTraversalCompletion.lean']))
# Exact named OLD locators. Capture declarations and the helper occurrences used by prior searches.
pattern=r'^import |^namespace |^theorem |^private theorem |^def |^inductive |^noncomputable def |^end |complete_with_fragments_resources|cost|Reserved|:= by'
(r/'old-locators').mkdir(exist_ok=True);loc=[]
for p in paths:
 b=subprocess.run(['rg','-n',pattern,str(p)],capture_output=True,check=False).stdout;rel=f'old-locators/{p.name}.txt';(r/rel).write_bytes(b);meta=subprocess.check_output(['wc','-lc',str(p)],text=True).split();loc.append({'source_path':str(p),'source_lines':int(meta[0]),'source_bytes':int(meta[1]),'source_sha256':subprocess.check_output(['sha256sum',str(p)],text=True).split()[0],'pattern':pattern,'actual_line_numbers':[int(v.split(b':',1)[0]) for v in b.splitlines()],'copy':rel,'copy_sha256':sha(b),'classification':'bounded named OLD locators; all matches counted in original-path union; not a whole semantic read'})
save('old-source-locator-ledger.json',loc)
unions=[]
for p in paths:
 xs=[x for x in old if x['source_path']==str(p)];ys=[x for x in loc if x['source_path']==str(p)];lines=set()
 for x in xs:lines.update(range(x['actual'][0],x['actual'][1]+1))
 for y in ys:lines.update(y['actual_line_numbers'])
 m=(xs+ys)[0];ranges=[]
 for n in sorted(lines):
  if ranges and ranges[-1][1]+1==n:ranges[-1][1]=n
  else:ranges.append([n,n])
 fraction=len(lines)/m['source_lines'];assert fraction<0.75
 unions.append({'source_path':str(p),'source_lines':m['source_lines'],'source_bytes':m['source_bytes'],'source_sha256':m['source_sha256'],'actual_union':ranges,'unique_lines':len(lines),'fraction':fraction,'whole_or_near_whole':False,'cut_count':len(xs),'locator_count':len(ys),'explicit_prior_reuse_count':sum('reuse_from' in x for x in xs)})
save('old-source-unions.json',{'whole_or_near_whole_acquisitions':0,'maximum_permitted':2,'source_paths':len(unions),'cuts':len(old),'cut_lines':sum(x['actual'][1]-x['actual'][0]+1 for x in old),'reused_cuts':sum('reuse_from' in x for x in old),'entries':unions})
# Retain only NEW candidates in the three assigned source families.
versions=[];files=[p for p in sorted(root.glob('*.lean')) if any(p.name.startswith(t) for t in ['native-child-traversal-','installed-child-traversal-','native-selected-edge-','installed-selected-edge-','native-continuation-count-','installed-continuation-count-'])]
for d,glob in [('traversal-review','NativeStored*.lean'),('selected-edge-review','NativeStored*.lean'),('continuation-count-review','*Count-v*-UNCOMPILED.lean')]:files+=sorted((root/d).glob(glob))
for p in files:
 b=p.read_bytes();rel='inputs/history/'+(p.parent.name+'-' if p.parent!=root else '')+p.name;dest=r/rel
 if dest.exists():assert dest.read_bytes()==b
 else:dest.write_bytes(b)
 versions.append({'source_path':str(p),'source_lines':len(b.splitlines()),'source_bytes':len(b),'source_sha256':sha(b),'copy':rel,'copy_sha256':sha(b),'classification':'retained current-task NEW version; current installed source read in full; all differences separately reviewed'})
save('candidate-version-metadata.json',versions);(r/'diffs').mkdir(exist_ok=True)
groups=[['traversal-review-NativeStoredChildTraversal-v1-UNCOMPILED.lean','traversal-review-NativeStoredChildTraversal-v2-UNCOMPILED.lean','native-child-traversal-v2.lean','native-child-traversal-v3.lean','installed-child-traversal-v4.lean'],['selected-edge-review-NativeStoredSelectedEdge-v1-UNCOMPILED.lean','native-selected-edge-v1.lean','installed-selected-edge-v2.lean'],['continuation-count-review-SourcePruningEnumerationNativeContinuationCount-v1-UNCOMPILED.lean','continuation-count-review-SourcePruningEnumerationNativeContinuationCount-v2-UNCOMPILED.lean','native-continuation-count-v2.lean','installed-continuation-count-v3.lean']]
diffs=[];combined=''
for group in groups:
 for a,b in zip(group,group[1:]):
  pa=r/'inputs/history'/a;pb=r/'inputs/history'/b;data=''.join(difflib.unified_diff(pa.read_text().splitlines(keepends=True),pb.read_text().splitlines(keepends=True),fromfile=a,tofile=b));rel='diffs/'+a+'--'+b+'.patch';(r/rel).write_text(data);diffs.append({'before':str(pa.relative_to(r)),'after':str(pb.relative_to(r)),'diff':rel,'bytes':len(data.encode()),'sha256':sha(data.encode()),'read_complete':False})
  if data:combined+='\nFILE '+rel+'\n'+data
save('candidate-diffs.json',diffs);(r/'candidate-diff-review.txt').write_text(combined);(r/'diff-chunks').mkdir(exist_ok=True);lines=combined.splitlines(keepends=True)
for lo in range(1,len(lines)+1,35):(r/f'diff-chunks/L{lo}-L{min(lo+34,len(lines))}.txt').write_text(''.join(lines[lo-1:lo+34]))
def header(p,name):
 s=p.read_text();start=s.index('theorem '+name);return s[start:s.index(':= by',start)]
checks={}
for name,owner,current in [('child_traversal_native_stored',groups[0][1],'installed-child-traversal.lean'),('selected_edge_native_stored',groups[1][0],'installed-selected-edge.lean'),('run_original_alternatives_bound',groups[2][1],'installed-count.lean')]:
 a=header(r/'inputs/history'/owner,name);b=header(r/'inputs'/current,name);assert a==b;checks[name]={'raw_public_header_exact_vs_owner':True,'owner':'inputs/history/'+owner,'current':'inputs/'+current,'header_sha256':sha(b.encode()),'owner_execution_claim':False}
save('contract-checks.json',{'status':'PASS','current_source_lines':328,'current_public_lines':163,'all_three_complete_headers_read':True,'all_three_standard_only_axiom_reports_read':True,'unhandled_conclusion':'True; no hidden-state property','count_conclusion':'complete processed length equals supplied edges length; stopped processed length strictly less','count_operational_hook_has_no_proof_supplier_premise':True,'checks':checks})
public=root/'public-v3/raw.log';meta=subprocess.check_output(['wc','-lc',str(public)],text=True).split();h=subprocess.check_output(['sha256sum',str(public)],text=True).split()[0];assert int(meta[1])==4934281 and h=='1a3c2ec3f52cfcfb41378701ffb47ae973ddd0a468078d2e3e529f054f3486b3';save('full-public-metadata.json',{'source_path':str(public),'lines':int(meta[0]),'bytes':int(meta[1]),'sha256':h,'metadata_only':True,'old_body_not_acquired':True,'old_prefix_exact':'Root-reported4923220B','intermediate_prefix_exact':'Root-reported4927290B; own4070B new-tail prefix independently checked'})
save('root-reported-validation.json',{'execution_owner':'Root','reviewer_execution':False,'serial_commands':15,'passed':15,'failed':0,'snapshots':42,'Audit_jobs':4764,'theorem_dependencies':83089,'public_checks':1230,'definition_prints':118,'standard_only_new_reports':3,'old_protected_exact':562,'old_native_exact':835,'old_Lean_exact_except_Audit':4761,'Audit_addition':'three imports before exact old body','final_full_public_bytes':4934281,'final_full_public_sha256':h,'intermediate_full_public_bytes':4927290,'intermediate_public_checks':1228,'intermediate_Audit_jobs':4762,'intermediate_theorem_dependencies':83081,'intermediate_commands':6,'intermediate_passed':6,'intermediate_snapshots':11})
print('OLD',len(old),'cuts',len(unions),'paths',sum(x['actual'][1]-x['actual'][0]+1 for x in old),'cut lines','maxfraction',max(x['fraction'] for x in unions));print('CANDIDATES',len(versions),'DIFFS',len(diffs),'DIFF REVIEW LINES',len(lines));print('DIFF CHUNKS',[p.name for p in sorted((r/'diff-chunks').iterdir())])
