# Independent source and public review

PASS. The reviewer read all 328 installed source lines, all 163 final public lines, and the complete 146-line repair-diff review. All three actual contracts agree with the source. No defect was found.

This review used source and metadata only. Root owns compilation, evaluation, native checks, Git, network, board, production, and packaging. The reviewer changed only this owned temporary directory. Root confirms the final installed, strict, Audit, and public checks passed. The prior frozen bundles remain unchanged.

| Installed module | Lines | SHA-256 |
| --- | ---: | --- |
| SourceCurrentAllocatedNativeStoredChildTraversal | 147 | c5642a69e8e2364d7ab5335882859865a87d9bae4b6693301cebd9c35c9d5390 |
| SourceCurrentAllocatedNativeStoredSelectedEdge | 88 | 716d4f08f64e0ee7fb5bcf58f51454bcca63e91b3831ecf13c90d4db9d6bd1d2 |
| SourcePruningEnumerationNativeContinuationCount | 93 | ddbbf4aa27707a19a2069f9f3f42acefdfe6d43e93ef7a03fc9134345f382e17 |

The final public tail has 163 lines and 11,061 bytes. Its SHA-256 is 714b5d7cf3ea863fc7f2826e7d5ce829b1f1b508226dda8b2c4bb296ab06dea9. All three complete statements and axiom reports were read. Each report contains only `propext`, `Classical.choice`, and `Quot.sound`.

## Native certificate meaning

`Stored` constrains returned native node and edge cells. If the request has an empty seen-list and both inputs have finite ordinary domains, its returned payload has a finite ordinary domain and height at most each input height. These are conditional structural certificates. This property does not certify result semantics, every active cell, or constructor normality.

## Child traversal

`child_traversal_native_stored` applies to the actual `ChildTraversal.run` result at arbitrary supplied fuels and either Empty-check setting. A complete result retains `Stored` at its actual returned caller. A stopped result retains `Stored` at the reached caller in its actual stopping observation.

The public entry conditions remain explicit: current Context, Safe core, root relation, waiting counts, current expandability flags, PendingRealized, available and closed incoming nodes, bounded and pending input buckets, Fits, a reservation for `cost inputs`, known guards, and entry Stored. The cost is the sum of each supplied bucket length plus one. These are the existing current traversal resource gates plus Stored.

The proof derives the head certificate before splitting any actual head outcome. All error, none, empty, malformed, and missing-cache stop shapes use that reached head certificate. Only actual singleton/cache success derives canonical completion internally. `run_some_unique` identifies its actual caller, queries, and cache. The canonical postcondition then supplies the next Context, roots, counts, flags, Realized, Fits, and known guards. Growth, enumerated origin, and protection derive the remaining input bounds and pending facts. The reservation is shortened by the consumed head cost. The induction hypothesis receives those derived facts and the actual head Stored certificate.

No public future Context, Realized, Fits, Stored, Trace, Paths, or completion supplier is added. The current root witness and current flags remain premises. The actual traversal Result/run definition and producer headers were checked with named bounded OLD cuts.

## Selected edge

`selected_edge_native_stored` retains the existing current SelectedEdge resource admission plus entry Stored. It includes parent availability and closure, actual edge membership, current state invariants and flags, bounded and pending suspensions, arity allowance, the supported constraint projection, Fits, reservation, and known guards.

`EdgeInputs.complete` derives the actual own cache and its Safe, roots, counts, flags, Realized, and genuine child inputs. The list readback identifies the literal staged traversal inputs. The native traversal law then supplies the certificate for each exposed caller.

The public result match is exact:

- `rejected`: Stored at the exposed caller.
- `stopped`: Stored at the caller in the exposed stopping observation.
- `complete`: Stored at the exposed caller.
- `unhandled`: True.

The unhandled branch exposes no caller and establishes no hidden-state fact. This is not a native certificate theorem for CapturedEdge or an outer none/unhandled wrapper. The actual SelectedEdge Result/run definition and the complete current admission and EdgeInputs producer headers match the proof.

## Continuation count

`run_original_alternatives_bound` has the existing operational inputs and arbitrary actual hook. It has no added semantic, current-invariant, or future-proof premise. For this one supplied edge list:

- Complete result: `processed.length = edges.length`.
- Stopped result: `processed.length < edges.length`.

Repeated edges count as separate list entries. The current stopping receipt is retained separately from the processed prefix. The count excludes that receipt, including a completed edge whose hook stops. Every actual capture, advance, hook-stop, and recursive suffix branch was checked against the old run/advance definitions.

“Original” means the edge list supplied to this fold. The theorem does not bound native work, hook outputs, recursive depth, global histories, or resets. It does not supply native certificates for arbitrary hooks.

## Provenance, versions, and checks

The bundle retains 12 NEW source candidates and nine adjacent diffs. All 146 combined diff-review lines were read. The three public headers match their owner V2/V1/V2 header text exactly. Original drafts remain source-only artifacts; this comparison does not claim that an uncompiled original was checked.

Before the first traversal probe, Root renamed the reserved proof binder `prefix` to `_processed`. That change does not alter its public header. SelectedEdge and the count passed their first Root probes without proof repair. Each final installation removes only its status line: 71, 71, and 56 bytes respectively. `installed-identities.json` verifies every other byte remains exact. The owner count V1/V2 proof changes and the earlier traversal owner changes are retained in the diffs. Root reports zero failed compiler probes.

OLD acquisition uses 17 bounded cuts, 412 cut lines, and 13 original source paths including locators. Two explicit prior reuses are counted against their ORIGINAL source paths. There are zero whole or near-whole OLD acquisitions, within the maximum of two. The largest cut-plus-locator union is under 44.4 percent of a source file. Every source path, full-file hash and size, exact acquired range or line numbers, copy hash, and reuse origin is recorded. Metadata hashing does not constitute an old source-body review.

`INCIDENTS.md` records one source display aborted before dispatch. The exact chunk was retried and read in full. No incomplete display was counted as complete. There were no reviewer compiler, evaluator, native, Git, network, board, production, or spawn actions.

Root reports 15 serial commands, all passing, with 42 snapshots. Audit passed at 4,764 jobs and 83,089 theorem dependencies. Public readback passed at 1,230 checks and 118 definition prints. Root reports exact preservation of 562 old protected files, 835 native files, and 4,761 old Lean files except three Audit imports. Full public metadata independently matches 4,934,281 bytes and SHA-256 1a3c2ec3f52cfcfb41378701ffb47ae973ddd0a468078d2e3e529f054f3486b3. Old full-output prefix identities remain Root-reported. The prior 4,070-byte NEW traversal tail is independently an exact prefix of this review's final NEW tail.

No Haskell defect or fix is established. No Haskell file was edited. Whole-worker correctness, whole-caller neutrality, hidden outer-state preservation, Haskell/public API correspondence, Word64 correspondence, and global depth/work bounds remain outside these three laws.
