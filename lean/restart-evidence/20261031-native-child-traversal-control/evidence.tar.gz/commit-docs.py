from pathlib import Path
import json,subprocess
r=Path('/tmp/mcfta-native-child-traversal-control-20261031');repo=Path('/home/tritlo/Code/mcfta')
expected=['FINDINGS.md','HANDOFF.md','NEXT-PROMPT.md','lean/notes-current-native-child-traversal.md']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='dd33ab557bd76f9f340f348743c3253777703d03'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True).strip()
subprocess.run(['git','add','--',*expected],cwd=repo,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True).splitlines())==set(expected)
process=subprocess.run(['git','commit','-m','Record recursive traversal and receipt count proof boundaries'],cwd=repo,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/'docs-commit.raw.log').write_text(process.stdout);assert process.returncode==0,process.stdout
row={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'message':'Record recursive traversal and receipt count proof boundaries','files':expected};(r/'docs-commit.json').write_text(json.dumps(row,indent=2)+'\n');assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=repo,text=True).strip();print(json.dumps(row))
