# OLD whole slots

None named or acquired. Two slots remain available. Name a whole or near-whole acquisition before reading it.
