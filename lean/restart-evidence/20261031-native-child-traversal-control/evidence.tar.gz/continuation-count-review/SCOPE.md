# Scope

Source-only proof of the exact supplied32-line header. Complete processed length equals the original edge-list length. Stopped processed length is strictly less. Duplicate edges and arbitrary actual hook outcomes remain allowed.

Root owns all compilation, evaluation, native runs, Git, network, board, production and publication. No spawning. Own only this fresh directory. Keep all previous frozen bundles unchanged.

Reuse the exact previous manifestfa3d2b0ae5053ffba0c86bad12eb0b156549630c3916cb0a38efc20ab1bbb2e7. Retain provider pins and all versions. No global depth, native-work or public-prefix claim. No Haskell issue or fix is established.
