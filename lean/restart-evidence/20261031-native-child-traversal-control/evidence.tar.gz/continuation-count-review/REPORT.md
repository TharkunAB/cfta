# Actual continuation processed-count proof

Status: SOURCE ONLY. V2 is the selected uncompiled draft. No compiler, evaluator or native program was run.

## Exact contract

The public theorem statement is byte-identical to the supplied32-line header. A complete `SourcePruningEnumerationNativeContinuations.run` result has exactly as many processed receipts as its original `edges` input. A stopped result has strictly fewer processed receipts.

The existing operational arguments remain unchanged. The proof adds no `Normal`, `Ready`, `Trace`, `Complete`, future result, abstract transition, state certificate, distinctness or no-reset assumption. The edge list can contain duplicates. The actual hook can return any value of its existing result type.

`PUBLIC-CONTRACT.json` retains the exact statement and its hash. The original header remains byte-exact under `reused/ORIGINAL32L-HEADER.txt`.

## Proof source

`SourcePruningEnumerationNativeContinuationCount-v2-UNCOMPILED.lean` is94 lines. The proof uses induction on the original edge list. It generalizes only the actual caller and queries. It keeps the captured cache fixed, as the literal source recursion does.

- The empty list returns complete with zero processed receipts.
- A missing captured result stops with zero processed receipts.
- An unhandled captured receipt has no advancing endpoint and stops with zero processed receipts.
- A rejected receipt uses its actual native endpoint and continues on the tail.
- A stopped captured receipt uses the actual `NativeBranches.advance` result. No endpoint stops the fold. An actual endpoint continues on the tail.
- A complete captured receipt calls the actual hook. A stopped hook stops before the current receipt enters the processed prefix. A complete hook continues at its actual returned native endpoint.
- Each continuing branch applies the suffix induction hypothesis. Equality and strict inequality are preserved by `Nat.succ` when the current receipt enters the processed prefix.

The proof counts processed receipts. A processed receipt can be a rejection or a resumable stopped-child receipt. This is not a count of successful fragments or emitted outputs. A stopped current receipt stays outside the processed list.

V1 is retained. V2 gives each suffix length proposition an explicit type after the actual suffix case. No compiler failure was observed for either version. This source adjustment avoids relying on an earlier dependent hypothesis being rewritten by the case tactic. Both versions retain the exact same theorem statement.

## Boundary

This law bounds one literal finite alternative fold by its original input list. It applies through actual sibling cache restoration because the suffix consumes the original list tail. It does not bound work inside a recursive hook. A hook can emit many outputs.

The law does not derive a global original-request carrier, a sufficient recursive depth, a native-work budget, ordered-prefix completeness, public API correspondence, language coverage or Haskell correctness. It does not alter the earlier inventory's account of source replacement or normalization.

Root alone will compile, repair if needed, install and run the required checks. This report makes no checked-proof claim.

## Source provenance

The frozen provider inventory has manifest SHA256 `fa3d2b0ae5053ffba0c86bad12eb0b156549630c3916cb0a38efc20ab1bbb2e7`. Its93 files remain unchanged. Its exact header,72-line literal NativeContinuations tags/run cut, and metadata inspection helper were copied with manifest verification.

Two new bounded cuts supply the exact receipt constructors and `NativeBranches.advance`. No OLD whole or near-whole source was acquired. All source hashes, copies and cumulative unions are retained. Metadata verification checks the original source bytes and the exact selected lines. It does not evaluate the formalized program.

No Git, network, board, production edit or sub-agent was used. No Haskell source was edited or executed. No executable issue or Haskell fix was established. There is no FINDINGS candidate.
