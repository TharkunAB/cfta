from pathlib import Path
import json,subprocess
r=Path('/tmp/mcfta-native-child-traversal-control-20261031');repo=Path('/home/tritlo/Code/mcfta')
head=json.loads((r/'docs-commit.json').read_text())['commit'];destination='git@github.com:TharkunAB/cfta.git'
def local(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert local('rev-parse','HEAD')==head and local('branch','--show-current')=='formalize'
assert local('remote','get-url','origin')==destination
assert not local('status','--porcelain=v1')
ssh='ssh -o BatchMode=yes -o ConnectTimeout=20 -o ConnectionAttempts=1 -o HostName=ssh.github.com -p 443 -o HostKeyAlias=github.com'
base=['git','-c','core.sshCommand='+ssh]
for label,args in [('push',['push','origin','HEAD:refs/heads/formalize']),('readback',['ls-remote',destination,'refs/heads/formalize','refs/heads/main'])]:
 process=subprocess.run(base+args,cwd=repo,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/f'publication-{label}.raw.log').write_text(process.stdout);assert process.returncode==0,process.stdout
refs={line.split()[1]:line.split()[0] for line in (r/'publication-readback.raw.log').read_text().splitlines() if line.strip()}
assert refs['refs/heads/formalize']==head
tracking=local('rev-parse','refs/remotes/origin/formalize');assert tracking==head
assert not local('status','--porcelain=v1')
row={'head':head,'destination':destination,'ref':'refs/heads/formalize','refs':refs,'tracking':tracking,'readback_exact':True,'tracking_exact':True,'clean':True};(r/'checkpoint-publication.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
