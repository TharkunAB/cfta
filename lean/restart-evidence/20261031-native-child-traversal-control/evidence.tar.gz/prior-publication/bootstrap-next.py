from pathlib import Path
import json,shutil,subprocess
repo=Path('/home/tritlo/Code/mcfta');old=Path('/tmp/mcfta-terminal-and-prefix-observation-control-20261031');publication=Path('/tmp/mcfta-terminal-prefix-packaging-20261031');r=Path('/tmp/mcfta-native-child-traversal-control-20261031')
assert not r.exists();assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=repo,text=True).strip()
final=json.loads((publication/'final-publication.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head==final['head']
r.mkdir()
for before,after in [('final-strong-sources.json','prior-strong-sources.json'),('final-lean-sources.json','prior-lean-sources.json'),('final-haskell.json','prior-haskell-sources.json')]:shutil.copyfile(old/before,r/after)
shutil.copytree(old/'public-v3',r/'prior-public-readback');shutil.copyfile(old/'public-v3.lean',r/'prior-public-source.lean');shutil.copytree(publication,r/'prior-publication');shutil.copytree(old/'next-traversal-review',r/'traversal-review')
(r/'prior-documents').mkdir()
for name in ['NEXT-PROMPT.md','HANDOFF.md','FINDINGS.md']:shutil.copyfile(repo/name,r/'prior-documents'/name)
shutil.copyfile(repo/'lean/MicroCFTA/Audit.lean',r/'prior-Audit.lean')
for name in ['check-installed.py','run-check-batch.py','build-public.py','verify-current.py','verify-documents.py']:
 text=(old/name).read_text().replace(str(old),str(r)).replace('public-v3.lean','public-v2.lean').replace('notes-current-terminal-and-prefix-observation.md','notes-current-native-child-traversal.md');(r/name).write_text(text)
(r/'modules.json').write_text(json.dumps(['SourceCurrentAllocatedNativeStoredChildTraversal'])+'\n')
(r/'bootstrap.json').write_text(json.dumps({'head':head,'old_protected':562,'old_lean':4761,'old_haskell':835,'old_public':1227,'old_definitions':118,'fresh_pull_log':'prior-publication/next-phase-pull.raw.log','full_goal_complete':False},indent=2)+'\n')
(r/'SCOPE.md').write_text('Actual ChildTraversal.run native Stored from existing CURRENT resource entry gates plus entryStored. Derive recursive gates from actual singleton/cache observations; no future Context, Realized, Fits, outputStored, Trace, Paths or Complete supplier. Preserve the complete original-input/original-resource, both-worker, optimized-core, ordered-prefix/public-API/Haskell and older constructor/equality/exact-size/order/rank objective. Root alone executes serial4GiB/zero-swap5min checks, Git/network/board/production. No new Haskell finding or fix.\n')
print(json.dumps({'root':str(r),'head':head,'baseline_protected':562,'baseline_lean':4761,'baseline_public':1227}))
