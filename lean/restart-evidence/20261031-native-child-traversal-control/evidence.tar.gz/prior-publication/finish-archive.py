from pathlib import Path
import subprocess,json
p=Path('/tmp/mcfta-terminal-prefix-packaging-20261031');repo=Path('/home/tritlo/Code/mcfta');area='lean/restart-evidence/20261031-terminal-prefix-control';expected={area+'/'+n for n in ['README.md','evidence.tar.gz','manifest.json','package.py','verify.py']}
def local(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert local('rev-parse','HEAD')=='b157df98e326cf7eec46af354a534c833a8eef29'
assert not local('diff','--cached','--name-only')
for folder in ['restored-current','restored-owned','restored-documents']:assert (p/folder).is_dir()
subprocess.run(['git','add','--',area],cwd=repo,check=True);assert set(local('diff','--cached','--name-only').splitlines())==expected
result=subprocess.run(['git','commit','-m','Preserve terminal and prefix observation restart evidence'],cwd=repo,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(p/'archive-commit.raw.log').write_text(result.stdout);assert result.returncode==0,result.stdout
head=local('rev-parse','HEAD');(p/'archive-commit.json').write_text(json.dumps({'commit':head,'files':sorted(expected)},indent=2)+'\n')
destination='git@github.com:TharkunAB/cfta.git';assert local('remote','get-url','origin')==destination
ssh='ssh -o BatchMode=yes -o ConnectTimeout=20 -o ConnectionAttempts=1 -o HostName=ssh.github.com -p 443 -o HostKeyAlias=github.com';base=['git','-c','core.sshCommand='+ssh]
for i,args in enumerate([['push','origin','HEAD:refs/heads/formalize'],['ls-remote',destination,'refs/heads/formalize','refs/heads/main']]):
 result=subprocess.run(base+args,cwd=repo,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(p/f'publication-{i}.raw.log').write_text(result.stdout);assert result.returncode==0,result.stdout
refs={line.split()[1]:line.split()[0] for line in (p/'publication-1.raw.log').read_text().splitlines()};assert refs['refs/heads/formalize']==head
tracking=local('rev-parse','refs/remotes/origin/formalize');assert tracking==head and not local('status','--porcelain=v1')
row={'head':head,'docs_head':'b157df98e326cf7eec46af354a534c833a8eef29','source_head':'1e7a2b6f459ea72279ec576c23fe6b1027abe84f','destination':destination,'ref':'refs/heads/formalize','refs':refs,'tracking':tracking,'readback_exact':True,'tracking_exact':True,'clean':True};(p/'final-publication.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
