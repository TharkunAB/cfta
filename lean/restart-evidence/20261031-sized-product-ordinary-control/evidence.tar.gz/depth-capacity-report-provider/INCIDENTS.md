Source and navigation incidents

- A SourcePruningEnumeration*Height*.lean shell glob had no matching file. The actual height modules were located by rg --files.
- The guessed SourceRecursiveIntersectionDegree.lean module does not exist. The actual public degree laws are in KernelReturnDegree, KernelClosedDegree and NativeReturnDegree.
- Some declaration and filename navigation output was truncated. No complete proof claim relies on truncated output; selected contracts and exact sources were recovered as retained cuts/whole sources.
- The initial HeightOrderControlled14–43 cut selected private iterate helpers rather than Path. That acquired scope is retained. The correct Path82–96 and length bound180–190 are separately retained.
- Two intentional whole-file requests1–10000 clamped to179 and98. Two later bounded requests clamp369→360 and191→190. Every requested and actual endpoint is recorded.
- No Lean candidate was created, no compiler/evaluator was run, and no compiler result is inferred from source/hash inspection.
- Historical memory supplied locators and caution only. Current claims use current source hashes and complete selected headers.
