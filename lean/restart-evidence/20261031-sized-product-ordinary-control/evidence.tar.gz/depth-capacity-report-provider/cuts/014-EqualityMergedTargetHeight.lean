namespace MicroCFTA.EqualityMergedTargetHeight
open InternedConstructorTemplates InternedRecordCoherence InternedProbeProvenance
open InternedNestedFacts InternedNestedProvenance InternedEdgeResidency InternedShallowHeap
open MergedPhysicalWarmup MergedSourceComparison MergedColdMerge MergedColdMergeMapFacts
open MergedOrdinaryHeight Language

/-- Finite ordinary trees stop only at empty values and contain no recursive or union records. -/
inductive Tree : Value Symbol Guard → Prop where
  | empty : Tree .empty
  | node (entry) (edges : List (EdgeValue Symbol Guard)) (depth free)
      (children : ∀ edge ∈ edges, ∀ child ∈ edge.children, Tree child) : Tree (.node entry edges depth free)

/-- Ordinary-tree roots never enter the recursive-union column branch. -/
