namespace MicroCFTA.InternedOpenDepthReadback
open Cache InternedConstructorTemplates InternedRecordCoherence InternedProbeProvenance
open InternedNestedConstruction (finish)
open InternedStoredPlanBinderDepth
open InternedBinderProtocol (NodeKey)

/-- One complete Mu has equal actual body and Depth-probe open depth. -/
def Correct (body depth : Value Symbol Guard) : Prop := valueDepth body = valueDepth depth

/-- Every complete Mu in the exact cache retains the body/probe open-depth equality. -/
def Heap (state : State Symbol Guard) : Prop :=
  ∀ key entry body depth ordinary, state.nodeRecords key = some (.mu entry body depth ordinary) → Correct body depth

