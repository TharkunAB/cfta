theorem merge_height [DecidableEq (EdgeKey Symbol Guard)] [DecidableEq Symbol]
    (grouping : List (EdgeValue Symbol Guard) → List (List (EdgeValue Symbol Guard)))
    (correct : ∀ edges, MergedPhysicalGroupRoot.Grouping edges (grouping edges))
    (clear : Guard → Bool) (top : Guard) (input result : Value Symbol Guard)
    (tree : Tree input) (done : EqualityMergedTargetShape.Merge grouping clear top input result) :
    Tree result ∧ height result ≤ height input := by
  obtain ⟨ordinary, comparison, before, after, facts, prepared, available, done⟩ := done
  exact worker_height grouping correct clear top ordinary comparison input before result after facts prepared available tree done

end MicroCFTA.EqualityMergedTargetHeight
