theorem worker_height [DecidableEq (EdgeKey Symbol Guard)] [DecidableEq Symbol]
    (grouping : List (EdgeValue Symbol Guard) → List (List (EdgeValue Symbol Guard)))
    (correct : ∀ edges, MergedPhysicalGroupRoot.Grouping edges (grouping edges))
    (clear : Guard → Bool) (top : Guard) (ordinary comparison : Nat) :
    HeightCall (worker grouping clear top ordinary comparison) := by
  induction ordinary with
  | zero =>
      intro input before result after facts prepared available tree done
      cases tree with
      | empty => cases done; exact ⟨.empty, Nat.le_refl _⟩
      | node entry edges depth free children =>
          by_cases closed : free = []
          · simp [worker, closed] at done
          · simp only [worker, closed, ↓reduceIte, MergedColdMerge.pure, Result.done.injEq] at done
            rcases done with ⟨rfl, rfl⟩
            exact ⟨.node entry edges depth free children, Nat.le_refl _⟩
  | succ ordinary ih =>
      intro input before result after facts prepared available tree done
      cases tree with
      | empty => cases done; exact ⟨.empty, Nat.le_refl _⟩
