def iterate (next : Nat → Nat) : Nat → Nat → Nat
  | 0, value => value
  | count + 1, value => iterate next count (next value)

private theorem iterate_ge (next : Nat → Nat) (grows : ∀ value, value ≤ next value)
    (count value : Nat) : value ≤ iterate next count value := by
  induction count generalizing value with
  | zero => exact Nat.le_refl _
  | succ count ih => exact Nat.le_trans (grows value) (ih (next value))

private theorem iterate_mono (next : Nat → Nat)
    (mono : ∀ {first last}, first ≤ last → next first ≤ next last) (count : Nat)
    {first last : Nat} (increase : first ≤ last) : iterate next count first ≤ iterate next count last := by
  induction count generalizing first last with
  | zero => exact increase
  | succ count ih => exact ih (mono increase)

private theorem iterate_add (next : Nat → Nat) (first last value : Nat) :
    iterate next (first + last) value = iterate next last (iterate next first value) := by
  induction first generalizing value with
  | zero => simp only [Nat.zero_add, iterate]
  | succ first ih => simpa only [Nat.succ_add, iterate] using ih (next value)

private theorem iterate_count_mono (next : Nat → Nat) (grows : ∀ value, value ≤ next value)
    {first last : Nat} (counts : first ≤ last) (value : Nat) :
    iterate next first value ≤ iterate next last value := by
  obtain ⟨extra, rfl⟩ := Nat.exists_eq_add_of_le counts
  rw [iterate_add]
  exact iterate_ge next grows extra _

