def HeightCall (call : Value Symbol Guard → Action Symbol Guard (Value Symbol Guard)) : Prop :=
  ∀ input before result after, Facts before → Prepared before → Available before input → Tree input →
    call input before = .done result after → Tree result ∧ height result ≤ height input

/-- A bounded returned ordinary value retains its actual cache availability. -/
def Bounded (limit : Nat) (state : State Symbol Guard) (value : Value Symbol Guard) : Prop :=
  Available state value ∧ Tree value ∧ height value ≤ limit

/-- Cache extensions preserve ordinary shape and height because complete values are immutable. -/
theorem bounded_grows (limit : Nat) (before after : State Symbol Guard) (extension : Extension before after)
    (value : Value Symbol Guard) (bounded : Bounded limit before value) : Bounded limit after value :=
  ⟨extension.available value bounded.1, bounded.2⟩

/-- Ordered recursive calls preserve a common height bound on their actual output list. -/
