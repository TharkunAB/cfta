
/-- The initial controlled-vector majorant bounds the number of actual strict steps. -/
theorem Path.length_le {control : Nat → Nat}
    (mono : ∀ {first last}, first ≤ last → control first ≤ control last)
    (grows : ∀ value, value < control value)
    {dimension firstControl lastControl length : Nat} {first last : Nat → Nat}
    (actual : Path control dimension first firstControl last lastControl length) :
    length ≤ majorant control dimension firstControl :=
  Nat.le_trans (Nat.le_trans (Nat.le_add_left _ _) actual.elapsed_le) (actual.final_le mono grows)

end MicroCFTA.HeightOrderControlled
