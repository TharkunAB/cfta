
/-- A finite descending vector path retains each state's own numeric control. -/
inductive Path (control : Nat → Nat) (dimension : Nat) :
    (Nat → Nat) → Nat → (Nat → Nat) → Nat → Nat → Prop where
  /-- An empty path checks only its initial coordinate bounds. -/
  | refl (bounded : ∀ index, index < dimension → first index ≤ firstControl) :
      Path control dimension first firstControl first firstControl 0
  /-- One strict vector step increases control within the stated function. -/
  | step (bounded : ∀ index, index < dimension → first index ≤ firstControl)
      (decrease : HeightOrder.Below dimension middle first)
      (progress : firstControl < middleControl) (controlled : middleControl ≤ control firstControl)
      (tail : Path control dimension middle middleControl last lastControl length) :
      Path control dimension first firstControl last lastControl (length + 1)

/-- The initial vector is bounded by its own control number. -/
