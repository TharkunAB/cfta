theorem closed_roots_degree
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (source : InternedConstructorTemplates.State Symbol Guard) (facts : Facts source)
    (holds : Guard → Language.Term Symbol → Bool) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (left right : Value Symbol Guard) (leftOriginal : Original left) (rightOriginal : Original right)
    (leftAvailable : Available source left) (rightAvailable : Available source right)
    (leftClosed : left.free = []) (rightClosed : right.free = []) :
    ∃ bound, ∀ (fuel : Nat) (state after : Machine Symbol Guard),
      Valid state → Grows source state.heap → Extends source.nodes.issued state.heap.nodes.issued →
      SemanticHeap state.heap → InternedOpenDepthReadback.Heap state.heap →
      ∀ value, execute emptyGuard conjoin fuel IntersectionEmptyDomain.emptyDomain left right state = .done value after →
      SemanticHeap after.heap ∧ InternedOpenDepthReadback.Heap after.heap ∧ valueDepth value ≤ bound := by
  have scope := initial_scope source left right leftOriginal rightOriginal leftAvailable rightAvailable
  have complete := SourceRecursiveIntersectionRequestProgress.initial_complete source facts holds left right
    leftOriginal rightOriginal leftAvailable rightAvailable leftClosed rightClosed
  let limit := maximumDepth (InternedRecordCoherence.nodeInventory source) + 1
  have bounded : InternedMuDepthInventory.Bounded source limit := InternedMuDepthInventory.initial_bounded source facts
  refine ⟨limit + requiredFuel (view source holds) (nodeSemantic ⟨IntersectionEmptyDomain.emptyDomain, left, right⟩) complete, ?_⟩
  intro fuel state after valid growth history semantic opened value done
  exact node_result_degree source facts limit bounded holds emptyGuard conjoin fuel
    ⟨IntersectionEmptyDomain.emptyDomain, left, right⟩ scope complete state after valid
    ⟨empty_domain state, leftAvailable.grows source state.heap growth history,
      rightAvailable.grows source state.heap growth history⟩
