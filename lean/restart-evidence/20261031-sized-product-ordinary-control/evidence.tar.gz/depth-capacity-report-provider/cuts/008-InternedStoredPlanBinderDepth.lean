termination_by expressions => sizeOf expressions
end

mutual
/-- Count open stored binders while treating closed captured records as constants. -/
def valueDepth (value : Value Symbol Guard) : Nat :=
  if value.free.isEmpty then 0 else
  match value with
  | .empty | .reference _ => 0
  | .node _ edges .. => edgesDepth edges
  | .union _ members .. => manyDepth members
  | .mu _ body .. => 1 + valueDepth body
