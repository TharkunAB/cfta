
/-- Closed captured records emit no binder instruction and have measure zero. -/
theorem closed_zero (value : Value Symbol Guard) (closed : value.free = []) : valueDepth value = 0 := by
  rw [valueDepth.eq_def, closed]
  rfl

mutual
