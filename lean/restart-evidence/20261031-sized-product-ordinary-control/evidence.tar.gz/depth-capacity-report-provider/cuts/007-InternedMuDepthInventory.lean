    exact rankAt_record state coherent entry body depth ordinary present

/-- Every complete Mu body lies below a fixed finite depth bound. -/
def Bounded (state : State Symbol Guard) (limit : Nat) : Prop :=
  ∀ key entry body depth ordinary, state.nodeRecords key = some (.mu entry body depth ordinary) → valueDepth body < limit

/-- The finite initial inventory supplies an upper bound without bounding future cached depth. -/
theorem initial_bounded (state : State Symbol Guard) (facts : InternedNestedFacts.Facts state) :
    Bounded state (maximumDepth (nodeInventory state) + 1) := by
  intro key entry body depth ordinary present
  have available := facts.cached.nodes key _ present
  have member := MergedPhysicalWarmup.inventory_complete state facts.coherent key _ present
  have large := (maximumDepth_exact _ _).mp (Nat.le_refl _) (.mu entry body depth ordinary) member
  have small := value_le_cached body state facts.coherent (available.children body (by simp [children]))
  simp only [Value.depth] at large
  omega

/-- A strict new-body allocation bound preserves the fixed maximum degree. -/
