  match value with
  | .empty | .reference _ => 0
  | .node _ edges .. => edgesDepth edges
  | .union _ members .. => manyDepth members
  | .mu _ body .. => 1 + valueDepth body
termination_by sizeOf value

/-- Original ordered value lists contribute their maximum open binder depth. -/
def manyDepth : List (Value Symbol Guard) → Nat
  | [] => 0
  | first :: rest => max (valueDepth first) (manyDepth rest)
termination_by values => sizeOf values

/-- Actual edge children determine the open binder depth of their stored plan. -/
def edgesDepth : List (EdgeValue Symbol Guard) → Nat
  | [] => 0
  | .mk _ children :: rest => max (manyDepth children) (edgesDepth rest)
termination_by edges => sizeOf edges
end

/-- Measure the actual body plan that one outer Mu unfolding executes. -/
def bodyDepth : Value Symbol Guard → Nat
  | .mu _ body .. => valueDepth body
  | _ => 0

