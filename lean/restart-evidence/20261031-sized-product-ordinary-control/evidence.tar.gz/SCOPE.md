# Original size-product and ordinary construction producer

The full goal covers original public inputs, sound outputs, intended finite ordered prefixes under exact configured order and stops, sufficient ORIGINAL resources, optimized interned core, BOTH workers, Prefix/table/count/checkpoint/public adapters, Haskell correspondence, and the earlier constructor/equality/exact-node-count/size-order/rank/unrank work.

This phase checks generated allocation rank, literal Integer allocation correspondence under an original embedded Nat minimum table, and ranked-DAG unfolding with actual ordinary fresh-build domain/height certificates. It does not claim actual minimumSizes production, reachable/SCC/memo/fromRows allocation correspondence, restriction transport, sufficient global depth, exact public ordered list identity or Haskell correspondence without proofs.

Preserve the previous correction: the finite original carrier contains constraint/SCS/projection address paths. Numeric forecast magnitudes can depend on supplied depth. The carrier does not bound term depth, recursion or work traces. Chosen-depth mathematical width already exists; common successful original depth remains open.

All current input and resource gates stay explicit. No future successful output, depth, Trace, Paths, Complete or native-domain supplier replaces original admission. Source-only candidates remain UNCOMPILED until Root verifies them. Root alone runs serial capped compiler jobs, native programs, Git/network/board and production edits. No Haskell change or native execution is planned in this phase.
