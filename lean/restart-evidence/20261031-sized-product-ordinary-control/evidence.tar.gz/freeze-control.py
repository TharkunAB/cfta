from pathlib import Path
import datetime,hashlib,json,subprocess
r=Path('/tmp/mcfta-sized-product-ordinary-control-20261031');repo=Path('/home/tritlo/Code/mcfta')
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert not (r/'FROZEN.json').exists();assert git('branch','--show-current')=='formalize';assert git('rev-parse','HEAD')=='83bcfae8e1257d77c07ef04bff71a3423d650bad';assert not git('status','--porcelain=v1');assert git('rev-parse','refs/remotes/origin/formalize')==git('rev-parse','HEAD')
(r/'freeze-control.py').write_bytes(Path(__file__).read_bytes())
for name,helper in [('current','verify-current.py'),('owned','verify-owned.py'),('documents','verify-documents.py'),('peer-replay','verify-peer-replay.py')]:
 result=subprocess.run(['python3',str(r/helper)],capture_output=True);(r/f'pre-freeze-{name}.raw.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0,(name,result.stdout,result.stderr)
summary=json.loads((r/'verification-summary.json').read_text());assert (summary['commands'],summary['passed'],summary['failed'],summary['input_snapshots'])==(26,15,11,82)
assert json.loads((r/'owned-verification.json').read_text())['status']=='pass';assert len(json.loads((r/'owners.json').read_text()))==12
payloads=[]
for source in sorted(r.rglob('*')):
 if source.is_file():
  assert not source.is_symlink();data=source.read_bytes();payloads.append({'path':str(source.relative_to(r)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
record={'scope':'Complete size-product ordinary construction control area','frozen_at':datetime.datetime.now().astimezone().isoformat(),'write_halt':True,'goal_turn':'progress','full_objective_complete':False,'source_head':'8bb5f94f512f6a6ff6a4b775da4f6fbd8bfe82e0','docs_head':'83bcfae8e1257d77c07ef04bff71a3423d650bad','owners':12,'payload_files':len(payloads),'payload_bytes':sum(a['bytes'] for a in payloads),'verification':summary,'payloads':payloads};(r/'FROZEN.json').write_text(json.dumps(record,indent=2)+'\n')
for source in r.rglob('*'):
 if source.is_file():source.chmod(source.stat().st_mode&~0o222)
assert all(not(source.stat().st_mode&0o222) for source in r.rglob('*') if source.is_file())
print(json.dumps({k:record[k] for k in ['write_halt','goal_turn','source_head','docs_head','owners','payload_files','payload_bytes']}))
