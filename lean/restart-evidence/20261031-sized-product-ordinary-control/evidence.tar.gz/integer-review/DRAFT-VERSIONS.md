# Draft versions

V1 is retained unchanged. V2 reuses the acquired existing filter_eq_self and
filter_eq_nil_iff laws in the two private filter helpers. It removes one
redundant local bound. It adds splits_negative from the literal Integer total.
All V1 public headers remain unchanged. No draft was compiled or evaluated.
