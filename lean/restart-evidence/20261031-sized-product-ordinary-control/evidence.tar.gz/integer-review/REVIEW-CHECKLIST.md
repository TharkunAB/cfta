# Source-only review

- Integer arithmetic is unbounded. The interval permits negative values.
- The interval uses ascending offsets and preserves source enumeration order.
- Both interval bounds follow from membership, and every in-bound value occurs.
- Exact list equality preserves multiplicity. No set conversion is used.
- The source child list is traversed in its original order.
- The source minimum lookups and failed-lookup results are retained.
- The model uses a Nat table embedded at the Integer arithmetic boundary.
- The sum cast is derived by list induction, not supplied as an input.
- The current guard derives each recursive subtraction conversion.
- No future recursive result, output, resource, or invariant is supplied.
- Negative source totals are handled directly by the generated empty interval.
- Actual minimumSizes production and source/native row transport remain open.
- Only the baseline allocations definition is needed by the new main proof.
- The baseline and extension require Root evaluation before any checked claim.
