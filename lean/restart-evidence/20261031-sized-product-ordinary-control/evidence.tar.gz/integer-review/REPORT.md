# Integer allocation correspondence draft

The candidate models the source ascending Integer interval and recursive splits.
It proves exact ordered-list equality with the existing Nat allocation core under
an embedded Nat minimum table and an embedded Nat total. It derives interval
membership and length. It accepts no supplied allocation sum or decrease fact.
The candidate is SOURCE-ONLY and UNCOMPILED. Root must check it before use.

## Candidate and baseline

Use SourceSizedPrefixProductInteger-v2-UNCOMPILED.lean.
It has 208 lines and 9787 bytes.
SHA256: 825fc1e3b517244c6b693df11d0a701a8bf48164bc8f01cec0d2cb03f5e4ca10.
V1 is retained. DRAFT-VERSIONS.md states all V2 changes.

The candidate imports MicroCFTA.SourceSizedPrefixProductRank provisionally.
Its retained baseline is the frozen 157-line V2, SHA
40326b095eddf260c6178537757b2b0cb9b8c8479654fa028f0ddf6620715d80.
Root has not reported a kernel check of that baseline for this task.
The new correspondence proof uses its allocations definition. It does not use
allocations_spec or accept that theorem's conclusions as premises.

## Literal numeric model

integerInterval lower upper is the list of lower + offset for ascending natural
offsets from zero to the closed-interval length. Its length is
(upper - lower + 1).toNat. It includes negative Integer values when required.
integerInterval_mem proves exact lower and upper bounds in both directions.

splits follows the actual Prefix.hs recursive list comprehension. It tests an
empty child list against total zero. For a nonempty child list, it performs the
same current and remaining minimum lookups. Failed lookups give no result.
Successful lookup values are embedded into Int. The interval ends at the Integer
total minus the sum of the embedded remaining minima. The recursion subtracts
the actual Integer first part and prepends that part to each recursive result.

The lookup representation is the baseline minimum : State -> Option Nat.
The model embeds successful lookup values at the arithmetic boundary. It models
the source specifically under that embedded table. It does not add an arbitrary
Integer-valued lookup API or claim that the actual minimumSizes producer has
already supplied such a table. This choice avoids a second lookup/traverse API.
The unused initial Control.mapM declaration locator is retained in the ledger.

## Candidate statements

- integerInterval_length gives the exact interval length.
- integerInterval_mem derives literal interval membership and bounds.
- integerInterval_embedded proves the ascending Integer interval equals the
  filtered Nat range as a list. No set conversion or permutation is used.
- splits_negative derives an empty result for every negative Integer total
  under the embedded Nat minimum table. It requires no positive-minimum premise.
- splits_embedded proves literal Integer splits equals allocations projected
  to Integer parts as an exact list. The equality preserves order and multiplicity.

The last proof uses structural induction on the original child list. At an
accepted first part, the current numeric guard derives its bound and the exact
Integer subtraction/Nat subtraction equality. Recursive admission is derived
inside the proof. No future recursive result or resource certificate is supplied.
The old allocation retains original child-state order. The projected part lists
therefore retain the source positional order for its later zipWith operation.

The negative-total law supplies the numeric empty-splits fact for the source
rowOf-at-zero case. A complete source-row correspondence theorem is not claimed.

## Existing machinery

The proof splits Nat ranges with the existing range'_append_1 theorem and reads
range' membership with mem_range'_1. It reuses filter_eq_self, filter_eq_nil_iff,
map_flatMap, and flatMap_map. All acquired stdlib cuts match Root's confirmed
active Lean4.34.1 source. No alternative desired-language model was introduced.

## Remaining obligations

1. Model the actual Ordinary/Table.minimumSizes producer and derive the embedded
   original nonnegative table. This draft does not assume it has been done.
2. Instantiate the source equalSizes implementation and relate row generation,
   including preserved symbols, full constraints, and ordered child states.
3. Model reachable explore/mkFTA/trim construction and fromRows/fromFTA native
   constructor reification. The separate structural lane owns that inventory.
4. Derive sufficient original resources and requested-prefix adequacy for both
   actual workers, exact configured policies, and public/Haskell adapters.

No Haskell execution or defect/fix claim was made. FINDINGS needs no defect entry.
Unknown and empty-language results remain distinct. No public policy was changed.

## Provenance

The actual Prefix.hs575-628 cut has full-source SHA
4acc51175aa2c84c1c54c188b2471d526dabb521db8208fbaf62522a9bca9a26.
acquisitions.json retains every exact source/copy pin and acquired line set.
cumulative-source-unions.json retains the union for each original path.
The frozen baseline is the only OLD whole ORIGINAL path: slot1. Slot2 is unused.
All other bodies are bounded named cuts. Filename discovery read no source body.
Both versions, all stderr, and the corrected message-evidence note are retained.
No compiler, evaluator, Haskell/native run, Git, network, board, or spawn was used.
