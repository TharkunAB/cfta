# Integer allocation correspondence

Started 2026-10-31 02:49 CET. SOURCE-ONLY. Root owns execution.
Model literal ascending Integer intervals and source recursive splits.
Prove exact ordered list equality with the embedded current Nat allocation core.
Preserve multiplicity and original child order. No supplied sum/decrease facts.
Keep actual minimumSizes production, equalSizes, reachable table, and native
reification separate. No production edits, compiler/evaluator, Haskell/native,
Git/network/board/spawn. At most TWO named OLD whole/near-whole ORIGINAL paths.
Slot1: the frozen current 157-line product-rank draft. Slot2 remains unused.
Other source acquisitions use exact named bounded cuts and declaration locators.
