# Exact source correspondence

| Actual Prefix.hs575-628 expression | Candidate expression | Status |
| --- | --- | --- |
| [smallest .. total - sum others] | integerInterval with closed length and ascending offset map | Exact arithmetic interval model; membership and length proofs drafted. |
| Current minimum lookup and traverse of remaining minima | Same Nat lookup/traverse cases, successful values embedded to Int | Embedded-table scope; actual minimumSizes table producer remains open. |
| first : sizes in source list comprehension | first :: tail in splits.flatMap/map | Same recursive list order and multiplicity. |
| splits rest (total - first) | Integer subtraction in splits | Conversion to a Nat recursive total is derived from each accepted current guard. |
| Source list of Integer part lists | allocations.map castParts | Exact list equality drafted in splits_embedded. |
| Source rowOf state 0 uses splits children (-1) | splits_negative | Numeric empty-splits fact drafted; row correspondence remains open. |
| Source zipWith children/parts | Existing allocation original-state order plus exact part-list equality | Original positional order retained; literal row theorem remains open. |
| equalSizes constraint parts | No implementation added | Still an original numeric constraint-filter correspondence obligation. |
| explore, mkFTA, trim, fromFTA/fromRows | No implementation added | Reachable/native construction remains open. |

All proof statuses are SOURCE-ONLY and UNCOMPILED. No Haskell equivalence or
kernel-check success is claimed here. Root must check the complete candidate.
