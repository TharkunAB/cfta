# Original depth and native construction: next producer

Status: source-only inventory and one proposed header. No compiler, evaluator,
native program, Git, network, board, production edit or child agent was used.
No construction producer or sufficient-depth theorem was proved here.

## Current strongest closed result

Both actual recursive workers have a stable outcome at every SUPPLIED finite
recursive depth under their existing original entry/resource gates. Their
recorded constraint/SCS paths lie in one finite ORIGINAL carrier, independent
of that depth. The carrier contains the initial stored constraint paths and
the original alphabet's projected equality paths, including their suffixes.
These are constraint address paths. They are not worker execution traces,
generated term-depth bounds or recursive-depth bounds. Exact resource
forecasts are retained. Their relevant projected constraint paths satisfy the
carrier property; numeric forecast magnitudes can still depend on depth.
Work bounds and numeric reservations can also depend on depth. A stable
outcome can still stop or exhaust recursive capacity.

The exact paired headers are:

- ExecutionOriginalPaths.Native.run_original_finite_complete_resources_paths.
- ExecutionOriginalPaths.Prepared.run_original_finite_complete_resources_paths.

Both take original Packet, Fits, Heap, selected-edge membership/length,
suspended-mass ceiling, depth-specific Reserved, original normalized literals
and seed inclusion in the original alphabet. They produce the work bound,
actual outcome, OutcomeResources and actual whole-worker execution paths.
No future StatePaths, Complete, trace, stage or chosen-target equation remains
an input. The original carrier is independent of supplied recursiveFuel.

The construction-facing native_run and prepared_run in ConstructedResources
are stronger original-entry producers. They start with finite nested Syntax,
a valid original cache, cached original equalities and empty metadata.pending.
For each supplied recursiveFuel they build the heap, compute the initial seed,
prepare the cache, compute mathematical word width from final(depth,seed,0),
produce the initial Packet, and derive a stable actual resource outcome.
Sufficient width is therefore already produced for each chosen depth.
The missing component is selection of sufficient original depth, not a new
per-chosen-depth width-existence lemma.

PUBLIC-HEADERS.md/json retain the exact four statements with source ranges and
header hashes. The whole sources have SHA256 954dfc48016d33c6afe7ac5423a47d5f6ebb252094214d7a36e9858ec05f073f
and b460067b8fcee75bc55b020e5583e095b1975a7f365db60d43555d84bb36b566.

PreparedFiniteOutputPrefix.run_finite_resources_outputs_prefix already derives
ordered operational output inclusion between two independently admitted
depths from original resource inputs. It does not produce the requested
accepted-term prefix. A decision=None output retains some metadata and a raw
cache; this is not by itself accepted-term production. No global completion
or coverage claim follows from operational complete or List.IsPrefix.

## The actual missing original-input connection

The current construction-facing worker inputs have no public Size or
preorder-token-prefix argument. They accept arbitrary nested Syntax and
internal stop/order functions. A size rank cannot be attached to that generic
signature without proving the actual public-query adapter.

The existing SourceSizedPublicContracts already gives a declarative size
specification. finite_class is ClassEvaluation of a finite size class.
enumeration_exact relates through(api.terms,bound) to original acceptance and
nodeSize<=bound; enumeration_complete covers every accepted finite term.
Those laws use publicSized success and their original ActiveOption gates.
They do not describe a native root or native allocation.

SourceSizedPreprocessing.Input has a finite original state list, root and
ordered annotated rows. publicSized selects optimizedApi or referenceApi over
sorted original rows. It does not construct an acyclic native source.
Reference classes recurse on requested size. A finite reference class does
not imply that the original graph, a stored Mu, a Union or an inherited field
value is recursively finite ordinary.

The standard bounded equality decision route provides a concrete structural
producer to prove. Prefix.bySize575–628 creates state/size pairs. Its generated
children have budgets that sum to parent size minus one; root rows cover
sizes1..bound. The new numeric review owns the exact generated-row rank proof.
The numeric rank does not need a positive minimum-table assumption. Actual
minimum-table, integer-to-natural, source-order and filtering correspondence
remain explicit obligations there.

The actual bounded product goes through trim and Interned.fromFTA. The latter
calls fromRows. fromRows computes reachable positional rows and SCC labels.
Its child dispatch emits Rec only for a bound child in the same component.
Its build wraps createMu only if the body refers to that state. Each body is
built with mkNode from the original ordered guarded rows.

If the actual product rows have a strictly decreasing original size rank,
they have no constructor dependency cycle. The same-component reference and
Mu cases can then be excluded from the literal reifier. This gives a concrete
route to a recursively finite ordinary native root. The route does not use a
future Native trace or a supplied output-domain invariant.

## First actionable lemma

NEXT-CONSTRUCTION-HEADER-ONLY.txt states bounded_deciding_product_domain.
Its only query arguments are the original finite row input and original size
bound. It produces literal modeled build completion, Ready, Available,
closedness, SourceCurrentAllocatedFiniteOrdinaryDomain.Node, and an ordinary
height bound from that original query.

The required expression adapter is genuinely missing at this boundary. The
repository search found SourceOrderedBinderImport, which models completed
positional rows, SCC labels and memo schedule. Its own module contract
explicitly excludes SCC extraction, constructor semantics and GHC evaluation
correspondence. SourceFiniteRebuild also leaves native identity/allocation
and fromFTA readback as separate adapters. These existing models can support
the new producer. They are not already that producer.

The new expression definition must model the actual bySize/trim/fromRows
route, or prove a constructor-level correspondence from it. It cannot simply
choose a convenient finite language with the desired terms. This is an
original-input definition because it depends only on the original rows/root,
constraints and size query. It contains no future worker states or outcomes.
The proposed header has not been elaborated and has no proof body.

The synthetic-root rank permits the safe height bound bound+1. This is an
ordinary constructor height bound, not the cached closed binder depth.
Closed binder depth0 does not establish this property.

## Prefix restriction and structural scope

Literal Template.restrict108–128 preserves a finite ordinary input by row
filtering and recursive child restriction. Hole and empty-prefix cases retain
the input. It constructs Node values and does not introduce a Mu or Union.
Prefix.restrictAt629–646 descends a finite requested path, rebuilds rows with
restricted children, and preserves other children. An actual domain/height
preservation proof is still required before transporting the first producer
to Enumeration.terms at the complete deciding route. No such proof is claimed.

This route-specific result is not a consequence for arbitrary nested Syntax.
Syntax permits union, binder, and supplied child expressions. Its actual
build uses makeUnion and binder requests. The ordinary construction gates
permit these forms and do not imply the recursively finite domain.

An opaque field-pool or ambient value can contain Mu/Union despite availability
and closedness. It needs its own structural admission, or proof that the
actual adapter reifies its whole graph through the bounded size product.
The ranked-fromFTA route has no opaque native-child supplier. Do not transfer
its conclusion to a bypassing field-pool path without that source proof.
This is a scope boundary, not a new Haskell defect or counterexample.

## How the producer can support actual worker progress

The relevant existing structural predicate is the mutual Node/Rows/Children
in SourceCurrentAllocatedFiniteOrdinaryDomain. Node contains only empty and
ordinary node values, recursively over every complete row child. It excludes
references, Mu and Union. Node.child_lt supplies strict ordinary child height.
The native Stored certificate for empty-seen queries gives result domain and
height bounded by BOTH domain operands. It does not apply to an arbitrary
Mu opponent just because the other operand is finite.

A candidate proof can use these facts as follows:

1. Derive the initial finite-ordinary payload and original height/arity/path
   bounds from the actual bounded decision construction. Derive the standard
   order, stop, templates and guard-admission gates from the actual adapter.
2. Transport domains through actual filtering, entry, staged children, native
   incoming intersections and finalization. Use the actual Stored certificate
   only after deriving BOTH operand domains and the empty-seen request. Raw
   handle renewal need not itself decrease a measure if height cannot rise.
3. Under the derived domain, recursiveBoundary=false. The parked repeated-key
   branch must be excluded from the literal checkRepeated observation. This
   exclusion must be derived; it is not a no-parked continuation premise.
   Prepared ordinary exposure is its literal identity branch.
4. A child-size argument still does not cover every recursive re-entry. The
   Prepared terminal/opaque branch can pass a hole through its Left callback
   and restart at the same slot. Actual incoming replacement can preserve
   height. Terminal obligations, representative joins and raw bucket work
   need a second finite charge derived from original path/slot data. Do not
   claim strict height decrease on every resume call.
5. Ordinary complete edges finalize the selected slot, then the Left callback
   frames actual recordTypes output and restarts at predecessor fuel. Neutral
   recording preserves stored control but supplies no strict progress.
6. Use a stack of finite sibling/child frames for the complete ordered scan.
   A suffix restores the captured cache while advancing the native endpoint.
   The checked processed-count law pays each direct original edge occurrence,
   including duplicates. A global scalar pending-size or row measure can rise
   at snapshot restoration. Each restored branch needs its own remaining
   frame budget. Account for every earlier alternative and staged child.

A useful global rank would combine finite ordinary constructor potential,
remaining terminal/alias/path work, and the finite suffix stack. Its initial
budget must be produced from the original query. The same-height replacement,
unknown-slot allocation, raw SCS multiplicity and actual public adapter
connections are still missing. A geometric height/arity estimate alone is
not yet a bound on all enumeration selections.

For general Mu/Union sources outside the bounded product, the existing local
alternative is finite unused trie shapes per physical handle plus normalized
root-edge loss. The shape key keeps its physical node ID. Incoming/native
rewrites can renew that ID and reset the row source. The number of such
renewals still has no global original-input producer. The prior frozen
capacity report and later checked row laws do not close it.

## Policy and objective boundaries

Keep four claims separate: a mathematical finite accepted prefix; finite
generated partial work before it; standard positive size ordering; bounded
preorder-token Prefix completions. The independent policy review pins their
actual routes and existing reference contracts. Optional custom-cost
starvation does not refute the standard size-bounded Prefix contract.

The actual worker preference is a safe hint. EnumerationPureSelection.next
calls EnumerationState.pickNext, which falls back to the first offered
variable when the hint returns None or an invalid ID. An early decision=None
comes from the explicit stop rule on a nonempty candidate list. It does not
come from preference=None. Root corrected the earlier contrary suggestion.
Standard policy meaning must still be linked to accepted terms explicitly.

This inventory does not add an original-language nonemptiness hypothesis or
assume requested coverage. For bounded completions, an empty accepted class
is a valid finite answer. A static original size rank is available in the
specific generated product. For unrestricted cost/policy routes, any needed
original local-finiteness/productivity condition must describe original data
and generated partial work, not posit a successful future worker trace or the
desired prefix. The policy review owns that distinction.

For an unbounded request for the first n accepted terms, a precise original
semantic condition is HasSizePrefix(input,n): there is a size B with at least
n distinct finite terms satisfying the original Accepts predicate and
nodeSize<=B. This is a proposed name, not an existing checked definition.
It states that the requested semantic prefix exists under positive-size
ordering. It does not posit any future worker result or bound the generated
partial work. A fixed-B bounded-completions query needs no such hypothesis;
an empty class or fewer than n results remains valid. Arbitrary custom-cost
routes additionally need local finiteness of generated partial work below
the requested cost key. Semantic availability alone does not provide it.

The full original-input objective remains open: sufficient recursive depth,
all earlier alternatives/staged children, both modeled workers, accepted
ordered coverage, optimized core, public Prefix/table/count/checkpoint,
Haskell/host interner/container/laziness correspondence, and the older
constructor/equality/node-count/size-order/rank-unrank integration. This first
construction producer is one necessary connection, not a replacement goal.

## Evidence and limits

The two root handoff snapshots changed during this inventory. Their retained
cuts keep their exact acquisition hashes. Metadata verification found every
other acquired source, including all Lean and Haskell modules, unchanged.
The report bases its formal statement on the exact paired headers and pinned
whole-worker canonical note. It does not treat the old root handoff snapshots
as the final R12 status.

Two OLD whole sources were named after filename/named-locator discovery and
before acquisition: ExecutionOriginalPaths128L and ConstructedResources156L.
All other bodies are bounded named cuts or locator records. Cumulative unions
and full source/copy hashes are retained. The supplied checked93L continuation
count source and frozen93-file history inventory are explicitly reused.
The earlier capacity REPORT is reused at Root's exact manifest/report pins.
No historical uncompiled draft is treated as newly checked here.

No Haskell source was edited or executed. No concrete executable issue or
Haskell fix was established. There is no FINDINGS candidate from this task.
All source and header claims above are separated from compiler evidence.
The proposed construction producer remains unimplemented and uncompiled.
