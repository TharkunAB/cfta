# Existing closed public headers

These are existing source headers. No new theorem is claimed here.

## MicroCFTA.SourcePruningEnumerationExecutionOriginalPaths.Native.run_original_finite_complete_resources_paths

Source copy: cuts/execution-original-paths-WHOLE-slot1.txt. Header SHA256 68040f48734c38e190e220d882467a617550186158394d1d926a452cdbf8f1c9.

```lean
theorem run_original_finite_complete_resources_paths
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool)) (order : Metadata Typing → List Nat → Option Nat)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (recursiveFuel : Nat) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos) (before : Cached) (metadata : Metadata Typing)
    (seed : Seed) (ceiling : Nat)
    (packet : Packet formulas solver inventory caller memos metadata before)
    (bounded : Fits seed.2 caller.checked)
    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)
    (selectionMembers : ∀ entry rows depth free, ∀ edge ∈ edgesOf (.node entry rows depth free), edge ∈ rows)
    (selectionLength : ∀ entry rows depth free, (edgesOf (.node entry rows depth free)).length ≤ rows.length)
    (initialMass : SourcePruningEnumerationPrefixAdmission.suspendedBound before.core ≤ ceiling)
    (reserved : SourcePruningEnumerationFiniteReservation.Reserved bits recursiveFuel seed ceiling)
    (literals : List Constraint)
    (normalized : ∀ literal ∈ literals, SourceEqualityGuardReadback.Cached literal.equalities)
    (included : seed.1 ⊆ SourceCurrentNativeClosedGuardAlphabet.originalAlphabet literals) :
    ∃ bound outcome,
      (∀ extra, run holeKey fits admits graph templates checkEmpty edgesOf stop order (bound + extra) recursiveFuel
        metadata caller memos.query before = outcome) ∧
      OutcomeResources formulas solver caller
        (SourcePruningEnumerationFiniteReservation.final recursiveFuel seed ceiling) outcome ∧
      (∀ extra, SourcePruningEnumerationExecutionPaths.Native (fun path => path ∈ SourcePruningEnumerationForecastPathDomain.carrier
          (SourceCurrentNativeClosedGuardAlphabet.originalAlphabet literals) before.core) holeKey fits admits graph templates checkEmpty edgesOf stop order
        (bound + extra) recursiveFuel metadata caller memos.query before)
```

## MicroCFTA.SourcePruningEnumerationExecutionOriginalPaths.Prepared.run_original_finite_complete_resources_paths

Source copy: cuts/execution-original-paths-WHOLE-slot1.txt. Header SHA256 7b3824bee94fcfe32eab024234b61d8c1cbbf8fc83e8abed14b78f15a13ef865.

```lean
theorem run_original_finite_complete_resources_paths
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool)) (order : Metadata Typing → List Nat → Option Nat)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (recursiveFuel : Nat) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos) (before : Cached) (metadata : Metadata Typing)
    (seed : Seed) (ceiling : Nat)
    (packet : Packet formulas solver inventory caller memos metadata before)
    (bounded : Fits seed.2 caller.checked)
    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)
    (selectionMembers : ∀ entry rows depth free, ∀ edge ∈ edgesOf (.node entry rows depth free), edge ∈ rows)
    (selectionLength : ∀ entry rows depth free, (edgesOf (.node entry rows depth free)).length ≤ rows.length)
    (initialMass : SourcePruningEnumerationPrefixAdmission.suspendedBound before.core ≤ ceiling)
    (reserved : SourcePruningEnumerationPreparedReservation.Reserved bits recursiveFuel seed ceiling)
    (literals : List Constraint)
    (normalized : ∀ literal ∈ literals, SourceEqualityGuardReadback.Cached literal.equalities)
    (included : seed.1 ⊆ SourceCurrentNativeClosedGuardAlphabet.originalAlphabet literals) :
    ∃ bound outcome,
      (∀ extra, run holeKey fits admits graph templates checkEmpty edgesOf stop order (bound + extra) recursiveFuel
        metadata caller memos.query before = outcome) ∧
      OutcomeResources formulas solver caller
        (SourcePruningEnumerationPreparedReservation.final recursiveFuel seed ceiling) outcome ∧
      (∀ extra, SourcePruningEnumerationExecutionPaths.Prepared (fun path => path ∈ SourcePruningEnumerationForecastPathDomain.carrier
          (SourceCurrentNativeClosedGuardAlphabet.originalAlphabet literals) before.core) holeKey fits admits graph templates checkEmpty edgesOf stop order
        (bound + extra) recursiveFuel metadata caller memos.query before)
```

## MicroCFTA.SourcePruningEnumerationConstructedResources.native_run

Source copy: cuts/constructed-resources-WHOLE-slot2.txt. Header SHA256 24ad17c2e0abd4c19a44ac269ef9eb1a5e2a62b737781b103df4d3bf34143ffa.

```lean
theorem native_run
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Guard) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Guard))
    (stop : Option (Metadata Typing → Nat → Bool)) (order : Metadata Typing → List Nat → Option Nat)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (cache : Cache.State SourceEqualityPartialConstraintKey.Key) (valid : Cache.Valid cache)
    (expression : Syntax)
    (cached : ∀ original ∈ SourceEqualityConstraintOrigins.guards expression,
      SourceEqualityGuardReadback.Cached original.equalities)
    (metadata : Metadata Typing) (emptyPending : metadata.pending = []) (recursiveFuel : Nat)
    (selectionMembers : ∀ entry rows depth free, ∀ edge ∈ edgesOf (.node entry rows depth free), edge ∈ rows)
    (selectionLength : ∀ entry rows depth free, (edgesOf (.node entry rows depth free)).length ≤ rows.length) :
    ∃ value heap, ∃ _built : InternedFreshOrdinaryConstruction.build expression [] empty = .done value heap,
      let seed : Seed := (SourceEqualityConstraintOrigins.guards expression,
        ⟨heap.nodes.next, heap.edges.next, 0, InternedValueMassHeap.initialBound heap⟩)
      let bits := SourceCurrentParentInitialRoom.roomBits
        (SourcePruningEnumerationFiniteReservation.final recursiveFuel seed 0).2
      let finalCache := (SourceEqualityOriginalAllocationPreparation.prepare seed.1 cache).2
      let beforeCaller := caller (bits + 2) finalCache heap
      ∃ handle, encodeNode value = some handle ∧ lookupNode heap handle = some value ∧
      let before : Cached := ⟨EnumerationState.initial handle,
        fun slot => if slot = 0 then !MergedOrdinaryHeight.recursiveBoundary value else false,
        fun _ => none⟩
      ∃ bound outcome,
        (∀ extra, SourcePruningEnumerationRecursive.run holeKey fits admits graph templates checkEmpty edgesOf
          stop order (bound + extra) recursiveFuel metadata beforeCaller globals.query before = outcome) ∧
        SourcePruningEnumerationRecursive.OutcomeResources formulas solver beforeCaller
          (SourcePruningEnumerationFiniteReservation.final recursiveFuel seed 0) outcome
```

## MicroCFTA.SourcePruningEnumerationConstructedResources.prepared_run

Source copy: cuts/constructed-resources-WHOLE-slot2.txt. Header SHA256 806343f43fa5f70f9c09c48b6d7fa96661d60c687d862c175e8eaa95550788e3.

```lean
theorem prepared_run
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Guard) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Guard))
    (stop : Option (Metadata Typing → Nat → Bool)) (order : Metadata Typing → List Nat → Option Nat)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (cache : Cache.State SourceEqualityPartialConstraintKey.Key) (valid : Cache.Valid cache)
    (expression : Syntax)
    (cached : ∀ original ∈ SourceEqualityConstraintOrigins.guards expression,
      SourceEqualityGuardReadback.Cached original.equalities)
    (metadata : Metadata Typing) (emptyPending : metadata.pending = []) (recursiveFuel : Nat)
    (selectionMembers : ∀ entry rows depth free, ∀ edge ∈ edgesOf (.node entry rows depth free), edge ∈ rows)
    (selectionLength : ∀ entry rows depth free, (edgesOf (.node entry rows depth free)).length ≤ rows.length) :
    ∃ value heap, ∃ _built : InternedFreshOrdinaryConstruction.build expression [] empty = .done value heap,
      let seed : Seed := (SourceEqualityConstraintOrigins.guards expression,
        ⟨heap.nodes.next, heap.edges.next, 0, InternedValueMassHeap.initialBound heap⟩)
      let bits := SourceCurrentParentInitialRoom.roomBits
        (SourcePruningEnumerationPreparedReservation.final recursiveFuel seed 0).2
      let finalCache := (SourceEqualityOriginalAllocationPreparation.prepare seed.1 cache).2
      let beforeCaller := caller (bits + 2) finalCache heap
      ∃ handle, encodeNode value = some handle ∧ lookupNode heap handle = some value ∧
      let before : Cached := ⟨EnumerationState.initial handle,
        fun slot => if slot = 0 then !MergedOrdinaryHeight.recursiveBoundary value else false,
        fun _ => none⟩
      ∃ bound outcome,
        (∀ extra, SourcePruningEnumerationPreparedRecursive.run holeKey fits admits graph templates checkEmpty edgesOf
          stop order (bound + extra) recursiveFuel metadata beforeCaller globals.query before = outcome) ∧
        SourcePruningEnumerationPreparedRecursive.OutcomeResources formulas solver beforeCaller
          (SourcePruningEnumerationPreparedReservation.final recursiveFuel seed 0) outcome
```
