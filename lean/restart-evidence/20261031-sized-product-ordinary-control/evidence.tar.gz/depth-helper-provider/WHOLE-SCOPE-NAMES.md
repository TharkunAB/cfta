# OLD whole slots

Slot1: SourcePruningEnumerationExecutionOriginalPaths.lean128L. Named after discovery and before acquisition at01:51 CET.
Slot2: SourcePruningEnumerationConstructedResources.lean156L. Named after discovery and before acquisition at01:56 CET.
No third slot is authorized.
