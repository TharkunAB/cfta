# Scope

Source-only inventory of the largest remaining goal. Identify the strongest closed original-input per-supplied-depth public headers for both workers. Start from current whole-worker original-carrier checkpoint and canonical notes. State the first missing sufficient-depth and ordered-prefix producer. Propose one substantive closed next contract and an actual progress argument.

No supplied future path/history/Normal/completion premise. Do not silently restrict the intended scope or replace the global target by a local count. Name any required original-input productivity/finite-prefix hypothesis and its relation to intended scope.

Own this directory only. Root owns compiler, evaluator, native, Git, network, board, production and publication. No spawning. At most two named OLD whole/near-whole sources after filename and locator discovery. Exact bounded cuts and cumulative unions. Reuse frozen history93-file inventory and explicitly checked installed count93L with pins. Inventory/header only. No proof body or Haskell claim.
