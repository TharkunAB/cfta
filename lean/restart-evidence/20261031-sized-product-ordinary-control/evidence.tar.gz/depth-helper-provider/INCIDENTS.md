# Retained read incidents

1. Broad filename-only displays were truncated. Their complete stdout/stderr remain under the corresponding discovery filenames. No source body was acquired by these filename-only commands.
2. Several named locator displays exceeded their output limits. Complete stdout/stderr and exact per-source matching lines remain under locators/. Cumulative unions include all matched lines. The report uses the displayed named cuts and exact source definitions, not an unreviewed hidden proof body.
3. A guessed InternedFiniteOrdinary.lean filename did not exist. The locator retained its stderr and other valid source matches. No body was acquired from the missing path. The actual predicate was located in SourceCurrentAllocatedFiniteOrdinaryDomain.
4. The requested fromRows child cut336–346 clamped to the actual source EOF344. acquisitions.json retains the exact actual line vector and source line count.
5. Root's early speculation that order=None can end the worker was corrected after literal PureSelection/pickNext readback. The report preserves the safe-hint fallback and the separate explicit-stop branch.

No compiler, evaluator or native probe was run. No observed proof failure or executable defect is claimed.
