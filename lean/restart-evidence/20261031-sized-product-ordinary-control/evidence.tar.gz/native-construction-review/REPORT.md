# Ranked-row native construction draft

Status: SOURCE ONLY. All candidate Lean sources are UNCOMPILED. No compiler,
evaluator, Haskell/native program, Git, network, board, production edit or
child agent was used. Root alone must check and integrate these drafts.

## Candidate pair

- SourceRankedRowsOrdinaryConstruction-v2-UNCOMPILED.lean, 238 lines.
- SourceSizedPrefixProductOrdinary-v1-UNCOMPILED.lean, 58 lines.

Generic V1 is retained unchanged. V2 adds expression_stable. This is a real
source property: any fuel above the original rank gives the same expression.
It makes the absence of active-row truncation explicit. No proof was tested.
The new numeric157L provider is retained at its exact owner V2 source hash.
Its UNCOMPILED status at acquisition is recorded separately from Root checks.
Root later reported the installed baseline checked after four deprecated-name
proof repairs; its public definitions and headers were unchanged. No Root
proof source was substituted into this owner bundle.

## Closed producer and original data

The generic source is a function from original states to ordered symbolic
rows. SourceSizedDecided.Row retains label, ordered children and full guard.
A static rank belongs to the ORIGINAL states. Each original nonempty row class
must have positive rank. Each original child must have strictly smaller rank.
These are static original-row properties. They mention no native state,
future result, trace, history, recursive-worker outcome or domain certificate.

layer copies each original row into EdgeSyntax.mk with the same label and
constraint. Its child sequence is mapped in the original order. It does not
sort or remove source rows. expression uses only Syntax.node and Syntax.empty.
It introduces no union, binder, reference, or additional synthetic-root wrapper.
expression_succ exposes the exact original row/child sequence by reflexivity.
expression_stable proves independence of excess fuel from the original rank.

The public generic closed candidate asserts, from those original inputs:

- the actual observed result of InternedFreshOrdinaryConstruction.build from
  the empty environment and empty native heap;
- InternedNestedFacts.Facts of that exact final heap, including coherent
  cached payloads and linked resident values;
- Available of the actual returned value;
- empty actual free-name list;
- recursive SourceCurrentAllocatedFiniteOrdinaryDomain.Node;
- MergedOrdinaryHeight.height no greater than the original root rank.

No output or intermediate observation is an input to closed. Completion comes
from the existing closed_complete producer. Closedness comes from the existing
closed_free_empty producer. Availability and native facts come from the actual
existing build verification law. The new mutually recursive proof draft derives
ordinary domain and ordinary height from literal build/buildMany/buildEdges.
Its private observed-result equations only analyze those actual constructor
calls. The public producer obtains its observed result internally.

The mutual proof uses a lexicographic measure: remaining unfolding fuel,
constructor/child-list/row-list phase, then remaining source list length.
A node enters its rows at smaller fuel. A row enters its children at a smaller
phase. A child enters its node at a smaller phase. Sibling tails shorten their
original lists. These are proof recursions over the constructed finite syntax;
they are not a claimed measure for the recursive enumeration workers.

The node case uses exact returned resident edges, not abstract Ready as a
normal-form supplier. The edge case uses exact completed child availability.
Domain.makeEdge/makeNode and their actual height bounds apply to those exact
endpoints. The proof never substitutes a future native domain hypothesis.

## Actual numeric product instantiation

The product file imports the new SourceSizedPrefixProductRank API. Its
rows_positive derives positive rank directly from generated row membership.
The zero-budget case has no model rows. The synthetic root rank is positive.
Its closed candidate supplies decreases by the model rows_rank law. It does
not ask the caller for either rank certificate or any native observation.

The public product arguments are only original rows, the operational minimum
table, the operational numeric constraint filter, original root and Int bound.
The exact generated synthetic-root row list is unfolded. No unary root node
is added around that list. The resulting height bound is bound.toNat+1.
For a nonnegative public natural size bound B this gives B+1. This draft does
not silently strengthen the result to B.

The two candidates keep a useful model boundary: the first file can be checked
independently of the new numeric product module. The second must be checked
after that module is installed under its canonical import name.

## Literal source reification remains open

This is a RANKED-DAG UNFOLDING producer. It is not yet a model of the literal
Data.CFTA.Interned.fromRows memo/SCC computation. The previous literal
SourceSizedPrefixNativeDecision.expression header remains unimplemented.
These new expression functions cannot replace it without a source proof.

The actual source fromRows first trims reachable/productive rows, computes
positional rows and SCC labels, and uses memo keys with binder contexts.
SourceOrderedBinderImport models the completed positional/component inputs,
ordered child dispatch and completed memo schedule. Its module contract
explicitly excludes SCC extraction, constructor semantics and GHC evaluation
correspondence. The reviewed select branch resets context for a child in a
different component. It does not itself prove that ranked rows have the
actual extracted component labels or construct a native value.

A ranked DAG should exclude the actual same-component reference/Mu branch.
That exclusion must be proved from correctness of the actual positional/SCC
extraction and the original rank. It is not a new premise in these candidates.
Repeated subgraphs are unfolded here. Literal fromRows can reuse a completed
memo result. Correspondence must therefore address source memo hits, native
constructor identity/readback, final allocations and exact scheduling. The
expression_stable result can support that later argument. It does not prove it.

The numeric provider also retains its own boundary: actual Integer intervals,
minimumSizes-to-Nat conversion, actual equalSizes, positive call domain and
reachable table exploration have no Haskell correspondence proof here.
The numeric rowOf0 equation is a MODEL definition. No equivalence with
arbitrary internal Integer rowOf calls is claimed.

## What this does not establish

Even if Root checks both candidates, they show finite ordinary structure for
the explicit modeled ranked unfolding. They do not yet connect an actual
public Prefix call to this value. Prefix template restriction/restrictAt still
needs actual domain/height transport. Generic nested Syntax can contain Mu,
Union or field-pool values; it is not silently restricted by this producer.

Native incoming intersections still need both actual operand domains and the
empty-seen request gate. Ordinary height alone does not bound same-slot
terminal/opaque restart, raw alias/SCS work, unknown allocation or source
replacement. Captured sibling cache restoration still needs a finite frame
budget. No sufficient recursive depth, accepted ordered prefix, either whole
worker's global termination or Haskell/host correspondence is claimed.

The older finite carrier concerns stored/projected constraint/SCS address
paths. It is not a generated term-height or recursive-work bound. This new
producer uses ordinary constructor height explicitly. Cached binder depth0
is not substituted for that measure.

No Haskell file was edited or executed. No new executable defect, Haskell fix
or FINDINGS candidate was established.

## Acquisition and verification

OLD whole slots were named before acquisition: Domain197L and FreshFacts162L.
Every other OLD source acquisition is a bounded named cut or named locator.
The cumulative source unions include all locator matches, including any
truncated display. No third OLD whole/near-whole source is used through reuse.
The exact numeric provider is NEW supplied source, not an OLD budget exception.

All source/copy hashes, provider identities, actual line vectors and cumulative
ranges are retained. Source hashes are metadata, not compiler evidence.
The complete candidate pair and earlier version remain frozen for Root review.
