# OLD whole acquisitions named before acquisition

2026-10-31 02:51 CET. Filename/named locator discovery has completed.
1. SourceCurrentAllocatedFiniteOrdinaryDomain.lean. Read its concrete constructor/domain/height API.
2. InternedFreshOrdinaryFacts.lean. Read its actual build readiness/availability/closedness induction.

No third OLD whole/near-whole acquisition is authorized. SourceOrderedBinderImport and the actual construction clauses remain bounded cuts.
