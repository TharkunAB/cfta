# Native ranked-row construction review

Own source-only scope. No compiler/evaluator/Haskell/native/Git/network/board/production/spawn.
Maximum two named OLD whole/near-whole acquisitions, including reuse by original path.
Draft a native finite-ordinary construction step from static ORIGINAL ranked rows.
Retain row order, child order, labels, constraints and synthetic root behavior.
A ranked-DAG unfolding must remain separate from literal SCC/memo/host allocation.
No future native-domain, trace, history or completion supplier.
