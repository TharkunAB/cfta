# Read incidents

Initial filename-only output was truncated; complete stdout/stderr retained. The first helper call lacked acquisitions.json and stopped before any acquisition. It was initialized, then retried. No compiler/evaluator was invoked.

The FreshOrdinaryFacts whole request1–170 clamped to its actual EOF162. Exact actual lines and source size are in acquisitions.json.

The first final metadata check guessed numeric provider MANIFEST.json. That name was wrong. Root supplied MANIFEST.sha256 and FROZEN-PINS.json; both exact hashes were verified. No provider artifact disappeared. The filename error is retained separately.
