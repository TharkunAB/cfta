# Incidents

1. The initial combined display of metadata and the supplied 280-line source exceeded the available output context. The byte-exact source copy was retained. Both source halves were later displayed in full. No source proof was run.
2. A provider manifest probe used `MANIFEST.sha256`. The frozen provider uses `MANIFEST.json`. The read failed with FileNotFoundError before helper acquisition. A filename-only inventory located the exact manifest. Its SHA256 matched the supplied946e109c pin before the helper copy.
3. The first locator stdout had105 lines and3957 tokens. The3100-token display limit truncated it. The complete stdout/stderr and each exact per-source locator copy were retained. The complete stdout was later displayed with a5000-token limit.
4. A metadata-only filename probe for SourcePruningEnumerationLeftBuild.lean returned MISSING. No body was acquired. The literal hook was found in the two named whole workers.

These incidents do not establish a proof failure or executable defect. No frozen provider was edited.
