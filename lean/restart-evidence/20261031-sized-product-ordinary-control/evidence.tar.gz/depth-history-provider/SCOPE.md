# Scope

Independent bounded source-only inventory. Own only this directory; keep all prior bundles frozen. Root owns compiler, evaluator, native, Git, network, board, production and publication. No spawning.

Explicit checked NEW whole reuse: SourcePruningNarrowPrefixObservation.lean280L SHA87ef63681bbeca51338c190b152adcfe33be949e12926fe7844ba2e211c8dbee.

Two OLD whole/near-whole slots allowed. Both worker modules were named before acquisition at01:22 CET. See WHOLE-SCOPE-NAMES.md and acquisitions.json. No third slot is authorized.

Inventory the nearest actual caller and closed next ORIGINAL-input numeric contract. Do not propose supplied future stages/history/Normal or abstract transition as a theorem premise. Freeze report and exact next header only; Root chooses implementation. No Haskell defect/fix without a concrete executable source issue.
