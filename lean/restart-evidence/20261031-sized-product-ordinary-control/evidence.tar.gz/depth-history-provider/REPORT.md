# Actual selected-prefix caller and next numeric contract

Date: 2026-10-31 01:35 CET.
Status: source inventory only. No theorem was implemented or checked here.

## Result

The nearest actual consumers are `SourcePruningEnumerationRecursive.resume` and `SourcePruningEnumerationPreparedRecursive.resume`. A successful narrowed/Right prefix enters the ordinary or prepared continuation scan. It does not call the root filter again at the returned pending slot.

The next obstacle is an actual selection tree with several row sources. A single linear `ChangedFilters` chain does not represent that tree. The native heap endpoint follows the previous recursive sibling. The next sibling starts from the same captured enumeration cache. A completed selected edge then writes the selected slot as `.enumerated fragment`. Those facts prevent a direct composition of consecutive pending-slot filtering histories from native `Keeps` alone.

`NEXT-HEADER-ONLY.txt` gives one closed numeric contract for the actual fold. It bounds direct alternatives by the original input list of that fold. The header takes no future stage equations, `Trace`, `Complete`, `Normal`, source-preservation predicate, or abstract transition. It has no proof body. This is a local finite bound. It is not the original-request resource theorem.

## Checked source reused

The explicit supplied source is `SourcePruningNarrowPrefixObservation.lean`, 280 lines, SHA256 `87ef63681bbeca51338c190b152adcfe33be949e12926fe7844ba2e211c8dbee`. The exact copy is under `reused/`. Both halves were displayed in full after an initial display truncation.

Root reports that the installed module, Audit and public checks pass. This task does not repeat those checks. Its two conclusions include `reached.checked.native.machine.heap = nextHeap`. That endpoint connection is closed. Do not report it as missing.

The actual changed gate is `after.core ≠ checked`, where both cores come from one retained narrowed prefix result. A narrowed tag alone does not imply that gate. The semantic law derives `Normal`, available/closed ordinary readback, `Keeps`, the stored new handle, and `PendingRealized` from original `Ready`, `PendingRealized`, `Total`, and the literal observation. No historical `makeNode` premise is needed.

## Actual caller and carrier path

1. Both workers compute `observed := SelectedStep.runPrefix ... uv caller before queries` with six copies of `workFuel`.
2. Their common accepted narrowed branch matches `reached`, saved queries, `some after`, Right singleton success with `false`, and no legacy ordinary result. This pattern accepts both changed and unchanged core outcomes. It discards the checked core, prepared result and action observation.
3. `Recursive.resume` calls `NativeOrdinaryContinuations.run` with `reached`, `after`, saved queries, and a literal recursive `continueWith` hook at the predecessor recursive fuel. `PreparedRecursive.resume` calls `SelectedContinuations.run` with the corresponding prepared hook.
4. `NativeOrdinaryContinuations.run` calls literal `Entry.enter`. Entry reads the pending value, finds its representative, decodes its resident handle, and updates expansion ancestry. Entry does not replace the slot value. A nonterminal ordinary result starts `NativeContinuations.run` at `frame entered before` and `edgesOf parent`.
5. `NativeContinuations.run` calls `CapturedEdge.run` on the head edge. A complete receipt invokes the actual hook before the suffix. The suffix receives the hook's native caller and queries, but receives the SAME original captured cache `before`. The edge list decreases to `rest`.
6. `CapturedEdge.run` finalizes a successful selected edge. `Finalize.run` clears expansion ancestry and writes `.enumerated fragment` at the captured raw target. A subsequent continuation therefore starts after consumption of this pending slot source.
7. The Left hook calls actual `recordTypes`, frames its result and computes a restart decision before recursing. Existing `recordTypes_frame` derives a compression `Frame` from success and original `Total`. Right recording is pure. Neither callback is an established slot-source reset.
8. `Recursive.finish` and `PreparedRecursive.finish` erase the processed receipt list on completion. Their successful final result retains outputs and native endpoint, not every intervening prefix tag or selected-slot write. A successful final worker result alone does not identify the changed-prefix events.

The retained cuts contain these exact definitions. The two full worker copies contain their literal hooks and recursive branch patterns.

## Actual branches and remaining obligations

| Site | Actual behavior | Consequence for progress |
| --- | --- | --- |
| Narrowed/Right, changed core | The checked law supplies a normal ordinary stored value and the returned native heap. | This is one actual normalized source. Connect its slot/readback to the next entry before using its rows. |
| Narrowed/Right, unchanged core | The worker enters the same continuation scan. | Strict root-row loss cannot count this call. The next ordinary expansion can supply a different progress argument. |
| Parked success | The worker frames the parked/restart result and recurses at predecessor recursive fuel. | This is a separate repeat/SC bucket/restart branch. The changed-filter law does not account for it. |
| Ordinary sibling suffix | The suffix keeps the captured cache and uses the reached native caller/queries. | Heap extension does not identify a descending current-slot row chain across siblings. Each suffix step consumes one original edge. |
| Selected edge completion | Finalization writes the selected target as enumerated and clears expansion ancestry. | The pending source ends. Descendant pending sources need their own original-data accounting. |
| Nonterminal child | Shallow child preparation runs on incoming child data and the descended SC bucket. | A child source is not the parent's root-edge carrier. Child-list length is finite for that concrete edge. |
| Terminal child | Terminal prefix merges, fold, and incoming-node application run at returned endpoints. | Representative winners, pending handles and SC buckets can change. The filtering subset theorem does not cover these writes. |
| Incoming, no old handle | `IncomingNode.run` installs `encodeNode incoming` at the representative and appends SCs. | This creates an actual source rather than preserving a prior encoded source. |
| Incoming, old handle | `IncomingNode.run` executes `requestNode ... incoming old`, checks optional emptiness, encodes the replacement and writes its handle with appended SCs. | A current slot can receive an intersection result. Native resident preservation alone is not a complete-edge carrier or `Normal` law for that replacement. |
| Prepared Mu | `SelectedValue.run` calls stored substitution unfolding. | Keep this reconstruction branch separate from an ordinary preserved source. |
| Prepared Union | `SelectedValue.run` exposes rows and calls `makeNode`. | Keep this reconstruction branch separate from an ordinary preserved source. |
| Prepared ordinary input | `SelectedValue.run` returns `.done value before`. | Once actual entry is shown to read the changed prefix's ordinary value, this immediate Mu/Union reset is excluded internally. |
| Callback | Right is pure. Successful Left has an existing derived `Frame` under `Total`. | Use the existing laws. Do not introduce a new no-write assumption or classify the callback itself as a row reset. |
| Empty/rejected/stopped branch | The worker returns no output or an explicit stop with the observed endpoint where available. | Counts must distinguish a normal branch rejection from unsupported or resource-limited observations. |

No completed execution or source counterexample was constructed. In particular, this inventory does not assert that an actual intersection increased a row count. It identifies the concrete operation and current-slot overwrite for which the present filter law gives no such bound.

## Smallest closed numeric next contract

For the literal `NativeContinuations.run` on original arguments, let `edges` be its original finite list. The proposed header states:

- A complete result has exactly `edges.length` processed receipts.
- A stopped result has strictly fewer than `edges.length` processed receipts.

Every recursive suffix removes one edge. A stopped current edge is retained outside the processed prefix. Thus the number of direct edge attempts is at most the original list length. Duplicate edges need no special assumption. A completed recursive hook can return many outputs; this statement does not bound those outputs or the hook's internal work.

The literal worker hooks instantiate this header directly. They are original function arguments to the actual fold. No abstract per-step transition or future hook result is supplied. The law remains valid through actual sibling cache restoration because the suffix still uses the original list tail.

A proof should use induction on that original list and the literal head matches. Keep the same input endpoints. The numeric search was limited to the recorded Native/Selected module filenames and patterns. It did not find this law in `NativeContinuations`. This is not a claim that no equivalent theorem exists anywhere in the repository.

The list here is ORIGINAL TO ONE FOLD. It is not a fixed carrier from the original public request. A wrapper obtains it as `edgesOf parent` after actual entry; the prepared wrapper obtains it after actual preparation. The exposed `edgesOf` argument is generic. Root must connect the actual edge projection and the actual original source before replacing that list by an original-request quantity.

## Why this does not close the requested theorem

`packet_prefix_complete` already supplies a common prefix fuel from a current packet and the current expansion decision. `SelectedContinuations.complete_resources` already supplies one common preparation bound from the current original packet/forecast. Those are local producers. They do not count all later selections, source replacements, sibling restorations, or new child sources.

Existing `ExecutionPaths.ResumeNative`, `NativeStage`, `PreparedStage` and `SiblingPaths` follow the actual prefix, entry, sibling hook and callback endpoints. They are useful destinations for derived invariants. Supplying those future predicates as assumptions would leave the original producer gap open.

To obtain the global ordered-prefix result, derive an original-data bound on the actual selection tree. It must count unchanged calls and parked restarts, charge each new/intersected/reconstructed source, account for every earlier sibling and staged child, and transport native readiness plus enumeration invariants through their actual writes. Each new source can require a first normalization before the existing strict-loss chain applies. The number of those normalizations has no global original-input bound in the inspected contracts.

Do not stitch all selected calls into one `ChangedFilters` chain. Do not infer `Normal` from `Ready` or `Available`. Do not replace the missing original bound by the worker's supplied recursive fuel. A fixed supplied fuel proves a bounded worker only. It does not show that the original request has enough fuel.

The full original-input, both-worker, public adapter, ordered language coverage and Haskell correspondence objective remains open. The new checked prefix laws close an actual local observation/control gate within that objective.

## Acquisition and execution boundary

Two OLD whole modules were named to Root before acquisition at 01:22 CET. They are the 128-line recursive worker and the 120-line prepared worker. No third whole or near-whole module was acquired. All other source bodies are retained named bounded cuts or locator records. `SOURCE-UNIONS.json` records exact cumulative unions. Metadata-only hashes do not count as source-body acquisition. Filename-only discoveries are retained separately.

No compiler, evaluator, native program, Git command, network, board, production edit or sub-agent was used. The only new formal text is the uncompiled header. No Haskell source was edited or executed. No concrete new executable defect or Haskell fix was established. There is no FINDINGS candidate from this inventory.

`INCIDENTS.md` retains the display truncations, one wrong manifest filename, and one filename-only missing helper probe. Each was corrected without changing frozen provider directories.
