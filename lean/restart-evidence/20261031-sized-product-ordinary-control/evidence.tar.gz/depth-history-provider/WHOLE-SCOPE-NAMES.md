# OLD whole slots

Slot1: SourcePruningEnumerationRecursive.lean128L.
Slot2: SourcePruningEnumerationPreparedRecursive.lean120L.
Both named before acquisition in the Root message at01:22 CET.
No third whole or near-whole source is authorized.
