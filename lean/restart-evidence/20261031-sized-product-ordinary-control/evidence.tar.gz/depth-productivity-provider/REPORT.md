# Original-prefix productivity inventory

2026-10-31 02:18 CET. SOURCE INVENTORY ONLY. No proof draft or evaluation.
The full original-input/BOTH-worker/public-adapter/Haskell objective stays OPEN.

## Result

There is an existing declarative positive-size prefix target. It is
SourceSizedQueries.through of the original exact size classes through B.
SourceSizedReferenceAPI.through_exact/complete identifies it with original
accepted terms of nodeSize≤B, and eventual membership of every accepted finite
term. SourceSizedPublicContracts has the corresponding reference-Api results
and finite_class with strictly decreasing size evaluation. Their current
preprocessing/ActiveOption gates remain explicit in ORIGINAL-CONTRACTS.md.

This is separate from PreparedFiniteOutputPrefix's List.IsPrefix relation
between two actual hook-output lists at supplied depths. That relation gives
neither sufficient depth nor equality with an original requested list.
For arbitrary internal stop/order/hook choices, no declarative policy-permitted
original prefix predicate was found in the inspected construction/output-prefix
interfaces. This is not a repository-wide absence claim.

## Public policy and architecture

Standard Sized.Prefix means completions of a preorder-token prefix within an
explicit original node-count bound. Its order is size-major, then language
order. It uses a prefixed count index or Sized.sized's table/strict-size
reference routes. The guarded walk separately builds an equality size product
and falls back to Enumeration.terms after finite fillings. The actual bySize
adapter pairs states with exact sizes; child budgets sum to parent−1.

Thus the standard bounded Prefix route has an original positive-size rank
source. It is not merely an arbitrary recursive worker with a supplied depth.
The next actual bridge is the bySize/trim/fromFTA/restriction construction
transport to the required native structural/progress predicate, then worker
adequacy for the existing reference list. Finite denotation alone is not that
native structural fact. normal_lineage_review owns this next source lane.
No future operational output/depth/history witness is proposed as admission.

The worker order parameter is a dependency-safe expandable-slot hint. Invalid
hints fall back to an offered candidate. It differs from cost-priority order.
The default full enumeration supplies no stop, no preference, and no pruning.
Custom stops may intentionally return partial terms; custom narrowing must
retain wanted branches. The exact configured policy must stay in the target.
Yes/No/Unknown guard verdicts also remain distinct. See POLICY-AND-ROUTES.md.

## Exact unrestricted-progress obstruction candidate

CURRENT-SOURCE-CANDIDATE.md gives the existing nonempty lexicographic example:
R accepts good, while infinitely many cheaper bad(u^n(a),z) candidates fail
an equality. The mathematical first accepted prefix [good] exists. Current
Tree.termsByCostBy pops minimum-key partials and checks constraints only after
completion, leaving another cheaper partial bad branch before good forever
in the proposed queue invariant. This is a source-grounded candidate to
formalize, not a newly executed or formally proved nontermination result.

It concerns cost-priority extraction. It directly refutes neither the workers'
slot-order sufficient-depth target nor standard size-bounded Prefix.
The existing documented sufficient condition is finiteness of generated raw
partial derivations below each requested key, plus terminating local work.
ORIGINAL-CONTRACTS.md states it using only original grammar/row/cost data.
Finiteness of accepted terms alone is weaker. No empty language is treated as
a failed prefix guarantee. The four distinctions are in FOUR-SCOPES.md.

Root verified the exact acquired Tree/EGraph/Prefix bytes against current main
bd5a406a6a3f84b7e3ae0906082783911509df83 and the live checkout. The complete
read-only blob/hash comparison is retained. No Haskell/native execution ran.
Historical FINDINGS timeouts remain historical evidence only. No new Haskell
defect, fix, or FINDINGS entry is established.

## Scope, incidents, and freeze

The two named OLD whole modules are PreparedFiniteOutputPrefix (94 lines) and
SourceSizedPublicContracts (95 lines). All other code acquisitions are named bounded
cuts or exact locator lines. There are 85 source records over 55 source files.
No duplicate whole acquisition was made in the other agent's depth lane.
Coordination, exact source metadata, copy pins, and cumulative unions remain.

INCIDENTS.md retains the initial filename display truncation and full repeated
raw locator, a saved document-locator display truncation, an overly broad
import locator, an EOF-range ledger correction, and the failed copy-hash
check/reconstruction after locator basename collisions. All prior ledgers,
raw outputs, overwritten payloads, and repaired exact copies are retained.
No source SHA or substantive conclusion changed during those repairs.

No compiler, evaluator, native execution, Git, network, board, production edit,
or spawn ran in this child task. Root's read-only Git comparison is separate.
The inventory proves no sufficient original depth, whole-worker adequacy,
finite global coverage, or Haskell correspondence. The next contract is an
original adapter/rank producer, not another supplied future-success gate.
