# Four separate prefix and progress questions

| Question | Exact current meaning | What it does not establish |
| --- | --- | --- |
| Mathematical finite accepted prefix | A finite initial list under a declared order on accepted terms. In the candidate below the only accepted term is good, so its first accepted prefix exists. | Finite search work before that list. Rejected candidates can precede it. |
| Finite work below a requested priority | Finitely many generated raw partial derivations at or below the requested key, plus termination and progress of each local job. | It does not follow from finiteness of accepted terms alone or local monotone/strict child-cost laws. |
| Positive size-major prefix | SourceSizedQueries.through classes B concatenates exact classes 0..B. PublicContracts.enumeration_exact identifies it with original acceptance and nodeSize≤B. | Native worker adequacy or correspondence of actual optimized adapters to that reference list. |
| Bounded preorder-token Prefix | Data.CFTA.Sized.Prefix restricts those bounded accepted terms to terms whose preorder starts with the supplied token list, retaining size/language order. | An arbitrary custom-cost ordered extraction prefix or arbitrary worker stop policy. |

The existing cross-depth worker statement is a fifth, operational relation:
List.IsPrefix(hookOutputs first, hookOutputs last). Both actual stable outcomes
are constructed under original resource gates. They may still exhaust.
The relation identifies neither output list with a declarative requested
prefix and supplies no sufficient original recursive depth.

Empty accepted languages and empty requested completion sets are legitimate.
Their finite bounded lists are empty and their counts are zero. They are not
failed requested-prefix guarantees. A first k accepted-term promise must not
require k existing accepted terms when the language has fewer than k.
