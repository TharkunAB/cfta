3:Constrained finite tree automata for Haskell. One interned, hash-consed graph
15:The ordinary layer is a finite tree automaton (FTA). The equality layer is the
27:- Restrict a language: choose finite literal domains, bound tree depth,
62:| List accepted terms | `FTA.terms`, `Enumeration.terms`, `Enumeration.plainTerms`, `Enumeration.plainTermsAtMost` | Every term. `FTA.terms`, `plainTerms`, and `plainTermsAtMost` list by depth. `FTA.terms` and `plainTerms` ignore constraints and give an infinite list for a recursive grammar, and `plainTermsAtMost` stops at a depth. `terms` solves constraints and stops at recursion. For an automaton with constraints or recursion, it lists in the order of the runs, each term once. |
75:| Visualize a grammar | `FTA.toTree`, `Common.toTree` | A finite tree of typed state and transition labels. Map the labels to strings for `drawTree`. |
158:`boundDepth 2` produces a finite language from the recursive grammar. Depth
169:`Int`, `Integer`, `Char`, and `Text` are atomic: they require explicit finite
281:`FTA.toTree` returns a finite tree with typed labels:
301:renderNode view = prefix ++ "q" ++ show (FTA.viewNode view) ++ " @" ++ renderPath (FTA.viewPath view)
303:    prefix = case view of
337:occurrence in the finite graph view. `ViewPath` is `[ViewStep]`; each
346:finite view does not list every route through a shared or recursive graph.
463:This argument assumes finite structural templates with independent holes.
465:complete finite terms. Equality constraints and residual guards cannot make
467:finite-term language. They do not establish equality of every recursive
581:`map snd` extracts the child-only route for one occurrence. The finite view
593:finite and recursive diagnostic graphs with local state names, occurrence
679:`Data.CFTA.Enumeration` also provides an optional ordered cursor.
710:and recursion machinery. Use closed automata with finite, total node data
761:`refinementFormula` gives it. The name has the reserved prefix `__cfta_`,
887:`toTree` converts the reachable graph to a finite tree with typed labels:
929:renderNode view = prefix ++ "node @" ++ renderPath (viewPath view)
931:    prefix = case view of
1006:occurrence; the finite view does not list every route through a shared graph.
1013:matching the paper's restriction that keeps solver obligations finite;
1089:Minimization applies a finite schedule of the paper's M-Trans rule on the
1112:finite structural derivations, the last finite structural root derivation is
1121:| `Data.CFTA.Generic` | Datatype derivation, finite domains, metadata, and typed codecs. |
1123:| `Data.CFTA.Checkpoint` | A saved position in a size-ordered listing of the terms of a graph: the graph, the query route and its version, the size bound, and the sized rank of the next term. A sampling checkpoint saves a position in a sampled run: the weights, the pseudorandom generator, the seed, and the number of draws. `cfta-generator` resumes both, and `cfta-serialization` stores both. |
1125:| `Data.CFTA.Template` | Patterns with holes and prefixes, and restriction of a grammar to a pattern. |
1137:| `Data.CFTA.Refinement.Lattice` | Exact counting and lexicographic ranking of the integer points of a linear formula, without enumeration, and `latticeEntailment`, which decides bounded linear integer implications without a solver. |
1302:that pair paths that are prefixes of one another cost several times more for
1312:types up to ten branches each, intersecting two 12,800-edge finite nodes,
1332:- finite and recursive intersection
1350:`liquid-fixpoint`, `mtl`, `text`, `transformers`, and `unordered-containers`.
