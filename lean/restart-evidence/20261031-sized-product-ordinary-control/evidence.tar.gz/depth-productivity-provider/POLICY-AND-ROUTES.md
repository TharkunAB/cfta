# Exact policies and public routes

1. ExpansionOrder is a slot-choice hint. Enumeration.nextExpandableUVar lines 845-877
   offers dependency-safe candidates, accepts only a preference in that set,
   and otherwise selects the minimum candidate. An arbitrary invalid hint
   therefore does not manufacture an invalid slot.
2. The ordinary enumerateFully default uses noExpansionPreference, no stop,
   and an oracle that never prunes. enumerateUntil' with a stop checks every
   remaining slot, including blocked slots, and stops only on a nonempty
   remaining set accepted by that rule. Restart.decision lines 13-23 mirrors this
   modeled stop behavior. A custom stop can intentionally return a partial
   term. It is not an unconditional accepted-complete-term policy.
3. termsPruneUntil passes its supplied stop/order/narrow/oracle and shallow
   expansion. Its documentation requires narrowing to keep every edge that
   leads to a desired term. That is a policy obligation on original desired
   terms, not a future successful-run witness. Arbitrary pruning cannot be
   silently treated as the standard no-pruning policy.
4. Bounded Prefix initially uses a prefixed count table when applicable.
   Otherwise it obtains Sized.sized and lists exact size classes1..B, then
   afterToken/afterPrefix retain matching preorder prefixes. Sized.sized uses
   optimized count tables where applicable and a strict-size reference fallback.
   This is not a direct call to the arbitrary recursive worker wrapper.
5. Guarded prefixCompletionsWith and deciding separate Yes,No,Unknown verdicts.
   Accepted lists/counts cover Yes. Unknown candidates remain explicitly
   undecided. An arbitrary nonterminating solver callback is not covered by
   finiteness of the candidate set alone.
6. decidingWithCap lines 344-380 builds fromFTA(trim(bySize B automaton)) only for the
   equality-product optimization. afterRuns lines 492-557 restricts it by the token
   prefix, tries finite fillings, then capped 0 calls Enumeration.terms node.
   Thus bySize is an actual original-size adapter where the equality enumerator
   is invoked. Its native fromFTA structural transport still needs inspection.
7. Optional OrderedConfig and EGraph.extract are separate cost-priority APIs.
   They require admissible bounds and callback contracts; current docs give
   no progress guarantee for an infinite lower-key search. Queue fuel also
   does not bound the cost of a callback or one raw sibling step.

The goal retains exact configured order and stops for BOTH workers. No policy
was replaced here. The missing full theorem must specify the desired
policy-permitted original prefix and prove its original resource admission.
For arbitrary internal callbacks, no such declarative predicate was located
in the inspected construction/output-prefix wrappers. This is an exact open
interface question, not permission to silently restrict the full goal.
