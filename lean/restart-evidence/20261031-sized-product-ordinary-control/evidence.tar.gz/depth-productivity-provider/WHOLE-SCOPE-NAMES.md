# Named OLD whole scope

Slot 1 named before acquisition at 2026-10-31 02:09 CET:
SourcePruningEnumerationPreparedFiniteOutputPrefix.lean (94 lines).
Slot 2 named before acquisition at 2026-10-31 02:09 CET:
SourceSizedPublicContracts.lean (95 lines).
Both OLD whole slots are now used. Other reads stay bounded cuts/locators.
