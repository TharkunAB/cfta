# Incidents

1. The initial filename-only rg command excluded restart-evidence only at the
   root. Nested lean/restart-evidence paths were included. Its tool output
   truncated (9864 lines reported; original token count 233289). No source text
   was read by that command. Full raw stdout was not saved before truncation.
   The identical filename-only command was repeated into retained stdout and
   stderr files. Later source work uses named files and exact cuts only.

2. The combined display of six bounded document locator outputs exceeded the
   tool output budget. Each complete locator stdout/stderr was already saved
   before display. All exact selected source lines and metadata are retained.
   No source data was lost. Later displays use narrower named cuts.

3. The current extraction route locator included ^import.*FTA. That pattern
   also selected general Data.CFTA imports in other cfta/src files. Those
   exact import lines and source metadata are retained in the acquisition
   ledger. No further bodies were read from that incidental set. The route
   was resolved to the named Data.CFTA.Internal.Tree source.

4. The named Tree.hs cut requested lines 305-425, but the source has 423
   lines. Python returned actual lines 305-423. The initial ledger recorded
   the requested end 425. The pre-correction ledger is retained unchanged.
   The current ledger retains requested 305-425 and correct actual 305-423.
   The source copy and its hash did not change.

5. The retained-copy check detected basename collisions in the incidental
   extraction import locator copies (Constraint.hs and potentially other
   repeated basenames). Earlier writes had been overwritten by later files
   with the same basename. The complete raw locator was already retained.
   Its exact per-source selected lines reconstructed unique source-qualified
   copies with the original expected hashes. The pre-correction ledger,
   original overwritten payloads, and exact validation error are retained.
   The corrected ledger records original_copy and each new unique copy. No
   source line or source SHA changed, and no new source acquisition occurred.
