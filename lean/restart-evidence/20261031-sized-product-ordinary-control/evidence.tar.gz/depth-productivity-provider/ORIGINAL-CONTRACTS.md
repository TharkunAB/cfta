# Existing predicates and precise next original contracts

## Existing declarative size prefix

SourceSizedQueries.through lines 181-182 is:

```lean
def through (classes : Nat → List α) (bound : Nat) : List α :=
  (List.range (bound + 1)).flatMap classes
```

SourceSizedReferenceAPI.through_exact lines 46-51 states:

```lean
term ∈ SourceSizedQueries.through (fun size => classes A size state) bound ↔
  Accepts A state term ∧ nodeSize term ≤ bound
```

through_complete lines 54-60 gives eventual membership for each original accepted
finite term, despite empty size gaps. PublicContracts.enumeration_exact lines 71-81
states the corresponding result for its current public reference Api. Its
current gates are publicSized input=.ok api and ActiveOption for equality
constraints of trimmed rows, with original formulas and solver semantics.
finite_class lines 29-38 supplies finite ClassEvaluation using decreasing size.
Those are reference/API results, not a proven execution correspondence for
the actual Haskell optimized worker or every Prefix route.

For a preorder-token query q, the public intended completion list is this
size-bounded list restricted to q being a prefix of preorder(t), in the same
order. This is directly specified by current Sized.Prefix documentation and
its actual filtered/indexed routes. No arbitrary worker policy is inserted.
A formal equality from the relevant actual worker/adapters to this specific
original list was not found in the inspected producer modules. This inventory
does not claim that no related result exists elsewhere in the repository.

## Existing operational prefix relation

PreparedFiniteOutputPrefix.run_finite_resources_outputs_prefix lines 54-92 constructs
two stable actual outcomes at supplied depths from current original packets
and their reservations. Its output claim is only:

```lean
List.IsPrefix (hookOutputs first) (hookOutputs last)
```

This is not an original declarative requested-prefix predicate. It neither
selects a sufficient depth nor proves equality with the list above.

## Original local-finiteness property for custom cost orders

This is a precise mathematical contract to formalize, not an existing Lean
declaration and not a hypothesis to silently add to every current theorem.
For original finite rows R, root state r, and original cost callback c, let
PartialRows(R,r) be the finite partial derivation trees: every Built node
carries an original row identity; every Hole carries its original child state.
Let optimistic(R,c,p) replace each hole with the raw least cost of its state,
as the current cost-search priority does. Unproductive holes give no key.

For every requested key K, require this original set to be finite:

    {p in PartialRows(R,r) | optimistic(R,c,p) is defined and ≤ K}.

This refers only to original grammar rows, row identities, cost order, and
raw least costs. It supplies no future output, actual depth, history, Trace,
or execution witness. Accepted-term finiteness alone is weaker and fails in
the nonempty candidate. The property is sufficient for the queue obstruction
only with terminating local callbacks and actual progress of each local job.
It does not bound arbitrary native normalization or callback work by itself.

## Concrete next original-size producer

For the existing public size-bounded route, derive the condition from the
original positive node-size input instead of supplying it as a new gate.
Prefix.bySize lines 575-627 constructs original states(state,n), root sizes 1..B,
and rows whose child sizes sum to n−1 and meet positive minimum sizes.
The exact next original adapter contract is:

- Every reachable child pair(state_i,n_i) has 1≤n_i<n.
- Its accepted terms have exactly n nodes; the synthetic root accepts
  precisely original accepted terms with nodeSize≤B.
- The size-product domain is finite from the original finite state table
  and the original bound B.
- Current fromFTA/trim/restriction construction carries that original rank
  to the required native structural/progress gate at the actual entry.

The final bullet must be proved from actual construction. Finite denotation
alone does not imply native finite-ordinary syntax. normal_lineage_review
owns that next source investigation. No sufficient native recursive depth
or hidden endpoint preservation is assumed here.
