# Source ownership and freshness coordination

normal_lineage_review owns the original depth/normal-lineage source lane.
It supplied exact existing ConstructedResources (156 lines) SHA
b460067b8fcee75bc55b020e5583e095b1975a7f365db60d43555d84bb36b566,
and ExecutionOriginalPaths (128 lines) SHA
954dfc48016d33c6afe7ac5423a47d5f6ebb252094214d7a36e9858ec05f073f.
This owner did not acquire those whole sources again. Their immutable byte
copies were offered from /tmp/mcfta-original-depth-next-review-20261031.

This owner supplied the actual public Prefix/Sized routes, the existing
size-reference prefix predicates, and current cost-search source pins.
normal_lineage_review now owns investigation of Interned.fromFTA and whether
the actual positive-size product yields the required native finite-ordinary
structural predicate. This owner did not assume that implication.

Root supplied authoritative scope and confirmed byte-exact Tree/EGraph/Prefix
source equality at current main bd5a406a6a3f84b7e3ae0906082783911509df83 and the
live checkout. Its JSON comparison is retained with an exact reuse pin.
This was read-only source metadata comparison, not Haskell/native execution.
No child compiler, evaluator, Git, network, board, production edit, or spawn ran.
