# Current-source lexicographic progress obstruction candidate

SOURCE-GROUNDED CANDIDATE ONLY. No evaluation or formal proof was performed.
This is an existing documented progress limit, not a new Haskell defect.

## Original finite grammar and accepted prefix

Use distinct symbols a, u, z, bad, good and three states A,Z,R:

- A has rows a and u(A).
- Z has its single row z.
- R has rows good and bad(A,Z).
- Only bad has an equality constraint, between paths [0] and [1].
- There is no unconstrained plain bad row in R.

Every A-term is u^n(a), which differs from z. Every bad(u^n(a),z) is rejected.
The accepted language of R is the nonempty singleton {good}. Therefore its
mathematical first accepted prefix [good] exists. This is not an empty-language
counterexample.

For lexicographic Integer pairs, define a base b(good)=(1,0) and b(s)=(0,0)
for every other symbol. If m is the maximum of the symbol base and all child
costs, set c(s,children)=(m.first,m.second+1). This callback is monotone in
child costs and strictly exceeds each child, including arbitrary Integer pairs.
The cost of good is (1,1). The cost of bad(u^n(a),z) is (0,n+2), always below good.

## Current route and why the candidate still applies

Current EGraph.termsByCost lines 759-795 calls Internal.Tree.termsByCostBy with the
constraint check as its check argument. Its least-cost analysis does not
filter complete constrained terms first. Its rowOf keeps constrained bad
because no matching plain bad row exists.

Current Tree.termsByCostBy lines 322-359 pops Map.minViewWithKey. Holes expand by the
original outgoing rows. Its complete function tests the constraint only after
all subterms have completed. No early partial constraint test appears in this
route. The raw least bounds are least(A)=least(Z)=(0,1), least(R)=(0,2).

After the root expansion, good has priority (1,1). The partial bad branch has
priority (0,2). Filling the A hole leaves an a alternative and a u alternative.
The former completes to a rejected bad candidate. The latter leaves another
A hole with a priority whose first component remains 0. Repeating gives another
cheaper partial bad branch before good at every finite stage. The queued good
therefore has infinitely many earlier raw partial jobs in this source model.
This is a queue-invariant argument to formalize, not an observed current run.
It does not depend on a finite timeout as proof of nontermination.

The exact Tree, EGraph, and public Prefix bytes were compared by Root against
current main bd5a406a6a3f84b7e3ae0906082783911509df83 and the live checkout.
All three comparisons match the acquired source pins. Evidence is retained
in ROOT-current-main-source-pins.json. Root performed only read-only blob/hash
comparison. No Haskell/native execution occurred in this task.

## Exact limit of the obstruction

This candidate concerns cost-priority extraction. The recursive workers'
order parameter is an expandable-slot hint, not this cost callback. The
candidate does not directly refute their sufficient-depth statement.
It also does not refute standard positive-size bounded Prefix completions.
The current public cost-search documentation already requires finiteness of
generated partial terms below each cost bound for this progress claim.
Historical FINDINGS records a timeout and earlier witness execution. Those
remain historical evidence only and are not presented as current execution.
