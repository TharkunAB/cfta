from pathlib import Path
import subprocess,json
r=Path('/tmp/mcfta-sized-product-ordinary-control-20261031');repo=Path('/home/tritlo/Code/mcfta')
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert git('branch','--show-current')=='formalize'
assert git('rev-parse','HEAD')=='31dbe59c648c6f5667d4995af77b85438a762723'
assert git('remote','get-url','origin')=='git@github.com:TharkunAB/cfta.git'
assert not git('diff','--cached','--name-only')
modules=json.loads((r/'modules.json').read_text());audit=repo/'lean/MicroCFTA/Audit.lean';final=audit.read_bytes()
expected={'lean/MicroCFTA/Audit.lean','NEXT-PROMPT.md','HANDOFF.md','FINDINGS.md','lean/notes-current-sized-product-ordinary.md'}|{'lean/MicroCFTA/'+name+'.lean' for name in modules}
status=subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=repo).split(b'\0');paths={v[3:].decode() for v in status if v};assert paths==expected,paths
result=subprocess.run(['git','diff','--check'],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/'pre-source-diff-check.raw.log').write_bytes(result.stdout);assert result.returncode==0
messages=['Prove original size-product row rank decrease','Prove ordered Integer size-split correspondence','Construct ordinary native values from ranked rows','Derive ordinary native input for bounded size products'];rows=[]
try:
 for index,(name,message) in enumerate(zip(modules,messages),1):
  audit.write_bytes((''.join('import MicroCFTA.'+m+'\n' for m in modules[:index])).encode()+(r/'prior-Audit.lean').read_bytes())
  files=['lean/MicroCFTA/'+name+'.lean','lean/MicroCFTA/Audit.lean'];subprocess.run(['git','add','--',*files],cwd=repo,check=True);assert set(git('diff','--cached','--name-only').splitlines())==set(files)
  result=subprocess.run(['git','commit','-m',message],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/f'source-commit-{index}.raw.log').write_bytes(result.stdout);assert result.returncode==0,result.stdout
  row={'module':name,'commit':git('rev-parse','HEAD'),'message':message,'files':files};rows.append(row);(r/'source-commits.json').write_text(json.dumps(rows,indent=2)+'\n')
finally:audit.write_bytes(final)
assert not git('diff','--','lean/MicroCFTA/Audit.lean');assert len(rows)==4
print(json.dumps(rows))
