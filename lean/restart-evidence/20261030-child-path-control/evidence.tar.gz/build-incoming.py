from pathlib import Path
import json

ROOT=Path('/home/tritlo/Code/mcfta')
AREA=Path('/tmp/mcfta-child-path-control-20261030')
old=(ROOT/'lean/MicroCFTA/SourcePruningEnumerationIncomingProper.lean').read_text()
def convert(text):
    return (text.replace('finish_singleton_proper','finish_singleton_paths')
        .replace('finish_reply_proper','finish_reply_paths').replace('run_proper','run_paths')
        .replace('ProperState','StatePaths P')
        .replace('∀ sc ∈ incomingScs, ProperTrie sc.trie','BucketPaths P incomingScs'))
finish=convert(old[old.index('private theorem finish_singleton_proper'):old.index('  have oldValid :')])
finish+='''  have oldPaths : BucketPaths P oldScs :=
    valid (.unenumerated oldNode oldScs) (List.mem_of_getElem? stored)
  have payload : BucketPaths P (references
      (.unenumerated (some handle) (incomingScs ++ oldScs) : UVarValue Symbol)) := by
    simpa only [references] using inputs.append oldPaths
  exact values_set_paths target (.unenumerated (some handle) (incomingScs ++ oldScs))
    valid payload rfl

'''
reply=convert(old[old.index('private theorem finish_reply_proper'):old.index('/-- The actual read and explicit write shape')])
header='''import MicroCFTA.SourcePruningEnumerationPathStorage
import MicroCFTA.SourcePruningEnumerationIncomingCacheAdapter

/-!
# Stored paths through actual incoming writes

The actual read retains all stored paths.
An incoming write appends its bucket to the actual stored bucket.
The explicit write law also covers raw rejection.
-/
namespace MicroCFTA.SourcePruningEnumerationIncomingNode
open EnumerationState EnumerationSchedule EnumerationCorrectness
open InternedConstructorTemplates SourcePruningEnumerationPathTransport
open SourcePruningEnumerationPathStorage
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Core" => EnumerationState.State Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Raw" => List (Except EnumerationState.Error (Unit × Core))
variable {P : EqualityTrie.Path → Prop}
attribute [local instance] SourcePruningEnumerationIncomingNode.incomingNodeMonadList

'''
written='''/-- The actual read and write preserve paths even when the raw continuation rejects. -/
theorem written_paths
    (before read after : Core) (fuel uv target handle : Nat) (oldNode : Option Nat)
    (incomingScs oldScs : List Suspended)
    (valid : StatePaths P before) (inputs : BucketPaths P incomingScs)
    (reading : Success (getValue fuel uv) before (.unenumerated oldNode oldScs) read)
    (shape : after = {read with
      values := read.values.set target (.unenumerated (some handle) (incomingScs ++ oldScs))
      recursionAncestry := fun other => if other = target then
        (read.expansionAncestry ++ read.recursionAncestry target).eraseDups
        else read.recursionAncestry other}) : StatePaths P after := by
  have readAndOld : StatePaths P read ∧ BucketPaths P oldScs := by
    obtain ⟨_found, _, stored, rfl⟩ := (getValue_success fuel uv before read
      (.unenumerated oldNode oldScs)).mp reading
    exact ⟨valid, valid (.unenumerated oldNode oldScs) (List.mem_of_getElem? stored)⟩
  rw [shape]
  have payload : BucketPaths P (references
      (.unenumerated (some handle) (incomingScs ++ oldScs) : UVarValue Symbol)) := by
    simpa only [references] using inputs.append readAndOld.2
  exact values_set_paths target (.unenumerated (some handle) (incomingScs ++ oldScs))
    readAndOld.1 payload rfl

end MicroCFTA.SourcePruningEnumerationIncomingNode
'''
text=header+finish+reply+written
path=ROOT/'lean/MicroCFTA/SourcePruningEnumerationPathIncoming.lean'
assert not path.exists()
path.write_text(text)
(AREA/'incoming-v1.lean').write_text(text)
modules=json.loads((AREA/'modules.json').read_text())+['SourcePruningEnumerationPathIncoming']
(AREA/'modules.json').write_text(json.dumps(modules,indent=2)+'\n')
print(len(text.splitlines()))
