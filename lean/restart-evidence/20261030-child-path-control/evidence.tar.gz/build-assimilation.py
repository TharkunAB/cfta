from pathlib import Path
import json

ROOT=Path('/home/tritlo/Code/mcfta')
AREA=Path('/tmp/mcfta-child-path-control-20261030')
old=(ROOT/'lean/MicroCFTA/SourcePruningEnumerationDispatchProper.lean').read_text()
body=old[old.index('theorem dispatch_proper'):old.rindex('end MicroCFTA.SourcePruningEnumerationDispatch')]
assert body.count('(fun absent => ⟨rfl, absent⟩)')==1
assert body.count('(by intro impossible; cases impossible)')==5
body=body.replace('dispatch_proper','dispatch_paths').replace('assimilated_proper','assimilated_paths')
body=body.replace('ProperState','StatePaths P').replace('proper','paths')
body=body.replace(' (fun absent => ⟨rfl, absent⟩)','').replace(' (by intro impossible; cases impossible)','')
header='''import MicroCFTA.SourcePruningEnumerationPathTransport
import MicroCFTA.SourcePruningEnumerationDispatch

/-!
# Stored path preservation through actual native assimilation

The actual writes append the two stored pending buckets.
The path predicate does not depend on their optional native handles.
-/
namespace MicroCFTA.SourcePruningEnumerationDispatch
open EnumerationState EnumerationCorrectness EnumerationSchedule
open InternedConstructorTemplates SourcePruningEnumerationPathTransport
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => InternedConstructorTemplates.Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
variable {EnumGuard : Type} {width : Nat} {P : EqualityTrie.Path → Prop}

/-- The actual target write and source elimination preserve both original path buckets. -/
theorem assimilated_paths
    (before : EnumerationState.State Symbol EnumGuard) (source target : Nat)
    (sourceNode targetNode merged : Option Nat) (sourceScs targetScs : List Suspended)
    (paths : StatePaths P before)
    (sourceStored : before.values[source]? = some (.unenumerated sourceNode sourceScs))
    (targetStored : before.values[target]? = some (.unenumerated targetNode targetScs)) :
    StatePaths P (assimilated before target source (.unenumerated merged (sourceScs ++ targetScs))) := by
  have sourcePaths : BucketPaths P sourceScs :=
    paths (.unenumerated sourceNode sourceScs) (List.mem_of_getElem? sourceStored)
  have targetPaths : BucketPaths P targetScs :=
    paths (.unenumerated targetNode targetScs) (List.mem_of_getElem? targetStored)
  have payload := sourcePaths.append targetPaths
  intro value member
  change value ∈ (before.values.set target
    (.unenumerated merged (sourceScs ++ targetScs))).set source .eliminated at member
  rcases List.mem_or_eq_of_mem_set member with retained | eliminated
  · rcases List.mem_or_eq_of_mem_set retained with old | replacement
    · exact paths value old
    · simpa only [replacement] using payload
  · simp only [eliminated, references, BucketPaths, List.not_mem_nil, false_implies, forall_const]

/-- Every actual successful dispatcher singleton preserves its original path predicate. -/
'''
text=header+body+'end MicroCFTA.SourcePruningEnumerationDispatch\n'
path=ROOT/'lean/MicroCFTA/SourcePruningEnumerationPathAssimilation.lean'
assert not path.exists()
path.write_text(text)
(AREA/'assimilation-v1.lean').write_text(text)
modules=json.loads((AREA/'modules.json').read_text())+['SourcePruningEnumerationPathAssimilation']
(AREA/'modules.json').write_text(json.dumps(modules,indent=2)+'\n')
(AREA/'assimilation-v1.json').write_text(json.dumps([
    ['lake','assimilation-v1-build','MicroCFTA.SourcePruningEnumerationPathAssimilation'],
    ['strict','assimilation-v1-strict','SourcePruningEnumerationPathAssimilation']],indent=2)+'\n')
print(len(text.splitlines()))
