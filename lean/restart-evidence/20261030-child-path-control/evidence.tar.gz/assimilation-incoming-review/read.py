from pathlib import Path
import sys, json, hashlib

root = Path('/home/tritlo/Code/mcfta')
area = Path('/tmp/mcfta-child-path-control-20261030/assimilation-incoming-review')
relative = sys.argv[1]
source = (root / relative).read_bytes()
lines = source.splitlines(keepends=True)
start = int(sys.argv[2]); requested_end = int(sys.argv[3])
end = min(requested_end, len(lines))
assert 1 <= start <= end
copied = b''.join(lines[start-1:end])
manifest = area / 'acquisitions.json'
rows = json.loads(manifest.read_text()) if manifest.exists() else []
ident = f'{len(rows)+1:03d}'
destination = area / 'cuts' / (ident + '-' + Path(relative).name)
destination.parent.mkdir(exist_ok=True)
destination.write_bytes(copied)
digest = lambda data: hashlib.sha256(data).hexdigest()
row = dict(path=relative, requested_start=start, requested_end=requested_end,
           actual_start=start, actual_end=end, source_lines=len(lines),
           source_bytes=len(source), source_sha256=digest(source),
           copy_path=str(destination.relative_to(area)), copy_bytes=len(copied),
           copy_sha256=digest(copied), whole=start == 1 and end == len(lines))
rows.append(row); manifest.write_text(json.dumps(rows, indent=2)+'\n')
print(json.dumps(row))
for number, line in enumerate(copied.decode().splitlines(), start):
    print(f'{number}: {line}')
