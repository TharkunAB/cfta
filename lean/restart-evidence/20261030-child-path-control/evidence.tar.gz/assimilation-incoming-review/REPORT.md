# Independent review: assimilation and incoming path transport

Result: no blocking issue found in the two exact passing modules. Both preserve an arbitrary fixed path predicate P. They add no satisfying-model, trie-validity, counter, semantic-admission, or absent-handle bucket-emptiness premise. The review did not execute Lean or project code and made no repository changes.

## Exact reviewed sources and checks

| Module | Lines | Bytes | SHA256 |
| --- | ---: | ---: | --- |
| PathAssimilation | 203 | 14,307 | `049f0dd8ef02d91f8d6fee1fd217a55e8a76d2689d84f52300676e3987d99012` |
| PathIncoming | 135 | 6,756 | `763647fcac2d023798aa91772f17b2e65ca759b1e8ed79926e3ce84a51d92c6d` |

The full module filenames have prefix `SourcePruningEnumeration`. Both literal copies match their Root build and strict input snapshots byte for byte. Root reports passing builds and empty strict logs. The retained build logs confirm 1,974 jobs for Assimilation and 1,975 jobs for Incoming. The reviewer read both complete passing build logs and verified that both strict logs have zero bytes.

The replayed warning in those build logs belongs to the older InternedFreshOrdinaryClosedCompletion source. The new target strict logs are empty. This review does not treat that replayed warning as a new target failure.

## Assimilation contract and cases

`SourcePruningEnumerationDispatch.assimilated_paths` requires StatePaths on the original state and the two actual stored pending values. It concludes StatePaths on the literal target write followed by source elimination. It derives both bucket properties directly from the original stored values. It appends those properties and applies the two actual List.set membership cases.

The optional native handles are arbitrary. In particular, a None handle does not force its bucket to be empty. This is a useful difference from the old properness helper: ProperValue needs a special empty-bucket condition for pure slots, whereas StatePaths can describe represented paths in any pending bucket. Removing that old condition is justified by the new property.

`dispatch_paths` retains the exact old successful-dispatcher scope: the actual dispatcher must select an action, and that action at the original core must return the actual successful singleton. It does not assume a successful later callback or accepted generated term.

Every old operational branch is retained:

* Equal source and target select the actual no-op before any slot read.
* An eliminated source also selects the no-op.
* Missing source or target slots cannot satisfy the selected-action equation where the dispatcher returns none.
* Enumerated-source and invalid target-value branches select invalidIntersection. They cannot satisfy the successful singleton equation.
* An absent source handle uses finishOptional with the target handle, including None. An absent target handle uses the present source handle. The explicit empty handle rejects. Other optional handles preserve the appended buckets.
* With two present handles, missing decodes cannot select a completed action. Yielded, failed, constraint-error, and blocked native outcomes are handled by the actual dispatcher equations.
* A completed native query follows the actual enabled-empty check, replacement, and encoding. Empty replacement rejects. Every remaining constructor uses the same literal appended-bucket assimilation.

No case uses a term model or a model-derived path bound. The new theorem matches the old dispatch_proper branch coverage and strengthens the input domain for the path-only property. Its successful-singleton premise must remain visible in any summary. It is not a claim about a completed row on every fault or rejection.

## Incoming read, singleton, and raw write

`SourcePruningEnumerationIncomingNode.run_paths` has two conclusions. The first gives StatePaths on the actual outer read core for every fixed set of bounds and every operational result. It needs no singleton premise. The second gives StatePaths on each actual successful singleton core.

The source run first finds a representative. Failure returns the original core. Success changes only the representatives in the outer read core. It then distinguishes missing and invalid slots, absent or present stored handles, decoding, native query outcomes, enabled-empty results, and replacement encoding. The outer read never changes values. A successful finish installs the append of the incoming bucket and the actual stored bucket. The proof follows the same cases as the old run_proper theorem, with P fixed throughout.

The private finish helper reads old bucket paths directly from StatePaths. It does not copy the old None-handle emptiness premise. An empty replacement returns no raw singleton. The singleton conclusion is conditional in that branch; the outer-read conclusion still applies.

`written_paths` supplies the separate law required for raw rejection. It assumes the actual getValue Success and the explicit after-state shape. It derives paths for the read state and its actual old bucket from getValue_success, then applies the checked generic values_set_paths theorem to the append. It does not assume that finish returned a singleton or that replacement was nonempty. Target and read variable may differ; the path law depends only on the supplied read and write evidence.

The exact raw adapter definition was inspected. For raw `[]`, it reads the old pending bucket at the target, constructs `.unenumerated (some 0) (incomingScs ++ oldScs)`, performs the native index write, and frames the candidate with the literal written core. Thus the same append law applies to the synthetic empty write. For a raw successful singleton, the adapter frames the exact returned core. Other raw shapes return no candidate.

Scope qualification: PathIncoming itself proves the outer-read, singleton, and explicit-write laws. It does not yet contain a theorem about every adapted candidate. That later theorem must compose the actual adapter shape with these laws. The raw-rejection argument does not rely only on the singleton conclusion. The current public write theorem is named written_paths; the review found no declaration named written_shapes in the inspected tree.

## Public headers and failed attempts

The two Incoming public declaration headers are byte-identical across the v1, v2, and passing v3 input snapshots. Their full source identities and exact headers are retained. The v2-to-v3 diff changes one indentation space in a private-helper application. It does not change a public premise or conclusion.

The full v1 diagnostic has 14,575 bytes. Root reported reading it fully, and this reviewer also read it fully without truncation. It concerns the unsuccessful private-helper application in the operational proof. Root fixed that application by specifying P explicitly.

The v2 diagnostic has 340,189 bytes. It is pinned in full, but this reviewer did not read it semantically. Root reported examining only the leading parser error. Neither the report nor the check manifest claims that Root read the whole v2 cascade. The final passing source and empty strict log are pinned separately.

## Acquisition and remaining scope

Two complete new proof modules were read. Four new bounded old-source cuts cover the actual incoming run, the actual dispatcher, the raw adapter, and the old adapter properness route. Two exact old scopes were reused from Root after checking current full source identities: DispatchProper lines 66–227 and IncomingProper lines 1–167.

There were no endpoint overruns or failed acquisitions. No complete old source was newly acquired. The combined IncomingProper scopes cover 205 of 234 lines; this broad union is disclosed and can conservatively count as one of the two allowed old-source equivalents. DispatchProper reuse covers 162 of 227 lines. All copied bytes and source hashes are recorded.

This review does not establish recursive all-state path transport, a capacity-independent carrier, global completion, exact public order, or Haskell correspondence. Root owns the remaining compositions and checks. No Haskell source was read and no Haskell defect or fix was established.
