from pathlib import Path
import ast
import gzip
import hashlib
import json
import re
import subprocess
root = Path('/home/tritlo/Code/mcfta')
base = root/'lean/restart-evidence'
archive_control = base/'20261118-source-entry-endpoint-seeds-checkpoint-control-draft'
work = base/'20261118-source-entry-endpoint-seeds-work'
runtime = base/'20261118-source-entry-endpoint-seeds-import-repair-publication'
archive = base/'20261118-source-entry-endpoint-seeds-checkpoint'
prior_archive = base/'20261118-worker-current-seeds-checkpoint'
publication_control = base/'20261118-source-entry-endpoint-seeds-import-repair-publication-control-draft'
board_prefix = 'current-board-source-entry-endpoint-seeds-'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
git = lambda *args: subprocess.check_output(['git',*args],cwd=root)
assert (archive_control/'STATUS.txt').read_text().startswith('FROZEN'),'OPEN control; do not execute.'
assert Path(__file__).resolve().parent == work.resolve() and Path(__file__).read_bytes() == (archive_control/'prepare-checkpoint-controls.py').read_bytes()

def records(value):
    if isinstance(value,list):
        return [(e.get('file',e.get('path')),e)for e in value]
    for key in ['files','pins']:
        if key in value:
            return records(value[key])
    return value.items()

def verify(path,record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256']if isinstance(record,dict)else record),str(path)
    if isinstance(record,dict)and 'bytes'in record:
        assert len(data) == record['bytes'],str(path)
    return data

def packet(path,digest=None):
    if digest is not None:
        verify(path/'MANIFEST.json',digest)
    for name,record in records(read(path/'MANIFEST.json')):
        verify(path/name,record)

packet(archive_control)
for name,record in records(read(archive_control/'SOURCE-PINS.json')):
    verify(root/name,record)
stage = read(work/'SOURCES-NORMAL-STAGING.json')
assert stage['status'] == 'SOURCE_NORMAL_STAGING_COMPLETED'and stage['normal_Source_changed']
assert (stage['source_files'],stage['audit_imports'],stage['audit_reports'],stage['independent_reports']) == (6287,5287,748,343)
assert (stage['fresh_public_reports'],stage['fresh_private_reports'],stage['inherited_reports'],stage['combined_reports']) == (2,1,560,563)
assert stage['new_public_theorems'] == 2 and stage['new_private_theorems'] == 1 and stage['new_private_helpers_transitive'] == stage['new_definitions'] == 0
assert stage['definition_checks'] == stage['definition_axiom_credit'] == 0
assert stage['new_modules'] == stage['changed_existing_owners'] == 1 and stage['Audit_changed']
overrides = stage['baseline_overrides']
assert set(overrides) == {'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean','lean/MicroCFTA/Audit.lean'}

def historical(name,record):
    digest = record['sha256']if isinstance(record,dict)else record
    for path in [root/name,root/overrides.get(name,name)]:
        if path.is_file()and sha(path.read_bytes()) == digest:
            return verify(path,record)
    raise AssertionError(name)

source_receipt,provenance = read(work/'SOURCE-COMMIT.json'),read(work/'SOURCE-COMMIT-ACTUAL-RUN.json')
code = source_receipt['source_commit']
assert code == provenance['source_commit'] and re.fullmatch(r'[0-9a-f]{40}',code)
assert source_receipt['parent'] == stage['prior_checkpoint'] == 'e54bd1879c3ab2c01c4815ec0f81b87533b7ca32'
assert type(provenance['actual_session']) is int and provenance['actual_terminal']and provenance['actual_terminal_exit'] == 0
commit_control = base/provenance['controller']
assert commit_control.name == '20261118-source-entry-endpoint-seeds-source-commit-control-draft'
packet(commit_control,provenance['control_manifest_sha256'])
assert (work/'commit-source.py').read_bytes() == verify(commit_control/'commit-source.py',provenance['script_sha256'])
assert read(commit_control/'MANIFEST.json')['all_final_receipts_bound_before_freeze']
assert (source_receipt['new_public_theorems'],source_receipt['new_private_theorems'],source_receipt['new_definitions']) == (2,1,0)
assert git('branch','--show-current').decode().strip() == 'formalize' and git('rev-parse','HEAD').decode().strip() == code
assert git('rev-parse',code+'^').decode().strip() == stage['prior_checkpoint'] and not git('status','--porcelain','--untracked-files=no')
assert set(git('diff','--name-only',stage['prior_checkpoint'],code).decode().splitlines()) == set(stage['exact_Source_write_paths'])
for name in stage['exact_Source_write_paths']:
    assert git('show',code+':'+name) == (root/name).read_bytes()
    if name in overrides:
        assert git('show',stage['prior_checkpoint']+':'+name) == (root/overrides[name]).read_bytes()
    else:
        assert not git('ls-tree','--name-only',stage['prior_checkpoint'],'--',name)
for name in ['NEXT-PROMPT.md','HANDOFF.md','FINDINGS.md']:
    assert (root/name).read_bytes() == git('show',code+':'+name)
publication,actual = read(work/'IMPORT-REPAIR-PUBLICATION-VERIFIED.json'),read(work/'IMPORT-REPAIR-PUBLICATION-ACTUAL-RUN.json')
assert publication['actual_session'] == actual['actual_session'] == source_receipt['publication_actual_session']
assert publication['actual_terminal']and actual['actual_terminal']and publication['actual_terminal_exit'] == actual['actual_terminal_exit'] == 0
report = json.loads(verify(runtime/'checked.json',publication['checked_sha256']))
assert report == json.loads(verify(runtime/'results.json',publication['results_sha256']))and report['checks'] == publication['checks']
assert [e['total_axiom_reports']for e in report['checks']] == [748,3,343,748,748]
assert all(e['exit'] == 0 and not e['diagnostics']and not e['sorryAx']and not e['nonstandard_axioms']and e['declaration_checks'] == 0 for e in report['checks'])
assert report['all_five_gates_passed']and report['source_pins_unchanged']
assert report['audited_theorems'] == publication['audited_theorems'] == source_receipt['audited_theorems']
assert type(report['audited_theorems']) is int and report['definition_checks'] == report['definition_axiom_credit'] == 0
public_pins = json.loads(verify(runtime/'source-pins.json',publication['source_pins_sha256']))
assert len(public_pins) == publication['pins_independently_reverified']
for name,record in public_pins.items():
    verify(root/name,record)
private_meta = read(publication_control/'PRIVATE-CHECK.json')
private,private_actual = read(root/private_meta['verified_receipt']),read(root/private_meta['actual_receipt'])
assert private['actual_terminal']and private_actual['actual_terminal']and private['actual_terminal_exit'] == private_actual['actual_terminal_exit'] == 0
assert private['actual_session'] == private_actual['actual_session'] == stage['actual_private_session']
private_run = base/private['runtime']
private_result = json.loads(verify(private_run/'checked.json',private['checked_sha256']))
assert private_result == json.loads(verify(private_run/'results.json',private['results_sha256']))and private_result['checks'] == private['checks']
assert [e['total_axiom_reports']for e in private_result['checks']] == [2,1]
for name,record in json.loads(verify(private_run/'source-pins.json',private['source_pins_sha256'])).items():
    historical(name,record)
assert stage['fresh_classification']['per_qname'] == source_receipt['per_qname_classification']
assert len(stage['fresh_classification']['per_qname']) == 3 and sum(e['private']for e in stage['fresh_classification']['per_qname'].values()) == 1
for entry in stage.get('rejected_checks',[]):
    failed = read(root/entry['receipt'])
    assert failed['actual_terminal']and failed['actual_terminal_exit'] == 1 and not failed['proof_credit']
    run = base/entry['runtime']
    assert not (run/'checked.json').exists()
    for name,record in json.loads(verify(run/'source-pins.json',failed['source_pins_sha256'])).items():
        historical(name,record)
rejected_publications = read(archive_control/'rejected-publications.json')
for entry in rejected_publications:
    rejected,rejected_actual = read(root/entry['receipt']),read(root/entry['actual_receipt'])
    assert rejected['actual_session'] == rejected_actual['actual_session'] == entry['actual_session']
    assert rejected['actual_terminal'] and rejected_actual['actual_terminal'] and rejected['actual_terminal_exit'] == rejected_actual['actual_terminal_exit'] == 1
    assert not rejected['proof_credit'] and rejected['credited_public_reports'] == rejected['credited_private_reports'] == 0
    failed_run = base/entry['runtime']
    failed = json.loads(verify(failed_run/'results.json',rejected['results_sha256']))
    assert not (failed_run/'checked.json').exists() and failed['checks'] == rejected['checks']
    failed_pins = json.loads(verify(failed_run/'source-pins.json',rejected['source_pins_sha256']))
    assert len(failed_pins) == rejected['pins_independently_reverified'] == entry['pins']
    for name,record in failed_pins.items():
        historical(name,record)
baseline = read(root/stage['source_baseline_path'])
assert len(baseline['sources']) == 6286 and len(baseline['toolchain']) == 4
for name,record in {**baseline['sources'],**baseline['toolchain']}.items():
    historical(name,record)
assert len(set(baseline['sources'])-set(overrides)) == stage['old_other_Source_files_byte_exact'] == 6284
for component in stage['components']:
    chosen = base/component['packet']
    packet(chosen,component['manifest_sha256'])
    raw = verify(root/component['source_path'],{'bytes':component['raw_bytes'],'sha256':component['raw_sha256']})
    assert raw == (chosen/component['source']).read_bytes()
    for filename,digest in component['headers'].items():
        header = verify(chosen/filename,digest)
        layouts = [header]+([header[:-1]]if header.endswith(b'\n')else[])
        assert sum(raw.count(layout+b' := by\n')for layout in layouts) == 1
owner = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
audit = 'lean/MicroCFTA/Audit.lean'
old_owner = historical(owner,baseline['sources'][owner]);old_audit = historical(audit,baseline['sources'][audit])
assert len(old_owner) == 2744218 and (root/owner).read_bytes().startswith(old_owner)
assert len(old_audit) == 436889 and (root/audit).read_bytes()[59:59+436889] == old_audit
bindings = read(archive_control/'prior-bindings.json')
for filename,key in [('manifest.json','prior_manifest_sha256'),('checkpoint.json','prior_checkpoint_json_sha256')]:
    data = verify(prior_archive/filename,bindings[key])
    assert git('show',stage['prior_checkpoint']+':'+str((prior_archive/filename).relative_to(root))) == data
old_pins = json.loads(gzip.decompress((prior_archive/'source-pins.json.gz').read_bytes()))
assert {n:v['sha256']for n,v in baseline['sources'].items()} == {n:v for n,v in old_pins.items()if n.startswith('lean/MicroCFTA/')and n.endswith('.lean')}
for name,record in old_pins.items():
    historical(name,record)
request,canonical = read(work/(board_prefix+'request.json')),read(work/(board_prefix+'canonical.json'))
assert canonical['verified'];post = canonical.get('post',canonical)
assert post['id'] == request['request_id']and type(post['sequence']) is int
for key,expected in [('author',request['username']),('thread_id',request['thread_id']),('post_type',request['post_type']),('content',request['content']),('metadata',request['metadata'])]:
    assert post[key] == expected,key
assert post['metadata']['source'] == code and not post['metadata']['joint_finite_completion_proved']
cleanup = read(work/'COMBINED-TMP-CLEANUP.json')
expected_runs = {private['actual_session']:private_run.name,actual['actual_session']:runtime.name}
expected_runs.update({e['actual_session']:e['runtime']for e in stage.get('rejected_checks',[])})
expected_runs.update({e['actual_session']:e['runtime']for e in rejected_publications})
assert len(cleanup['runs']) == cleanup['owned_terminal_directories'] == len(expected_runs)
assert {e['actual_session']:e['runtime']for e in cleanup['runs']} == expected_runs
assert cleanup['all_targets_removed']and cleanup['normal_cache_preserved']and cleanup['unknown_tmp_entries_preserved']and cleanup['no_cache_data_copied']
cumulative = 7320493405
for entry in cleanup['runs']:
    assert entry['prior_cumulative_removed_bytes'] == cumulative
    cumulative += entry['regular_bytes_removed'];assert entry['cumulative_removed_bytes'] == cumulative
    assert entry['owned_terminal_only']and entry['normal_cache_preserved']and entry['all_targets_removed']and entry['no_cache_data_copied']and not entry['live_process_references']
    if entry['regular_bytes_removed'] == 0:
        assert entry['symlink_only_terminal_namespace']and entry['no_regular_data_unlinked']
    else:
        assert entry['scope_ActiveState'] == 'inactive'and entry['generated_terminal_outputs_only']and entry['no_source_or_normal_cache_data_unlinked']
    assert not Path(entry['path']).exists()and not Path(entry['path']).is_symlink()
assert cumulative == cleanup['cumulative_removed_bytes']
assert sum(e['regular_bytes_removed']for e in cleanup['runs']) == cleanup['regular_bytes_removed_this_batch']
assert sum(e['symlinks_removed']for e in cleanup['runs']) == cleanup['symlinks_removed_this_batch']
start,resume = read(work/'START.json'),read(work/'RESUME-AUTHORIZATION.json')
assert start['expected_public_reports'] == 2 and start['expected_explicit_private_reports'] == 1 and start['new_definitions'] == 0
assert resume['manual_work_explicitly_authorized']and resume['earlier_usage_pause_lifted']and not resume['goal_status_change_performed']and not resume['goal_completion_claimed']
usage = read(root/read(archive_control/'historical-usage-selection.json')['path'])
percent = usage['rate_limits']['primary']['used_percent']
current_path = root/read(archive_control/'current-usage-selection.json')['path'];current = read(current_path)
assert type(current['used_percent'])in[int,float]and not current['pause_required']and current['pause_threshold_percent'] == 80
assert code in (work/'LIVE-HANDOFF.md').read_text()
roots = read(archive_control/'selection-roots.json');additional = read(archive_control/'archive-additional-roots.json')
assert len(roots) == len(set(roots))and prior_archive.name not in roots
for extra in additional:
    assert extra['current_batch_theorem_credit'] == 0 and not extra['private_runtime_selected']
    packet(base/extra['root'],extra['sha256'])
    for filename in ['SOURCE-PINS.json','DEPENDENCY-PINS.json']:
        path = base/extra['root']/filename
        if path.exists():
            for name,record in records(read(path)):
                historical(name,record)
    roots.append(extra['root'])
assert len(roots) == len(set(roots))and all((base/n).is_dir()and not(base/n).is_symlink()for n in roots)
for name in ['assemble.py','finalize.py','verify.py','commit-checkpoint.py']:
    ast.parse((archive_control/name).read_text())
source_pins = {n:v for n,v in public_pins.items()if n.startswith('lean/MicroCFTA/')and n.endswith('.lean')}
assert len(source_pins) == 6287
tree = hashlib.sha256()
for name,digest in sorted(source_pins.items()):
    tree.update(name.encode()+b'\0'+digest.encode()+b'\n')
selected = sorted(str((base/n).relative_to(root))for n in roots)
config = dict(report)
config.update(checked_code=code,prior_checkpoint=stage['prior_checkpoint'],public_run=str(runtime),public_gates=5,explicit_reports=748,board_prefix=board_prefix,board_post_id=post['id'],board_sequence=post['sequence'],source_tree_sha256=tree.hexdigest(),old_other_Source_files_byte_exact=6284,known_cumulative_tmp_removed_bytes=cumulative,cleanup_receipt='COMBINED-TMP-CLEANUP.json',removed_regular_bytes=cleanup['regular_bytes_removed_this_batch'],removed_symlinks=cleanup['symlinks_removed_this_batch'],historical_primary_usage_percent=percent,historical_primary_usage_checked_at=usage['checked_at'],current_usage_not_measured=False,current_primary_usage_percent=current['used_percent'],current_primary_usage_checked_at=current['sample_at'],current_usage_receipt=str(current_path.relative_to(root)),prior_immutable_archive=prior_archive.name,prior_manifest_sha256=bindings['prior_manifest_sha256'],actual_selected_private_sessions=[private['actual_session']],actual_publication_session=actual['actual_session'],actual_source_commit_session=provenance['actual_session'],executed_source_commit_control=commit_control.name,source_commit_control_bound_after_final_publication=True,persistent_goal_control_status=resume['persistent_goal_control_status'],work_authorized_by_explicit_user_resume=True,goal_active=False,goal_completion_claimed=False,additional_frozen_roots=additional,additional_frozen_roots_theorem_credit=0,future_worker_runtime_selected=False)
skipped = sorted(str(p.relative_to(root))for p in base.iterdir()if p.is_dir()and p.name.startswith(('20261117-','20261118-'))and str(p.relative_to(root))not in selected)
review = dict(selected_roots=len(roots),additional_frozen_roots=additional,fresh_public_reports=2,fresh_private_reports=1,inherited_reports=560,combined_reports=563,new_public_theorems=2,new_private_theorems=1,new_definitions=0,all_root_documents_preserved_as_suffix=True,future_extra_theorem_credit=0,future_worker_runtime_selected=False,joint_finite_completion_proved=False)
note = (archive_control/'checkpoint-note.md').read_text()
for key,value in {'THEOREMS':report['audited_theorems'],'PINS':publication['pins_independently_reverified'],'OWNED_DIRS':cleanup['owned_terminal_directories'],'REMOVED':cleanup['regular_bytes_removed_this_batch'],'SYMLINKS':cleanup['symlinks_removed_this_batch'],'CLEANUP':cumulative,'USAGE':percent,'CURRENT_USAGE':current['used_percent'],'CURRENT_USAGE_TIME':current['sample_at'],'BOARD':post['sequence']}.items():
    note = note.replace('{{'+key+'}}',str(value))
assert set(re.findall(r'\{\{(.*?)\}\}',note)) == {'TIME','TREE','CODE'}
outputs = {'checkpoint-config.json':config,'archive-roots.json':selected,'skipped-published-roots.json':skipped,'selection-review.json':review}
assert not archive.exists()and all(not(work/n).exists()for n in outputs)
# Root writes checkpoint inputs only after all final read-only gates pass.
for name,value in outputs.items():
    (work/name).write_text(json.dumps(value,indent=2)+'\n')
(work/'checkpoint-note.md').write_text(note)
print(json.dumps(dict(checked_code=code,archive=archive.name,roots=len(roots),board_sequence=post['sequence'],fresh_public_reports=2,fresh_private_reports=1,inherited_reports=560,combined_reports=563)))
