from pathlib import Path
import hashlib,json,re,shutil
own=Path('/tmp/mcfta-prepared-semantic-history-20261028/parent-projection')
area=own.parent
repo=Path('/home/tritlo/Code/mcfta')
def ident(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def copy_file(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True)
    data=src.read_bytes()
    if dst.exists(): assert dst.read_bytes()==data
    else: dst.write_bytes(data)
    return ident(data)

mapping=json.loads((area/'parent-final-whitespace.json').read_text())
snap=own/'final-sources'
snap.mkdir(exist_ok=True)
index=json.loads((own/'source-index.json').read_text())
checks=[]
for record in mapping:
    module=record['module']
    prior=own/('drafts/v4' if module.endswith('Edits') else 'drafts/v3')/(module+'.lean')
    source=repo/'lean/MicroCFTA'/(module+'.lean')
    a=prior.read_bytes();b=source.read_bytes()
    assert ident(a)['sha256']==record['old_sha256']
    assert ident(b)['sha256']==record['new_sha256']
    assert a==b+b'\n'
    copy_file(source,snap/source.name)
    lines=b.splitlines(keepends=True)
    cut=own/'cuts'/(module+'-final-whole-body.lean')
    first=next(i+1 for i,line in enumerate(lines) if line.startswith(b'namespace MicroCFTA.'))
    selected=b''.join(lines[first-1:])
    cut.write_bytes(selected)
    entry={'source':str(source),'whole':{'path':str((snap/source.name).relative_to(own)),**ident(b)},
      'cuts':[{'path':str(cut.relative_to(own)),'first_line':first,'last_line':len(lines),**ident(selected)}]}
    index['sources']=[s for s in index['sources'] if s['source']!=str(source)]+[entry]
    checks.append({'module':module,'final':ident(b),'lines':len(lines),'only_removed_one_final_newline':True})
index['status']='OPEN; final installed source and strict receipts captured; public/doc review ongoing'
(own/'source-index.json').write_text(json.dumps(index,indent=2)+'\n')
(own/'final-source-comparison.json').write_text(json.dumps({'status':'PASS','modules':checks},indent=2)+'\n')

receipt_names=[]
for tag in ('primitives','merge','targets','edits','scan','heap'):
    receipt_names.extend(['parent-final-'+tag,'parent-projection-'+tag+'-'+('v4' if tag=='edits' else 'v3'),
      'parent-projection-'+tag+'-build'])
receipts=[]
for name in receipt_names:
    src=area/name
    for basename in ('report.json','raw.log','inputs.json'):
        if (src/basename).exists():
            identity=copy_file(src/basename,own/'evidence'/name/basename)
            receipts.append({'source':str(src/basename),'copy':'evidence/'+name+'/'+basename,**identity})
for basename in ('parent-final-whitespace.json','parent-projection-final-commit.json','parent-commit-whitespace-failure.log'):
    receipts.append({'source':str(area/basename),'copy':'evidence/'+basename,
      **copy_file(area/basename,own/'evidence'/basename)})
(own/'evidence-index.json').write_text(json.dumps({'files':receipts},indent=2)+'\n')

# Preserve each complete #check plus #print axioms block, including byte/line scope.
raw=(area/'public-readback-final/raw.log').read_bytes()
report=json.loads((area/'public-readback-final/report.json').read_text())
assert report['exit_code']==0
assert ident(raw)=={k:report[k] for k in ('bytes','sha256')}
catalog=json.loads((area/'new-public-declarations.json').read_text())
names=[n for n in catalog if 'ProjectionHeap' in n or 'ParentProjection' in n or n in (
  'SourceCurrentAllocatedTargetQuery.Receipt.projection_heap',
  'SourceCurrentAllocatedSharedTargetLeaf.Receipt.projection_heap')]
blocks=[]
for name in names:
    qualified='MicroCFTA.'+name
    start=re.search(rb'(?m)^'+re.escape(qualified.encode())+rb'(?=\s)',raw)
    assert start,name
    axioms=re.search(rb"(?m)^'"+re.escape(qualified.encode())+rb"' depends on axioms: \[([^\]]*)\]\n",raw[start.start():])
    assert axioms,name
    end=start.start()+axioms.end()
    selected=raw[start.start():end]
    path=own/'public-blocks'/(name+'.txt')
    path.parent.mkdir(exist_ok=True)
    path.write_bytes(selected)
    axiom_names=[a.strip().decode() for a in axioms.group(1).split(b',') if a.strip()]
    assert set(axiom_names)<=set(('propext','Classical.choice','Quot.sound'))
    blocks.append({'declaration':qualified,'path':str(path.relative_to(own)),**ident(selected),
      'source':str(area/'public-readback-final/raw.log'),'start_byte':start.start(),'end_byte_exclusive':end,
      'first_line':raw[:start.start()].count(b'\n')+1,'last_line':raw[:end].count(b'\n'),
      'axioms':axiom_names})
assert len(names)==len(blocks)
copy_file(area/'public-readback-final/report.json',own/'evidence/public-readback-final/report.json')
copy_file(area/'public-readback-final/public.lean',own/'evidence/public-readback-final/public.lean')
(own/'public-blocks/index.json').write_text(json.dumps({'status':'Full blocks copied; semantic reading pending',
 'whole_raw_identity':ident(raw),'blocks':blocks},indent=2)+'\n')
for i in range(0,len(blocks),8):
    text=b''.join((own/b['path']).read_bytes()+b'\n' for b in blocks[i:i+8])
    (own/'public-blocks'/f'chunk-{i//8+1}.txt').write_bytes(text)
print(json.dumps({'final_sources':checks,'public_blocks':len(blocks),
 'public_bytes':sum(b['bytes'] for b in blocks),'source_count':len(index['sources']),
 'cut_count':sum(len(s['cuts']) for s in index['sources'])},indent=2))
