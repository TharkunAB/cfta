from pathlib import Path
import re, hashlib, json

ROOT = Path('/home/tritlo/Code/mcfta')
OWN = Path('/tmp/mcfta-prepared-semantic-history-20261028/parent-projection')
OUT = OWN / 'drafts/v1'
used = {}

def read(name):
    p = ROOT / 'lean/MicroCFTA' / (name + '.lean')
    data = p.read_bytes()
    used[name] = (p, data)
    return data.decode()

def body(name):
    text = read(name)
    return text[text.index('namespace MicroCFTA.'):]

notation = '''local notation "Heap" => SourceEqualityAnnotationHeap.Heap
  (fun constraint : Guard => SourcePruningEnumerationConstraint.project constraint ≠ none)'''
prop = '(fun constraint : Guard => SourcePruningEnumerationConstraint.project constraint ≠ none)'
names = {
 'SourcePruningEnumerationProbeExposureArity':'SourcePruningEnumerationProbeExposureProjectionHeap',
 'SourcePruningEnumerationProjectionArity':'SourcePruningEnumerationPathProjectionHeap',
 'SourcePruningEnumerationMergeArity':'SourcePruningEnumerationMemoMergeProjectionHeap',
 'SourcePruningEnumerationAllocatedMergeArity':'SourcePruningEnumerationAllocatedMergeProjectionHeap',
 'SourcePruningEnumerationSharedTargetArity':'SourcePruningEnumerationSharedTargetProjectionHeap',
 'SourcePruningEnumerationSeededArity':'SourcePruningEnumerationSeededProjectionHeap',
 'SourcePruningEnumerationConjunctionArity':'SourcePruningEnumerationConjunctionProjectionHeap',
 'SourcePruningEnumerationClassEditArity':'SourcePruningEnumerationClassEditProjectionHeap',
 'SourcePruningEnumerationScanArity':'SourcePruningEnumerationScanProjectionHeap',
 'SourcePruningEnumerationLocalReductionArity':'SourcePruningEnumerationLocalReductionProjectionHeap',
 'SourcePruningEnumerationParentArity':'SourcePruningEnumerationParentProjectionHeap',
}
def common(text):
    for old, new in names.items():
        text = text.replace(old, new)
    text = text.replace('open SourcePruningEnumerationArityOrigins (Heap)\n', '')
    text = text.replace('open SourcePruningEnumerationArityOrigins (Fits Heap)\n', '')
    text = text.replace('local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula',
        'local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula\n' + notation)
    text = text.replace('SourcePruningEnumerationArityOrigins.node_heap',
        'SourcePruningEnumerationParentProjectionPrimitives.node_heap')
    text = text.replace('SourcePruningEnumerationArityOrigins.unfold_heap',
        'SourcePruningEnumerationParentProjectionPrimitives.unfold_heap')
    return text

def write(name, imports, sections, description):
    text = ''.join('import MicroCFTA.'+n+'\n' for n in imports)
    text += '\n/-!\n# '+description+'\n\nThis draft follows the actual recorded worker endpoints.\nIt does not assert completion of an arbitrary native prefix.\n-/\n'
    text += '\n\n'.join(sections) + '\n'
    # Only documentation terms change here. Proof identifiers remain explicit.
    text = re.sub(r'(?s)/--(.*?) -/', lambda m: '/--'+m.group(1).replace('arity', 'projectability').replace('Arity', 'Projectability')+' -/', text)
    (OUT/(name+'.lean')).write_text(text)

helpers = '''namespace MicroCFTA.SourcePruningEnumerationParentProjectionPrimitives
open InternedConstructorTemplates InternedProbeProvenance
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
'''+notation+'''
variable {Symbol : Type}

/-- Node allocation adds no edge guard. -/
theorem node_heap [DecidableEq (EdgeKey Symbol Guard)]
    (rows : List (EdgeValue Symbol Guard)) (before : State Symbol Guard)
    (heap : Heap before) : Heap (run (makeNode rows) before).2 :=
  SourceEqualityAnnotationHeap.run _ _ (SourceEqualityAnnotationHeap.makeNode _ rows) before heap

/-- Stored unfolding retains every original edge guard. -/
theorem unfold_heap [DecidableEq (EdgeKey Symbol Guard)]
    (value : Value Symbol Guard) (before : State Symbol Guard)
    (facts : InternedNestedFacts.Facts before) (heap : Heap before)
    (available : Available before value) :
    Heap (InternedFreshOrdinaryStoredSubstitution.unfold value before).state :=
  InternedFreshOrdinaryStoredConstraintHeap.unfold_heap _ value before facts heap available

end MicroCFTA.SourcePruningEnumerationParentProjectionPrimitives'''
probe = common(body('SourcePruningEnumerationProbeExposureArity'))
projection = common(body('SourcePruningEnumerationProjectionArity'))
# The original read/cost/available structure applies to open values unchanged.
write('SourcePruningEnumerationParentProjectionPrimitives', [
 'SourceCurrentAllocatedProbeExposure', 'InternedFreshOrdinaryFacts',
 'InternedFreshOrdinaryStoredConstraintHeap', 'SourceEqualityProjectionCosts',
 'SourcePruningEnumerationNativeQueryProjectionHeap', 'SourceCurrentRequiredHeapEffects'],
 [helpers, probe, projection], 'Projectability through actual open exposure and projection')

merge = common(body('SourcePruningEnumerationMergeArity'))
start = merge.index('private theorem top_fits')
end = merge.index('variable [DecidableEq Symbol]', start)
merge = merge[:start]+'''private theorem top_projectable :
    SourcePruningEnumerationConstraint.project (top : Guard) ≠ none := by
  change (some ([], none) : Option (List EqualityTrie.Trie × Option Guard)) ≠ none
  intro impossible
  cases impossible

'''+merge[end:]
# SafeWork needs only the emitted guard, not a child-count condition.
merge = re.sub(r'private theorem map_length .*?(?=private def Checks)', '', merge, flags=re.S)
merge = merge.replace('∀ state, SourcePruningEnumerationNativeArityPrimitives.WorkFits job state',
    'SourceEqualityAnnotationHeap.SafeWork '+prop+' job')
merge = merge.replace('SourcePruningEnumerationNativeArityPrimitives.makeUnion_fits values',
    'SourceEqualityAnnotationHeap.makeUnion '+prop+' values')
merge = merge.replace('SourcePruningEnumerationNativeArityPrimitives.makeNode_fits _',
    'SourceEqualityAnnotationHeap.makeNode '+prop+' _')
start = merge.index('private theorem small_checks')
end = merge.index('private theorem column_checks', start)
merge = merge[:start]+'''private theorem small_checks (clear : Guard → Bool) (edge : EdgeValue Symbol Guard)
    (checked : SourcePruningEnumerationConstraint.project edge.entry.key.constraint ≠ none) :
    Checks clear (small edge) := by
  refine ⟨map_checks clear Code.request edge.children (fun _ _ => trivial), ?_⟩
  intro children before middle memo saved actual
  exact SourceEqualityAnnotationHeap.makeEdge _ _ _ children checked

'''+merge[end:]
merge = merge.replace('fun children _ _ _ _ _ state =>\n    SourcePruningEnumerationNativeArityPrimitives.makeEdge_fits _ _ children state (top_fits _)',
    'fun children _ _ _ _ _ =>\n    SourceEqualityAnnotationHeap.makeEdge _ _ _ children top_projectable')
merge = merge.replace('Fits edge.entry.key.constraint edge.children.length',
    'SourcePruningEnumerationConstraint.project edge.entry.key.constraint ≠ none')
merge = merge.replace('heap.edge before semantic.ready.semantic.1.normal.facts.coherent edge (resident edge original)',
    'heap edge.entry.key edge (resident edge original)')
merge = merge.replace('SourcePruningEnumerationNativeArityPrimitives.work_heap job state heap (checked state)',
    'SourceEqualityAnnotationHeap.run _ job checked state heap')
merge = merge.replace('(SourcePruningEnumerationSelectionArity.select_effect _ fuel _ _ semantic costs certified.1 _ _ done).arity heap',
    '(SourceCurrentMergedHeapEffects.select_effect '+prop+' _ fuel _ _ semantic costs certified.1 _ _ done).annotations heap')
write('SourcePruningEnumerationParentProjectionMerge', [
 'SourcePruningEnumerationParentProjectionPrimitives', 'SourceCurrentMemoMergeEffects',
 'SourceCurrentAllocatedMergeActual', 'SourceCurrentMergedHeapEffects'],
 [merge], 'Projectability through actual memo-aware merge calls')

shared = common(body('SourcePruningEnumerationSharedTargetArity'))
shared = shared.replace('theorem Receipt.arity_heap', 'theorem Receipt.projection_heap')
shared = shared.replace('query.arity_heap', 'query.projection_heap')
shared = shared.replace('SourcePruningEnumerationNativeQueryArity.',
    'SourcePruningEnumerationNativeQueryProjectionHeap.')
seeded = common(body('SourcePruningEnumerationSeededArity'))
seeded = seeded.replace('SourcePruningEnumerationNativeQueryArity.',
    'SourcePruningEnumerationNativeQueryProjectionHeap.')
write('SourcePruningEnumerationParentProjectionTargets', [
 'SourcePruningEnumerationParentProjectionMerge', 'SourceCurrentAllocatedSharedTargetLeaf',
 'SourceCurrentAllocatedSeededQuery'], [shared, seeded],
 'Projectability through actual checked shared and seeded targets')

edit = common(body('SourcePruningEnumerationClassEditArity'))
edit = edit.replace('receipt.arity_heap', 'receipt.projection_heap')
start = edit.index('    have fits : SourcePruningEnumerationArityOrigins.Fits')
end = edit.index('    have field :=', start)
edit = edit[:start]+'''    have guard : SourcePruningEnumerationConstraint.project edge.entry.key.constraint ≠ none :=
      arity edge.entry.key edge (resident _ List.mem_cons_self)
    have rebuiltHeap : Heap (advanceHeap middle heap).checked.native.machine.heap := by
      change Heap heap
      simpa only [rebuilt] using SourceEqualityAnnotationHeap.run
        (fun constraint : Guard => SourcePruningEnumerationConstraint.project constraint ≠ none)
        (makeEdge edge.entry.key.symbol edge.entry.key.constraint values)
        (SourceEqualityAnnotationHeap.makeEdge _ _ _ values guard)
        middle.checked.native.machine.heap middleHeap
'''+edit[end:]
passes = common(body('SourcePruningEnumerationClassPassArity'))
write('SourcePruningEnumerationParentProjectionEdits', [
 'SourcePruningEnumerationParentProjectionTargets', 'SourceCurrentAllocatedClassPass'],
 [edit, passes], 'Projectability through actual shared class edits and class folds')

# Conjunction requirements use the existing arbitrary-annotation theorem.
conjunction = common(body('SourcePruningEnumerationConjunctionArity'))
start = conjunction.index('/-- Each actual exposure')
end = conjunction.index('/-- Equality contradiction', start)
conjunction = conjunction[:start]+'''/-- Actual class requirements retain the whole projection heap. -/
theorem requirements_heap
    {tuple : List (EdgeValue Symbol Guard)} {classes : EqualityNormalize.Constraints}
    {before after : State Symbol Guard} {requirements : List (List (Value Symbol Guard))}
    (actual : Req.Requirements tuple classes before requirements after)
    (semantic : SemanticReady before) (costs : CostHeap before)
    (resident : Edges before tuple) (closed : ClosedEdges tuple) (heap : Heap before) : Heap after :=
  (actual.verified (fun constraint : Guard => SourcePruningEnumerationConstraint.project constraint ≠ none)
    semantic costs heap resident closed).1.annotations

'''+conjunction[end:]
conjunction = conjunction.replace('have current := exposures_heap reads ready.semantic ready.costs available heap',
    'have current := (reads.verified '+prop+' ready.semantic ready.costs heap available closed).1.annotations')
scan = common(body('SourcePruningEnumerationScanArity'))
scan = scan.replace('SourcePruningEnumerationGateArity.Primary.class_effects',
    'SourcePrimaryGateEffects.class_effects '+prop)
scan = scan.replace('SourcePruningEnumerationGateArity.Secondary.class_effects',
    'SourceCurrentSecondaryEffects.class_effects '+prop)
write('SourcePruningEnumerationParentProjectionScan', [
 'SourcePruningEnumerationParentProjectionTargets', 'SourceCurrentConjunctionClassScanCompletion',
 'SourcePrimaryGateEffects', 'SourceCurrentSecondaryEffects', 'SourceCurrentConjunctionMemo'],
 [conjunction, scan], 'Projectability through the actual allocated class scan')

reduction = common(body('SourcePruningEnumerationLocalReductionArity'))
reduction = reduction.replace('SourcePruningEnumerationRequiredArity.requireAll',
    'SourceCurrentRequiredHeapEffects.requireAll '+prop)
parent = common(body('SourcePruningEnumerationParentArity'))
parent = parent.replace('exact (SourceCurrentAllocatedMkEdge.reject_correct formulas solver inventory _ _ ready admitted).preserves_arity_heap heap',
    'exact SourceCurrentAllocatedMkEdge.reject_projectable_heap _ _ heap')
parent = parent.replace('constructor.preserves_arity_heap middleHeap',
    'constructor.preserves_projection_heap receipt.ready.good.operations storedReady middleHeap')
write('SourcePruningEnumerationParentProjectionHeap', [
 'SourcePruningEnumerationParentProjectionScan', 'SourcePruningEnumerationParentProjectionEdits',
 'SourceCurrentAllocatedLocalWorkerActual', 'SourceCurrentAllocatedParentEdgeActual',
 'SourcePruningEnumerationCheckedProjectionHeap'], [reduction, parent],
 'Whole projectability through actual local reduction and parent construction')

# Pin literal reviewed templates. Record exact whole-source bytes independently of drafts.
for name, (p, data) in used.items():
    (OWN/'sources'/p.name).write_bytes(data)

index = {'status':'OPEN; drafts UNTESTED by owner', 'sources':[]}
for name, (p, data) in used.items():
    lines = data.splitlines(keepends=True)
    namespace = next(i+1 for i,l in enumerate(lines) if l.startswith(b'namespace MicroCFTA.'))
    span = b''.join(lines[namespace-1:])
    cut = OWN/'cuts'/(name+'-body.lean')
    cut.write_bytes(span)
    index['sources'].append({'source':str(p), 'whole':{'path':'sources/'+p.name,'bytes':len(data),
      'sha256':hashlib.sha256(data).hexdigest()},'cuts':[{'path':'cuts/'+cut.name,
      'first_line':namespace,'last_line':len(lines),'bytes':len(span),'sha256':hashlib.sha256(span).hexdigest()}]})
(OWN/'source-index.json').write_text(json.dumps(index,indent=2)+'\n')
(OWN/'drafts-v1-status.json').write_text(json.dumps({'status':'UNTESTED; no owner compiler run',
  'modules':[{'path':str(p.relative_to(OWN)),'lines':len(p.read_bytes().splitlines()),'bytes':p.stat().st_size,
    'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.glob('*.lean'))]},indent=2)+'\n')
