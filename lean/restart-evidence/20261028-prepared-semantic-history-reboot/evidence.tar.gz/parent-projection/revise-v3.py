from pathlib import Path
import hashlib,json,re
own=Path('/tmp/mcfta-prepared-semantic-history-20261028/parent-projection')
root=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
out=own/'drafts/v3'
out.mkdir(exist_ok=True)
for p in (own/'drafts/v2').glob('*.lean'):
    (out/p.name).write_bytes(p.read_bytes())

p=out/'SourcePruningEnumerationParentProjectionPrimitives.lean'
s=p.read_text()
start=s.index('/-- Stored unfolding retains')
end=s.index('end MicroCFTA.SourcePruningEnumerationParentProjectionPrimitives',start)
s=s[:start]+s[end:]
start=s.index('namespace MicroCFTA.SourcePruningEnumerationProbeExposureProjectionHeap')
end=s.index('namespace MicroCFTA.SourcePruningEnumerationPathProjectionHeap',start)
s=s[:start]+'''namespace MicroCFTA.SourcePruningEnumerationProbeExposureProjectionHeap
open InternedConstructorTemplates InternedProbeProvenance
open SourceEqualityRequiredSemanticCache
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
  (fun constraint : Guard => SourcePruningEnumerationConstraint.project constraint ≠ none)
variable {Symbol : Type}

/-- A completed row read retains projectability for available open inputs. -/
theorem read_heap [DecidableEq (EdgeKey Symbol Guard)]
    {value : Value Symbol Guard} {before after : State Symbol Guard}
    {rows : List (EdgeValue Symbol Guard)}
    (actual : SourceEqualityProjectionRead.Read value before rows after)
    (semantic : SemanticReady before) (available : Available before value)
    (heap : Heap before) : Heap after := by
  cases actual with
  | done fuel completed =>
      simpa only [completed, MergedSourceExposure.Result.state] using
        SourceCurrentOpenExposureFields.nodeEdges_heap
          (fun constraint : Guard => SourcePruningEnumerationConstraint.project constraint ≠ none)
          fuel value before semantic heap available

/-- The actual head node adds no edge guard after its completed row read. -/
theorem head_heap [DecidableEq (EdgeKey Symbol Guard)]
    {value result : Value Symbol Guard} {before after : State Symbol Guard}
    (actual : SourceEqualityRequiredHead.Head value before result after)
    (semantic : SemanticReady before) (available : Available before value)
    (heap : Heap before) : Heap after := by
  cases actual with
  | read fuel edges middle exposed rebuilt =>
      have middleHeap := read_heap (.done fuel exposed) semantic available heap
      simpa only [rebuilt] using
        SourcePruningEnumerationParentProjectionPrimitives.node_heap edges middle middleHeap

end MicroCFTA.SourcePruningEnumerationProbeExposureProjectionHeap

'''+s[end:]
s=s.replace('semantic.ready.semantic.1.normal.facts (available _ List.mem_cons_self) heap',
    'semantic (available _ List.mem_cons_self) heap')
s=s.replace('semantic.ready.semantic.1.normal.facts available heap', 'semantic available heap')
p.write_text(s)

p=out/'SourcePruningEnumerationParentProjectionEdits.lean'
s=p.read_text().replace('ready.checked.semantic.ready.semantic.1.normal.facts available arity',
    'ready.checked.semantic available arity')
p.write_text(s)

# Attach the complete existing parent receipt packet to the same actual endpoint.
p=out/'SourcePruningEnumerationParentProjectionHeap.lean'
s=p.read_text()
end=s.rindex('end MicroCFTA.SourcePruningEnumerationParentProjectionHeap')
old=(root/'SourceCurrentAllocatedParentEdgeActual.lean').read_text()
verified=old[old.index('theorem verified\n'):old.index(' := by\n',old.index('theorem verified\n'))]
verified=verified.replace('theorem verified\n','theorem verified_projection_heap\n')
verified=verified.replace('(valid : Valid before.native.machine.heap memos) :',
    '(valid : Valid before.native.machine.heap memos) (heap : Heap before.native.machine.heap) :')
verified=verified.replace('    ∃ next, Receipt formulas solver next symbol original loaded inherited values before result after fourth savedFourth memo saved final',
    '    (∃ next, SourceCurrentAllocatedParentEdge.Receipt formulas solver next symbol original loaded inherited values before result after fourth savedFourth memo saved final) ∧\n      Heap after.native.machine.heap')
verified+=''' := by
  have packet := SourceCurrentAllocatedParentEdgeActual.verified formulas solver inventory reads ready admitted live
    correct stored covered valid
  exact ⟨packet, parent_heap formulas solver inventory reads ready admitted live correct stored covered valid heap⟩
'''
finite=old[old.index('theorem finite (formulas'):old.index(' := by\n',old.index('theorem finite (formulas'))]
finite=finite.replace('theorem finite (formulas','theorem finite_projection_heap (formulas')
finite=finite.replace('(memos : Memos) (valid : Valid before.native.machine.heap memos) :',
    '(memos : Memos) (valid : Valid before.native.machine.heap memos)\n    (heap : Heap before.native.machine.heap) :')
finite=finite.replace('        Reads formulas solver actual memos final ∧\n        Receipt formulas solver next symbol original loaded inherited values before result after fourth savedFourth memo saved final',
    '        (Reads formulas solver actual memos final ∧\n          SourceCurrentAllocatedParentEdge.Receipt formulas solver next symbol original loaded inherited values before result after fourth savedFourth memo saved final) ∧\n        Heap after.native.machine.heap')
finite+=''' := by
  obtain ⟨result, after, savedFourth, saved, next, final, actual, reads, receipt⟩ :=
    SourceCurrentAllocatedParentEdgeActual.finite formulas solver inventory budget symbol original loaded inherited
      values before fourth memo ready admitted cached found inheritedReady available correct stored covered ranges memos valid
  have liveInputs : contradictory original = false →
      SourceEqualityGuardReadback.Cached original.equalities ∧
      SourceEqualityConstraintFieldLookup.load original before.operations.constraints = .ok (some loaded) ∧
      SourceEqualityConstraintAllocation.Ready before.operations.constraints inherited ∧
      Values before.native.machine.heap values ∧
      SourceCurrentAllocatedLocalReductionActual.Ranges budget loaded inherited values before fourth :=
    fun test => ⟨cached, found, inheritedReady, available,
      SourceCurrentAllocatedLocalReductionActual.ranges_of_finite (ranges test)⟩
  exact ⟨result, after, savedFourth, saved, next, final, actual, ⟨reads, receipt⟩,
    parent_heap formulas solver inventory reads ready admitted liveInputs correct stored covered valid heap⟩
'''
s=s[:end]+'''/-- The full original actual-return receipt is retained at the same endpoint. -/
'''+verified+'''\n/-- The original finite producer is called once and retains its whole return packet. -/
'''+finite+'\n'+s[end:]
p.write_text(s)

records=[]
for p in sorted(out.glob('*.lean')):
    data=p.read_bytes()
    records.append({'path':str(p.relative_to(own)),'bytes':len(data),'lines':len(data.splitlines()),
        'sha256':hashlib.sha256(data).hexdigest()})
(own/'drafts-v3-status.json').write_text(json.dumps({'status':'UNTESTED; source review only',
  'changes_from_v2':['Use existing arbitrary-annotation open exposure instead of duplicating its bounded induction.',
     'Update read/head helper calls to their available original SemanticReady premises.',
     'Add same-endpoint wrappers retaining the complete original actual verification and finite parent packets.'],
  'dependency_order':['Primitives','Merge','Targets','Edits','Scan','Heap'], 'modules':records},indent=2)+'\n')
