from pathlib import Path
import hashlib,json,re
own=Path('/tmp/mcfta-prepared-semantic-history-20261028/parent-projection')
repo=Path('/home/tritlo/Code/mcfta')
def identity(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
index=json.loads((own/'source-index.json').read_text())
seen={r['source'] for r in index['sources']}
extra={
 'SourceCurrentOpenExposureFields':[(12,89)],
 'SourceCurrentRequiredHeapEffects':[(13,55),(204,245)],
 'SourcePrimaryGateEffects':[(13,38),(147,171)],
 'SourceCurrentSecondaryEffects':[(13,38),(147,172)],
 'SourceCurrentMergedHeapEffects':[(14,45),(216,229)],
 'SourceCurrentMemoMergeEffects':[(15,41),(322,390)],
 'SourceEqualityAnnotationHeap':[(14,108)],
 'SourceCurrentConjunctionRequirements':[(152,173),(216,233)],
 'SourceCurrentConjunctionCompletionReads':[(19,51),(69,90),(173,199)],
 'SourcePruningEnumerationNativeQueryProjectionHeap':[(1,32),(294,336)],
 'SourcePruningEnumerationCheckedProjectionHeap':[(1,52),(81,111)],
 'SourceCurrentAllocatedParentEdgeActual':[(1,60),(64,89),(132,182)],
 'SourceCurrentAllocatedParentEdge':[(32,102)],
 'SourceCurrentAllocatedLocalWorkerActual':[(1,28)],
}
for name,spans in extra.items():
    source=repo/'lean/MicroCFTA'/(name+'.lean')
    data=source.read_bytes()
    lines=data.splitlines(keepends=True)
    whole=own/'sources'/source.name
    if str(source) in seen:
        entry=next(r for r in index['sources'] if r['source']==str(source))
        assert whole.read_bytes()==data
    else:
        whole.write_bytes(data)
        entry={'source':str(source),'whole':{'path':str(whole.relative_to(own)),**identity(data)},'cuts':[]}
        index['sources'].append(entry)
    for first,last in spans:
        last=min(last,len(lines))
        cut=own/'cuts'/(name+f'-L{first}-L{last}.lean')
        selected=b''.join(lines[first-1:last])
        cut.write_bytes(selected)
        entry['cuts'].append({'path':str(cut.relative_to(own)),'first_line':first,'last_line':last,**identity(selected)})

index['status']='OPEN; immutable v1/v2/v3 drafts; compiler review pending Root'
(own/'source-index.json').write_text(json.dumps(index,indent=2)+'\n')

contracts=own/'contracts'
contracts.mkdir(exist_ok=True)
def decl(src,name):
    start=src.index('theorem '+name)
    end=src.index(' :=',start)
    return src[start:end]
comparison={'status':'SOURCE TEXT comparison only; no owner elaboration or printed-public comparison',
 'heap_interpretation_change':'The lexical local notation Heap changes from numeric projected arity to SourceEqualityAnnotationHeap.Heap (fun constraint => Constraint.project constraint != none). All other original runtime admissions remain.',
 'checks':[]}
old=(repo/'lean/MicroCFTA/SourceCurrentAllocatedParentEdgeActual.lean').read_text()
new=(own/'drafts/v3/SourcePruningEnumerationParentProjectionHeap.lean').read_text()
for name,oldfile,newname in [('parent_heap','SourcePruningEnumerationParentArity','parent_heap'),
 ('reduction_heap','SourcePruningEnumerationLocalReductionArity','reduction_heap'),
 ('literal_heap','SourcePruningEnumerationLocalReductionArity','literal_heap')]:
    original=(repo/'lean/MicroCFTA'/(oldfile+'.lean')).read_text()
    a=decl(original,name)
    b=decl(new,newname)
    (contracts/(name+'-original-header.lean')).write_text(a+'\n')
    (contracts/(name+'-draft-header.lean')).write_text(b+'\n')
    comparison['checks'].append({'theorem':name,'literal_header_equal':a==b,
        'original':identity(a.encode()),'draft':identity(b.encode()),
        'qualification':'Equal lexical headers retain their runtime inputs; the documented Heap notation denotes a different property.'})

# Recover the original finite declaration with an exact, narrow inverse.
a=decl(old,'finite (formulas')
b=decl(new,'finite_projection_heap (formulas')
recovered=b.replace('theorem finite_projection_heap (formulas','theorem finite (formulas',1)
recovered=recovered.replace('(memos : Memos) (valid : Valid before.native.machine.heap memos)\n    (heap : Heap before.native.machine.heap) :',
    '(memos : Memos) (valid : Valid before.native.machine.heap memos) :',1)
recovered=recovered.replace('        (Reads formulas solver actual memos final ∧\n          SourceCurrentAllocatedParentEdge.Receipt formulas solver next symbol original loaded inherited values before result after fourth savedFourth memo saved final) ∧\n        Heap after.native.machine.heap',
    '        Reads formulas solver actual memos final ∧\n        Receipt formulas solver next symbol original loaded inherited values before result after fourth savedFourth memo saved final',1)
(contracts/'finite-original-declaration.lean').write_text(a+'\n')
(contracts/'finite-draft-declaration.lean').write_text(b+'\n')
(contracts/'finite-recovered-declaration.lean').write_text(recovered+'\n')
comparison['checks'].append({'theorem':'finite_projection_heap','original_finite_exactly_recovered':a==recovered,
 'original':identity(a.encode()),'recovered':identity(recovered.encode()),
 'inverse':['Restore original theorem name.','Delete only the new original heap premise.',
  'Delete the final output heap conjunct and its explicit grouping; restore existing Receipt qualification.'],
 'grouping':'Actual draft has (Reads AND Receipt) AND Heap under the same existential actual. No resource/semantic field is removed.'})
(contracts/'comparison-v3.json').write_text(json.dumps(comparison,indent=2)+'\n')

# Validate exact self-contained snapshots and literal source slices. No Lean invocation.
checks=[]
for source in index['sources']:
    whole=own/source['whole']['path']
    data=whole.read_bytes()
    assert identity(data)=={k:source['whole'][k] for k in ('bytes','sha256')}
    assert Path(source['source']).read_bytes()==data
    lines=data.splitlines(keepends=True)
    for cut in source['cuts']:
        selected=(own/cut['path']).read_bytes()
        assert selected==b''.join(lines[cut['first_line']-1:cut['last_line']])
        assert identity(selected)=={k:cut[k] for k in ('bytes','sha256')}
    checks.append({'source':source['source'],'whole_and_cuts_valid':True})
(own/'source-validation-local.json').write_text(json.dumps({'status':'PASS; byte/slice validation only',
 'sources':len(index['sources']),'cuts':sum(len(s['cuts']) for s in index['sources']),
 'checks':checks},indent=2)+'\n')
print(json.dumps({'sources':len(index['sources']),'cuts':sum(len(s['cuts']) for s in index['sources']),
 'contract_checks':comparison['checks']},indent=2))
