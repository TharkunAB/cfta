Parent projection heap transport: OPEN source review

Recorded at 2026-10-28 08:05:57 CET. The owner did not run Lean, a build,
native evaluation, Git, a network request, or a repository edit. All six
v3 modules are UNTESTED. Root owns compilation and installation.

The actual Parent route supports the requested transport. The final draft
does not infer the property from generic Keeps, normalized annotations,
or arbitrary raw conjunction. It derives the property through the actual
checked target and seeded query receipts. It then follows the same local
reduction reads, class edit schedule, and checked edge constructor.

The six immutable v3 modules are in drafts/v3. Their dependency order is
Primitives, Merge, Targets, Edits and Scan, then Heap. The manifest
drafts-v3-status.json records their exact bytes and hashes. The original
v1 and v2 sources remain present. These earlier versions were source
drafts, not compiler attempts.

The public endpoint interfaces are:

- SourcePruningEnumerationLocalReductionProjectionHeap.reduction_heap
  uses the supplied actual local reads and their original admission.
- SourcePruningEnumerationLocalReductionProjectionHeap.literal_heap
  uses the literal completed LocalWorker.reduce equation and the original
  PartialInvariant.Context. Its output refers to that same checked state.
- SourcePruningEnumerationParentProjectionHeap.parent_heap uses the
  original actual Parent reads, Ready, inventory admission, conditional
  live load/available/range facts, fourth-table correctness, stored merge
  table, semantic cache coverage, and full global Memos validity.
- verified_projection_heap retains the complete old actual verification
  result and appends Heap at the same supplied endpoint.
- finite_projection_heap calls the old actual finite producer once. It
  returns the same result, checked state, fourth and merge tables,
  inventory, full final Memos, actual Edge, Reads, and complete Receipt.
  Its only additional output is Heap at that same returned checked state.

Heap in the new modules means SourceEqualityAnnotationHeap.Heap of
Constraint.project != none. It is a local notation, not a new predicate.
The original numeric arity theorem headers are used only as operational
proof templates. No numeric arity invariant is assumed by this draft.

The actual mutation cases have the following proofs.

1. Open exposure uses the existing arbitrary-annotation bounded exposure
   theorem. Path projection reads those actual endpoints and allocates
   ordinary nodes without adding edge guards.
2. Memo merge follows its actual Run/Call induction. Small rows retain
   their original resident guard. Large rows emit the actual Top guard.
   The local SafeWork checks are proved from those exact instructions.
   Recursive calls use the induction hypothesis, not an input callback law.
3. A TargetQuery receipt contains a completed rich native Trace. The
   checked NativeQueryProjectionHeap.node_query_heap theorem proves its
   exact returned heap property. Shared hit/force/leaf paths thread the
   actual checked states and full memo endpoints.
4. Seeded query completion uses the old range/support admission. The
   native rich trace proves the property at the chosen completion. Existing
   uniqueness identifies that endpoint with the supplied actual Seeded
   receipt. It does not identify unrelated low-fuel failures.
5. Class edits reuse the original stored edge guard after actual child
   edits. The right fold passes the exact tail state, inventory and full
   Memos to the next class. No new closedness gate is added.
6. The actual scan uses generic primary/secondary annotation effects and
   the checked seeded query. Conjunction worklists use their actual closed
   rows, derived by the original operational guard. Required reconstruction
   uses SourceCurrentRequiredHeapEffects, which supports original open
   inputs. The precheck's unchanged/empty branches change no native heap.
7. Rejected Parent construction uses the actual checked Top sentinel.
   Live Parent construction uses the actual local reduction endpoint and
   Receipt.preserves_projection_heap. The necessary loaded field Ready
   and valid operations come from the original receipt and its real effects.

No public final API assumes a child output Heap, final Heap, accepted
assignment, successful future query, or a generic continuation property.
The internal induction hypotheses concern actual smaller read receipts.
The final verified and finite wrappers retain all old Receipt fields.
This includes final Ready/At, physical Effects, resident edge, merge Stored,
CacheCovers, merge/fourth extension, full final global validity, constructor
provenance, and the original conditional native language law.

contracts/comparison-v3.json records source-text checks. The parent_heap,
reduction_heap and literal_heap headers are literal-equal to their original
numeric headers, with the explicitly documented different Heap notation.
The original finite declaration is recovered byte exactly by the recorded
inverse. The new output groups (Reads AND Receipt) before appending Heap.
These are lexical checks. They do not claim a compiled type or printed
public association check. Root's compiler and public readback remain pending.

The scope is completed source-refined allocated worker execution. These
lemmas do not establish projectability after an arbitrary failed/pending
native prefix. They do not yet attach the property to every PreparedRecursive
history or prove selector/coverage, model preservation, physical Haskell
correspondence, or a Haskell defect. Original construction provenance is
still supplied by the earlier checked source/emission theorems. The present
draft transports that genuine original whole heap through this Parent route.

source-index.json contains 25 whole source snapshots and 37 literal cuts.
source-validation-local.json verifies current whole bytes and exact line
slices. It is a file-integrity check, not a theorem check. Some complete
large dependencies are retained for provenance while review used their
listed contract cuts. The actual draft bodies and their operational numeric
templates were inspected. Earlier truncated tool output is not counted as
an independent whole-file review.

One inherited comment in the Edits source says reconstruction uses an
unchanged child count. The new proof only needs the unchanged guard.
This is a documentation correction to make after Root's compiler feedback;
it does not change a declaration or proof.

The bundle remains OPEN. No seal or publication success is claimed.
