from pathlib import Path
import hashlib, json
own=Path('/tmp/mcfta-prepared-semantic-history-20261028/parent-projection')
out=own/'drafts/v2'
out.mkdir(exist_ok=True)
for path in sorted((own/'drafts/v1').glob('*.lean')):
    text=path.read_text()
    if path.name=='SourcePruningEnumerationParentProjectionMerge.lean':
        text=text.replace('import MicroCFTA.SourceCurrentAllocatedMergeActual',
            'import MicroCFTA.SourceCurrentAllocatedMergeGraph')
        text=text.replace('SourcePruningEnumerationNativeArityPrimitives.makeNode_fits rows.flatten',
            'SourceEqualityAnnotationHeap.makeNode _ rows.flatten')
        text=text.replace('intro children before middle memo saved actual\n',
            'intro children _ _ _ _ _\n')
    (out/path.name).write_text(text)
records=[]
for p in sorted(out.glob('*.lean')):
    data=p.read_bytes()
    records.append({'path':str(p.relative_to(own)),'bytes':len(data),'lines':len(data.splitlines()),
       'sha256':hashlib.sha256(data).hexdigest()})
(own/'drafts-v2-status.json').write_text(json.dumps({'status':'UNTESTED; source review only; no owner compiler run',
    'changes_from_v1':['Correct nonexistent merge import to actual allocated merge graph.',
       'Replace remaining numeric makeNode check with existing arbitrary annotation SafeWork law.',
       'Keep all statements unchanged; mark unused local readback names anonymous.'],
    'modules':records},indent=2)+'\n')
