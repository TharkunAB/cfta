import MicroCFTA.SourcePruningEnumerationNativeNodeProjectionHeap
import MicroCFTA.SourcePruningEnumerationNativeBodyTrace

/-!
# Projectability through actual complete checked native queries

The rich body trace exposes the actual checked ready or sentinel branch.
Actual trace-length induction discharges both recursive request families.
Every child-created record belongs to the same returned physical heap.
No unconditional property of raw conjunction or future endpoint is supplied.
-/
namespace MicroCFTA.SourcePruningEnumerationNativeQueryProjectionHeap
open InternedConstructorTemplates SourceRecursiveIntersectionKernel
open SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace)
open SourceCurrentAllocatedNativePhysicalCompletion (Good)
open SourceCurrentAllocatedNativeSemanticTraceReadback
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "projectable" =>
  (fun constraint : Guard => SourcePruningEnumerationConstraint.project constraint ≠ none)
local notation "Heap" => SourceEqualityAnnotationHeap.Heap projectable
local notation "Checked" => SourceEqualityNativeDemand.State
variable {width : Nat}

private theorem lift_heap (operations : SourceEqualityConstraintMemoAllocation.State)
    (outcome : SourceRecursiveIntersectionNative.Outcome width Symbol Guard A) :
    (lift operations outcome).state.native.machine.heap = outcome.state.machine.heap := by
  cases outcome <;> rfl

variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
