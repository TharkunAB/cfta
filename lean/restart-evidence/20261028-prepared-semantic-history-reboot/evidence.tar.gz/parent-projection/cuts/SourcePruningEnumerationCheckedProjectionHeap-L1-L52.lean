import MicroCFTA.SourcePruningEnumerationCheckedProjection

/-!
# Projection heaps through the actual checked edge constructor

The accepted branch emits its checked original guard.
The rejected branch emits the Top sentinel guard.
Equality allocation changes no native edge record before this constructor.
-/
namespace MicroCFTA.SourcePruningEnumerationCheckedProjectionHeap
open InternedConstructorTemplates
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "projectable" =>
  (fun constraint : Constraint => SourcePruningEnumerationConstraint.project constraint ≠ none)
local notation "top" => SourceEqualityConstraintConstructors.top (Formula := FullSyntax.Formula)
variable [DecidableEq (EdgeKey Symbol Constraint)]

/-- Both actual checked constructor branches preserve the whole physical heap property. -/
theorem work_heap (symbol : Symbol) (constraint : Constraint)
    (children : List (Value Symbol Constraint)) (before : State Symbol Constraint)
    (heap : SourceEqualityAnnotationHeap.Heap projectable before) :
    SourceEqualityAnnotationHeap.Heap projectable
      (run (SourceEqualityMkEdgeAllocation.work symbol constraint children
        (SourceEqualityMkEdgeAllocation.accepted constraint children.length)) before).2 := by
  cases selected : SourceEqualityMkEdgeAllocation.accepted constraint children.length with
  | false =>
      have sentinel : projectable top := by
        change (some ([], none) : Option (List EqualityTrie.Trie × Option Constraint)) ≠ none
        intro impossible
        cases impossible
      simpa only [SourceEqualityMkEdgeAllocation.work, selected, Bool.false_eq_true, ↓reduceIte] using
        SourceEqualityAnnotationHeap.run projectable (makeEdge symbol top [.empty])
          (SourceEqualityAnnotationHeap.makeEdge projectable symbol top [.empty] sentinel) before heap
  | true =>
      have original := SourcePruningEnumerationCheckedProjection.accepted_projectable
        constraint children.length selected
      simpa only [SourceEqualityMkEdgeAllocation.work, selected, ↓reduceIte] using
        SourceEqualityAnnotationHeap.run projectable (makeEdge symbol constraint children)
          (SourceEqualityAnnotationHeap.makeEdge projectable symbol constraint children original) before heap

/-- Actual equality checks determine the selected work without a supplied successful result. -/
theorem build_heap (symbol : Symbol) (stored : SourceEqualityConstraintAllocation.Value)
    (guard : SourceGuards.Guard FullSyntax.Formula)
    (children : List (Value Symbol Constraint))
    (operations : SourceEqualityConstraintMemoAllocation.State) (before : State Symbol Constraint)
    (valid : SourceEqualityConstraintMemoAllocation.Valid operations)
    (ready : SourceEqualityConstraintAllocation.Ready operations.constraints stored)
    (heap : SourceEqualityAnnotationHeap.Heap projectable before) :
    SourceEqualityAnnotationHeap.Heap projectable
      (SourceEqualityMkEdgeAllocation.build symbol stored guard children operations before).2.2 := by
  have actual := SourceEqualityMkEdgeAllocation.build_receipt symbol stored guard children
