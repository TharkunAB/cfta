theorem Projections.verified [DecidableEq (EdgeKey Symbol Guard)]
    (annotation : Guard → Prop) {jobs : List (Job Symbol Guard)}
    {values : List (Value Symbol Guard)} {before after : State Symbol Guard}
    (actual : Projections jobs before values after) (semantic : SemanticReady before)
    (costs : CostHeap before) (fields : AnnotationHeap annotation before) (inputs : Inputs before jobs) :
    Effects annotation before after ∧ Values after values ∧ ClosedValues values := by
  induction actual with
  | nil => exact ⟨⟨pure_keeps _ semantic.ready, semantic, costs, fields⟩, by simp [Values], by simp [ClosedValues]⟩
  | @cons children path before value middle remaining values after first rest ih =>
      have ownInputs := inputs _ List.mem_cons_self
      have own := SourceEqualityProjectionCosts.forest_effects first semantic costs ownInputs.1
      have verified := SourceEqualityProjectionComplete.forest_complete (path.map Int.ofNat) children before
        semantic ownInputs.1 ownInputs.2
      obtain ⟨_, _, completed, _, _, _, resultClosed⟩ := verified
      obtain ⟨rfl, rfl⟩ := SourceEqualityProjectionAPI.forest_unique completed first
      have annotations := SourceEqualityAnnotationProjection.forest annotation first semantic ownInputs.1 ownInputs.2 fields
      have later := ih own.2.1 own.2.2.1 annotations
        (Inputs.keeps (fun job member => inputs job (List.mem_cons_of_mem _ member)) own.1)
      refine ⟨⟨own.1.trans later.1.keeps, later.1.semantic, later.1.costs, later.1.annotations⟩, ?_, ?_⟩
      · intro result member
        rcases List.mem_cons.mp member with rfl | member
        · exact later.1.keeps.available _ own.2.2.2
        · exact later.2.1 result member
      · intro result member
        rcases List.mem_cons.mp member with rfl | member
        · exact resultClosed
        · exact later.2.2 result member
