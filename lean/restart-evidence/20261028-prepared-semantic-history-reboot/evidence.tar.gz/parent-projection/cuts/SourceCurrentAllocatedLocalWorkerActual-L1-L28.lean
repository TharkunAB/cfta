import MicroCFTA.SourceCurrentAllocatedLocalWorkerCompletion
import MicroCFTA.SourceCurrentAllocatedLocalWorkerStability
import MicroCFTA.SourceCurrentAllocatedLocalReductionActual
import MicroCFTA.SourceCurrentAllocatedPartialInvariant
import MicroCFTA.SourceCurrentAllocatedProbeActual

/-!
# Full caller receipts for literal local equality reduction

The actual stored field and initial caller construct a strict local graph.
Stable execution and unconditional success uniqueness identify its complete
return with any supplied literal success. The same strict reads derive the
final probe heap. The receipt and caller postcondition use the same computed
inventory. Host demand and memo publication remain separate boundaries.
-/
namespace MicroCFTA.SourceCurrentAllocatedLocalWorkerActual
open Language EqualityNormalize InternedConstructorTemplates InternedProbeProvenance
open InternedNestedProvenance (Values)
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Context Post)
open SourceCurrentAllocatedLocalReduction (Reduction Receipt Ranges)
open SourceCurrentAllocatedLocalReductionActual (Reads)
open SourceCurrentAllocatedLocalWorker (reduce)
open SourceCurrentAllocatedLocalWorkerCompletion (StableRun)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Checked" => SourceEqualityNativeDemand.State
