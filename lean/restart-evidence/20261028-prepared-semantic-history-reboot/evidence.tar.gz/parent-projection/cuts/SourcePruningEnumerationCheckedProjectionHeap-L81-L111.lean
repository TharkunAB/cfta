    constraint.guard children before.operations before.native.machine.heap valid ready heap

/-- A retained actual checked receipt identifies the same returned physical heap. -/
theorem Receipt.preserves_projection_heap
    {formulas : SourceGuards.Formulas FullSyntax.Formula}
    {solver : SourceGuards.Entailment FullSyntax.Formula}
    {inventory : SourceCurrentAllocatedNativeInventoryState.Inventory}
    {symbol : Symbol} {constraint : Allocated} {children : List (Value Symbol Constraint)}
    {before after : SourceEqualityNativeDemand.State width} {result : EdgeValue Symbol Constraint}
    (receipt : Receipt formulas solver inventory symbol constraint children before result after)
    (valid : SourceEqualityConstraintMemoAllocation.Valid before.operations)
    (ready : SourceEqualityConstraintAllocation.Ready before.operations.constraints constraint.stored)
    (heap : SourceEqualityAnnotationHeap.Heap projectable before.native.machine.heap) :
    SourceEqualityAnnotationHeap.Heap projectable after.native.machine.heap := by
  have same : (build symbol constraint children before).2 = after := congrArg Prod.snd receipt.actual
  rw [← same]
  exact build_projectable_heap symbol constraint children before valid ready heap

/-- The concrete contradiction sentinel preserves the whole original projection heap. -/
theorem reject_projectable_heap (symbol : Symbol) (before : SourceEqualityNativeDemand.State width)
    (heap : SourceEqualityAnnotationHeap.Heap projectable before.native.machine.heap) :
    SourceEqualityAnnotationHeap.Heap projectable (reject symbol before).2.native.machine.heap := by
  have sentinel : projectable top := by
    change (some ([], none) : Option (List EqualityTrie.Trie × Option Constraint)) ≠ none
    intro impossible
    cases impossible
  exact SourceEqualityAnnotationHeap.run projectable (makeEdge symbol top [.empty])
    (SourceEqualityAnnotationHeap.makeEdge projectable symbol top [.empty] sentinel)
    before.native.machine.heap heap

end MicroCFTA.SourceCurrentAllocatedMkEdge
