theorem finite (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (budget : Nat) (symbol : Symbol) (original : Guard) (loaded : Allocated) (inherited : EqValue)
    (values : List (Value Symbol Guard)) (before : Checked width) (fourth : Fourth) (memo : Memo)
    (ready : Ready before) (admitted : At formulas solver inventory before)
    (cached : SourceEqualityGuardReadback.Cached original.equalities)
    (found : SourceEqualityConstraintFieldLookup.load original before.operations.constraints = .ok (some loaded))
    (inheritedReady : SourceEqualityConstraintAllocation.Ready before.operations.constraints inherited)
    (available : Values before.native.machine.heap values)
    (correct : SourceCurrentEmptinessMemo.Correct formulas solver before.native.machine.heap fourth)
    (stored : SourceCurrentMemoMergeEffects.Stored before.native.machine.heap memo)
    (covered : ∀ ambient, SourceCurrentMemoMergeLanguage.CacheCovers (SourceEqualityPCSGuard.holds formulas solver) ambient memo)
    (ranges : SourceCurrentAllocatedParentEdge.Ranges budget original loaded inherited values before fourth memo)
    (memos : Memos) (valid : Valid before.native.machine.heap memos) :
    ∃ result after savedFourth saved next final,
      ∃ actual : Edge budget symbol original loaded inherited values before fourth memo result after savedFourth saved,
        Reads formulas solver actual memos final ∧
        Receipt formulas solver next symbol original loaded inherited values before result after fourth savedFourth memo saved final := by
  have liveInputs : contradictory original = false →
      SourceEqualityGuardReadback.Cached original.equalities ∧
      SourceEqualityConstraintFieldLookup.load original before.operations.constraints = .ok (some loaded) ∧
      SourceEqualityConstraintAllocation.Ready before.operations.constraints inherited ∧
      Values before.native.machine.heap values ∧
      SourceCurrentAllocatedLocalReductionActual.Ranges budget loaded inherited values before fourth :=
    fun test => ⟨cached, found, inheritedReady, available,
      SourceCurrentAllocatedLocalReductionActual.ranges_of_finite (ranges test)⟩
  cases test : contradictory original with
  | true =>
      let actual : Edge budget symbol original loaded inherited values before fourth memo
          (SourceCurrentAllocatedMkEdge.reject symbol before).1 (SourceCurrentAllocatedMkEdge.reject symbol before).2
          fourth memo := .rejected test
      have read : Reads formulas solver actual memos memos := .rejected (test := test)
      obtain ⟨next, receipt⟩ := verified formulas solver inventory read ready admitted liveInputs correct stored covered valid
      exact ⟨_, _, _, _, next, memos, actual, read, receipt⟩
  | false =>
      have loadedReady := SourceEqualityConstraintFieldLookup.load_ready original before.operations.constraints
        ready.good.operations.constraints cached loaded found
      obtain ⟨children, middle, savedFourth, saved, next, final, reduction, localRead, receipt⟩ :=
        SourceCurrentAllocatedLocalReductionActual.finite formulas solver inventory budget original loaded inherited values before
          fourth memo ready admitted cached found inheritedReady available correct stored covered (ranges test) memos valid
      have storedReady := loadedReady.1.grows receipt.effects.grows.constraint_growth
      have field : SourceCurrentConjunctionEquality.FieldAvailable middle.operations (raw loaded) := by
        rw [loadedReady.2]
        exact (show SourceCurrentConjunctionEquality.FieldAvailable before.operations original from ⟨cached, loaded, found⟩).grows
          receipt.effects.grows
      obtain ⟨result, after, constructor⟩ := SourceCurrentAllocatedMkEdge.finite formulas solver next symbol loaded children middle
        receipt.ready receipt.admitted storedReady field receipt.available
      let actual := Edge.live (original := original) (symbol := symbol) test reduction constructor.actual
      have read : Reads formulas solver actual memos final :=
        .live (test := test) (built := constructor.actual) localRead
      obtain ⟨finalInventory, receipt⟩ := verified formulas solver inventory read ready admitted liveInputs correct stored covered valid
