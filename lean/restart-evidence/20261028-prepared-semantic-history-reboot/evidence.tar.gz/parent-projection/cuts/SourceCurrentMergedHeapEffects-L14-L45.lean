namespace MicroCFTA.SourceCurrentMergedHeapEffects
open InternedConstructorTemplates InternedProbeProvenance
open InternedNestedProvenance (Values Edges)
open MergedColdReaderClosedInputs (ClosedValues ClosedEdges)
open SourceEqualityRequiredCache SourceEqualityRequiredSemanticCache
open MergedSourceComparison (Result identity children anyCover)
open MergedFreshOrdinaryComparison (check allRows)
open SourceMergedComparisonEffects (bind_done)
open SourceEqualityAnnotationHeap (Heap)
local notation "CostHeap" => InternedFreshOrdinaryCostHeap.Heap

/-- A successful stage retains actual cache effects and preserves physical edge annotations. -/
structure Effect (annotation : Guard → Prop) (before after : State Symbol Guard) : Prop where
  keeps : Keeps before after
  semantic : SemanticReady after
  costs : CostHeap after
  annotations : Heap annotation before → Heap annotation after

/-- Annotation effects retain the previously proved source cache effects. -/
theorem Effect.original {annotation : Guard → Prop} {before after : State Symbol Guard} (effect : Effect annotation before after) :
    SourceMergedComparisonEffects.Effect before after := ⟨effect.keeps, effect.semantic⟩

/-- A direct Boolean return has no cache effects. -/
theorem pure_effect (annotation : Guard → Prop) (before : State Symbol Guard) (semantic : SemanticReady before) (costs : CostHeap before) (answer result : Bool)
    (after : State Symbol Guard) (done : Result.done answer before = Result.done result after) : Effect annotation before after := by
  have parts := Result.done.inj done
  cases parts.2
  exact ⟨pure_keeps _ semantic.ready, semantic, costs, fun heap => heap⟩

/-- Ordered successful effects compose semantic caches, histories, and annotation preservation. -/
theorem Effect.trans {annotation : Guard → Prop} {before middle after : State Symbol Guard} (first : Effect annotation before middle) (second : Effect annotation middle after) : Effect annotation before after :=
  ⟨first.keeps.trans second.keeps, second.semantic, second.costs, fun heap => second.annotations (first.annotations heap)⟩
