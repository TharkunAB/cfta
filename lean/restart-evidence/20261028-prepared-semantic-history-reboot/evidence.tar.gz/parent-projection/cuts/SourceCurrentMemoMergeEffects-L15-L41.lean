open MergedColdReaderClosedInputs (ClosedValues ClosedEdges)
open SourceEqualityRequiredCache SourceEqualityRequiredSemanticCache
open SourceCurrentMemoMergeGraph
local notation "CostHeap" => InternedFreshOrdinaryCostHeap.Heap

/-- Completed entries retain physical originals and conditionally closed results. -/
def Stored (heap : State Symbol Guard) (memo : Memo Symbol Guard) : Prop :=
  ∀ key entry, memo key = some entry → entry.original.referenceOf = key ∧
    Available heap entry.original ∧ Available heap entry.result ∧
      (entry.original.free = [] → entry.result.free = [])

/-- An empty completed table needs no physical entry premise. -/
theorem stored_empty (heap : State Symbol Guard) : Stored heap empty := by
  intro key entry found
  cases found

/-- Actual heap growth retains every original and completed result. -/
theorem Stored.grows {before after : State Symbol Guard} {memo : Memo Symbol Guard}
    (stored : Stored before memo) (keeps : Keeps before after) : Stored after memo := by
  intro key entry found
  obtain ⟨identity, original, result, closed⟩ := stored key entry found
  exact ⟨identity, keeps.available _ original, keeps.available _ result, closed⟩

/-- Completion preserves an earlier winner and checks a newly stored pair. -/
theorem stored_remember {heap : State Symbol Guard} {memo : Memo Symbol Guard}
    (stored : Stored heap memo) (input output : Value Symbol Guard)
    (original : Available heap input) (result : Available heap output)
