theorem Exposures.verified [DecidableEq (EdgeKey Symbol Guard)]
    (annotation : Guard → Prop) {values : List (Value Symbol Guard)}
    {before after : State Symbol Guard} {rows : List (List (EdgeValue Symbol Guard))}
    (actual : Exposures values before rows after) (semantic : SemanticReady before)
    (costs : CostHeap before) (fields : AnnotationHeap annotation before)
    (available : Values before values) (closed : ClosedValues values) :
    Effects annotation before after ∧ ∀ edges ∈ rows, Edges after edges ∧ ClosedEdges edges := by
  induction actual with
  | nil =>
      exact ⟨⟨pure_keeps _ semantic.ready, semantic, costs, fields⟩, by simp⟩
  | @cons value before edges middle values more after first rest ih =>
      have own := read_effects annotation first semantic costs fields (available _ List.mem_cons_self)
      have rows := first.verified semantic (available _ List.mem_cons_self) (closed _ List.mem_cons_self)
      have later := ih own.semantic own.costs own.annotations
        (fun child member => own.keeps.available child (available child (List.mem_cons_of_mem _ member)))
        (fun child member => closed child (List.mem_cons_of_mem _ member))
      refine ⟨⟨own.keeps.trans later.1.keeps, later.1.semantic, later.1.costs, later.1.annotations⟩, ?_⟩
      intro chosen member
      rcases List.mem_cons.mp member with rfl | member
      · exact ⟨fun edge member => InternedEdgeResidency.edge_grows middle after later.1.keeps.growth edge
          (rows.2.2.1 edge member), rows.2.2.2⟩
      · exact later.2 chosen member
