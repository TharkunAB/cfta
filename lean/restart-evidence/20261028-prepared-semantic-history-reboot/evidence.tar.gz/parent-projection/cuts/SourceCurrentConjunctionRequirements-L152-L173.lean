theorem ClassRequirements.verified [DecidableEq (EdgeKey Symbol Guard)]
    (annotation : Guard → Prop) {forests : List (List (Value Symbol Guard))} {classes : Constraints}
    {before after : State Symbol Guard} {requirements : List (List (Value Symbol Guard))}
    (actual : ClassRequirements forests classes before requirements after)
    (semantic : SemanticReady before) (costs : CostHeap before) (fields : AnnotationHeap annotation before)
    (inputs : RowsReady before forests) : Effects annotation before after ∧ RowsReady after requirements := by
  induction actual with
  | nil => exact ⟨⟨pure_keeps _ semantic.ready, semantic, costs, fields⟩, by simp [RowsReady]⟩
  | @cons paths before projected middle classes requirements after first rest ih =>
      have own := first.verified annotation semantic costs fields
        (SourceCurrentConjunctionCompletionReads.jobs_inputs before forests paths
          (fun forest member => (inputs forest member).1) (fun forest member => (inputs forest member).2))
      have canonical := canonical_values projected middle own.1.semantic own.2.1 own.2.2
      have later := ih own.1.semantic own.1.costs own.1.annotations
        (fun forest member => ⟨fun child included => own.1.keeps.available child ((inputs forest member).1 child included),
          (inputs forest member).2⟩)
      refine ⟨⟨own.1.keeps.trans later.1.keeps, later.1.semantic, later.1.costs, later.1.annotations⟩, ?_⟩
      intro row member
      rcases List.mem_cons.mp member with rfl | member
      · exact ⟨fun child included => later.1.keeps.available child (canonical.1 child included), canonical.2⟩
      · exact later.2 row member

