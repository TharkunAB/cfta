          (fun requested used bounded initial output answer checked origin called =>
            (ih used (by omega)).1 requested initial output answer checked origin called)
          (fun requested used bounded initial output answer checked origin called =>
            (ih used (by omega)).2 requested initial output answer checked origin called)
          original start final result count (Nat.le_refl _) good current actual
      · intro request before after value valid heap trace
        apply SourcePruningEnumerationNativeQueryProjectionHeap.edge_request_heap request before after value fuel valid heap trace
        intro count original start final result smaller good ready current actual
        apply body_heap count
          (fun requested used bounded initial output answer checked origin called =>
            (ih used (by omega)).1 requested initial output answer checked origin called)
          original count start final result (Nat.le_refl _) good ready current actual

/-- Every actual complete native node query retains projectability of its entire returned edge-record heap. -/
theorem node_query_heap (request : NodeRequest Symbol Guard)
    (before after : Checked width) (value : Value Symbol Guard) (fuel : Nat)
    (valid : Good before) (heap : Heap before.native.machine.heap)
    (trace : Trace fuel (.code (requestNode request.domain request.left request.right)) before (.code (.pure value)) after) :
    Heap after.native.machine.heap :=
  (query_heaps fuel).1 request before after value valid heap trace

/-- Every actual complete native edge query retains projectability of all old and newly created edge records. -/
theorem edge_query_heap (request : EdgeRequest Symbol Guard)
    (before after : Checked width) (value : EdgeValue Symbol Guard) (fuel : Nat)
    (valid : Good before) (heap : Heap before.native.machine.heap)
    (trace : Trace fuel (.code (requestEdge request.domain request.left request.right)) before (.code (.pure value)) after) :
    Heap after.native.machine.heap :=
  (query_heaps fuel).2 request before after value valid heap trace

/-- Every returned edge memo cell after a native node query projects from its actual resident record. -/
theorem node_query_edge_memo_projectable (request : NodeRequest Symbol Guard)
    (before after : Checked width) (value : Value Symbol Guard) (fuel : Nat)
    (valid : Good before) (heap : Heap before.native.machine.heap)
    (trace : Trace fuel (.code (requestNode request.domain request.left request.right)) before (.code (.pure value)) after)
    (handle : Nat) (original : EdgeRequest Symbol Guard) (edge : EdgeValue Symbol Guard)
    (stored : after.native.edges.cells handle = some ⟨original, .returned edge⟩) :
    SourcePruningEnumerationConstraint.project edge.entry.key.constraint ≠ none := by
  have afterHeap := node_query_heap request before after value fuel valid heap trace
  have reached := SourceCurrentAllocatedNativeSemanticTraceReadback.effects trace valid (fun _ => trivial)
  have resident := (reached.1.native.edges.checked handle _ stored).2
  exact afterHeap edge.entry.key edge resident

end MicroCFTA.SourcePruningEnumerationNativeQueryProjectionHeap
