        have facts := semantic.ready.semantic.1.normal.facts
        have resident := InternedEdgeResidency.resident_edges before facts.linked _ available.resident
        have rowsClosed : ClosedEdges edges := fun edge member child inner =>
          MergedOrdinaryHeight.closed_child before facts.coherent entry edges depth free available.resident closed edge member child inner
        have grouping := MergedSourceGrouping.groups_correct edges
        have original (group : List (EdgeValue Symbol Guard)) (member : group ∈ MergedSourceGrouping.groups edges)
            (edge : EdgeValue Symbol Guard) (inner : edge ∈ group) : edge ∈ edges :=
          grouping.partition.mem_iff.mp (List.mem_flatten.mpr ⟨group, member, inner⟩)
        have checked := root_certified clear top _ before semantic costs
          (fun group member edge inner => resident edge (original group member edge inner))
          (fun group member edge inner => rowsClosed edge (original group member edge inner))
        exact checked.mono (fun _ _ ready => ⟨ready.1, fun _ => ready.2⟩)
      · simp only [body, closed, ite_false, Certified]
        exact ⟨available, id⟩
  | empty | reference | mu | union => exact ⟨available, id⟩

/-- Actual instruction induction discharges every recursive request contract. -/
theorem run_effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    {clear : Guard → Bool} {top : Guard} {code : Code Symbol Guard Output}
    {before after : State Symbol Guard} {memo saved : Memo Symbol Guard} {output : Output}
    (actual : Run clear top code before memo output after saved) :
    ∀ (post : State Symbol Guard → Output → Prop), SemanticReady before → CostHeap before → Stored before memo →
      Certified Contract clear code before post → Effect before after ∧ Stored after saved ∧ post after output := by
  induction actual using Run.rec
      (motive_2 := fun input before memo output after saved _ => SemanticReady before → CostHeap before →
        Stored before memo → Available before input → Effect before after ∧ Stored after saved ∧ Contract input before output after) with
  | pure value state memo =>
      intro post semantic costs stored checked
      exact ⟨effect_refl _ semantic costs, stored, checked⟩
  | work job state memo =>
      intro post semantic costs stored checked
      exact ⟨checked.1, stored.grows checked.1.keeps, checked.2⟩
  | select fuel done =>
      intro post semantic costs stored checked
      have original := SourceCurrentMergedHeapEffects.select_effect (fun _ => True) _ fuel _ _ semantic costs checked.1 _ _ done
      have effect : Effect _ _ := ⟨original.keeps, original.semantic, original.costs⟩
      exact ⟨effect, stored.grows effect.keeps, checked.2.2 fuel _ _ done effect⟩
  | request actual ih =>
      intro post semantic costs stored checked
      obtain ⟨effect, retained, returned⟩ := ih semantic costs stored checked.1
      exact ⟨effect, retained, checked.2 _ _ effect returned⟩
  | bind first later ihFirst ihLater =>
      intro post semantic costs stored checked
      obtain ⟨intermediate, firstChecked, nextChecked⟩ := checked
      obtain ⟨firstEffect, firstStored, valid⟩ := ihFirst intermediate semantic costs stored firstChecked
      obtain ⟨laterEffect, laterStored, returned⟩ := ihLater post firstEffect.semantic firstEffect.costs firstStored
        (nextChecked _ _ firstEffect valid)
      exact ⟨firstEffect.trans laterEffect, laterStored, returned⟩
  | hit found =>
      rename_i semantic costs stored available
      obtain ⟨same, result, closed⟩ := hit_original semantic available stored found
      exact ⟨effect_refl _ semantic costs, stored, result, closed⟩
  | @miss memo input before candidate after current absent actual ih =>
      rename_i semantic costs stored available
      obtain ⟨effect, retained, result, closed⟩ := ih _ semantic costs stored (body_certified _ _ input before semantic costs available)
      have inputAvailable := effect.keeps.available input available
      have completed := stored_remember retained input candidate inputAvailable result closed
      obtain ⟨same, winnerAvailable, winnerClosed⟩ := hit_original effect.semantic inputAvailable completed (winner_found current input candidate)
      exact ⟨effect, completed, winnerAvailable, winnerClosed⟩

/-- Completed hits and memo-aware misses derive the actual returned heap and winner. -/
theorem call_effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    {clear : Guard → Bool} {top : Guard} {input output : Value Symbol Guard}
    {before after : State Symbol Guard} {memo saved : Memo Symbol Guard}
    (actual : Call clear top input before memo output after saved) (semantic : SemanticReady before)
    (costs : CostHeap before) (stored : Stored before memo) (available : Available before input) :
    Effect before after ∧ Stored after saved ∧ Available after output ∧ (input.free = [] → output.free = []) :=
  run_effects (.request actual) (fun after output => Contract input before output after) semantic costs stored
    ⟨available, fun _ _ _ returned => returned⟩
