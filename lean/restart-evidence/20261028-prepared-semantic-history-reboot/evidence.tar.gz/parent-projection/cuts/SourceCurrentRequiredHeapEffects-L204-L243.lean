/-- Every completed node graph retains semantic heaps, costs, annotations, and its actual returned value. -/
theorem node (property : Guard → Prop) [DecidableEq (EdgeKey Symbol Guard)]
    {needed : SourceEqualityNeeded.Needed} {value result : Value Symbol Guard} {before after : State Symbol Guard}
    (trace : RequireNode needed value before result after) (semantic : SemanticReady before)
    (costs : CostHeap before) (fields : Heap property before) (available : Available before value) :
    Keeps before after ∧ SemanticReady after ∧ CostHeap after ∧ Heap property after ∧ Available after result := by
  obtain ⟨⟨kept, ready, finalCosts, finalFields⟩, resident⟩ := effects property |>.1 _ _ _ _ _ trace semantic costs fields available
  exact ⟨kept, ready, finalCosts, finalFields, resident⟩

/-- Actual child graphs retain their exact returned positions and all physical heap invariants. -/
theorem children (property : Guard → Prop) [DecidableEq (EdgeKey Symbol Guard)]
    {entries : List (Int × SourceEqualityNeeded.Needed)} {index : Nat} {values results : List (Value Symbol Guard)}
    {before after : State Symbol Guard} (trace : RequireChildren entries index values before results after)
    (semantic : SemanticReady before) (costs : CostHeap before) (fields : Heap property before) (available : Values before values) :
    Keeps before after ∧ SemanticReady after ∧ CostHeap after ∧ Heap property after ∧ Values after results := by
  obtain ⟨⟨kept, ready, finalCosts, finalFields⟩, resident⟩ := effects property |>.2.1 _ _ _ _ _ _ trace semantic costs fields available
  exact ⟨kept, ready, finalCosts, finalFields, resident⟩

/-- Actual row graphs retain resident rebuilt edges and all physical heap invariants. -/
theorem rows (property : Guard → Prop) [DecidableEq (EdgeKey Symbol Guard)]
    {entries : List (Int × SourceEqualityNeeded.Needed)} {edges results : List (EdgeValue Symbol Guard)} {before after : State Symbol Guard}
    (trace : RequireRows entries edges before results after) (semantic : SemanticReady before)
    (costs : CostHeap before) (fields : Heap property before) (resident : Edges before edges) :
    Keeps before after ∧ SemanticReady after ∧ CostHeap after ∧ Heap property after ∧ Edges after results := by
  obtain ⟨⟨kept, ready, finalCosts, finalFields⟩, available⟩ := effects property |>.2.2 _ _ _ _ _ trace semantic costs fields resident
  exact ⟨kept, ready, finalCosts, finalFields, available⟩

/-- A completed literal requireAll worker retains costs, annotations, and exact semantic state. -/
theorem requireAll (property : Guard → Prop) [DecidableEq (EdgeKey Symbol Guard)]
    (fuel readFuel : Nat) (paths : List (List Int)) (values results : List (Value Symbol Guard)) (before after : State Symbol Guard)
    (done : SourceEqualityRequiredExecution.requireAll fuel readFuel paths values before = .done results after)
    (semantic : SemanticReady before) (costs : CostHeap before) (fields : Heap property before) (available : Values before values) :
    Keeps before after ∧ SemanticReady after ∧ CostHeap after ∧ Heap property after ∧ Values after results := by
  have trace := (SourceEqualityRequiredExecution.requireAll_execution_iff paths values before results after).mpr ⟨fuel, readFuel, done⟩
  cases compiled : SourceEqualityNeeded.build paths with
  | node entries =>
      simp only [compiled] at trace
      exact children property trace semantic costs fields available

end MicroCFTA.SourceCurrentRequiredHeapEffects
