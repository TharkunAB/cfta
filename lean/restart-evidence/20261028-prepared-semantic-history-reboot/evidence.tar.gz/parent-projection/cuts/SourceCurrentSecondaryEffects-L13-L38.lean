-/
namespace MicroCFTA.SourceCurrentSecondaryEffects
open InternedConstructorTemplates InternedProbeProvenance
open InternedNestedConstruction (Outcome)
open SourceCurrentSecondaryTrace EqualityNormalize
open SourceEqualityRequiredCache SourceEqualityRequiredSemanticCache
open SourceEqualityAnnotationHeap (Heap)

private def Effects (property : Guard → Prop) (before after : State Symbol Guard) : Prop :=
  SemanticReady after ∧ Keeps before after ∧ InternedFreshOrdinaryCostHeap.Heap after ∧ Heap property after

private def NodeEffects (property : Guard → Prop) (value : Value Symbol Guard)
    (before after : State Symbol Guard) : Prop :=
  SemanticReady before → InternedFreshOrdinaryCostHeap.Heap before → Available before value →
    Heap property before → Effects property before after

private def ChildEffects (property : Guard → Prop) (values : List (Value Symbol Guard))
    (before after : State Symbol Guard) : Prop :=
  SemanticReady before → InternedFreshOrdinaryCostHeap.Heap before → (∀ value ∈ values, Available before value) →
    Heap property before → Effects property before after

private def EdgesEffects (property : Guard → Prop) (edges : List (EdgeValue Symbol Guard))
    (before after : State Symbol Guard) : Prop :=
  SemanticReady before → InternedFreshOrdinaryCostHeap.Heap before →
    (∀ value ∈ edges.flatMap EdgeValue.children, Available before value) →
      Heap property before → Effects property before after
