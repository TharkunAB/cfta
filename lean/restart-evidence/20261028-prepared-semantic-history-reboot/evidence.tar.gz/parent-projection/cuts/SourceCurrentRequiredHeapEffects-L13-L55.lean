namespace MicroCFTA.SourceCurrentRequiredHeapEffects
open Cache InternedConstructorTemplates InternedProbeProvenance
open InternedNestedProvenance (Values Edges)
open SourceEqualityRequiredCache SourceEqualityRequiredSemanticCache SourceEqualityRequiredGraph
open SourceEqualityAnnotationHeap (Heap)
local notation "CostHeap" => InternedFreshOrdinaryCostHeap.Heap

private def Effects (property : Guard → Prop) (before after : State Symbol Guard) : Prop :=
  Keeps before after ∧ SemanticReady after ∧ CostHeap after ∧ Heap property after

/-- Actual ordinary reconstruction retains open semantic heaps, costs, and physical annotations. -/
theorem node_constructor (property : Guard → Prop) [DecidableEq (EdgeKey Symbol Guard)]
    (edges : List (EdgeValue Symbol Guard)) (state : State Symbol Guard)
    (semantic : SemanticReady state) (costs : CostHeap state) (fields : Heap property state)
    (resident : Edges state edges) :
    Keeps state (run (makeNode edges) state).2 ∧ SemanticReady (run (makeNode edges) state).2 ∧
      CostHeap (run (makeNode edges) state).2 ∧ Heap property (run (makeNode edges) state).2 ∧
      Available (run (makeNode edges) state).2 (run (makeNode edges) state).1 := by
  have checked := SourceEqualityOpenOrdinaryHead.node edges state semantic resident
  exact ⟨checked.1, checked.2.1,
    InternedFreshOrdinaryCostHeap.preserve state _ costs (InternedShallowHeap.makeNode_noNewMu edges state),
    SourceEqualityAnnotationHeap.run property _ (SourceEqualityAnnotationHeap.makeNode property edges) state fields,
    checked.2.2.1⟩

/-- Every completed head read derives its actual open result and all physical heap effects. -/
theorem head (property : Guard → Prop) [DecidableEq (EdgeKey Symbol Guard)]
    {value result : Value Symbol Guard} {before after : State Symbol Guard}
    (trace : SourceEqualityRequiredHead.Head value before result after)
    (semantic : SemanticReady before) (costs : CostHeap before) (fields : Heap property before)
    (available : Available before value) :
    Keeps before after ∧ SemanticReady after ∧ CostHeap after ∧ Heap property after ∧ Available after result := by
  cases trace with
  | read fuel edges middle exposed rebuilt =>
      have read := SourceEqualityExposureCosts.nodeEdges_verified fuel value before semantic costs available
      have middleSemantic : SemanticReady middle := by simpa only [exposed, MergedSourceExposure.Result.state] using read.semantic
      have middleCosts : CostHeap middle := by simpa only [exposed, MergedSourceExposure.Result.state] using read.costs
      have first : Keeps before middle := by simpa only [exposed, MergedSourceExposure.Result.state] using read.keeps
      have middleFields : Heap property middle := by
        simpa only [exposed, MergedSourceExposure.Result.state] using
          SourceCurrentOpenExposureFields.nodeEdges_heap property fuel value before semantic fields available
      have checked := node_constructor property edges middle middleSemantic middleCosts middleFields (read.rows _ _ exposed)
      have resultEffects : Keeps middle after ∧ SemanticReady after ∧ CostHeap after ∧
          Heap property after ∧ Available after result := by simpa only [rebuilt] using checked
