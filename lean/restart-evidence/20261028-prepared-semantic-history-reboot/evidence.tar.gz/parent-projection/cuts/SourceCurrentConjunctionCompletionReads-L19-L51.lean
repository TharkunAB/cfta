namespace MicroCFTA.SourceCurrentConjunctionCompletionReads
open Language InternedConstructorTemplates InternedProbeProvenance
open InternedNestedProvenance (Values Edges)
open MergedColdReaderClosedInputs (ClosedValues ClosedEdges)
open SourceEqualityRequiredCache SourceEqualityRequiredSemanticCache
open SourceEqualityProjectionRead SourceEqualityProjectionGraph
open InternedGuardedLanguage (meaning)
local notation "CostHeap" => InternedFreshOrdinaryCostHeap.Heap
local notation "AnnotationHeap" => SourceEqualityAnnotationHeap.Heap

/-- Completed reads retain all four current constructor-heap invariants. -/
structure Effects (annotation : Guard → Prop) (before after : State Symbol Guard) : Prop where
  keeps : Keeps before after
  semantic : SemanticReady after
  costs : CostHeap after
  annotations : AnnotationHeap annotation after

/-- A read at its exact returned heap retains stored costs and annotations. -/
theorem read_effects [DecidableEq (EdgeKey Symbol Guard)]
    (annotation : Guard → Prop) {value : Value Symbol Guard}
    {before after : State Symbol Guard} {edges : List (EdgeValue Symbol Guard)}
    (actual : Read value before edges after) (semantic : SemanticReady before)
    (costs : CostHeap before) (fields : AnnotationHeap annotation before)
    (available : Available before value) : Effects annotation before after := by
  have checked := SourceEqualityProjectionCosts.read_effects actual semantic costs available
  refine ⟨checked.1, checked.2.1, checked.2.2.1, ?_⟩
  cases actual with
  | done fuel completed =>
      simpa only [completed, MergedSourceExposure.Result.state] using
        SourceCurrentOpenExposureFields.nodeEdges_heap annotation fuel value before semantic fields available

/-- A finite selected operand sequence retains separate edge lists and their order. -/
inductive Exposures [DecidableEq (EdgeKey Symbol Guard)] :
