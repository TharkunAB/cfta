theorem Requirements.verified [DecidableEq (EdgeKey Symbol Guard)]
    (annotation : Guard → Prop) {tuple : List (EdgeValue Symbol Guard)} {classes : Constraints}
    {before after : State Symbol Guard} {requirements : List (List (Value Symbol Guard))}
    (actual : Requirements tuple classes before requirements after)
    (semantic : SemanticReady before) (costs : CostHeap before) (fields : AnnotationHeap annotation before)
    (resident : Edges before tuple) (closed : ClosedEdges tuple) :
    Effects annotation before after ∧ RowsReady after requirements := by
  cases actual with
  | run _ actual =>
      have checked := actual.verified annotation semantic costs fields (tuple_inputs tuple before semantic resident closed)
      refine ⟨checked.1, ?_⟩
      intro row member
      rcases List.mem_append.mp member with column | requirement
      · obtain ⟨original, originalIn, rfl⟩ := List.mem_map.mp column
        have original := columns_ready tuple before semantic resident closed original originalIn
        have canonical := canonical_values _ before semantic original.1 original.2
        exact ⟨fun child included => checked.1.keeps.available child (canonical.1 child included), canonical.2⟩
      · exact checked.2 row requirement
