variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] [DecidableEq (Value Symbol Guard)] {width : Nat}

/-- Raw rejection skips the local child graph; live construction uses its actual return. -/
inductive Edge (budget : Nat) (symbol : Symbol) (original : Guard) (loaded : Allocated)
    (inherited : EqValue) (values : List (Value Symbol Guard)) (before : Checked width)
    (fourth : Fourth) (memo : Memo) : EdgeValue Symbol Guard → Checked width → Fourth → Memo → Prop where
  | rejected (test : contradictory original = true) :
      Edge budget symbol original loaded inherited values before fourth memo
        (SourceCurrentAllocatedMkEdge.reject symbol before).1 (SourceCurrentAllocatedMkEdge.reject symbol before).2 fourth memo
  | live {children middle savedFourth saved result after}
      (test : contradictory original = false)
      (reduction : SourceCurrentAllocatedLocalReduction.Reduction budget loaded inherited values before fourth memo
        children middle savedFourth saved)
      (built : SourceCurrentAllocatedMkEdge.build symbol loaded children middle = (.ok result, after)) :
      Edge budget symbol original loaded inherited values before fourth memo result after savedFourth saved

/-- Only the reached live local graph demands global memo reads. -/
inductive Reads (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) :
    {budget : Nat} → {symbol : Symbol} → {original : Guard} → {loaded : Allocated} → {inherited : EqValue} →
    {values : List (Value Symbol Guard)} → {before after : Checked width} → {result : EdgeValue Symbol Guard} →
    {fourth savedFourth : Fourth} → {memo saved : Memo} →
    Edge budget symbol original loaded inherited values before fourth memo result after savedFourth saved → Memos → Memos → Prop where
  | rejected {budget symbol original loaded inherited values before fourth memo test memos} :
      Reads formulas solver (Edge.rejected (budget := budget) (symbol := symbol) (original := original)
        (loaded := loaded) (inherited := inherited) (values := values) (before := before)
        (fourth := fourth) (memo := memo) test) memos memos
  | live {budget symbol original loaded inherited values before fourth memo children middle savedFourth saved result after test}
      {reduction : SourceCurrentAllocatedLocalReduction.Reduction budget loaded inherited values before fourth memo
        children middle savedFourth saved}
      {built : SourceCurrentAllocatedMkEdge.build symbol loaded children middle = (.ok result, after)} {memos final}
      (reads : SourceCurrentAllocatedLocalReduction.Reads formulas solver reduction memos final) :
      Reads formulas solver (Edge.live (original := original) (symbol := symbol) test reduction built) memos final

/-- Local range plans apply only after the raw constructor contradiction test passes. -/
def Ranges (budget : Nat) (original : Guard) (loaded : Allocated) (inherited : EqValue)
    (values : List (Value Symbol Guard)) (before : Checked width) (fourth : Fourth) (memo : Memo) : Prop :=
  contradictory original = false → SourceCurrentAllocatedLocalReduction.Ranges budget loaded inherited values before fourth memo

/-- Interpret the original raw edge without replacing its stored field by its accessor. -/
def RawMeaning (holds : Guard → Term Symbol → Bool) (ambient : InternedGuardedLanguage.Env Symbol)
    (symbol : Symbol) (original : Guard) (values : List (Value Symbol Guard)) (term : Term Symbol) : Prop :=
  ∃ terms, term = .node symbol terms ∧ All₂ (meaning holds ambient) values terms ∧ holds original term = true

/-- The actual parent return retains physical and completed-cache invariants. -/
structure Receipt (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (symbol : Symbol) (original : Guard) (loaded : Allocated) (inherited : EqValue)
    (values : List (Value Symbol Guard)) (before : Checked width) (result : EdgeValue Symbol Guard)
    (after : Checked width) (fourth savedFourth : Fourth) (memo saved : Memo) (final : Memos) : Prop where
  ready : Ready after
  admitted : At formulas solver inventory after
  effects : SourceCurrentConjunctionRowsAllocation.Effects (physical before) (physical after)
  resident : InternedEdgeResidency.EdgeResident after.native.machine.heap result
  stored : SourceCurrentMemoMergeEffects.Stored after.native.machine.heap saved
  covered : ∀ ambient, SourceCurrentMemoMergeLanguage.CacheCovers (SourceEqualityPCSGuard.holds formulas solver) ambient saved
  retained : Extends memo saved
  globals : Valid after.native.machine.heap final
  correct : SourceCurrentEmptinessMemo.Correct formulas solver after.native.machine.heap savedFourth
  fourthRetained : SourceCurrentEmptinessMemo.Extends fourth savedFourth
  construction : SourceCurrentAllocatedMkEdge.RejectReceipt formulas solver inventory symbol before result after ∨
    ∃ children middle, children.length = values.length ∧
      SourceCurrentAllocatedMkEdge.Receipt formulas solver inventory symbol loaded children middle result after
  language : ∀ ambient term,
    (edgeMeaning (SourceEqualityPCSGuard.holds formulas solver) ambient result term →
      RawMeaning (SourceEqualityPCSGuard.holds formulas solver) ambient symbol original values term) ∧
    (SourceEqualityPrecheck.Sat term inherited.payload →
      (edgeMeaning (SourceEqualityPCSGuard.holds formulas solver) ambient result term ↔
        RawMeaning (SourceEqualityPCSGuard.holds formulas solver) ambient symbol original values term))

omit [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] [DecidableEq (Value Symbol Guard)] in
