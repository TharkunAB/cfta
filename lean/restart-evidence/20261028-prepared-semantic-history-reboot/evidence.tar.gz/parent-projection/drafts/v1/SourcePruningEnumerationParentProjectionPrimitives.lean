import MicroCFTA.SourceCurrentAllocatedProbeExposure
import MicroCFTA.InternedFreshOrdinaryFacts
import MicroCFTA.InternedFreshOrdinaryStoredConstraintHeap
import MicroCFTA.SourceEqualityProjectionCosts
import MicroCFTA.SourcePruningEnumerationNativeQueryProjectionHeap
import MicroCFTA.SourceCurrentRequiredHeapEffects

/-!
# Projectability through actual open exposure and projection

This draft follows the actual recorded worker endpoints.
It does not assert completion of an arbitrary native prefix.
-/
namespace MicroCFTA.SourcePruningEnumerationParentProjectionPrimitives
open InternedConstructorTemplates InternedProbeProvenance
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
  (fun constraint : Guard => SourcePruningEnumerationConstraint.project constraint ≠ none)
variable {Symbol : Type}

/-- Node allocation adds no edge guard. -/
theorem node_heap [DecidableEq (EdgeKey Symbol Guard)]
    (rows : List (EdgeValue Symbol Guard)) (before : State Symbol Guard)
    (heap : Heap before) : Heap (run (makeNode rows) before).2 :=
  SourceEqualityAnnotationHeap.run _ _ (SourceEqualityAnnotationHeap.makeNode _ rows) before heap

/-- Stored unfolding retains every original edge guard. -/
theorem unfold_heap [DecidableEq (EdgeKey Symbol Guard)]
    (value : Value Symbol Guard) (before : State Symbol Guard)
    (facts : InternedNestedFacts.Facts before) (heap : Heap before)
    (available : Available before value) :
    Heap (InternedFreshOrdinaryStoredSubstitution.unfold value before).state :=
  InternedFreshOrdinaryStoredConstraintHeap.unfold_heap _ value before facts heap available

end MicroCFTA.SourcePruningEnumerationParentProjectionPrimitives

namespace MicroCFTA.SourcePruningEnumerationProbeExposureProjectionHeap
open Cache InternedConstructorTemplates InternedProbeProvenance
open InternedNestedFacts
open InternedNestedProvenance (Values)
open InternedNestedConstruction (Outcome)
open MergedFreshOrdinaryExposure
open MergedSourceExposure (Result)
open SourceEqualityAnnotationExposure (prepend_state canonical_state)
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
  (fun constraint : Guard => SourcePruningEnumerationConstraint.project constraint ≠ none)
variable {Symbol : Type}

private theorem unfold_verified [DecidableEq (EdgeKey Symbol Guard)]
    (value : Value Symbol Guard) (state : State Symbol Guard)
    (facts : Facts state) (available : Available state value) :
    Verified state (InternedFreshOrdinaryStoredSubstitution.unfold value state) Available := by
  cases value with
  | empty | reference | node | union => exact pure_verified state facts _ Available available
  | mu entry body depth ordinary =>
      apply InternedFreshOrdinaryFacts.build_verified _ _ state facts
      apply InternedStoredSubstitution.inputs_available body _ state
        (available.children body (by simp [children]))
      intro name replacement found
      simp only [] at found
      split at found
      · cases found; exact available
      · contradiction

/-- Every actual bounded worklist retains projectability at its exact done, pending, unresolved or exhausted cache. -/
theorem collect_heap [DecidableEq (EdgeKey Symbol Guard)]
    (fuel : Nat) (state : State Symbol Guard) (facts : Facts state) (heap : Heap state)
    (seen : List Nat) (pending : List (Value Symbol Guard)) (inputs : Values state pending) :
    Heap (collect fuel state seen pending).state := by
  induction fuel generalizing state seen pending with
  | zero => cases pending <;> exact heap
  | succ fuel ih =>
      cases pending with
      | nil => exact heap
      | cons value rest =>
          have available := inputs value List.mem_cons_self
          have restInputs : Values state rest := fun child member => inputs child (List.mem_cons_of_mem _ member)
          cases value with
          | empty => exact ih state facts heap seen rest restInputs
          | reference => exact heap
          | node entry edges depth free =>
              simpa only [collect, prepend_state] using ih state facts heap seen rest restInputs
          | union entry members depth free =>
              by_cases visited : entry.identity ∈ seen
              · simpa only [collect, ite_eq_left visited] using ih state facts heap seen rest restInputs
              · have nextInputs : Values state (members ++ rest) := by
                  intro child member
                  rcases List.mem_append.mp member with first | later
                  · exact available.children child first
                  · exact restInputs child later
                simpa only [collect, ite_eq_right visited] using
                  ih state facts heap (entry.identity :: seen) (members ++ rest) nextInputs
          | mu entry body depth ordinary =>
              by_cases visited : entry.identity ∈ seen
              · simpa only [collect, ite_eq_left visited] using ih state facts heap seen rest restInputs
              · have verified := unfold_verified (.mu entry body depth ordinary) state facts available
                have retained := SourcePruningEnumerationParentProjectionPrimitives.unfold_heap
                  (.mu entry body depth ordinary) state facts heap available
                cases unfolded : InternedFreshOrdinaryStoredSubstitution.unfold (.mu entry body depth ordinary) state with
                | pending key after =>
                    simpa only [collect, ite_eq_right visited, unfolded, Outcome.state, Result.state] using retained
                | done result after =>
                    have afterFacts : Facts after := by simpa only [unfolded, Outcome.state] using verified.facts
                    have afterHeap : Heap after := by simpa only [unfolded, Outcome.state] using retained
                    have nextInputs : Values after (result :: rest) := by
                      intro child member
                      rcases List.mem_cons.mp member with rfl | member
                      · exact verified.result child after unfolded
                      · simpa only [unfolded, Outcome.state] using verified.available child (restInputs child member)
                    simpa only [collect, ite_eq_right visited, unfolded] using
                      ih after afterFacts afterHeap (entry.identity :: seen) (result :: rest) nextInputs

/-- Direct reads and closure fallback retain the entire actual edge-record projectability heap. -/
theorem nodeEdges_heap [DecidableEq (EdgeKey Symbol Guard)]
    (fuel : Nat) (value : Value Symbol Guard) (state : State Symbol Guard)
    (facts : Facts state) (heap : Heap state) (available : Available state value) :
    Heap (nodeEdges fuel value state).state := by
  have fallback (current : State Symbol Guard) (currentFacts : Facts current)
      (currentHeap : Heap current) (root : Value Symbol Guard) (rootAvailable : Available current root) :
      Heap (collect fuel current [] [root]).canonical.state := by
    rw [canonical_state]
    exact collect_heap fuel current currentFacts currentHeap [] [root]
      (by intro child member; simpa only [List.mem_singleton.mp member] using rootAvailable)
  cases value with
  | empty | reference | node => exact heap
  | union => exact fallback state facts heap _ available
  | mu entry body depth ordinary =>
      have verified := unfold_verified (.mu entry body depth ordinary) state facts available
      have retained := SourcePruningEnumerationParentProjectionPrimitives.unfold_heap
        (.mu entry body depth ordinary) state facts heap available
      cases unfolded : InternedFreshOrdinaryStoredSubstitution.unfold (.mu entry body depth ordinary) state with
      | pending key after =>
          simpa only [nodeEdges, unfolded, Outcome.state, Result.state] using retained
      | done result after =>
          have afterFacts : Facts after := by simpa only [unfolded, Outcome.state] using verified.facts
          have afterHeap : Heap after := by simpa only [unfolded, Outcome.state] using retained
          have rootAvailable : Available after (.mu entry body depth ordinary) := by
            simpa only [unfolded, Outcome.state] using verified.available _ available
          have closure := fallback after afterFacts afterHeap (.mu entry body depth ordinary) rootAvailable
          cases result with
          | node => simpa only [nodeEdges, unfolded, Result.state] using afterHeap
          | empty | reference | union | mu => simpa only [nodeEdges, unfolded] using closure

/-- The actual comparison-read spelling keeps the same heap at successful and failed outcomes. -/
theorem read_outcome_heap [DecidableEq (EdgeKey Symbol Guard)]
    (fuel : Nat) (value : Value Symbol Guard) (state : State Symbol Guard)
    (facts : Facts state) (heap : Heap state) (available : Available state value) :
    Heap (MergedFreshOrdinaryExposure.read fuel value state).state := by
  have retained := nodeEdges_heap fuel value state facts heap available
  cases actual : nodeEdges fuel value state with
  | done rows after | unresolved name after | pending key after | exhausted after =>
      simpa only [MergedFreshOrdinaryExposure.read, actual, Result.state, MergedSourceComparison.Result.state] using retained

/-- A completed actual projection read retains projectability at its own returned heap. -/
theorem read_heap [DecidableEq (EdgeKey Symbol Guard)]
    {value : Value Symbol Guard} {before after : State Symbol Guard} {edges : List (EdgeValue Symbol Guard)}
    (actual : SourceEqualityProjectionRead.Read value before edges after)
    (facts : Facts before) (available : Available before value) (heap : Heap before) : Heap after := by
  cases actual with
  | done fuel completed =>
      simpa only [completed, Result.state] using nodeEdges_heap fuel value before facts heap available

/-- The actual row reconstruction adds no edge record after its literal read. -/
theorem head_heap [DecidableEq (EdgeKey Symbol Guard)]
    {value result : Value Symbol Guard} {before after : State Symbol Guard}
    (actual : SourceEqualityRequiredHead.Head value before result after)
    (facts : Facts before) (available : Available before value) (heap : Heap before) : Heap after := by
  cases actual with
  | read fuel edges middle exposed rebuilt =>
      have middleHeap := read_heap (.done fuel exposed) facts available heap
      simpa only [rebuilt] using SourcePruningEnumerationParentProjectionPrimitives.node_heap edges middle middleHeap

/-- Current checked readiness supplies the record facts for the exact bounded cold read. -/
theorem nodeEdges_heap_of_good
    [DecidableEq (EdgeKey (SourceObservations.Label FullSyntax.Formula) Guard)]
    {width : Nat} (fuel : Nat) (value : Value (SourceObservations.Label FullSyntax.Formula) Guard)
    (before : SourceEqualityNativeDemand.State width)
    (good : SourceCurrentAllocatedNativePhysicalCompletion.Good before)
    (heap : Heap before.native.machine.heap) (available : Available before.native.machine.heap value) :
    Heap (nodeEdges fuel value before.native.machine.heap).state :=
  nodeEdges_heap fuel value before.native.machine.heap good.heap.semantic.1.normal.facts heap available

end MicroCFTA.SourcePruningEnumerationProbeExposureProjectionHeap


namespace MicroCFTA.SourcePruningEnumerationPathProjectionHeap
open InternedConstructorTemplates InternedProbeProvenance
open InternedNestedProvenance (Values Edges)
open SourceEqualityRequiredCache SourceEqualityRequiredSemanticCache
open SourceEqualityProjectionGraph SourceEqualityProjectionRead SourceEqualityProjectionUnion
variable {Symbol : Type}
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
  (fun constraint : Guard => SourcePruningEnumerationConstraint.project constraint ≠ none)
local notation "CostHeap" => InternedFreshOrdinaryCostHeap.Heap
variable [DecidableEq (EdgeKey Symbol Guard)]

/-- Every actual ordered row read retains projectability at its complete returned heap. -/
theorem readAll_heap
    {values : List (Value Symbol Guard)} {before after : State Symbol Guard} {edges : List (EdgeValue Symbol Guard)}
    (actual : ReadAll values before edges after) (semantic : SemanticReady before)
    (costs : CostHeap before) (available : Values before values) (heap : Heap before) : Heap after := by
  induction actual with
  | nil => exact heap
  | @cons value before rows middle values more after first rest ih =>
      have reached := SourceEqualityProjectionCosts.read_effects first semantic costs (available _ List.mem_cons_self)
      have current := SourcePruningEnumerationProbeExposureProjectionHeap.read_heap first
        semantic.ready.semantic.1.normal.facts (available _ List.mem_cons_self) heap
      exact ih reached.2.1 reached.2.2.1
        (fun child member => reached.1.available child (available child (List.mem_cons_of_mem _ member))) current

/-- The literal source union reads its inputs and adds no new edge record afterward. -/
theorem union_heap
    {values : List (Value Symbol Guard)} {before after : State Symbol Guard} {result : Value Symbol Guard}
    (actual : Union values before result after) (semantic : SemanticReady before)
    (costs : CostHeap before) (available : Values before values) (heap : Heap before) : Heap after := by
  cases actual with
  | node read built =>
      have current := readAll_heap read semantic costs available heap
      have sameState := congrArg Prod.snd built
      dsimp only at sameState
      rw [← sameState]
      exact SourcePruningEnumerationParentProjectionPrimitives.node_heap _ _ current

private def NodeHeap (value : Value Symbol Guard) (before after : State Symbol Guard) : Prop :=
  SemanticReady before → CostHeap before → Available before value → Heap before → Heap after

private def RowsHeap (edges : List (EdgeValue Symbol Guard)) (before after : State Symbol Guard) : Prop :=
  SemanticReady before → CostHeap before → Edges before edges → Heap before → Heap after

private theorem project_heaps :
    (∀ path (value : Value Symbol Guard) before result after,
      Project path value before result after → NodeHeap value before after) ∧
    (∀ path index (edges : List (EdgeValue Symbol Guard)) before results after,
      ProjectRows path index edges before results after → RowsHeap edges before after) := by
  have rootCase : ∀ {value : Value Symbol Guard} {state}, NodeHeap value state state := by
    intro value state _ _ _ heap
    exact heap
  have emptyCase : ∀ {state}, NodeHeap (.empty : Value Symbol Guard) state state := by
    intro state _ _ _ heap
    exact heap
  have ordinaryCase : ∀ {path index edges before values middle result after entry depth free},
      ProjectRows (Symbol := Symbol) («Guard» := Guard) path index edges before values middle →
      Union values middle result after → RowsHeap edges before middle →
      NodeHeap (.node entry edges depth free) before after := by
    intro path index edges before values middle result after entry depth free rows union ih semantic costs available heap
    have resident := InternedEdgeResidency.resident_edges before
      semantic.ready.semantic.1.normal.facts.linked _ available.resident
    have current := ih semantic costs resident heap
    have reached := SourceEqualityProjectionCosts.rows_effects rows semantic costs resident
    exact union_heap union reached.2.1 reached.2.2.1 reached.2.2.2 current
  have recursiveCase : ∀ {original before exposed middle path index result after},
      SourceEqualityRequiredGraph.Recursive original → SourceEqualityRequiredHead.Head original before exposed middle →
      Project (Symbol := Symbol) («Guard» := Guard) (index :: path) exposed middle result after →
      NodeHeap exposed middle after → NodeHeap original before after := by
    intro original before exposed middle path index result after _ head _ ih semantic costs available heap
    have reached := SourceEqualityProjectionCosts.head_effects head semantic costs available
    have current := SourcePruningEnumerationProbeExposureProjectionHeap.head_heap head
      semantic.ready.semantic.1.normal.facts available heap
    exact ih reached.2.1 reached.2.2.1 reached.2.2.2 current
  have nilCase : ∀ {state}, RowsHeap ([] : List (EdgeValue Symbol Guard)) state state := by
    intro state _ _ _ heap
    exact heap
  have missingCase : ∀ {edge path index edges before results after}, select edge.children index = none →
      ProjectRows (Symbol := Symbol) («Guard» := Guard) path index edges before results after →
      RowsHeap edges before after → RowsHeap (edge :: edges) before after := by
    intro edge path index edges before results after _ _ ih semantic costs resident heap
    exact ih semantic costs (fun row member => resident row (List.mem_cons_of_mem _ member)) heap
  have selectedCase : ∀ {edge index child path before result middle edges results after},
      select edge.children index = some child → Project (Symbol := Symbol) («Guard» := Guard) path child before result middle →
      ProjectRows path index edges middle results after → NodeHeap child before middle →
      RowsHeap edges middle after → RowsHeap (edge :: edges) before after := by
    intro edge index child path before result middle edges results after found first _ firstIH restIH semantic costs resident heap
    have available := semantic.ready.semantic.1.normal.facts.cached.edges edge.entry.key edge
      (resident edge List.mem_cons_self) child (select_member found)
    have current := firstIH semantic costs available heap
    have reached := SourceEqualityProjectionCosts.project_effects first semantic costs available
    exact restIH reached.2.1 reached.2.2.1
      (fun row member => InternedEdgeResidency.edge_grows before middle reached.1.growth row
        (resident row (List.mem_cons_of_mem _ member))) current
  constructor
  · intro path value before result after trace
    exact Project.rec (motive_1 := fun _ value before _ after _ => NodeHeap value before after)
      (motive_2 := fun _ _ edges before _ after _ => RowsHeap edges before after)
      rootCase emptyCase ordinaryCase recursiveCase nilCase missingCase selectedCase trace
  · intro path index edges before results after trace
    exact ProjectRows.rec (motive_1 := fun _ value before _ after _ => NodeHeap value before after)
      (motive_2 := fun _ _ edges before _ after _ => RowsHeap edges before after)
      rootCase emptyCase ordinaryCase recursiveCase nilCase missingCase selectedCase trace

/-- Every completed actual path projection retains the entire projectability heap. -/
theorem project_heap
    {path : List Int} {value result : Value Symbol Guard} {before after : State Symbol Guard}
    (actual : Project path value before result after) (semantic : SemanticReady before)
    (costs : CostHeap before) (available : Available before value) (heap : Heap before) : Heap after :=
  project_heaps.1 _ _ _ _ _ actual semantic costs available heap

/-- Ordered actual row projections retain every old and newly reconstructed edge record. -/
theorem rows_heap
    {path : List Int} {index : Int} {edges : List (EdgeValue Symbol Guard)} {results : List (Value Symbol Guard)}
    {before after : State Symbol Guard} (actual : ProjectRows path index edges before results after)
    (semantic : SemanticReady before) (costs : CostHeap before) (resident : Edges before edges)
    (heap : Heap before) : Heap after := project_heaps.2 _ _ _ _ _ _ actual semantic costs resident heap

/-- The actual forest root, missing child and selected child branches preserve projectability. -/
theorem forest_heap
    {path : List Int} {values : List (Value Symbol Guard)} {result : Value Symbol Guard} {before after : State Symbol Guard}
    (actual : Forest path values before result after) (semantic : SemanticReady before)
    (costs : CostHeap before) (available : Values before values) (heap : Heap before) : Heap after := by
  cases actual with
  | root union => exact union_heap union semantic costs available heap
  | missing => exact heap
  | selected found body => exact project_heap body semantic costs (available _ (select_member found)) heap

end MicroCFTA.SourcePruningEnumerationPathProjectionHeap

