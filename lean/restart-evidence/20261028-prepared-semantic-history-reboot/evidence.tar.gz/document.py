from pathlib import Path
import hashlib
import json

repo = Path('/home/tritlo/Code/mcfta')
area = Path('/tmp/mcfta-prepared-semantic-history-20261028')
head = (area / 'source-head.txt').read_text().strip()
public = json.loads((area / 'public-validation.json').read_text())
validation = json.loads((area / 'source-validation.json').read_text())

def digest(data):
    return hashlib.sha256(data).hexdigest()

common = f'''
## Admitted histories at every finite prepared driver depth

Source checkpoint: {head}. Whole-CFTA goal ACTIVE. Checkpoint PROGRESS.
For every fixed finite recursive depth, the admitted prepared driver has
one stable actual outcome at all sufficiently large work fuels. The complete
previous endpoint and output resource result remains. Every emitted output
now also has a ResourceHistory at that SAME chosen work bound. Each recursive
input retains its original Packet, Fits, known guards, suspended mass and
reservation. Each selected step retains actual prefix validity, preparation,
full Memos, ordinary or opaque receipt, false recording and recursive tail.
The finite entry proves the stronger induction hypothesis. It takes no
supplied Complete, history, semantic model or future success premise.
Stopped and exhausted outcomes remain possible. Outputs before a later stop
retain their histories.

Actual preparation now connects the original stored value to its separate
prepared ordinary parent in the backward language proof. An actual ordinary
callback restores the selected input model through preparation and prefix.
The old Canonical, nonterminal, fresh projected arity, retained-child and
final satisfying-assignment gates remain. No new Ranges premise is added.
Whole-parent completed execution also preserves the projectable native heap
from its original admitted heap. Neither result establishes semantic output
soundness for every driver branch.

The largest remaining connection is semantic induction through these admitted
histories. Derive the ordinary branch gates from real receipts where possible.
Prove the backward opaque and terminal cases and compose parked restarts.
Global accepted-output coverage also needs an original sufficient recursive
depth for ALL earlier callbacks. Fixed-depth resource closure does not supply
that depth. Public API adapters, ranking, sampling and physical Haskell
correspondence remain open. Conditional finite-pruning language preservation
and all earlier results retain their recorded scope.

Twenty-four modules add 63 public theorems and nine definitions. All 25 final
strict checks pass. Full Audit passes 4433 jobs and checks 81262 theorem
dependencies. Public readback has 574 theorem blocks and 57 definitions.
Its complete previous 2256710-byte output is an exact prefix. All 4408 prior
non-Audit Lean, 257 strong and 810 Haskell source/evidence files retain bytes.
No Haskell file changed. No new Haskell defect or required repair was found.
Details: lean/notes-current-prepared-semantic-history.md.

'''
findings = common + '''### Haskell comparison and external integration handoff

No Haskell or Cabal file changed in this checkpoint. No Haskell test or
benchmark ran. No new Haskell defect or required repair was established.
Keep the integrated LPO and KBO Natural-weight repairs and all earlier
counterexamples below. Refreshed main d1ca06a1dd0c7488205feda613b529df21a08669
is already an ancestor. This checkpoint requests no Haskell patch.

The new resource-history theorem concerns the actual modeled prepared worker.
It does not prove refinement of the Haskell implementation. Full memo states
pass through the real chronological callbacks and sibling scan. The original
stored handle remains separate from the prepared parent. Do not replace that
distinction with a lookup equation that identifies the two values.

The ordinary semantic bridge uses the same actual preparation witnesses.
It derives the source/prepared language equivalence from that preparation.
Its local backward conclusion still requires a satisfying callback cache,
Canonical input, nonterminal constraints, fresh projected arity and the
retained-child condition. Resource admission alone supplies no model.

The whole-parent heap theorem covers completed actual reduction, native
queries, edits, class scans and checked parent construction. It retains the
original physical, readiness, semantic and resource premises. It does not
assume arbitrary raw conjunction supports projection. It does not cover all
failed or pending native query prefixes. Its initial projectable heap remains
explicit. Attaching that heap property to every recursive history is open.

The depth obstruction remains unchanged. An earlier stopped callback can omit
later siblings. More work fuel cannot remove recursive-depth exhaustion.
Fresh UVar IDs do not change recursion keys. Union narrowing can remove the
original Union before entry. Equality normalization can increase path length.
The previous counterexamples and rejected progress measures remain below.
No complete admitted divergence example was established here.

Next, consume ResourceHistory in a semantic induction. Keep opaque and terminal
receipts separate from ordinary completed-head receipts. Prove original
path and recursive-identity carriers before claiming a global depth bound.

'''
insertions = area / 'document-insertions'
insertions.mkdir()
(insertions / 'common.md').write_text(common)
(insertions / 'findings.md').write_text(findings)
records = {}
for previous in sorted((area / 'prior-documents').rglob('*.md')):
    name = previous.relative_to(area / 'prior-documents')
    old = previous.read_bytes()
    assert (repo / name).read_bytes() == old
    insertion = (findings if str(name) == 'FINDINGS.md' else common).encode()
    first, rest = old.split(b'\n', 1)
    new = first + b'\n' + insertion + rest
    assert new.replace(insertion, b'', 1) == old
    (repo / name).write_bytes(new)
    records[str(name)] = dict(before_sha256=digest(old), after_sha256=digest(new), inserted_bytes=len(insertion))
(area / 'document-inverse.json').write_text(json.dumps(records, indent=2) + '\n')

note = f'''# Admitted prepared histories and actual semantic receipts

Source checkpoint: {head}. Whole-CFTA goal ACTIVE. Checkpoint PROGRESS.
Five proof and Audit commits are published on formalize. The evidence commit follows.

## Strongest current statement

Under the recorded original admission, resource, selector and policy conditions,
finite pruning preserves the represented language. For every fixed finite
recursive depth, the prepared enumeration worker has one stable actual outcome
at all sufficiently large work fuels. Every output in that outcome now has an
actual recursive history with the admitted state and resource facts retained
at each input. This includes outputs retained before a later stop.

The model and original-subtree results for startup, preparation, branch,
sibling-event and recording stages remain. The new ordinary backward bridge
uses the actual preparation receipt to restore a selected input model.
Whole-driver output soundness and original accepted-output coverage remain
open. The finite-depth theorem permits stops and exhaustion. It supplies no
global sufficient recursive depth and no physical Haskell refinement.

## Actual finite resource histories

PreparedRecursive.HistoryAdmission records the original Packet, Fits, known
guards, suspended mass bound and original finite reservation. ResourceHistory
has the actual stop, done, parked and selected cases. The parked case retains
the literal prefix and framed restart. The selected case retains PrefixValid,
the literal narrowed phase, the full prefix Post and Memos, actual preparation
and ordinary or opaque invocation, actual false recordTypes output and the
same smaller-depth tail. ResourceHistory.forget returns the existing actual
operational OutputHistory.

SelectedHistoryReceipt retains the original stored source and separate prepared
parent. It includes the actual stable and selected-fuel preparation equations,
source lookup, Post, full Memos, both cache states, Ready, stored slot, values,
counter, index preservation, parent availability, closedness and universal
source/prepared language equivalence. Its ordinary case contains the actual
CompletedHeadReceipt. Its opaque case contains an actual opaque dispatch,
Post, captured and completed Packets, admission, pending references and
fragment history. No ordinary receipt is assigned to an opaque branch.

CallbackOutputHistoryAt keeps the literal false recording and recursive frame.
The actual head, receipt, sibling, finished scan, ordinary and opaque producers
derive these certificates. The original sibling order and full native memo
states remain. All certificates use the same chosen work fuel as execution.

PreparedRecursive.finite_complete_with_history proves the stronger contract by
depth induction. run_finite_complete_resources_with_history derives the public
result from the original inputs. Neither finite entry accepts Complete, an
output history, a semantic model or future successful execution as an input.
The entire previous running and OutcomeResources fields remain first.
Local induction producers use a smaller CompleteWithHistory hypothesis. The
public finite theorem discharges it for every natural recursive depth.

## Actual preparation and ordinary backward meaning

SelectedPreparation.identify_complete calls the actual preparation producer
once. A common larger fuel identifies its exact witnesses with the observed
stable preparation. The entered cache is the actual frame, including index
and waiting data. It is not replaced by an arbitrary cache from its core.

CapturedEdge.stable_complete_sound_prepared_resources uses a separate available
closed prepared parent and retains the original stored source handle. Its
diagonal adapter uses the actual prepared resource producer. It adds no Ranges
premise. The entire old five semantic fields remain grouped first. Original
source acceptance is appended.

CompletedHeadReceipt.sound_ordinary_input and sound_ordinary_callback_input
derive that preparation equivalence from the same actual preparation. The
source lookup passes through the real preparation and prefix Keeps effects.
The false callback restores the original model. SelectedStep.
narrowed_receipt_sound_prepared also restores the outer selected prefix.
It derives the narrowed cache Packet from actual prefix facts and full Post.

These are conditional backward statements. Canonical input, nonterminal
inherited constraints, fresh projected arity, retained-child conditions and
a satisfying final callback cache remain explicit. Resource admission does
not imply those semantic premises. Full history consumption remains open.

## Whole-parent projection support

The six ParentProjection modules preserve the projectable native heap through
actual allocation, exposure, projection, merge, target query, seeded query,
edits, class folds, conjunction scans, local reduction and checked parent
construction. Completed rich native queries discharge smaller-call obligations.
Accepted checked construction supplies the combined guard projection. The
rejected sentinel also preserves the property. No closure theorem for an
arbitrary raw conjoin is assumed.

The public finite parent theorem retains the complete old running, Reads and
Receipt packet, then appends the whole returned heap property. Its original
physical, resource, readiness and semantic admissions remain. An original
projectable heap is explicit. Failed and pending prefixes are outside this
completed execution result. Every recursive history does not yet carry this
heap property.

## Remaining proof obligations

Consume the admitted resource history in a semantic induction. Use the actual
ordinary receipt bridge and prove the opaque, terminal and parked cases.
Derive ordinary branch gates from original checked annotations and real
receipts where possible. Do not add future model or endpoint success gates
to the original input contract.

Accepted-output coverage needs selector coverage, original template and policy
origins, and a sufficient recursive depth for every earlier reachable callback.
A chosen term's height alone does not bound those earlier callbacks. Fresh
IDs do not alter recursion keys. Union narrowing can remove the original
boundary before entry. Equality closure can lengthen paths. Derive one
original path domain and a finite recursive-identity carrier through all actual
allocation and reconstruction. The prior depth audit retains the exact failed
measures and source comparisons. No admitted all-depth divergence example is
claimed. Public API, ranking, sampling and physical Haskell correspondence
remain open.

## Validation and preservation

Twenty-four modules add 63 public theorems and nine definitions. All 25 final
strict checks pass with warningAsError=true and linter.all=true. Full Audit
passes 4433 jobs and checks 81262 theorem dependencies. There are 61 current
compiler, build and public commands plus one inherited receipt. Four failed
strict attempts remain with complete logs and immutable drafts. All commands
run serially with measured memory.max=memory.high=4294967296 and swap.max=0.
No proof limit was raised. No linter was disabled. No new proof uses sorry,
admit, a custom axiom or native_decide. One constructor case is named @admit;
it is not the proof-hole tactic. The build replays one unchanged old warning.

Public readback contains 574 complete signatures and axiom lists, plus 57
printed definitions. Only propext, Classical.choice and Quot.sound occur.
The complete prior 2256710-byte output is an exact prefix. There is no elision.
Full readback: {public['bytes']} bytes, SHA256 {public['sha256']}.
New appendix: {public['new_bytes']} bytes, SHA256 {public['new_sha256']}.
Named owners review the complete assigned public blocks. Root reads all new
sources, corrective diffs and failed compiler logs. The review records state
their exact scope. Copying a source alone is not a whole read.

All 4408 prior non-Audit Lean, 257 strong and 810 Haskell source/evidence files
retain exact bytes. Audit adds imports before its complete previous body.
Nine documents retain their old bodies after the insertion is removed.
No Haskell or Cabal file changed. No Haskell test or benchmark ran. No new
Haskell defect or required repair was established. FINDINGS retains the
integrated LPO and KBO Natural repairs. Refreshed main is already included.

The failed identification draft had an ambiguous explicit common-run type.
The semantic draft needed the actual frame counter equation. Two foundation
drafts had an unqualified FragmentBound and an intentionally unused callback
target binder. Their final statements retain the original admissions.
Untested predecessor drafts remain separate from failed compiler commands.
An initial commit check found one extra EOF blank line in each parent module.
The final sources remove only those bytes and pass strict checks again.
The source validator initially matched the real @admit constructor case.
The corrected check permits that case pattern only. The failed check remains.
The public catalog's temporary namespace handling was corrected before the
compiler readback. No proof statement changed for that helper correction.

## Restart and evidence

Raw evidence: /tmp/mcfta-prepared-semantic-history-20261028.
Archive: lean/restart-evidence/20261028-prepared-semantic-history.
Each command retains its tested sources, complete raw output, exit code,
hashes and measured limits. The archive includes all frozen files and drafts.
Large and whitespace-sensitive payloads use deterministic gzip. The verifier
checks exact sets, source and public preservation, document inverses, live
reconstruction and committed bytes. Earlier frozen areas remain unchanged.
Use a fresh evidence area after this checkpoint is frozen.

The whole formalization is incomplete. Continue with semantic consumption of
the admitted histories. Keep the optimized interned core. Preserve older
constructor and equality work as secondary targets. Goal ACTIVE.
'''
target = repo / 'lean/notes-current-prepared-semantic-history.md'
assert not target.exists()
target.write_text(note)
(area / 'root-review/notes-current-prepared-semantic-history.md').write_text(note)
print(json.dumps({'documents':len(records),'common_bytes':len(common.encode()),'findings_bytes':len(findings.encode()),'note_bytes':len(note.encode()),'note_sha256':digest(note.encode())}))
