import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path('/home/tritlo/Code/mcfta')
area = Path('/tmp/mcfta-prepared-semantic-history-20261028')
label, message, *pairs = sys.argv[1:]
assert len(pairs) % 2 == 0
files = []
for module, check in zip(pairs[::2], pairs[1::2]):
    path = 'lean/MicroCFTA/' + module + '.lean'
    report = json.loads((area / check / 'report.json').read_text())
    assert report['exit_code'] == 0 and report['bytes'] == 0
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == report['source_sha256']
    files.append(path)

def git(*arguments):
    return subprocess.run(['git', *arguments], cwd=root, check=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).stdout.decode()

assert not git('diff', '--cached', '--name-only').strip()
git('add', '--', *files)
assert set(git('diff', '--cached', '--name-only').splitlines()) == set(files)
git('diff', '--cached', '--check')
result = git('commit', '-m', message)
receipt = {'head':git('rev-parse', 'HEAD').strip(), 'files':files, 'message':message, 'result':result}
target = area / (label + '-commit.json')
assert not target.exists()
target.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
