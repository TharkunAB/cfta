from pathlib import Path
import hashlib
import json
import shutil

repo = Path('/home/tritlo/Code/mcfta')
area = Path('/tmp/mcfta-prepared-semantic-history-20261028')


def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new, 1)


old_parent = '    (decoded : lookupNode caller.checked.native.machine.heap handle = some (.node parentEntry edges depth free))'
prepared_parent = '''    (parentAvailable : Available caller.checked.native.machine.heap (.node parentEntry edges depth free))
    (parentClosed : free = [])'''
source_parent = '''    (sourceValue : Node)
    (decoded : lookupNode caller.checked.native.machine.heap handle = some sourceValue)
'''+prepared_parent+'''
    (preparedMeaning : ∀ ambient term,
      InternedGuardedLanguage.meaning (SourceEqualityPCSGuard.holds formulas solver)
        ambient (.node parentEntry edges depth free) term ↔
      InternedGuardedLanguage.meaning (SourceEqualityPCSGuard.holds formulas solver)
        ambient sourceValue term)'''
old = (repo / 'lean/MicroCFTA/SourcePruningEnumerationCapturedEdgeResourceSoundness.lean').read_text()
text = replace_once(old, 'import MicroCFTA.SourcePruningEnumerationCapturedEdgeResources',
                    'import MicroCFTA.SourcePruningEnumerationCapturedPreparedResources')
text = replace_once(text, '''# Native soundness after actual captured-slot finalization

The original resource admission bounds the actual expansion.
The expansion transports the neutral captured payload.
The final fragment equation restores the original pending restriction.''', '''# Resource-based backward meaning for an actual prepared parent

The original stored value remains separate from the prepared parent.
The same preparation supplies their language equivalence.
Original resource reservations replace a universal range premise.
Actual completed receipts retain all original semantic conditions.''')
text = replace_once(text, 'theorem stable_complete_sound_current_resources',
                    'theorem stable_complete_sound_prepared_resources')
text = replace_once(text, old_parent, source_parent)
text = replace_once(text, '        assignment after.core →\n      Satisfies',
                    '        assignment after.core →\n      (Satisfies')
text = replace_once(text, '''      Fragments.fill assignment fragment = assignment uv := by
  obtain ⟨value, lookup, available, closed⟩ := realized uv handle scs stored
  have same : value = .node parentEntry edges depth free := Option.some.inj (lookup.symm.trans decoded)
  subst value''', '''      Fragments.fill assignment fragment = assignment uv) ∧
      InternedGuardedLanguage.meaning (SourceEqualityPCSGuard.holds formulas solver)
        ambient sourceValue (assignment uv) := by
  have available := parentAvailable
  have closed := parentClosed''')
text = replace_once(text, 'exact (SourcePruningEnumerationNativeLanguage.handles_lookup _ _ _ _ _ _ decoded).mpr parentAccepted',
                    '''exact (SourcePruningEnumerationNativeLanguage.handles_lookup _ _ _ _ _ _ decoded).mpr
          ((preparedMeaning ambient (Fragments.fill assignment fragment)).mp parentAccepted)''')
text = replace_once(text, '''    exact ⟨original, by simpa only [equation] using edgeAccepted,
      by simpa only [equation] using parentAccepted,
      by simpa only [equation] using suspended, equation⟩''', '''    refine ⟨⟨original, by simpa only [equation] using edgeAccepted,
      by simpa only [equation] using parentAccepted,
      by simpa only [equation] using suspended, equation⟩, ?_⟩
    exact (preparedMeaning ambient (assignment uv)).mp (by simpa only [equation] using parentAccepted)''')
ending = '\nend MicroCFTA.SourcePruningEnumerationCapturedEdge\n'
assert text.endswith(ending)
text = text[:-len(ending)]

diagonal = (repo / 'lean/MicroCFTA/SourcePruningEnumerationCapturedEdgeDiagonalResourceSoundness.lean').read_text()
begin = diagonal.index('/-- Original resources identify')
middle = diagonal.index('/-- Actual diagonal completion')
stable = diagonal[begin:middle]
stable = replace_once(stable, 'theorem stable_complete_of_diagonal_resources',
                      'theorem stable_complete_of_diagonal_resources_prepared')
stable = replace_once(stable, old_parent, prepared_parent)
stable = replace_once(stable, '    complete_resources seed', '    complete_with_history_resources_prepared seed')
stable = replace_once(stable, 'edge roots memos initial ready stored decoded realized selected',
                      'edge roots memos initial ready stored parentAvailable parentClosed realized selected')
sound = diagonal[middle:-len(ending)]
sound = replace_once(sound, 'theorem diagonal_complete_sound_current_resources',
                     'theorem diagonal_complete_sound_prepared_resources')
sound = replace_once(sound, old_parent, source_parent)
sound = replace_once(sound, '        assignment after.core →\n      Satisfies',
                     '        assignment after.core →\n      (Satisfies')
sound = replace_once(sound, '      Fragments.fill assignment fragment = assignment uv := by',
                     '''      Fragments.fill assignment fragment = assignment uv) ∧
      InternedGuardedLanguage.meaning (SourceEqualityPCSGuard.holds formulas solver)
        ambient sourceValue (assignment uv) := by''')
sound = replace_once(sound, '    stable_complete_of_diagonal_resources seed',
                     '    stable_complete_of_diagonal_resources_prepared seed')
sound = sound.replace('parentEntry edges depth free edge roots memos initial ready stored decoded realized selected',
                     'parentEntry edges depth free edge roots memos initial ready stored parentAvailable parentClosed realized selected', 1)
sound = replace_once(sound, '  exact stable_complete_sound_current_resources seed',
                     '  exact stable_complete_sound_prepared_resources seed')
sound = replace_once(sound, 'parentEntry edges depth free edge roots memos initial ready stored decoded realized selected',
                     'parentEntry edges depth free edge roots memos initial ready stored sourceValue decoded parentAvailable parentClosed preparedMeaning realized selected')
text += '\n'+stable+sound+ending
name = 'SourcePruningEnumerationPreparedCapturedResourcesLanguage'
draft = area / 'root-drafts/prepared-resource-language/v1' / (name+'.lean')
draft.parent.mkdir(parents=True)
draft.write_text(text)
shutil.copyfile(draft, repo / 'lean/MicroCFTA' / draft.name)
modules = json.loads((area / 'modules.json').read_text())
assert name not in modules
modules.append(name)
(area / 'modules.json').write_text(json.dumps(modules, indent=2)+'\n')
print(json.dumps(dict(module=name, lines=len(text.splitlines()), bytes=len(text.encode()), sha256=hashlib.sha256(text.encode()).hexdigest())))
