import hashlib
import json
from pathlib import Path

area = Path('/tmp/mcfta-prepared-semantic-history-20261028')
source = Path('/home/tritlo/Code/mcfta/lean/MicroCFTA/SourcePruningEnumerationPreparedFiniteExpansionResources.lean')
text = source.read_text()

def replace(old, new):
    global text
    assert text.count(old) == 1, (old[:120], text.count(old))
    text = text.replace(old, new)

replace('import MicroCFTA.SourcePruningEnumerationPreparedFiniteParkedResources',
        'import MicroCFTA.SourcePruningEnumerationPreparedFiniteParkedHistory')
replace('import MicroCFTA.SourcePruningEnumerationPreparedOrdinaryResources',
        'import MicroCFTA.SourcePruningEnumerationPreparedOrdinaryHistory')
replace('import MicroCFTA.SourcePruningEnumerationPreparedOpaqueFiniteResources',
        'import MicroCFTA.SourcePruningEnumerationPreparedOpaqueFiniteHistory')
replace('theorem selected_finite_complete_resources', 'theorem selected_finite_complete_resources_with_history')
replace('(recursive : Complete (bits := bits)', '(recursive : CompleteWithHistory (bits := bits)')
replace('(Forecast (recursiveFuel + 1) seed ceiling) outcome := by',
'''(Forecast (recursiveFuel + 1) seed ceiling) outcome ∧
      ∀ extra output, output ∈ SourcePruningEnumerationHookInvocation.hookOutputs outcome →
        ResourceHistory holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver
          (bound + extra) (recursiveFuel + 1) inventory caller memos metadata before seed ceiling
          (some (.expand uv)) output := by
  have admission : HistoryAdmission formulas solver inventory caller memos metadata before
      (recursiveFuel + 1) seed ceiling := ⟨packet, bounded, known, initialMass, reserved⟩''')
replace('⟨bound, outcome, running, resources⟩ := parked_finite_complete_resources',
        '⟨bound, outcome, running, resources, histories⟩ := parked_finite_complete_resources_with_history')
replace('using resources⟩', 'using resources, histories⟩')
replace('stageGrowth.1) stageGrowth.2⟩\n    intro extra\n    rw [resume, (phase extra).1]',
'''stageGrowth.1) stageGrowth.2, ?_⟩
    · intro extra
      rw [resume, (phase extra).1]
    · intro extra output member
      cases member''')
replace('SourcePruningEnumerationPreparedNativeOrdinaryResources.complete_resources',
        'SourcePruningEnumerationPreparedNativeOrdinaryResources.complete_resources_with_history')
replace('preparationRun, _preparedLookup, preparationPost', 'preparationRun, preparedLookup, preparationPost')
replace('preparedAvailable, preparedClosed, _preparedLanguage, _preparedModels',
        'preparedAvailable, preparedClosed, preparedLanguage, _preparedModels')
replace('_scanPacket, dispatchRun, _fullPost, resources⟩',
        '_scanPacket, dispatchRun, _fullPost, resources, histories⟩')
replace('(resources.mono growth.1 growth.2).post middlePost⟩',
        '(resources.mono growth.1 growth.2).post middlePost, ?_⟩')
replace('resources, opaqueFoldRun⟩', 'resources, opaqueFoldRun, opaqueHistories⟩')
replace('SourcePruningEnumerationPreparedNativeHookResources.opaque_finite_complete_resources',
        'SourcePruningEnumerationPreparedNativeHookResources.opaque_finite_complete_resources_with_history')
replace('using original⟩', 'using original, ?_⟩')

def history_tail(offset):
    return f'''      let w := prefixFuel + ({offset}) + extra
      obtain ⟨currentAction, currentPrefix, currentValid⟩ := phase ({offset} + extra)
      have aligned : prefixFuel + ({offset} + extra) = w := by dsimp [w]; omega
      rw [aligned] at currentPrefix currentValid
      have prefixObserved : runPrefix holeKey fits admits graph templates stop order metadata
          w w w w w w uv caller before memos.query =
          .narrowed checked (.done (phaseValue, some currentAction) heap) reached middleMemos.query
            (some [.ok ((), after.core)]) (some after)
            (some [.ok ((false, metadata), after.core)]) none := by
        simpa only [middleQuery] using currentPrefix
      obtain ⟨fragment, headCaller, headCache, returnedInventory, returnedMemos, callbackSeed, callbackCeiling,
        invocation, receipt, callbackAdmission, recorded, callbackCore, recording, _frame, tail⟩ := selectedHistory
      exact .selected admission currentValid prefixObserved middlePost invocation receipt callbackAdmission recording tail
'''

# Keep the complete old running proof as the first field. Append history at the same bound.
start = text.index('      apply resume_depth_stable')
end = text.index('    · have dispatchGate', start)
old = text[start:end]
text = text[:start] + '      · ' + old.lstrip()[:0] + '\n'.join('  '+line for line in old.rstrip().splitlines()) + '\n' + '''      · intro extra output member
        have listed : output ∈ SourcePruningEnumerationHookInvocation.foldOutputs folded := by
          simpa only [finish_hook_outputs] using member
        have selectedHistory := histories (prefixFuel + extra) output listed
        have common : preparationFuel + scanFuel + (prefixFuel + extra) =
            prefixFuel + (preparationFuel + scanFuel) + extra := by omega
        rw [common] at selectedHistory
''' + '\n'.join('  '+line for line in history_tail('preparationFuel + scanFuel').rstrip().splitlines()) + '\n' + text[end:]
# Correct the bullet indentation without changing the retained proof.
text = text.replace('      ·         apply resume_depth_stable', '      · apply resume_depth_stable')
start = text.index('      apply resume_depth_stable', text.index('    · have dispatchGate'))
end = text.index('\nend MicroCFTA.', start)
old = text[start:end]
text = text[:start] + '      · ' + '\n'.join('  '+line for line in old.rstrip().splitlines()) + '\n' + '''      · intro extra output member
        have listed : output ∈ SourcePruningEnumerationHookInvocation.foldOutputs folded := by
          simpa only [finish_hook_outputs] using member
        have current := opaqueHistories (prefixFuel + preparationFuel + extra) output listed
        let w := prefixFuel + (preparationFuel + opaqueFuel) + extra
        have common : opaqueFuel + (prefixFuel + preparationFuel + extra) = w := by dsimp [w]; omega
        rw [common] at current
        obtain ⟨fragment, headCaller, headCache, returnedInventory, returnedMemos, callbackSeed, callbackCeiling,
          actualRun, headPost, capturedPacket, completedPacket, admitted, pending, history, callbackHistory⟩ := current
        have preparationAt : SourcePruningEnumerationSelectedPreparation.run w w uv reached after =
            ([.ok ((uv, handle, scs, preparedDecoded), entered.core)], some (.done preparedValue preparedHeap)) := by
          have actual := preparationRun (prefixFuel + opaqueFuel + extra)
          have sameFuel : preparationFuel + (prefixFuel + opaqueFuel + extra) = w := by dsimp [w]; omega
          rw [sameFuel] at actual
          exact actual
        have framed : EnumerationExpandableIndex.frame entered.core after = entered := by
          cases entered with
          | mk core expandable waiting =>
              simp only [EnumerationExpandableIndex.frame] at *
              congr 1
              · exact enteredFlags.symm
              · exact enteredWaiting.symm
        have selectedHistory : SelectedOutputHistoryAt holeKey fits admits graph templates checkEmpty edgesOf stop order
            formulas solver w recursiveFuel inventory reached middleMemos metadata after uv output := by
          refine ⟨fragment, headCaller, headCache, returnedInventory, returnedMemos, callbackSeed, callbackCeiling,
            ?_, ?_, callbackHistory⟩
          · refine ⟨uv, handle, scs, preparedDecoded, preparedValue, preparedHeap, entered.core, preparationAt, ?_⟩
            rw [framed]
            cases preparedValue with
            | node entry rows depth free =>
                have terminal : scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = true := by
                  cases terminal : scs.any (fun sc => EqualityTrie.isTerminal sc.trie) with
                  | false => exact False.elim (ordinaryShape ⟨entry, rows, depth, free, rfl, terminal⟩)
                  | true => rfl
                simpa only [terminal, ↓reduceIte] using actualRun
            | empty | reference _ | union _ _ _ _ | mu _ _ _ _ =>
                split <;> exact actualRun
          · exact ⟨entered, handle, scs, preparedDecoded, preparedValue, preparedHeap, preparationFuel,
              middlePacket, ready, stored, preparationRun, preparationAt, preparedLookup, preparationPost,
              enteredPacket, stable, enteredReady, enteredStored, _enteredCounter, enteredValues,
              enteredFlags, enteredWaiting, preparedAvailable, preparedClosed, preparedLanguage,
              .inr ⟨dispatchGate, actualRun, headPost, capturedPacket, completedPacket, admitted, pending, history⟩⟩
''' + '\n'.join('  '+line for line in history_tail('preparationFuel + opaqueFuel').rstrip().splitlines() if 'let w :=' not in line) + '\n' + text[end:]
text = text.replace('      ·         apply resume_depth_stable', '      · apply resume_depth_stable')
out = area / 'root-drafts/expansion-history/v1'
out.mkdir(parents=True)
target = out / 'SourcePruningEnumerationPreparedFiniteExpansionHistory.lean'
target.write_text(text)
(out / 'status.json').write_text(json.dumps({'status':'untested','source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2)+'\n')
print(target)
