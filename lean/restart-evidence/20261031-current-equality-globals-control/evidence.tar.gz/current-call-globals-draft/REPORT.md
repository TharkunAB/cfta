# Same global memos at actual conjunction-call endpoints

The original current `Context` is sufficient for this local transport. `SourceCurrentConjunctionCallGlobals.call_globals` proves `EndpointMemoGateTrace.Valid` for the SAME complete `memos` at the literal allocated conjunction call's actual reached heap. It covers every actual outcome. There is no supplied future `Valid`, `Context`, heap effect, execution trace, or successful result.

The unchanged canonical V1 has 42 lines, 2,282 bytes, and SHA256 `4987f61863edc5f0abea215269e397005845c48a51acc27d72ce7a7dba48733e`. Root's isolated first strict check passed with an empty raw log. The check used Lean4.34.1, warning-as-error, all linters, measured 4 GiB memory limits, and zero swap. This is a NEXT source-only candidate outside the frozen R21 five-module/684-line checkpoint. No production installation, default Lake build, aggregate Audit, public appendix, documentation, or publication is certified for this candidate here.

This owner ran no Lean, compiler, evaluator, modeled program, Haskell operation, Git, network, or board command. All owner writes are confined to this fresh subtree. Older owners remain unchanged.

## Exact theorem and original gates

The public inputs are the original current call's `p`, `h`, and `budget`, query, caller, complete `EndpointMemoGateTrace.Memos`, current `Context`, resident query availability, and query closure. The actual endpoint is defined by the literal expression:

```lean
SourceCurrentAllocatedConjunctionWorker.call p h budget query before.checked before.fourth
```

The result is:

```lean
EndpointMemoGateTrace.Valid actual.state.native.machine.heap memos
```

`metadata/contract-comparison.json` and the retained gate cuts check equality of the complete original `call_retained` input gates after whitespace removal. They also check the same literal actual-call expression. The result is a separate missing field. There is no claim that this theorem repeats the entire earlier return packet.

## Source-connected derivation

`EndpointMemoGateTrace.Valid` has two fields: unfolding-memo correctness, and paired query-memo validity. The latter contains the descendant and predicate memo families. The theorem transports these same three global families. The current fourth table is a separate object.

The checked `SourceCurrentConjunctionWorkerEffects.allocated_call_effects` derives heap growth and issued-node history extension at the literal actual endpoint. Its original inputs come from `context.ready.semantic.ready.semantic`, `context.ready.semantic.ready.covered`, and the original resident closed query. These effects are produced inside the theorem. They are not caller admissions. The effects proof handles literal warm hits, completed misses, failed decisions, and failed rows. It retains the actual failed heap.

`InternedFreshOrdinaryUnfoldMemo.grows` needs ORIGINAL constructor validity, growth, and issued history. Original validity is derived by:

```lean
context.ready.semantic.ready.semantic.1.normal.facts.coherent.valid
```

The inspected `Facts` and `Coherent` declarations establish these projections. `Coherent.valid` is `InternedConstructorTemplates.Valid` for the original heap. No endpoint constructor-validity premise is added.

Unfolding correctness includes the exact replay equation `unfold input heap = .done output heap`, plus input/output residence and the stored input key. The existing `grows` proof transports residence through actual growth/history and uses the existing `unfold_replay` theorem. Thus this field is not reduced to a numeric or cache-only surrogate.

`SourceEndpointMemo.grows` transports both query tables through the same actual growth/history. Its descendant law retains the exact source answer and grows input residence. Its predicate component uses the checked predicate transport. The SAME original `memos` supplies the previous validity fields throughout.

No completed-run equation, successful receipt, all-future continuation condition, model, or recursive-depth witness is supplied. No runtime definition is added or copied. The new file contains one public theorem.

## Read scope and provider boundaries

Exactly two OLD whole originals were named before acquisition:

- `lean/MicroCFTA/EndpointMemoGateTrace.lean`: 113 lines.
- `lean/MicroCFTA/SourceCurrentAllocatedPartialInvariant.lean`: 89 lines.

Other OLD acquisitions are bounded literal cuts or declaration/transport locators. Their cumulative unions are:

| Original basename | Acquired union / original lines |
| --- | --- |
| SourceEndpointMemoCorrect | 7 / 154 |
| InternedFreshOrdinaryUnfoldMemo | 27 / 94 |
| EndpointMemoGateLift | 45 / 162 |
| SourceCurrentMuEndpointMemos | 5 / 80 |
| SourceEndpointMemo | 33 / 159 |
| SourceRecursiveIntersectionSemanticHeap | 5 / 94 |
| InternedNestedFacts | 12 / 148 |
| InternedRecordCoherence | 12 / 458 |

Every secondary OLD union is strictly below half the original file. OLD scope totals 348 distinct lines across ten original paths. There is no third OLD whole or near-whole acquisition.

All five permitted current sources were copied and read in full: RowsWorkerEffects186, WorkerEffects153, IncomingOldKnownAll150, CallRetained125, and CallSound70. Their total is 684 lines. The current rows path uses its actual equality/projection work and preserves effects for all outcomes. The incoming consumer distinguishes raw native outcomes and actual caller endpoints. The earlier answer theorem concerns the returned fourth memo and does not imply this global-memo result.

The new owned candidate adds 42 lines. Its immutable checked snapshot is byte-identical to the canonical owned draft. The snapshot is recorded as a copy alias of that original authored body. Including this new body, NEW scope is 726 lines across six original bodies. Overall scope is 1,074 lines across sixteen originals. `source-index.json` retains full original paths, metadata hashes, literal cut hashes, and deduplicated line unions. `source-vectors.json` gives the cumulative vectors. Whole-file hashes and line counts identify sources; they do not claim acquisition of unretained source bodies.

The two directly used OLD growth theorems are public. Their complete relevant theorem bodies are retained as cuts. The consulted private `endpoint_lift` helper is retained in full with its module imports, opens, and local notations within the bounded cuts; it was screened and is not used by the candidate. Consulted private helpers in the permitted NEW effects modules are retained in those whole files. Other locator-only files are recorded as screened providers. There is no claim to have independently reread every transitive public library proof.

The separate Root135 equality candidate was not acquired or used. No earlier frozen owner's bodies were recopied. A filename-only memo inventory search read no additional proof body.

## Exact check and input provenance

The complete actual Root receipt is retained under `metadata/check/`: report, command, seven-input hash index, and empty raw log. `checked/SourceCurrentConjunctionCallGlobals.lean` is the immutable run source. The report's source hash equals the unchanged canonical V1 hash. The seven input records are the five checked baseline modules, Audit metadata, and this candidate. Audit is hash metadata only; its body was not acquired. This owner does not describe seven reviewed source bodies as the input scope.

The earlier five-module strict input metadata was copied before acquisition to verify the five baseline hashes. `metadata/input-origins.json` records exact original metadata/snapshot paths and retained-copy hashes. No evolving owner index was used. Root retains the broader compiler import and stage packaging closure. This owner retains the complete inputs it actually consulted, its whole/cut source record, and its exact local check evidence.

One metadata acquisition probe failed before the new-source index was saved. A manually copied WorkerEffects digest had `e` instead of `a` at digest character index53. The literal probe, failure output, and compared digests are retained. The acquisition was repeated using the copied actual strict-input metadata. All five baseline hashes then matched. The initial Rows copy and the final Rows copy have the same bytes. No source modification or semantic failure followed from this incident. This was a Python metadata assertion, not a Lean or modeled execution. The candidate's one Root strict attempt passed on its first check.

## Remaining full objective

This result derives only the original global-memo field at the actual conjunction-call heap. It does not derive probe-heap `Clean`, the whole reached `Ready`, or the complete returned `Context`. It does not replace returned-fourth correctness, which was proved separately. Higher wrappers that actually change global query memos still need their own exact update facts.

The fixed-original-D execution and continuation induction remains open for BOTH original and prepared workers. Generic Mu/Union routes, terminal/alias/renewal progress, SAME captured cache at the actual post-hook caller and queries, Prepared inner failure heap versus outer endpoint `None`, original resource sufficiency, global accepted-output coverage, public order, generic/default/Map/signed scope, and Haskell correspondence remain open. Heap growth here transports memo correctness; it supplies no descending worker rank or termination proof. No Haskell defect is asserted. The full goal remains active.

## Replay and freeze

The portable `verify.py` reads retained copies only. It checks literal overlaps, cumulative original-path unions, the exact two OLD whole paths, strict half-file limits, baseline hashes against copied input metadata, unchanged checked candidate bytes, exact original gates/call expression, the actual Root strict log and caps, and metadata origins. The final manifest covers every payload. Exact set equality excludes only the three owner top-level control files. Nested files named MANIFEST or PINS remain payloads. The owner stops all subtree writes after the immutable seal is made.
