from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
R=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
origin=Path('/tmp/mcfta-current-call-control-20261031/SourceCurrentConjunctionCallSound-strict-v2/inputs.json')
raw=origin.read_bytes();(P/'metadata/current-5-inputs.json').write_bytes(raw)
entries=json.loads(raw);index=json.loads((P/'source-index.json').read_text())
for row in entries:
 if row['module']=='Audit':continue
 src=R/(row['module']+'.lean');data=src.read_bytes();actual=hashlib.sha256(data).hexdigest();assert actual==row['sha256'],(row['module'],row['sha256'],actual)
 dst=P/'sources'/src.name;dst.write_bytes(data);index['sources'].append({'source':str(src),'classification':'NEW checked whole','source_lines':len(data.splitlines()),'source_bytes':len(data),'source_sha256':actual,'whole':{'path':str(dst.relative_to(P)),'bytes':len(data),'sha256':actual},'reviewed_union_lines':list(range(1,len(data.splitlines())+1))})
(P/'source-index.json').write_text(json.dumps(index,indent=2)+'\n')
(P/'metadata/input-origins.json').write_text(json.dumps({'records':[{'source':str(origin),'copy':'metadata/current-5-inputs.json','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'scope':'WHOLE immutable check input metadata; no old proof bodies'}]},indent=2)+'\n')
