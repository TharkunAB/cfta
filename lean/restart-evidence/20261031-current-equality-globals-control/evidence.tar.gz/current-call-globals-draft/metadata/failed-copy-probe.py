# Historical failed acquisition probe. Do not replay after the owner is sealed.
from pathlib import Path
import json,hashlib
p=Path('/tmp/mcfta-current-call-globals-review-20261031');repo=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA');index=json.loads((p/'source-index.json').read_text());expected={'SourceCurrentConjunctionRowsWorkerEffects':'07484734d32544d0ea70b60c2da5816d75099377c37d0be7d0362a5aefda599f','SourceCurrentConjunctionWorkerEffects':'eb57fa22e9a5302218be456a748e13d8b87700c59c389cace06e6e2467c59153','SourceCurrentAllocatedNativeIncomingOldKnownAll':'10abcfe5160728172383e5b44cb4259fe634b82d6e0fc89163c50f3f92ff0ca4','SourceCurrentConjunctionCallRetained':'3529605c6b52b1456b3d53d75433598809a4a4ade5c83bec41ffd271f8ae2e11','SourceCurrentConjunctionCallSound':'6a7102e317ab8d9d223f31fcf1f14b1652d5edc1182994010594e2844bc592b9'}
for name,sha in expected.items():
 src=repo/(name+'.lean');data=src.read_bytes();assert hashlib.sha256(data).hexdigest()==sha;dst=p/'sources'/(name+'.lean');dst.write_bytes(data);index['sources'].append({'source':str(src),'classification':'NEW checked whole','source_lines':len(data.splitlines()),'source_bytes':len(data),'source_sha256':sha,'whole':{'path':str(dst.relative_to(p)),'bytes':len(data),'sha256':sha},'reviewed_union_lines':list(range(1,len(data.splitlines())+1))})
(p/'source-index.json').write_text(json.dumps(index,indent=2)+'\n')
