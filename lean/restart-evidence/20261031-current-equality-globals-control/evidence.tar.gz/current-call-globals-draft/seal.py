"""Seal this exact owner tree once. Keep every nested metadata file."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent
assert not (P/'FROZEN.json').exists()
CONTROLS={Path('MANIFEST.json'),Path('PINS.json'),Path('FROZEN.json')}
def record(path):
 data=path.read_bytes();return {'path':str(path.relative_to(P)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
subprocess.run([sys.executable,str(P/'verify.py')],check=True)
files=sorted(q for q in P.rglob('*') if q.is_file() and q.relative_to(P) not in CONTROLS)
manifest={'scope':'Exact complete fresh owner tree; exclude only its three top-level controls. All nested metadata remains a payload.','payload_count':len(files),'payloads':[record(q) for q in files]}
(P/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
pins={'manifest':record(P/'MANIFEST.json'),'payload_count':len(files),'exact_file_count':len(files)+3}
(P/'PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
seal={'status':'FROZEN_WRITE_HALT','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':'/root/arity_meaning','manifest':record(P/'MANIFEST.json'),'pins':record(P/'PINS.json'),'payload_count':len(files),'exact_file_count':len(files)+3,'candidate_sha256':'4987f61863edc5f0abea215269e397005845c48a51acc27d72ce7a7dba48733e','root_isolated_strict':'PASS_FIRST_ATTEMPT_ZERO_DIAGNOSTICS','production_or_R21_integration_claimed':False,'owner_compiler_evaluator_commands':0}
(P/'FROZEN.json').write_text(json.dumps(seal,indent=2)+'\n')
subprocess.run([sys.executable,str(P/'verify.py')],check=True)
for q in P.rglob('*'):
 if q.is_file():q.chmod(0o444)
for q in sorted((q for q in P.rglob('*') if q.is_dir()),key=lambda q:len(q.parts),reverse=True):q.chmod(0o555)
P.chmod(0o555)
for name in ['REPORT.md','MANIFEST.json','PINS.json','FROZEN.json']:print(json.dumps(record(P/name)))
print(json.dumps({'payload_count':len(files),'exact_file_count':len(files)+3,'status':'WRITE HALT'}))
