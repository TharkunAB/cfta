#!/usr/bin/env python3
"""Verify retained metadata, literal source cuts, and the exact owner tree only."""
from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
CONTROLS={Path('MANIFEST.json'),Path('PINS.json'),Path('FROZEN.json')}
def sha(data):return hashlib.sha256(data).hexdigest()
def checked(row,key='path'):
 relative=Path(row[key]);assert not relative.is_absolute() and '..' not in relative.parts
 data=(P/relative).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'],relative
 return data
index=json.loads((P/'source-index.json').read_text());seen=set();totals={'OLD':0,'NEW':0};wholes=[];bodies={}
for row in index['sources']:
 assert row['source'] not in seen;seen.add(row['source']);kind=row['classification'].split()[0]
 if 'whole' in row:
  data=checked(row['whole']);assert len(data)==row['source_bytes'] and sha(data)==row['source_sha256'] and len(data.splitlines())==row['source_lines']
  union=set(range(1,row['source_lines']+1));bodies[Path(row['source']).stem]=data
  if kind=='OLD':wholes.append(Path(row['source']).name)
 else:
  recovered={}
  for cut in row['cuts']:
   data=checked(cut);lines=data.splitlines(keepends=True)
   if cut.get('numbered'):
    numbered=[(int(line.split(b':',1)[0]),line.split(b':',1)[1]) for line in lines]
    assert [n for n,_ in numbered]==cut['actual_lines']
   else:
    ns=list(range(cut['first_line'],cut['last_line']+1));assert len(ns)==len(lines);numbered=list(zip(ns,lines))
   for number,literal in numbered:
    assert 1<=number<=row['source_lines']
    if number in recovered:assert recovered[number]==literal
    recovered[number]=literal
  union=set(recovered);assert 2*len(union)<row['source_lines'],row['source']
 assert sorted(union)==row['reviewed_union_lines'];totals[kind]+=len(union)
assert sorted(wholes)==['EndpointMemoGateTrace.lean','SourceCurrentAllocatedPartialInvariant.lean']
assert totals=={'OLD':348,'NEW':726} and len(seen)==16
origins=json.loads((P/'metadata/input-origins.json').read_text())
for row in origins['records']:checked(row,'copy')
base=json.loads((P/'metadata/current-5-inputs.json').read_text());assert len(base)==6
for row in base:
 if row['module']!='Audit':assert sha(bodies[row['module']])==row['sha256']
candidate=(P/'drafts/v1/SourceCurrentConjunctionCallGlobals.lean').read_bytes();snapshot=(P/'checked/SourceCurrentConjunctionCallGlobals.lean').read_bytes()
assert candidate==snapshot and sha(candidate)=='4987f61863edc5f0abea215269e397005845c48a51acc27d72ce7a7dba48733e'
assert len(candidate.splitlines())==42
report=json.loads((P/'metadata/check/report.json').read_text());raw=(P/'metadata/check/raw.log').read_bytes()
assert report['exit_code']==0 and report['bytes']==0 and len(raw)==0 and sha(raw)==report['sha256']
assert report['source_sha256']==sha(candidate) and report['caps_verified_before_command']
for key in ['cgroup_limits_before','cgroup_limits']:
 assert report[key]=={'memory.max':'4294967296','memory.high':'4294967296','memory.swap.max':'0'}
assert '-DwarningAsError=true' in report['command'] and '-Dlinter.all=true' in report['command']
inputs=json.loads((P/'metadata/check/inputs.json').read_text());assert len(inputs)==7
for row in inputs:
 if row['module']!='Audit':assert sha(bodies[row['module']])==row['sha256']
norm=lambda data:b''.join(data.split())
assert norm((P/'metadata/contracts/old-gates.txt').read_bytes())==norm((P/'metadata/contracts/new-gates.txt').read_bytes())
old=bodies['SourceCurrentConjunctionCallRetained'].split(b'theorem call_retained ',1)[1].split(b'let actual :=',1)[1].split(b'\n',1)[0]
new=candidate.split(b'theorem call_globals ',1)[1].split(b'let actual :=',1)[1].split(b'\n',1)[0];assert old==new
incident=json.loads((P/'metadata/acquisition-incident.json').read_text());a=incident['expected_worker_digest_transcribed'];b=incident['actual_worker_digest_verified_against_Root_strict_inputs'];assert [(i,x,y) for i,(x,y) in enumerate(zip(a,b)) if x!=y]==[(53,'e','a')]
print('PASS scopes: two OLD wholes; OLD348/10 originals; NEW726/6 originals; checked immutable42; strict0diagnostics; seven input records')
if (P/'MANIFEST.json').exists():
 manifest=json.loads((P/'MANIFEST.json').read_text());expected=set()
 for row in manifest['payloads']:
  checked(row);assert row['path'] not in expected;expected.add(row['path'])
 actual={str(q.relative_to(P)) for q in P.rglob('*') if q.is_file() and q.relative_to(P) not in CONTROLS}
 assert actual==expected,{'missing':sorted(expected-actual),'extra':sorted(actual-expected)}
 assert manifest['payload_count']==len(expected)
 pins=json.loads((P/'PINS.json').read_text());checked(pins['manifest'])
 seal=json.loads((P/'FROZEN.json').read_text());checked(seal['pins']);checked(seal['manifest'])
 assert seal['payload_count']==len(expected) and seal['exact_file_count']==len(expected)+3
 assert len([q for q in P.rglob('*') if q.is_file()])==len(expected)+3
 print(f'PASS exact full tree: {len(expected)} payloads; {len(expected)+3} files; nested control basenames retained')
