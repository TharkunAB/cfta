theorem grows [DecidableEq (EdgeKey Symbol Guard)] (before after : State Symbol Guard)
    (valid : Valid before) (growth : Grows before after)
    (history : Extends before.nodes.issued after.nodes.issued) (memo : Memo Symbol Guard)
    (correct : Correct before memo) : Correct after memo := by
  intro key input output found
  obtain ⟨identity, inputAvailable, outputAvailable, actual⟩ := correct key input output found
  exact ⟨identity, inputAvailable.grows before after growth history, outputAvailable.grows before after growth history,
    InternedFreshOrdinaryStoredSubstitution.unfold_replay input before after output before valid actual growth⟩

