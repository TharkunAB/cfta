namespace MicroCFTA.InternedFreshOrdinaryUnfoldMemo
open Cache InternedConstructorTemplates InternedRecordCoherence InternedProbeProvenance
open InternedNestedConstruction (Outcome)
open InternedFreshOrdinaryGateRank (Node step)
open InternedBinderProtocol (NodeRef)

/-- The source memo keeps each queried record and its complete unfolding result. -/
