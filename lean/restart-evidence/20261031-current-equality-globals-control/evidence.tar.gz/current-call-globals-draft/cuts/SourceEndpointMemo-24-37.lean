def Correct (heap : State Symbol Guard) (memo : Memo) : Prop :=
  ∀ key input answer, memo key = some (input, answer) → input.referenceOf = key ∧
    Available heap input ∧ answer = SourceEndpointReachability.reaches SourceMemoGate.unconstrained input

/-- A descendant traversal carries its own memo and the separate constraint-predicate memo. -/
structure Memos where
  descendants : Memo
  predicate : SourceUnconstrainedMemo.Memo

/-- Both memo families retain complete resident inputs and exact answers. -/
structure Valid (heap : State Symbol Guard) (memos : Memos) : Prop where
  descendants : Correct heap memos.descendants
  predicate : SourceUnconstrainedMemo.Correct heap memos.predicate

