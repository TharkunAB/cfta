def Correct [DecidableEq (EdgeKey Symbol Guard)] (state : State Symbol Guard) (memo : Memo Symbol Guard) : Prop :=
  ∀ key input output, memo key = some (input, output) → input.referenceOf = key ∧
    Available state input ∧ Available state output ∧
    InternedFreshOrdinaryStoredSubstitution.unfold input state = .done output state

