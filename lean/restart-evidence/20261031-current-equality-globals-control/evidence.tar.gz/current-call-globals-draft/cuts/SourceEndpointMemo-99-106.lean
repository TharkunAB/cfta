theorem grows (before after : State Symbol Guard) (growth : Grows before after)
    (history : Extends before.nodes.issued after.nodes.issued) (memos : Memos) (valid : Valid before memos) :
    Valid after memos := by
  refine ⟨?_, SourceUnconstrainedMemo.grows before after growth history memos.predicate valid.predicate⟩
  intro key input answer found
  obtain ⟨identity, available, actual⟩ := valid.descendants key input answer found
  exact ⟨identity, available.grows before after growth history, actual⟩

