def SemanticHeap (state : State Symbol Guard) : Prop :=
  Context state [] ∧ InternedFreshOrdinaryDepthHeap.Heap state

/-- Empty source caches satisfy every semantic heap invariant. -/
