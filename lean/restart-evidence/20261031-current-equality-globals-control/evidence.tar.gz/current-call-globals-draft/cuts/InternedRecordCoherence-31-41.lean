structure Coherent (state : InternedConstructorTemplates.State Symbol Guard) : Prop where
  valid : InternedConstructorTemplates.Valid state
  edges : ∀ key value, state.edgeRecords key = some value →
    state.edges.table key = some value.entry ∧ EdgeFields key value
  nodes : ∀ key value, state.nodeRecords key = some value →
    ∃ entry, state.nodes.table key = some entry ∧ NodeFields key entry value

/-- Every completed identity request has a payload. Listed Mu keys may still be pending. -/
structure Covered (pending : List NodeKey) (state : InternedConstructorTemplates.State Symbol Guard) : Prop where
  edges : ∀ key entry, state.edges.table key = some entry → ∃ value, state.edgeRecords key = some value
  nodes : ∀ key entry, state.nodes.table key = some entry →
