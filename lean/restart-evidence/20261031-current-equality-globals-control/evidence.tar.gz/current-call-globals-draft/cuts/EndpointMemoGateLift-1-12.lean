import MicroCFTA.EndpointMemoGateTrace

/-!
# Coherent completed memo calls through current gate traces

Every current pure trace receives actual calls of all three memo families.
Current heap coherence derives each hit or miss. Constructor growth retains
the query tables before each later child. No future memo validity is assumed.
-/
namespace MicroCFTA.EndpointMemoGateTrace
open Cache InternedConstructorTemplates InternedRecordCoherence InternedProbeProvenance
open InternedNestedConstruction (Outcome)
