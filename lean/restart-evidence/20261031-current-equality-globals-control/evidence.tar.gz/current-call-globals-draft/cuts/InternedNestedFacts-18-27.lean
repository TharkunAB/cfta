structure Facts (state : State Symbol Guard) : Prop where
  coherent : Coherent state
  cached : Cached state
  linked : Linked state

/-- The source starts with all record invariants established. -/
theorem empty_facts : Facts (empty (Symbol := Symbol) (Guard := Guard)) :=
  ⟨empty_correct.1, empty_cached, empty_linked⟩

/-- Both outcomes preserve actual state histories. A completed result also
