open SourceObservations SourceSymbolicIndex EqualityNormalize
open InternedFreshOrdinaryMemoGateTrace (Ready node_ready)

local notation "Symbol" => Label FullSyntax.Formula
local notation "Guard" => Constraint FullSyntax.Formula
local notation "source" => SourceMemoGate.unconstrained
local notation "reaches" => SourceEndpointReachability.reaches source

/-- An open endpoint skips the helper; a closed endpoint retains its actual paired memo result. -/
private theorem endpoint_lift [DecidableEq (EdgeKey Symbol Guard)]
    {free : List InternedBinderProtocol.Reference} (slow : (depth == 0 && free.isEmpty) = false)
    (state : State Symbol Guard) (ready : Ready state)
    (available : Available state (.node entry edges depth free)) (memos : Memos) (valid : Valid state memos) :
    ∃ saved, NodeReads (EndpointStatefulGateTrace.NodeTrace.endpoint slow :
      EndpointStatefulGateTrace.NodeTrace source reaches [] (.node entry edges depth free) state
        (!free.isEmpty || reaches (.node entry edges depth free)) state) memos saved ∧
      Keeps state state saved := by
  by_cases closed : free.isEmpty = true
  · have checked := SourceEndpointMemoCorrect.run_checked _ _ ready.1.normal.facts.coherent available memos.query valid.query
    have actual : SourceEndpointMemo.run _ memos.query =
        (reaches (.node entry edges depth free), (SourceEndpointMemo.run _ memos.query).2) :=
      Prod.ext checked.answer rfl
    exact ⟨_, .endpoint_closed slow closed actual,
      pure_keeps _ _ ready ⟨valid.unfolding, checked.valid⟩⟩
  · exact ⟨memos, .endpoint_open slow (Bool.eq_false_iff.mpr closed), pure_keeps _ _ ready valid⟩

