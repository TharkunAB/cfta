# Exact return observer scope

REPORT.md uses the existing source comment's phrase "returns the original right root".
The literal `native_returned` theorem observes only `NodeRef`:
`returned = some (.mu 26)` at native fuel100.
It does not itself state payload equality with `operands.2` or equality of caches.
Use that exact reference observation when citing this result. No payload equality
is claimed by this audit. The completed execution still excludes interpreting
this witness as a demonstrated infinite execution.

The original report and FILES-v1 remain unchanged. This clarification is additive.
