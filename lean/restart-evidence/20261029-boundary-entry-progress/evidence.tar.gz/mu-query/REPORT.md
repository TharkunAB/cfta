# Native query closure of the original Mu body-degree ceiling

Status: bounded source-only audit, complete. NO new theorem or proof candidate.
Root owns compilation, evaluation, repository edits, Git, native checks,
network and board work. Parent reports starting checkpoint70ff91ffce.
This child did not query Git or execute any source/native evaluator.

## Result

The existing source proves exact native optional-binder compilation and
preservation of semantic and body/probe heap facts. It does not yet derive
the SAME ORIGINAL Mu body-degree ceiling through a whole native query.
No actual native counterexample to that ceiling was established here.

The smallest unresolved step is the degree of the GENERATED body returned
by the actual recursive node request, before optional-binder construction.
Do not insert that degree bound as a future-body premise of the global
producer. It must follow from original operand/domain descriptors and the
actual native trace, or a different original rank must replace it.

## Exact runtime attachment

SourceRecursiveIntersectionCompile.compileMu first enters the actual
extended domain. It then issues .node with the two source body values.
Its continuation receives a newly returned value and constructs
.optionalBinder (pair first second) value .pure. The optional binder's
body is therefore a generated recursive result. It is not identified with
the body of either original Mu operand.

SourceRecursiveIntersectionNative.step.optionalBinder invokes actual
SourceRecursiveIntersectionMaybeMu.maybeMu. Source effects, reached caller
and continuation are literal. The actual compiled ordinary work adds no Mu:
OrdinaryWork, compileMu_ordinaryWork and compileNode_ordinaryWork establish
this fact through all compiler continuations. The remaining allocation rule
is the explicit optionalBinder instruction, including its repaired probes.

## Available constructive source route and the exact missing inequality

SourceRecursiveIntersectionMaybeMu.maybeMu_eq identifies the complete actual
operation, including pending outcomes, with the repaired source expression:

  .binder true (encode (leaves body) [intersectionPairReference] body)

when the pair reference remains free. Otherwise it returns the input body
and unchanged state. Original Facts and Available body suffice for this
exact compilation; no future cache or language interpretation is supplied.

InternedStoredPlanBinderDepth.encode_depth states that the encoded plan has
degree valueDepth body. InternedStoredLeafShape.leaves_shape makes each
captured input a closed value or a literal reference. Each has degree zero.
Consequently the existing build_new_lower proof route gives, with original
SemanticHeap and body/probe Heap at this point, the source-derived statement:

  Lower before (1 + valueDepth body) (maybeMu pair body before).state

This line is a proof-route consequence of the read source declarations,
not a new compiled public theorem from this audit. SemanticHeap.context
supplies the lexical context from Available body. The existing build_new_lower
handles every probe and completed/pending cache. An unused pair uses lower_refl.

The consequence for every newly completed Mu body is degree <= valueDepth body.
Thus original Bounded before limit plus valueDepth body < limit is sufficient
to preserve the SAME limit at this point. New records use that inequality;
old records use the original Bounded fact. Requiring 1+valueDepth body<limit
would be unnecessarily strong. The generic bounded_after lemma has that
stronger strict-rank gate, so direct old/new cases avoid this off-by-one.

The missing inequality is not supplied by the definition of Bounded itself.
Bounded constrains RESIDENT MU BODY degree. For an open resident Mu,
valueDepth of the entire Mu is one plus its body's degree. A structural
availability argument would therefore give at most valueDepth value <= limit;
it does not automatically give the strict callback-body inequality above.
Actual compiled callback provenance must supply the missing strictness, or
justify an original larger rank. No equality between an original stored body
and the generated callback body was assumed.

## Existing admitted obstruction to the first-order shortcut

The WHOLE SourceRecursiveIntersectionOpenBodyBoundary is preserved here:
212 lines, 12,005 bytes, SHA256
81985a5d4cfaa355c4b81ae3b644fcef36acecc90a08db091d795a54ed970d38.
It is existing source, not a new attempted counterexample. Complete exported
source headers are retained in public-signatures-v1.json.

Two repaired Syntax Nat Nat source builds start from empty caches. Their
closed Original roots have Facts, Available, Covered [], repaired Context,
valid initial native memos and checked 64-bit root words. The source counter
is32. Actual native execution takes22 steps to an optionalBinder body for
pair(10,26). That body retains the outer pair reference and contains an open
nested Mu. reaches_unprepared derives the actual Steps witness and
not_all_closed_original_prepared refutes universal PreparedWithoutMu at
those actual callback sites under its exact original premises.

The same native request returns the original right root at bounded fuel100,
as proved by native_returned. This is a counterexample to first-order
preparation preservation, not to native termination, not to this degree
ceiling, and not to the whole prepared Packet contract. It does not justify
adding PreparedWithoutMu to global admission. The existing FINDINGS cut
25360-25405 already records this exact invariant boundary and kernel-reduction
provenance. No new execution or validation is claimed.

Longer ordinary node chains or unary period/LCM examples are also insufficient
to refute this measure: node paths add no binder nesting. No such example is
reported as a new admitted obstruction.

## Other existing theorems do not close the gap

OpenDepthEffects.optionalBinder and Native.Bounds.open_depth_heaps preserve
SemanticHeap plus InternedOpenDepthReadback.Heap. The latter Heap equates
actual body and Depth-probe degree. It does not bound either degree by an
original number. These actual source preservation results remain useful
premises for the build_new_lower route above.

CompileMuBounds.mu_request_below and compileMu_below give actual request
requiredFuel descent only with an input Completes(view source holds)
(nodeSemantic request) proof. They do not derive the new Mu body ceiling
from initial Bounded. Do not use this conditional termination premise as an
original-source global closure result.

## Next concrete proof target and remaining cardinality scope

At an actual native Steps prefix from an original checked root request to
.optionalBinder pair generatedBody next, derive a bound on generatedBody's
plan degree from the ORIGINAL operand/domain graph. Try the same ceiling
only if the actual provenance proves it. Otherwise compute a justified
original rank over those descriptors. Then compose that allocation lemma
with the existing ordinary-work/no-new-Mu and native evaluation inductions.
The native recursive body must establish this result; a callback supplier
that simply assumes the desired body bound would leave the gap unchanged.

Even a successful whole-query ceiling theorem would not establish a finite
physical handle carrier. Bounded counts binder nesting, not the number of
Mu/Union records at a degree. Actual optional-binder keys depend on the
Depth and ordinary probes and their generated physical values. Native edge
compilation also accepts arbitrary conjoin : Guard -> Guard -> Guard and
emits its computed constraints. No finite original closure of those generated
keys or guard expressions follows merely from a Mu degree ceiling.

A bound for ONE query rooted in its fixed original operand graph is distinct
from a bound for later queries whose operands are previously generated roots.
Original descriptor closure across those queries remains necessary. No
per-current-heap inventory, per-supplied-depth roomBits bound, future handle
membership, future model or future Bounded assumption replaces that task.
No global finiteness, global depth, output coverage or Haskell correspondence
claim follows from this audit.

## Evidence and Haskell

Twelve Lean sources and one prior report were read WHOLE:126,017 bytes and
1,981 lines. Six literal cuts contain23,192 bytes and382 lines. Source and
cut identities are retained in manifest-v1.json. Nineteen complete existing
source theorem headers are retained separately. These are source headers;
no fresh compiler print or validation ran.

The first discovery batch was truncated. It was not used for whole-source
claims. Every file recorded WHOLE was read again in an untruncated call.
Partially read files have explicit literal cuts. The earlier areas were
read only. No previous evidence was overwritten.

No Haskell change, new defect or fix was found. The relevant existing
counterexample concerns a proof invariant and is already in FINDINGS.
There is no new Haskell fix for root to record from this task.

All evidence is frozen after final source/copy identity verification.
