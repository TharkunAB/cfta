# Actual selected preparation retains an original Mu degree ceiling

Status: bounded source-only candidate, UNTESTED. Root owns all compilation,
evaluation, repository changes, Git, network, native checks and board work.
Parent-reported starting HEAD: 73b3f496ea0eb4ddfb0b784cf4ae1393d4325cfa.
No Git command verified that value in this child task.

## Delivered local theorem

File: candidate-v1/MicroCFTA/SourcePruningEnumerationSelectedValueMuDepth.lean.
The immutable v1 has 69 lines and 3,783 bytes. SHA256:
b14b555fe37beea917be6afae57240d6761322c113bc03fa3e75a3faa98e5287.

`MicroCFTA.SourcePruningEnumerationSelectedValue.run_mu_bounded` takes:

- An original limit, actual fuel, original value and original source state.
- Original SemanticReady, Available and closed value facts.
- Original InternedMuDepthInventory.Bounded before limit.
- The literal selected operation result run fuel value before = .done result after.

It concludes Bounded after limit, with the SAME original limit. It does not
recompute a maximum from the result state. It does not assume Lower, a future
record inventory, future membership, a model or a future heap bound.

Bounded means that every complete Mu record has a body-plan degree below the
limit. It uses InternedStoredPlanBinderDepth.valueDepth on the stored body.
This measure differs from Value.depth, the cached depth of the physical value.
The original startup bound can come from InternedMuDepthInventory.initial_bounded.
This theorem alone does not attach the local original bound to a full Packet.

## Proof route

The empty, reference and node branches retain the source state. The actual
Mu branch derives InternedStoredPlanBinderDepthProgress.unfold_new_lower
from the original semantic/depth/availability/closedness facts. This is a
source-derived Lower result, not a caller-supplied future invariant. The
original resident Mu provides its original body degree bound. bounded_after
then retains the original limit through the actual unfold result. A pending
unfold cannot equal the supplied literal completed observation.

The explicit Union branch uses the actual nodeEdges operation and its
nodeEdges_progress theorem. The original limit survives that exposure.
The final makeNode adds no Mu, so every final Mu was resident in the exposure
state. The literal completed result identifies the exact returned state.
Unresolved, pending and exhausted exposure cannot equal that completed result.

No source/prepared identity cast occurs. The theorem is at the actual local
SelectedValue operation. It does not assert complete selected receipt,
whole recursive producer, output coverage or Haskell correspondence.

## Existing constructive progress, retained rather than duplicated

InternedFreshMuUnfoldBudget.unfold_progress already derives the actual
successful closed unfold's progress without a supplied Lower hypothesis.
MergedFreshOrdinaryColdBudget.nodeEdges_progress already retains the
original heap invariant and SAME Bounded limit through actual completed
closed exposure. Its declaration and proof were read whole.

Their progress relation permits strict decrease in the unfinished Mu degree
vector OR exact source heap equality. The Union's final ordinary makeNode
can allocate a node. Therefore that exact strict-or-full-heap-equality
statement does not follow for the whole SelectedValue branch merely by
applying the exposure theorem. The delivered theorem claims the preserved
bound only. No stronger progress result is concealed in its public scope.

## Exact old source witness and checked provenance

The complete 142-line, 7,052-byte SourceColdUnfoldNewMuBoundary source is
retained in inputs-v1/whole. Its SHA256 is
8fa6db83d05581d6a2274e4c8e502ef9d094d5427bafaca6b3fc2a77f83979b4.
All ten exact source theorem headers, together with the new header, are
retained in public-signatures-v1.json. These are source headers, not fresh
kernel printouts. The whole file retains all definitions and local context.

The witness builds Syntax Nat Unit for mu x. mu y. f(x,y) from empty caches
with the repaired source constructor. The actual root and its actual state
are retained. The actual successful closed unfolding is also retained.
source_verified and final_verified establish SemanticHeap, Covered [],
Available and closedness at the corresponding endpoints. new_mu states
that the returned Mu record was absent in the original source and resident
in the actual final state. not_noNewMu proves the negation of NoNewMu.
observed proves cached depth 2 to 3 and node counter 13 to 17. read_finishes
proves that the actual repaired reader returns one edge with counter 18.

This is a counterexample to the complete initial Mu-record inventory and to
decreasing cached depth as general measures. It does not refute every finite
structural carrier. It is not a whole prepared Packet execution, an infinite
run, a Haskell defect or a termination counterexample.

Provenance is explicit. The current Audit source imports this file at line1105.
The complete old notes-native-output-cold-effects.md attributes the witness
to 0534aad8. It records an aggregate Lean4.34.1 check of 1,417 jobs and 43,451
theorem dependency checks at the documented historical checkpoint0258ae86.
FINDINGS25465-25525 also records the exact measure boundary. The old theorem
source contains kernel cbv proofs and its existing local evaluation options.
These options were copied as historical evidence; the new candidate adds none.

The historical /tmp/mcfta-guarded-input-native-soundness-20261014-audit.log and
/tmp/mcfta-cold-measure-native-20261014.log are absent on this host. The note's
historical validation is reported as historical provenance, not independently
reexecuted or recovered raw evidence. Root owns current checking.

## Remaining handle-factor obligation

The new local lemma preserves an original Mu body-plan degree ceiling through
actual completed preparation. A degree ceiling does not bound the number of
fresh lower-degree Mu or Union identities. It does not produce a finite
original carrier of physical handles. It does not justify roomBits uniformly
across unknown later depth.

The next semantic step must examine the actual native intersection/conjunction
or query allocation trace. It must derive an original-descriptor bound on
each new recursive binder's open body plan, or derive the correct alternative
rank from its original operands and domain. Whether the SAME ceiling survives
that separate operation is not proved here. It must not be assumed. Even such
a ceiling would still leave cardinality and ordered global recursive progress
open. No future handle membership, Lower, support or global depth oracle was
introduced by the candidate or recommended as an input contract.

## Haskell and integration

No Haskell source changed. No new Haskell defect or fix was discovered. The
old source note reports a historical Haskell reproduction of the same two
rejected measures. It is not a new test result from this task. Root needs no
new Haskell fix entry in FINDINGS for this bounded result.

The new module is additive. Every old repository source remains unchanged.
The candidate remains UNTESTED until root reports compilation. All source
copies, literal cuts and hashes are listed in manifest-v1.json. The nine Lean
whole files plus two whole context documents total 94,942 bytes and 1,481
lines. Seven literal cuts total 25,729 bytes and 453 lines. Search results were
used only to find source. No theorem claim relies on a truncated read.

This report and v1 evidence are frozen after final identity verification.
