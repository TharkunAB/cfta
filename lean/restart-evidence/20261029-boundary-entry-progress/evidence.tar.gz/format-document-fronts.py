"""Correct spacing in the new text without changing inherited document bodies."""
from pathlib import Path
import hashlib,json,re
p=Path('/tmp/mcfta-boundary-entry-progress-20261029');root=Path('/home/tritlo/Code/mcfta');prior={r['path']:r for r in json.loads((p/'prior-documents.json').read_text())};rows=[]
replace={'at4GiB':'at 4 GiB','measured4GiB':'measured 4 GiB','Lean4.34.1':'Lean 4.34.1','actual22-step':'actual 22-step','checked64-bit':'checked 64-bit','fuel100':'fuel 100','NodeRef.mu26':'NodeRef.mu 26','some(.mu26)':'some (.mu 26)','Lower before(1+valueDepth body)':'Lower before (1 + valueDepth body)','encode(leaves body)[pairReference]body':'encode (leaves body) [pairReference] body','pure()':'pure ()','modules:580':'modules: 580','bytes;seven':'bytes; seven','theorems;no':'theorems; no','commands have14':'commands have 14','and85':'and 85','is0':'is 0','and67':'and 67','verify95':'verify 95','Board716':'Board 716','SHA2565fbe':'SHA256 5fbe','mems;swap':'mems; swap','counter history':'counter history'}
for row in json.loads((p/'final-documents.json').read_text()):
 file=root/row['path'];raw=file.read_bytes();old=(p/'prior-document-bodies'/row['path']).read_bytes()if row['path']in prior else b'';assert raw.endswith(old);front=raw[:-len(old)]if old else raw;text=front.decode();text=re.sub(r'(?<=[A-Za-z])(?=\d{1,3},\d{3})',' ',text)
 for first,second in replace.items():text=text.replace(first,second)
 raw=text.encode()+old;file.write_bytes(raw);(p/'final-document-bodies'/row['path']).write_bytes(raw);rows.append(dict(path=row['path'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
(p/'final-documents.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(dict(documents=len(rows),old_suffixes=len(prior))))
