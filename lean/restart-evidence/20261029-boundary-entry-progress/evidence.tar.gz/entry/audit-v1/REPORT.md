# Actual Entry boundary budget: bounded source report

Status: candidate v2 is UNTESTED. The parent owns compilation and repository writes.
The parent reports checkpoint 70ff91ffce pushed. No child Git call was made.

## Exact result

The candidate adds `SourcePruningEnumerationBoundaryEntryBudget.lean` with two public theorems.
Version v2 has 143 lines and 8,601 bytes.
Its SHA256 is ab837ea02325507aef32a8a8e697658f7020b6d8ee83f2f1d59237d86852540b.
Version v1 is preserved. Version v2 makes the tuple-result equalities explicit instead of relying on local variable names after rfl substitutions.
Neither version was compiled here.

`SourcePruningEnumerationEntry.enter_history` takes original representative Total and an actual successful Entry observation.
It derives the actual resolved target path, actual native decoded lookup, unchanged complete per-slot recursionAncestry, and the exact returned expansionAncestry.
For a boundary, this expansion history is `(recursionKey handle bucket :: before.recursionAncestry target).eraseDups`.
For another decoded value, it is exactly the old target history.
The theorem inverts actual getValue, representative, lookup, modify and pure operations.
It uses no property supplier for a future Entry return.

`SourcePruningEnumerationBoundaryEntryBudget.checked_enter_shape_budget` connects that actual Entry to the preceding actual false boundary check.
It derives the check's freshness from its actual observation.
It aligns the check representative and actual Entry target by finite root paths and Frame preservation.
It derives shape-carrier membership from the original stored model point.
The returned expansionAncestry therefore has a strictly smaller per-handle unused shape count than `checked.recursionAncestry target`.
It also retains the actual native lookup, actual check representative success, unchanged ALL per-slot history and exact inserted expansion history.

## Original premises and actual observations

The composition takes the check heap, primitive fuels, selected uv, actual returned Entry target, exact handle/bucket, and returned decoded value.
It takes four literal states: original check input, check output, Entry input and Entry output.
Original representative Total is explicit.
The original model premises are Satisfies, AssignmentOrigins, Canonical, uv inside the original counter, and the literal original stored pending slot with the SAME exact handle/bucket.
They derive membership in `ModelKeyShapes.keyShapes whole` through the checked `stored_recursion_key_mem` theorem.
No post-Entry model or supplied future key membership is an input.

The check premise is actual `Success (checkRepeated heap checkFuel uv handle bucket) before false checked`.
The Entry premise is the literal actual raw singleton `[.ok ((target, handle, bucket, value), after)]`.
The returned native value is a recursive boundary.
The sole intervening-state premise is a complete `Frame checked entering`.
It supplies no freshness, model, key-carrier membership or future completion assertion.

A separate live-root premise is unnecessary for this observer.
The two ACTUAL representative paths derive equality with Entry's actual target even if that target is not syntactically uv.
The original stored key and actual Entry tuple explicitly use the same exact handle/bucket.
No decoded source handle is used as a prepared parent.

## Connection to the actual narrowed prefix

The prefix peer reports a pending source theorem that exposes the actual original getValue singleton, actual false check from the read state to checked, the same stored handle/bucket, the same returned boundary, and `after = Cached.frame checked before`.
At that actual endpoint, `Frame.refl` supplies the intervening premise.
The original caller model, origins and canonical data can be transported to the genuine getValue state by its complete compression frame.
This candidate does not assume the peer's theorem and does not claim it was checked.
The parent must compose that actual prefix identity and the later literal Entry observation.

## Measure scope

Entry writes ONLY expansionAncestry.
It does not insert the new key into recursionAncestry target.
The theorem therefore compares the returned ACTIVE EXPANSION history to the old resolved target's per-slot history.
It does not claim a strict decrease of the returned target recursionAncestry itself.
Later allocation inherits the active expansion history; that subsequent inheritance is outside this candidate.

The budget is finite for ONE FIXED native handle and the original model's shape carrier.
The proof does not assume all historical keys are inside that carrier.
It derives only the actual inserted key's required membership and freshness.
It does not bound native handles, callback count, whole search depth, global termination, output existence or rendered-language completeness.
No Haskell code or Haskell defect claim is added.

## Evidence and limits

Nine input modules were read whole.
Six additional exact literal cuts are preserved with both original-whole and cut SHA identities.
The complete two public statements include their actual namespace, implicit types and local instance contexts.
All source identities, read scopes, statement ranges and candidate identities are in `source-manifest.json`.
The child performed no compiler, evaluator/native, Git, network, board or repository mutation.
The candidate is source-only and frozen for the parent's checks.
