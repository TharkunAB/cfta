import MicroCFTA.SourcePruningEnumerationRecursion
import MicroCFTA.EnumerationPendingOrder

namespace MicroCFTA.SourcePruningEnumerationRecursionOrder
open EnumerationState EnumerationCorrectness EnumerationCompressionFrame
open SourcePruningEnumerationNodes
local notation "Symbol" => SourcePruningTemplates.Symbol
variable {EnumGuard NativeGuard : Type}

/-- An actual false native recursion check retains every field and representative path. -/
theorem checkRepeated_false_frame
    (heap : InternedConstructorTemplates.State Symbol NativeGuard)
    (fuel uv handle : Nat) (scs : List Suspended)
    (before after : EnumerationState.State Symbol EnumGuard)
    (total : UnionFind.Total before.representatives)
    (observed : Success (SourcePruningEnumerationRecursion.checkRepeated heap fuel uv handle scs)
      before false after) : Frame before after := by
  cases decoded : lookupNode heap handle with
  | none =>
      have impossible : Success (failure .unresolvedReference) before false after := by
        simpa only [SourcePruningEnumerationRecursion.checkRepeated, decoded] using observed
      exact (success_failure .unresolvedReference before after false impossible).elim
  | some value =>
      by_cases boundary : MergedOrdinaryHeight.recursiveBoundary value = true
      · simp only [SourcePruningEnumerationRecursion.checkRepeated, decoded, boundary, ↓reduceIte] at observed
        obtain ⟨root, resolved, resolution, continued⟩ := (success_bind _ _ _ _ _).mp observed
        by_cases seen : recursionKey handle scs ∈ resolved.recursionAncestry root
        · simp [Success, setValue, get, getThe, MonadStateOf.get, modify, modifyGet,
            MonadStateOf.modifyGet, bind, pure, StateT.pure, StateT.bind, StateT.get, StateT.modifyGet,
            ExceptT.bind, ExceptT.pure, ExceptT.bindCont, ExceptT.mk, ExceptT.run, seen] at continued
        · have same : after = resolved := by
            simpa [Success, get, getThe, MonadStateOf.get, bind, pure, StateT.pure, StateT.bind,
              StateT.get, ExceptT.bind, ExceptT.pure, ExceptT.bindCont, ExceptT.mk,
              ExceptT.run, seen, eq_comm] using continued
          subst after
          exact representative_frame fuel uv root before resolved total resolution
      · exact pure_frame false false before after (by
          simpa only [SourcePruningEnumerationRecursion.checkRepeated, decoded, ite_eq_right boundary] using observed)

end MicroCFTA.SourcePruningEnumerationRecursionOrder
