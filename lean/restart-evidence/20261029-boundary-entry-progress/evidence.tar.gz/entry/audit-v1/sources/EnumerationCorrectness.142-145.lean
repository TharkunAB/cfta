def Satisfies (language : NodeLanguage Symbol) (meaning : Guard → Term Symbol → Prop)
    (assignment : Nat → Term Symbol) (state : State Symbol Guard) : Prop :=
  Fragments.stateSatisfies state.representatives (heap language state.values) assignment ∧
    guardsHold meaning assignment state.obligations
