# Actual boundary prefix identity

Timestamp: 2026-10-29 00:19:20 CET.
Parent supplied base checkpoint: `70ff91ffce`. Root owns repository, compiler, Git, and board operations. The author performed only source reads and writes in this new owned area.

## Candidate and status

`/tmp/mcfta-boundary-entry-progress-20261029/prefix/candidate-v1/MicroCFTA/SourcePruningEnumerationBoundaryPrefixIdentity.lean`

170 lines; 11564 bytes; SHA256 `167bddc82d1d4770fd9194efb52ff5347fe472b2410c136f223dfde6373603ad`.

Status: UNTESTED source candidate. Root owns compilation and installation. All previous proof areas remain unchanged.

The only public theorem is `SourcePruningEnumerationSelectedStep.narrowed_boundary_identity`. `PUBLIC-SIGNATURE.txt` preserves its complete literal declaration and conclusion. The candidate preserves its imports, local notation, type parameters, and local instance declarations.

## Original premises and actual observations

The theorem takes the original full `Packet` at `caller`, `memos`, `metadata`, and `before`, plus the original restart decision that selects `uv`. It takes the existing `PrefixValid` receipt for the actual common-fuel `runPrefix`. It also takes that run's literal completed `.narrowed` observation, including the actual checked core, native preparation value/action/heap, caller, queries, optional raw action rows, retained cache, and successful false Right row. The native preparation result is an actual recursive boundary.

No later model, heap, key-shape membership, handle identity, key freshness, Packet, Ready, or preservation supplier is an added premise. `PrefixValid` is the existing producer receipt; this theorem adds no new validity contract. The explicit successful Right row binds the theorem to that actual supported prefix path.

## Derived results

The actual native result heap equals the original heap. The complete reached caller equals the original caller. Saved queries equal the original query memo. The selected enumeration action equals `pure ()`. The observed raw action rows equal the singleton with the checked core.

The complete returned cached state equals `EnumerationExpandableIndex.frame checked before`. This equality retains both original index tables. Updated metadata equals the original metadata, and the actual Right core equals the checked core.

The actual returned cache has `Packet formulas solver inventory caller memos metadata after` at the ORIGINAL complete caller, memos, and metadata. It also has `Ready uv after.core`. The Packet supplies its actual CacheValid, safe, pending, order, and metadata-bound fields.

The theorem exposes one handle, one suspended bucket, and the actual intermediate read state. The original slot, read-state slot, and returned-cache slot contain that same handle and bucket. The original native lookup returns the boundary result value, and that value encodes to the same handle. The first raw reading equation, false recursion-check equation, and complete read Frame remain explicit. The actual successful representative lookup resolves to `uv` at the checked core. The exact key is absent from the actual returned cache's recursion ancestry at `uv`.

## Proof route

The proof inverts the existing Valid receipt once. Original selection and the original Packet derive Ready before the first read. The actual read derives its complete Frame, selected stored slot, and native value resources. BoundaryAction then derives native heap retention and the pure identity action from the original native Ready/Available/closed/coherent resources.

The retained value's encoded handle identifies the Valid witness's new handle with the original checked handle. The proof reconstructs the literal `runPrefix` result using the actual reading, checking, native preparation, pure action, equal-handle adapter, and pure Right record. Constructor equality identifies every actual returned endpoint. This avoids a new raw-result case tree.

The returned Packet uses the original context. Existing Valid shape facts supply safe/pending/CacheValid; exact caller identity transports CacheValid. PrefixValid's original-counter and dependency-order facts transport the old Packet's remaining fields. The actual false check supplies freshness. Actual representative lookup plus the read's derived Ready fixes its representative to `uv`.

## Next composition and limits

The Entry-budget consumer can use the exposed actual false check from `readAfter` to `checked`. The actual cache core equals `checked`, so the intervening core Frame is reflexive. Original model, origins, and canonical assumptions can be transported to `readAfter` with the exposed genuine read Frame. They are not assumptions about a future Entry model.

The returned Packet/Ready/stored slot and original native lookup support Entry existence through the existing SelectedEntry or SelectedPreparation producer. This observer itself proves neither Entry existence nor its unused-shape budget decrease. The peer Entry task owns that composition.

The theorem covers the supported narrowed boundary path at the actual common prefix fuel. It does not assert that every selected prefix reaches that path. It proves no global finite native-handle universe, full model-emission coverage, or sufficient global recursive depth. It introduces no runtime definition, new broad history type, model oracle, or source/prepared identity cast.

## Read scope and ownership

`MANIFEST.json` records complete source snapshots and their exact whole-versus-cut read scopes. `cuts/` preserves the listed literal ranges. Unlisted portions of copied source files are provenance only. Some exploratory broad output was truncated; the retained focused ranges state the proof-relevant scope.

No compiler, evaluator, native execution, Git, network, or board call was made. No repository or Haskell file changed. No Haskell finding arose.
