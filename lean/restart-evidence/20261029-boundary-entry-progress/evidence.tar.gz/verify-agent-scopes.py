"""Verify retained source scopes and candidate identities before document headers."""
from pathlib import Path
import json,hashlib
AREA=Path('/tmp/mcfta-boundary-entry-progress-20261029')
files=[AREA/'prefix/scope-v1/MANIFEST.json',AREA/'entry/audit-v1/source-manifest.json',AREA/'mu-query/manifest-v1.json']
rows=[]
for manifest in files:
 count=[0]
 def check(path,record):
  raw=path.read_bytes()
  if path==Path('/home/tritlo/Code/mcfta/lean/MicroCFTA/Audit.lean') and hashlib.sha256(raw).hexdigest()!=record['sha256']:
   raw=(AREA/'prior-Audit.lean').read_bytes()
   assert path.read_bytes().endswith(raw)
  assert hashlib.sha256(raw).hexdigest()==record['sha256'],path
  if 'bytes'in record:assert len(raw)==record['bytes'],path
  count[0]+=1
 def walk(value):
  if isinstance(value,dict):
   skip=set()
   if 'source_identity'in value and 'cut_identity'in value:
    check(Path(value['source']),value['source_identity']);check(manifest.parent/value['copy'],value['cut_identity']);skip={'source_identity','cut_identity'}
   if 'sha256'in value:
    paths=[Path(value[k])if Path(value[k]).is_absolute()else manifest.parent/value[k]for k in ['preserved','snapshot','copy','file','path','report','source','statement_and_context']if isinstance(value.get(k),str)]
    path=next((p for p in paths if p.is_file()),None);assert path,(manifest,value)
    record=dict(sha256=value.get('cut_sha256',value['sha256']))
    if 'bytes'in value:record['bytes']=value.get('cut_bytes',value['bytes'])
    check(path,record)
   for key,child in value.items():
    if key not in skip:walk(child)
  elif isinstance(value,list):
   for child in value:walk(child)
 walk(json.loads(manifest.read_text()));rows.append(dict(manifest=str(manifest.relative_to(AREA)),verified=count[0],unresolved=0))
(AREA/'agent-manifest-verification.json').write_text(json.dumps(dict(verified_before_document_headers=True,manifests=rows),indent=2)+'\n')
print(json.dumps(rows))
