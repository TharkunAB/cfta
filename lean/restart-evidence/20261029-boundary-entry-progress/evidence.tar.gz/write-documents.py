"""Record actual boundary entry progress and retain every prior document byte."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,shutil
ROOT=Path('/home/tritlo/Code/mcfta');AREA=Path('/tmp/mcfta-boundary-entry-progress-20261029')
source=json.loads((AREA/'source-publication.json').read_text())['source_head'];board=json.loads((AREA/'board-post-verification.json').read_text());stamp=datetime.now(ZoneInfo('Europe/Stockholm')).strftime('%Y-%m-%d %H:%M %Z')
header=f'''# Verified actual boundary entry progress — {stamp}

Source `{source}` is pushed and verified on formalize. Full goal ACTIVE.
Read `lean/notes-current-boundary-entry-progress.md` for exact contracts and next work.
Every earlier document byte follows unchanged.

The actual narrowed boundary prefix retains its checked handle, native caller,
metadata and both indexes. It derives the same fresh key and original Packet.
That Packet constructs completed Entry and native preparation at a local bound.
Entry inserts the checked key into expansionAncestry. Its unused original-model
shape budget strictly decreases from the ORIGINAL target recursion history.
Direct child allocation inherits this decrease at the SAME CHECKED handle.
Per-slot ancestry is unchanged by Entry. A child's own native handle may differ.
The original-packet producer derives prefix validity and its sufficient bound.
No future model, freshness, key membership or Entry success supplier is added.
The actual supported reached boundary observation remains explicit.

Strongest system semantics remains conditional checked rendered soundness under
fixed-PCS/whole-Discharged and ordered output-prefix retention at greater depth.
The previous actual terminal emission theorem remains. Native generated boundary
closure/rank, nonterminal chosen-model emission and original-source sufficient
recursive depth across earlier callbacks remain open. DONE does not imply
Discharged. Complete policy/origin/public API and Haskell correspondence remain.

Four modules/seven public theorems: 580 lines/37,367 bytes; no new definitions or
private proof helpers. All five final strict sources pass. Audit: 4,584 jobs and
81,886 theorem dependencies. Compiler matrix: 19 commands, 14 PASS, five preserved
FAIL; all final inputs pass at serial measured 4 GiB and zero swap. Public:
794 theorem checks/axiom lists,67 definition bodies,3,408,116 bytes SHA256
5fbeccbfcc8cbc35107512f25694593b0e38585c34b3ee4968f6afe30cf06216.
Prior3,376,571 bytes are an exact prefix; all31,545 new bytes were read.
All4,579 old non-Audit Lean,428 stronger-source and817 Haskell/Cabal identities
remain. Three source-scope manifests verify95 artifact identities.

No Haskell source changed. No Haskell check ran. No new Haskell defect/fix was
established. FINDINGS retains earlier external repair records. Source-only
native audit identifies the missing generated callback body degree bound.
Existing OpenBodyBoundary refutes first-order preparation at an actual native
site; native_returned observes NodeRef.mu26 only. It is no divergence or original
ceiling counterexample. Existing NoNewMu/cached-depth counterexample remains.

Evidence: `lean/restart-evidence/20261029-boundary-entry-progress/`.
Board {board['sequence']}: `{board['post_id']}`, exact verified author/content/metadata.
Keep frozen evidence immutable. Use a new writable area and refresh upstream.
Compiler/native jobs remain serial at4GiB. Normal formalize pushes remain
explicitly authorized. The full objective is incomplete and stays ACTIVE.

---

'''
note=f'''# Actual boundary prefix, Entry and inherited shape budgets

Checked at {stamp}. Source `{source}` on formalize.
The complete formalization objective remains ACTIVE and incomplete.

## Current strongest statement

The optimized interned Lean model has conditional checked rendered soundness
under its semantic/resource contracts, fixed-PCS and whole-Discharged. Greater
recursive depth retains the ordered output prefix. Its finite prepared worker
retains resources, histories, proper/canonical storage, arity and projection
under the original gates. The previous checkpoint constructs actual terminal
callback emission with the same original assignment. DONE does not imply
Discharged, and configured stop can emit a partial result.

This checkpoint proves actual local budget consumption through the supported
narrowed boundary path. It constructs completed selected preparation from the
original returned Packet. It does not prove global recursive output coverage
or an original-input sufficient recursive depth. It adds four proof modules and
seven public theorems. Enumerator, native and Haskell definitions are unchanged.

## Complete boundary prefix identity

`SelectedStep.narrowed_boundary_identity` starts with the original Packet and
actual restart expansion choice. It uses the existing PrefixValid receipt for
the actual common-fuel runPrefix, its literal supported completed narrowed row,
and the recursiveBoundary observation on the returned native value.

It derives original native heap/caller/query identity and pure enumeration
action. The complete returned cache equals frame checked before, including
both original index tables. Right recording retains the original metadata and
checked core. The endpoint has the ORIGINAL full Packet and Ready condition.
One same handle and suspended bucket occur in the original, read and endpoint
slots. Actual native lookup and encode identify that handle. The theorem exposes
the actual first getValue singleton, false check, complete read Frame and actual
representative success. It derives absence of the exact key at the endpoint.
No new handle identity, freshness, future Packet or later model is assumed.

The proof inverts Valid once. Original selected Ready identifies the read slot.
Original realized storage gives the native value's resources. BoundaryAction
excludes ordinary fallback, so actual narrowing retains the original value and
heap and selects pure(). The proof then reduces actual runPrefix through the
same-handle adapter and pure Right event. It retains the original full memos.

## Exact Entry history and strict budget

`Entry.enter_history` takes original representative Total and an actual Entry
Success. It derives the actual target root path and native lookup. ALL per-slot
recursionAncestry fields remain unchanged. Entry sets expansionAncestry to the
old target's recursion history, with the actual checked key prepended and
normalized by eraseDups when the decoded value is a boundary.

`BoundaryEntryBudget.checked_enter_shape_budget` uses original Total, the actual
false check, an intervening full Frame and the literal actual Entry singleton
with the same exact handle/bucket. Original Satisfies, AssignmentOrigins,
Canonical, selected-slot liveness and literal stored key derive carrier
membership. The actual false check derives freshness. Actual root paths derive
equality of the check and Entry representatives; no supplied root equality is
needed. The returned expansion history strictly consumes the unused shape count
at that native handle. This generic observer needs no separate Ready premise.
Its actual Entry observation is explicit. The producer below constructs one.

The budget baseline is the OLD RESOLVED TARGET recursion history. Entry does not
insert into that target history. A comparison with the former expansion history
would be wrong. Existing all-slot KeyAncestry and stale-slot allocation facts
remain necessary and unchanged.

## Original inputs construct actual preparation

`BoundaryPreparationBudget.narrowed_boundary_preparation_budget` composes the
complete actual prefix with the existing SelectedPreparation.complete producer.
Inputs are the original Packet/choice, actual valid prefix boundary observation,
and original Satisfies, AssignmentOrigins and Canonical model gates.

The actual endpoint Packet/Ready/same stored key construct one bound for actual
Entry and native selected-value preparation. At every larger preparation fuel,
SelectedPreparation.run is exactly the singleton Entry result and native done
result. The entered tuple contains the SAME selected root, checked handle,
suspended bucket and decoded boundary. The actual entered cache retains its
full Packet at the actual advanced native caller and RenderStable.

The first component of that literal prepared run supplies actual Entry Success.
Entry.enter_history and the actual false-check Frame identify the inserted
history with `(recursionKey handle scs :: ORIGINAL target history).eraseDups`.
The original model supplies the shape. Derived freshness supplies strictness.
All per-slot history remains ORIGINAL. The actual returned expansion budget
strictly decreases versus the ORIGINAL selected target history.
No future Entry equation, model, key membership, freshness or returned Packet
is an input to this composition.

`packet_boundary_preparation_budget` derives the sufficient PREFIX bound from
the ORIGINAL Packet before observing any actual row. It adds no PrefixValid
supplier. At every larger prefix fuel, for the actual supported reached narrowed
boundary row and actual expansion choice, it constructs preparation and the
same strict budget. Symbol/Node decidable equality are not public hypotheses of
this producer. Its proof uses classical equality only for the existing validity
producer. The actual EdgeKey equality parameter remains.

The boundary row and original current model remain explicit. This theorem does
not show every selected prefix takes that branch or every future callback keeps
a chosen model. Prefix and preparation bounds are local and may differ. No one
uniform work/recursion bound for the full search follows from this result.

## Actual child inheritance

`KeyShapeBudget.allocated_unused_le` proves that raw allocation gives its fresh
slot every expansion key. Its old stale-slot keys can only remove more unused
shapes. `CachedChild.allocate_unused_le` inverts actual cached allocation. It
identifies the returned fresh slot and the actual inherited budget.

The preparation composition uses this result. Every successful DIRECT cached
allocation from its actual entered cache has a strictly smaller unused count
at the SAME CHECKED native handle than the ORIGINAL selected target history.
The new child's own native handle can differ. This result does not assert a
strict decrease at that different handle. It does not yet cover an arbitrary
sequence of intervening head/child operations or every future descendant.
Each later segment must retain the required history relation from its actual
operations. Per-handle counts need a finite handle domain or another justified
original well-founded rank to give a global termination argument.

## Native closure audit and rejected shortcuts

A separate source-only audit adds no new theorem and ran no native evaluator.
Actual compileMu issues a node request before optionalBinder. The returned
binder body is GENERATED recursive output. It is not either original stored
operand body. Actual maybeMu_eq compiles the full repaired binder, with probes,
through encode(leaves body)[pairReference]body when the pair remains free.

Existing encode_depth, zero-degree stored leaves and build_new_lower give a
source proof route to Lower before(1+valueDepth body) actualAfter. Thus each new
Mu BODY has degree at most that generated body's degree. Original Bounded
constrains resident Mu BODY degree strictly below its limit. The whole valueDepth
of an OPEN resident Mu is one greater than its body degree. Bounded alone does
not supply the generated callback body's required strict original ceiling.
This route is an audited use of existing source results, not a newly compiled
whole-query closure theorem.

The next native obligation is an original operand/domain/actual-trace bound on
the generated callback body before optionalBinder. Derive the same ceiling only
if that provenance proves it. Otherwise derive a justified original rank. Do
not assume the desired generated-body bound in a callback supplier. Existing
compileMu_below requires Completes of the request's semantics; it cannot supply
this original-input closure by assuming the termination result under proof.

The existing SourceRecursiveIntersectionOpenBodyBoundary starts two repaired
closed Original builds with Facts/Available/Covered/Context, valid native memos
and checked64-bit words. Its actual22-step witness reaches an optional-binder
body containing an open nested Mu and retaining the pair reference. It refutes
universal PreparedWithoutMu at those actual sites. Its native_returned observes
only `returned = some(.mu26)` at fuel100. It does not assert payload or cache
identity. The audit's additive SCOPE-CLARIFICATION-v1.md preserves this limit.
This is neither divergence nor a refutation of the original degree ceiling.
Do not add PreparedWithoutMu as a new global admission gate.

Even a whole-query degree ceiling does not bound the number of physical Mu/
Union identities at a degree. Physical depth/ordinary probe values and generated
guard expressions remain. The native edge compiler accepts arbitrary conjoin.
A single query over fixed original operands also differs from later queries
whose operands are generated roots. Prove closure over those descriptors or a
suitable alternative rank. Per-current-heap Nat ranges, supplied-depth Fits/
Reserved and future key/handle/model suppliers leave this gap unchanged.

The older SourceColdUnfoldNewMuBoundary still refutes startup-only complete Mu
inventory and monotonically decreasing cached depth. Its historical native/tmp
logs remain absent. No old native run was repeated or claimed recovered here.
All prior counterexamples and repair records remain unchanged.

## Next work

1. Extend exact Entry/child history relations through the actual prepared head,
   own allocation, all intervening writes and selected recursive child. Track
   which checked handle component decreases. Do not claim the child's different
   native handle has that strict decrease.
2. Derive original native descriptor closure/rank across generated query bodies,
   optional binders, physical probes and generated later operands. The body-degree
   link above is one concrete missing inequality. A global finite handle or
   suitable well-founded measure must follow from original inputs.
3. Prove original-model nonterminal chosen-output induction through actual child
   recursion and emitted caches. Fresh assignments stay branch-specific because
   sibling caches can reuse numeric fresh identities.
4. Derive sufficient recursive depth covering earlier allocating/stopped
   callbacks, or prove a valid same-target emission argument. Local producer
   bounds and ordered prefix stability do not establish eventual output.
5. Complete policy/solver/origin/public API contracts and optimized Haskell
   correspondence. Retain older constructor and equality proofs as secondary.

## Verification

Four additive modules:580 lines/37,367 bytes;seven public theorems;no new runtime
or proof-domain definitions and no private proof helpers. All four plus Audit
pass exact strict Lean4.34.1 checks with warningAsError=true and linter.all=true.
Audit passes4,584 jobs and checks81,886 theorem dependencies. Only propext,
Classical.choice and Quot.sound are allowed. Counts are validation evidence.

Nineteen serial compiler commands have14 passes and five preserved failures.
All final sources pass. One draft used subst on a root with competing equalities;
an explicit rewrite fixed the actual target. Two prefix drafts needed literal
result-state reduction, then caller rewrite and nested-frame reduction. Strict
producer checking rejected unused public equality instances and then omit.
Scoped variable declarations and local classical proof equality fixed those
failures. No semantic model/resource gate changed. All failed inputs, complete
raw logs, repairs and85 command input snapshots remain. All measured memory.max
and memory.high are4,294,967,296;swap max is0. No budget increase, custom axiom,
native_decide, placeholder or linter suppression was added. Default replay's old
unused-input warning is in unchanged InternedFreshOrdinaryClosedCompletion.

Public:794 theorem checks/axiom lists and67 definition bodies,3,408,116 bytes,
SHA2565fbeccbfcc8cbc35107512f25694593b0e38585c34b3ee4968f6afe30cf06216.
The previous3,376,571 bytes are an exact prefix. All31,545 new bytes were read
in three complete contiguous ranges. No new public display cut remains.
All4,579 prior non-Audit Lean,428 stronger-source and817 Haskell/Cabal identities
remain. Audit preserves its entire prior body after four imports. Twenty-one
prior document bodies remain exact suffixes. Twenty-two final documents remain.
Three source-scope manifests verify95 artifact identities. Exact literal cuts
remain cuts. Failed drafts and child UNTESTED status labels remain. Final-source
hashes identify Root's actual checked repairs. Two small evidence-tool repairs
corrected a previous public-log path and added the statement_and_context field
to the source-scope verifier. Neither changed a proof or inherited artifact.

## External Haskell repair record

No Haskell source changed. No Haskell check ran. No new Haskell defect or fix
was established. All five new failed drafts concern Lean elaboration/reduction
or strict linting. The native first-order counterexample is already recorded
and is a proof-invariant boundary. The remaining degree/handle gap is not a
new Haskell defect. FINDINGS.md retains every earlier repair record. Record any
later Haskell defect, proposed repair, actual fix and reproduction there.

## Publication and restart

Three source commits end at `{source}`. Remote and tracking
formalize heads match on git@github.com:TharkunAB/cfta.git refs/heads/formalize.
Origin/main d1ca06a1dd0c7488205feda613b529df21a08669 remains an ancestor.
The current refresh completed with Already up to date. Normal formalize pushes
remain explicitly authorized. Refresh upstream before new work. Preserve all
proofs, counterexamples, repairs, marked drafts, frozen areas and older archives.

Board{board['sequence']}, post `{board['post_id']}`, has exact verified author,
content and metadata. The shared note uses the msg-board skill. Complete
unfiltered evidence is in lean/restart-evidence/20261029-boundary-entry-progress/.
Its standard-library verifier reconstructs every sealed regular file from
/tmp/mcfta-boundary-entry-progress-20261029/. This includes failures, drafts,
source scopes, public types/axioms, raw logs, input snapshots, all prior/final
documents, measurements, Git and board receipts. Use a fresh destination. Keep
frozen/restored evidence immutable. Continue in a NEW writable directory.

Read this note and the front matter of NEXT-PROMPT.md,HANDOFF.md and FINDINGS.md.
Keep compiler/native jobs serial under the existing measured4GiB cap. Do not
repeat passing checks unless inputs change. Continue the full objective without
asking whether to continue. The complete goal remains ACTIVE and incomplete.
'''
old=json.loads((AREA/'prior-documents.json').read_text());records=[]
for row in old:
 path=ROOT/row['path'];before=(AREA/'prior-document-bodies'/row['path']).read_bytes();assert path.read_bytes()==before;addition=header
 if row['path']=='FINDINGS.md':addition+='External Haskell repair record: no new Haskell change/check/defect/fix.\nThe five new draft repairs affect only Lean proof elaboration or strict linting.\nThe re-read OpenBodyBoundary is an existing invariant counterexample, not a new\nHaskell defect or divergence claim. All earlier repair records follow unchanged.\n\n'
 path.write_bytes(addition.encode()+before);raw=path.read_bytes();assert raw.endswith(before);records.append(dict(path=row['path'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
path=ROOT/'lean/notes-current-boundary-entry-progress.md';assert not path.exists();path.write_text(note);raw=path.read_bytes();records.append(dict(path=str(path.relative_to(ROOT)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()));(AREA/'final-documents.json').write_text(json.dumps(records,indent=2)+'\n');dest=AREA/'final-document-bodies';dest.mkdir()
for row in records:
 target=dest/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/row['path'],target)
(AREA/'source-head.json').write_text(json.dumps(dict(head=source),indent=2)+'\n');print(json.dumps(dict(documents=len(records),prior_exact_suffixes=len(old),new_note_bytes=len(raw),time=stamp)))
