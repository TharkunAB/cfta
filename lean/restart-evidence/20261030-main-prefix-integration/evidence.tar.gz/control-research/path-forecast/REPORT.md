# Path transport from the original fixed-capacity forecast

Status: source-only investigation. No Lean proof, evaluator, native worker, or project code was executed. No repository file was changed. The earlier sealed bundles remain unchanged.

## Result

The path invariant can be independent of a satisfying term, trie validity, and callback output. The useful invariant says that each represented path in a pending bucket satisfies a predicate P. The only required closure of P is deletion of a leading child index. `CachedOwn.prepare` then needs the projected paths of the selected guard to satisfy P.

The complete actionable statement below uses `HeadAdmission`. It applies before head completion. It obtains the selected guard from the admitted current physical heap and obtains the inherited bucket from the admitted stored slot. It does not assume a future resource packet, completed head, accepted output, or finite model.

For a fixed capacity D, Root can instantiate P with its original-input carrier for the guards in `PreparedReservation.final D seed ceiling`. This transport does not prove that any finite D suffices. Its original forecast still depends on D.

There is no existing all-state path-domain theorem among the inspected sources. The existing properness and ancestry families give close proof patterns. The resource producers expose the correct stage guards before they discard the relation between those guards and output histories. That is where the path property must be added.

## One complete proposed Lean statement

The following notation uses the types in `SourcePruningEnumerationPreparedHeadAdmission`. `Symbol` is `SourcePruningTemplates.Symbol`. `Constraint` is `SourceSymbolicIndex.Constraint FullSyntax.Formula`. `Cached`, `Caller`, `Memos`, and `Inventory` have the same meanings as in that file. This is a proposed statement, not a checked declaration.

```
def BucketPaths (P : EqualityTrie.Path → Prop)
    (scs : List EnumerationState.Suspended) : Prop :=
  ∀ sc ∈ scs, ∀ path ∈ EqualityTrie.fromPathTrie sc.trie, P path

def StatePaths (P : EqualityTrie.Path → Prop)
    (state : EnumerationState.State Symbol Constraint) : Prop :=
  ∀ value ∈ state.values,
    BucketPaths P (EnumerationSchedule.references value)

def ProjectionPaths (guards : List Constraint)
    (P : EqualityTrie.Path → Prop) : Prop :=
  ∀ guard ∈ guards, ∀ tries residual,
    SourcePruningEnumerationConstraint.project guard = some (tries, residual) →
    ∀ trie ∈ tries, ∀ path ∈ EqualityTrie.fromPathTrie trie, P path

theorem HeadAdmission.prepare_paths_of_forecast
    {Typing : Type} {bits : Nat}
    {seed : SourcePruningEnumerationIncomingReservation.Seed}
    {formulas : SourceGuards.Formulas FullSyntax.Formula}
    {solver : SourceGuards.Entailment FullSyntax.Formula}
    {inventory : SourceCurrentAllocatedNativeInventoryState.Inventory}
    {caller : SourceCurrentAllocatedPartialState.State (bits + 2)}
    {memos : EndpointMemoGateTrace.Memos}
    {metadata : SourcePruningRecordTypes.Metadata Typing} {before : Cached}
    {uv handle : Nat} {scs : List EnumerationState.Suspended}
    {parentEntry : Cache.Interned InternedBinderProtocol.NodeKey}
    {storedEdges : List (InternedConstructorTemplates.EdgeValue Symbol Constraint)}
    {depth : Nat} {free : List InternedBinderProtocol.Reference}
    {edge : InternedConstructorTemplates.EdgeValue Symbol Constraint}
    (admission : HeadAdmission seed formulas solver inventory caller memos metadata
      before uv handle scs parentEntry storedEdges depth free edge)
    (guards : List Constraint) (P : EqualityTrie.Path → Prop)
    (included : seed.1 ⊆ guards)
    (projected : ProjectionPaths guards P)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (original : StatePaths P before.core)
    {rows : List _}
    (observed : SourcePruningEnumerationCachedOwn.prepare
      caller.checked.native.machine.heap scs edge before = some rows) :
    ∀ row ∈ rows,
      StatePaths P row.2.core ∧
      ∀ child ∈ row.1.2.1, BucketPaths P child.2.1
```

This statement must be placed in, or open, `SourcePruningEnumerationPreparedNativeHookResources`. It also needs the existing decidable instances used by HeadAdmission and the native constructors. The implicit row type is inferred from the literal prepare equation. This follows the existing `prepare_ancestry_extension` statement.

Using `ProjectionPaths` over the actual projected tries avoids an unnecessary cached-class or NormalClasses premise. If Root defines its carrier from raw PCS paths instead, `SourcePruningEnumerationConstraint.project_complete` supplies the exact readback under the existing Cached premise. That distinction must remain explicit.

## Proof route for that statement

1. Obtain the inherited bucket from `admission.stored`. `List.mem_of_getElem?` places its pending value in `before.core.values`. Apply `original` to that value. `EnumerationSchedule.references` reduces to exactly scs.
2. Derive the selected edge's physical residency. Copy the exact argument in `RecursiveReservation.edge_shape_from_packet`, lines 208–210. Its linkedness proof is `admission.packet.context.ready.semantic.ready.semantic.1.normal.facts.linked`. Use `admission.parentAvailable.resident` and `admission.selected`.
3. Apply `admission.known edge.entry.key edge resident`. Apply `included`. This places the actual selected guard in the original guard carrier. Apply `projected` to its literal projection equation.
4. Prove a path-only `suspendMany` lemma by induction on tries. `CachedChild.allocate` adds `EnumerationState.allocated none`; `allocated` appends a pending value with an empty bucket. It does not install an own trie in that slot. The returned suspended list attaches each input trie to a fresh variable. Its paths are exactly the input trie paths. No storage, model, or variable-bound premise is needed for this path-only statement.
5. Unfold `CachedOwn.prepare`. Arity rejection gives an empty row list. Projection failure contradicts a successful prepare observation. A successful projection yields the single literal row.
6. For each staged child, split membership in `descendScs index scs ++ descendScs index own`. A descended represented path has its original `index :: suffix` in the original trie. Apply the inherited or own path property, then apply `tails`.

The last step needs no Valid premise. `EnumerationSuspendedForward.descended_path_original`, lines 14–29, already proves that implication for an arbitrary trie. It is private. Either expose that existing fact or reproduce the short structural proof in the new path module. The reverse implication would need stronger premises, but path transport needs only this forward implication.

The source `descendScs` map retains the variable and changes only the trie by `pathTrieDescend`. Its filter removes empty tries. Removing elements does not add paths. This also makes variable renaming irrelevant to the path invariant.

## Actual writers and the all-state extension

The inspected writes support a small generic path-preservation family:

| Operation | Actual path effect | Exact retained source |
| --- | --- | --- |
| `CachedOwn.suspendMany` | Returns the projected tries; appends empty pending buckets | cut 002 |
| `CachedOwn.prepare` | Appends the inherited and own descended buckets for each child | cut 002, lines 32–42 |
| `EnumerationState.allocated` | Appends `.unenumerated node []` | cut 015 |
| `CachedChild.prepareOrdinary` | Installs the supplied bucket unchanged in the fresh slot | cut 013 |
| `NativeIndex.write` | Installs the supplied value; updates counts and flags | cut 018 |
| `intersectValues` | Appends the two pending buckets | reused cut 045 |
| `IncomingNode.finish` | Installs `incomingScs ++ oldScs` | cut 019 |
| `assimilate` and `mergeNode` | Use `intersectValues`; eliminate or overwrite slots | cut 020 |
| `ShallowChild.prepareChild` | Installs the supplied bucket for an ordinary node; allocates an empty bucket for a boundary | cut 017 |

These facts explain why the generic child transport can use any P. It receives an already descended bucket and does not need a new model or a new original PCS closure. The child path proof must still cover the terminal adapter, representative merging, raw/core framing, and finalization. These branches are not already checked by this bundle.

`ChildProper.observed_cache_proper` is the closest existing proof pattern. It covers every returned candidate cache, including rejection. It does not require a successful singleton output. Its terminal branch transfers the filtered descendant bucket into `CachedTerminalAdapter.candidate_proper`. A parallel path-only family should establish the same assertion with StatePaths and BucketPaths. The generic write and merge cases above are the required local ingredients.

`ChildTraversal.Trace` records every successful child call and its exact next cache. `run` stops at the first other observation and retains its candidate cache. The existing stopped-trace API should be used for that prefix too. A proof restricted to complete traces misses a failed child's retained candidate. A proof restricted to final emitted outputs misses rejected and empty-output callbacks.

Then follow the existing `CompletedHeadReceipt.proper` proof. Its `receipt.running 0` gives the actual captured run. Unfold that run, derive the selected-edge branch, apply the new own-path and child-path facts, and transport through finalization. This gives path membership for the completed head's actual cache from its original admission. The future `completed`, `captured`, and output packet fields need not be assumed as new premises.

For a strict claim about every internal state, define the observation scope explicitly. The required controller scope includes each input cache, own-allocation cache, staged child bucket, child prefix cache, retained failed candidate, captured head cache, callback frame, and restart cache. If the intended claim also includes raw observation cores for which no Cached value is returned, add the raw terminal-adapter preservation theorem as well. The candidate-cache theorem alone does not establish that larger scope.

## Where the original forecast relation is retained and erased

The important existing resource facts are independent of output membership:

* `PreparedFiniteSiblingHistory`, lines 123–124, certifies every processed receipt with `ReceiptAt`.
* `PreparedFiniteSiblingCertificates.ReceiptAt`, lines 41–55, retains its precise `afterHead (stage ... index)` numeric and guard forecast.
* `PreparedFiniteHeadReceiptHistory`, lines 137–140, returns a `CompletedHeadReceipt` for every completed actual head receipt. It does so before any callback output-membership test.
* `PreparedFiniteSiblingHistory`, lines 152–159, lifts that head forecast into the sibling-wide forecast.
* `PreparedReservation.stage_le_final`, lines 161–166, lifts a bounded ordinary scan into the original positive-depth final forecast.

The existing `SelectedHistoryReceipt` and `InvocationHistoryAt` both existentially hide headSeed. Neither statement records that headSeed's inclusion in the original final guard forecast. Their rich callback histories also quantify over emitted outputs. They are insufficient interfaces for the requested all-state path claim.

A preliminary message from this task said that InvocationHistoryAt itself retained the exact stage seed. The exact cut disproved that statement. It was corrected promptly. The producer retains the literal current seed while constructing the existential witness at lines 198–201. The wrapper forgets it.

The useful change is at that producer, not a wrapper around output soundness. Add the path certificate beside the actual head receipt. Propagate it into callback inputs before checking whether the callback has outputs. Propagate it through the earlier sibling's completed callback before recursing to the next sibling. For a stopped callback, retain the path certificate in the stop/prefix evidence. Use the existing stage inclusions to keep one original final P throughout this construction.

`HistoryAdmission.prepared_opaque_resources` already derives the narrowed caller's guard heap from the original history admission and the actual prefix. Its conclusion uses the same seed guard list. It also accepts a current narrowed packet in the selected-preparation clause. For the new all-state theorem that current packet must be produced by the prefix induction. It must not be added as a new premise about an arbitrary future callback.

At the recursive level, strengthen the existing finite resource induction. Start with StatePaths for the original cache and a single original final guard carrier. Prove each local mutation and recursive callback preserves that same P. Keep traces of processed heads and callback inputs regardless of output. `Complete` currently returns only the stable outcome and its endpoint resources. It needs this additional all-state evidence if the public theorem is to state all-state transport.

## What this does and does not settle

This route supplies model-independent path transport for the original fixed-capacity forecast. It avoids the invalid suffix closure of only the original uncombined PCS paths: Root's carrier must include the actual projections of forecasted conjoined guards before taking suffixes.

It does not supply a carrier uniform in D. It does not bound neutral steps or prove that earlier callbacks have some complete depth. It does not derive global finite-value coverage, public exact order, or Haskell correspondence. Root owns the finite recursion-key carrier and budget construction; this task did not duplicate it.

No new Haskell file was read. No Haskell defect or fix was established. No Haskell FINDINGS item follows from this investigation.

## Acquisition and preservation

There are 29 new exact source scopes and 11 reused frozen scopes. Each new scope records requested and actual endpoints, full source bytes/hash, and copied bytes/hash. Each reused scope retains its old manifest and verifies the current full source identity before copying.

One complete old Lean source was acquired: CachedOwn, 178 lines. The PrefixPointResources cut covers 101 of 128 lines. Conservatively charge that broad partial scope as a second whole-source equivalent. Constraint has 59 of 90 lines and HeadReceiptProper has a union of 47 of 76 lines. These broad partial scopes are disclosed. The conservative whole-source budget use is 2 of 4. No source acquisition exceeded its requested endpoints.

A mistaken source name, `SourcePruningEnumerationSuspendedForward.lean`, caused one failed exact-cut acquisition at requested lines 12–41. The actual existing source is `EnumerationSuspendedForward.lean`. Its prior frozen cut was reused with a matching current hash. Some broad rg locators were truncated or named absent candidate files. No final source claim relies on the omitted locator text. The retained exact cuts were inspected without truncation.

Administrative commands only created, copied, hashed, and froze this owned bundle. They did not run Lean or project code. Root owns all compilation, evaluation, native execution, integration, Git, network, board activity, and repository changes. Root reported a new main commit during the task and stated that the relevant Lean sources were unchanged upstream. This task did not run Git to verify that report. The exact live source identities in the manifests are the authority for these cuts.

`VALIDATION.json`, `pins.json`, and `FROZEN.json` record the final checks and freeze. Prior sealed bundles remain immutable. Future proof attempts must use a new Root-owned artifact.
