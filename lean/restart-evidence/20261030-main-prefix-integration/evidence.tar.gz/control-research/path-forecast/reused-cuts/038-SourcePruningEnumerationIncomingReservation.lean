open SourceCurrentAllocatedNativeResourceForecast (Profile Le Room)
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula

/-- One schedule entry retains its guard alphabet and numeric profile. -/
abbrev Seed := List Constraint × Profile

/-- Forecast one native query and its optional Empty check from the current entry. -/
noncomputable def step (seed : Seed) : Seed :=
  (SourceCurrentGeneratedQueryGuardResources.forecast seed.1 seed.2,
    SourcePruningEnumerationIncomingQuery.forecast seed.1 seed.2)

/-- Forecast a fixed number of combined incoming steps from the original seed. -/
noncomputable def advance (seed : Seed) : Nat → Seed
  | 0 => seed
  | count + 1 => advance (step seed) count

/-- An empty schedule retains the original seed. -/
theorem advance_zero (seed : Seed) : advance seed 0 = seed := rfl

/-- A nonempty schedule continues from its first forecast. -/
theorem advance_succ (seed : Seed) (count : Nat) :
    advance seed (count + 1) = advance (step seed) count := rfl

/-- Consecutive parts of the same schedule compose at their shared seed. -/
theorem advance_add (seed : Seed) (first last : Nat) :
    advance seed (first + last) = advance (advance seed first) last := by
  induction first generalizing seed with
  | zero => simp only [Nat.zero_add, advance]
  | succ first ih => simpa only [Nat.succ_add, advance] using ih (step seed)

/-- One combined step retains every initial numeric component. -/
theorem step_profile_ge (seed : Seed) : Le seed.2 (step seed).2 :=
  SourcePruningEnumerationIncomingQuery.forecast_ge seed.1 seed.2

/-- One combined step retains every initial guard. -/
theorem step_alphabet_ge (seed : Seed) : seed.1 ⊆ (step seed).1 :=
  SourceCurrentGeneratedQueryGuardResources.forecast_ge seed.1 seed.2

/-- Every scheduled numeric profile bounds the original profile. -/
theorem advance_profile_ge (seed : Seed) (count : Nat) : Le seed.2 (advance seed count).2 := by
  induction count generalizing seed with
  | zero => exact Le.refl _
  | succ count ih => exact (step_profile_ge seed).trans (ih (step seed))

/-- Every scheduled alphabet retains the original guards. -/
theorem advance_alphabet_ge (seed : Seed) (count : Nat) : seed.1 ⊆ (advance seed count).1 := by
  induction count generalizing seed with
  | zero => exact fun _ member => member
  | succ count ih => exact fun _ member => ih (step seed) (step_alphabet_ge seed member)

/-- A later entry of this schedule bounds every earlier numeric entry. -/
