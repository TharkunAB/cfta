def suspend (trie : EqualityTrie.Trie) : EnumerateM Symbol Guard Suspended := do
  pure ⟨trie, ← allocate none⟩

/-- Only two unenumerated slots can be intersected. -/
def intersectValues (graph : Graph Symbol Guard) :
    UVarValue Symbol → UVarValue Symbol → Option (UVarValue Symbol)
  | .unenumerated left ls, .unenumerated right rs =>
      some (.unenumerated (match left, right with
        | none, node => node
        | node, none => node
        | some a, some b => some (graph.intersect a b)) (ls ++ rs))
  | _, _ => none

/-- Structural emptiness rejects an intersection branch. -/
def hasEmptyContents (graph : Graph Symbol Guard) : UVarValue Symbol → Bool
