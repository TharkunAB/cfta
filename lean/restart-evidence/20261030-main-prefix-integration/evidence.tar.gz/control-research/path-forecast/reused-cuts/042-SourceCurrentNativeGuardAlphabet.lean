local notation "top" => SourceEqualityConstraintConstructors.top (Formula := FullSyntax.Formula)
local notation "conjoin" => SourceEqualityPCSNativeEdge.conjoin

/-- One alphabet extension retains all entry guards and each possible primitive guard. -/
noncomputable def step (alphabet : List Guard) : List Guard :=
  alphabet ++ [top] ++ alphabet.flatMap (fun first => alphabet.map (conjoin first))

/-- Every entry guard remains in the next alphabet. -/
theorem mem_step_of_mem {alphabet : List Guard} {guard : Guard} (member : guard ∈ alphabet) :
    guard ∈ step alphabet := by
  exact List.mem_append_left _ (List.mem_append_left _ member)

/-- Top is in every next alphabet, including an empty entry alphabet. -/
theorem top_mem_step (alphabet : List Guard) : top ∈ step alphabet := by
  exact List.mem_append_left _ (List.mem_append_right _ (by simp))

/-- Each literal ordered pair of entry guards contributes its actual source conjunction. -/
theorem conjoin_mem_step {alphabet : List Guard} {first second : Guard}
