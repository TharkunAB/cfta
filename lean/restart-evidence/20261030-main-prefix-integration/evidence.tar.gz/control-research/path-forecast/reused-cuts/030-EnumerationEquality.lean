contradiction laws used by constructor-row intersection.
-/

namespace MicroCFTA.EnumerationEquality
open Language EnumerationCorrectness EqualityNormalize

/-- Read a canonical path class through the source trie constructor. -/
def classTrie (paths : Class) : EqualityTrie.Trie :=
  (EqualityTrie.toPathTrie paths.eraseDups).getD .empty

/-- The source stores one trie for each normalized equality class. -/
def readClasses (classes : Constraints) : List EqualityTrie.Trie := classes.map classTrie

/-- Every normalized class has a valid trie with exactly its paths. -/
theorem classTrie_readback (fuel : Nat) (classes output : Constraints)
    (success : mkEqConstraints fuel classes = .normalized output) (paths : Class) (member : paths ∈ output) :
