        SourcePruningEnumerationTerminal.run checkEmpty representativeFuel nativeFuel p h
          first rest waiting beforeCaller before incoming descendants queries

/-- Add the native cache while retaining terminal caller, query and raw effects. -/
noncomputable def run
    (checkEmpty : Bool) (representativeFuel nativeFuel p h indexFuel : Nat)
    (scs : List Suspended) (incoming : Node)
    (beforeCaller : Caller width) (before : EnumerationExpandableIndex.Cached Symbol Constraint)
    (queries : Queries) : Observation width × Option (EnumerationExpandableIndex.Cached Symbol Constraint) :=
  if incoming = .empty then
    ((.ok (some []), beforeCaller, queries, before.core, before.waiting), some before)
  else
    match scs.partition (fun sc => EqualityTrie.isTerminal sc.trie) with
    | ([], _) =>
        (observe checkEmpty representativeFuel nativeFuel p h scs incoming
          beforeCaller before.core before.waiting queries,
          match SourcePruningEnumerationCachedPrepare.prepareChild
              beforeCaller.checked.native.machine.heap indexFuel scs incoming before with
          | some [] => some before
          | some [(_, after)] => some after
          | _ => none)
    | (first :: rest, descendants) =>
        SourcePruningEnumerationCachedTerminalAdapter.run
          checkEmpty representativeFuel nativeFuel p h indexFuel
          first rest beforeCaller before incoming descendants queries

/-- Cache erasure preserves every raw result and reached caller at fixed bounds. -/
theorem erase
    (checkEmpty : Bool) (representativeFuel nativeFuel p h indexFuel : Nat)
    (scs : List Suspended) (incoming : Node)
    (beforeCaller : Caller width) (before : EnumerationExpandableIndex.Cached Symbol Constraint)
    (queries : Queries) :
    (run checkEmpty representativeFuel nativeFuel p h indexFuel
      scs incoming beforeCaller before queries).1 =
      observe checkEmpty representativeFuel nativeFuel p h scs incoming
        beforeCaller before.core before.waiting queries := by
  by_cases empty : incoming = .empty
  · simp only [run, observe, ite_eq_left empty]
  · cases partitioned : scs.partition (fun sc => EqualityTrie.isTerminal sc.trie) with
    | mk here descendants =>
      cases here with
      | nil => simp only [run, ite_eq_right empty, partitioned]
      | cons first rest =>
        simpa only [run, observe, ite_eq_right empty, partitioned] using
          SourcePruningEnumerationCachedTerminalAdapter.erase
            checkEmpty representativeFuel nativeFuel p h indexFuel
