/-- Complete every child or retain the completed prefix and exact stopping receipt. -/
inductive Result (width : Nat) where
  /-- All children return one successful row and a cache. -/
  | complete (fragments : List Fragment) (caller : Caller width) (queries : Queries) (after : Cached)
  /-- Keep the completed fragments and the first stopping observation. -/
  | stopped (completedPrefix : List Fragment) (observation : SourcePruningEnumerationChildDispatch.Observation width)
      (candidate : Option Cached)

variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Run children in order with the reached caller, queries and post-write cache. -/
noncomputable def run
    (checkEmpty : Bool) (representativeFuel nativeFuel p h indexFuel : Nat) :
    List (Node × List Suspended) → Caller width → Cached → Queries → Result width
  | [], caller, before, queries => .complete [] caller queries before
  | (value, bucket) :: rest, caller, before, queries =>
      match SourcePruningEnumerationChildDispatch.run checkEmpty representativeFuel nativeFuel p h indexFuel
          bucket value caller before queries with
      | ((.ok (some [.ok (fragment, _returned)]), reachedCaller, savedQueries, _outer, _waiting), some after) =>
          match run checkEmpty representativeFuel nativeFuel p h indexFuel rest reachedCaller after savedQueries with
          | .complete fragments finalCaller finalQueries final =>
              .complete (fragment :: fragments) finalCaller finalQueries final
          | .stopped completedPrefix observation candidate =>
              .stopped (fragment :: completedPrefix) observation candidate
      | (observation, candidate) => .stopped [] observation candidate

/-- A complete trace records each actual child call at its exact returned core. -/
inductive Trace (checkEmpty : Bool) (representativeFuel nativeFuel p h indexFuel : Nat) :
    List (Node × List Suspended) → Caller width → Cached → Queries →
      List Fragment → Caller width → Cached → Queries → Prop
  /-- An empty child list retains its input state. -/
  | nil (caller : Caller width) (before : Cached) (queries : Queries) :
      Trace checkEmpty representativeFuel nativeFuel p h indexFuel [] caller before queries [] caller before queries
  /-- One actual child result supplies the next child state. -/
  | cons {value : Node} {bucket : List Suspended} {rest : List (Node × List Suspended)}
      {beforeCaller middleCaller afterCaller : Caller width} {before middle after : Cached}
      {queries middleQueries afterQueries : Queries} {fragment : Fragment} {fragments : List Fragment}
      {outer : EnumerationState.State Symbol Constraint} {waiting : EnumerationWaitingIndex.Waiting}
      (head : SourcePruningEnumerationChildDispatch.run checkEmpty representativeFuel nativeFuel p h indexFuel
        bucket value beforeCaller before queries =
        ((.ok (some [.ok (fragment, middle.core)]), middleCaller, middleQueries, outer, waiting), some middle))
      (tail : Trace checkEmpty representativeFuel nativeFuel p h indexFuel rest middleCaller middle middleQueries
        fragments afterCaller after afterQueries) :
      Trace checkEmpty representativeFuel nativeFuel p h indexFuel ((value, bucket) :: rest)
        beforeCaller before queries (fragment :: fragments) afterCaller after afterQueries
