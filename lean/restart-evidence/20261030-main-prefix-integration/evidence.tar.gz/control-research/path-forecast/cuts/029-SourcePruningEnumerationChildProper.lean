/-- The actual child candidate retains proper paths on successful and rejected branches. -/
theorem observed_cache_proper
    (checkEmpty : Bool) (r n p h k : Nat) (scs : List Suspended) (incoming : Node)
    (caller : Caller width) (before : Cached) (queries : Queries)
    (proper : ProperState before.core) (inputs : ProperInputs scs) (after : Cached)
    (candidate : (run checkEmpty r n p h k scs incoming caller before queries).2 = some after) :
    ProperState after.core := by
  by_cases empty : incoming = .empty
  · simp only [run, empty, ↓reduceIte, Option.some.injEq] at candidate
    subst after
    exact proper
  · cases partitioned : scs.partition (fun sc => EqualityTrie.isTerminal sc.trie) with
    | mk here descendants =>
      cases here with
      | nil =>
        apply SourcePruningEnumerationCachedPrepare.cache_proper
          caller.checked.native.machine.heap k scs incoming before after proper inputs
        simp only [run, ite_eq_right empty, partitioned] at candidate
        cases prepared : SourcePruningEnumerationCachedPrepare.prepareChild
            caller.checked.native.machine.heap k scs incoming before with
        | none => simpa only [prepared] using candidate
        | some rows =>
          cases rows with
          | nil => simpa only [prepared] using candidate
          | cons row tail =>
            rcases row with ⟨fragment, reached⟩
            cases tail with
            | nil => simpa only [prepared] using candidate
            | cons next rest => simpa only [prepared] using candidate
      | cons first rest =>
        have descendantsSame : scs.filter (fun sc => !EqualityTrie.isTerminal sc.trie) = descendants := by
          simpa only [List.partition_eq_filter_filter, Function.comp_def] using congrArg Prod.snd partitioned
        have descendantsProper : ∀ sc ∈ descendants, ProperTrie sc.trie := by
          intro sc member
          apply proper_below scs inputs sc
          simpa only [descendantsSame] using member
        apply SourcePruningEnumerationCachedTerminalAdapter.candidate_proper checkEmpty r n p h k
          first rest caller before incoming descendants queries proper descendantsProper after
        simpa only [run, ite_eq_right empty, partitioned] using candidate

/-- An actual successful child derives proper paths at its exact attached cache. -/
