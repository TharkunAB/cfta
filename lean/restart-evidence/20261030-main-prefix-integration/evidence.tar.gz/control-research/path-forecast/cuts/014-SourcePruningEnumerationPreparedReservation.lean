theorem rows_positive (seed : Seed) : 1 ≤ rows seed := by
  unfold rows
  omega

/-- A shorter original ordinary scan fits the positive-depth driver envelope. -/
theorem stage_le_final (depth : Nat) (seed : Seed) (ceiling count : Nat)
    (bounded : count ≤ rows seed) :
    Le (stage depth (preparedSeed seed) ceiling ceiling count).2 (final (depth + 1) seed ceiling).2 ∧
      (stage depth (preparedSeed seed) ceiling ceiling count).1 ⊆ (final (depth + 1) seed ceiling).1 := by
  rw [final_succ]
  exact count_mono depth (preparedSeed seed) ceiling ceiling bounded

/-- A parked route can use the first paired stage without an actual edge execution. -/
theorem first_le_final (depth : Nat) (seed : Seed) (ceiling : Nat) :
    Le (step depth (preparedSeed seed) ceiling ceiling).2 (final (depth + 1) seed ceiling).2 ∧
      (step depth (preparedSeed seed) ceiling ceiling).1 ⊆ (final (depth + 1) seed ceiling).1 :=
  stage_le_final depth seed ceiling 1 (rows_positive seed)

