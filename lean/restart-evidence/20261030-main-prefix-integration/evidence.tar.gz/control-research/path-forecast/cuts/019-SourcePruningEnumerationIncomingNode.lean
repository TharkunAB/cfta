def finish (target handle : Nat) (incomingScs oldScs : List EnumerationState.Suspended)
    (replacement : Node) : EnumerateM Symbol EnumGuard Unit := do
  setValue target (.unenumerated (some handle) (incomingScs ++ oldScs))
  inheritAncestry target
  match replacement with
  | .empty => reject
  | _ => pure ()

/-- Execute the incoming merge and retain the actual reached read endpoint. -/
