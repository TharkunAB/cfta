local notation "Symbol" => SourcePruningTemplates.Symbol
variable {EnumGuard NativeGuard : Type}

/-- Actual own allocation retains every old slot key and the exact expansion history. -/
theorem suspendMany_ancestry_extension
    (heap : InternedConstructorTemplates.State Symbol NativeGuard) (tries : List EqualityTrie.Trie)
    (before after : EnumerationExpandableIndex.Cached Symbol EnumGuard) (suspended : List Suspended)
    (observed : suspendMany heap tries before = some (suspended, after)) :
    Extends before.core after.core ∧ after.core.expansionAncestry = before.core.expansionAncestry := by
  induction tries generalizing before after suspended with
  | nil =>
      have same : ([], before) = (suspended, after) := Option.some.inj observed
      have cacheSame : before = after := congrArg Prod.snd same
      subst after
      exact ⟨Extends.refl before.core, rfl⟩
  | cons trie rest ih =>
      simp only [suspendMany, Option.bind_eq_some_iff, Option.map_eq_some_iff] at observed
      obtain ⟨allocation, allocated, result, continued, same⟩ := observed
      have allocationFields := SourcePruningEnumerationCachedChild.allocate_ancestry_extension allocated
      have resultFields := ih allocation.2 result.2 result.1 continued
      have combined := And.intro (allocationFields.1.trans resultFields.1)
        (resultFields.2.trans allocationFields.2)
      have cacheSame : result.2 = after := congrArg Prod.snd same
      simpa only [cacheSame] using combined

local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint

/-- Each actual own-class row extends the input and retains its expansion history. -/
theorem prepare_ancestry_extension
    {heap : InternedConstructorTemplates.State Symbol Constraint}
    {scs : List Suspended} {edge : InternedConstructorTemplates.EdgeValue Symbol Constraint}
    {before : Cached} {rows : List _}
    (observed : prepare heap scs edge before = some rows) :
    ∀ row ∈ rows, Extends before.core row.2.core ∧
      row.2.core.expansionAncestry = before.core.expansionAncestry := by
  unfold prepare at observed
  split at observed
  · cases projected : SourcePruningEnumerationConstraint.project edge.entry.key.constraint with
    | none =>
        simp only [projected] at observed
        cases observed
    | some projection =>
        obtain ⟨tries, residual⟩ := projection
        simp only [projected] at observed
        obtain ⟨result, suspended, same⟩ := Option.map_eq_some_iff.mp observed
        have resultFields := suspendMany_ancestry_extension heap tries before result.2 result.1 suspended
        intro row member
        rw [← same] at member
        have rowSame := List.mem_singleton.mp member
        cases rowSame
        exact resultFields
  · have rowsSame : [] = rows := Option.some.inj observed
    rw [← rowsSame]
    intro row member
    cases member

end MicroCFTA.SourcePruningEnumerationCachedOwn

namespace MicroCFTA.SourcePruningEnumerationCachedPrepare
open EnumerationState SourcePruningEnumerationAncestryExtension
local notation "Symbol" => SourcePruningTemplates.Symbol
variable {EnumGuard NativeGuard : Type}
