theorem CompletedHeadReceipt.proper
    {seed : Seed} {inherited : Nat}
    {formulas : SourceGuards.Formulas FullSyntax.Formula}
    {solver : SourceGuards.Entailment FullSyntax.Formula} {inventory : Inventory}
    {caller : Caller (bits + 2)} {memos : Memos} {metadata : Metadata Typing} {before : Cached}
    {checkEmpty : Bool} {uv handle : Nat} {scs : List Suspended}
    {parentEntry : Cache.Interned InternedBinderProtocol.NodeKey}
    {storedEdges : List (EdgeValue Symbol Constraint)} {depth : Nat}
    {free : List InternedBinderProtocol.Reference} {edge : EdgeValue Symbol Constraint}
    {bound : Nat} {fragment : Fragments.Fragment Symbol} {reached : Caller (bits + 2)}
    {saved : SourceEndpointMemo.Memos} {after : Cached} {returnedInventory : Inventory} {returnedMemos : Memos}
    (receipt : CompletedHeadReceipt seed inherited formulas solver inventory caller memos metadata before
      checkEmpty uv handle scs parentEntry storedEdges depth free edge bound fragment reached saved after
      returnedInventory returnedMemos)
    (proper : ProperState before.core) : ProperState after.core := by
  obtain ⟨roots, paths, _storage, realized, counts, flags⟩ := receipt.admission.packet.valid
  obtain ⟨tries, residual, projected⟩ := receipt.projected
  have stored := receipt.admission.stored
  have bounded : ∀ sc ∈ scs, sc.var < before.core.counter :=
    receipt.admission.ready.safe.1.values _ (List.mem_of_getElem? stored)
  have inputs : ProperInputs scs :=
    proper_inputs (.unenumerated (some handle) scs) (proper _ (List.mem_of_getElem? stored))
  have inheritedInputs : ValidSuspended scs := fun sc member => (inputs sc member).1
  have pending := EnumerationReferences.pending_inputs before.core receipt.admission.packet.pending
    uv (some handle) scs stored
  have completed := receipt.running 0
  simp only [Nat.add_zero] at completed
  unfold SourcePruningEnumerationCapturedEdge.run at completed
  cases selectedRun : SourcePruningEnumerationSelectedEdge.run checkEmpty bound bound bound bound bound
      scs edge caller before memos.query with
  | unhandled => rw [selectedRun] at completed; cases completed
  | rejected selectedCaller queries selectedCache => rw [selectedRun] at completed; cases completed
  | stopped fragments observation candidate => rw [selectedRun] at completed; cases completed
  | complete produced selectedCaller queries selectedCache =>
      rw [selectedRun] at completed
      simp only [Option.map_eq_some_iff] at completed
      obtain ⟨finished, finishRun, fields⟩ := completed
      have sameCache : finished = after :=
        (SourcePruningEnumerationSelectedEdge.Result.complete.inj fields).2.2.2
