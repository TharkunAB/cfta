theorem edge_shape_from_packet
    (seed : Seed)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : SourceCurrentAllocatedNativeInventoryState.Inventory)
    (caller : Caller width) (memos : Memos) (metadata : Metadata Typing) (before : Cached)
    (packet : SourcePruningEnumerationRecursive.Packet formulas solver inventory caller memos metadata before)
    (bounded : Fits seed.2 caller.checked)
    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)
    (entry : Cache.Interned InternedBinderProtocol.NodeKey)
    (rows : List (EdgeValue Symbol Constraint)) (depth : Nat) (free : List InternedBinderProtocol.Reference)
    (available : Available caller.checked.native.machine.heap (.node entry rows depth free))
    (edge : EdgeValue Symbol Constraint) (selected : edge ∈ rows) :
    edge.children.length ≤ scalar seed.2 ∧
      ∀ tries residual,
        SourcePruningEnumerationConstraint.project edge.entry.key.constraint = some (tries, residual) →
        tries.length ≤ guardWidth seed.1 := by
  have resident : InternedEdgeResidency.EdgeResident caller.checked.native.machine.heap edge :=
    InternedEdgeResidency.resident_edges caller.checked.native.machine.heap
      packet.context.ready.semantic.ready.semantic.1.normal.facts.linked _ available.resident edge selected
  have heapFits : SourceCurrentConstrainedCapRequiredResources.HeapFits seed.2
      caller.checked.native.machine.heap :=
    SourceCurrentConstrainedCapRequiredResources.of_checked
      (profile := seed.2) (before := caller.checked) bounded
  refine ⟨SourceCurrentConstrainedCapRequiredResources.edge_width heapFits edge resident, ?_⟩
  intro tries residual projected
  exact SourcePruningEnumerationGuardWidth.project_le seed.1 edge.entry.key.constraint tries residual
    (known edge.entry.key edge resident) projected
