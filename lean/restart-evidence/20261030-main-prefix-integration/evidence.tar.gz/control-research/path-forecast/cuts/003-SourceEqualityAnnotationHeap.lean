/-- Every actual physical edge key in the constructor cache satisfies the annotation predicate. -/
def Heap (valid : Guard → Prop) (state : State Symbol Guard) : Prop :=
  ∀ key edge, state.edgeRecords key = some edge → valid key.constraint

/-- The empty constructor cache satisfies every source annotation invariant. -/
theorem empty_heap (valid : Guard → Prop) : Heap valid (empty (Symbol := Symbol) (Guard := Guard)) := by
  intro key edge impossible
  cases impossible

/-- Original actual linked records derive their complete semantic annotation invariant from the cache. -/
theorem available (valid : Guard → Prop) (state : State Symbol Guard) (heap : Heap valid state) (linked : Linked state)
    (value : Value Symbol Guard) (resident : Available state value) : Annotated valid value := by
  induction resident with
  | intro value resident issued children ih =>
      cases value with
      | empty => exact .empty
      | reference name => exact .reference name
      | node entry edges depth free =>
          apply Annotated.node
          · intro edge member
            exact heap edge.entry.key edge (resident_edges state linked _ resident edge member)
          · simpa only [InternedProbeProvenance.children] using ih
      | union entry members depth free => exact .union entry members depth free (by simpa only [InternedProbeProvenance.children] using ih)
      | mu entry body depth ordinary => exact .mu entry body depth ordinary (ih body (by simp [InternedProbeProvenance.children]))

/-- A checked actual edge derives its own guard and each child annotation from the same physical heap. -/
theorem edge (valid : Guard → Prop) (state : State Symbol Guard) (heap : Heap valid state) (facts : InternedNestedFacts.Facts state)
    (edge : EdgeValue Symbol Guard) (resident : EdgeResident state edge) :
    valid edge.entry.key.constraint ∧ ∀ child ∈ edge.children, Annotated valid child :=
  ⟨heap edge.entry.key edge resident, fun child member => available valid state heap facts.linked child (facts.cached.edges _ edge resident child member)⟩
