
/-- Suspended references carried by one live pending slot. -/
def references : UVarValue Symbol → List Suspended
  | .unenumerated _ scs => scs
  | _ => []

/-- One candidate insertion adds exactly the current eligible slot index. -/
theorem collect_candidates (graph : Graph Symbol Guard) (roots : Nat → Nat)
    (accumulator : List Nat × List Nat) (entry : UVarValue Symbol × Nat) (uv : Nat) :
    uv ∈ (collectPure graph roots accumulator entry).1 ↔
      uv ∈ accumulator.1 ∨ (uv = entry.2 ∧ candidate graph entry.1 = true) := by
  obtain ⟨value, index⟩ := entry
