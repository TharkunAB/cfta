def HistoryAdmission
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos) (metadata : Metadata Typing) (before : Cached)
    (recursiveFuel : Nat) (seed : Seed) (ceiling : Nat) : Prop :=
  Packet formulas solver inventory caller memos metadata before ∧
  Fits seed.2 caller.checked ∧
  Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap ∧
  suspendedBound before.core ≤ ceiling ∧
  SourcePruningEnumerationPreparedReservation.Reserved bits recursiveFuel seed ceiling

/-- The exact callback input retains its original finite resource plan. -/
def RecursiveCallbackAdmission
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos) (metadata : Metadata Typing) (before : Cached)
    (_uv : Nat) (fragment : Fragment) (recursiveFuel : Nat) (seed : Seed) (ceiling : Nat) : Prop :=
  Packet formulas solver inventory caller memos metadata before ∧
  EnumerationCorrectness.FragmentBound before.core.counter fragment ∧
  Fits seed.2 caller.checked ∧
  Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap ∧
  suspendedBound before.core ≤ ceiling ∧
  SourcePruningEnumerationPreparedReservation.Reserved bits recursiveFuel seed ceiling

/-- A selected invocation retains one actual preparation and its ordinary or opaque completed receipt. -/
def SelectedHistoryReceipt
    (formulas : SourceGuards.Formulas FullSyntax.Formula) (solver : SourceGuards.Entailment FullSyntax.Formula)
    (metadata : Metadata Typing) (checkEmpty : Bool) (workFuel uv : Nat)
    (inventory : Inventory) (caller : Caller (bits + 2)) (memos : Memos) (before : Cached)
    (fragment : Fragment) (reached : Caller (bits + 2)) (after : Cached)
    (returnedInventory : Inventory) (returnedMemos : Memos) : Prop :=
  ∃ (entered : Cached) (handle : Nat) (scs : List Suspended) (decoded prepared : Node)
    (heap : InternedConstructorTemplates.State Symbol Constraint) (preparationBound : Nat),
    Packet formulas solver inventory caller memos metadata before ∧
    EnumerationDriver.Ready uv before.core ∧
    before.core.values[uv]? = some (.unenumerated (some handle) scs) ∧
    (∀ extra, SourcePruningEnumerationSelectedPreparation.run (preparationBound + extra)
      (preparationBound + extra) uv caller before =
        ([.ok ((uv, handle, scs, decoded), entered.core)], some (.done prepared heap))) ∧
    SourcePruningEnumerationSelectedPreparation.run workFuel workFuel uv caller before =
      ([.ok ((uv, handle, scs, decoded), entered.core)], some (.done prepared heap)) ∧
    SourcePruningEnumerationNodes.lookupNode caller.checked.native.machine.heap handle = some decoded ∧
    Post formulas solver inventory caller
      (SourcePruningEnumerationSelectedValueCaller.advance caller heap) memos ∧
    Packet formulas solver inventory
      (SourcePruningEnumerationSelectedValueCaller.advance caller heap) memos metadata entered ∧
    EnumerationDriver.RenderStable before.core entered.core ∧
    EnumerationDriver.Ready uv entered.core ∧
    entered.core.values[uv]? = some (.unenumerated (some handle) scs) ∧
    entered.core.counter = before.core.counter ∧ entered.core.values = before.core.values ∧
    entered.expandable = before.expandable ∧ entered.waiting = before.waiting ∧
    Available heap prepared ∧ prepared.free = [] ∧
    (∀ holds ambient term,
      InternedGuardedLanguage.meaning holds ambient prepared term ↔
        InternedGuardedLanguage.meaning holds ambient decoded term) ∧
    ((∃ (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
        (edges : List (EdgeValue Symbol Constraint)) (depth : Nat)
        (free : List InternedBinderProtocol.Reference) (edge : EdgeValue Symbol Constraint)
        (headSeed : Seed) (inherited : Nat) (headInventory : Inventory)
        (headCaller : Caller (bits + 2)) (headMemos : Memos) (headBound : Nat),
        prepared = .node parentEntry edges depth free ∧
        scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = false ∧
        Post formulas solver headInventory
          (SourcePruningEnumerationSelectedValueCaller.advance caller heap) headCaller headMemos ∧
        SourcePruningEnumerationCapturedEdge.run checkEmpty workFuel workFuel workFuel workFuel workFuel
          uv scs edge headCaller entered headMemos.query =
            some (.complete fragment reached returnedMemos.query after) ∧
        SourcePruningEnumerationPreparedNativeHookResources.CompletedHeadReceipt headSeed inherited formulas solver
          headInventory headCaller headMemos metadata entered checkEmpty uv handle scs parentEntry edges depth free edge
          headBound fragment reached returnedMemos.query after returnedInventory returnedMemos) ∨
      ((match (generalizing := false) prepared with
        | .node .. => !(scs.any (fun sc => EqualityTrie.isTerminal sc.trie))
        | _ => false) = false ∧
        SourcePruningEnumerationSelectedOpaqueDispatch.run checkEmpty workFuel workFuel workFuel workFuel workFuel
          uv scs prepared (SourcePruningEnumerationSelectedValueCaller.advance caller heap) entered memos.query =
            some (.complete fragment reached returnedMemos.query after) ∧
        Post formulas solver returnedInventory
          (SourcePruningEnumerationSelectedValueCaller.advance caller heap) reached returnedMemos ∧
        Packet formulas solver returnedInventory reached returnedMemos metadata entered ∧
        Packet formulas solver returnedInventory reached returnedMemos metadata after ∧
        SourcePruningEnumerationNativeBranchCompletion.Admitted uv
          (.complete fragment reached returnedMemos.query after) ∧
        SourcePruningEnumerationNativeBranchCompletion.Pending
          (.complete fragment reached returnedMemos.query after) ∧
        SourcePruningEnumerationNativeBranchCompletion.FragmentHistory entered.core
          (.complete fragment reached returnedMemos.query after)))

