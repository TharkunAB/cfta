        (SourcePruningEnumerationSelectedEdge.Result.complete.inj fields).2.2.2
      rw [← sameCache]
      exact SourcePruningEnumerationFinalize.run_proper selectedCaller.checked.native.machine.heap bound uv
        produced selectedCache finished
        (SourcePruningEnumerationSelectedEdge.complete_proper caller before checkEmpty
          parentEntry storedEdges depth free edge scs roots memos receipt.admission.packet.context
          receipt.admission.parentAvailable receipt.admission.parentClosed receipt.admission.selected
          receipt.admission.ready.safe realized paths counts flags bounded pending receipt.allowed
          tries residual projected proper inheritedInputs selectedRun) finishRun
