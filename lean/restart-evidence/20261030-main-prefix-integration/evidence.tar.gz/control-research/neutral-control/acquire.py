from pathlib import Path
import hashlib, json, sys

area = Path(__file__).parent
root = Path('/home/tritlo/Code/mcfta')
source = Path(sys.argv[1])
if not source.is_absolute():
    source = root / source
start = int(sys.argv[2])
data = source.read_bytes()
lines = data.splitlines(keepends=True)
requested_end = sys.argv[3]
end = len(lines) if requested_end == 'all' else int(requested_end)
actual_end = min(end, len(lines))
assert 1 <= start <= actual_end
copy = b''.join(lines[start-1:actual_end])
name = sys.argv[4]
destination = area / 'sources' / name
destination.parent.mkdir(exist_ok=True)
assert not destination.exists()
destination.write_bytes(copy)
manifest = area / 'source-scope.json'
rows = json.loads(manifest.read_text()) if manifest.exists() else []
whole = start == 1 and actual_end == len(lines)
row = dict(source=str(source), source_bytes=len(data), source_sha256=hashlib.sha256(data).hexdigest(), source_lines=len(lines), requested_start=start, requested_end=requested_end, actual_start=start, actual_end=actual_end, whole=whole, task_source=source.name in set(), copy=str(destination.relative_to(area)), copy_bytes=len(copy), copy_sha256=hashlib.sha256(copy).hexdigest())
rows.append(row)
assert sum(x['whole'] and x['source'].endswith('.lean') and not x['task_source'] for x in rows) <= 4
manifest.write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(row))
print(copy.decode())
