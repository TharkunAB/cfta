  refine ⟨readFuel, handle, scs, value, readAfter, checkFuel, repeated, after, stored, decoded,
    available, closed, readExact, readFrame, checkExact, afterReady, afterPaths, afterRealized,
    afterCounts, afterFlags, incoming, pending, continued, ?_, parked⟩
  intro repeatedTrue
  obtain ⟨_boundary, _cleared, _disabled, _waiting, resolved, _countFuel, frame, _readRoot,
    _seen, written, _indexed⟩ := parked repeatedTrue
  exact parked_order uv handle scs before.core resolved after.core stored frame written

local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Metadata" => SourcePruningRecordTypes.Metadata
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
variable {Typing : Type} {width : Nat}

/-- Rebuild the cleared slot's flag and remove its original suspended counts. -/
