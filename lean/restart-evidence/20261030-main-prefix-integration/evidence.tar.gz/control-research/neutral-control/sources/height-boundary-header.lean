import MicroCFTA.SourceEqualityWarmNativeEdge
import MicroCFTA.MergedOrdinaryHeight

/-!
# Ordinary height can increase before the next recursive source call

Both selected endpoints are ordinary wrappers. Their children are raw
closed binders with constrained bodies. The gate accepts the endpoints.
Native intersection removes the unused binders and exposes their common
constrained ordinary body. The next child exceeds the original root height.
This is a counterexample to a proposed measure, not to termination.
-/
namespace MicroCFTA.SourceEqualityPartialHeightBoundary
open InternedConstructorTemplates InternedNestedConstruction
open SourceObservations SourceSymbolicIndex SourceEqualityClassFoldGraph
local notation "Symbol" => Label FullSyntax.Formula
local notation "Guard" => Constraint FullSyntax.Formula
local notation "top" => SourceEqualityConstraintConstructors.top (Formula := FullSyntax.Formula)

set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
set_option cbv.maxSteps 200000000

attribute [local cbv_eval] SourceCompactGuards.arrayNormalize_eq

private instance : DecidableEq FullSyntax.Formula :=
  fun first second => decidable_of_iff (FormulaOrder.compareFormula first second = .eq) (FormulaOrder.formula_eq first second)

private instance : DecidableEq (SourceGuards.Guard FullSyntax.Formula) := SourceEqualityPCSNativeEdge.guardDecidableEq

private instance : DecidableEq Guard := fun first second =>
  decidable_of_iff (first.equalities = second.equalities ∧ first.guard = second.guard)
