import MicroCFTA.SourcePruningEnumerationRecursion
import MicroCFTA.EnumerationPendingOrder
import MicroCFTA.SourcePruningEnumerationRestart

namespace MicroCFTA.SourcePruningEnumerationParkedRestart
open EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationCompressionFrame
open InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes SourcePruningEnumerationObservation
local notation "Symbol" => SourcePruningTemplates.Symbol
variable {EnumGuard NativeGuard : Type}

/-- The actual pending-bucket clear retains the allocation counter and dependency levels. -/
theorem parked_order
