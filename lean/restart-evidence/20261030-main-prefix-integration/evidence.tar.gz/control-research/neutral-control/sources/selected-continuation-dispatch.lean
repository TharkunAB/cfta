local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Core" => EnumerationState.State Symbol Constraint
local notation "Raw" => List (Except EnumerationState.Error ((Nat × Nat × List Suspended × Node) × Core))
local notation "Preparation" => Raw × Option (MergedSourceComparison.Result Symbol Constraint Node)
local notation "HookResult" => SourcePruningEnumerationNativeContinuations.HookResult
local notation "Fold" => SourcePruningEnumerationNativeContinuations.Result
universe u v
variable {Typing : Type} {width : Nat} {Output : Type u} {Reason : Type v}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Prepare once and run the actual branch with its hook in source order. -/
noncomputable def run
    (hook : Fragment → Caller width → Queries → Cached → HookResult Output Reason width)
    (checkEmpty : Bool) (entryFuel nativeFuel r n p h k uv : Nat)
    (edgesOf : Node → List (EdgeValue Symbol Constraint)) (caller : Caller width)
    (before : Cached) (queries : Queries) : Preparation × Option (Fold Output Reason width) :=
  let observation := SourcePruningEnumerationSelectedPreparation.run entryFuel nativeFuel uv caller before
  (observation, match observation.2 with
    | some (.done value heap) =>
        match observation.1 with
        | [.ok ((target, _handle, scs, _decoded), entered)] =>
            some (if scs.any (fun sc => EqualityTrie.isTerminal sc.trie) then
              SourcePruningEnumerationReceiptContinuation.run hook
                (SourcePruningEnumerationSelectedOpaqueDispatch.run checkEmpty r n p h k target scs value
                  (SourcePruningEnumerationSelectedValueCaller.advance caller heap)
                  (EnumerationExpandableIndex.frame entered before) queries)
            else match value with
              | parent@(.node ..) =>
                  SourcePruningEnumerationNativeContinuations.run hook checkEmpty r n p h k target scs
                    (EnumerationExpandableIndex.frame entered before) (edgesOf parent)
                    (SourcePruningEnumerationSelectedValueCaller.advance caller heap) queries
              | _ =>
                  SourcePruningEnumerationReceiptContinuation.run hook
                    (SourcePruningEnumerationSelectedOpaqueDispatch.run checkEmpty r n p h k target scs value
                      (SourcePruningEnumerationSelectedValueCaller.advance caller heap)
                      (EnumerationExpandableIndex.frame entered before) queries))
        | _ => none
    | _ => none)

/-- Every actual entry row and native preparation outcome remains exact. -/
theorem preparation_readback
    (hook : Fragment → Caller width → Queries → Cached → HookResult Output Reason width)
    (checkEmpty : Bool) (entryFuel nativeFuel r n p h k uv : Nat)
    (edgesOf : Node → List (EdgeValue Symbol Constraint)) (caller : Caller width)
    (before : Cached) (queries : Queries) :
    (run hook checkEmpty entryFuel nativeFuel r n p h k uv edgesOf caller before queries).1 =
      SourcePruningEnumerationSelectedPreparation.run entryFuel nativeFuel uv caller before := rfl

/-- Ordinary siblings run at each preceding hook's actual returned native endpoint. -/
