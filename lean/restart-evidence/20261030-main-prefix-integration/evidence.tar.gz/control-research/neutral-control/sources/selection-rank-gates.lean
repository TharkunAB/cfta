/-- Apply the source preference rule to the pure candidate-minus-waiting result. -/
def next (preference : List Nat → Option Nat) (state : Cached Symbol Guard) : Next :=
  pickNext preference (find state)

/-- Execute the pure lookup through the existing source CPS state operation. -/
def findAction : EnumerationCPS.Computation (Cached Symbol Guard) (Option (List Nat)) :=
  EnumerationCPS.state fun state => (find state, state)

/-- Pure cached lookup returns one result with the complete input state unchanged. -/
theorem findAction_represents : EnumerationCPS.Represents
    (findAction : EnumerationCPS.Computation (Cached Symbol Guard) (Option (List Nat)))
    (fun state => [(find state, state)]) :=
  EnumerationCPS.state_represents (fun state => (find state, state))

/-- Canonical cached selection equals the full slot scan's mathematical summary. -/
theorem find_exact (graph : Graph Symbol Guard) (roots : Nat → Nat) (state : Cached Symbol Guard)
    (correct : Correct graph roots state) :
    find state = let summary := state.core.values.zipIdx.foldl (collectPure graph roots) ([], [])
      offered summary.1 summary.2 := by
  have candidatesSame : EnumerationIndexSelection.candidates state =
      (state.core.values.zipIdx.foldl (collectPure graph roots) ([], [])).1 := by
    rw [candidates_exact graph roots state correct, EnumerationIndexSelection.candidate_fold]
    rfl
  have blocked (uv : Nat) : state.waiting uv ≠ none ↔
      uv ∈ (state.core.values.zipIdx.foldl (collectPure graph roots) ([], [])).2 :=
    (EnumerationCanonicalWaiting.support_exact roots state.core.values state.waiting correct.waiting uv).trans
      (EnumerationIndexSelection.scan_blocked graph roots state.core.values uv).symm
  unfold find
  rw [candidatesSame]
  unfold offered
  dsimp only
  split
  · rfl
  · congr 1
    apply List.filter_congr
    intro uv _
    cases stored : state.waiting uv with
    | none =>
        have absent : uv ∉ (state.core.values.zipIdx.foldl (collectPure graph roots) ([], [])).2 :=
          fun present => (blocked uv).mpr present stored
        simp [absent]
    | some count =>
        have present := (blocked uv).mp (by simp [stored])
        simp [present]

/-- Every successful old scan agrees with pure selection and retains the full compression frame. -/
theorem scan_agrees (graph : Graph Symbol Guard) (roots : Nat → Nat) (state : Cached Symbol Guard)
    (correct : Correct graph roots state) (paths : Roots state.core.representatives roots)
    (fuel : Nat) (result : Option (List Nat)) (after : State Symbol Guard)
    (success : Success (findExpandable graph fuel) state.core result after) :
    result = find state ∧ EnumerationCompressionFrame.Frame state.core after := by
  have total : UnionFind.Total state.core.representatives := by
    intro uv
    obtain ⟨size, path⟩ := paths uv
    exact ⟨roots uv, size, path⟩
  exact ⟨(findExpandable_exact graph fuel roots state.core after result paths success).2.trans
    (find_exact graph roots state correct).symm,
    EnumerationCompressionFrame.findExpandable_frame graph fuel state.core after result total success⟩

/-- A total representative interpretation supplies a finite old scan for the same pure selection. -/
theorem scan_complete (graph : Graph Symbol Guard) (roots : Nat → Nat) (state : Cached Symbol Guard)
