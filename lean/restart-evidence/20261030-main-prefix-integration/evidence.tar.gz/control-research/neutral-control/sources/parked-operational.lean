/-- Rebuild the cleared slot's flag and remove its original suspended counts. -/
def adapt
    (heap : InternedConstructorTemplates.State Symbol Constraint)
    (indexFuel uv handle : Nat) (scs : List Suspended)
    (before : Cached) (checked : EnumerationState.State Symbol Constraint) : Option Cached :=
  (SourcePruningEnumerationNativeIndex.write heap indexFuel uv (.unenumerated (some handle) []) [] scs
    (EnumerationExpandableIndex.frame checked before)).map (EnumerationExpandableIndex.frame checked)

/-- An attached parked cache retains the exact observed check endpoint. -/
theorem adapt_core
    (heap : InternedConstructorTemplates.State Symbol Constraint)
    (indexFuel uv handle : Nat) (scs : List Suspended)
    (before after : Cached) (checked : EnumerationState.State Symbol Constraint)
    (adapted : adapt heap indexFuel uv handle scs before checked = some after) :
    after.core = checked := by
  simp only [adapt, Option.map_eq_some_iff] at adapted
  obtain ⟨cached, _written, same⟩ := adapted
  subst after
  rfl

/-- The actual clear write supplies the same rebuilt parked cache after observation. -/
theorem adapt_after_write
    (heap : InternedConstructorTemplates.State Symbol Constraint)
    (indexFuel uv handle : Nat) (scs : List Suspended)
    (before after : Cached) (resolved checked : EnumerationState.State Symbol Constraint)
    (written : Success (setValue uv (.unenumerated (some handle) [])) resolved () checked)
    (indexed : SourcePruningEnumerationNativeIndex.write heap indexFuel uv
      (.unenumerated (some handle) []) [] scs (EnumerationExpandableIndex.frame resolved before) = some after)
    (core : after.core = checked) :
    adapt heap indexFuel uv handle scs before checked = some after := by
  have shape := (EnumerationDriver.modify_success _ resolved checked).mp written
  have forest : checked.representatives = resolved.representatives := by rw [shape]
  have same : adapt heap indexFuel uv handle scs before checked =
      (SourcePruningEnumerationNativeIndex.write heap indexFuel uv (.unenumerated (some handle) []) [] scs
        (EnumerationExpandableIndex.frame resolved before)).map (EnumerationExpandableIndex.frame checked) := by
    unfold adapt SourcePruningEnumerationNativeIndex.write
    dsimp only [EnumerationExpandableIndex.frame]
    rw [forest]
    cases SourcePruningEnumerationNativeIndex.candidate heap (.unenumerated (some handle) []) with
    | none => rfl
    | some _flag =>
        cases SourcePruningEnumerationNativeIndex.count indexFuel resolved.representatives (-1) scs before.waiting <;> rfl
  rw [same, indexed, Option.map_some, ← core]
  rfl

/-- Read and check once, then restart with rebuilt indexes on the repeated branch. -/
def run
    (heap : InternedConstructorTemplates.State Symbol Constraint)
    (readFuel checkFuel indexFuel uv : Nat)
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing)
    (before : Cached) : EnumerateM Symbol Constraint (Option (Metadata Typing × Option Next)) :=
  fun state =>
    (ExceptT.run (getValue readFuel uv state)).flatMap fun row =>
      match row with
      | .error error => [.error error]
      | .ok (.unenumerated (some handle) scs, readAfter) =>
          (ExceptT.run (SourcePruningEnumerationRecursion.checkRepeated heap checkFuel uv handle scs readAfter)).flatMap
            fun checkedRow => match checkedRow with
            | .error error => [.error error]
            | .ok (false, checked) => [.ok (none, checked)]
            | .ok (true, checked) =>
                match adapt heap indexFuel uv handle scs before checked with
                | none => [.error .representativeFuel]
                | some parked =>
                    (ExceptT.run (SourcePruningEnumerationRestart.run stop order metadata parked checked)).map
                      fun restarted => match restarted with
                      | .error error => .error error
                      | .ok (result, final) => .ok (some result, final)
      | .ok _ => []

/-- Actual read, check and index observations derive the exact parked restart result. -/
