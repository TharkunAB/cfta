  exact ⟨⟨storage, scan_live before after roots paths valid safe.2⟩, counter⟩

/-- The selected allocated root has no self-reference in its pending constraints. -/
structure Ready (uv : Nat) (state : State Symbol Guard) : Prop where
  safe : Safe state
  inside : uv < state.counter
  root : IsRoot state.representatives uv
  avoids : ∀ node scs, state.values[uv]? = some (.unenumerated (some node) scs) →
    Avoids state.representatives uv scs

/-- Scheduler selection establishes the precondition for the caller's final write. -/
theorem findExpandable_ready (graph : Graph Symbol Guard) (fuel uv : Nat) (before after : State Symbol Guard)
