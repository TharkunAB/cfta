    exact (EqualityTrie.arity_exact sc.trie (valid sc member) arity).mp (bounds sc member)

/-- An ordering hint can select only a variable offered by the scheduler. -/
theorem pickNext_safe (preference : List Nat → Option Nat) (offered : List Nat) (uv : Nat)
    (selected : pickNext preference (some offered) = .expand uv) : uv ∈ offered := by
  cases offered with
  | nil => cases selected
  | cons first rest =>
      unfold pickNext at selected
      cases choice : preference (first :: rest) with
      | none => simp [choice] at selected; subst uv; simp
      | some wanted =>
          by_cases present : wanted ∈ first :: rest
          · simp [choice, present] at selected
            subst uv
            exact present
          · simp [choice, present] at selected
            subst uv
            simp
