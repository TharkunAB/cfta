open EnumerationState EnumerationCorrectness InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes SourcePruningEnumerationObservation
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Post)
open SourcePruningEnumerationRecursive (Packet)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Core" => EnumerationState.State Symbol Constraint
local notation "Raw" => List (Except EnumerationState.Error ((Nat × Nat × List Suspended × Node) × Core))
variable {Typing : Type} {width : Nat}
private theorem satisfies_read (language : NodeLanguage Symbol)
    (meaning : Constraint → Language.Term Symbol → Prop) (assignment : Nat → Language.Term Symbol)
    (before after : Core) (stable : EnumerationDriver.RenderStable before after) :
    Satisfies language meaning assignment after ↔ Satisfies language meaning assignment before := by
  have classes : UnionFind.Satisfies after.representatives assignment ↔
      UnionFind.Satisfies before.representatives assignment := by
    constructor
    · intro satisfied left right related
      exact satisfied left right ((stable.classes left right).mpr related)
    · intro satisfied left right related
      exact satisfied left right ((stable.classes left right).mp related)
  simp only [Satisfies, Fragments.stateSatisfies, stable.values, stable.obligations, classes]

variable [DecidableEq (EdgeKey Symbol Constraint)]

/-- Retain the complete entry observation and every actual native preparation outcome. -/
def run (entryFuel nativeFuel uv : Nat) (caller : Caller width) (before : Cached) :
    Raw × Option (MergedSourceComparison.Result Symbol Constraint Node) :=
  let raw := ExceptT.run (SourcePruningEnumerationEntry.enter caller.checked.native.machine.heap
    entryFuel uv before.core)
  (raw, match raw with
    | [.ok ((_target, _handle, _scs, value), _entered)] =>
        some (SourcePruningEnumerationSelectedValue.run nativeFuel value caller.checked.native.machine.heap)
    | _ => none)

/-- Original selected storage derives one stable preparation and its full forward-model packet. -/
theorem complete
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (caller : Caller width) (memos : Memos) (metadata : SourcePruningRecordTypes.Metadata Typing)
    (before : Cached) (uv handle : Nat) (scs : List Suspended)
    (packet : Packet formulas solver inventory caller memos metadata before)
    (ready : EnumerationDriver.Ready uv before.core)
    (stored : before.core.values[uv]? = some (.unenumerated (some handle) scs)) :
    ∃ (bound : Nat) (decoded result : Node) (heap : InternedConstructorTemplates.State Symbol Constraint) (entered : Cached),
      (∀ extra, run (bound + extra) (bound + extra) uv caller before =
        ([.ok ((uv, handle, scs, decoded), entered.core)], some (.done result heap))) ∧
      lookupNode caller.checked.native.machine.heap handle = some decoded ∧
      Post formulas solver inventory caller
        (SourcePruningEnumerationSelectedValueCaller.advance caller heap) memos ∧
      Packet formulas solver inventory
        (SourcePruningEnumerationSelectedValueCaller.advance caller heap) memos metadata entered ∧
      EnumerationDriver.RenderStable before.core entered.core ∧
      EnumerationDriver.Ready uv entered.core ∧
      entered.core.values[uv]? = some (.unenumerated (some handle) scs) ∧
      entered.core.counter = before.core.counter ∧ entered.core.values = before.core.values ∧
      entered.expandable = before.expandable ∧ entered.waiting = before.waiting ∧
