  bind_assoc := by intros; exact List.flatMap_assoc

/-- The increasing finite view of the cached expandable set uses the allocated slot domain. -/
def candidates (state : Cached Symbol Guard) : List Nat :=
  (List.range state.core.counter).filter state.expandable

/-- The finite map's key enumeration contains exactly its stored entries. -/
def WaitingKeys (state : Cached Symbol Guard) (keys : List Nat) : Prop :=
  ∀ uv, uv ∈ keys ↔ state.waiting uv ≠ none

/-- The new source fold resolves a raw waiting-map key. -/
def resolveKey (fuel : Nat) (blocked : List Nat) (uv : Nat) : EnumerateM Symbol Guard (List Nat) :=
  resolve fuel blocked ⟨.terminal, uv⟩

/-- Indexed scheduling traverses only the waiting keys before it subtracts blocked representatives. -/
def findIndexed (fuel : Nat) (candidates keys : List Nat) : EnumerateM Symbol Guard (Option (List Nat)) := do
  let blocked ← keys.foldlM (resolveKey fuel) []
  finishScan (candidates, blocked)

/-- Each actual indexed lookup returns the same canonical representative as the old slot fold. -/
theorem resolveKey_scan (values : List (UVarValue Symbol)) (roots : Nat → Nat)
    (fuel : Nat) (blocked result : List Nat) (uv : Nat) (before after : State Symbol Guard)
    (valid : ScanValid values roots before) (success : Success (resolveKey fuel blocked uv) before result after) :
