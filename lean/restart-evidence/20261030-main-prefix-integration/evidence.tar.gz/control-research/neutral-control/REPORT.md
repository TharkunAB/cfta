# Neutral control and parked progress

Status: source-only review and theorem plan. No compiler, evaluator, native run, Git, network or board command was run by this owner. No repository source was changed. All earlier bundles remain immutable. The full global, public and Haskell objective remains active.

## Result

The best immediate control theorem is exact progress for the actual repeated-boundary parked transition. It requires no accepting model and no future worker or resource supplier. It can strengthen the existing producer without changing its inputs, witnesses or operational observations.

Use the existing measure:

```lean
(EnumerationIndexSelection.candidates state).length
```

`EnumerationIndexSelection.candidates` is exactly `(List.range state.core.counter).filter state.expandable` at source lines38–39. A successful actual parked transition removes exactly its selected candidate. The strongest target equation is:

```lean
(EnumerationIndexSelection.candidates after).length + 1 =
  (EnumerationIndexSelection.candidates before).length
```

This equation implies strict decrease and bounds a consecutive parked-only block by the original number of candidates. It is a proposed theorem in this bundle. It has not been compiled or proved here.

## Original inputs already contain the required true flag

`SourcePruningEnumerationSelection.offered` at source lines11–22 already proves:

```lean
selection : EnumerationPureSelection.next preference before = .expand uv
-- implies
uv < before.core.counter ∧ before.expandable uv = true ∧ before.waiting uv = none
```

No Safe, CacheValid, accepting model or other premise is needed for this extraction. The existing parked producers already have this exact selection premise. Reuse `offered`; do not add a new selection helper or top-level flag premise.

`EnumerationDriver.Ready` at lines397–402 has Safe, allocated index, representative-root and incoming-avoidance fields. It does not mention the cached expandable function. Ready alone therefore does not supply the needed true flag. The proof must use the original actual `.expand` selection.

## Exact producer and proof plan

The most complete parked receipt interface is `SourcePruningEnumerationParkedRestart.selected_complete_with_order` at lines33–87. It preserves the original stored pending slot; decoded, available and closed native value; exact read and check observations for all extra work; read compression frame; Ready; roots; native realization; waiting and flag equations; incoming avoidance; pending-reference retention; unchanged state on the non-repeated branch; unchanged counter and dependency levels on the repeated branch; the cleared slot, disabled flag and waiting subtraction; and the actual representative, history-membership, setValue and indexed-write receipts.

The strongest restart interface is `SourcePruningEnumerationParkedRestart.selected_complete_with_restart` at lines207–251. Its only original inputs are caller, cached state, preference, selected index, Safe, CacheValid and actual `.expand` selection. It retains stable reads and repeated checks, CacheValid, Safe and pending-reference retention. Its repeated case retains the unchanged counter and dependency levels and a single countFuel bound that works for every extra amount, stop function, order function and metadata. Its exact configured restart result includes the empty stuck result. It does not silently convert stuck to another result.

The complete append-only strengthened statements for both interfaces are in `STRONGER_STATEMENTS.md`. They retain every old conjunct and add the selected true flag and the exact repeated-case flag/count equations. The added equations are conditional only on repeated=true. The original output contract remains unconditional.

Implement in this order:

1. Call `SourcePruningEnumerationSelection.offered before preference uv selection` once. Retain the bound and true flag.
2. Obtain the existing full `selected_complete_with_order` witnesses once. Keep its actual `parked` receipt. Do not independently call two producers and assume their existential states coincide.
3. In repeated=true, use the original `parked` receipt. It supplies the decoded boundary value and `indexed : ∀ extra, NativeIndex.write heap (countFuel + extra) uv (.unenumerated (some handle) []) [] scs (frame resolved before) = some after`.
4. Specialize indexed at extra=0. `NativeIndex.candidate` at lines17–26 reduces the cleared boundary slot to `some false`, using the existing decoded and boundary facts. `NativeIndex.write` at lines41–51 changes only this flag. Framing preserves the original flags. Derive the exact equation for all indices: `after.expandable other = if other = uv then false else before.expandable other`.
5. Reuse the old repeated-case counter equation. Expand candidates, replace the counter and flags, and use the original bound and true flag. The finite range has no duplicates. Filtering out one present selected index reduces length by exactly one. A short generic finite-list removal lemma or induction on the counter suffices. No semantic term or pending-model cost is needed.
6. Return every original witness and old clause unchanged, then append the new facts. This proves the full parked receipt strengthening.
7. Build the restart strengthening from that same stronger full receipt. Follow the existing selected_complete_with_restart proof at lines232–251. Rebuild CacheValid and Safe as before. Use the exact original read/check/index receipts with `run_parked_after_write`. Append the already derived count result. Do not replace the old exact result with a weaker success-exists statement.

A candidate-list removal equation is also available: after.candidates equals before.candidates with uv removed. The numerical +1 equation is enough for the next control bound and avoids adding an unnecessary public abstraction.

## Remaining neutral control cases

The actual `PreparedRecursive.resume` recurs after a parked restart or a successful receipt hook. Failed, rejected, unsupported, stopped, done and empty results do not create another recursive call in that branch. Finite sibling scans still require bounds for their earlier recursive hooks, even if a later accepting branch is known.

| Route | Existing structural facts | Remaining control obligation |
| --- | --- | --- |
| Repeated boundary, parked restart | Selected flag becomes false; counter and dependency levels remain fixed; exact waiting subtraction and restart are available. | The exact candidate-count theorem above. |
| Ordinary constructor receipt | Original producer retains its native, cache, output and callback effects. Chosen-model constructor/callback progress is already available upstream. | A model-independent rank for the effective prepared child transition, including unsuccessful earlier branches. Plain original ordinary height does not work. |
| Terminal inherited constraint, including an ordinary incoming value | SelectedContinuations sends it through actual opaque dispatch and ChildDispatch's terminal adapter. Finalize stores the fragment at the captured raw target. | A structural bound for terminal unification and any resulting child obligations. Do not count this route as an ordinary constructor decrease without proof. |
| Nonterminal opaque value | ChildDispatch's shallow/cached prepare can allocate a fresh pending child. Finalize then writes the captured original target. | A structural control statement for the actual allocation and finalization. Pending-slot count alone is not justified as a strict measure. |
| Fresh selected mu/union entry | Entry.enter records the key before SelectedValue unfolds mu or exposes union. | Parent's model-independent key carrier/budget remains separate from the bounds for intervals between these entries. |

`SourcePruningEnumerationAction.prepare_boundary_retained` only states identity when the resulting narrowed value is a boundary. It does not bound a resulting ordinary value. `MergedOrdinaryHeight.child_lt` applies to literal children of an ordinary value. It does not transfer through arbitrary native equality narrowing.

## Existing checked obstruction to plain ordinary height

`SourceEqualityPartialHeightBoundary` is an existing Lean module imported by Audit at line2615. Its `actual_heights` theorem at lines79–80 proves, by kernel cbv:

```lean
heights = some (2, 1, 3)
```

These are the original parent height, original child height and actual equality-narrowed child height. `not_parent_height_bound` at lines88–92 explicitly refutes the proposed original-parent bound. The source fixture is closed, scoped and has normalized valid annotations (`source_valid`, lines56–63). The actual native equality edge worker exposes bodies below closed binders and can raise ordinary child height above the original parent.

This existing result blocks a naive neutral rank based on the original parent's ordinary height. It does not prove an infinite worker run, an admitted all-capacity earlier-failure counterexample, global nontermination, loss of public coverage or a Haskell defect. This owner did not rerun the theorem.

A finite carrier of selected recursion keys does not by itself establish acyclicity of the effective ordinary prepared transition. A later global rank must account for native equality narrowing and preparation, not just literal source child edges. Do not add a future transition rank, closure certificate or worker-resource supplier as an unexplained new top-level premise.

## Full objective and Haskell boundary

The new statement would prove a model-independent finite bound for consecutive parked transitions in the exact prepared control flow. It would not prove global sufficient recursive depth, bounds for unproductive ordinary alternatives, full unfolding/public coverage or Haskell correspondence.

The distinct Recursive and PreparedRecursive workers remain in scope. This review pins PreparedRecursive's actual resume and the shared parked producer. It does not equate their failure types, packet types or recursive transitions. The separate Recursive operational specialization still requires its own check when the global proof is composed.

No Haskell source fix or new Haskell defect was established by this review. The height counterexample must be recorded as a rejected measure if added to FINDINGS. It must not be reported as a Haskell regression. Parent owns the new main integration and the required Haskell FINDINGS updates.

## Scope and evidence

`source-scope.json` records each acquisition's requested and actual lines, full-source byte count and SHA256, copy byte count and SHA256, and whole/cut classification. Exactly four old Lean sources were acquired whole: PreparedRecursive (120 lines), MergedOrdinaryHeight (179), BoundaryAction (63), and SelectedStep (228). Every other Lean acquisition is an exact cut. No request was clamped to EOF or relabelled as a partial source.

Some broad locator output was truncated. No semantic claim relies on a truncated locator. The reviewed source cuts are complete and saved separately. The initial active-candidates cut covered setup rather than the definition; the separate active-candidate-definition cut records the exact definition and is used above.

`VALIDATION.json` records the final measured validation time, acquisition counts, current full-source hash checks and byte-for-byte source-copy endpoint checks. It also records any drift. `pins.json` and `FROZEN.json` seal only this owner bundle. They do not claim compiler validation.
