# Source-only strengthened parked contracts

These statements are not compiled or proved in this bundle. They preserve every clause in the named old theorem. The appended facts use the same existential witnesses. No new premise is added. The source context is recorded in sources/parked-header.lean and sources/parked-typed-context.lean.

## Full parked receipts

The original statement occurs at SourcePruningEnumerationParkedRestart.lean:33. The measure uses the existing finite candidate list.

```lean
theorem selected_complete_with_order_progress
    (heap : InternedConstructorTemplates.State Symbol NativeGuard)
    (before : EnumerationExpandableIndex.Cached Symbol EnumGuard)
    (preference : List Nat → Option Nat) (uv : Nat) (roots : Nat → Nat)
    (safe : Safe before.core)
    (selection : EnumerationPureSelection.next preference before = .expand uv)
    (realized : PendingRealized heap before.core)
    (paths : Roots before.core.representatives roots)
    (counts : EnumerationCanonicalWaiting.Correct roots before.core.values before.waiting)
    (flags : ∀ slot, SourcePruningEnumerationNativeIndex.candidate heap
      ((before.core.values[slot]?).getD .eliminated) = some (before.expandable slot)) :
    ∃ (readFuel handle : Nat) (scs : List Suspended) (value : Value Symbol NativeGuard)
      (readAfter : EnumerationState.State Symbol EnumGuard) (checkFuel : Nat) (repeated : Bool)
      (after : EnumerationExpandableIndex.Cached Symbol EnumGuard),
      before.core.values[uv]? = some (.unenumerated (some handle) scs) ∧
      lookupNode heap handle = some value ∧ Available heap value ∧ value.free = [] ∧
      (∀ extra, ExceptT.run (getValue (readFuel + extra) uv before.core) =
        [.ok (.unenumerated (some handle) scs, readAfter)]) ∧
      Frame before.core readAfter ∧
      (∀ extra, ExceptT.run (SourcePruningEnumerationRecursion.checkRepeated heap
        (checkFuel + extra) uv handle scs readAfter) = [.ok (repeated, after.core)]) ∧
      EnumerationDriver.Ready uv after.core ∧ Roots after.core.representatives roots ∧
      PendingRealized heap after.core ∧
      EnumerationCanonicalWaiting.Correct roots after.core.values after.waiting ∧
      (∀ slot, SourcePruningEnumerationNativeIndex.candidate heap
        ((after.core.values[slot]?).getD .eliminated) = some (after.expandable slot)) ∧
      EnumerationReferences.IncomingAvoid uv after.core ∧
      (EnumerationReferences.PendingReferences before.core → EnumerationReferences.PendingReferences after.core) ∧
      (repeated = false → Frame before.core after.core ∧ after.expandable = before.expandable ∧
        after.waiting = before.waiting ∧ after.core.values[uv]? = some (.unenumerated (some handle) scs)) ∧
      (repeated = true → after.core.counter = before.core.counter ∧
        ∀ level frontier, EnumerationOrder.Stratified before.core level frontier →
          EnumerationOrder.Stratified after.core level frontier) ∧
      (repeated = true → MergedOrdinaryHeight.recursiveBoundary value = true ∧
        after.core.values[uv]? = some (.unenumerated (some handle) []) ∧ after.expandable uv = false ∧
        after.waiting = EnumerationCanonicalWaiting.count roots (-1) scs before.waiting ∧
        ∃ (resolved : EnumerationState.State Symbol EnumGuard) (countFuel : Nat),
          Frame before.core resolved ∧
          Success (representative checkFuel uv) readAfter uv resolved ∧
          recursionKey handle scs ∈ resolved.recursionAncestry uv ∧
          Success (setValue uv (.unenumerated (some handle) [])) resolved () after.core ∧
          ∀ extra, SourcePruningEnumerationNativeIndex.write heap (countFuel + extra) uv
            (.unenumerated (some handle) []) [] scs (EnumerationExpandableIndex.frame resolved before) = some after) ∧
      before.expandable uv = true ∧
      (repeated = true →
        (∀ other, after.expandable other =
          if other = uv then false else before.expandable other) ∧
        (EnumerationIndexSelection.candidates after).length + 1 =
          (EnumerationIndexSelection.candidates before).length)
```

## Exact restart behavior

The original statement occurs at SourcePruningEnumerationParkedRestart.lean:207. Its actual stop/order/metadata result remains exact, including the empty stuck result.

```lean
theorem selected_complete_with_restart_progress
    (caller : SourceCurrentAllocatedPartialState.State width)
    (before : Cached) (preference : List Nat → Option Nat) (uv : Nat)
    (safe : Safe before.core)
    (valid : SourcePruningEnumerationNativeBranchCompletion.CacheValid caller before)
    (selection : EnumerationPureSelection.next preference before = .expand uv) :
    ∃ (readFuel handle : Nat) (scs : List Suspended)
      (readAfter : EnumerationState.State Symbol Constraint) (checkFuel : Nat) (repeated : Bool) (after : Cached),
      before.core.values[uv]? = some (.unenumerated (some handle) scs) ∧
      (∀ extra, ExceptT.run (getValue (readFuel + extra) uv before.core) =
        [.ok (.unenumerated (some handle) scs, readAfter)]) ∧
      (∀ extra, ExceptT.run (SourcePruningEnumerationRecursion.checkRepeated caller.checked.native.machine.heap
        (checkFuel + extra) uv handle scs readAfter) = [.ok (repeated, after.core)]) ∧
      SourcePruningEnumerationNativeBranchCompletion.CacheValid caller after ∧ Safe after.core ∧
      (EnumerationReferences.PendingReferences before.core → EnumerationReferences.PendingReferences after.core) ∧
      (repeated = true → after.core.counter = before.core.counter ∧
        (∀ level frontier, EnumerationOrder.Stratified before.core level frontier →
          EnumerationOrder.Stratified after.core level frontier) ∧
        ∃ countFuel, ∀ extra (stop : Option (Metadata Typing → Nat → Bool))
          (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing),
          ExceptT.run (run caller.checked.native.machine.heap readFuel checkFuel (countFuel + extra) uv
            stop order metadata before before.core) =
            if SourcePruningEnumerationRestart.decision stop order metadata after = some .stuck then []
            else [.ok (some (metadata, SourcePruningEnumerationRestart.decision stop order metadata after), after.core)]) ∧
      before.expandable uv = true ∧
      (repeated = true →
        (∀ other, after.expandable other =
          if other = uv then false else before.expandable other) ∧
        (EnumerationIndexSelection.candidates after).length + 1 =
          (EnumerationIndexSelection.candidates before).length)
```
