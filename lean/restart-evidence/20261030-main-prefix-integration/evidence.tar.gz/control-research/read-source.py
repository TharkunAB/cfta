from pathlib import Path
import hashlib, json, sys

root = Path('/home/tritlo/Code/mcfta')
area = Path('/tmp/mcfta-uniform-key-control-20261030')
label, name, first, requested_last = sys.argv[1:]
source = root / name
raw = source.read_bytes()
lines = raw.splitlines(keepends=True)
first = int(first)
last = len(lines) if requested_last == 'EOF' else min(int(requested_last), len(lines))
assert 1 <= first <= last
data = b''.join(lines[first-1:last])
out = area / 'root-source-reads' / label
out.mkdir(parents=True, exist_ok=False)
(out / 'source.txt').write_bytes(data)
digest = lambda b: hashlib.sha256(b).hexdigest()
(out / 'scope.json').write_text(json.dumps(dict(source=name, source_bytes=len(raw), source_lines=len(lines), source_sha256=digest(raw), first=first, last=last, requested_last=requested_last, whole=first==1 and last==len(lines), bytes=len(data), sha256=digest(data)), indent=2)+'\n')
print(name)
for i, line in enumerate(data.decode().splitlines(), first):
    print(str(i) + ' ' + line)
