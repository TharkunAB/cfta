# Sized count-table review of new main

Status: no confirmed correctness defect from source review.
This is not a compiler, test or runtime result. Root owns those checks.
The owner changed no repository file and ran no compiler, evaluator, native
worker, test, network request or Git mutation. No subagent was used.

Reviewed revision: bd5a406a6, the PR102 merge on main.
Compared revision:7b8db072fbde44f20ce9a803736de5624050f038.
The exact Git blob IDs, full source hashes and copied-range hashes are in
acquisitions.json and diff-manifest.json. All13 source scopes and5 complete
diff identities were verified. The source observations below apply to those
exact blobs, independent of a later merge in Root's worktree.

## Distinct terms of ambiguous rows

Table.hs489–547 implements the bottom-up subset construction. A deterministic
state is the set of original states that accept a term. Transitions are grouped
by symbol and arity. A child tuple is considered if one original transition
can use all of its child sets. The target contains every original state with
a transition that can use that tuple. The target is therefore nonempty.

The initial round supplies nullary transitions. Later rounds consider tuples
whose first newly found child set occurs at each possible position. Earlier
positions use old sets; later positions can use any known set. The local Set
removes duplicates when several original transitions propose the same tuple.
This gives one deterministic transition per token and useful child tuple.

The table keeps transitions found for existing target sets as well as new sets.
When a round finds no new target set, it still unions that round's transitions
into the returned table. The construction therefore does not discard new
transitions merely because their target was already known.

A Right state holds the deterministic rows of one set. A Left original state
unites the transitions of all deterministic sets that contain it. The sets
describe disjoint term languages. This is the source argument for distinct-term
counting and for the unambiguous-row precondition of tablePosition.
It is not a checked Lean determinization theorem.

countingRows checks unambiguity on the rows reached after trim. The plain route
keeps sortedRows of the original whole graph. The ambiguous route constructs
deterministic rows of the whole graph. sizedStates uses the same route for
each reached state and shares the unconstrained tables. A failed bounded
construction returns Nothing and selects the reference route.

## Equal-child intersections and ranks

Table.hs608–651 constructs keys that are sets of original states. A key accepts
the common terms of its members. A transition tuple has one same-token
transition from each member. The code joins all direct-child equality groups
of the tuple. For each group it intersects every tuple member's child state at
every position of that group. It writes that same child key at every position.
It does not select only the first original child state of a class.

This addresses the important unequal-child-state case. For a row
g(a,c) with children0=1, the shared child comes from L(a) intersect L(c).
It also handles joined constraints: if one member equates0=1 and another
equates1=2, the group uses all three child positions from both members.

equalChildren rejects residual guards, contradictory equality classes and
paths that are not valid direct-child positions. childGroups starts from every
position of the row. Its joins retain a partition of the positions. The
intersection writer therefore produces a complete child array, and each group
has a valid leader and positive width.

stateTable reads one index for the first position of each group. It scales
that index's size by the width of the group. seed copies the selected term to
every position of the group. Thus a term used k times contributes k times its
node count, while the group has only one term choice.

termPositions first requires a child rank from the actual child state at every
position. It also checks equality of the actual child terms in every class.
It then uses the same group leaders, scaled child sizes and productPosition
sequence as stateTable. Nonadjacent classes, such as{0,2}, use their first
position before position1 in both directions. This is the source argument for
rank/unrank agreement on these rows. It is not a runtime inverse-law result.

The fast equality route requires the rows to be unambiguous after erasing
their constraints. A term then chooses at most one transition per member of an
intersection key. Joining positive equality groups cannot introduce another
accepting run. Ambiguous constrained rows remain on the reference route.

Automaton.hs changes the ordinary adapter's annotation from() to empty
EqualChildren. It retains the existing rejection of open, constrained and
ambiguous native automata. The extracted childGroups operation preserves the
direct-child partition logic used by the finite import. I found no source
evidence that this adapter change broadens its accepted native support.

## Order, guards and checkpoint compatibility

The ambiguous and equal-child table routes may use a different sequence from
sizedReference. The public module documents this. It retains equality of the
sets and counts; it does not promise the old reference order on those routes.
Both sized and sized-sample checkpoint route versions increase from1 to2.
The existing tests reject version1. A formal correspondence claim must use
the selected route's actual row and product order.

sizedStates calls referenceStates first. A residual guard in a row reached
from the supplied initial state therefore still returns ResidualGuard.
The route only returns nonempty state indexes for states in the initial trim.
Unsupported equality shapes select the reference implementation; they are not
silently treated as unconstrained. sizedUpTo retains its solver route and
GuardUnknown result. Its classes use smaller-size child classes and remove
duplicate terms after constraint decisions.

The new all-state API requires care in a future theorem. Its shared result
agrees with a separate sized call for each state reached by the initial state.
It does not claim that an unreachable state's independent language is returned.
The source intentionally returns an empty class function there.

## Resource boundary and concrete check targets

countingLimit is1024. It bounds the number of constructed deterministic states
or intersection keys. The intersection route also bounds the transitions of
one key by taking1025 entries before it rejects the row.

The deterministic route computes a complete round map before its next state
count check. Its tuple generator can enumerate a large product of child-set
holders. The state limit does not bound this intermediate product. The
intersection route can also inspect many rejected Cartesian candidates before
it finds1025 matching transitions. The code documents exponential growth.
These are resource boundaries for a future correspondence proof, not confirmed
correctness defects. No runtime reproducer was executed by this owner.

Useful existing Root check targets are present in SizedSpec:

- Overlapping alternatives and repeated transitions count each term once.
- A constrained pair with different child states uses their intersection,
  including a productive common language and an empty common language.
- Overlapping equal-child classes join to one three-position class.
- A nonadjacent class{0,2} agrees with the reference's set and count and has
  consecutive inverse ranks.
- Perfect binary terms have sparse size classes. The large count and rank
  checks use five-second limits.
- exactClasses checks accepted-term sets, uniqueness, counts, rank/unrank
  correspondence, out-of-range unrank, and suffix listing.
- stateAgreement compares shared and independent indexes for every reached
  state, including invalid ranks at both ends.

The source also updates referenceAgreement to compare sequences only for the
unambiguous unconstrained route. Other routes compare sorted sets and counts.
This is an intentional contract distinction. A passing unordered comparison
does not verify route order. Root must use the inverse-rank and checkpoint
checks for that part of the behavior.

## Formalization and FINDINGS boundary

The new public implementation needs distinct correspondence obligations:
deterministic-set membership equals original acceptance; each deterministic
term has one run; intersection keys mean conjunction of member languages;
group copying has weighted node size; table selection and ranking use the same
ordered products; fallback preserves classes; and route-version checks reject
obsolete positions. Existing core soundness and native intersection proofs do
not by themselves establish these whole public API statements.

No Haskell repair or new executable defect was established by this owner.
The upstream equal-child intersection correction should be described as an
incorporated upstream change, rather than a newly reproduced bug in the final
merge. Any later concrete repair must be recorded by Root in FINDINGS.

## Acquisition and readback limits

The complete658-line new Table body was covered by four bounded cuts. This is
a complete Table review, not a claim that only a small part was examined.
The Sized routing, contracts and query bodies were read in bounded cuts.
The module's imports and some datatype declarations were not a whole-module
review. The ordinary adapter and required tests were read in exact cuts.
All cut endpoints and full upstream blob identities are retained.

One combined display of the equal-prefix cut and SizedSpec patch was truncated
inside the patch. The complete equal-prefix cut preceded that truncation.
Required new fixtures and property sections were then read in separate exact
cuts. No whole SizedSpec body review is claimed. No finding depends on omitted
patch text. The full unmodified patch is retained as evidence.

All13 acquisition entries are present and verify against the exact stored cuts.
All5 stored diffs verify byte-for-byte against the named immutable revisions.
VALIDATION.json records those checks. pins.json and FROZEN.json bind every
payload and the read-only freeze. Later execution belongs to Root's evidence.
