from pathlib import Path
import subprocess,json,hashlib,sys
root=Path('/home/tritlo/Code/mcfta');p=Path('/tmp/mcfta-main-prefix-integration-20261030/count-review');ref,path,start,end,label=sys.argv[1:];start=int(start);end=int(end)
raw=subprocess.check_output(['git','show',ref+':'+path],cwd=root);lines=raw.splitlines(keepends=True);actual_end=min(end,len(lines));data=b''.join(lines[start-1:actual_end]);target=p/'cuts'/(label+'.txt');target.parent.mkdir(exist_ok=True);target.write_bytes(data)
row=dict(ref=ref,path=path,blob=subprocess.check_output(['git','rev-parse',ref+':'+path],cwd=root,text=True).strip(),source_bytes=len(raw),source_lines=len(lines),source_sha256=hashlib.sha256(raw).hexdigest(),requested_start=start,requested_end=end,actual_start=start,actual_end=actual_end,copy=str(target.relative_to(p)),copy_bytes=len(data),copy_sha256=hashlib.sha256(data).hexdigest(),whole=start==1 and actual_end==len(lines))
f=p/'acquisitions.json';rows=json.loads(f.read_text()) if f.exists() else [];rows.append(row);f.write_text(json.dumps(rows,indent=2)+'\n')
print(path,ref,start,actual_end)
for i,line in enumerate(data.decode().splitlines(),start):print(i,line)
