# Main Prefix integration

The full goal remains ACTIVE. Read
final-documents/lean/notes-current-main-prefix-integration.md first.
Main PR102 is integrated and tested. No new Lean theorem was added.
415 generator and56 serialization examples pass. Required formatters pass.
All4675 Lean files and476 protected identities remain unchanged.
Use final-haskell.json with835 current native inputs as the new baseline.
The831-input manifests inside control-research are premerge history.

Every regular payload is archived without filtering. Keep the source tree
and reconstruction immutable. Continue in a fresh writable area.
Control reports and proposed parked/path statements are source-only.
Keep their status, all scope limits and the failed host-linker attempt.
Existing failed suffix-carrier probes remain in the previous archive.
Verification executes no Lean or Haskell code.
