import MicroCFTA.InternedFreshOrdinaryConstruction
import MicroCFTA.InternedRecordCoherence

namespace MicroCFTA.SourceSynthesisCurrentCaptureRowRecordOrigin
open Cache InternedConstructorTemplates
open InternedBinderProtocol (NodeKey Reference)
open InternedNestedConstruction (Syntax Outcome work)
open InternedFreshOrdinaryConstruction (build buildMany buildEdges)
set_option autoImplicit false
variable {Symbol Guard : Type}

private theorem capture_row_union_record_origin
    [DecidableEq (EdgeKey Symbol Guard)]
    (symbol : Symbol) (constraint : Guard) (indices : List Nat)
    (environment : List (Value Symbol Guard)) (before : State Symbol Guard)
    (value : Value Symbol Guard) (after : State Symbol Guard)
    (completed : build (.node [.mk symbol constraint (indices.map Syntax.var)])
      environment before = .done value after) :
    ∀ (key : NodeKey) (entry : Interned NodeKey)
      (members : List (Value Symbol Guard)) (depth : Nat)
      (free : List Reference),
      after.nodeRecords key = some (.union entry members depth free) →
        before.nodeRecords key = some (.union entry members depth free)
 := by
  have variables (positions : List Nat) (current : State Symbol Guard) :
      buildMany (positions.map Syntax.var) environment current =
        .done (positions.map fun index => environment[index]?.getD .empty) current := by
    induction positions with
    | nil => rfl
    | cons index rest ih =>
        simp only [List.map_cons, buildMany, build, Outcome.bind, ih]
  let captured : List (Value Symbol Guard) :=
    indices.map fun index => environment[index]?.getD .empty
  let made := run (makeEdge symbol constraint captured) before
  let madeNode := run (makeNode [made.1]) made.2
  have executed :
      build (.node [.mk symbol constraint (indices.map Syntax.var)])
        environment before = .done madeNode.1 madeNode.2 := by
    simp only [build, buildEdges, variables, buildMany, Outcome.bind, work]
  have endpoints : madeNode.1 = value ∧ madeNode.2 = after := by
    simpa only [Outcome.done.injEq] using executed.symm.trans completed
  intro key entry members depth free stored
  have present : madeNode.2.nodeRecords key = some (.union entry members depth free) :=
    endpoints.2.symm ▸ stored
  change (run (makeNode [made.1]) made.2).2.nodeRecords key =
    some (.union entry members depth free) at present
  unfold makeNode at present
  dsimp only at present
  split at present
  · simpa only [run] using present
  · rename_i first rest kept
    simp only [run, nodeStep] at present
    rcases InternedRecordCoherence.record_cases
      made.2.nodeRecords _ key _ (.union entry members depth free) present
      with old | ⟨_same, candidate⟩
    · exact old
    · simp only [identifyNode, reduceCtorEq] at candidate

end MicroCFTA.SourceSynthesisCurrentCaptureRowRecordOrigin
