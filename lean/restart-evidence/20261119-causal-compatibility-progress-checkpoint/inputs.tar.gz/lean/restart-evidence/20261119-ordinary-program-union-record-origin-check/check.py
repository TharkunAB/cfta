from pathlib import Path
import datetime, hashlib, json, os, re, subprocess
ROOT = Path('/home/tritlo/Code/mcfta')
RUNTIME = ROOT / 'lean/restart-evidence/20261119-ordinary-program-union-record-origin-check'
SHA = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
s = json.loads((RUNTIME / 'selection.json').read_text())
pins = json.loads((RUNTIME / 'source-pins.json').read_text())
def verify():
    for name, expected in pins.items(): assert SHA(ROOT/name) == expected, name
verify()
assert not (RUNTIME/'results.json').exists() and not (RUNTIME/'checked.json').exists()
group = next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
cgroup = Path('/sys/fs/cgroup') / group.lstrip('/')
limits = {name:(cgroup/name).read_text().strip() for name in ['memory.max','memory.high','memory.swap.max']}
assert limits == s['limits']
source = RUNTIME / 'source/MicroCFTA' / (s['module']+'.lean')
assert not source.with_suffix('.olean').exists()
env = dict(os.environ); env.pop('LEAN_SYSROOT',None); env['LEAN_NUM_THREADS']='1'
started = datetime.datetime.now().astimezone().isoformat()
with (RUNTIME/'compiler.txt').open('w') as log:
    try:
        done = subprocess.run(['nix-shell',str(ROOT/'shell.nix'),'--run',
            'exec lake env lean -j1 -DwarningAsError=true -R '+str(RUNTIME/'source')+' '+str(source)],
            cwd=ROOT/'lean',env=env,stdout=log,stderr=subprocess.STDOUT,text=True,
            timeout=s['compiler_internal_timeout_seconds'])
        code, timed_out = done.returncode, False
    except subprocess.TimeoutExpired:
        code, timed_out = 124, True
verify()
assert not source.with_suffix('.olean').exists()
assert not (ROOT/'lean/.lake/build/lib/lean/MicroCFTA'/(s['module']+'.olean')).exists()
text = (RUNTIME/'compiler.txt').read_text()
groups = re.findall(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",text,re.S)
free = re.findall(r"'([^']+)' does not depend on any axioms",text)
names = [name for name,_ in groups] + free
axioms = set().union(*(set(x.strip() for x in values.split(',') if x.strip()) for _,values in groups)) if groups else set()
bad = sorted(axioms-{'propext','Classical.choice','Quot.sound'})
diagnostics = len(re.findall(r'(?m)^(?:error(?:\([^\n]*\))?:|[^\n]*:\d+:\d+: error(?:\([^\n]*\))?:)',text))
warnings = len(re.findall(r'(?m)^(?:warning(?:\([^\n]*\))?:|[^\n]*:\d+:\d+: warning(?:\([^\n]*\))?:)',text))
passed = code == 0 and not timed_out and not diagnostics and not warnings and not bad and 'sorryAx' not in text and names == [s['expected_private_qname']]
result = {'status':'FINAL SMALL PRIVATE LEAF PASS' if passed else 'FINAL SMALL PRIVATE LEAF FAILURE',
    'started_at':started,'completed_at':datetime.datetime.now().astimezone().isoformat(),
    'driver_exit':code,'timed_out':timed_out,'axiom_groups':len(groups),'axiom_free_reports':len(free),
    'total_axiom_reports':len(names),'expected_user_qname':s['expected_user_qname'],'expected_private_qname':s['expected_private_qname'],
    'resolved_private_qname':names[0] if len(names)==1 else None,'observed_qnames':names,
    'nonstandard_axioms':bad,'diagnostics':diagnostics,'warnings':warnings,'sorryAx':'sorryAx' in text,
    'limits':limits,'source_pins_unchanged':True,'pins_independently_reverified':len(pins),
    'source_pins_sha256':SHA(RUNTIME/'source-pins.json'),'source_sha256':SHA(source),'driver_sha256':SHA(Path(__file__)),
    'log_sha256':SHA(RUNTIME/'compiler.txt'),'new_public_theorems':0,'new_private_theorems':1,
    'new_helpers':0,'new_definitions':0,'definition_checks':0,'proof_credit':passed,
    'normal_Source_changed':False,'compiled_objects_written':False,'historical_joint_assignment_proved':False,
    'original_root_acceptance_proved':False}
(RUNTIME/'results.json').write_text(json.dumps(result,indent=2)+'\n')
if passed: (RUNTIME/'checked.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
raise SystemExit(0 if passed else 1)
