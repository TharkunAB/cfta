import MicroCFTA.EqualityLeafProjectionUnion

namespace MicroCFTA.SourceSynthesisCurrentOrdinaryUnionRecordOrigin
open Cache InternedConstructorTemplates
open InternedBinderProtocol (NodeKey Reference)
open EqualityLeafProjectionUnion (OrdinaryRoot NodeRoot)
open InternedEdgeResidency (nodeEdges)
set_option autoImplicit false
variable {Symbol Guard : Type}

private theorem ordinary_union_record_origin
    [DecidableEq (EdgeKey Symbol Guard)]
    (values : List (Value Symbol Guard)) (before : State Symbol Guard)
    (ordinary : ∀ value ∈ values, OrdinaryRoot value) :
    ∀ (key : NodeKey) (entry : Interned NodeKey)
      (members : List (Value Symbol Guard)) (depth : Nat)
      (free : List Reference),
      (run (makeUnion values) before).2.nodeRecords key =
          some (.union entry members depth free) →
        before.nodeRecords key = some (.union entry members depth free)
 := by
  have nodeOrigin (edges : List (EdgeValue Symbol Guard)) :
      ∀ (key : NodeKey) (entry : Interned NodeKey)
        (members : List (Value Symbol Guard)) (depth : Nat)
        (free : List Reference),
        (run (makeNode edges) before).2.nodeRecords key =
            some (.union entry members depth free) →
          before.nodeRecords key = some (.union entry members depth free) := by
    unfold makeNode
    dsimp only
    split
    · intro key entry members depth free present
      exact present
    · rename_i first rest kept
      intro key entry members depth free present
      rcases InternedRecordCoherence.record_cases
        before.nodeRecords
        (.node ((first :: rest).map fun edge => edge.entry.identity)) key
        (identifyNode (first :: rest)
          (Cache.intern before.nodes
            (.node ((first :: rest).map fun edge => edge.entry.identity))).1)
        (.union entry members depth free) present with old | ⟨_same, candidate⟩
      · exact old
      · simp only [identifyNode, reduceCtorEq] at candidate
  have nodes : ∀ value ∈ distinctNodes (values.flatMap unionMembers),
      NodeRoot value := by
    intro value member
    obtain ⟨source, included, inner⟩ := List.mem_flatMap.mp
      (InternedProbeProvenance.distinctNodes_member _ value member)
    exact (EqualityLeafProjectionUnion.ordinary_member
      source value (ordinary source included) inner).2
  cases normalized : distinctNodes (values.flatMap unionMembers) with
  | nil =>
      intro key entry members depth free present
      simpa only [makeUnion, normalized, run] using present
  | cons first rest =>
      cases rest with
      | nil =>
          intro key entry members depth free present
          simpa only [makeUnion, normalized, run] using present
      | cons second tail =>
          have extracted : ordinaryEdges (first :: second :: tail) =
              some ((first :: second :: tail).flatMap nodeEdges) :=
            EqualityLeafProjectionUnion.ordinary_edges _ (by
              intro value member
              exact nodes value (by rw [normalized]; exact member))
          simpa only [makeUnion, normalized, extracted] using
            nodeOrigin ((first :: second :: tail).flatMap nodeEdges)

end MicroCFTA.SourceSynthesisCurrentOrdinaryUnionRecordOrigin

#print axioms MicroCFTA.SourceSynthesisCurrentOrdinaryUnionRecordOrigin.ordinary_union_record_origin
