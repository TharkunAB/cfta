from pathlib import Path
import ast
import hashlib
import json
import re

ROOT = Path('/home/tritlo/Code/mcfta')
BASE = ROOT/'lean/restart-evidence'
CONTROL = BASE/'20261119-own-inherited-child-path-terminal-join-check-control-draft'
WORK = BASE/'20261119-own-inherited-child-path-terminal-join-work'
SHA = lambda b: hashlib.sha256(b).hexdigest()
assert Path(__file__).resolve().parent == WORK.resolve()
assert Path(__file__).read_bytes() == (CONTROL/Path(__file__).name).read_bytes()
bound = set()
def verify(path, expected):
    data = path.read_bytes()
    assert SHA(data) == (expected['sha256'] if isinstance(expected,dict) else expected), str(path)
    if isinstance(expected,dict) and 'bytes' in expected: assert len(data) == expected['bytes'], str(path)
    bound.add(path)
    return data
def record(expected): return verify(ROOT/expected['path'],expected)
manifest = json.loads((CONTROL/'MANIFEST.json').read_text())
assert manifest['status'] == 'FROZEN SMALL PRIVATE LEAF CHECK CONTROLLER / NOT EXECUTED'
for name,expected in manifest['files'].items(): verify(CONTROL/name,expected)
bound.add(CONTROL/'MANIFEST.json')
s = json.loads((CONTROL/'SELECTION.json').read_text())
assert s['status'] == 'FROZEN ONE PRIVATE SAME-LEAF CHECK / NOT EXECUTED'
assert s['entrypoint'] == Path(__file__).name and s['work'] == WORK.name
assert s['runtime'] == '20261119-own-inherited-child-path-terminal-join-check'
assert s['expected_private_reports'] == 1 and s['expected_public_reports'] == 0
assert s['expected_definition_checks'] == s['new_helpers'] == s['new_definitions'] == 0
assert s['Nix'] and s['Lean_threads'] == 1 and s['warnings_as_errors'] and s['default_proof_limits'] and s['no_o']
assert s['required_outer_time_cap_minutes'] == 5 and s['compiler_internal_timeout_seconds'] == 290
assert s['limits'] == {'memory.max':'4294967296','memory.high':'4294967296','memory.swap.max':'0'}
assert s['no_private_namespace'] and not s['normal_publication_selected']
runtime = BASE/s['runtime']; assert not runtime.exists()
for name,expected in json.loads((CONTROL/'KNOWN-INPUT-PINS.json').read_text())['files'].items(): verify(ROOT/name,expected)
packet = BASE/s['candidate_packet']
candidate = json.loads(record(s['candidate_manifest']))
for name,expected in candidate['files'].items(): verify(packet/name,expected)
for name,expected in json.loads((packet/'SOURCE-PINS.json').read_text())['files'].items(): verify(ROOT/name,expected)
if s['Root_math_review'] is not None:
    review = json.loads(record(s['Root_math_review']))
    assert review['status'].startswith('FINAL') and not review.get('proof_credit',False)
raw,first,proof,preamble = [record(s[k]) for k in ['source','FIRST','proof','preamble']]
assert SHA(raw) == '0746a34c3629ce25b92268ab237e5eb9d2b7ca888e01b540ae40ca4bf458eb9f'
assert SHA(first) == 'a984c77e7ca5f2e680121abfe0078620d8c6a34be58729d2da27db1d450b893e'
assert SHA(proof) == 'b14635e6d3aa19bd6da642685f073a88400ac70e266a41472123254830d72497'
assert raw == preamble+first+proof+b'\nend MicroCFTA.SourcePruningEnumerationCachedOwn\n' and raw.count(first+proof) == 1
assert len(re.findall(rb'^private theorem ',raw,re.M)) == 1
assert not re.search(rb'^(?:private )?(?:def|inductive|structure|axiom|opaque|noncomputable def) ',raw,re.M)
assert not re.search(rb'\b(?:sorry|admit|axiom)\b',proof)
assert not re.search(rb'set_option\s+(?:maxHeartbeats|maxRecDepth|warningAsError|linter\.)',raw)
fixture = verify(CONTROL/'PROBES.lean.txt',manifest['files']['PROBES.lean.txt'])
assert fixture == b'#print axioms '+s['expected_user_qname'].encode()+b'\n'
assert s['expected_private_qname'] == '_private.MicroCFTA.SourcePruningEnumerationOwnInheritedPathTerminalJoin.0.'+s['expected_user_qname']
push = json.loads(record(s['parent_PUSH_receipt']))
assert push['source_commit'] == s['parent_source_commit']
assert push['checkpoint_commit'] == push['remote_commit'] == s['parent_checkpoint_commit']
assert push['actual_push_terminal_exit'] == push['actual_remote_check_terminal_exit'] == push['postpush_current_tree_verifier_terminal_exit'] == 0
normal = json.loads(record(s['parent_normal_source_pins']))
paths = {p.stem:p for p in (ROOT/'lean/MicroCFTA').glob('*.lean')}
assert len(paths) == s['expected_source_files'] == 6298 and len(normal) == s['expected_source_toolchain_pins'] == 6302
assert set(normal) == {str(p.relative_to(ROOT)) for p in paths.values()} | {'shell.nix','lean/lean-toolchain','lean/lakefile.toml','lean/lake-manifest.json'}
for name,expected in normal.items(): verify(ROOT/name,expected)
name = s['module']; assert name not in paths
order,graph,active,seen = [],{ },[],set()
def visit(module):
    assert module not in active,repr(active+[module])
    if module in seen: return
    active.append(module)
    text = raw.decode() if module == name else paths[module].read_text()
    graph[module] = re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$',text,re.M)
    for dep in graph[module]: visit(dep)
    active.pop(); seen.add(module); order.append(module)
visit(name)
dag = json.loads((CONTROL/'IMPORT-DAG.json').read_text())
canonical = lambda v:(json.dumps(v,indent=2,sort_keys=True)+'\n').encode()
assert len(order) == dag['full_modules'] == 2011 and len(order)-1 == dag['normal_dependencies'] == 2010
assert graph[name] == s['direct_parent_modules'] == ['SourcePruningEnumerationOwnInputShape','SourcePruningEnumerationTerminalPrefix']
assert SHA(canonical(order)) == dag['full_order_sha256'] and SHA(canonical(graph)) == dag['direct_import_graph_sha256']
for name,expected in json.loads((CONTROL/'SOURCE-TOOLCHAIN-PINS.json').read_text()).items(): verify(ROOT/name,expected)
objects = ROOT/'lean/.lake/build/lib/lean/MicroCFTA'
assert not (objects/(s['module']+'.olean')).exists()
for dep in seen-{s['module']}: assert (objects/(dep+'.olean')).is_file(),dep
ast.parse((CONTROL/'check-driver.py.txt').read_text())
ast.parse((CONTROL/'run-private-with-terminal-receipt.py.txt').read_text())
runtime.mkdir()
source = runtime/'source/MicroCFTA'/(s['module']+'.lean'); source.parent.mkdir(parents=True)
source.write_bytes(raw+b'\n'+fixture)
(runtime/'check.py').write_bytes((CONTROL/'check-driver.py.txt').read_bytes())
(runtime/'selection.json').write_text(json.dumps(s,indent=2,sort_keys=True)+'\n')
bound.update([source,runtime/'check.py',runtime/'selection.json',Path(__file__)])
(runtime/'source-pins.json').write_text(json.dumps({str(p.relative_to(ROOT)):SHA(p.read_bytes()) for p in sorted(bound)},indent=2,sort_keys=True)+'\n')
print(json.dumps({'runtime':str(runtime),'commands':1,'private_reports':1,'public_reports':0,'definition_checks':0,'no_o':True,'normal_Source_changed':False,'memory_GiB':4,'minutes':5}))
