# OPEN stored-substitution prerequisite

Status: ONE FROZEN FIRST, NO PROOF BODY. No compiler check or mathematical credit exists. No helper or definition was authored.

The owner is InternedFreshOrdinaryStoredSubstitution.execute, lines76-78. This is the executor called by SourceRecursiveIntersectionMaybeMu.callback, lines22-24. The older InternedStoredSubstitution.execute is not an unconditional replacement. execute_eq requires PreparedWithoutMu and is not used as a hidden premise here.

The FIRST uses only current Facts, availability of the original body and replacement reference, and the current no-union-record inventory. nameAvailable is the existing current constructor-reference fact. It is available for the depth and ordinary placeholders, and for the exact fresh reserved reference. It is not a future result or a semantic supplier. No closedness or PreparedWithoutMu premise was added.

Exact first blocked case:

For an open ordinary stored node, encode emits Syntax.node (encodeEdges context locals edges). The real executor first runs buildEdges, which runs buildMany for each row, which returns to build for each child. Proving only the original value-level substitution statement gives no IH at this syntax/list/edge boundary. Existing build_verified gives Facts, growth and availability, but permits Syntax.union and therefore cannot prove the missing record-tag exclusion.

The later binder case is a second coupled obligation. An open stored Mu encodes to Syntax.binder. The executor runs the actual depth callback, ordinary callback, and possibly fresh-body callback. Each callback uses build and then withoutSelfReference. To show the latter does not call makeUnion, the proof must also know that its ACTUAL returned value is not a union. Current after-heap inventory plus the existing available result would give this, once preservation has been proved through the preceding build.

Smallest required closure before this FIRST can have a short body:

A structural induction over the three existing build/buildMany/buildEdges families must carry: union-free encoded syntax; current Facts and input availability; current no-union records; preservation at every pending or completed heap; and available completed results. The syntax property must be hereditary through nodes and binders, not just a top-level inequality. The source inventory and recursive Available derive this property for encode; replacement inputs follow from leaves_available and inputs_available. Reference substitutions do not introduce Syntax.union.

At a binder, withoutSelfReference is pure for a nonunion returned value. request can retain an old payload, return pending, or add only a Mu payload. This keeps every actual probe and stopping endpoint. makeNode adds only an ordinary payload; makeEdge does not change nodeRecords. No new union constructor is needed in any of these cases.

No existing theorem read supplies that restricted constructor induction. Writing it here would add a larger coupled proof than the requested small cut. Work stops at this exact missing closure. There is no claimed false case. No sorry, axiom, placeholder proof or future preservation premise was added. Accepted-source initialization, generic kernel closure and warm/shared attachments remain pending.
