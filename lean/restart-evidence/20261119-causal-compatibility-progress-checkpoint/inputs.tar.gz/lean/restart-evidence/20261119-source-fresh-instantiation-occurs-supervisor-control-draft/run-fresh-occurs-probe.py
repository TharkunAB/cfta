from pathlib import Path
import datetime, hashlib, json, os, re, shlex, subprocess, sys, tempfile, time

ROOT = Path('/home/tritlo/Code/mcfta')
BASE = ROOT/'lean/restart-evidence'
CONTROL = BASE/'20261119-source-fresh-instantiation-occurs-supervisor-control-draft'
SELF = CONTROL/'run-fresh-occurs-probe.py'
CAP = Path('/home/tritlo/Code/heavy-management/bin/capped')

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def read(path: Path) -> dict:
    return json.loads(path.read_text())

def new_json(path: Path, value: dict) -> None:
    with path.open('x') as out:
        out.write(json.dumps(value,indent=2,sort_keys=True)+'\n')

def verify(path: Path, record: dict) -> bytes:
    data = path.read_bytes()
    assert sha(data) == record['sha256'], str(path)
    if 'bytes' in record: assert len(data) == record['bytes'], str(path)
    return data

def frozen_packet(path: Path, expected: str | None = None) -> dict:
    data = (path/'MANIFEST.json').read_bytes()
    if expected is not None: assert sha(data) == expected
    manifest = json.loads(data)
    assert manifest['status'].startswith('FROZEN'), str(path)+' is not frozen'
    for name, record in manifest['files'].items():
        payload = path/name
        assert payload.resolve().is_relative_to(path.resolve())
        verify(payload,record)
    return manifest

assert Path(__file__).resolve() == SELF.resolve()
frozen_packet(CONTROL)
s = read(CONTROL/'SELECTION.json')

# This branch executes inside the actual capped Nix stage.
if len(sys.argv) == 4 and sys.argv[1] == '--stage':
    request_path = Path(sys.argv[2]); data = request_path.read_bytes()
    assert sha(data) == sys.argv[3]
    request = json.loads(data)
    assert request_path.resolve().is_relative_to((BASE/s['work']).resolve())
    group = next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
    cgroup = Path('/sys/fs/cgroup')/group.lstrip('/')
    limits = {k:(cgroup/k).read_text().strip() for k in s['expected_limits']}
    start = time.monotonic(); at = datetime.datetime.now().astimezone().isoformat()
    new_json(Path(request['start_receipt']),{'status':'ACTUAL CAPPED STAGE START','at':at,'argv':request['argv'],
        'cwd':str(ROOT),'uid':os.getuid(),'cgroup':group,'limits':limits,'expected_limits':s['expected_limits']})
    assert limits == s['expected_limits']
    env = dict(os.environ); env.update({'LC_ALL':'C','LANG':'C'}); env.update(request['environment'])
    result = subprocess.run(request['argv'],cwd=ROOT,env=env)
    after = {k:(cgroup/k).read_text().strip() for k in s['expected_limits']}
    new_json(Path(request['terminal_receipt']),{'status':'FINAL ACTUAL INNER STAGE EXIT','at':datetime.datetime.now().astimezone().isoformat(),
        'argv':request['argv'],'cwd':str(ROOT),'environment_overrides':request['environment'],'actual_exit':result.returncode,
        'seconds':time.monotonic()-start,'cgroup':group,'limits_before':limits,'limits_after':after,
        'limits_exact':limits == after == s['expected_limits'],'request_sha256':sha(data),'script_sha256':sha(SELF.read_bytes())})
    raise SystemExit(result.returncode if result.returncode >= 0 else 128-result.returncode)

assert len(sys.argv) == 1
assert s['source_packet_manifest_sha256'] and s['source80_normal_verified'], 'Bind final frozen source packet and Source80 normal PASS first'
packet = BASE/s['source_packet']
frozen_packet(packet,s['source_packet_manifest_sha256'])
predecessor = json.loads(verify(ROOT/s['source80_normal_verified']['path'],s['source80_normal_verified']))
assert predecessor['actual_terminal'] and predecessor['actual_terminal_exit'] == 0 and predecessor['all_five_gates_passed']
assert predecessor['source_files'] == 6298 and [row['total_axiom_reports'] for row in predecessor['checks']] == [794,1,389,794,794]
for name, record in s['protected_source_payloads'].items(): verify(packet/name,record)
source_pins = read(packet/'SOURCE-PINS.json')['files']
assert len(source_pins) == s['expected_source_pin_count'] == 11
support = read(CONTROL/'REFERENCE-PINS.json')['files']
observed = read(packet/'OBSERVED-ENVIRONMENT.json')
loader = observed['loader_library_directories']
assert all(Path(path).is_dir() for path in loader)

def inputs() -> dict:
    frozen_packet(packet,s['source_packet_manifest_sha256'])
    for name, record in source_pins.items(): verify(ROOT/name,record)
    for name, record in support.items(): verify(Path(name),record)
    plan_data = (ROOT/'dist-newstyle/cache/plan.json').read_bytes(); plan = json.loads(plan_data)
    packages = [x for x in plan['install-plan'] if (x.get('pkg-name') in ['cfta','cfta-generator'] and x.get('component-name') == 'lib') or x.get('pkg-name') == 'text']
    assert sorted(x['id'] for x in packages) == sorted(s['expected_package_ids'])
    assert plan['compiler-id'] == s['expected_compiler_id']
    return {'plan_sha256':sha(plan_data),'compiler_id':plan['compiler-id'],'package_ids':[x['id'] for x in packages]}

initial = inputs()
work = BASE/s['work']
work.mkdir(exist_ok=True)
for name in ['ACTUAL-RUN.json','INPUT-VERIFICATION.json','logs','requests']:
    assert not (work/name).exists(), 'Preserve previous work: '+name
(work/'logs').mkdir(); (work/'requests').mkdir()
new_json(work/'INPUT-VERIFICATION.json',{'status':'FINAL PRE-EXECUTION INPUT VERIFICATION','source_manifest_sha256':s['source_packet_manifest_sha256'],
    'controller_manifest_sha256':sha((CONTROL/'MANIFEST.json').read_bytes()),'source_pins':source_pins,'support_pins':support,'Cabal_plan':initial,
    'source80_predecessor':s['source80_normal_verified'],'new_theorem_credit':0})
owned = Path(tempfile.mkdtemp(prefix='mcfta-source-fresh-occurs-',dir='/tmp'))
assert owned.parent == Path('/tmp') and owned.stat().st_uid == os.getuid()
for name in ['Probe.hs','Good.hs','BadOccurs.hs']:
    data = verify(packet/name,s['protected_source_payloads'][name]); (owned/name).write_bytes(data)
(owned/'ghc').mkdir()
base_ghc = ['ghc','-hide-all-packages','-package','base','-O0','-Wall','-j1']
compile_probe = ['cabal','exec','--','ghc','-hide-all-packages','-package','base']
for package_id in s['expected_package_ids']: compile_probe += ['-package-id',package_id]
compile_probe += ['-O0','-Wall','-j1','-threaded','-rtsopts','-outputdir',str(owned/'ghc'),'-o',str(owned/'probe'),str(owned/'Probe.hs')]
control = base_ghc+['-fno-code','-fforce-recomp','-i'+str(owned),'-outputdir',str(owned/'ghc')]
jobs = [('diagnostic-compile',compile_probe,0,{}),('Good',control+[str(owned/'Good.hs')],0,{}),
    ('BadOccurs',control+[str(owned/'BadOccurs.hs')],1,{}),
    ('runtime',['timeout','--kill-after=3s','60s',str(owned/'probe'),'FRESH_OCCURS','+RTS','-N1','-M3072m','-RTS'],0,{'LD_LIBRARY_PATH':':'.join(loader)})]
rows=[]; failure=None; observed_runtime=None
try:
    for name, argv, expected, environment in jobs:
        before = inputs()
        for source in ['Probe.hs','Good.hs','BadOccurs.hs']: verify(owned/source,s['protected_source_payloads'][source])
        request = {'name':name,'argv':argv,'environment':environment,'start_receipt':str(work/'requests'/(name+'-start.json')),
            'terminal_receipt':str(work/'requests'/(name+'-terminal.json'))}
        request_path = work/'requests'/(name+'.json'); new_json(request_path,request)
        inner = shlex.join(['python3',str(SELF),'--stage',str(request_path),sha(request_path.read_bytes())])
        unit = 'mcfta-fresh-occurs-'+owned.name.rsplit('-',1)[-1]+'-'+name.lower()+'.scope'
        command = [str(CAP),'--mem','4G','--time','2m','nix-shell',str(ROOT/'shell.nix'),'--run','exec '+inner]
        env = dict(os.environ); env['CAPPED_UNIT']=unit; env['HEAVY_PEAKS']=str(work/'heavy-peaks')
        log = work/'logs'/(name+'.txt'); started=time.monotonic()
        with log.open('x') as out:
            done = subprocess.run(command,cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT,text=True)
        terminal_path = Path(request['terminal_receipt'])
        terminal = read(terminal_path) if terminal_path.is_file() else None
        row = {'name':name,'actual_argv':command,'actual_inner_argv':argv,'scope':unit,'actual_exit':done.returncode,'expected_exit':expected,
            'seconds':time.monotonic()-started,'log':str(log.relative_to(ROOT)),'log_sha256':sha(log.read_bytes()),
            'inner_terminal':terminal,'Cabal_plan_before':before,'Cabal_plan_after':None}
        rows.append(row)
        row['Cabal_plan_after']=inputs()
        assert terminal and terminal['limits_exact'] and terminal['actual_exit'] == done.returncode == expected, name+' failed or has no exact capped terminal receipt'
        text = log.read_text(); plain = text.translate(str.maketrans({'‘':"'",'’':"'",'“':'"','”':'"'}))
        if name == 'BadOccurs':
            finite = 'occurs check' in plain.lower() or 'infinite type' in plain.lower()
            finite = finite or bool(re.search(r"Couldn't match type\s+'(\w+)'\s+with\s+'\1\s*->\s*\1'",plain))
            finite = finite or bool(re.search(r"Couldn't match type\s+'(\w+)\s*->\s*\1'\s+with\s+'\1'",plain))
            assert finite and 't t' in plain and re.search(r'BadOccurs\.hs:\d+:\d+:.*error',plain), 'Exit 1 is not yet classified as the expected finite occurs error'
            row['classification']='actual finite occurs type error at the exact negative source'
        if name == 'runtime':
            assert 'case_complete=True; observations_only=True; partial_type_scope=retained' in text
            observed_runtime={}
            for phase in ['public','typed']:
                statuses=re.findall(r'^'+phase+r'\.candidate="([^"]+)" status=(\S+) finite_hm_expected=(True|False)$',text,re.M)
                assert sorted(x[0] for x in statuses)==['fresh_identity_positive','fresh_occurs_negative']
                scanned=re.findall(r'^'+phase+r'\.scanned=(\d+)$',text,re.M); exhausted=re.findall(r'^'+phase+r'\.exhausted=(True|False)$',text,re.M)
                assert len(scanned)==len(exhausted)==1
                observed_runtime[phase]={'scanned':int(scanned[0]),'exhausted':exhausted[0]=='True','statuses':{x[0]:x[1] for x in statuses}}
            observed_runtime['streams_cross_joined']=False
            observed_runtime['same_typed_run_payloads_retained_in_full_log']=True
        print(json.dumps({'stage':name,'actual_exit':done.returncode,'seconds':round(row['seconds'],3),'caps_verified':True}),flush=True)
except Exception as error:
    failure={'type':type(error).__name__,'message':str(error)}
result={'status':'FINAL DIAGNOSTIC EXECUTION COMPLETE' if failure is None else 'FINAL DIAGNOSTIC EXECUTION REJECTED',
    'at':datetime.datetime.now().astimezone().isoformat(),'owned_tmp':str(owned),'stages':rows,'failure':failure,'observed_runtime':observed_runtime,
    'source_packet_manifest_sha256':s['source_packet_manifest_sha256'],'controller_manifest_sha256':sha((CONTROL/'MANIFEST.json').read_bytes()),
    'script_sha256':sha(SELF.read_bytes()),'heavy_peaks_sha256':sha((work/'heavy-peaks').read_bytes()) if (work/'heavy-peaks').is_file() else None,'all_four_stages_completed':len(rows)==4 and failure is None,'new_theorem_credit':0,
    'counterexample_established':False,'finite_typing_or_joint_completion_proved':False,'normal_Source_changed':False,'temporary_outputs_deleted':False}
new_json(work/'ACTUAL-RUN.json',result)
print(json.dumps({'status':result['status'],'stage_exits':[x['actual_exit'] for x in rows],'failure':failure,'observed_runtime':observed_runtime,
    'receipt':str(work/'ACTUAL-RUN.json'),'owned_tmp':str(owned),'new_theorem_credit':0}),flush=True)
raise SystemExit(0 if failure is None else 1)
