from pathlib import Path
import datetime, hashlib, json, subprocess, sys
ROOT = Path('/home/tritlo/Code/mcfta')
CONTROL = ROOT/'lean/restart-evidence/20261119-ordinary-program-union-record-origin-run-reduction-repair-check-control-draft'
WORK = ROOT/'lean/restart-evidence/20261119-ordinary-program-union-record-origin-run-reduction-repair-work'
RUNTIME = ROOT/'lean/restart-evidence/20261119-ordinary-program-union-record-origin-run-reduction-repair-check'
assert Path(__file__).resolve().parent == WORK.resolve()
assert Path(__file__).read_bytes() == (CONTROL/'run-private-with-terminal-receipt.py.txt').read_bytes()
output = WORK/'PRIVATE-DRIVER-EXIT.json'
assert not output.exists()
driver = RUNTIME/'check.py'
run = subprocess.run([sys.executable,str(driver)],cwd=ROOT)
receipt = {'status':'FINAL DIRECT DRIVER EXIT OBSERVED','at':datetime.datetime.now().astimezone().isoformat(),
    'driver_exit':run.returncode,'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),
    'supervisor_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'proof_credit':False}
with output.open('x') as stream: stream.write(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(run.returncode)
