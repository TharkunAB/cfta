-- | Independent finite-type controls. This module does not import CFTA.
module Good where

-- | Discard a value of any monotype.
sink :: a -> Bool
sink _ = True

-- | Supply only the type of t. The control does not evaluate this function.
t :: (a -> a) -> a
t _ = error "Type-only diagnostic: t is not evaluated"

-- | The polymorphic identity.
i :: a -> a
i x = x

-- | Instantiate the finite positive control at Bool.
goodFinite :: Bool
goodFinite = sink (t i :: Bool)
