These commands are an OPEN plan. None has run. Root decides serial execution after the active proof publication. Record each actual command, exit, timeout, elapsed time and full log. Keep compiler or loader failures separate from semantic results.

First verify every SOURCE-PINS.json payload and every packet artifact. Re-read the current Cabal plan. Use the exact selected library IDs recorded in OBSERVED-ENVIRONMENT.json only if they still match. The commands below match the current plan. If library objects are absent, Root must build cfta:lib:cfta and cfta-generator:lib:cfta-generator with -j1 inside Nix and the same serial cap before this plan continues.

Materialize only this packet's three Haskell files in one new owned diagnostic directory. Do not modify normal Source, existing archives or Cabal files. A future Root shell can use:

```sh
export probe_source=/home/tritlo/Code/mcfta/lean/restart-evidence/20261119-source-fresh-instantiation-occurs-probe-draft
export probe_work=$(mktemp -d /tmp/mcfta-source-fresh-occurs.XXXXXX)
export HEAVY_PEAKS="$probe_work/heavy-peaks"
cp -- "$probe_source/Probe.hs" "$probe_source/Good.hs" "$probe_source/BadOccurs.hs" "$probe_work/"
mkdir "$probe_work/ghc"
```

Run these operations serially from /home/tritlo/Code/mcfta. Use /home/tritlo/Code/heavy-management/bin/capped --mem 4G --time 2m around each nix-shell shell.nix --run command. The cap sets memory.max and memory.high to 4 GiB and memory.swap.max to zero. Root must retain the effective scope limits and actual terminal state. Choose distinct task scope names.

Inside the capped Nix environment, compile the one diagnostic:

```sh
cabal exec -- ghc -hide-all-packages -package base \
  -package-id cfta-0.1.0.0-inplace \
  -package-id cfta-generator-0.1.0.0-inplace \
  -package-id text-2.1.3-2a27 \
  -O0 -Wall -j1 -threaded -rtsopts \
  -outputdir "$probe_work/ghc" -o "$probe_work/probe" "$probe_work/Probe.hs"
```

Type-check the independent controls in separate capped commands. Expected exits are 0 for Good.hs and 1 for BadOccurs.hs. These are expectations, not observed results. The negative result must be an actual finite-type error at t t, not a missing package, syntax error or loader failure.

```sh
ghc -hide-all-packages -package base -O0 -Wall -j1 -fno-code -fforce-recomp \
  -i"$probe_work" -outputdir "$probe_work/ghc" "$probe_work/Good.hs"
ghc -hide-all-packages -package base -O0 -Wall -j1 -fno-code -fforce-recomp \
  -i"$probe_work" -outputdir "$probe_work/ghc" "$probe_work/BadOccurs.hs"
```

After successful diagnostic compilation, run exactly FRESH_OCCURS in one capped command. Keep the actual checker flag and callbacks unchanged. The matching Nix library directories below still exist. Set this loader path on the child command only. Resolve replacements from the same Nix environment if those paths change.

```sh
LD_LIBRARY_PATH=/nix/store/6qi8skh85ci2k9gvl27nnh3kiy32qnsz-zlib-1.3.1/lib:/nix/store/k8bqvzzw3xll9sjkai15skrj7ab4f8gg-gmp-with-cxx-6.3.0/lib \
  timeout --kill-after=3s 60s "$probe_work/probe" FRESH_OCCURS +RTS -N1 -M3072m -RTS
```

Save the complete runtime log. Report each route's scanned count, exhaustion flag and both exact candidate statuses. Retain the same typed-run term and residual list for each typed match, including the encoding-completeness marker. Do not infer a shared witness between the public and typed routes. Do not turn a timeout into absence. Do not classify a source soundness defect from presence alone; check the exact typed output, partial-type boundary and residuals first. No performance comparison or general completeness claim is planned.
