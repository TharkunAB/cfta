-- | Expected finite-type occurs error. No result has been measured yet.
module BadOccurs where

import Good (sink, t)

-- | Two fresh instances of t still require a recursive type equation.
badFinite :: Bool
badFinite = sink (t t)
