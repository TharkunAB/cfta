from pathlib import Path
import datetime, hashlib, json, os, stat, subprocess, sys
ROOT=Path('/home/tritlo/Code/mcfta')
WORK=ROOT/'lean/restart-evidence/20261119-source-fresh-instantiation-occurs-probe-work'
SHA=lambda data:hashlib.sha256(data).hexdigest()
def digest_rows(rows):
    return SHA(json.dumps(rows, separators=(',', ':')).encode())

def fingerprint(path):
    info = path.lstat()
    return [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns,
            info.st_mode, info.st_uid, info.st_nlink]

def source_stats(pins):
    assert set(pins) == {str(p.relative_to(ROOT)) for p in (ROOT / 'lean/MicroCFTA').glob('*.lean')} | {
        'lean/lake-manifest.json', 'lean/lakefile.toml', 'lean/lean-toolchain', 'shell.nix'}
    rows = []
    for name, expected in sorted(pins.items()):
        path = ROOT / name
        actual = SHA(path.read_bytes())
        assert actual == (expected['sha256'] if isinstance(expected, dict) else expected), name
        rows.append([name, fingerprint(path), actual])
    return {'files': len(rows), 'stat_sha256': digest_rows(rows)}

def cache_stats(normal_cache, targets):
    rows = []
    for path in sorted(normal_cache.glob('*.olean')):
        resolved = path.resolve(strict=True)
        assert not any(resolved.is_relative_to(target) for target in targets)
        rows.append([str(path), str(resolved), fingerprint(path), fingerprint(resolved)])
    return {'targets': len(rows), 'stat_sha256': digest_rows(rows)}

def process_scan(targets):
    references, errors = [], []

    def inside(text):
        clean = text.removesuffix(' (deleted)')
        return any(clean == str(t) or clean.startswith(str(t) + '/') for t in targets)

    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name) == os.getpid():
            continue
        try:
            if proc.stat().st_uid != os.getuid():
                continue
            checks = [('cmdline', lambda: (proc / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')),
                      ('cwd', lambda: os.readlink(proc / 'cwd'))]
            for kind, read in checks:
                try:
                    value = read()
                    if (any(str(t) in value for t in targets) if kind == 'cmdline' else inside(value)):
                        references.append([proc.name, kind, value])
                except (FileNotFoundError, ProcessLookupError):
                    pass
                except OSError as error:
                    errors.append([proc.name, kind, str(error)])
            try:
                for fd in (proc / 'fd').iterdir():
                    try:
                        value = os.readlink(fd)
                        if inside(value):
                            references.append([proc.name, str(fd), value])
                    except (FileNotFoundError, ProcessLookupError):
                        pass
                    except OSError as error:
                        errors.append([proc.name, str(fd), str(error)])
            except (FileNotFoundError, ProcessLookupError):
                pass
            except OSError as error:
                errors.append([proc.name, 'fd', str(error)])
        except (FileNotFoundError, ProcessLookupError):
            pass
        except OSError as error:
            errors.append([proc.name, 'stat', str(error)])
    assert not references, references
    return {'live_process_references': references, 'process_scan_errors': errors,
            'process_visibility_complete': not errors}

mode=sys.argv[1]
assert mode in ['preview','apply']
original=json.loads((WORK/'ACTUAL-RUN.json').read_text())
target=Path(original['owned_tmp'])
assert target.parent==Path('/tmp') and target.name.startswith('mcfta-source-fresh-occurs-')
assert target.is_dir() and not target.is_symlink() and target.resolve()==target and target.stat().st_uid==os.getuid()
expected={'BadOccurs.hs','Good.hs','Probe.hs','ghc/Main.hi','ghc/Main.o','probe'}
files=[]; directories=[]
for p in sorted(target.rglob('*')):
    info=p.lstat(); relative=str(p.relative_to(target))
    assert info.st_uid==os.getuid() and not p.is_symlink(),str(p)
    if p.is_dir():
        assert relative=='ghc';directories.append(relative)
    else:
        assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and relative in expected,str(p)
        files.append({'file':relative,'bytes':info.st_size,'sha256':SHA(p.read_bytes()),'stat':fingerprint(p)})
assert {x['file'] for x in files}==expected and directories==['ghc']
scopes=[x['scope'] for x in original['stages']]+['mcfta-fresh-occurs-rmba6z28-runtime-root-resume.scope']
env={**os.environ,'XDG_RUNTIME_DIR':'/run/user/1000','DBUS_SESSION_BUS_ADDRESS':'unix:path=/run/user/1000/bus'}
states={s:subprocess.check_output(['systemctl','--user','show',s,'--property=ActiveState','--value'],env=env,text=True).strip() for s in scopes}
assert set(states.values())=={'inactive'}
scan=process_scan([target])
pins=json.loads((ROOT/'lean/restart-evidence/20261118-source80-accepted-current-satisfies-inventory-work/NORMAL-SOURCE-PINS.json').read_text())
cache=(ROOT/'lean/.lake/build/lib/lean/MicroCFTA').resolve()
source_before=source_stats(pins);cache_before=cache_stats(cache,[target])
preview=WORK/'ROOT-TMP-CLEANUP-PREVIEW.json';result=WORK/'ROOT-TMP-CLEANUP.json';assert not result.exists()
protected={str(p.relative_to(ROOT)):SHA(p.read_bytes()) for p in WORK.rglob('*') if p.is_file() and p not in [preview,result]}
current={'target':str(target),'root_stat':fingerprint(target),'files':files,'directories':directories,'scopes':states,'normal_Source':source_before,'normal_cache':cache_before,'protected_runtime_files':protected}
if mode=='preview':
    assert not preview.exists();preview.write_text(json.dumps({**current,'process_scan':scan},indent=2)+'\n')
    print(json.dumps({'target':str(target),'bytes':sum(x['bytes'] for x in files),'files':len(files),'preview_sha256':SHA(preview.read_bytes()),'normal_Source':source_before,'normal_cache':cache_before,'live_process_references':scan['live_process_references'],'process_visibility_complete':scan['process_visibility_complete']}))
    raise SystemExit(0)
assert len(sys.argv)==3 and SHA(preview.read_bytes())==sys.argv[2]
before=json.loads(preview.read_text())
for k,v in current.items():assert before[k]==v,k
for item in files:
    p=target/item['file'];assert fingerprint(p)==item['stat'] and SHA(p.read_bytes())==item['sha256'];p.unlink()
(target/'ghc').rmdir();target.rmdir()
assert source_stats(pins)==source_before and cache_stats(cache,[target])==cache_before
assert all(SHA((ROOT/p).read_bytes())==h for p,h in protected.items())
record={'status':'FINAL EXACT CLOSED PROBE OUTPUTS REMOVED','at':datetime.datetime.now().astimezone().isoformat(),'target':str(target),'regular_bytes_removed':sum(x['bytes'] for x in files),'regular_files_removed':len(files),'preview_sha256':sys.argv[2],'script_sha256':SHA(Path(__file__).read_bytes()),'normal_Source_preserved':True,'normal_cache_preserved':True,'runtime_files_preserved':True,'unknown_tmp_entries_preserved':True,'normal_Source':source_before,'normal_cache':cache_before,'scopes':states,'process_scan':scan,'proof_credit':False}
result.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k] for k in ['status','regular_bytes_removed','regular_files_removed']}))
