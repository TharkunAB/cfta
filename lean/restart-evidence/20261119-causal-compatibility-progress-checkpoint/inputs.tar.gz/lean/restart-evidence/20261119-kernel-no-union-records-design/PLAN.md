# OPEN kernel union-record design

Status: HEADER AND PLAN ONLY. No proof body or compiler check exists. Credit is zero.

Use one structural inventory: every constructor nodeRecords payload has a tag other than Value.union. The FIRST writes this predicate inline. It adds no definition or runtime data.

Available.resident gives the exact stored payload. Available.children gives the same fact recursively for node children and all three Mu fields. Therefore the inventory excludes unions at every available descendant. Facts alone does not establish the inventory.

The next kernel FIRST preserves this inventory for every bounded execute outcome. It retains the existing Valid, Domain and operand Available inputs. It has no child-call provider, closedness, guard-Top or unique-head premise. The final accepted-source claim must derive the initial inventory from its actual build; that derivation is not claimed here.

Proof order:

1. Establish that makeEdge writes no node record and makeNode writes only an ordinary-node payload. Use the actual Work interpreter and record_cases. Do not infer global absence from Grows: growth alone can add a union.
2. Prove stored substitution preserves the inventory for an available body when its environment supplies available union-free values or literal references. Available recursively excludes the union branch of encode. The maybeMu callback supplies a literal replacement reference. Its probes, reservation and request can add ordinary or Mu records, but no union payload. Check every pending outcome too. This is the main new prerequisite, not a consequence of the existing verified theorem alone.
3. Induct on execute fuel. Reuse execute_checked for Facts, Domain, availability and extension at each exact earlier endpoint. The ordinary branch traverses all matched rows and their actual zipped child pairs; apply the smaller-fuel IH in sequence, then step 1. Arity mismatch only builds an empty edge. Keep failure and stopped-prefix heaps.
4. Rule out leftUnion/rightUnion through input availability and the inventory. Reset, swap and reference resolution use the smaller-fuel IH; Domain.bindings supplies availability for the exact read result. Self, empty and repeated leave the heap unchanged. Mu enters its domain, uses the smaller-fuel IH on actual stored bodies, then step 2.

Memo boundary:

Native Thunks.Valid already retains NodeGood/EdgeGood. Their returned states carry Produced receipts. Memo.produced_spec derives Available in the CURRENT heap from that receipt; the edge counterpart gives resident rows and available children. Thus the same heap inventory is enough at memo hits. Bare memo tables without these existing physical validity inputs are insufficient. No additional future semantic memo provider is proposed.

Scope:

This is one generic kernel target, not a worker or Type-domain NoUnion theorem. Native instruction preservation, actual accepted-source initialization, required-node read reconstruction, and warm/shared target composition remain separate attachments. No compiler, runtime, Haskell, normal Source or Git action was performed. No full Type-row Top property is assumed.
