# OPEN no-union constructor audit and completion leaf

Status: ONE PRIVATE PROOF DRAFT. It has not been compiled or frozen. Credit is zero. No additional helper, definition or runtime data was authored.

The leaf proves only that actual InternedNestedRequestFacts.complete preserves the no-union record inventory. It is the exact terminal record write of InternedNestedConstruction.request's miss branch. The request definition spells that write inline; it does not call complete by name. The proof uses keepFirst's existing record_cases law. A retained union would be either an earlier record, excluded by the premise, or equal to the new Mu candidate, excluded by constructor disjointness. The leaf does not need Facts, availability, smart cleanup restrictions or a callback provider.

Placement: the private FIRST belongs in the SAME InternedNestedRequestFacts compiler owner as the later structural proof. PREAMBLE and APPEND are proof-review fixtures. A separate production module could not export this private name. No owner edit is authorized or performed here.

Exact sufficient hereditary properties:

H(heap): every nodeRecords payload has a tag other than Value.union. Available recursively exposes residency for ordinary children and all three Mu fields, so H excludes union at every available descendant.

N(expression): empty and var are allowed; node is allowed iff all its edge-child expressions satisfy N; binder is allowed iff its body satisfies N; union is excluded. The list and edge clauses require N of every actual member. No restriction on guards, repeated symbols, Mu presence or free references is needed. This is a sufficient syntactic restriction for stored encode, not a claim that every safe source syntax must exclude union. Initial source syntax has ordinary-only unions that need their own construction argument.

H plus Available derives N(encode context locals value) by the existing Value/list/edge recursion: closed values become captured var instructions; references become var instructions; open node and Mu recurse through available descendants; a union value contradicts its exact resident record. The actual source replacement is a literal reference. Original leaves and current replacement availability establish the initial environment facts through leaves_available and inputs_available.

Required induction architecture:

Use the three EXISTING build/buildMany/buildEdges recursion families. Each IH quantifies over current environment and heap, takes Facts, input Values, H and N, and returns H at the ACTUAL Outcome.state. Use existing build_verified/buildMany_verified/buildEdges_verified separately for Facts, availability, growth and issued-reference history. Do not duplicate their invariant proof. Completed result availability plus H gives the no-union result shape when it is needed. Pending heaps must also retain H.

In the binder case, apply the body IH to the actual depth callback, ordinary callback and possible reserved-reference callback. For each completed callback, H plus its available result excludes root union. Therefore withoutSelfReference is literally Work.pure and leaves the heap unchanged. Reservation changes only nodes, not nodeRecords. A request hit or pending return changes no record. Its miss completion uses this new leaf. finish/cleanup changes only the returned value. No saved future result or unrestricted callback preservation supplier is needed in the final structural theorem.

Existing generic rules and limits:

InternedNestedFacts.bind_verified composes arbitrary RESULT properties but fixes its heap facts to Facts; it cannot itself add H at pending endpoints. request_verified already handles actual reservation and callback availability. InternedRecordCoherence.record_cases is sufficient for primitive writes. InternedFreshOrdinaryFacts.build_verified already gives the three-family execution/fact induction. InternedFreshOrdinaryStoredConstraintHeap and InternedFreshOrdinaryConstraintHeap are analogous guard-property inductions; their predicates inspect guards, so they cannot express exclusion of the union constructor tag. No general ready-made tag-preservation theorem was found in the bounded owner search.

Remaining work:

Prove N for stored encode and the restricted three-family H preservation. The present leaf closes only the terminal Mu write. The prior exact stored-substitution FIRST, generic kernel no-union preservation, accepted-source initial H and warm/native/shared attachments remain open. No PreparedWithoutMu, closedness, model or future-result premise was assumed.
