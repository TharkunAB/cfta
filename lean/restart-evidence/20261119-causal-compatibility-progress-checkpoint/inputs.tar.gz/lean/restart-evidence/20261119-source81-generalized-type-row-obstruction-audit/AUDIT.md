# Generalized Type rows do not all have full Top constraints

Status: OPEN source audit. No new theorem or execution was checked.

For any Type universe U, the source calculation is:

```text
typ = tFun (tVar "a") (tVar "a")
equalityClasses typ = [[[1], [2]]]
generalize U typ = node [mk "->" (eqGuard [[[1], [2]]]) [arrowMarker top, U, U]]
```

The complete constraint requires equal argument and result children. It differs
from `top = ⟨some [], .top⟩`. Its residual `.guard` is still `.top`.
This is a counterexample to the proposed invariant for all Type-domain rows.
It is intentional generalization. Production `generalize` replaces variables
with the Type universe and adds equality constraints for their occurrences.
This is correct Haskell behavior. It is not a runtime defect.

The accepted source component constructor inserts this generalized Type as
its annotation child. `RowCall.guard_eq` preserves the complete source guard
at the same actual native row construction. The component row itself has Top.
Its annotation root need not have Top. `ProgramEdge.annotated` permits an
arbitrary annotation value. It does not establish full Top for that value.

The exact original-U scope is already closed:

- `SourceSynthesisCurrentUniverseBody.current_types_callback_rows` at441
  gives full Top for every original body row and the marker/reference layout.
- `SourceSynthesisCurrentUniverseUnfoldedRowPreparation.original_universe_unfolded_row_top`
  at31 retains full Top through the same actual U unfold receipt.
- `original_universe_unfolded_row_preparation` at59 derives the actual Top
  preparation. The arrow case keeps the cache and has no residual.

These laws need no new wrapper. They do not classify all narrowed Type rows.
`SourceSynthesisNativeTypeTrace.pool` includes the generalized library Type
constraints. Its `Origin` predicate closes under actual conjunction.
`SourceSynthesisNativeTypeSharedHeap.edge` preserves a complete original
constraint. `SourceRecursiveIntersectionKernel.edge` constructs the
conjunction of both operand constraints. These contracts do not erase the
source equality class. Native ProgramSlots transport preserves lookups and
Program roles. It does not add a full-Top Type certificate.

The same-boundary segment question remains open. A generalized prefix by
itself does not disprove a restriction to exact U-to-the-same-U segments.
The missing clause must derive from the actual segment which rows came from
unchanged U unfolding and which rows came from imported Type-prefix
conjunctions. It must exclude the latter or account for their own-class
allocations. `KeyAncestry` records trie-list shapes. It has no such row-origin
clause. No supplied NoFresh condition or future model can replace this proof.

No accepted eager repeat-run receipt was established. No same-boundary
exclusion, joint assignment, original-root acceptance, or global completion
was proved. No compiler, runtime probe, Haskell edit, or Source edit ran.
