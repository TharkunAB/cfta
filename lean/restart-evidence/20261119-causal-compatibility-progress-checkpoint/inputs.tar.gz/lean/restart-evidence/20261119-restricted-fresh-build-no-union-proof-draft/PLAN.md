# OPEN restricted fresh-constructor no-union proof

Status: COMPLETE PROOF DRAFT, UNCOMPILED, NOT FROZEN. Credit is zero. All nine FIRST files and the preamble were written before any body. The assembled source contains each complete literal FIRST plus body once.

The packet has four pure predicate definitions: NoUnionRecords and the three mutually recursive UnionFree/UnionFreeMany/UnionFreeEdges definitions. It has six private primitive or sequencing lemmas and three mutually recursive reusable preservation laws. There are no other module-level helpers or definitions.

The three laws preserve NoUnionRecords at the actual completed OR pending outcome heap. They require current Facts and available inputs plus the hereditary syntax restriction. They do not require PreparedWithoutMu, closedness, a model, a future child result or a future resource provider. The union instruction is excluded; arbitrary ordinary rows and open smart/raw binders remain allowed.

Existing build_verified/buildMany_verified/buildEdges_verified supply all Facts, availability, issued-reference and record-growth transport. This proof does not reprove those invariants. The binder proof applies its smaller syntax-body IH to each actual callback. After that build, current NoUnionRecords plus actual result Available excludes root union. withoutSelfReference is then pure. The request-miss rule preserves the inventory through reservation, its actual callback and the Mu-only keepFirst completion. Cache hits and pending returns retain the same heap.

The private request and sequencing rules accept local preservation arguments. Those arguments are fully discharged in the three main proofs by the actual body/tail IH and primitive laws. No such supplier appears in the reusable main FIRSTs.

The COMPLETE primitive proof adapts the preceding request-completion leaf, using the new concise inventory predicate. The old packet is unchanged. NODE follows the existing record_cases/nodeStep pattern. Ordinary edge construction changes no nodeRecords field. FILTER contradicts exact union residency. Existing private names from other compiler owners are not imported or referenced.

Static review only: FIRST/body joins, declaration counts and source pins were checked as bytes. No Lean elaboration has run. Possible elaboration issues include reducing NoUnionRecords through primitive Work projections, known-constructor bind reduction, and mutual termination under the local callback IH. These are not known semantic blockers. No limit or linter setting was changed; autoImplicit is false.

Remaining scope: derive UnionFree of the actual stored encode from current Available and the no-union heap inventory. Then compose actual reference replacement and maybeMu, prove generic kernel preservation and derive the initial accepted-source heap property. Native warm memo, required-read and shared-worker attachments remain separate. This packet does not prove the final source-domain NoUnion claim or joint finite completion.

Static pre-handoff refinement: the three recursive predicate definitions now use the same explicit sizeOf termination measures as existing BinderFree/ManyBinderFree/EdgesBinderFree. NODE explicitly reduces nodeStep in its stored-record hypothesis before record_cases. Every FIRST and the other eight bodies remain exact. The earlier OPEN bytes are retained in before-explicit-measures-and-node-reduction. No kernel check occurred.
