import MicroCFTA.SourcePruningEnumerationOwnInputShape
import MicroCFTA.SourcePruningEnumerationTerminalPrefix

namespace MicroCFTA.SourcePruningEnumerationCachedOwn
open EnumerationState EnumerationCorrectness EnumerationSchedule
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => InternedConstructorTemplates.Value Symbol Constraint
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Fragment" => Fragments.Fragment Symbol
attribute [local instance] SourcePruningEnumerationTerminalPrefix.terminalPrefixMonadList
attribute [local instance] SourcePruningEnumerationTerminalPrefix.terminalPrefixLawfulMonadList
private theorem actual_own_inherited_child_path_terminal_join
    (heap : InternedConstructorTemplates.State Symbol Constraint)
    (scs : List Suspended)
    (edge : InternedConstructorTemplates.EdgeValue Symbol Constraint)
    (before prepared : Cached) (symbol : Symbol)
    (staged : List (Node × List Suspended ×
      Option (EnumerateM Symbol Constraint Fragment)))
    (tries : List EqualityTrie.Trie) (residual : Option Constraint)
    (projected : SourcePruningEnumerationConstraint.project edge.entry.key.constraint =
      some (tries, residual))
    (actualPreparation : prepare heap scs edge before =
      some [((symbol, staged, residual), prepared)])
    (index : Nat)
    (input : Node × List Suspended × Option (EnumerateM Symbol Constraint Fragment))
    (selectedChild : staged[index]? = some input)
    (inherited : Suspended) (inheritedMember : inherited ∈ scs)
    (classIndex : Nat) (trie : EqualityTrie.Trie)
    (ownClass : tries[classIndex]? = some trie)
    (inheritedValid : EqualityTrie.Valid inherited.trie)
    (ownValid : EqualityTrie.Valid trie)
    (inheritedPath : [index] ∈ EqualityTrie.fromPathTrie inherited.trie)
    (ownPath : [index] ∈ EqualityTrie.fromPathTrie trie)
    (first : Suspended) (rest : List Suspended)
    (terminalPartition : input.2.1.filter (fun sc => EqualityTrie.isTerminal sc.trie) =
      first :: rest)
    (fuel : Nat) (waiting moved : EnumerationWaitingIndex.Waiting)
    (terminalBefore terminalAfter : EnumerationState.State Symbol Constraint)
    (recorded : List Nat) (winner : Nat)
    (total : UnionFind.Total terminalBefore.representatives)
    (actualPrefix : ExceptT.run
      (SourcePruningEnumerationTerminalPrefix.run fuel first rest waiting terminalBefore) =
        [.ok ((recorded, winner, moved), terminalAfter)]) :
    UnionFind.SameClass terminalAfter.representatives
      inherited.var (before.core.counter + classIndex)
 := by
  have shape := prepare_inputs heap scs edge before prepared tries residual
    (symbol, staged, residual) projected actualPreparation
  have fields := (Prod.mk.inj shape).2
  have stagedSame := (Prod.mk.inj fields).1
  simp only [SourcePruningEnumerationEdgeInputs.children, List.map_map] at stagedSame
  rw [stagedSame, List.getElem?_map] at selectedChild
  obtain ⟨indexed, indexedStored, inputSame⟩ := Option.map_eq_some_iff.mp selectedChild
  rw [List.getElem?_zipIdx] at indexedStored
  obtain ⟨_child, _childStored, rfl⟩ := Option.map_eq_some_iff.mp indexedStored
  simp only [Nat.zero_add] at inputSame
  cases inputSame
  change (descendScs index scs ++
      descendScs index (suspendedVars before.core.counter tries)).filter
        (fun sc => EqualityTrie.isTerminal sc.trie) = first :: rest at terminalPartition
  have inheritedEnd : EqualityTrie.pathTrieDescend inherited.trie index = .terminal :=
    (EqualityTrie.nil_mem _).mp
      ((EqualityTrie.descend_exact inherited.trie inheritedValid index []).mpr inheritedPath)
  have ownEnd : EqualityTrie.pathTrieDescend trie index = .terminal :=
    (EqualityTrie.nil_mem _).mp
      ((EqualityTrie.descend_exact trie ownValid index []).mpr ownPath)
  have ownIndexed : ∀ (classes : List EqualityTrie.Trie) (start requested : Nat)
      (wanted : EqualityTrie.Trie), classes[requested]? = some wanted →
        (⟨wanted, start + requested⟩ : Suspended) ∈ suspendedVars start classes := by
    intro classes
    induction classes with
    | nil =>
        intro start requested wanted found
        simp at found
    | cons head tail ih =>
        intro start requested wanted found
        cases requested with
        | zero =>
            have same : head = wanted := Option.some.inj found
            subst wanted
            change (⟨head, start⟩ : Suspended) ∈
              (⟨head, start⟩ :: suspendedVars (start + 1) tail)
            exact List.mem_cons_self
        | succ requested =>
            change tail[requested]? = some wanted at found
            have member := ih (start + 1) requested wanted found
            change (⟨wanted, start + (requested + 1)⟩ : Suspended) ∈
              (⟨head, start⟩ :: suspendedVars (start + 1) tail)
            apply List.mem_cons_of_mem
            simpa only [Nat.add_assoc, Nat.add_comm 1 requested] using member
  have terminalDescended : ∀ (items : List Suspended) (original : Suspended),
      original ∈ items → EqualityTrie.pathTrieDescend original.trie index = .terminal →
        (⟨.terminal, original.var⟩ : Suspended) ∈ descendScs index items := by
    intro items original present ended
    change (⟨.terminal, original.var⟩ : Suspended) ∈
      (items.map (fun sc => ⟨EqualityTrie.pathTrieDescend sc.trie index, sc.var⟩)).filter
        (fun sc => !EqualityTrie.isEmpty sc.trie)
    apply List.mem_filter.mpr
    constructor
    · apply List.mem_map.mpr
      refine ⟨original, present, ?_⟩
      rw [ended]
    · rfl
  have inheritedDescended := terminalDescended scs inherited inheritedMember inheritedEnd
  have ownDescended := terminalDescended (suspendedVars before.core.counter tries)
    ⟨trie, before.core.counter + classIndex⟩
    (ownIndexed tries before.core.counter classIndex trie ownClass) ownEnd
  have inheritedTerminal : (⟨.terminal, inherited.var⟩ : Suspended) ∈ first :: rest := by
    rw [← terminalPartition]
    exact List.mem_filter.mpr ⟨List.mem_append_left _ inheritedDescended, rfl⟩
  have ownTerminal : (⟨.terminal, before.core.counter + classIndex⟩ : Suspended) ∈
      first :: rest := by
    rw [← terminalPartition]
    exact List.mem_filter.mpr ⟨List.mem_append_right _ ownDescended, rfl⟩
  obtain ⟨roots, paths⟩ := roots_exist terminalBefore.representatives total
  have prefixSuccess : Success
      (SourcePruningEnumerationTerminalPrefix.run fuel first rest waiting)
      terminalBefore (recorded, winner, moved) terminalAfter := by
    simp only [Success, actualPrefix, List.mem_singleton]
  unfold SourcePruningEnumerationTerminalPrefix.run at prefixSuccess
  obtain ⟨actualRecorded, scanned, scanning, continued⟩ :=
    (success_bind _ _ _ _ _).mp prefixSuccess
  obtain ⟨ignored, united, unions, continued⟩ :=
    (success_bind _ _ _ _ _).mp continued
  cases ignored
  obtain ⟨actualWinner, resolved, resolution, returned⟩ :=
    (success_bind _ _ _ _ _).mp continued
  obtain ⟨_returnedSame, terminalSame⟩ := (success_pure _ _ _ _).mp returned
  have scanValid := (representatives_scan terminalBefore.values roots fuel
    (first :: rest) terminalBefore scanned actualRecorded ⟨rfl, paths⟩ scanning).1
  let selectedRoots := rest.foldl (fun selected sc => roots sc.var :: selected) [roots first.var]
  have unionValid : Merging terminalBefore.values roots selectedRoots united :=
    terminal_unions terminalBefore.values roots [roots first.var] fuel first.var rest
      scanned united (merging_initial terminalBefore.values roots scanned first.var scanValid)
      (by simp) unions
  have resolvedValid := (merging_representative terminalBefore.values roots selectedRoots
    fuel first.var actualWinner united resolved unionValid resolution).1
  have selectedMember (sc : Suspended) (member : sc ∈ first :: rest) :
      roots sc.var ∈ selectedRoots := by
    apply (resolve_members roots rest [roots first.var] (roots sc.var)).mpr
    rcases List.mem_cons.mp member with same | later
    · subst sc
      exact Or.inl (by simp)
    · exact Or.inr ⟨sc, later, rfl⟩
  rw [terminalSame]
  exact (resolvedValid.joined inherited.var (before.core.counter + classIndex)).mpr
    (Or.inr ⟨selectedMember ⟨.terminal, inherited.var⟩ inheritedTerminal,
      selectedMember ⟨.terminal, before.core.counter + classIndex⟩ ownTerminal⟩)

end MicroCFTA.SourcePruningEnumerationCachedOwn
