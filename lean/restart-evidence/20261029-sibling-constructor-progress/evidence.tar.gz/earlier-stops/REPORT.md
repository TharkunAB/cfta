# Earlier recursive failure and original-input control

Status: SOURCE-ONLY REVIEW. No repository source change, compiler, evaluator,
native execution, Git, network or board command was used. Root owns integration.
The review is based on current literal source identities. Root supplied branch
checkpoint b68f1d9ad; this owner did not run Git to verify it.

## Decisive stop distinction

An intentional configured stop does not stop the sibling suffix.
Restart.decision returns none when the nonempty candidate list satisfies the
configured stopping predicate. Both Recursive.resume90 and
PreparedRecursive.resume82 convert this to a COMPLETE result with one partial
output. A callback rejection also returns COMPLETE with no output.
The exact earlier stopped-hook alternative is a FAILURE alternative.

Both continueWith definitions make the following distinction:

| Observation | Hook result |
| --- | --- |
| Singleton successful callback with true | complete with no output |
| Singleton successful callback with false | invoke the actual recursive worker |
| Other callback raw result | stopped with the exact callback observation |

The recursive worker returns complete for restart none, done and stuck.
The first returns a metadata-bearing partial output. Done returns a metadata-free
output. Stuck returns no output. A selected expansion with zero recursive fuel
returns stopped/exhausted. Unsupported prefix, entry/preparation, edge or hook
observations also remain explicit failures.

NativeContinuations.run54-63 advances to the next sibling ONLY after a complete
hook. It appends that hook's outputs before later outputs. A stopped hook retains
its outputs and terminates the suffix. The next sibling receives the hook's
actual caller and query endpoint. Its enumeration cache and captured metadata
remain the original sibling inputs.

Documentation should therefore distinguish configured stopping from operational
failure. The earlier failure case must be excluded to reach a later chosen edge.
Configured partial-output behavior must remain unchanged.

## Strongest existing original-input control result

PreparedRecursive.Complete in PreparedFiniteContract29-49 and the corresponding
Recursive.Complete in FiniteContract28-48 quantify ORIGINAL Packet, native Fits,
known guard Heap, edge selection membership/length, suspended mass and the
original finite reservation. Each returns one work bound and an exact stable
actual outcome at the supplied recursive depth, with OutcomeResources.
The result can be stopped. Complete is not a no-failure proposition.

PreparedFiniteResources.finite_complete29-53 and
FiniteResources.finite_complete28-52 construct those contracts by induction on
the supplied recursive depth. They derive stable finite execution. They do not
derive the existence of a depth with a complete HookResult.

The prepared worker separately has two useful monotonicity statements:

- PreparedRecursiveDepth.resume_complete_moreDepth70-83 and
  run_complete_moreDepth196-212 keep a complete actual result EXACT when only
  recursive depth increases, at fixed work fuel.
- PreparedRecursiveOutputPrefix.resume_outputs_moreDepth73-87 keeps all emitted
  outputs as an ordered prefix when only recursive depth increases.

These statements start from an actual complete result or retain an actual output
prefix. They do not provide the missing existential complete depth. This review
did not find or verify an equivalent legacy complete-depth monotonicity theorem.
Legacy ResumeDepth.resume_depth_stable26-44 instead aligns stable prefix/scan
work bounds at a fixed supplied recursive depth.

Increasing operation work can stabilize a fixed-depth exhausted result. It does
not increase the recursive depth or change its exhausted constructor. Therefore
the new local constructor work bound cannot by itself remove earlier failure.

## Exact recursive-capacity recurrence

Every selected expansion consumes one recursive level. A parked restart receives
the predecessor fuel. Every sibling's completed receipt invokes a hook that
captures that SAME predecessor fuel. Fuel does not decrease across siblings.
The native endpoint can change across siblings.

For an admitted finite expansion tree, its sufficient recursive depth therefore
has this shape:

```text
D(terminal restart or ordinary rejection) = 0
D(parked restart q) = 1 + D(q)
D(expansion with child continuations q1,...,qn) = 1 + max_i D(qi)
```

The zero for an empty maximum is suitable for an expansion with no continuing
child. Every qi includes the actual adaptive native endpoint for its stage.
Neutral preparation/parking transitions must be counted when they cause another
resume expansion. Native work and resource reservations compose through their
separate ordered plans; the recursive-depth maximum does not replace them.

This is a proposed proof recurrence derived from the definitions. It is not a
new checked theorem. Its missing step is to construct a finite tree, or an
equivalent well-founded bound, from the ORIGINAL admitted public input. Exposing
future recursive completions or endpoint models as a public premise would leave
that same step unproved.

A term accepted by the chosen later edge cannot justify D(qi) for every earlier
edge. Those alternatives can reject that term or have no accepting term. The
single-model strict pending-cost theorem must remain within its accepted branch.

## Why simple infinite-left-branch examples are insufficient

NativeIndex.candidate17-27 disables an unenumerated Mu/explicit-Union boundary
when its suspended bucket is empty. Such a slot is not expanded indefinitely.
Recursion.checkRepeated17-29 also detects an existing boundary key in the actual
root ancestry, clears the bucket and returns true. SelectedStep.runPrefix56-60
then parks that slot and performs an actual restart. Both workers recurse on
that parked restart, or return complete when it rejects or ends.

EnumerationState.recursionKey55-64 deliberately omits equality-union-find IDs.
Its key consists of the native node handle and a sorted deduplicated set of trie
path sets. A fresh equality ID alone cannot avoid repetition.

Consequently these are not established all-capacity failure counterexamples:

- A constructor before a leaf that merely revisits the same boundary handle
  with the same trie shape.
- The same example with fresh equality-union-find IDs but unchanged path sets.
- A recursive root with an empty suspended bucket.

The last case has a known different limitation. DischargeBoundary.initial_boundary_done
152-191 starts from Context, Available closed recursive value and empty pending
metadata. It derives an original proper Packet whose root is undischarged and
whose candidate list is empty. At EVERY work and recursive fuel the direct worker
returns its complete partial output. The prepared worker has the same terminal
resume equation. This demonstrates the need for unfolding/public rendering
coverage. It is not an earlier-hook failure counterexample.

No fully exhibited admitted all-capacity earlier-hook failure was found here.
No claim that general coverage is false follows from this review.

## Concrete route to a model-independent bound

The useful structural ingredients are partially present:

1. MergedOrdinaryHeight.child_lt50-60 gives strict ordinary-height descent to
   every child of every member edge. It requires no accepting term for the edge.
   Its height stops at Mu and explicit Union. It is not a global rank across
   their preparation.
2. Boundary repetition prevents expansion of a key already in that slot's
   inherited ancestry. A fixed FINITE universe of all reachable boundary keys
   would therefore give a decreasing number of unused keys on each branch.
3. Between insertions of new keys, a multiset of pairs of unused-key counts and
   ordinary heights is a plausible rank. A parent can have several children, so
   the unweighted SUM of child heights need not decrease. A multiset extension
   can account for replacement by any finite set of smaller child pairs.
4. Parking, union-find assimilation, narrowing, opaque transfer and callback
   transitions still need exact preservation/decrease laws for that rank.

This is a research plan, not a proved invariant. It needs a fixed key universe
derived from original source structure and controls, valid for unproductive
earlier alternatives as well as the chosen accepted branch. Native preparation
must not escape that handle universe. Bucket transformations must not escape
its trie-shape universe. All local fault/unsupported gates also need discharge.

Existing model-relative bounds do not meet this need by themselves:
ModelPathDomain.stored_suspended_paths34-50 and
stored_recursion_key_paths79-101 use BOTH Satisfies and AssignmentOrigins for the
current state. KeyAncestry.enter_key_ancestry81-92 similarly uses the original
model, origins and canonicality. KeyAncestry18-20 bounds key.tries only; it does
not bound key.node. A later chosen-edge model does not persist through an
incompatible earlier branch. Per-reached-heap finite handles do not give one
original finite universe over every future stage.

The next proof should either derive this model-independent universe/rank, derive
another original finite control family with the same coverage scope, or exhibit
a fully admitted counterexample and state the exact completion boundary. This
review does not recommend replacing the full objective with an ordinary-only or
chosen-edge-only theorem.

## Scope and provenance

There are 26 successful literal source acquisitions: 3 whole existing sources
within the limit of 4, and 23 cuts. The two worker acquisitions intentionally
requested beyond EOF and are counted as whole sources. Every requested and
actual endpoint, full source identity and copied identity is in acquisitions.json.
The third whole source is the 61-line legacy ResumeDepth module.

One earlier request for ResumeDepth67-91 was outside its 61-line file. The reader
failed before it wrote a copy or acquisition row. acquisition-incidents.json
retains this failed request. It was replaced by the explicit whole-source read.
Some broad locator output was truncated or included nonexistent candidate paths.
No semantic conclusion relies on omitted locator text. The required definitions
and theorem statements above were read through the exact successful cuts.

This owner used no subagent and made no source, compiler or external-service
change. Root should retain the existing Haskell fixes in FINDINGS. No new Haskell
defect or fix was established. The full public coverage, exact stop/order,
global-resource and Haskell correspondence objectives remain ACTIVE.
