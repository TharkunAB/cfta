
/-- The source recursive-boundary test stops at Mu and explicit union records. -/
def recursiveBoundary : Value Symbol Guard → Bool
  | .mu .. | .union .. => true
  | _ => false

/-- A closed operand without a recursive boundary is empty or an ordinary node. -/
theorem ordinary_operand (value : Value Symbol Guard) (closed : value.free = [])
    (clear : recursiveBoundary value = false) :
    value = .empty ∨ ∃ entry edges depth free, value = .node entry edges depth free := by
  cases value <;> simp_all [recursiveBoundary, Value.free]

/-- Every actual child of a closed ordinary record is closed. -/
theorem closed_child (state : State Symbol Guard) (coherent : Coherent state)
    (entry : Interned InternedBinderProtocol.NodeKey) (edges : List (EdgeValue Symbol Guard))
    (depth : Nat) (free : List InternedBinderProtocol.Reference)
    (resident : Resident state (.node entry edges depth free)) (closed : free = [])
    (edge : EdgeValue Symbol Guard) (present : edge ∈ edges)
    (child : Value Symbol Guard) (member : child ∈ edge.children) : child.free = [] := by
  have recorded := InternedNormalizationFree.node_free state coherent entry edges depth free resident
  apply List.eq_nil_iff_forall_not_mem.mpr
  intro name included
  have parent : name ∈ childFree (edges.flatMap EdgeValue.children) :=
    (childFree_member _ _).mpr
      ⟨child, List.mem_flatMap.mpr ⟨edge, present, member⟩, included⟩
  rw [← recorded, closed] at parent
  cases parent

/-- The actual boundary guard leaves only ordinary or empty retained column operands. -/
