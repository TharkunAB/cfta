/-- Original input models derive the new key shape at an actual successful entry. -/
theorem enter_key_ancestry
    (heap : InternedConstructorTemplates.State Symbol NativeGuard) (fuel uv : Nat)
    (before after : EnumerationState.State Symbol EnumGuard) (target handle : Nat)
    (bucket : List Suspended) (decoded : Value Symbol NativeGuard)
    (language : NodeLanguage Symbol) (meaning : EnumGuard → Term Symbol → Prop)
    (whole : Term Symbol) (assignment : Nat → Term Symbol)
    (satisfied : Satisfies language meaning assignment before)
    (origins : AssignmentOrigins whole before.counter assignment)
    (canonical : Canonical before) (aligned : before.counter = before.values.length)
    (bounded : KeyAncestry (SourcePruningEnumerationModelKeyShapes.keyShapes whole) before)
    (success : Success (enter heap fuel uv) before (target, handle, bucket, decoded) after) :
    KeyAncestry (SourcePruningEnumerationModelKeyShapes.keyShapes whole) after := by
  unfold enter at success
  obtain ⟨value, read, reading, continued⟩ := (success_bind _ _ _ _ _).mp success
  obtain ⟨readFound, _lookup, stored, readSame⟩ :=
    (getValue_success fuel uv before read value).mp reading
  have readBounded : KeyAncestry (SourcePruningEnumerationModelKeyShapes.keyShapes whole) read := by
    rw [readSame]
    exact bounded
  cases value with
  | enumerated fragment => exact (reject_unsuccessful read after _ continued).elim
  | eliminated => exact (reject_unsuccessful read after _ continued).elim
  | unenumerated node scs =>
      cases node with
      | none => exact (reject_unsuccessful read after _ continued).elim
      | some storedHandle =>
          have inside : readFound.representative < before.counter := by
            rw [aligned]
            exact (List.getElem?_eq_some_iff.mp stored).1
          have inserted := SourcePruningEnumerationModelKeyShapes.stored_recursion_key_mem
            language meaning before whole assignment satisfied origins canonical inside stored
