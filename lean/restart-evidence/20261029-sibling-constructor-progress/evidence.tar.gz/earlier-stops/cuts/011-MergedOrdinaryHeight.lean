open InternedEdgeResidency InternedFreshProbeKeys

mutual
/-- Count ordinary constructor layers and stop at every recursive or union boundary. -/
def height : Value Symbol Guard → Nat
  | .node _ edges _ _ => edgesHeight edges + 1
  | _ => 0

/-- The height below an edge is the maximum height of its children. -/
def edgeHeight : EdgeValue Symbol Guard → Nat
  | .mk _ children => childrenHeight children

/-- The greatest child height in an ordered edge list. -/
def edgesHeight : List (EdgeValue Symbol Guard) → Nat
  | [] => 0
  | edge :: rest => max (edgeHeight edge) (edgesHeight rest)

/-- The greatest height in an ordered list of complete child records. -/
def childrenHeight : List (Value Symbol Guard) → Nat
  | [] => 0
  | child :: rest => max (height child) (childrenHeight rest)
end

/-- A maximum of edge heights is bounded exactly when every edge is bounded. -/
theorem edgesHeight_le (edges : List (EdgeValue Symbol Guard)) (bound : Nat) :
    edgesHeight edges ≤ bound ↔ ∀ edge ∈ edges, edgeHeight edge ≤ bound := by
  induction edges with
  | nil => simp [edgesHeight]
  | cons edge rest ih => simp [edgesHeight, Nat.max_le, ih]

/-- A maximum of child heights is bounded exactly when every child is bounded. -/
theorem childrenHeight_le (children : List (Value Symbol Guard)) (bound : Nat) :
    childrenHeight children ≤ bound ↔ ∀ child ∈ children, height child ≤ bound := by
  induction children with
  | nil => simp [childrenHeight]
  | cons child rest ih => simp [childrenHeight, Nat.max_le, ih]

/-- Every immediate ordinary child is strictly below its parent. -/
theorem child_lt (entry : Interned InternedBinderProtocol.NodeKey)
    (edges : List (EdgeValue Symbol Guard)) (depth : Nat) (free : List InternedBinderProtocol.Reference)
    (edge : EdgeValue Symbol Guard) (present : edge ∈ edges)
    (child : Value Symbol Guard) (member : child ∈ edge.children) :
    height child < height (.node entry edges depth free) := by
  have edgeBound := (edgesHeight_le edges (edgesHeight edges)).mp (Nat.le_refl _) edge present
  have childBound : height child ≤ edgeHeight edge := by
    cases edge with
    | mk entry children => exact (childrenHeight_le children (childrenHeight children)).mp (Nat.le_refl _) child member
  simp only [height]
  omega

