                    (SourcePruningEnumerationRestart.decision stop order updated
                      (EnumerationExpandableIndex.frame core before)) outputs reached saved actual

variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- A complete actual prepared resume stays exact when only recursive depth increases. -/
theorem resume_complete_moreDepth
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat)
    (workFuel recursiveFuel larger : Nat) (increase : recursiveFuel ≤ larger) :
    ∀ (metadata : Metadata Typing) (caller : Caller width) (queries : Queries) (before : Cached)
      (next : Option Next) (outputs : List (Output width Typing))
      (finalCaller : Caller width) (finalQueries : Queries),
      resume holeKey fits admits graph templates checkEmpty edgesOf stop order workFuel recursiveFuel
        metadata caller queries before next = .complete outputs finalCaller finalQueries →
      resume holeKey fits admits graph templates checkEmpty edgesOf stop order workFuel larger
        metadata caller queries before next = .complete outputs finalCaller finalQueries := by
  induction recursiveFuel generalizing larger with
  | zero =>
      intro metadata caller queries before next outputs finalCaller finalQueries actual
      cases next with
      | none => cases larger <;> exact actual
      | some next =>
          cases next with
          | done | stuck => cases larger <;> exact actual
          | expand uv => simp only [resume, reduceCtorEq] at actual
  | succ fuel ih =>
      cases larger with
      | zero => omega
      | succ larger =>
          have enough : fuel ≤ larger := Nat.le_of_succ_le_succ increase
          intro metadata caller queries before next outputs finalCaller finalQueries actual
          cases next with
          | none => exact actual
          | some next =>
              cases next with
              | done | stuck => exact actual
              | expand uv =>
