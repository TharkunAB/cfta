theorem finite_complete
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool)) (order : Metadata Typing → List Nat → Option Nat)
    (formulas : SourceGuards.Formulas FullSyntax.Formula) (solver : SourceGuards.Entailment FullSyntax.Formula)
    (recursiveFuel : Nat) :
    Complete (bits := bits) holeKey fits admits graph templates checkEmpty edgesOf stop order
      formulas solver recursiveFuel := by
  induction recursiveFuel with
  | zero =>
      intro inventory caller memos before metadata seed ceiling packet bounded known
        _selectionMembers _selectionLength _initialMass _reserved
      obtain ⟨outcome, running, resources⟩ := resume_zero_outcome_resources
        holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver inventory
        caller memos before metadata (SourcePruningEnumerationRestart.decision stop order metadata before)
        seed packet bounded known
      exact ⟨0, outcome, fun extra => by simpa only [run, Nat.zero_add] using running extra, resources⟩
  | succ recursiveFuel ih =>
      intro inventory caller memos before metadata seed ceiling packet bounded known
        selectionMembers selectionLength initialMass reserved
      exact run_finite_succ_complete_resources
        holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver recursiveFuel ih
        inventory caller memos before metadata seed ceiling packet bounded known
        selectionMembers selectionLength initialMass reserved
