                                                                  edgesOf reached after saved same processed emitted endCaller endQueries folded
                                                                dsimp only [second] at retained
                                                                simp only [folded, finish] at actual
                                                                simpa only [retained, finish] using actual

/-- A complete actual prepared driver run stays exact at larger recursive depth. -/
theorem run_complete_moreDepth
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat)
    (workFuel recursiveFuel larger : Nat) (increase : recursiveFuel ≤ larger)
    (metadata : Metadata Typing) (caller : Caller width) (queries : Queries) (before : Cached)
    (outputs : List (Output width Typing)) (finalCaller : Caller width) (finalQueries : Queries)
    (actual : run holeKey fits admits graph templates checkEmpty edgesOf stop order workFuel recursiveFuel
      metadata caller queries before = .complete outputs finalCaller finalQueries) :
    run holeKey fits admits graph templates checkEmpty edgesOf stop order workFuel larger
      metadata caller queries before = .complete outputs finalCaller finalQueries :=
  resume_complete_moreDepth holeKey fits admits graph templates checkEmpty edgesOf stop order
    workFuel recursiveFuel larger increase metadata caller queries before
    (SourcePruningEnumerationRestart.decision stop order metadata before)
    outputs finalCaller finalQueries actual

