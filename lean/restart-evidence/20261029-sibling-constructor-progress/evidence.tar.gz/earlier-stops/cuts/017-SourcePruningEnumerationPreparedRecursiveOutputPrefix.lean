                      (EnumerationExpandableIndex.frame core before))

variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Preserve every actual prepared resume output when only recursive depth increases. -/
theorem resume_outputs_moreDepth
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat)
    (workFuel recursiveFuel larger : Nat) (increase : recursiveFuel ≤ larger) :
    ∀ (metadata : Metadata Typing) (caller : Caller width) (queries : Queries) (before : Cached)
      (next : Option Next),
      List.IsPrefix (SourcePruningEnumerationHookInvocation.hookOutputs
        (resume holeKey fits admits graph templates checkEmpty edgesOf stop order workFuel recursiveFuel
          metadata caller queries before next))
        (SourcePruningEnumerationHookInvocation.hookOutputs
          (resume holeKey fits admits graph templates checkEmpty edgesOf stop order workFuel larger
            metadata caller queries before next)) := by
  induction recursiveFuel generalizing larger with
  | zero =>
      intro metadata caller queries before next
      cases next with
      | none => cases larger <;> exact List.prefix_rfl
      | some next =>
          cases next with
          | done | stuck => cases larger <;> exact List.prefix_rfl
          | expand uv => exact List.nil_prefix
