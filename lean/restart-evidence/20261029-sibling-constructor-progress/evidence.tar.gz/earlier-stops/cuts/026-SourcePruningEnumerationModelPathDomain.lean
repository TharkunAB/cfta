variable {Symbol Guard : Type}

/-- The actual stored recursion key retains the finite original relative path bounds. -/
theorem stored_recursion_key_paths
    (language : NodeLanguage Symbol) (meaning : Guard → Term Symbol → Prop)
    (state : State Symbol Guard) (whole : Term Symbol) (assignment : Nat → Term Symbol)
    (satisfied : Satisfies language meaning assignment state)
    (origins : AssignmentOrigins whole state.counter assignment)
    (canonical : Canonical state)
    {uv handle : Nat} {scs : List Suspended}
    (inside : uv < state.counter)
    (stored : state.values[uv]? = some (.unenumerated (some handle) scs)) :
    ∀ trie ∈ (EnumerationState.recursionKey handle scs).tries,
      (∀ path ∈ trie, path ∈ relativePaths whole) ∧
      trie.length ≤ (relativePaths whole).length := by
  intro trie member
  have source : trie ∈ scs.map (fun sc => EqualityTrie.fromPathTrie sc.trie) := by
    simpa only [EnumerationState.recursionKey, List.mem_mergeSort, List.mem_eraseDups]
      using member
  obtain ⟨sc, present, rfl⟩ := List.mem_map.mp source
  constructor
  · intro path represented
    exact (stored_suspended_paths language meaning state whole assignment satisfied origins inside stored
      sc present path represented).1
  · exact stored_trie_length language meaning state whole assignment satisfied origins canonical inside stored
      sc present

