# Audit import placement repair

The first aggregate build failed because the new Audit import was at EOF.
Imports must precede the other commands. Move this one import to the beginning.
The complete old Audit body remains byte-exact after the new import.
The failed aggregate source copy, raw log and report remain in audit-final-build.
The old successful axiom count printed before the error does not cover the two
new modules. Only the repaired complete Audit can establish their audit result.
