from pathlib import Path
import json

r = Path('/home/tritlo/Code/mcfta')
p = Path('/tmp/mcfta-sibling-constructor-progress-20261029')
old = (r / 'lean/MicroCFTA/SourcePruningEnumerationPreparedFiniteHeadCoverage.lean').read_text()
header = old[:old.index(' := by\n', old.index('theorem head_finite_complete_resources_accepting\n'))]
header = header.replace('import MicroCFTA.SourcePruningEnumerationPreparedFiniteResources\n', 'import MicroCFTA.SourcePruningEnumerationPreparedFiniteResources\nimport MicroCFTA.SourcePruningEnumerationConstructorIteration\n')
start = header.index('/-!\n'); end = header.index('namespace ', start)
header = header[:start] + '''/-!
# Progress at the actual prepared finite head

The operational head keeps its original bound and complete resource result.
An original accepting assignment gives the same actual receipt a strict
pending-term decrease and a complete recursive Packet. A comparison at a
common sufficient work index identifies the constructive and actual receipts.
-/
''' + header[end:]
header = header.replace('open EnumerationState ', 'open EnumerationProgress EnumerationState ', 1)
header = header.replace('/-- Retain every prepared head resource and construct its actual accepted captured receipt. -/', '/-- The actual stable head preserves its resources and derives strict accepted-model progress. -/')
header = header.replace('theorem head_finite_complete_resources_accepting\n', 'theorem head_finite_complete_resources_accepting_progress\n')
needle = '    (packet : Packet formulas solver inventory caller memos metadata before)\n'
assert needle in header; header = header.replace(needle, needle + '    (proper : ProperState before.core)\n')
assert header.endswith('extended afterCache.core')
header += ''' ∧
          ProperState afterCache.core ∧
          EnumerationStorageProgress.pendingSize afterCache.core extended + 1 ≤
            EnumerationStorageProgress.pendingSize before.core assignment ∧
          ∃ (progressInventory : Inventory) (progressMemos : Memos),
            Post formulas solver progressInventory caller middleCaller progressMemos ∧
            progressMemos.query = saved ∧
            Packet formulas solver progressInventory middleCaller progressMemos metadata afterCache'''
body = ''' := by
  obtain ⟨bound, receipt, middleCaller, saved, middleMemos, middleInventory, resources, _accepting⟩ :=
    head_finite_complete_resources_accepting holeKey fits admits graph templates checkEmpty edgesOf stop order
      metadata recursiveFuel seed formulas solver inventory caller memos before uv handle scs
      parentEntry storedEdges depth free edge packet ready stored parentAvailable parentClosed selected incoming
      bounded known selectionMembers selectionLength capturedMass inherited initialMass inheritedLength reserved
  refine ⟨bound, receipt, middleCaller, saved, middleMemos, middleInventory, resources, ?_⟩
  intro ambient assignment satisfied accepted
  have inheritedModel : ∀ sc ∈ scs, Suspended.Holds assignment (assignment uv) sc := by
    have model := satisfied.1.2 uv
    simp only [heap, stored, Option.getD_some, slot, Fragments.slotSatisfies,
      List.forall_mem_map] at model
    exact model.2
  obtain ⟨tries, residual, _terms, projected, _valid, _termShape, _children,
    _length, allowed, _ownEqualities, _residualHolds⟩ :=
    SourcePruningEnumerationSelectedEdgeAdmission.selected_admission formulas solver inventory caller memos
      parentEntry storedEdges depth free edge scs packet.context parentAvailable selected ambient assignment
      (assignment uv) accepted inheritedModel
  obtain ⟨children, own⟩ := SourcePruningEnumerationRecursiveReservation.edge_shape_from_packet
    seed formulas solver inventory caller memos metadata before packet bounded known
    parentEntry storedEdges depth free parentAvailable edge selected
  have costBound := SourcePruningEnumerationRecursiveReservation.edge_cost_le seed inherited scs
    before.core.counter edge children own inheritedLength
  have actualCost : edgeCost scs before.core.counter edge =
      SourcePruningEnumerationSelectedEdge.cost edge scs before.core.counter tries := by
    simp only [edgeCost, allowed, ↓reduceIte, projected]
  have actualReserved : SourcePruningEnumerationIncomingReservation.Reserved bits seed
      (SourcePruningEnumerationSelectedEdge.cost edge scs before.core.counter tries) := by
    simpa only [actualCost] using reserved.edge costBound
  obtain ⟨r, n, p, h, k, fragment, actualCaller, recorded, afterCache, actualSaved, progressMemos,
    progressInventory, _afterRoots, extended, original, capturedRun, afterPacket, afterProper,
    _admitted, _history, _pendingInputs⟩ :=
    SourcePruningEnumerationConstructorIteration.accepted_prepared_constructor_packet
      seed formulas solver inventory caller before checkEmpty parentEntry storedEdges depth free edge scs memos
      metadata packet proper uv handle ready incoming stored parentAvailable parentClosed selected
      ambient assignment (assignment uv) rfl satisfied accepted tries residual projected bounded actualReserved known
  rcases original with ⟨_selectedRun, _finalizeRun, progressPost, progressQueries, agree, originalSatisfied,
    filled, _recordedSatisfied, afterSatisfied, _safe, _canonical, _roots, _storage, _realized,
    _counts, _flags, _fits, _known, decrease⟩
  let padding := r + n + p + h + k
  let work := bound + padding
  have rl : r ≤ work := by dsimp [work, padding]; omega
  have nl : n ≤ work := by dsimp [work, padding]; omega
  have pl : p ≤ work := by dsimp [work, padding]; omega
  have hl : h ≤ work := by dsimp [work, padding]; omega
  have kl : k ≤ work := by dsimp [work, padding]; omega
  have capturedAt := capturedRun (work - r) (work - n) work work (work - k) pl hl
  simp only [Nat.add_sub_of_le rl, Nat.add_sub_of_le nl, Nat.add_sub_of_le kl] at capturedAt
  have receiptSame : receipt = .complete fragment actualCaller actualSaved afterCache :=
    Option.some.inj ((resources.1 padding).symm.trans capturedAt)
  have reached : advance receipt = some (middleCaller, saved) := by
    rcases resources.2.2.2.2.2.2.2.2.2 with ⟨unsupported, _allowed, _projected⟩ |
      ⟨_outcome, advanced, _callback, _resources, _captured⟩
    · rw [receiptSame] at unsupported
      cases unsupported
    · simpa only [resources.2.2.1] using advanced
  rw [receiptSame] at reached
  change some (actualCaller, actualSaved) = some (middleCaller, saved) at reached
  have sameEndpoint := Option.some.inj reached
  have sameCaller : actualCaller = middleCaller := congrArg Prod.fst sameEndpoint
  have sameQueries : actualSaved = saved := congrArg Prod.snd sameEndpoint
  refine ⟨extended, fragment, afterCache, agree, originalSatisfied, ?_, filled, ?_, afterProper,
    decrease, progressInventory, progressMemos, ?_, ?_, ?_⟩
  · simpa only [sameCaller, sameQueries] using receiptSame
  · simpa only [sameCaller] using afterSatisfied
  · simpa only [sameCaller] using progressPost
  · exact progressQueries.trans sameQueries
  · simpa only [sameCaller] using afterPacket

end MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources
'''
target = r / 'lean/MicroCFTA/SourcePruningEnumerationPreparedFiniteHeadProgress.lean'
assert not target.exists(); target.write_text(header + body)
(p / 'modules.json').write_text(json.dumps(['SourcePruningEnumerationPreparedFiniteHeadProgress', 'SourcePruningEnumerationPreparedFiniteSiblingProgress'], indent=2) + '\n')
(p / 'head-progress-v1.json').write_text(json.dumps([['lake','head-progress-v1-build','MicroCFTA.SourcePruningEnumerationPreparedFiniteHeadProgress'], ['strict','head-progress-v1-strict','SourcePruningEnumerationPreparedFiniteHeadProgress']], indent=2)+'\n')
print('Added actual stable-head progress theorem; original coverage source unchanged.')
