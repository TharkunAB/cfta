from pathlib import Path
import json

r = Path('/home/tritlo/Code/mcfta')
p = Path('/tmp/mcfta-sibling-constructor-progress-20261029')
old = (r / 'lean/MicroCFTA/SourcePruningEnumerationPreparedFiniteSiblingCoverage.lean').read_text()
source = old.replace('import MicroCFTA.SourcePruningEnumerationPreparedFiniteHeadCoverage\n', 'import MicroCFTA.SourcePruningEnumerationPreparedFiniteHeadProgress\n')
start = source.index('/-!\n'); end = source.index('namespace ', start)
source = source[:start] + '''/-!
# Strict constructor progress in the actual prepared sibling scan

The complete ordered scan retains all resource and output certificates.
The chosen accepting event returns a compatible model, a strict pending-term
decrease and a complete recursive Packet. An earlier stopped hook retains
its exact failure, outputs and resource endpoint. The captured proper state
passes unchanged between siblings; only native effects advance.
-/
''' + source[end:]
source = source.replace('open EnumerationState ', 'open EnumerationProgress EnumerationState ', 1)
source = source.replace('/-- A supported indexed prefix reaches its accepting head or retains an exact earlier hook stop. -/', '/-- The actual chosen head has strict progress or an exact earlier hook failure. -/')
source = source.replace('theorem alternatives_finite_complete_resources_accepting\n', 'theorem alternatives_finite_complete_resources_accepting_progress\n')
needle = '    (packet : Packet formulas solver inventory caller memos metadata before)\n'; assert needle in source
source = source.replace(needle, needle + '    (proper : ProperState before.core)\n')
needle = '                      extended afterCache.core) ∨\n'; assert needle in source
source = source.replace(needle, '''                      extended afterCache.core ∧
                    ProperState afterCache.core ∧
                    EnumerationStorageProgress.pendingSize afterCache.core extended + 1 ≤
                      EnumerationStorageProgress.pendingSize before.core assignment ∧
                    ∃ (progressInventory : Inventory) (progressMemos : Memos),
                      Post formulas solver progressInventory headCaller branchCaller progressMemos ∧
                      progressMemos.query = branchQueries ∧
                      Packet formulas solver progressInventory branchCaller progressMemos metadata afterCache) ∨
''')
source = source.replace('SourcePruningEnumerationPreparedNativeHookResources.head_finite_complete_resources_accepting\n', 'SourcePruningEnumerationPreparedNativeHookResources.head_finite_complete_resources_accepting_progress\n')
source = source.replace('depth free edge packet ready stored parentAvailable parentClosed', 'depth free edge packet proper ready stored parentAvailable parentClosed')
source = source.replace('_agree, _original, impossible, _filled, _final⟩', '_agree, _original, impossible, _filled, _final, _proper, _decrease, _progress⟩')
source = source.replace('completed, filled, afterSatisfied⟩', 'completed, filled, afterSatisfied, afterProper, decrease, progressResources⟩')
source = source.replace('originalSatisfied, filled, afterSatisfied⟩', 'originalSatisfied, filled, afterSatisfied, afterProper, decrease, progressResources⟩')
source = source.replace('oldSatisfied, filled, afterSatisfied⟩', 'oldSatisfied, filled, afterSatisfied, afterProper, decrease, progressResources⟩')
source = source.replace('''                    completed, filled, afterSatisfied⟩ := headAccepting''', '''                    completed, filled, afterSatisfied, afterProper, decrease, progressResources⟩ := headAccepting''')
source = source.replace('''                    simpa only [actualSame.1] using afterSatisfied⟩''', '''                    simpa only [actualSame.1] using afterSatisfied, afterProper, decrease, by
                    simpa only [actualSame.1, actualSame.2] using progressResources⟩''')
target = r / 'lean/MicroCFTA/SourcePruningEnumerationPreparedFiniteSiblingProgress.lean'
assert not target.exists(); target.write_text(source)
(p / 'sibling-progress-v1.json').write_text(json.dumps([['lake','sibling-progress-v1-build','MicroCFTA.SourcePruningEnumerationPreparedFiniteSiblingProgress'], ['strict','sibling-progress-v1-strict','SourcePruningEnumerationPreparedFiniteSiblingProgress']], indent=2)+'\n')
print('Added chosen-event progress to the complete ordered sibling proof; old source unchanged.')
