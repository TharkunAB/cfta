import json,subprocess,sys
from pathlib import Path
a=Path(__file__).parent
mods=json.loads((a/'modules.json').read_text())
checks={}
for i,module in enumerate(mods[:5],1):
 label=f'strict-first-{i:02d}'
 completed=subprocess.run([sys.executable,str(a/'check-installed.py'),'strict',label,module])
 if completed.returncode: raise SystemExit(completed.returncode)
 checks[module]=label
 (a/'strict-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
