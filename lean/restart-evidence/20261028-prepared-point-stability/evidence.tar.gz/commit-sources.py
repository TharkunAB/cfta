from pathlib import Path
import subprocess,json
r=Path('/home/tritlo/Code/mcfta');a=Path(__file__).parent
changes=[('Prove stability of completed enumeration workers',['SourcePruningEnumerationDispatchStability','SourcePruningEnumerationFoldStability','SourcePruningEnumerationIncomingNodeStability','SourcePruningEnumerationIncomingCacheAdapterStability']),('Preserve completed terminal and opaque observations at larger bounds',['SourcePruningEnumerationTerminalPrefixStability','SourcePruningEnumerationCachedPrepareStability','SourcePruningEnumerationCachedFoldStability','SourcePruningEnumerationTerminalStability','SourcePruningEnumerationCachedTerminalStability','SourcePruningEnumerationChildDispatchStability','SourcePruningEnumerationSelectedOpaqueStability']),('Derive prepared opaque semantics from original history resources',['SourcePruningEnumerationSelectedPreparationPointResources','SourcePruningEnumerationPreparedPrefixPointResources','SourcePruningEnumerationPreparedOpaquePointLanguage']),('Preserve native arity at prepared completion points',['SourcePruningEnumerationPreparedHeadReceiptArity','SourcePruningEnumerationSelectedOpaqueArity','Audit'])]
records=[]
for message,modules in changes:
 for cmd in [['git','add','--',*[f'lean/MicroCFTA/{m}.lean' for m in modules]],['git','diff','--cached','--check'],['git','commit','-m',message]]:
  result=subprocess.run(cmd,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);records.append({'command':cmd,'exit_code':result.returncode,'output':result.stdout});(a/'source-commits.json').write_text(json.dumps(records,indent=2)+'\n');print(result.stdout,end='')
  if result.returncode:raise SystemExit(result.returncode)
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();records.append({'head':head,'message':message});(a/'source-commits.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'source_head':head}))
