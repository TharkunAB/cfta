# Prepared opaque receipt point soundness candidate

Recorded: 2026-10-28T17:03:51+01:00.
Owned area: `/tmp/mcfta-prepared-point-stability-20261028/incoming/receipt-sound-v1`.
Root owns all repository changes, compilation, Git and network operations.
This bounded task changed no repository file and ran no compiler or native check.

## Result

One additive Lean module contains one theorem:
`HistoryAdmission.prepared_opaque_sound_retained`.
The theorem is a candidate. Root must compile it before claiming a checked result.
Candidate SHA-256: `c33a0471bc3af959c94a7341a43ec43a3c66bf4740a56180ab68fbf9dc62ed55`.
Candidate size: 9771 bytes, 134 lines.

The theorem consumes the actual prefix and the relevant literal fields of the
existing selected receipt. It does not define a history type or endpoint contract.
After the caller opens `SelectedHistoryReceipt` and its opaque arm, every local
premise is already a field of that receipt, except the explicit retention gate.
The original `HistoryAdmission`, its actual prefix execution and `PrefixValid`
supply the resources. No opaque stability family is required from the caller.

## Exact local premises

| Wrapper input | Existing source |
| --- | --- |
| Original admission, actual `runPrefix`, and `PrefixValid` | Actual `ResourceHistory` selected constructor and `HistoryAdmission` |
| Narrowed `Packet`, `Ready`, stored original handle and bucket | Common `SelectedHistoryReceipt` fields |
| Stable preparation family and literal work-fuel preparation point | Common `SelectedHistoryReceipt` fields |
| Actual prepared `Packet` at the full entered cache | Common `SelectedHistoryReceipt` field |
| Prepared opaque dispatch gate and literal successful complete point | Literal opaque disjunct in `SelectedHistoryReceipt` |
| Prepared value is a node, or the bucket contains a terminal, or the bucket is empty | Explicit retention condition required by `stable_complete_sound_retained_resources` |

Both full `nextMemos` and `returnedMemos` remain in the interface. The run consumes
`nextMemos.query` and returns `returnedMemos.query`. The entered and final cache
values remain the exact full values in the completion equation. The preparation
family refers to that entered cache's exact core.

## Proof route

1. `HistoryAdmission.prepared_opaque_resources` derives `Fits`, guard `Heap`, and
   `Reserved` for the actual prepared heap and bucket length.
2. `SelectedPreparation.identify_complete` identifies the actual stable
   preparation. It supplies the prepared heap model, the exact preparation model
   equivalence, the original decoded lookup, and the prepared/source language
   equivalence.
3. `lookupNode_keeps` transfers the original decoded source lookup through
   `preparationPost.effects.keeps` to the actual prepared caller. This preserves
   the original decoded node. It does not identify it with the prepared node.
4. `SelectedOpaqueDispatch.complete_stable` derives the full diagonal family from
   the literal complete point. All five fuel inequalities are `workFuel <=
   workFuel + extra`. The fragment, caller, query and cache are identical.
5. `stable_complete_sound_retained_resources` derives the prepared input model,
   meanings for both distinct nodes, all original suspended constraints and the
   exact fragment equation.
6. The preparation model equivalence restores the original narrowed input model.

## Exact conclusion and remaining scope gates

For each ambient environment, residual interpretation and assignment, a model of
the exact final core at the exact returned caller implies a model of the original
narrowed core at its original caller. The selected term has both the prepared
meaning and decoded source meaning. It satisfies every suspended constraint in
that original bucket. Filling the returned fragment gives the selected term.

The retention gate stays explicit. A non-node prepared boundary with a nonempty
bucket that contains no terminal is outside this theorem. The existing retained
semantic theorem has no forward-arity premise. No arity gate was removed or
replaced. No global `ResourceHistory` induction, recursive callback semantics,
whole-generator completeness, or Haskell correspondence is claimed here.
The wrapper does not discharge the ordinary receipt arm.

The wrapper keeps the stable preparation family already present in the original
receipt. It derives opaque stability from a literal successful point. It adds no
future model, semantic oracle, new reservation, or new endpoint invariant.

## Source and validation evidence

`manifest.json` records whole source snapshot hashes, exact read ranges, and
literal byte-preserving cuts. Nine relevant source files were copied in full.
The reviewed ranges are explicit. Unlisted ranges in partial source reviews
were copied for identity and were not claimed as reviewed.

Root reported at 2026-10-28 16:59 CET that
`SelectedOpaqueStability.complete_stable` and all 13 current new modules passed
strict Lean with `warningAsError` and `linter.all`, without budget changes.
This is dependency evidence reported by Root. This child ran no Lean command.
The new wrapper itself remains uncompiled in this bounded task.

No `sorry`, `admit`, custom axiom, `native_decide`, budget option, or linter
suppression occurs in this candidate. No Haskell source changed, so this task
produced no new Haskell fix to record in `FINDINGS`.

The candidate, copied sources, literal cuts and this report are immutable on
completion. Root may install a copy and make any required repository repair.
