# Incoming successful point stability

Completed: 2026-10-28T16:42:56+01:00.

Two additive uncompiled module drafts are ready in candidate-v1.
Root must install, compile and strictly check them.
No existing source byte was changed.
All seven retained source files still matched the repository on the final read.
The previous evidence areas were not modified.

The first module adds IncomingNode.run_ok_stable and run_singleton_stable.
The general theorem requires an actual .ok (some raw) observation.
It also requires raw = [] or raw = [.ok ((), returned)] for an actual returned core.
This condition excludes representativeFuel error rows.
An actual representative-fuel error can change when representative fuel increases.
The candidate does not claim stability for that observation.

The point proof retains the exact successful findRoot result and its compressed forest.
An actual native done result retains its whole checked state at larger native fuel.
An actual enabled emptiness done result retains its answer, checked state, fourth memo and queries.
The finish action has no remaining work-fuel argument.
The result retains the exact raw list, caller, query memo and outer read state.
The four fuel arguments increase under the explicit gates r <= R, n <= N, p <= P and h <= H.

The second module adds IncomingCacheAdapter.adapt_some_stable and run_some_stable.
An actual some cache fixes the successful indexed write.
NativeIndex.write_some_moreFuel retains the entire same written cache at k <= K.
The adapter frames that same write with the same returned raw core or rejected core.
The combined theorem retains the exact raw/caller/query/read tuple and the same full cache.
It does not claim that a none adapter candidate remains none.
CachedIncoming has no independent run definition. It needs no separate run-stability layer.

All endpoint and fuel parameters are implicit.
Explicit run_ok_stable arguments are observed, successful, enoughR, enoughN, enoughP, enoughH.
Explicit run_singleton_stable arguments are observed, enoughR, enoughN, enoughP, enoughH.
Explicit run_some_stable arguments add enoughK after the same general argument order.
The terminal-chain owner received these exact interfaces and module paths.

No Context, reservation, WordRanges, semantic model or future stable-family premise was added.
The proof does not identify a prepared value with a stored source value.
The reached caller retains its actual native tables, fourth memo and merge table.
The query field remains the actual SourceEndpointMemo.Memos.
The draft does not reconstruct a full EndpointMemoGateTrace.Memos from that field.

The whole-source snapshots and SHA-256 identities are in baseline-v1 and baseline-dependency-v1.
REPORT.json gives every exact read range and source identity.
The literal-read-cuts-v1 directory preserves the unmodified bytes of each cited source range.
The initial combined source output was truncated.
It was followed by untruncated reads of all definitions and interfaces used here.
The omitted text from the first request is not review evidence.

No compiler, build, native execution, Git, network or board operation ran here.
No repository write or write to earlier frozen evidence areas occurred.
No sorry, admit, custom axiom, native_decide, limit change or linter suppression was added.
No global history, semantic induction or arity scope was started.
This is the bounded candidate handoff. Root owns the next check.
