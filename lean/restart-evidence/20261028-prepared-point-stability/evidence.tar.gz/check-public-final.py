import json,subprocess,sys
from pathlib import Path
a=Path(__file__).parent
commands=[('lake','build-audit-final-1','MicroCFTA.Audit'),('strict','strict-audit-final-1','Audit'),('public','public-readback-final')]
for args in commands:
 result=subprocess.run([sys.executable,str(a/'check-installed.py'),*args])
 if result.returncode:raise SystemExit(result.returncode)
 if args[0]=='strict':
  p=a/'strict-checks.json';d=json.loads(p.read_text());d['Audit']=args[1];p.write_text(json.dumps(d,indent=2)+'\n')
