import json,subprocess,sys
from pathlib import Path
a=Path(__file__).parent
checks=json.loads((a/'strict-checks.json').read_text())
commands=[('lake','build-opaque-arity-1','MicroCFTA.SourcePruningEnumerationSelectedOpaqueArity')]
commands += [('strict',f'strict-receipts-final-{i:02d}',m) for i,m in enumerate(json.loads((a/'modules.json').read_text())[13:],14)]
for kind,label,arg in commands:
 result=subprocess.run([sys.executable,str(a/'check-installed.py'),kind,label,arg])
 if result.returncode:raise SystemExit(result.returncode)
 if kind=='strict':
  checks[arg]=label;(a/'strict-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
