# Forward arity audit

The native preservation lemmas needed for this route already exist.
The remaining work is prepared producer and recursive callback composition.
No smaller native intersection, conjunction or cap-edit operation lemma was found missing.
This report does not assert a completed whole prepared-driver arity theorem.

The source base is the parent-reported `formalize 74164b679`.
`MANIFEST.json` binds every recorded source and literal read cut to its full SHA256.
No compiler, native execution, Git, network or repository write ran here.

## Exact invariant and original input

`SourcePruningEnumerationArityOrigins.Heap state` quantifies over every stored edge key.
For each record, `Fits key.constraint key.children.length` requires every successful projection to pass `arityAllows` at every fresh start ID.
It covers the entire native edge-record heap. Availability of one requested root is weaker.
It does not require successful projection. A missing projection makes `Fits` vacuous.

`constructed_heap_of_source expression checked value state built` derives this invariant for the exact actual closed build from empty.
`SourceChecked expression` requires normalized equality fields and an actual accepted source constructor test at each original edge's syntactic child count.
The actual construction equation must identify the same initial native heap used by the caller.
A certificate for some other heap or for one available value is insufficient.
`MkEdge.Receipt.preserves_arity_heap` and `MkEdge.RejectReceipt.preserves_arity_heap` cover actual checked allocations and rejected sentinel construction from an input Heap.

The current `Recursive.Packet` has native context, safe storage, pending references, cache validity, dependency order and metadata bounds.
It carries no SourceChecked construction certificate or arity heap.
The finite admission additionally carries numeric Fits, guard-carrier membership, a suspended-mass bound and a reservation.
Those are separate invariants.
`OriginPolicies` constrains term subtrees, template avoidance and program encoding. It does not certify native edge construction.
Keep a genuine original Heap or its exact checked-construction derivation explicit.
This audit does not supply a full Packet counterexample to Heap.

`CheckedProjection.raw_ready_counterexample` concerns a raw normalized but unprojectable edge.
It is not a counterexample to ArityOrigins.Heap: its projection is none, so Fits is vacuous.
It is not a full Context/Packet, checked public-input or Haskell counterexample.
The FINDINGS cuts retain these limits and the distinction between raw buildEdges and checked mkEdge.
Older FINDINGS paragraphs about missing native/query preservation are superseded by the existing modules below.

## Existing forward composition

| Operation | Existing lemma | Required boundary |
| --- | --- | --- |
| Native query, all finite outcomes | `NativePrefixArity.node_query_execute_heap`, `edge_query_execute_heap` | Original physical Good, input Heap and actual InputsThrough for that finite physical execution. |
| Completed rich query | `NativePrefixArity.node_query_heap`, `edge_query_heap` | Original physical Good, input Heap and the actual completed rich Trace. Do not infer that Trace from arbitrary raw done. |
| Actual target/shared-target request | `AllocatedTargetQuery.Receipt.arity_heap`, `SharedTargetArity.*_heap` | Actual receipt/read graph, original availability/readiness and input Heap. |
| Conjunction including cache hits | `ConjunctionArity.call_heap` | Actual Call graph, Ready, available original operands and input Heap. |
| Cap and class edits | `ClassEditArity.node_heap`, `children_heap`, `rows_heap`, `list_heap`; `class_heap`, `fold_heap`, `pass_heap` | Actual Reads, admitted domains/coherent active classes, Ready, available values, safe edits, stored/covered memos, valid global memos and input Heap. |
| Local reduction and Parent | `LocalReductionArity.reduction_heap`, `literal_heap`; `ParentArity.parent_heap` | Actual read/worker graph and its existing original admission, ranges and memo gates; input Heap. |
| Partial worker | `PartialActualArity.node_call_heap`, `node_body_heap`, `edge_call_heap`, `edge_body_heap`, `rows_heap`, `descendants_heap`, `children_heap`, `walk_heap` | Actual source-aligned Reads/Checks, Context, inherited readiness, original availability/residency and input Heap. |
| Literal query and child fold | `IncomingQuery.raw_done_resources_arity`; `Dispatch.observed_heap`; `Fold.observed_heap`; `ChildDispatch.observed_heap` | Exact successful point observations plus the original resource, cache, pending and availability admission; input Heap. |
| Selected narrowing/prefix | `NativeNarrowArity.*_heap`; `SelectedStep.prefix_heap` | Original Facts/Context and actual available decoded value or PendingRealized plus actual PrefixValid; input Heap. |
| Actual selected preparation | `SelectedPreparation.run_heap` / `complete_heap` | Original Packet, actual stored handle and decoded lookup, exact preparation result/family and input Heap. These support Mu and Union preparation. |
| Selected-edge traversal and residual | `SelectedEdge.complete_with_fragments_resources_arity` | Separate available closed prepared parent, selected row, Packet-derived cache facts, actual projection/arity check, original reservation and input Heap. Returned Heap covers all records. |

No arbitrary closure law for raw constraint conjunction is used.
No future model or later/output arity premise is a substitute for these original admissions.
`Post.arity_before` and `ResourceHistory.arity_before` remain backward reflection results.
They do not derive arity of newly added records from an earlier heap.

## Additive prepared completed-head candidate

The immutable candidate is `candidate/MicroCFTA/SourcePruningEnumerationPreparedHeadReceiptArity.lean`.
Its public interface is `CompletedHeadReceipt.arity_after receipt heap`.
It concludes arity of that receipt's actual reached caller from arity of its actual input caller.
It takes no later arity, model, extra domain condition or source/prepared equality.
The parent owns compilation and integration. This report makes no compilation claim.

The proof uses `SelectedEdge.complete_with_fragments_resources_arity` directly.
`receipt.admission.parentAvailable` and `parentClosed` refer to the separate prepared parent.
The original stored handle supplies only the actual suspended bucket facts.
The proof aligns the selected-edge stable family with `receipt.running` at one common work bound.
The literal CapturedEdge finalizer map then identifies the same native caller.
The finalizer changes the enumeration cache, not that native caller.
A stopped selected-edge result cannot match the actual completed captured result.

The old `CapturedEdge.complete_with_history_resources_arity` expects the stored handle to decode as its ordinary parent.
It cannot be applied to a Mu/Union source by identifying that source with its prepared parent.
The direct selected-edge bridge avoids this restriction.

## Remaining whole prepared-driver attachment

The selected receipt's ordinary branch begins after earlier sibling callbacks.
It records a Post from the prepared scan caller to an existential headCaller.
The new local head candidate starts at that headCaller.
An original prepared-scan Heap therefore still needs transport through the actual preceding scan and callbacks.
The selected output's later ResourceHistory tail does not describe those earlier callbacks.
The exact bounded obstruction is recorded in `history-arity-v1/OBSTRUCTION.md`.

A genuine prepared finite producer must preserve both the aggregate endpoint Heap and every emitted output's Heap.
The aggregate fact is needed even when an earlier callback emits zero outputs.
The existing old-worker OutcomeResourcesWithArity and finite arity producers provide a proof pattern.
They do not establish execution identity with the prepared worker.
No old/new cast is valid here.

## Haskell scope

This audit changed no Haskell source and executed no Haskell check.
It establishes no new Haskell defect or required fix.
Keep the existing FINDINGS repair handoffs unchanged.
The arity proof boundary does not itself request a Haskell patch.
