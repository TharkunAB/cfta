# Whole ResourceHistory forward arity: exact remaining attachment

The bounded direct induction is not complete.
No Lean candidate claims the missing ordinary-prefix result.
No desired result was added as a premise, axiom or history field.
The original HistoryAdmission and ResourceHistory remain unchanged.

## Intended statement

For the actual prepared ResourceHistory and a genuine Heap at its initial caller,
derive Heap at that same history's emitted output caller.
This is forward preservation, not the existing conditional backward arity reflection.

## Branches that compose directly

Stopped and done retain the input caller.
Parked uses the same native caller and full memos at its tail.
For selected, prefix_heap derives Heap at ordinaryCaller from original Packet realization and actual PrefixValid.
SelectedPreparation.run_heap derives Heap at the actual prepared heap from the exact preparation row.
The opaque arm can use SelectedOpaqueDispatch.complete_heap with the original prepared-point resources.
The selected recordTypes callback changes no native caller.
The remaining tail induction then uses Heap at its actual input.

The companion opaque wrapper has explicit proof arguments:
`SelectedOpaqueDispatch.complete_heap seed packet stored available closed bounded reserved known arity completed`.
All other data indices are implicit.
Its candidate is owned by opaque_meaning under terminal/arity-history-audit-v1/candidate.
This report does not assert its compilation result.

## Exact ordinary gap

PreparedFiniteHistoryContract.SelectedHistoryReceipt records in its ordinary branch:

- preparation of the separately indexed actual parent;
- a full Post from the prepared scan caller to headCaller;
- the actual selected CapturedEdge completion at headCaller;
- CompletedHeadReceipt for that same head invocation.

The new CompletedHeadReceipt.arity_after needs Heap at headCaller.
The initial preparation theorem supplies Heap only at the prepared scan caller.
The intervening headPost cannot supply forward arity of new edge records.

The retained SelectedContinuations.Invocation does contain actual scan provenance.
For the ordinary branch, it exposes HookInvocation.Invocation.
Its completed constructor contains an earlier actual CapturedEdge completion,
then `hook first headCaller headQueries headCache = .complete outputs middleCaller middleQueries`,
then the suffix invocation at middleCaller.
Its other constructor contains a non-complete captured receipt and its actual advance endpoint.
Thus every earlier callback endpoint and every handled receipt endpoint must preserve Heap.

ResourceHistory.selected has one later callback tail for the selected emitted output.
Its structural induction hypothesis covers that later tail.
It supplies no theorem about the aggregate endpoint of a different earlier callback.
An earlier callback can finish with zero outputs and still change the caller used by later siblings.
Per-output arity for that callback would then be vacuous.
The aggregate endpoint invariant is required.

This is an identified missing producer attachment.
It is not a checked counterexample to the intended actual-execution preservation theorem.
It is not evidence that an actual supported prepared run creates a bad arity edge.

## Smallest genuine route

1. Extend the prepared actual native head resource proof with returned Heap for every handled receipt shape.
   The accepted complete/stopped paths can use SelectedEdgeResourcesArity and literal CapturedEdge finalization.
   Rejected or unhandled paths retain the corresponding actual caller.
   This is a composition lemma over existing native proofs, not a new native primitive theorem.
2. Prove actual prepared callback preservation with the smaller-depth recursive theorem.
   Keep Heap at its aggregate reached caller, including an empty output list.
   The recording phase itself preserves the caller.
3. Induct over the actual sibling scan with those head and callback facts.
   Retain original Packet, resource seed, full memos, reservation and separate prepared parent throughout.
4. Carry aggregate and per-output Heap in the finite prepared producer's own result.
   Establish this by the finite-depth induction, not as an assumed later endpoint.
   The existing old OutcomeResourcesWithArity describes the needed pair of invariants.
   Do not cast the old worker into the prepared worker.
5. Attach those derived own-result facts to the unchanged actual output histories.

No later/output Heap, arbitrary forward Post rule, source/prepared identity or future model is an admissible repair.
A theorem that assumes arity for every earlier callback endpoint would only restate the missing proof.
