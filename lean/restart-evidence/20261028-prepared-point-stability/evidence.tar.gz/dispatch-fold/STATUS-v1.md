# Dispatch and fold stability candidate v1

This is an uncompiled additive draft. Root owns all installation and checking.
No repository file or frozen proof area was changed.

The intended public interfaces have all data and fuel indices implicit:

- `afterQuery_ok_stable observed enoughP enoughH`.
- `dispatch_ok_stable observed enoughNative enoughP enoughH`.
- `Fold.run_ok_stable observed enoughNative enoughP enoughH`.

Each theorem retains the exact outer `.ok` observation, including its optional
action or raw list, complete caller, query memo, and fold outer core.
The option can be `none`. A raw list can be empty or contain errors.
Only the singleton successful raw list continues the actual fold.
No state, range, model, resource, or future-success premise is added.

The dispatcher follows the already checked explicit case structure from
DispatchUnique. It uses native done_stable at `N - n`, then afterQuery stability.
The latter uses EnabledEmpty.check_done_stable only when the actual check is done.
The fold uses induction on the actual source list and exact action identity.

Potential elaboration repairs are confined to simplification and implicit indices.
No dependent full-match equation, arbitrary-call termination, or error-outcome
stability is asserted. CachedFold and terminal adapters remain outside this task.
READ-SCOPES-v1.json records exact current source hashes and complete required cuts.
