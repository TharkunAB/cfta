from pathlib import Path
import json,hashlib,subprocess,datetime
r=Path('/home/tritlo/Code/mcfta');a=Path(__file__).parent
records=[]
for name,size,expected in [('20261028-prepared-history-semantics',9183435,'5ef2c6192d1a12da427e2f613a82eae861be745fe9d2ce5436060a69f1c6767a'),('20261028-prepared-semantic-history-reboot',21237469,'929e5b83fd2e9c5f374ae6810c15a895937a97dbfa476e8be960e0ede4de2205')]:
 p=r/'lean/restart-evidence'/name/'evidence.tar.gz';b=p.read_bytes();assert len(b)==size and hashlib.sha256(b).hexdigest()==expected;records.append({'path':str(p.relative_to(r)),'bytes':size,'sha256':expected})
(a/'preserved-prior-archives.json').write_text(json.dumps(records,indent=2)+'\n')
request=json.loads((a/'point-semantics-board-request.json').read_text());reply=json.loads((a/'point-semantics-board-readback.json').read_text())['structuredContent']['items'][0];assert reply['id']==request['request_id'] and reply['content']==request['content'] and reply['metadata']==request['metadata']
(a/'board-validation.json').write_text(json.dumps({'request_id':reply['id'],'sequence':reply['sequence'],'content_matches':True,'metadata_matches':True,'comparison':'JSON objects; property order ignored'},indent=2)+'\n')
assert not (a/'FROZEN.json').exists();assert subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True)==''
paths=sorted(a.rglob('*'));assert not any(p.is_symlink() for p in paths)
payloads=[]
for p in paths:
 if p.is_file():
  b=p.read_bytes();payloads.append({'path':str(p.relative_to(a)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
seal={'write_halt':True,'source_head':'05570bab725e076f94d8371be1efa485c3877f9d','docs_head':'01505ac21fe6e8d3a49b94a51de9f3957a709984','sealed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner_writes_stopped':['root','dispatch-fold','incoming','terminal'],'payloads':payloads,'whole_goal_complete':False,'goal_status':'active'}
(a/'FROZEN.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps({'payloads_before_seal':len(payloads),'bytes_before_seal':sum(x['bytes'] for x in payloads),'write_halt':True}))
