# Ordinary child slot creation

Source-only. No compiler, evaluator, native, Haskell, Git, network, board, production, or spawn. Own this fresh directory only.

Produce at most160 lines for actual CachedChild.prepareOrdinary slot creation and constraint writing, with current recursive Node domain and common height cap. Derive actual encode/lookup from the existing producer. Derive grades only from actual canonical parent rows and children. Do not replace that tie with an arbitrary edgesOf callback. No hidden node certificate for None. Keep storage, alignment, and freshness gates explicit. No future output, Trace, or global invariant supplier.

Named OLD whole slots before acquisition:
1. lean/MicroCFTA/SourcePruningEnumerationCachedChild.lean255.
2. Optional exact frozen69L SourceSizedPrefixOrdinarySlotCreation-v1-UNCOMPILED.lean from the prior owned slot-creation review.

All other OLD sources use named bounded cuts or locators and count reuses by ORIGINAL path. The optional69L has not been checked by this owner and is not required as an import.
