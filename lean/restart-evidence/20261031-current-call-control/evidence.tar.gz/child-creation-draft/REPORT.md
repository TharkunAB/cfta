# Ordinary child slot creation

Date: 2026-10-31. Current source-only draft: SourceSizedPrefixOrdinaryChildCreation-v2-UNCOMPILED.lean, 98 lines. No compiler, evaluator, native, Haskell, Git, network, board, or production action was run. No subagent was started. No checked theorem is claimed.

## Actual producer law

prepareOrdinary_known uses the actual SourcePruningEnumerationCachedChild.complete producer. It derives the encode and physical lookup observations. It derives the actual prepareOrdinary result for a sufficient native index-reader fuel and every added fuel amount. It exports the exact hole, actual newly stored slot, counter increment, and KnownOrdinary at the SAME heap and height cap.

The slot holds an already resident native child handle. The operation allocates an enumeration slot. It does not allocate or mutate a native heap node. The proof covers the actual append and subsequent constraint write. The append either retains an old known handle or adds the decoded input handle. The actual list.set write either retains a prior member or stores that same input handle with the new suspended constraints.

The current input must be an outer ordinary node, Available and closed in the actual coherent heap. It must have recursive finite-ordinary Node domain and height at most the shared cap. An outer .node tag alone is not that recursive certificate. KnownOrdinary alone is not an Available or closure certificate.

All original creator gates remain explicit: StorageValid, PendingRealized, current representative roots, waiting counts, native flags, bounded suspended variables, and nonterminal constraints. The law also takes current KnownOrdinary. It does not take an encoded handle, future lookup, final cache, successful output, Trace, or future invariant witness. The actual producer derives those outputs.

The existence of sufficient index-reader/count fuel does not bound recursive worker depth. The existing StorageValid gate contains counter alignment. That gate, together with the existing creator, identifies the returned old counter as the fresh appended slot. The pure KnownOrdinary proof does not derive freshness or alignment from the predicate.

## Actual child grade

selected_input_grade derives the recursive child Node certificate, strict ordinary height loss relative to its parent, and the common height cap. It starts from a known pending parent handle, its current decoded ordinary parent observation, literal selected-row membership in InternedEdgeResidency.nodeEdges of that parent, and membership in the actual EdgeInputs.children list.

The proof identifies the decoded parent with the value from KnownOrdinary. It unfolds the canonical nodeEdges observation and the actual ordered child-input map. It uses the existing Node.child_lt lemma on the resulting literal row and child memberships. It does not assume the child domain or child height as a future result.

The existing EdgeInputs.complete producer separately derives child Available, closure, and current bucket gates from its Ready, parent Available/closed, actual selected row, original equality projection, and original cache gates. Those facts can feed the Some-creator law. A caller must also retain current availability and heap correspondence across any intervening query. The draft does not replace those actual producer gates with its height predicate.

## Precise remaining caller bridge

The two laws compose when the actual selected edge belongs to the decoded parent's canonical nodeEdges and the child input comes from that edge's actual EdgeInputs.children output. The Native ordinary wrapper still accepts an arbitrary edgesOf callback. Membership in edgesOf parent alone is not the canonical nodeEdges premise. This draft does not infer that missing tie, specialize the complete worker, or introduce an all-slot admission condition to bypass it.

Empty children create no Some slot through prepareOrdinary. Terminal suspended constraints take another branch. Union, Mu, and reference values are outside this ordinary creator law. None equality slots have no hidden native node certificate. Incoming or terminal intersection results, aliases, narrowing replacements, and later new cache bindings need their own actual returned-value and slot-update laws.

The proof does not close either whole worker. It gives no global original-depth bound, reset/history bound, public output-order identity, full signed/Map adaptation, literal bySize/fromRows/SCC/memo/allocation correspondence, or Haskell correspondence. No Haskell defect or fix was established. There is no Haskell FINDINGS entry from this task.

## Evidence and status

All 255 lines of the current CachedChild source were read. All 98 lines of the current draft and both complete statements/proofs were read. PUBLIC-CONTRACTS.md/json retain the exact namespace/import/notation context and statements. There is no compiler or public-output evidence for this draft.

The OLD acquisition ledger counts every copied semantic cut and reuse at its ORIGINAL path. Only the named CachedChild255 whole slot was used. The optional prior69L draft was not acquired or imported. KnownOrdinary uses a six-line definition cut. Other inputs use named domain, child-map, allocation, and standard-list cuts. The standard mem_or_eq_of_mem_set statement was read before use.

V1 remains retained. Source preflight qualified Heap as InternedConstructorTemplates.State in V2 because two opened namespaces have State names. No public statement or proof text changed. V1 has no claimed typed meaning. The upstream69L mixed-existential syntax failure reported by Root has no dependency here: the current creator output uses only typed existential binders.

No external private provider or helper is needed. All acquired source copies, full source and copy hashes, exact line vectors, complete statement context, read evidence, incidents, and both draft versions are retained. The verifier checks payloads and source metadata only. It does not execute the model or run Lean.
