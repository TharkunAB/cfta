from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
ledger = json.loads((ROOT / 'acquisitions.json').read_text())
unions = {}
for rec in ledger:
    original = Path(rec['source_path']).read_bytes()
    assert sha(original) == rec['source_sha256']
    assert len(original) == rec['source_bytes']
    lines = original.splitlines(keepends=True)
    assert len(lines) == rec['source_lines']
    ids = rec['actual_lines']
    assert ids == sorted(set(ids))
    rebuilt = b''.join((str(i).encode() + b':' if 'locator' in rec['classification'] else b'') + lines[i - 1] for i in ids)
    saved = (ROOT / rec['copy']).read_bytes()
    assert saved == rebuilt and sha(saved) == rec['copy_sha256']
    u = unions.setdefault(rec['source_path'], {'source_sha256': rec['source_sha256'], 'source_lines': rec['source_lines'], 'actual_lines': set()})
    u['actual_lines'].update(ids)
rows = []
for path, u in sorted(unions.items()):
    u['source_path'] = path
    u['actual_lines'] = sorted(u['actual_lines'])
    u['union_line_count'] = len(u['actual_lines'])
    u['named_whole'] = Path(path).name == 'SourcePruningEnumerationCachedChild.lean'
    if not u['named_whole']:
        assert u['union_line_count'] / u['source_lines'] < 0.75
    rows.append(u)
assert sum(x['named_whole'] for x in rows) == 1

contracts = json.loads((ROOT / 'PUBLIC-CONTRACTS.json').read_text())
current = ROOT / contracts['current_source']
source = current.read_text()
assert sha(current.read_bytes()) == contracts['current_source_sha256']
assert len(source.splitlines()) == 98 <= 160
assert len(contracts['contracts']) == 2
for c in contracts['contracts']:
    a, b = c['source_lines']
    header = ''.join(source.splitlines(keepends=True)[a - 1:b]).split(' := by', 1)[0]
    assert header == c['header']
assert '∃ suspended (after' not in source and '∃ output (after' not in source
assert 'local notation "Heap" => InternedConstructorTemplates.State' in source
assert 'SourceSizedPrefixOrdinarySlotCreation' not in source
result = {'status': 'PASS source bytes, exact cuts, contracts and metadata only; no Lean check', 'current_draft': current.name, 'current_draft_lines': 98, 'current_draft_bytes': current.stat().st_size, 'current_draft_sha256': sha(current.read_bytes()), 'draft_status': 'SOURCE-ONLY UNCOMPILED', 'public_contracts': 2, 'source_acquisition_records': len(ledger), 'old_original_paths': len(rows), 'old_original_line_union': sum(x['union_line_count'] for x in rows), 'old_named_wholes_used': 1, 'optional69L_acquired_or_imported': False, 'compiler_evaluator_native_haskell_commands': 0, 'git_network_board_commands': 0, 'production_edits': 0, 'spawned_agents': 0, 'external_private_helpers': []}
for name, value in [('metadata/old-source-unions.json', rows), ('metadata/verification.json', result)]:
    data = (json.dumps(value, indent=2) + '\n').encode()
    p = ROOT / name
    if p.exists():
        assert p.read_bytes() == data
    else:
        p.write_bytes(data)
print(json.dumps(result))
