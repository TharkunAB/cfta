# Draft contracts

SOURCE-ONLY and UNCOMPILED. No actual public readback exists.

```lean
import MicroCFTA.SourceSizedPrefixKnownOrdinary
import MicroCFTA.SourcePruningEnumerationCachedChild
import MicroCFTA.SourcePruningEnumerationEdgeInputs

-- UNCOMPILED SOURCE-ONLY DRAFT. Root must run the Lean checks.
namespace MicroCFTA.SourceSizedPrefixOrdinaryChildCreation
open EnumerationState EnumerationCorrectness EnumerationSchedule
open InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes SourcePruningEnumerationObservation
open SourceSizedPrefixKnownOrdinary
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Heap" => InternedConstructorTemplates.State Symbol Constraint
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
```

```lean
theorem selected_input_grade
    (heightBound : Nat) (heap : Heap) (before : Cached)
    (known : KnownOrdinary heightBound heap before)
    (parentHandle : Nat) (parentScs : List Suspended)
    (stored : UVarValue.unenumerated (some parentHandle) parentScs ∈ before.core.values)
    (entry : Cache.Interned InternedBinderProtocol.NodeKey)
    (edges : List (EdgeValue Symbol Constraint)) (depth : Nat) (free : List InternedBinderProtocol.Reference)
    (decoded : lookupNode heap parentHandle = some (.node entry edges depth free))
    (edge : EdgeValue Symbol Constraint)
    (selected : edge ∈ InternedEdgeResidency.nodeEdges (.node entry edges depth free))
    (scs : List Suspended) (tries : List EqualityTrie.Trie)
    (incoming : Value Symbol Constraint) (bucket : List Suspended)
    (input : (incoming, bucket) ∈
      SourcePruningEnumerationEdgeInputs.children edge scs before.core.counter tries) :
    SourceCurrentAllocatedFiniteOrdinaryDomain.Node incoming ∧
      MergedOrdinaryHeight.height incoming < MergedOrdinaryHeight.height (.node entry edges depth free) ∧
      MergedOrdinaryHeight.height incoming ≤ heightBound
```

```lean
theorem prepareOrdinary_known
    (heightBound : Nat) (heap : Heap) (before : Cached)
    (entry : Cache.Interned InternedBinderProtocol.NodeKey)
    (edges : List (EdgeValue Symbol Constraint)) (depth : Nat) (free : List InternedBinderProtocol.Reference)
    (scs : List Suspended) (roots : Nat → Nat)
    (coherent : InternedRecordCoherence.Coherent heap)
    (available : Available heap (.node entry edges depth free)) (closed : free = [])
    (storage : StorageValid before.core) (realized : PendingRealized heap before.core)
    (paths : Roots before.core.representatives roots)
    (counts : EnumerationCanonicalWaiting.Correct roots before.core.values before.waiting)
    (flags : ∀ slot, SourcePruningEnumerationNativeIndex.candidate heap
      ((before.core.values[slot]?).getD .eliminated) = some (before.expandable slot))
    (bounded : ∀ sc ∈ scs, sc.var < before.core.counter)
    (nonterminal : scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = false)
    (known : KnownOrdinary heightBound heap before)
    (ordinary : SourceCurrentAllocatedFiniteOrdinaryDomain.Node (.node entry edges depth free))
    (height : MergedOrdinaryHeight.height (.node entry edges depth free) ≤ heightBound) :
    ∃ (handle : Nat) (after : Cached) (fuel : Nat),
      encodeNode (.node entry edges depth free) = some handle ∧
      lookupNode heap handle = some (.node entry edges depth free) ∧
      (∀ extra, SourcePruningEnumerationCachedChild.prepareOrdinary heap (fuel + extra) scs
        (.node entry edges depth free) before = some (.hole before.core.counter, after)) ∧
      after.core.values[before.core.counter]? = some (.unenumerated (some handle) scs) ∧
      after.core.counter = before.core.counter + 1 ∧
      KnownOrdinary heightBound heap after
```
