# Current full-constraint public contract

Status: UNCOMPILED source-only candidate. The namespace is `MicroCFTA.SourceSizedConstraintEqualSizes`. The declarations use the original modules and full current constraint type.

```lean
noncomputable def view (constraint : SourceSymbolicIndex.Constraint Formula) : EqualityView :=
  (SourceCompactGuards.sourceEqualities constraint).map (List.map (List.map (List.map Int.ofNat)))

/-- Filter with the current full constraint, including its positive guard equalities. -/
noncomputable def equalSizes {Size : Type} [DecidableEq Size]
    (constraint : SourceSymbolicIndex.Constraint Formula) (parts : List Size) : Bool :=
  SourceSizedPrefixEqualSizes.equalSizes (view constraint) parts

/-- Exact Int embedding preserves the produced full-constraint numeric filter. -/
theorem equalSizes_cast (constraint : SourceSymbolicIndex.Constraint Formula) (parts : List Nat) :
    equalSizes constraint (parts.map Int.ofNat) = equalSizes constraint parts :=
  SourceSizedPrefixEqualSizes.equalSizes_cast (view constraint) parts

theorem accepted_equal_sizes [DecidableEq Formula]
    (formulas : SourceGuards.Formulas Formula) (solver : SourceGuards.Entailment Formula)
    (constraint : SourceSymbolicIndex.Constraint Formula)
    (cached : SourceEqualityGuardReadback.Cached constraint.equalities)
    (symbol : SourceObservations.Label Formula)
    (children : List (Term (SourceObservations.Label Formula)))
    (accepted : SourceSymbolicIndex.acceptsConstraint formulas solver constraint (.node symbol children) = true) :
    equalSizes constraint (children.map nodeSize) = true
```

The cache premise concerns the stored payload. No supplied equality view, positive-guard restriction, or path-sign premise is added. The signed Haskell adapter remains open.
