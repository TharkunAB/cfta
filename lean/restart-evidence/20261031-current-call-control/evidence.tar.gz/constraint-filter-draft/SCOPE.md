# Scope

Source-only current Nat-path full-constraint numeric view and filter.
Named OLD wholes before acquisition:
1. current SourceSizedPrefixEqualSizes.lean117;
2. current SourceEqualityGuardReadback.lean105.
Every other old source uses a named bounded cut at its original path.
Root owns compiler/evaluator/native/Haskell/Git/network/board/production.
No spawning is permitted.
No supplied view or positive/nonnegative-path gate is added.
The all-signed Haskell adapter remains open.
