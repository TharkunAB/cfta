# Current full-constraint numeric size filter

Status: SOURCE-ONLY. The 127-line V2 is UNCOMPILED. No Lean compiler, evaluator, Haskell execution, native execution, Git, network, message board, production edit, or child delegation was used.

## Result

The candidate defines a numeric view directly from `SourceCompactGuards.sourceEqualities constraint`. It maps each current natural path index to Int. It then applies the existing signed numeric filter to that view. The caller supplies the full current constraint. The caller does not supply an equality view.

The cast theorem preserves the exact Boolean result when Nat child sizes are embedded in Int. It needs no cache premise.

The semantic theorem states this implication: if the stored payload satisfies the existing `SourceEqualityGuardReadback.Cached` predicate, and the complete constraint accepts an actual node, the produced numeric filter accepts that node's child-size vector. The theorem has no positive-guard, nonnegative-path, future-run, or supplied-view premise. The existing `Cached` gate concerns the stored payload. The proof derives its existing `ActiveOption` gate with `SourceEqualityGuardReadback.active`.

The candidate does not match on a reduced guard syntax. It calls the actual complete accessor. It therefore retains the current accessor's own behavior on every guard constructor. In particular, unsupported extraction and an empty extracted payload retain the stored payload. Other extracted payloads use the existing combination. This does not claim that the accessor extracts every Same atom below arbitrary unsupported syntax.

## Proof structure

1. `accepted_equalities` derives the actual full accessor's Boolean class payload from complete constraint acceptance.
2. Its `classTest` is the existing `Symbolic.ClassSatisfied` predicate. A nonempty accepted class has one common term at all its member paths.
3. `direct_member` recovers an original singleton natural path from each selected numeric child index. It preserves the actual selection. It does not assume a public path-sign property.
4. `singleton_size` reads that actual child and derives its node size from the literal `Term.atPath` equation. The nonnegative cast fact is internal.
5. `read_common`, `numeric_common`, and `class_filter` derive the existing filter's Boolean result from those lookups.
6. The public theorem composes these facts for the actual accessor result.

The numeric contradiction branch still returns True. This is a prefilter result. It is not a satisfiability result. Root/deep paths are ignored by the existing direct-child projection. An empty selected class passes. Selected out-of-range indexes retain the existing rejection branch.

## Public interface

The intended installed module is `MicroCFTA.SourceSizedConstraintEqualSizes`. It exports `view`, `equalSizes`, `equalSizes_cast`, and `accepted_equal_sizes`. `PUBLIC-CONTRACT.md` retains the literal definitions and theorem statements. V2 is the proposed source. Its imports include the two named old modules and the standard head/drop theorem module.

The function has the existing filter shape when specialized to Nat child sizes. A later startup specialization can select this function for full current constraints. That application is not added in this bounded task.

## Scope and remaining gaps

This is the CURRENT natural-path source model. It is not the full original signed Haskell adapter. The signed ChildIndex representation, signed normalization, class Set representation and ordering, guard extraction correspondence, and literal Haskell Constraint.equalities correspondence remain open. No physical Set-order equivalence is claimed.

The candidate adds no worker execution result. It proves no sufficient original depth, global capacity, ordered public prefix, captured sibling restoration bound, source-reset bound, or literal SCC/allocation correspondence. The full original-input, both-worker, public, and Haskell objective remains open.

No Haskell defect or fix was established. There is no new FINDINGS item from this source-only task.

## Static review and retained attempts

V1 is retained. Static review identified an equality-direction concern in its class head case. It also identified redundant trailing `rfl` tactics after tactics that may close the goal. V2 replaces that head proof with an explicit rewrite and removes those trailing tactics. These are source-review observations. No elaboration failure was observed because no compiler was run.

The remaining risk is untested elaboration and strict-linter behavior. Root must check the exact frozen V2. No checked theorem claim is made here.

## Acquisition and provenance

The two OLD whole paths were named before acquisition: `SourceSizedPrefixEqualSizes.lean` (117 lines) and `SourceEqualityGuardReadback.lean` (105 lines). Both exact copies are retained. No third whole or near-whole module was acquired. All other code observations are retained named cuts or declaration locators. The cumulative ledger uses ORIGINAL absolute source paths. It counts reuse by that path.

`acquisitions.json` records each source hash, source line count, source byte count, acquired lines, and retained-copy hash. `cumulative-source-unions.json` records full unions. `SOURCE-AUDIT.json` checks these identities and the two-whole limit. The declaration search scanned additional source filenames with no matched lines. Those negative results are metadata records, not acquired module bodies.

The prior 65-file equality inventory remains available at `/tmp/mcfta-original-equality-filter-producer-review-20261031`. Its exact manifest and pins are copied as metadata. `provider-closure-check.json` verifies every payload in that manifest. No additional body from that provider was acquired under a reuse alias.

## Incidents

The first intended accessor cut used lines 476–481. Those six lines belong to a different proof. They remain retained under the original cut name. A named locator found the actual accessor at 488–491. The corrected cut is retained. All ten lines count in the cumulative union.

One batched locator output was truncated by the tool/context boundary. Exact locator queries were replayed into retained files. All resulting matched lines and negative results are in the acquisition ledger.

A console-only summary keyed files by basename. It collapsed the display of the two distinct standard-library TakeDrop paths. The canonical cumulative ledger always uses full paths and does not have that collision.
