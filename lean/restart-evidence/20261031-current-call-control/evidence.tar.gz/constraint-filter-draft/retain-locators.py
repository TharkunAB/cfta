from pathlib import Path
import hashlib,json,re
r=Path(__file__).parent;a=json.loads((r/'acquisitions.json').read_text())
repo=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA');std=Path('/home/tritlo/.elan/toolchains/leanprover--lean4---v4.34.1/src/lean/Init/Data/List')
queries=[
 ('class-predicate-locators',[repo/'EqualityNormalize.lean',repo/'Symbolic.lean'],r'^(def|abbrev) (Satisfies|ClassSatisfied)'),
 ('class-test-negative-locators',[repo/'SymbolicDriver.lean',repo/'ConstraintIndicators.lean'],r'classTest|^def equalityValue'),
 ('class-test-definition-locators',sorted(repo.glob('Symbolic*.lean')),r'def classTest|abbrev classTest|theorem classTest'),
 ('head-drop-generic-locators',[std/'TakeDrop.lean',std/'Lemmas.lean'],r'head\?.*drop|drop.*head\?'),
 ('drop-element-generic-locators',[std/'TakeDrop.lean',std/'Lemmas.lean'],r'getElem\?_drop|drop.*getElem\?|head\?_eq_getElem\?'),
 ('head-drop-natural-locators',[std/'Nat/TakeDrop.lean'],r'head\?_drop|getElem\?_drop'),
 ('source-accessor-locator',[repo/'SourceCompactGuards.lean'],r'^noncomputable def sourceEqualities')]
for label,paths,pattern in queries:
 for p in paths:
  data=p.read_bytes();lines=data.decode().splitlines(keepends=True);selected=[i for i,line in enumerate(lines,1)if re.search(pattern,line)];copy=r/'locators'/(label+'-'+p.parent.name+'-'+p.name+'.txt');copy.write_text(''.join(f'{i}:{lines[i-1]}'for i in selected));a.append({'kind':'retained exact locator replay','original_path':str(p),'source_sha256':hashlib.sha256(data).hexdigest(),'source_bytes':len(data),'source_lines':len(lines),'patterns':[pattern],'actual_lines':selected,'copy':str(copy.relative_to(r)),'copy_sha256':hashlib.sha256(copy.read_bytes()).hexdigest()})
(r/'acquisitions.json').write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({'locator_queries':len(queries),'total_acquisition_records':len(a)},indent=2))
