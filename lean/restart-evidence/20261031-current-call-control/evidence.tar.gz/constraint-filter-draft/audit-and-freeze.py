from pathlib import Path
import hashlib,json,os
r=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((r/'acquisitions.json').read_text());errors=[];unions={}
for x in a:
 p=Path(x['original_path']);copy=r/x['copy']
 if sha(p)!=x['source_sha256']:errors.append({'kind':'original source changed','path':str(p)})
 if sha(copy)!=x['copy_sha256']:errors.append({'kind':'retained copy changed','path':str(copy)})
 u=unions.setdefault(str(p),{'source_sha256':x['source_sha256'],'source_lines':x['source_lines'],'lines':set()})
 u['lines'].update(x.get('actual_lines',[]))
 for low,high in x.get('line_ranges',[]):u['lines'].update(range(low,high+1))
for u in unions.values():u['lines']=sorted(u['lines']);u['line_count']=len(u['lines'])
(r/'cumulative-source-unions.json').write_text(json.dumps(unions,indent=2)+'\n')
provider=Path('/tmp/mcfta-original-equality-filter-producer-review-20261031')
expected={'MANIFEST.json':'6ab5bde861e14ecfb3c71e48033edfc0ced887954916dc012fd79d76c7e9cfa5','pins.json':'91082d457a8510e38596ddc2a7beed1713a38accdbdd7804b72b5c8ab6d8eb52'}
meta=r/'provider-metadata';meta.mkdir(exist_ok=True)
for name,want in expected.items():
 if sha(provider/name)!=want:errors.append({'kind':'provider identity mismatch','path':str(provider/name)})
for name in ['MANIFEST.json','pins.json','FROZEN']:(meta/name).write_bytes((provider/name).read_bytes())
provider_files=json.loads((provider/'MANIFEST.json').read_text())['files'];verified=[]
for entry in provider_files:
 p=provider/entry['path'];ok=p.is_file()and sha(p)==entry['sha256']and p.stat().st_size==entry['bytes'];verified.append({'path':str(p),'sha256':entry['sha256'],'bytes':entry['bytes'],'verified':ok})
 if not ok:errors.append({'kind':'provider payload mismatch','path':str(p)})
(r/'provider-closure-check.json').write_text(json.dumps({'provider':str(provider),'manifest_sha256':sha(provider/'MANIFEST.json'),'pins_sha256':sha(provider/'pins.json'),'full_payloads_verified':verified,'semantic_source_reuse':'No additional provider source body was acquired. The original read-only provider remains available.'},indent=2)+'\n')
whole=[p for p,u in unions.items()if u['line_count']==u['source_lines']and u['line_count']]
expected_whole=['/home/tritlo/Code/mcfta/lean/MicroCFTA/SourceSizedPrefixEqualSizes.lean','/home/tritlo/Code/mcfta/lean/MicroCFTA/SourceEqualityGuardReadback.lean']
if sorted(whole)!=sorted(expected_whole):errors.append({'kind':'whole acquisition budget mismatch','actual':whole})
audit={'status':'source/provenance audit only; no compiler/evaluator execution','whole_old_sources':whole,'old_whole_limit':2,'acquisition_records':len(a),'provider_payloads_verified':len(verified),'errors':errors}
(r/'SOURCE-AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
if errors:raise SystemExit(json.dumps(errors))
excluded={'MANIFEST.json','pins.json','FROZEN'}
files=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(r.rglob('*'))if p.is_file()and str(p.relative_to(r))not in excluded]
(r/'MANIFEST.json').write_text(json.dumps({'kind':'complete immutable owner source-only evidence','status':'UNCOMPILED; Root alone checks','files':files},indent=2)+'\n')
candidate=r/'SourceSizedConstraintEqualSizes-v2-UNCOMPILED.lean'
pins={'owner':str(r),'status':'UNCOMPILED SOURCE-ONLY','candidate':candidate.name,'candidate_lines':len(candidate.read_text().splitlines()),'candidate_sha256':sha(candidate),'manifest_sha256':sha(r/'MANIFEST.json'),'report_sha256':sha(r/'REPORT.md'),'public_contract_sha256':sha(r/'PUBLIC-CONTRACT.md'),'whole_old_sources':{p:unions[p]['source_sha256']for p in whole},'previous_provider':str(provider),'previous_provider_manifest_sha256':sha(provider/'MANIFEST.json')}
(r/'pins.json').write_text(json.dumps(pins,indent=2)+'\n');(r/'FROZEN').write_text('Source-only owner bundle. All draft versions and acquired materials are retained. No compiler or evaluator was run.\n')
for entry in files:
 p=r/entry['path']
 if sha(p)!=entry['sha256']or p.stat().st_size!=entry['bytes']:raise SystemExit('post-manifest mismatch '+str(p))
result={'files':len(list(r.rglob('*'))),'payload_files':len(files),'candidate_sha256':sha(candidate),'manifest_sha256':sha(r/'MANIFEST.json'),'pins_sha256':sha(r/'pins.json'),'report_sha256':sha(r/'REPORT.md'),'public_contract_sha256':sha(r/'PUBLIC-CONTRACT.md'),'provider_payloads_verified':len(verified),'status':'UNCOMPILED FROZEN'}
for p in r.rglob('*'):
 if p.is_file():p.chmod(0o444)
for p in sorted([p for p in r.rglob('*')if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
r.chmod(0o555)
print(json.dumps(result,indent=2))
