The public theorem is `MicroCFTA.SourceCurrentAllocatedNativeCachedFoldKnown.fold_known`.

Its exact public header and conclusion are in the retained 139-line candidate.
It takes the existing CURRENT source-list fold resource admission and current whole-cache KnownOrdinary.
It computes the actual cached fold.
Every actual `some after` cache has whole KnownOrdinary at the actual returned caller heap and the SAME bound.

The proof derives each next admission through literal dispatch and singleton observations inside a source-list induction.
It takes no public future per-step property, result, Post, range, trace, or callback witness.
Raw fallback rows with cache `none` remain outside this claim.
No global depth or productivity result follows.

Status: UNCOMPILED source-only future candidate. Root owns kernel checks and installation. This is outside the five-module R18 checkpoint.
