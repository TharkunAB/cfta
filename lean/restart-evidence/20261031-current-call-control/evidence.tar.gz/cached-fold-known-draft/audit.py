from pathlib import Path
import hashlib
import json

owner = Path('/tmp/mcfta-native-fold-known-review-20261031')
ledger_text = (owner / 'acquisitions.json').read_text()
entries = json.loads(ledger_text)
unions = {}
for row in entries:
    original = Path(row['original_path'])
    raw = original.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row['source_sha256'], original
    lines = raw.decode().splitlines(keepends=True)
    assert len(lines) == row['source_lines'], original
    retained = owner / row['copy']
    retained_bytes = retained.read_bytes()
    assert hashlib.sha256(retained_bytes).hexdigest() == row['copy_sha256'], retained
    whole = row['kind'] == 'named whole original'
    expected = raw if whole else ''.join(f'{i}:{lines[i-1]}' for i in row['actual_lines']).encode()
    assert retained_bytes == expected, retained
    union = unions.setdefault(str(original), {
        'source_sha256': row['source_sha256'],
        'source_bytes': row['source_bytes'],
        'source_lines': len(lines),
        'whole': False,
        'actual_lines': set(),
        'retained_copies': [],
    })
    assert union['source_sha256'] == row['source_sha256']
    union['actual_lines'].update(row['actual_lines'])
    union['whole'] |= whole
    union['retained_copies'].append(row['copy'])

for union in unions.values():
    union['actual_lines'] = sorted(union['actual_lines'])
    union['union_count'] = len(union['actual_lines'])
    union['union_fraction'] = union['union_count'] / union['source_lines']
assert sum(row['whole'] for row in unions.values()) == 2
result = {'acquisitions': len(entries), 'original_paths': len(unions), 'sources': unions}
(owner / 'cumulative-original-unions.json').write_text(json.dumps(result, indent=2) + '\n')
print('Source/cut/hash audit PASS:', len(entries), 'acquisitions;', len(unions), 'original paths; exactly two OLD wholes.')
other = [(row['union_fraction'], path, row['union_count'], row['source_lines'])
         for path, row in unions.items() if not row['whole']]
for fraction, path, count, total in sorted(other, reverse=True)[:4]:
    print(count, '/', total, f'{fraction:.3f}', path)
