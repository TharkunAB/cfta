from acquire import acquire

acquire('SourceSizedPrefixKnownOrdinary.lean', 'cuts/current-known-definition',
        'named bounded current predicate definition', 21, 25)
acquire('EnumerationExpandableIndex.lean', 'locators/cache-frame-declaration',
        'named cache projection declaration locator', pattern=r'^def frame|^structure Cached')
