from acquire import acquire

pattern = r'^import |^namespace |^(private )?(theorem|lemma|def|noncomputable def|abbrev) '
for name in [
    'SourcePruningEnumerationFoldAdmission.lean',
    'SourceCurrentAllocatedNativeStoredFold.lean',
    'SourceCurrentAllocatedNativeResourceForecast.lean',
    'SourceCurrentAllocatedNativeStoredDispatch.lean',
    'SourceCurrentAllocatedNativeDispatchKnown.lean',
]:
    acquire(name, 'locators/' + name, 'named declaration locators', pattern=pattern)

for name, first, last, label in [
    ('SourcePruningEnumerationFoldAdmission.lean', 32, 60, 'actual-singleton-current-next-gates'),
    ('SourceCurrentAllocatedNativeStoredFold.lean', 28, 45, 'existing-native-fold-header-and-base'),
    ('SourceCurrentAllocatedNativeDispatchKnown.lean', 53, 78, 'checked-dispatch-known-header'),
]:
    acquire(name, 'cuts/' + label, 'named bounded actual-admission/header cut', first, last)
