from pathlib import Path
import hashlib
import json

owner = Path(__file__).resolve().parent
manifest_raw = (owner / 'MANIFEST.json').read_bytes()
pins_text = (owner / 'pins.json').read_text()
pins = json.loads(pins_text)
assert hashlib.sha256(manifest_raw).hexdigest() == pins['manifest_sha256']
manifest = json.loads(manifest_raw)
for row in manifest['files']:
    path = owner / row['path']
    data = path.read_bytes()
    assert len(data) == row['bytes'], path
    assert hashlib.sha256(data).hexdigest() == row['sha256'], path
    assert path.stat().st_mode & 0o222 == 0, path
candidate = owner / pins['candidate']
assert len(candidate.read_text().splitlines()) == pins['candidate_lines']
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == pins['candidate_sha256']
assert len(manifest['files']) == pins['payload_files']
assert owner.stat().st_mode & 0o222 == 0
print('Frozen payload replay PASS:', pins['payload_files'], 'payloads;', pins['total_files'], 'total files.')
print('Candidate remains UNCOMPILED:', pins['candidate_sha256'])
