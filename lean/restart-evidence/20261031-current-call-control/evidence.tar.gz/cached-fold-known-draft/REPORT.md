# Actual cached-fold ordinary-cache transport

The final candidate is `SourceCurrentAllocatedNativeCachedFoldKnown-v1-UNCOMPILED.lean`.
It has 139 lines. SHA256 is `d1f5ea12266cbdc61ee886271c88d9c41af3c6b918702362f43d643dcfcbff52`.
It is UNCOMPILED. Root owns kernel checks and production work.
No compiler, evaluator, native worker, Haskell program, Git command, network request, board tool, or child agent was used.

## Exact result

`fold_known` computes the literal `SourcePruningEnumerationCachedFold.run` at arbitrary supplied native, prefix, and height fuels.
Whenever its actual cache component is `some after`, the entire `after` cache has `KnownOrdinary bound` at the literal returned caller heap.
The bound is the SAME input bound.
The result covers an actual retained cache after an empty raw result, as well as the final cache after successful singleton recursion.
It does not assert that any chosen fuels produce a cache.

The public inputs are the existing current fold admission:

- Current Seed, Context, PendingRealized, pending target, and selected pending-or-eliminated sources.
- Current Fits, original `Reserved bits seed sources.length`, and annotation Heap.
- Current native Stored and whole-cache KnownOrdinary.

There is no public per-step Known, range, receipt, lookup, target result, Post, next Context, callback, trace, history, or future result supplier.
The actual source-list induction is internal.
The theorem uses the actual current memo record and its `memos.query`.

## Literal branch argument

The empty source list returns the original cache and caller.

For a nonempty source list, the original reservation supplies Room for the current step and a reservation for the tail.
The actual selected source is pending or eliminated.
The target is pending.
Their current read equations derive the exact slots disjunction required by `dispatch_known`.
No separate source-domain, source-cap, or lookup witness is supplied.

An outer dispatch error or missing action returns cache `none`.
For an actual returned action, `dispatch_known` derives both old-cache Known at the reached heap and whole Known for each actual successful raw Core.

The adapter/fold branches then have these exact meanings:

| Actual branch | Cache result | Proof used |
| --- | --- | --- |
| Raw `[]` | `some before` at the reached caller | Dispatch old-cache Known |
| Raw row error | `none` | No returned-cache assertion |
| More than one raw row | `none` | No returned-cache assertion |
| Singleton success, adapter `none` | Raw fallback, final cache `none` | No returned-cache assertion |
| Singleton success, adapter `some recovered` | Recurse with `frame core recovered` | Actual Core Known and internal list IH |

The literal `frame` sets its cache Core to the actual singleton Core.
KnownOrdinary depends only on that Core's values and the current heap.
Thus the actual raw-Core property supplies the complete next cache property without a future Frame or cache certificate.

In the recursive branch, `SourcePruningEnumerationFold.observed_singleton` consumes the actual dispatch and raw singleton equations.
It derives the actual Post, next Context through `post.context`, PendingRealized, pending target, selected remaining sources, Fits, and annotation Heap.
`dispatch_native_stored` derives native Stored at the same reached caller.
`Reserved.tail` supplies the remaining reservation.
The IH receives only those internally derived facts.
The actual Post's memo equality rewrites the next `final.query` to the literal saved query memo used by the runtime recursion.

## Static review and boundaries

The two actual whole runtime modules were read before drafting.
The proof case structure follows their literal recursion and adapter branches.
The current dispatch producer header was retained from production source162, SHA256 `6b68803de715a87927777e705f8d01bbb32e475333143522326c89ed2257066c`.
Root was finishing its verification at task assignment.
This owner made no independent kernel-check claim for that dependency.

No logical obstruction was found in this bounded review.
The candidate can still need proof-only elaboration or linter repairs.
The main untested details are reduction of the actual result tag, the structural IH argument order, and simplification of the saved memo equality.
There is one retained version. No proof failed under a compiler because none was run.

The result deliberately leaves raw fallback Core rows outside the claim.
That branch executes the original raw fold and returns no cache.
It can still return raw Core data for later generic fallback work.
This theorem does not certify those Core rows or close that generic route.

The result does not prove the complete terminal adapter, caller restoration, Prepared fallback, opaque/Mu/Union reconstruction, original resource sufficiency, global depth, worker productivity, ordered-prefix completion, accepted-term production, or public/Haskell correspondence.
The source list has a structural induction here. This does not bound the number of source lists or recursive resumes in the whole worker.
KnownOrdinary remains a physical ordinary-value/height assertion. It is not a Normal, language, satisfiability, or accepted-output assertion.
No Haskell defect or fix was established. No FINDINGS entry is proposed.

## Provenance

The two OLD whole paths were named to Root before acquisition:

- `lean/MicroCFTA/SourcePruningEnumerationCachedFold.lean`, 120 lines, SHA256 `f39f3597b5864c7e586aacb651fa620b201daa692d72a6d8f8b51b5483256420`.
- `lean/MicroCFTA/SourcePruningEnumerationCachedAdapter.lean`, 171 lines, SHA256 `251246fe2b2f9f903a865ff5a3fd34c91c9e108a9fee860627c675f69d24a9fc`.

Every other source read is a named bounded cut or declaration locator.
`acquisitions.json` retains the full original source hash, byte and line counts, actual selected lines, and retained-copy hash.
`cumulative-original-unions.json` merges all selections at ORIGINAL paths.
The small scripts retain every acquisition request and its ranges.
No previous private proof source or sealed owner bundle was reused or changed.
All dependencies here use the current production source vectors and retained literal cuts.
