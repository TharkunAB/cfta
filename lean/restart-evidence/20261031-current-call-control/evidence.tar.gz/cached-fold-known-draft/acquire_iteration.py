from acquire import acquire

for name, first, last, label in [
    ('SourceCurrentAllocatedPartialInvariant.lean', 38, 47, 'post-supplies-next-context'),
    ('SourcePruningEnumerationIncomingReservation.lean', 90, 100, 'actual-reserved-head-tail'),
    ('EnumerationCompleteness.lean', 18, 24, 'current-pending-slot-definitions'),
]:
    acquire(name, 'cuts/' + label, 'named bounded internal-IH admission cut', first, last)
