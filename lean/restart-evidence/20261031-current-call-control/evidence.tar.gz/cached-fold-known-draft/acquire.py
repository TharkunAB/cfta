from pathlib import Path
import hashlib
import json

OWNER = Path('/tmp/mcfta-native-fold-known-review-20261031')
SOURCE_ROOT = Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
LEDGER = OWNER / 'acquisitions.json'


def acquire(name, label, kind, first=None, last=None, pattern=None):
    import re
    source = SOURCE_ROOT / name
    data = source.read_bytes()
    lines = data.decode().splitlines(keepends=True)
    if kind == 'named whole original':
        selected = list(range(1, len(lines) + 1))
        retained = data
    elif pattern is not None:
        selected = [i for i, line in enumerate(lines, 1) if re.search(pattern, line)]
        retained = ''.join(f'{i}:{lines[i-1]}' for i in selected).encode()
    else:
        selected = list(range(first, last + 1))
        retained = ''.join(f'{i}:{lines[i-1]}' for i in selected).encode()
    target = OWNER / label
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(retained)
    entries = json.loads(LEDGER.read_text()) if LEDGER.exists() else []
    entry = {
        'kind': kind,
        'original_path': str(source),
        'source_sha256': hashlib.sha256(data).hexdigest(),
        'source_bytes': len(data),
        'source_lines': len(lines),
        'actual_lines': selected,
        'copy': label,
        'copy_sha256': hashlib.sha256(retained).hexdigest(),
    }
    if pattern is not None:
        entry['pattern'] = pattern
    entries.append(entry)
    LEDGER.write_text(json.dumps(entries, indent=2) + '\n')
    print(name, len(lines), 'lines', entry['source_sha256'])
    print(target.read_text())


if __name__ == '__main__':
    acquire('SourcePruningEnumerationCachedFold.lean', 'reused/SourcePruningEnumerationCachedFold.lean', 'named whole original')
    acquire('SourcePruningEnumerationCachedAdapter.lean', 'reused/SourcePruningEnumerationCachedAdapter.lean', 'named whole original')
