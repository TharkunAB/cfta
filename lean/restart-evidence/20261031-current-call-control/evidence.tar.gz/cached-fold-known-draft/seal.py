from datetime import datetime
from pathlib import Path
import hashlib
import json
import os

owner = Path('/tmp/mcfta-native-fold-known-review-20261031')
vectors_text = (owner / 'cumulative-original-unions.json').read_text()
vectors = json.loads(vectors_text)
now = datetime.now().astimezone().strftime('%Y-%m-%d %H:%M %Z')
excluded = {'MANIFEST.json', 'pins.json', 'FROZEN'}
payload = []
for path in sorted(owner.rglob('*')):
    if not path.is_file():
        continue
    relative = str(path.relative_to(owner))
    if relative in excluded:
        continue
    raw = path.read_bytes()
    payload.append({
        'path': relative,
        'bytes': len(raw),
        'sha256': hashlib.sha256(raw).hexdigest(),
    })
manifest = {
    'status': 'FROZEN SOURCE-ONLY; 139-line candidate UNCOMPILED',
    'frozen_at': now,
    'payload_files': len(payload),
    'payload_bytes': sum(row['bytes'] for row in payload),
    'acquisitions': vectors['acquisitions'],
    'original_paths': vectors['original_paths'],
    'old_whole_originals': [path for path, row in vectors['sources'].items() if row['whole']],
    'private_proof_provider_reuse': 'None; current production source vectors only.',
    'files': payload,
}
(owner / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
candidate = owner / 'SourceCurrentAllocatedNativeCachedFoldKnown-v1-UNCOMPILED.lean'
assert len(candidate.read_text().splitlines()) == 139
pins = {
    'frozen_at': now,
    'status': 'UNCOMPILED future candidate outside the five-module R18 checkpoint',
    'manifest_sha256': hashlib.sha256((owner / 'MANIFEST.json').read_bytes()).hexdigest(),
    'candidate': candidate.name,
    'candidate_lines': 139,
    'candidate_sha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
    'report_sha256': hashlib.sha256((owner / 'REPORT.md').read_bytes()).hexdigest(),
    'source_vectors_sha256': hashlib.sha256((owner / 'cumulative-original-unions.json').read_bytes()).hexdigest(),
    'payload_files': len(payload),
    'total_files': len(payload) + 3,
}
(owner / 'pins.json').write_text(json.dumps(pins, indent=2) + '\n')
(owner / 'FROZEN').write_text('Frozen source-only. Candidate remains UNCOMPILED. ' + now + '\n')
for path in owner.rglob('*'):
    if path.is_file():
        os.chmod(path, 0o444)
for path in sorted(owner.rglob('*'), reverse=True):
    if path.is_dir():
        os.chmod(path, 0o555)
os.chmod(owner, 0o555)
print(json.dumps(pins, indent=2))
print('pins.json SHA256', hashlib.sha256((owner / 'pins.json').read_bytes()).hexdigest())
