from acquire import acquire

for name, first, last, label in [
    ('SourceCurrentAllocatedNativeStoredFold.lean', 11, 25, 'existing-native-fold-namespace'),
    ('SourcePruningEnumerationFoldAdmission.lean', 60, 64, 'literal-current-slot-gate-construction'),
    ('SourceCurrentAllocatedNativeStoredDispatch.lean', 57, 71, 'actual-dispatch-native-stored-header'),
]:
    acquire(name, 'cuts/' + label, 'named bounded existing namespace/producer cut', first, last)

pattern = r'^import |^namespace |^(private )?(theorem|lemma|def|noncomputable def|abbrev|structure) '
for name in [
    'SourcePruningEnumerationIncomingReservation.lean',
    'SourceCurrentAllocatedPartialInvariant.lean',
    'EnumerationCompleteness.lean',
]:
    acquire(name, 'locators/' + name, 'named current reservation/context declaration locators', pattern=pattern)
