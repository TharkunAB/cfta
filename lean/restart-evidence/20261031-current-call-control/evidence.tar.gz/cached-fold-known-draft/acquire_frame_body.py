from acquire import acquire

acquire('EnumerationExpandableIndex.lean', 'cuts/literal-cache-frame-core',
        'named bounded literal frame projection', 47, 49)
