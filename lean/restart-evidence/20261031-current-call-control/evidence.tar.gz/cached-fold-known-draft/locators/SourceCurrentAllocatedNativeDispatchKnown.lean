1:import MicroCFTA.SourceSizedPrefixKnownOrdinaryHeap
2:import MicroCFTA.SourcePruningEnumerationDispatchResources
3:import MicroCFTA.SourcePruningEnumerationDispatchUnique
4:import MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryTargetResult
15:namespace MicroCFTA.SourceCurrentAllocatedNativeDispatchKnown
32:private theorem assimilated_known (bound : Nat) (heap : State Symbol Constraint)
55:theorem dispatch_known (bits bound : Nat) (profile : Profile)
