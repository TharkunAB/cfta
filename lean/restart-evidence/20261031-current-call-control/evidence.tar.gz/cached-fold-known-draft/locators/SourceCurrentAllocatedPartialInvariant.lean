1:import MicroCFTA.SourceCurrentAllocatedPartialMemoSound
2:import MicroCFTA.SourceCurrentConjunctionClassScan
3:import MicroCFTA.SourceCurrentAllocatedMuRebuild
4:import MicroCFTA.SourceCurrentAllocatedNativeInventoryState
5:import MicroCFTA.SourceCurrentMemoMergeLanguage
14:namespace MicroCFTA.SourceCurrentAllocatedPartialInvariant
25:structure Context (formulas : SourceGuards.Formulas FullSyntax.Formula)
38:structure Post (formulas : SourceGuards.Formulas FullSyntax.Formula)
50:theorem Context.rebase (context : Context formulas solver inventory before memos)
65:theorem Post.refl (context : Context formulas solver inventory before memos) :
72:theorem Post.trans (first : Post formulas solver inventory before middle memos)
78:theorem Post.rebase (context : Context formulas solver inventory before memos)
