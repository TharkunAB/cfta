1:import MicroCFTA.SourcePruningEnumerationDispatchResources
2:import MicroCFTA.SourcePruningEnumerationDispatchUnique
3:import MicroCFTA.SourcePruningEnumerationIncomingReservation
4:import MicroCFTA.SourcePruningEnumerationFold
13:namespace MicroCFTA.SourcePruningEnumerationFold
32:theorem observed_singleton (seed : Seed)
107:theorem initial_ranges (seed : Seed)
