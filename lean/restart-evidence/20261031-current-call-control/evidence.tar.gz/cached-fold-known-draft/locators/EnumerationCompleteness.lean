1:import MicroCFTA.EnumerationExecution
10:namespace MicroCFTA.EnumerationCompleteness
18:def PendingAt (state : State Symbol Guard) (uv : Nat) : Prop :=
22:def PendingOrEliminated (state : State Symbol Guard) (uv : Nat) : Prop :=
26:theorem stored_satisfies (language : NodeLanguage Symbol) (meaning : Guard → Term Symbol → Prop)
33:theorem satisfies_not_empty (graph : Graph Symbol Guard) (meaning : Guard → Term Symbol → Prop)
41:theorem assimilated_pending (state : State Symbol Guard) (target source : Nat) (node : Option Nat) (scs : List Suspended)
60:theorem assimilate_terminates (graph : Graph Symbol Guard) (meaning : Guard → Term Symbol → Prop)
99:theorem assimilations_terminate (graph : Graph Symbol Guard) (meaning : Guard → Term Symbol → Prop)
118:theorem inputs_pendingAt (state : State Symbol Guard) (safe : Safe state) (scs : List Suspended)
135:theorem mergeNode_terminates (graph : Graph Symbol Guard) (meaning : Guard → Term Symbol → Prop)
168:theorem mergeTerminal_terminates (graph : Graph Symbol Guard) (meaning : Guard → Term Symbol → Prop)
249:theorem enumerateNode_terminal_terminates (graph : Graph Symbol Guard) (meaning : Guard → Term Symbol → Prop)
