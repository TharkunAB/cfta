1:import MicroCFTA.SourcePruningEnumerationIncomingQueryResources
2:import MicroCFTA.SourceCurrentParentInitialRoom
12:namespace MicroCFTA.SourcePruningEnumerationIncomingReservation
17:abbrev Seed := List Constraint × Profile
20:noncomputable def step (seed : Seed) : Seed :=
25:noncomputable def advance (seed : Seed) : Nat → Seed
30:theorem advance_zero (seed : Seed) : advance seed 0 = seed := rfl
33:theorem advance_succ (seed : Seed) (count : Nat) :
37:theorem advance_add (seed : Seed) (first last : Nat) :
44:theorem step_profile_ge (seed : Seed) : Le seed.2 (step seed).2 :=
48:theorem step_alphabet_ge (seed : Seed) : seed.1 ⊆ (step seed).1 :=
52:theorem advance_profile_ge (seed : Seed) (count : Nat) : Le seed.2 (advance seed count).2 := by
58:theorem advance_alphabet_ge (seed : Seed) (count : Nat) : seed.1 ⊆ (advance seed count).1 := by
64:theorem advance_count_profile_mono (seed : Seed) {first last : Nat} (counts : first ≤ last) :
71:def Reserved (bits : Nat) (seed : Seed) (count : Nat) : Prop :=
75:theorem reserved_zero (bits : Nat) (seed : Seed) : Reserved bits seed 0 := by
80:theorem reserved_succ_iff (bits : Nat) (seed : Seed) (count : Nat) :
91:theorem Reserved.head {bits count : Nat} {seed : Seed}
96:theorem Reserved.tail {bits count : Nat} {seed : Seed}
101:theorem Reserved.prefix {bits first last : Nat} {seed : Seed}
106:theorem Reserved.after_prefix {bits consumed remaining : Nat} {seed : Seed}
114:theorem reserved_iff_last (bits : Nat) (seed : Seed) (count : Nat) :
123:theorem reserved_of_final_room (bits : Nat) (seed : Seed) (count : Nat)
128:theorem reserved_computed (seed : Seed) (count : Nat) :
