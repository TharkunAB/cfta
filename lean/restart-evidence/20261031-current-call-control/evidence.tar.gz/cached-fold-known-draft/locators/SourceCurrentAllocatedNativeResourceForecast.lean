1:import MicroCFTA.SourceCurrentAllocatedNativeComputedBudget
2:import MicroCFTA.SourceCurrentAllocatedRecursiveMassMonotone
11:namespace MicroCFTA.SourceCurrentAllocatedNativeResourceForecast
29:def Le (first last : Profile) : Prop :=
34:theorem Le.refl (profile : Profile) : Le profile profile :=
38:theorem Le.trans {first middle last : Profile} (one : Le first middle) (two : Le middle last) :
44:def step (profile : Profile) : Profile :=
51:theorem step_ge (profile : Profile) : Le profile (step profile) :=
56:theorem step_mono {first last : Profile} (increase : Le first last) : Le (step first) (step last) := by
66:def advance (profile : Profile) : Nat → Profile
71:theorem advance_zero (profile : Profile) : advance profile 0 = profile := rfl
74:theorem advance_succ (profile : Profile) (count : Nat) :
78:theorem advance_add (profile : Profile) (first last : Nat) :
85:theorem advance_ge (profile : Profile) (count : Nat) : Le profile (advance profile count) := by
91:theorem advance_mono {first last : Profile} (increase : Le first last) (count : Nat) :
98:theorem advance_count_mono (profile : Profile) {first last : Nat} (counts : first ≤ last) :
105:def Room (bits : Nat) (profile : Profile) : Prop :=
110:theorem Room.mono {bits : Nat} {first last : Profile} (room : Room bits last)
118:def Reserved (bits : Nat) (profile : Profile) (count : Nat) : Prop :=
122:theorem reserved_zero (bits : Nat) (profile : Profile) : Reserved bits profile 0 := by
127:theorem reserved_succ_iff (bits : Nat) (profile : Profile) (count : Nat) :
138:theorem Reserved.head {bits count : Nat} {profile : Profile}
143:theorem Reserved.tail {bits count : Nat} {profile : Profile}
148:theorem Reserved.mono {bits count : Nat} {first last : Profile}
153:theorem Reserved.prefix {bits first last : Nat} {profile : Profile}
158:theorem reserved_iff_last (bits : Nat) (profile : Profile) (count : Nat) :
