No failed acquisition, tool failure, source revision, or observed elaboration error occurred. Both proof modules remain uncompiled. The header transport check is source text comparison only.
