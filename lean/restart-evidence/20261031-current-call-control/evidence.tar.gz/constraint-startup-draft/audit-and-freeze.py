from pathlib import Path
import hashlib,json,re
r=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((r/'acquisitions.json').read_text());errors=[];unions={}
for x in a:
 p=Path(x['original_path']);copy=r/x['copy']
 if sha(p)!=x['source_sha256']:errors.append({'kind':'original changed','path':str(p)})
 if sha(copy)!=x['copy_sha256']:errors.append({'kind':'copy changed','path':str(copy)})
 u=unions.setdefault(str(p),{'source_sha256':x['source_sha256'],'source_lines':x['source_lines'],'lines':set()})
 for low,high in x.get('line_ranges',[]):u['lines'].update(range(low,high+1))
for u in unions.values():u['lines']=sorted(u['lines']);u['line_count']=len(u['lines'])
(r/'cumulative-source-unions.json').write_text(json.dumps(unions,indent=2)+'\n')
whole=[p for p,u in unions.items()if u['line_count']==u['source_lines']]
if len(whole)!=2:errors.append({'kind':'old whole count','actual':whole})
source=(r/'reused'/'SourceSizedPrefixComputedMinimum.lean').read_text();candidate=r/'SourceSizedPrefixCurrentConstraintStartup-v1-UNCOMPILED.lean';draft=candidate.read_text()
def header(text,name):
 start=text.index('theorem '+name)+len('theorem '+name);return text[start:text.index(':= by',start)]
old=header(source,'initial_packet_computed');new=header(draft,'initial_packet')
specialized=old.replace('(equalSizes : Guard → List Nat → Bool) ','')
specialized=re.sub(r'\bequalSizes\b','SourceSizedConstraintEqualSizes.equalSizes',specialized)
compact=lambda text:re.sub(r'\s+','',text)
transport={'status':'source text comparison only; no compiler/evaluator','base_theorem':'SourceSizedPrefixComputedMinimum.initial_packet_computed','candidate_theorem':'SourceSizedPrefixCurrentConstraintStartup.initial_packet','removed_binder':'(equalSizes : Guard → List Nat → Bool)','fixed_argument':'SourceSizedConstraintEqualSizes.equalSizes','headers_equal_modulo_whitespace':compact(specialized)==compact(new)}
(r/'HEADER-TRANSPORT.json').write_text(json.dumps(transport,indent=2)+'\n')
if not transport['headers_equal_modulo_whitespace']:errors.append({'kind':'header specialization mismatch'})
(r/'PUBLIC-CONTRACT.md').write_text('# Current startup contract\n\nStatus: UNCOMPILED. The theorem is in `MicroCFTA.SourceSizedPrefixCurrentConstraintStartup`.\n\n```lean\ntheorem initial_packet'+new.rstrip()+'\n```\n\nThe existing local aliases and original typeclass instances remain unchanged. No free minimum table, equality view, or numeric filter occurs among the inputs.\n')
providers=[('/tmp/mcfta-current-constraint-equal-sizes-review-20261031','962cd385e97c397125f4a9e8664b30f0f6493531531ac0da017a00d2c6b18bd8','d65a1aa3651f02557f1b8bd42a9fb85702e300ea40da4eb8e63249fe6c199a53'),('/tmp/mcfta-original-equality-filter-producer-review-20261031','6ab5bde861e14ecfb3c71e48033edfc0ced887954916dc012fd79d76c7e9cfa5','91082d457a8510e38596ddc2a7beed1713a38accdbdd7804b72b5c8ab6d8eb52')]
closures=[]
for number,(path,manifest_sha,pins_sha)in enumerate(providers,1):
 provider=Path(path);meta=r/'provider-metadata'/str(number);meta.mkdir(parents=True,exist_ok=True)
 if sha(provider/'MANIFEST.json')!=manifest_sha or sha(provider/'pins.json')!=pins_sha:errors.append({'kind':'provider identity mismatch','path':path})
 for name in ['MANIFEST.json','pins.json','FROZEN']:(meta/name).write_bytes((provider/name).read_bytes())
 entries=json.loads((provider/'MANIFEST.json').read_text())['files'];checked=[]
 for entry in entries:
  p=provider/entry['path'];ok=p.is_file()and sha(p)==entry['sha256']and p.stat().st_size==entry['bytes'];checked.append({'path':str(p),'sha256':entry['sha256'],'bytes':entry['bytes'],'verified':ok})
  if not ok:errors.append({'kind':'provider payload mismatch','path':str(p)})
 closures.append({'provider':path,'manifest_sha256':manifest_sha,'pins_sha256':pins_sha,'payloads':checked})
(r/'provider-closure-check.json').write_text(json.dumps(closures,indent=2)+'\n')
(r/'SOURCE-AUDIT.json').write_text(json.dumps({'status':'source/provenance audit only','old_whole_paths':whole,'old_whole_limit':2,'no_other_old_bodies':len(a)==2,'errors':errors},indent=2)+'\n')
if errors:raise SystemExit(json.dumps(errors))
(r/'STATE.md').write_text('FROZEN SOURCE-ONLY. V1 is 55 lines and uncompiled. Its 127-line full-constraint filter dependency is also uncompiled. One literal startup specialization removes the free filter argument and preserves the computed minimum and all same-root admission/cap outputs. Root alone checks, repairs, installs, packages, and publishes. Signed/Set/Haskell and global worker goals remain open.\n')
(r/'INCIDENTS.md').write_text('No failed acquisition, tool failure, source revision, or observed elaboration error occurred. Both proof modules remain uncompiled. The header transport check is source text comparison only.\n')
excluded={'MANIFEST.json','pins.json','FROZEN'}
files=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(r.rglob('*'))if p.is_file()and str(p.relative_to(r))not in excluded]
(r/'MANIFEST.json').write_text(json.dumps({'kind':'complete source-only startup owner','status':'UNCOMPILED','files':files},indent=2)+'\n')
pins={'owner':str(r),'status':'UNCOMPILED','candidate':candidate.name,'candidate_lines':len(draft.splitlines()),'candidate_sha256':sha(candidate),'manifest_sha256':sha(r/'MANIFEST.json'),'report_sha256':sha(r/'REPORT.md'),'public_contract_sha256':sha(r/'PUBLIC-CONTRACT.md'),'old_whole_sources':{p:unions[p]['source_sha256']for p in whole}}
(r/'pins.json').write_text(json.dumps(pins,indent=2)+'\n');(r/'FROZEN').write_text('Source-only. No compiler/evaluator was run. Complete owner and provider provenance are retained.\n')
for entry in files:
 p=r/entry['path']
 if sha(p)!=entry['sha256']:raise SystemExit('post-manifest mismatch '+str(p))
result={'candidate_lines':len(draft.splitlines()),'candidate_sha256':sha(candidate),'manifest_sha256':sha(r/'MANIFEST.json'),'pins_sha256':sha(r/'pins.json'),'report_sha256':sha(r/'REPORT.md'),'public_contract_sha256':sha(r/'PUBLIC-CONTRACT.md'),'payload_files':len(files),'total_files':len(files)+3,'provider_payload_counts':[len(x['payloads'])for x in closures],'header_transport':transport['headers_equal_modulo_whitespace'],'status':'UNCOMPILED FROZEN'}
for p in r.rglob('*'):
 if p.is_file():p.chmod(0o444)
for p in sorted([p for p in r.rglob('*')if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
r.chmod(0o555)
print(json.dumps(result,indent=2))
