# Current full-constraint bounded startup

Status: SOURCE-ONLY. The 55-line V1 is UNCOMPILED. Its 127-line full-constraint filter dependency is also UNCOMPILED. No compiler, evaluator, Haskell/native execution, Git, network, message board, production edit, or delegation was used.

## Result

The proposed module is `MicroCFTA.SourceSizedPrefixCurrentConstraintStartup`. Its single theorem is `initial_packet`. It specializes `SourceSizedPrefixComputedMinimum.initial_packet_computed` to the actual `SourceSizedConstraintEqualSizes.equalSizes` function.

The caller supplies no minimum table, equality view, or numeric filter. The minimum table remains `minimumNat input`. That table comes from the actual empty-initialized signed minimum producer. The filter remains the full current constraint accessor followed by the existing numeric test. The theorem adds no definition, abstraction, premise, or guard restriction.

## Preserved inputs and outputs

All original inputs remain: the original input structure, formulas, solver, valid original cache, original row-cache gate, metadata with empty pending work, size bound, width, and original equality instances. The row-cache gate is the existing `Cached row.constraint.equalities` premise. No new positive-guard or nonnegative-path premise is added.

The conclusion retains the exact computed-table embedding equality. Its expression uses the original `input.rows`, computed `minimumNat input`, fixed full-constraint filter, original `input.root`, and original `bound`.

The same expression supplies the actual build equation and its exact `value`, `heap`, and `built` witnesses. The conclusion retains Facts, Available, free=[], the recursive ordinary Node domain, and height at most `bound.toNat + 1`. It retains the same guard preparation cache, annotation heap, encoded handle, heap lookup, and startup slot. It retains Packet, Fits with the same four-component cap, canonical startup, initial slot value, zero suspended bound, and KnownOrdinary on the actual caller heap.

`HEADER-TRANSPORT.json` compares the literal old public header to the new header after removal of the one free filter binder and substitution of the fixed function. It ignores whitespace only. This is a source comparison, not a proof check.

## Proof

The proof is one exact application of the existing computed-minimum startup theorem. It supplies the fixed full-constraint filter in the old filter argument position. It supplies all other arguments unchanged. The existential outputs remain outputs. No build result, future table, completion certificate, or worker history is supplied as input.

The filter's pending accepted_equal_sizes theorem is a separate semantic law. This startup wrapper does not claim an additional accepted-language theorem merely from the initializer application.

## Scope

This is the CURRENT Nat-path Lean source model. The full signed ChildIndex, normalization, Set representation/order, and literal Haskell equalities adapter remain open. The source Map/domain/key-order and literal SCC/fromRows/allocation correspondences remain separate. No sufficient global original worker depth, ordered public prefix, captured sibling restoration bound, or general capacity result follows from this wrapper.

No Haskell defect or fix was established. There is no FINDINGS item from this source-only task.

## Provenance

The two OLD whole paths were named before acquisition: the exact frozen 127-line full-constraint draft at its original private path, and current `SourceSizedPrefixComputedMinimum.lean` (75 lines) at its production source path. Their exact copies are retained. No other OLD body was acquired. Cumulative unions use original paths, including the uninstalled dependency path.

The complete filter provider remains available at `/tmp/mcfta-current-constraint-equal-sizes-review-20261031`. Its original equality-inventory provider remains available at `/tmp/mcfta-original-equality-filter-producer-review-20261031`. The closure check verifies both complete manifests. Only provider identity metadata is copied into this new owner. Provider source bodies are not acquired under metadata aliases.

V1 is the only draft. No failed read, tool failure, source revision, or observed elaboration error occurred in this task. Elaboration and strict-linter behavior remain untested. Root must kernel-check both the pending dependency and this wrapper before any checked claim.
