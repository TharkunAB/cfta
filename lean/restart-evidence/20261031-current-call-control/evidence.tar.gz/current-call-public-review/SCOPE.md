# Review scope

The parent authorized an independent source-only final review. Production edits and compiler, evaluator, native, Haskell, Git, network, board, and spawn operations were excluded. Python was used for byte copies, hashes, metadata checks, and the portable verifier.

Two OLD whole originals were named before acquisition:

- `lean/MicroCFTA/SourcePruningEnumerationIncomingNode.lean`, 296 lines.
- `lean/MicroCFTA/SourceCurrentAllocatedPartialInvariant.lean`, 89 lines.

Other OLD cumulative unions are:

| Original | Exact ranges | Union / original lines |
| --- | --- | --- |
| SourceCurrentEmptinessMemo | 28–38 | 11 / 129 |
| SourceCurrentConjunctionWorker | 49–97 | 49 / 108 |
| SourceCurrentConjunctionRowsWorker | 30–42, 45–55, 58–67, 88–100, 113–117 | 52 / 119 |
| SourceCurrentAllocatedConjunctionWorker | 25–41 | 17 / 105 |
| SourceSizedPrefixKnownOrdinary | 22–25 | 4 / 110 |
| SourceCurrentAllocatedNativeIncomingOldKnown | 43–65 | 23 / 165 |

The nine acquisition records retain original paths, full-source hashes and lengths, exact cuts, cut hashes, and copy names. `OLD-SOURCE-REPLAY-MAP.json` retains cumulative vectors and every matching whole snapshot already present in the required opaque provider closures. No third OLD whole was used for semantic review. No Nodes or RequiredCache body was read in this review. Their earlier scope concerns remain in the complete inherited provider evidence.

The five NEW checked sources are fully readable under the parent instruction. All 684 lines were read. The public suffix, canonical note, and current document prefix were read completely. Earlier document bodies and public output prefixes were retained and compared as bytes. They were not read again as new semantic inputs.

All 42 complete provider trees were preserved as required. Their embedded source bodies are opaque evidence except for the exact current semantic cuts. No provider, nested metadata file, failed attempt, or superseded seal was removed. Root's independent source and stdlib scopes remain separate from this reviewer scope.

The immutable historical 40-owner index remains unchanged. Supplements 41 and 42 are separate. Future owner 42 is outside the checked five-module checkpoint. No later source or proof status was folded into the historical index.

`replay.py` has no external file reads. It verifies restored evidence. It does not validate Lean judgments independently, run product code, or reconstruct the complete EmptinessMemo source from its small cuts.
