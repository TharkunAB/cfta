# Independent current-call review

Result: CLEAR. This review found no new issue in the five checked sources or their public claims.

The current local statement is conditional on the stated current entry gates. The actual allocated emptiness call retains the physical information needed for old handle lookup on every outcome. Its returned memo is correct on success and failure. A completed `True` proves that the query language is empty in the modeled semantics. `False` does not prove that the language is nonempty. Actual incoming-node execution also retains native `Stored` and the bounded ordinary handles in the BEFORE cache at every exposed caller. That conclusion concerns the original cache. It is not a certificate for a returned `Core`.

This review ran source and metadata checks. It did not run Lean, Haskell, a native worker, Git, or the message board. Root reports the checked source at `8efe735ba7fad5a030ba63c9daf5eff8d8733713`, full Audit default/strict at 4806 jobs and 83739 dependencies, and public output at 1332 declarations, 159 definitions, and 11 standard-axiom reports. The retained command records contain 18 attempts, 16 passes, two earlier failed attempts, and 90 input snapshots. Those are Root execution records.

## Source and contract review

All five new source bodies were read. They contain 684 lines. The complete 243-line public suffix was read. Its 11 public types match the source contracts. All 11 axiom reports list only `propext`, `Classical.choice`, and `Quot.sound`.

| Source | Checked claim and limit |
| --- | --- |
| Rows effects, 186 lines | Internal list and bind proofs retain semantic heap, coverage, growth, and issued-node history at actual endpoints. Completed rows have the stated available and closed results. Cold exposure and forest results derive the needed local gates. Failures and exhaustion use the reached heap. |
| Worker effects, 153 lines | Internal budget and pending-list induction covers actual explore, decision, call, and allocated call. The allocated wrapper uses the actual physical endpoint on success and failure. No future effect or trace is a public premise. |
| Incoming old known, 150 lines | Actual query execution derives its native trace internally. Physical check effects supply exact old-handle lookup at the reached heap. All exposed callers retain `Stored` and BEFORE-cache `KnownOrdinary`. The statement does not certify a returned `Core`. |
| Retained call, 125 lines | Actual call retains `At`, old merge `Stored`, old fourth-memo correctness, and every old fourth-memo entry. Failed calls retain the correct original memo at the reached heap. This is a subset of `Context/Post`. |
| Sound call, 70 lines | The actual completed-call semantic receipt is derived internally. Actual returned memo correctness holds on all outcomes. Completed answer soundness is conservative and proves emptiness only for `True`. |

The top contracts use the stated current heap, availability, closure, caller, cache, room, and resource gates. They do not request a future `Trace`, completed run, output certificate, future `Post`, or universal effect supplier. Existing native query proofs are used for `NativeDemand.execute`. The legacy raw interpreter is not substituted for it.

The complete OLD `Context/Post` definition was read. The five modules do not construct reached full readiness, partial-memo soundness, all global-cache validity, probe conditions, or the full physical-effects record. Physical heap growth and old-handle lookup do not establish those fields.

## Evidence and document checks

The historical 40-owner public input is unchanged. Its INDEX SHA is `f93c0caff4f0d1f3ce5430da5d7166f2483bf3edb1ce5077adff2ab5f17c681e`. Separate supplements retain sound owner 41 and future equality owner 42. All 42 owner trees were copied without filtering. Their 4912 files, active manifests, pins, full file sets, extra seals, and nested metadata pass byte replay. Provider bodies outside the direct semantic scope are opaque retained evidence.

The frozen owner-42 candidate is historical 132-line UNCOMPILED source. Root later reports a separate isolated 135-line strict pass outside the current checkpoint. Neither version is part of the five sources or the public 1332 output. The reviewer did not read or execute that future proof.

The 133-line canonical note and 64-line root prefix were read. Each full root document equals the exact new prefix plus its retained prior bytes. The complete public readback is 5120002 bytes. It equals the exact prior 5102922 bytes plus the new 17080-byte suffix. The intermediate 5118161 bytes are also an exact prefix. All 835 native-input metadata records are unchanged.

The direct OLD semantic scope is 541 lines over eight originals. Only IncomingNode, 296 lines, and PartialInvariant, 89 lines, are whole acquisitions. Every other original union is strictly below half. Seven originals can be replayed against exact whole source snapshots already present in the opaque closures. EmptinessMemo has only its 11 named lines retained as direct evidence. Its original whole-source SHA was recorded at acquisition. No additional whole source was acquired to reconstruct it.

## Remaining proof scope

The nearest local gap is the full actual caller `Context/Post`, including reached native readiness and equality/field obligations. The larger gap is a single sufficient ORIGINAL resource/depth bound with actual recursive progress for BOTH workers. Same-slot restarts, terminal and alias work, captured sibling restoration at the same caller and cache, and full worker fallback remain relevant. `PreparedNone` and unhandled observations do not expose a hidden caller, so they receive no hidden-state claim.

The complete objective still includes original public inputs, sound outputs, the intended finite ordered prefix under the exact order and stop policy, sufficient original resources, native and prepared workers, `Mu`/`Union`/opaque paths, public adapters, and Haskell correspondence. The current local results do not close that objective. No Haskell defect, fix, or runtime claim was established here. The root FINDINGS prefix retains that status for external work.

## Replay

Run `python3 /path/to/owner/replay.py` or `python3 /path/to/owner/replay.py /restored/owner`.

The verifier uses only files below the selected owner root. It checks all active provider trees and the complete review file set. It does not invoke a proof compiler or a product program. The OLD EmptinessMemo whole-source identity remains acquisition provenance; the verifier checks the retained cuts and their hashes.
