# Incidents

The initial bulk display combined old whole source and a large historical owner index. Tool output was truncated. All input bytes were copied and verified. The89-line PartialInvariant source was then read separately in full. The296-line IncomingNode source matched the prior fully read exact pin. The new five sources and public/doc content were read in separate bounded displays without truncation.

A preliminary metadata inspection attempted to parse every historical manifest as JSON. One historical manifest uses sha256sum text. The inspection stopped. No payload was changed. The final verifier distinguishes JSON and sha256sum formats.

A display of Root verify-owned.py was truncated. The complete script was copied as provenance. It is not called or claimed independently read in full. A separate portable source-only verifier will validate retained file sets and exact hashes without repository, Git, compiler, or external-path access.

All complete provider trees were copied opaquely without source or provenance filtering. Copying these evidence bytes does not enlarge the semantic OLD body-read scope. Every direct semantic OLD acquisition is recorded separately in acquisitions.json.

[2026-10-31 11:40 CET] Public-prefix copy initially treated Root/prior-public-readback as a file. Assertion stopped before any new OLD acquisition. It is a directory. Both already copied public output logs remain retained. Correct path is located by filename only.

[2026-10-31 11:49] First own replay attempt assumed every INDEX was an array. Historical INDEX is an object with files; the separate supplements are arrays. TypeError and the exact first attempt stdout/stderr/report remain retained. The corrected second replay passed. This is a metadata verifier correction. No proof source changed.

One optional metadata display called len on integer input_snapshots. It stopped with TypeError: object of type int has no len(). The18 command records store snapshot counts as integers. The complete records remain retained. No evidence or source changed.

Message timestamp correction: a progress message used11:49 before the host date read11:46:52 CET. That estimated message time is not a source, build, or freeze timestamp. All final records use the observed host clock.
