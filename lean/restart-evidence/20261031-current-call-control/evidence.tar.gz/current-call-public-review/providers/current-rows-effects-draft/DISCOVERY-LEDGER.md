# Discovery ledger

All direct named cuts are in acquisitions.json. All declaration and exact-match locators are in LOCATOR-LEDGER.json. The matched lines were replayed for byte-exact retention. Repeated lines count at their original source path.

The exact SemanticReady declaration search scanned declaration names under lean/MicroCFTA. Its only positive declaration was SourceEqualityRequiredSemanticCache.SemanticReady. No other body was acquired from that search.

Provider copies contain metadata and documents. They exclude source cuts and Lean source payloads. Complete private-provider provenance from the earlier reviewed dependencies remains available in that metadata closure.
