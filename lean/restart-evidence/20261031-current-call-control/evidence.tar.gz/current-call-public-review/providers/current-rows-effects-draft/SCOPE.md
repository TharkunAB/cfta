# Scope

SOURCE ONLY. UNCOMPILED future R20. Root owns all checks and production changes.

Named OLD whole slot1: SourceCurrentConjunctionRowsWorker.lean. Slot2: SourceCurrentConjunctionEquality.lean. All other bodies use bounded named cuts. Cumulative original-path unions include declaration locators. No third near-whole source acquisition. No Nodes or RequiredCache body.

Target: actual rows all-outcome semantic heap, coverage, growth, and issued history, plus actual completed available and closed rows. Use checked225 project/forest effects internally. Current natural inputs only. No future effects, completed/failed result, Post, Trace, or native admission supplier.

Keep actual Mu/Union/opaque and exhaustion endpoints. No legacy requireAll or native class substitution. The full original resources, both-worker, public prefix, and Haskell goal remains open.
