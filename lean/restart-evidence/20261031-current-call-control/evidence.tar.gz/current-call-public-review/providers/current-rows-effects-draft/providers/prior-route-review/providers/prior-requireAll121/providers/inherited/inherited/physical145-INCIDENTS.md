# Retained incidents

1. A saved-cut display exceeded the available output budget. The tool output was truncated. The command wrote the exact source cuts and all acquisition metadata before printing. The four saved payloads were then read from the owner directory. No payload was lost.
2. The second named `SourcePruningEnumerationNodes.lean` cut was unnecessarily broad. The union is lines 10–34 and 51–76, or 51 of 76 lines. Root was informed. Root replied at 08:13 CET: "It is not a third complete file, but your extra encode/preamble cut was unnecessary." Root required the 67 percent union to remain an explicit scope concern. Root allowed proof work from the acquired data and forbade any further body acquisition or reuse from this original. The draft uses the retained data only. The ledger does not classify this union as a signature-only read.
3. One saved-payload read was aborted before tool dispatch when a new Root message arrived. The same read then completed. There was no source acquisition or state change in the aborted call.

No compiler or evaluator attempt ran. There is no omitted compiler failure. No source file in production was changed.
