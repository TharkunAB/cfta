# Retained scope controls

The two requested whole filenames existed. There was no filename correction or failed source acquisition.

SharedTargetWorker reads accumulated to 34 of 60 lines. This is a 57 percent source union. It includes actual result constructors and the force, step, and leaf calls needed to locate the physical endpoint boundary. It is not labeled signature-only. Root was informed at 09:35 CET. No further SharedTargetWorker body was acquired after that notice. A later bounded public-header cut records the newly checked require210 dependency. The exact union and copy pins remain in the ledgers.

No Nodes or RequiredCache body was read in this fresh task. Their inherited 51/76 and 57/105 scope records, including the prior unused 25 lines, remain copied as provider metadata only.

No compiler or evaluator ran. There is no omitted probe failure. Native admission sufficiency and the missing native-node contract were neither proved nor refuted by execution. No source or Haskell defect is claimed.
