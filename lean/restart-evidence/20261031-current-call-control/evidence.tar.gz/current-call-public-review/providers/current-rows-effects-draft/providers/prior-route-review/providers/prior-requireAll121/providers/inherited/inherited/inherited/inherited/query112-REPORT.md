# New ordinary result of an actual target query

Status: SOURCE-ONLY. Final V2 has112 lines. V1 and V2 are UNCOMPILED.
Root owns all execution and kernel checks.

# Concrete local result

The candidate bridges the real TargetQuery receipt to the existing native
finite-ordinary result theorem. It classifies the NEW returned value.
For empty-seen ordinary operands, the result is an ordinary Node and its height
is at most each actual operand's height. It returns an actual encoded handle
and successful lookup of the SAME value in the reached physical heap.
It also returns the finite-ordinary native Stored certificates after the query.

The source heap can be any admitted supplied heap. Only the native thunk
tables are empty at this entry. The source heap is not required to be empty.

The top initial_finite_result producer uses the literal
SourceCurrentAllocatedPartialInitialization.checked initializer. It derives
entry Stored from the actual empty native thunk tables. Stored, a future
result, a future trace and a future receipt are not inputs to that producer.
Its other inputs are the existing current query gates: Ready, At, Available
operands, closed operands, Fits, Room and valid global memos. It also takes the
actual ordinary-domain properties of the two current operands.

The finite_result law is a compositional step. It takes existing CURRENT Stored
and returns Stored after an actual constructed query. The receipt_result law
reads the actual receipt's Step.run trace and classifies that actual endpoint.
Those two conditional helpers do not establish arbitrary warm admission.
The cold producer establishes the native structural seed and the actual query
updates establish the next Stored value. No replacement MemoOrd API is added.

# Exact source route

SourceCurrentAllocatedFiniteOrdinaryStored.NodeCertificate at24 states:
empty seen and ordinary left/right imply ordinary result and both height bounds.
Stored at36 quantifies over every returned native node AND edge memo cell.
Both tables are needed because actual node queries can hit edge memos internally.
initial_stored at98 derives that property from empty native thunk tables.
advance_stored at102 retains it when the physical machine changes at fixed
native thunk tables.

SourceCurrentAllocatedFiniteOrdinaryExecution.node_trace at246 consumes the
actual completed physical trace. It returns Stored-after, Node result and both
height bounds. Its verified proof at77 follows actual source instructions.
It proves the body result before each literal finish frame stores it. Warm-hit
branches use the actual captured request. node_observed_ready at Stored144
reads the certificate for the exact ready cell identified by the physical memo
lookup and demand. No semantic-equivalence substitute supplies that certificate.
The proof also covers warm memo hits created earlier INSIDE the first cold query.

TargetQuery.Step.run at35 has the literal emptyDomain request and a completed
physical trace. The candidate supplies NodeInputs with empty seen and the two
ordinary operands. TargetQuery.Receipt.actual exposes that Step. Its available,
closed and ready fields supply the actual resident result and coherent reached
heap. SourcePruningEnumerationNodes.available_readback at35 then returns
encodeNode value=some handle and lookupNode reachedHeap handle=some value.
The value is the actual query result, including empty and contradiction results.

The factory derives Original operands from closed_original. Fits.room supplies
the three current numeric bounds. warm_initial_ranges derives WordRanges from
those current bounds, Good, SemanticReady and available Original operands.
TargetQuery.finite constructs the actual completed receipt. No caller supplies
WordRanges, a desired result, a future trace or a completion witness.

The checked initializer at36 sets native to
SourceRecursiveIntersectionThunks.initial width (heap, Cache.emptyState).
The existing initial_stored theorem applies to that exact native state.
SourceCurrentAllocatedNativeStoredTrace.initial_clean_trace_stored at277 uses
the same literal seed. Its clean_trace_stored theorem at59 supplies the existing
mixed-source preservation route. Both full modules and all their private
helpers are retained in this bundle.

# Admission distinctions and remaining gaps

Ready exposes Good, SemanticReady, cost Heap, scoped native cache and Idle.
At exposes contextual and covered native memo laws plus physical growth/history
from the original inventory. Global Memos.Valid certifies unfolding and endpoint
memo families. These fields are distinct from finite-ordinary Stored.
They are not interchangeable.

This review does not prove that arbitrary warm Ready+At+global validity implies
finite-ordinary Stored. It also establishes no counterexample to that implication.
The exact unproved strengthening would remove the CURRENT Stored input from
finite_result while retaining an unrestricted warm before state. The candidate
claims no such strengthening. Its top cold producer derives Stored directly.
For later real worker states, the actual initializer and actual maintained
native-Store preservation laws must produce that current fact at each reached
query entry. This is an operational producer obligation, not a proposed future
history or MemoOrd supplier. WARM-ENTRY-BOUNDARY.md retains the precise distinction.

The new result bounds imply the same original shared height bound when an
actual operand has that bound. They do not prove strict decrease for a repeated
same-slot query or bound sibling count. Output row-count/arity profiles use the
separate OutputStored family; this draft claims no new profile theorem.

Arbitrary configured-fuel raw endpoints remain separate. The constructed
completed TargetQuery receipt does not by itself identify every actual incoming
execute observation with that endpoint. The retained Step.done and Step.unique source cuts expose literal completed
execution and completed_unique. They can support a later observed-done
endpoint bridge. That bridge is not added in this owner. No result property is asserted at unfinished
outcomes or unexposed states. Actual incoming cache assignment, terminal/alias
handling and captured sibling restoration still need their own concrete
transports. This candidate returns the new handle but does not certify a cache
update that stores it.

The work proves no whole-worker progress, original sufficient-depth theorem,
finite ordered-prefix theorem, literal Haskell reification or Haskell behavior.
No Haskell defect or fix was established. FINDINGS was not changed.

# Provenance

There are34 acquisitions at17 original paths. Exactly TWO OLD wholes were
named before acquisition: FiniteOrdinaryExecution271L
SHAc8d546542d20fc2005a01c364eb2c1b5c5de4849cfcdd44518dfe9faef107d57,
and NativeStoredTrace290L
SHAe12f40e084180ab303d4d06301ecec61f927865c0cfd141db17daeed563da8a4.
All other code uses named bounded cuts or declaration locators. The largest
other cumulative union is69 of119 lines in TargetQuery. All acquired source
payloads, unused output-profile locators, hashes, versions and incidents remain.

acquisitions.json records full source paths, full source hashes and sizes,
exact cuts and copy hashes. ORIGINAL-FILE-UNIONS.json records cumulative unions.
SOURCE-VERIFICATION.json records successful metadata and exact-range checks.
There is no external private draft provider in this proof. The two whole
providers retain their private helpers. Other imports are checked repository
dependencies; their complete transitive source bodies were not separately
acquired or claimed as reviewed here. No compilation or evaluation ran.
