# Actual incoming old-cache transport

The source-only draft isolates the remaining full-target producer at failed
physical checks. It supplies code for the other transport cases and the concrete
empty-row fallback need. This draft still needs Root checking. It is not a
checked proof of the full all-exposed-caller target.

Final candidate: SourceCurrentAllocatedNativeIncomingOldKnown-v2-UNCOMPILED.lean.
150 lines, 10580 bytes, SHA256
9ec62f58e4a1dc868a5ff8f696f0a702d9239b2e6985fa56792c47e68a71a372.
It contains two public laws and one private execute-prefix helper. No compiler,
evaluator, native/Haskell execution, Git, network, board, production edit or
spawn ran. Both retained candidates remain UNCOMPILED.

## Concrete draft result

native_query_old_known consumes current Ready, available/closed actual operands,
Fits/Room and current KnownOrdinary for the before Cached value. For arbitrary
native fuel it derives KnownOrdinary for that SAME Cached value at the actual
execute outcome's physical heap. This includes yielded, done, failed, blocked
and constraint-error constructor cases as a property of the actual outcome state.
No future receipt, trace, result, output or per-step invariant is an input.

The proof derives closed Original operands from actual availability/coherence,
then derives current word ranges from Fits.room. The existing initial_complete
producer constructs its checked physical trace internally from these current
entry gates. The copied private execute-prefix readback selects the actual
bounded execution state from that trace. SemanticTraceReadback.effects gives
physical old-handle retention at the selected prefix, and keeps_known transports
Known. The internally produced complete trace is not a supplied future witness.
This is the same current-entry producer route as checked execute_stored. It does
not select a sufficient original worker depth or establish global progress.

run_old_known_except_failed_check handles actual IncomingNode.run with arbitrary
checkEmpty, representative/native/p/h fuels and endpoint queries. It takes the
current Context, PendingRealized, incoming Available/closed, current Known,
Fits/Room and native Stored. Incoming Node/height hypotheses are unnecessary
for OLD-cache retention and are omitted. No stronger admission is added.

Native Stored holds at every exposed caller. The SAME before Cached value has
Known at the reached heap on every actual result except outer .error(.inr check).
This includes representative/slot error ROWS inside outer .ok, enumerated and
eliminated slot error rows, None-fill, .ok none, .ok(some []), successful Core
returns, and native .error(.inl outcome). Native non-done cases use the new
actual-prefix Known producer. Successful physical phases derive their actual
Call and Post from observed execution, current queryPost.context and
receipt.available, then use post_known. No future Post is an entry gate.

No Core row is required for this old-cache statement. In particular .ok(some [])
retains the OLD Cached Known at the new physical heap. This directly supports
CachedAdapter's empty-row fallback to before. It claims no hidden caller from
an enclosing wrapper. The excluded physical-check failure still has native
Stored, but this draft gives no old-cache/lookup fact for its physical heap.

## Exact remaining current-entry producer

NEXT-MISSING-CONTRACT.lean.txt states failed_call_lookup as a HEADER ONLY.
It consumes current Context, current query availability/closedness and ordinary
query. It executes the literal AllocatedConjunctionWorker.call p h 1000 and
concludes physical old-node lookup retention at its actual failed endpoint.
It takes no future outcome, Post, Keeps, Trace, lookup supplier or invariant.
Lookup retention is the precise needed conclusion. A stronger failed-state
Ready/Keeps theorem is not required by the cache property.

At actual Incoming failure, the source forces enabled checking and a true
endpoint guard. AllocatedConjunctionWorker.call_failed exposes the exact raw
physical failure and its advancePhysical endpoint. The current query Context,
availability and closedness derive from actual raw_done_caller_initial. Under
the original ordinary incoming/current-Known/current-Stored admission, the
ordinary query also derives internally from receipt_result and old-slot membership.
The header therefore adds no new top-level gate. Applying this current-entry
producer to each existing known handle would remove the sole exception from
the draft's main law.

The inspected completed-call exports do not prove this producer.
ConjunctionCaller.actual and ProjectionWorkerSound.forest_graph consume actual
DONE observations. Physical call_failed only exposes the reached physical state
and saved memo; it supplies no lookup preservation. AnnotationOutcome.call_heap,
allocated_call_heap and enabled_check_heap cover success/failure but their
HeapOutcome is only Heap annotation result.state.heap. This does not imply
retention of old canonical handles.

The actual failed path passes through RowsWorker.exposures/projections, whose
pending/unresolved/exhausted branches retain the exact returned heap. The lower
ProjectionWorker.forest/project and RequiredWorker result binds also retain
partial heaps on failure. The needed next proof is all-outcome physical lookup
transport through these actual operations, then the rows/explore/check wrappers.
There is useful lower support: ColdEffects.Verified supplies semantic/covered,
heap growth and issued-history extension even for exposure exhaustion. Its
structure does not directly contain the desired high-level failed-call lookup
export. Forest annotation preservation and completed graph/resource laws do
not fill this missing implication. No current execution contradicts desired
retention. This is an unproved producer, not an established runtime defect.

## Check status and full scope

The first named whole snapshot was current IncomingKnown180, initially reported
UNCOMPILED while Root repaired it. Root confirmed at 07:19 that the SAME SHA
 a326d1b5ba430f43d7d835148997fa61368de13bf73afaec1bed41c89c774069
passes both focused default and strict checks. The exact snapshot remains
unchanged. The historical initial label is retained in SCOPE and acquisitions.
Root's checked status is separate from these new 150-line source-only drafts.

Cold Known/native Stored still derive from the actual existing initializer
producers. Warm current Stored is maintained; it is not inferred from arbitrary
Ready/At or merge memo Stored. The draft is local physical/cache support. It
does not close the excluded failed check, whole-worker invariants/termination,
terminal/alias progress, captured sibling restoration, sufficient ORIGINAL
resources, intended finite ordered public prefixes, both worker/public adapters
or Haskell correspondence. No new Haskell defect/fix is established.

All source acquisitions/reuses, original-path cumulative unions, exact full-source
hash/size/line metadata, exact cut/locator bytes and private provider metadata
are retained. Exactly TWO OLD whole originals are used: IncomingKnown180 and
IncomingNode296. All other source bodies are named bounded cuts. The complete
source verification records any current-source drift separately from immutable
acquisition bytes. Root owns checks, any repair, installation and publication.

Freeze verification: 57 source acquisitions across 30 ORIGINAL paths; two OLD
whole modules. The largest other body union is 81/559 lines of physical trace
completion. The highest other fraction is 53/89 lines of StoredExecute, all from
named locator/range acquisitions. No third whole body is acquired. All source
metadata, range/locator bytes, copy hashes and current-source pins match. There
is no source drift. All 48 provider metadata copies are byte-exact.
