# Next current failed-call contract

HEADER ONLY. UNIMPLEMENTED. UNELABORATED. No proof or truth claim.

Use the same Symbol, Constraint, Node, Checked, Caller, Cached, Inventory, Context, and KnownOrdinary aliases as the checked current incoming API. The Node equality required by call can use scoped Classical.

```lean
open scoped Classical in
theorem failed_call_old_known
    (bound : Nat)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (before : Caller width)
    (memos : EndpointMemoGateTrace.Memos) (cached : Cached)
    (p h : Nat) (query : Node)
    (context : Context formulas solver inventory before memos)
    (available : Available before.checked.native.machine.heap query)
    (closed : query.free = [])
    (ordinary : FiniteOrdinaryDomain.Node query)
    (known : KnownOrdinary bound before.checked.native.machine.heap cached) :
    match SourceCurrentAllocatedConjunctionWorker.call p h 1000 query
        before.checked before.fourth with
    | .done _ _ _ => True
    | .failed _ reached _ =>
        KnownOrdinary bound reached.native.machine.heap cached
```

The full physical lookup target is stronger than this cache consumer. It retains every old handle and exact decoded value at the actual failed endpoint. That target is the prior failed_call_lookup contract. Do not replace it with language equivalence.

The first actual local induction target is CurrentConjunctionRowsWorker.projections. Its inputs are the current physical state and current finite job list. Each present job forest must be Available and closed at that current heap. The output must derive current semantic heap, coverage, growth, and issued history at actual Outcome.state.heap. Only an actual done result requests available closed returned values.

At the outer caller, derive those job facts from actual exposures, tuple edges, and jobs construction. Do not expose them as a future successful-row or per-step supplier. Prove all pending, unresolved, exhausted, equality error, missing-equality, table-grow, memo-hit, and early closed/empty/skip branches.

No native WordRanges or raw-class admission belongs in this current physical path unless an actual call edge introduces it.
