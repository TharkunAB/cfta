# Actual native incoming whole-cache Known

Started 2026-10-31 06:30 CET. SOURCE-ONLY task.
Prove whole returned-cache KnownOrdinary for actual IncomingNode.run from current
Known, incoming ordinary Node/height cap, and existing Context/PendingRealized/
Available/closed/Fits/Room/native Stored gates. Derive all actual branches,
receipts, physical old-handle retention, old-row membership and new-slot facts
internally. Preserve arbitrary representative/native/check fuels and checkEmpty,
None, Some, enumerated/eliminated, all errors and empty rejection. Claim Known
only on actually returned successful Core rows. No hidden-state/Core claim on
failure/absence. No future output, Post, Receipt or whole-invariant supplier.

OLD whole slot1: SourceSizedPrefixKnownOrdinary.lean. OLD whole slot2:
SourcePruningEnumerationIncomingNode.lean. Other source uses named bounded cuts
and exact cumulative ORIGINAL-path unions. Root owns compiler/evaluator/native/
Haskell/Git/network/board/production. No spawning. Preserve cold initialization,
warm Stored maintenance, whole-worker progress and Haskell boundaries.

The final top also permits arbitrary actual endpoint queries as current data.
The Context memos remain the raw-query/physical-call proof environment.
The draft imports neither uncompiled Bool145 nor uncompiled None92.
