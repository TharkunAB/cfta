# Incidents and attempts

No compiler/evaluator/native/Haskell/Git/network/board/production/spawn action
occurred. No executed Haskell defect or fix is claimed.

One named path did not exist: SourceCurrentAllocatedNativePhysicalTrace.lean.
Its missing-path payload remains retained. The actual Trace is declared in
SourceCurrentAllocatedNativePhysicalTraceCompletion.lean. Subsequent source
acquisitions use that exact module and declaration ranges.

Filename-only searches stayed in the actual native/conjunction/equality-worker
families. Full outputs/stderr are retained. No bodies were read from filename
output. The broad physical-effect filename result did not establish any failed
lookup theorem. Every later semantic read was a named locator/cut.

Annotation outcome exports were inspected as a possible failure bridge. Their
actual conclusion is only annotation Heap. It was not promoted to old lookup
retention. ColdEffects.Verified contains growth/history rather than a direct
high-level call-failure Keeps export. Both distinctions are explicit in REPORT.

V1 was retained before V2 strengthened actual native-error coverage. No compiler
failures or fixes are claimed for either. Root's external IncomingKnown180 checks
are recorded separately. The exact initially UNCOMPILED snapshot was not altered.
