# Incidents and versions

No source-copy or hash check failed. No compiler, evaluator or native/Haskell
execution was attempted. No executable counterexample or defect was established.

The first tool display exceeded its output budget. The complete declaration
locators and filename-discovery payload were already retained under cuts and
discovery. No source payload was lost. Later displays used bounded output.

Initial inspection included OutputStored and OutputExecution. Those modules
certify output row/arity profiles. The needed Node/height certificate is instead
FiniteOrdinaryStored.NodeCertificate. All unused locator payloads are retained.

V1 named after/value explicitly under dependent Step.run elimination. V2 uses
inferred endpoint arguments in the node_trace call. No statement or proof route
changes. This is a source preflight correction, not a compiler failure.
Both draft versions remain UNCOMPILED. Root must check elaboration and the empty
seen reduction. Root was sent both exact hashes.
