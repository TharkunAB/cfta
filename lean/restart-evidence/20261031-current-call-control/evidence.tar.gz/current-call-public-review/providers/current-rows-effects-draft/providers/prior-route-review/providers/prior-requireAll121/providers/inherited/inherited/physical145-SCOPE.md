# Actual failed physical lookup retention

Started 2026-10-31 08:03 CET. SOURCE-ONLY FUTURE R19. R18 remains CLOSED at five
checked modules. This work is uncompiled and outside that claim.
Try the exact prior failed_call_lookup HEADER ONLY contract from CURRENT Context,
Available/closed/ordinary query. No supplied future outcome/Trace/Keeps/lookup
supplier. If full call closure does not fit this bounded task, implement the
smallest necessary actual all-outcome projection/required/rows transport law
and give the exact next producer. No axioms or omitted proof bodies in drafts.

Exactly TWO named OLD whole originals: SourceCurrentAllocatedConjunctionWorker
and SourceEqualityProjectionWorker. Other old source/proof reuse uses named
bounded cuts, cumulative ORIGINAL-path unions, exact pins and full provider
metadata. Inspect SourceRecursiveIntersectionNativeColdEffects.Verified before
duplicating support. Root owns all compiler/evaluator/native/Haskell/Git/network/
board/production actions. No spawning. Preserve original Mu/Union/opaque and
all-branch worker/global original-D scope. No Haskell defect/fix is established.
