# RequireAll and class physical review

Status: SOURCE-ONLY UNCOMPILED FUTURE R20. The complete candidate is `SourceEqualityRequiredAllEffects-v2-UNCOMPILED.lean`, 121 lines, 7937 bytes, SHA256 `7fa43d3550ba56df5975bb3045779ff84c7fe4fffa707af2e08a458aed1b96f5`.

The draft derives actual `requireAll_effects` from the public `require_effects` dependency. It performs its own actual child-list induction. It does not call a private helper from the require, project, or physical modules. Current inputs are `SemanticHeap`, `Covered []`, and availability and closure of the supplied value list. Worker fuel, read fuel, and source paths are arbitrary. There is no future effect, trace, lookup, failed outcome, successful Post, or callback supplier.

The compiled Needed map is obtained from actual `build paths`. The list induction follows each actual lookup at the current signed index. An absent map entry keeps the original child. A present entry invokes actual `require` and uses the checked public producer. Earlier unchanged or rebuilt values remain available through later sibling growth and issued history. Each actual final result retains semantic, coverage, physical growth, and issued-history facts. A completed list is available and closed at that same final heap.

This is a complete source proof draft. It has not been compiled or evaluated. Root reported at 09:37 CET that normalized require210 passed default and strict checks. Its SHA256 is `50c7fa76998aaf81d9543700e61c6c05141cdb3792261e01877a4298d7011dcd`. The checked public header was acquired through a bounded cut and its full source hash matches. The old 209-line frozen snapshot keeps its historical UNCOMPILED label. Normalized physical149 remains separately checked. No frozen old provider was changed.

## Actual class consumer

The second named whole source is the actual `SourceEqualityClassFoldWorker`. It performs a finite right fold. Each class calls `SourceEqualitySharedEditWorker.editAll` with its captured current values, actual class edits, and `SourceEqualitySharedTargetState.initial before`. That initializer clears only the shared target map. It retains the supplied native machine and both native memo families. Completed classes pass their returned native state to the earlier class. Incomplete classes retain the original captured forest and the complete shared-stage observation.

The list-entry result alone does not close that class producer. Actual edits call `SharedTargetWorker.leaf`. A leaf first calls `force`, then `step`:

- `force` returns a cached `before.targets path` value directly on a hit. The class initializer proves that there is no hit initially. Later hits need availability and closure derived from actual stores and carried through actual native heap growth.
- On a miss, `force` calls actual `SourceEqualityDemandTargetWorker.target`. A failed target is wrapped as `.target other before`. The inner target observation must be read at its actual endpoints.
- `step` calls actual `SourceRecursiveIntersectionNative.execute` with the literal node request `(.node ⟨emptyDomain, target, input⟩ .pure)`. A non-done result is wrapped as `.native other before`.

The outer shared state in that last result is the old `before`. The actual native endpoint is `other.state`. `Native.Outcome.state` explicitly covers yielded, done, failed, and blocked outcomes. Proving a fact only at the outer shared state would omit physical effects from the native prefix. No such class-preservation claim is made here.

The next smaller native obligation is recorded in `NEXT-NATIVE-PHYSICAL-CONTRACT.lean.txt`. It asks for physical growth and issued history at every actual native endpoint. Full semantic and coverage facts, plus result availability and closure, are requested only on actual `.done`. It does not demand a complete semantic heap at every yielded, failed, or blocked prefix. The file is an open implication to investigate, not a proved or assumed theorem.

Current native admission also needs an actual producer. `SourceRecursiveIntersectionThunks.State` has independent machine, node-memo, and edge-memo fields. Its `Valid` proposition constrains all three. Heap-only cold gates do not supply that separate proposition in the inspected source. This task has not proved that those weak gates suffice or fail for the native obligation. It adds no native-validity premise to the implemented public list theorem. Any needed current native invariant must be derived from the actual caller initialization and actual updates before class composition.

The exact bounded class consumer and required result distinctions are retained in `NEXT-CLASS-CONSUMER.md`. The class fold, final empty propagation, outer conjunction rows and decision workers, and the final failed-call wrapper remain unproved here. In particular, `failed_call_lookup` is still open.

## Full goal boundary

No ordinary-only condition was added. Mu, Union, opaque inputs, and every actual failure or exhaustion remain in scope. This local list result does not establish sufficient original resources, Native or Prepared whole-worker progress, terminal and alias maintenance, captured sibling restoration, finite ordered requested-prefix coverage under the configured policy, public-adapter correctness, or Haskell correspondence. No Haskell defect or fix was established.

## Source controls

Both named OLD whole paths were checked to exist before content acquisition: `SourceEqualityRequiredExecution.lean` and `SourceEqualityClassFoldWorker.lean`. Every other acquisition is a named bounded cut or declaration locator. Full source pins, copy pins, exact ranges, and cumulative original-path vectors are retained.

The current SharedTargetWorker union is 34 of 60 lines. It includes constructors, force, step, leaf, and declaration locators. This 57 percent union is retained as a scope concern. It is not described as a signature-only read. Root was informed at 09:35 CET. No further SharedTargetWorker body was acquired after that notice. The only later source acquisition was the newly checked require210 public header. No third complete file was acquired.

No Nodes or RequiredCache body was acquired in this task. The prior Nodes 51/76 concern and RequiredCache 57/105 union, including its unused 25-line incidents, remain in the full inherited metadata closure. The old 129-file provider stays immutable.

No compiler, evaluator, native or Haskell execution, Git, network, board, production edit, or child task ran here.
