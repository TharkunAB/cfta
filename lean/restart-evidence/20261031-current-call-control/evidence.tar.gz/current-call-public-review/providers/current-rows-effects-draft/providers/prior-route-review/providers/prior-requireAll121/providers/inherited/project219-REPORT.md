# Project physical closure

Status: SOURCE-ONLY UNCOMPILED FUTURE R19. The final candidate has 219 lines. It is `SourceEqualityProjectionWorkerEffects-v3-UNCOMPILED.lean`, SHA256 `d408ce1b79c746cd94e37dce358b8fee74785921008772c2dba2256506f7f2ac`.

The draft implements the exact current-entry `project_effects` contract from the prior frozen header. Its public inputs are the actual fuel, read fuel, signed path, query, and initial heap, plus current `SemanticHeap`, `Covered []`, query availability, and query closure. It has no future outcome, trace, semantic postcondition, or lookup supplier.

Each actual outcome returns `SemanticHeap`, `Covered []`, physical `Grows`, and issued-history `Extends` at its exposed heap. A completed value is available in that same heap and has no free references. These are draft statements with complete source proof bodies. They are not checked claims.

The induction follows the actual `project` fuel and source row order. It derives a selected child's availability from the current resident edge and current cached facts. It carries the remaining resident edges through the actual recursive growth. It also carries earlier returned values through later row work. The private `rows_verified` helper receives only the smaller actual `project` induction hypothesis. The public producer derives that hypothesis by fuel induction. No caller supplies it.

The Mu and Union cases execute actual `head`. They recurse only after that call returns `.done`. Every other result retains its actual reached heap. Worker exhaustion and head exhaustion remain separate actual constructors. There is no assumption that either bound is sufficient. Bare references retain their actual unresolved outcome. No ordinary-only or all-slot admission condition is added.

Primitive reconstruction uses the actual `InternedNestedFacts.node_verified`, `SourceRecursiveIntersectionSemanticHeap.node`, `InternedNestedCoverage.run_covered`, and `makeNode_closed` producers. It does not require `Ready.depth`. Growth and issued history suffice for the old-record transport needed here.

The additional `forest_effects` law uses the same producers. It covers root union, an absent signed child returning Empty, and an actual selected child. It derives membership from the observed selector result. It adds no future gate.

The private `Verified` record and bind lemma package proof fields inside this module. They are not public admission conditions. The actual public project and forest laws derive every field internally. The candidate concerns the source constructor heap. It does not establish native thunk `Stored`, all-caller admission, or a new global invariant by itself.

## Dependency status

The only old helper reused from the prior 145-line draft is its public API: the transparent `reached` and `exposure` definitions and the `readAll_verified` header. Their exact cuts total 16 of 145 lines. No private body from that draft was acquired.

At Root's last status message, 08:37 CET, the installed physical helper had 147 lines and its first default probe had proof-only elaboration failures. Its public statements were unchanged. Root was repairing indentation, primitive work normalization, and head-match normalization. This new 219-line candidate is also uncompiled. Its primitive `work` proof may need the same explicit normalization during Root's check. No result here assumes that the original helper proof passed.

Root also reported that the separate raw150 and cached139 laws passed default and strict checks. Those checks do not type-check this new candidate. The complete Root message is retained in `ROOT-STATUS.md`.

## Remaining bridge

The next producer is actual `SourceEqualityRequiredWorker.require` with the same current heap gates and the same all-outcome effects and completed-value properties. Its child traversal must carry unchanged and rebuilt values through actual sibling work. Its row traversal must use the actual `makeEdge` and `makeNode` producers. The proposed header is retained in `NEXT-REQUIRED-CONTRACT.lean.txt`; it is not a proof.

The required-class fold and subsequent rows, decision, and conjunction-call wrappers must then lift these actual effects to each failed result. The original `failed_call_lookup` is still open. Its header remains in the inherited provider closure. No future failed result, `Post`, or `Keeps` premise has been substituted for that producer.

This local transport does not prove sufficient original depth or word capacity, Native or Prepared whole-worker progress, captured sibling restoration, terminal and alias preservation, global requested-prefix coverage, public-adapter correctness, or Haskell correspondence. Original Mu, Union, opaque inputs, and the full original-input goal remain in scope. No Haskell code was executed. No Haskell defect or fix was established.

## Source controls

The two named OLD whole originals are `SourceEqualityProjectionWorker.lean` and `SourceEqualityRequiredWorker.lean`. All other source acquisitions are named bounded cuts or exact declaration locators. Full source hashes, copied bytes, and cumulative original-path vectors are retained.

No `SourcePruningEnumerationNodes.lean` body was acquired or reused directly in this task. The prior helper provider retains its acknowledged 51-of-76-line scope concern. `INHERITED-SCOPE.json` preserves that provenance. It does not describe the earlier union as a signature-only read.

The full prior document and metadata closure was copied byte for byte. No prior Lean proof body was copied through that closure. No compiler, evaluator, native or Haskell execution, Git, network, board, production edit, or child task ran here.
