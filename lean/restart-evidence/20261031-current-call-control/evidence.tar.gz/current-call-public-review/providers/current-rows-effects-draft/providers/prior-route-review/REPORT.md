# Actual current failed-check route

Status: SOURCE ONLY. No new proof draft or checked law.

The current failed-check route does not call SharedTargetWorker.step, SharedTargetWorker.force, or ClassFoldWorker.pass. A law for those functions does not close the current failed_call_lookup gap.

## Actual calls

1. SourcePruningEnumerationEnabledEmpty.check28–34 calls SourceCurrentAllocatedConjunctionWorker.call when the endpoint guard succeeds.
2. SourceCurrentAllocatedConjunctionWorker.call35–41 calls SourceCurrentConjunctionWorker.call. It lifts both outcomes with advancePhysical.
3. SourceCurrentConjunctionWorker.call90–97 checks the emptiness memo first. A miss calls decision75–83.
4. decision calls explore49–64 for a closed query. A rows failure returns the actual reached physical state. A failed table grow also returns the reached state.
5. explore calls SourceCurrentConjunctionRowsWorker.rows113–117.
6. rows exposes the input nodes, then processes the matching tuples.
7. tuple88–100 runs SourceCurrentConjunctionEquality.fold. This changes the equality operation cache and retains before.heap. The error and missing-equality branches expose that retained heap.
8. The live tuple calls requirements81–85, then classes70–78.
9. classes calls projections58–67. Each projection calls SourceEqualityProjectionWorker.forest at the actual current heap. All pending, unresolved, and exhausted cases expose the forest result heap.

The current class requirements are a finite list of physical forest projections. They do not run the separate native class narrowing worker. The completed requireAll law is not the direct consumer in this requirements function.

## Native interpreter distinction

The separately inspected SharedTargetWorker.step calls SourceRecursiveIntersectionNative.execute. The checked native_query_old_known API calls SourceEqualityNativeDemand.execute. NativeDemand.step91–100 intercepts an edge request and enters edgeBody. Its other instructions lift raw native.step. The two interpreters have no definitional endpoint identity established here.

SharedTargetWorker.step exposes a raw non-done endpoint inside other.state. Its outer shared state remains before. No preservation statement about that inner endpoint was proved here.

Context.ready supplies the checked current Ready admission. The separate SharedTargetState.Ready contains raw IdleReady, captured Keeps, and target receipts. The old raw warm_node_complete header also requires WordRanges. No new relation from those old headers to the current failed-check route is claimed.

## Next current producer

Use checked SourceEqualityProjectionWorkerEffects225 public forest_effects at the actual forest call. First prove an all-outcome effects law for CurrentConjunctionRowsWorker.projections by list induction. Maintain the current job forests through actual constructor heap growth. Then lift through classes, requirements, tuple, tuples, rows, explore, decision, and call.

The exposure producer must also retain the actual current heap and complete operand availability. The existing physical149 readAll_verified is the relevant current support. No new future Trace, Keeps, completed run, or effects witness may be supplied to the public consumer.

The next failed-call contract is retained in HEADER-ONLY-CURRENT-FAILED-CALL.md. It is not a theorem. The report does not assume that its current admission is sufficient.

## Evidence and limits

All direct cuts and all declaration locators have original source hashes, exact copied bytes, and original-path unions. Two OLD whole originals were named before acquisition. Both were acquired unchanged. No Nodes or RequiredCache body was acquired.

Cumulative supplemental unions include NativeDemand86/160, SharedTargetState59/124, CurrentConjunctionWorker54/108, and CurrentConjunctionRowsWorker77/119. The last union includes51 direct cut lines and41 locator lines, with overlap. The rows branch locator was broader than required. This is an additional source-scope concern. It is not hidden as a signature-only read. No supplemental source was acquired as a whole file.

The prior Nodes51/76 and RequiredCache57/105, including25 unused lines, remain in inherited provenance. The prior SharedTargetWorker34/60 concern is retained. This task explicitly named that original as its first whole-file slot.

The class-step investigation stopped after Root requested the actual-route test and the different current route was confirmed. No compiler, evaluator, native execution, Haskell execution, Git, network, board, production edit, or child spawn occurred. No Haskell defect or fix was established.

Original sufficient resources, whole-worker progress, both workers, Mu/Union/opaque behavior, public requested prefixes, and Haskell correspondence remain open at the parent goal. No new global result is claimed.
