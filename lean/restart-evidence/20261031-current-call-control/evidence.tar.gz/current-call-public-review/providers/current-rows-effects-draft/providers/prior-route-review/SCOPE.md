# Scope

SOURCE ONLY. UNCOMPILED future R20. Root owns all execution and production changes.

The two named OLD whole originals are SourceEqualitySharedTargetWorker.lean and SourceEqualityClassFoldWorker.lean. All other source reads use named bounded cuts and cumulative original-path unions. No Nodes or RequiredCache body is acquired.

The target is actual step or force-miss old-cache Known transport at the true native endpoint. Current Context/Ready/Fits/Room and available closed operand admission may remain. No future certificate, Trace, ranges, completion, or output supplier is allowed. Class-fold preservation and native admission from cold heap gates remain open unless derived. Full original-resource, both-worker, public, and Haskell goals remain open.

Inherited scope concerns: Nodes 51/76; RequiredCache 57/105, including unused 25. The prior owner SharedTargetWorker 34/60 concern is retained as provenance. This task names that original as one of its two complete source acquisitions.
