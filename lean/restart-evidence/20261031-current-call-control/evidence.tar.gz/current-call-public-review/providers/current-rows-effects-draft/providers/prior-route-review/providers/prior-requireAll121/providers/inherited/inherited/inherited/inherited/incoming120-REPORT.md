# Actual incoming Some/Some result

The final source-only draft is SourceCurrentAllocatedFiniteOrdinaryIncomingResult-v2-UNCOMPILED.lean.
It has 120 lines. Its SHA256 is
3912d9d66cad22b1f63e37be6501e9e9008bccd683ff1a22957f124b8c7e9715.
It contains two public laws and one private finish helper. No compiler or
execution ran. The imported 112-line result producer remains an exact pinned
source-only dependency until Root checks it.

## Actual source route

EnumerationState.Graph at EnumerationState.lean51-53 has a pure Nat-to-Nat
intersect field. EnumerationBuilderRuntime.graph at lines 265-268 fills that field
with its supplied meet argument. These definitions do not produce an actual
native query endpoint. Root corrected this target at 05:47 CET. The draft uses
SourcePruningEnumerationIncomingNode.run instead.

The actual stateful path finds the representative, reads the representative's
current unenumerated Some old handle, physically decodes that handle, and runs
SourceEqualityNativeDemand.execute on requestNode emptyDomain incoming old.
The checkEmpty=false successful branch retains queried.state, encodes the
query value, and passes the actual handle to finish. Its caller is the actual
Caller.advance of queried.state. No abstract Graph field is used as native code.

## Public laws

initial_caller_stored derives native Stored for the literal
SourceCurrentAllocatedPartialInitialization.caller width cache heap. The
interned source heap is the arbitrary supplied heap. Actual native thunk tables
start empty. This law does not require an empty source heap or a supplied Stored
certificate. It does not establish all other caller-admission conditions.

some_some_result takes the CURRENT Context, PendingRealized, incoming
Available/closed, ordinary Node for both actual operands, Fits/Room, and native
Stored. It also takes the actual current findRoot result, the actual Some old
slot read, and the current old-handle physical lookup. These local observations
select the Some/Some branch. There is no future execution result, receipt, trace,
postcondition, success, output certificate, or completion premise.

PendingRealized derives old Available and old closedness from the actual slot.
Physical lookup uniqueness identifies that old node with the decoded operand.
Fits.room supplies all three current raw-execute resource bounds. For an actual
raw .done, raw_done_caller_initial derives the actual QueryReceipt and Post
internally from Context, operand admission, current bounds, and the observed
execute equation. The pinned 112-line receipt_result then derives ordinary result,
both operand height bounds, physical result encoding/lookup, and queried Stored.
The existing checked incoming_run_stored retains native Stored at the exposed
caller for every outcome of this selected call. Native Stored is the finite
ordinary native-table predicate. It is not inferred from arbitrary Ready/At or
from a different merge memo predicate.

If the actual return is .ok(some rows), the conclusion provides query and handle,
recursive ordinary Node query, height(query)<=height(incoming),
height(query)<=height(old), encodeNode query=some handle, and literal lookup at
the actual returned caller heap. Thus any shared input height cap also bounds
this result by transitivity. Every returned successful Core row has that exact
Some handle at found.representative with incomingScs++oldScs. The representative
slot bound follows from its actual successful getElem? read. The private helper
reduces the literal setValue and inheritAncestry operations. It requires no
StorageValid, all-slot nonterminal condition, or future Core invariant.

## Exposed outcomes and exact limits

The main law fixes checkEmpty=false. Fuels r/n/p/h remain supplied. The actual
findRoot=some observation is an entry premise; this is not a proof that any
original representative fuel suffices. Native query fuel n is arbitrary: a
non-done outcome receives no result-handle claim. Every exposed caller still
has the native Stored conclusion under the stated current gates.

finish rejects an empty query by returning no Core rows. A successful handle
classification for .ok(some []) therefore does not assert a successful slot
write or a nonempty result language. The Core-write statement quantifies only
over actual returned successful rows. For .error or .ok none, the handle/Core
part is True. This proves no handle fact, hidden-state fact, or Core existence
for those branches. No discarded caller from an enclosing wrapper is modeled.

The law does not cover checkEmpty=true handle retention, the None-fill branch,
other current slot kinds, or the missing-current-read cases as a result
classifier. It does not establish a whole-cache KnownOrdinary invariant,
future slot admission, alias/terminal progress, captured sibling restoration,
Native/Prepared worker termination, original sufficient depth, finite ordered
prefix completeness, or public/Haskell correspondence. The current Context,
PendingRealized, ordinary operand facts, Fits/Room and native Stored still need
actual outer-worker maintenance. Warm native Stored is not derived from an
arbitrary weak Ready/At state. No new Haskell defect or fix is established.

## Source and provider scope

There are 32 source acquisition records across 18 ORIGINAL paths. Exactly TWO
OLD whole/near-whole paths are used: private 112-line V2 SHA 19ce4d1b72374516495c3e4255e90287c5a4e7c55ed5a6da402be7c20019a583,
and actual IncomingNode, 296 lines SHA ff3a4fa83ad6f3368a1141cf6b908f5d1e5a56d500b4efc3c480d2b263b508c4.
Every other source read is a named bounded cut or declaration locator. Exact
source full hashes, sizes, line counts, copy hashes, ranges, locator lines and
cumulative original-path unions are retained. Metadata, range bytes, and
locator contents verify with no differences at freeze preparation.

The private 112-line provider's manifest/pins/report/entry-boundary/acquisitions/unions/
source verification/versions/incidents/scope metadata are copied unchanged.
Its frozen manifest SHA is 45d2a2b678c08eb46bcdf71a50730626df10a7282ed7d3071ede885d86e14c98;
its pins SHA is f190c5291e7c9c3074215c464917bad70b2a40753018db6495e3355ba2e44b34.
No other source body from that provider is reused in this task. Named imports
refer to library APIs. They do not assert that all imported bodies were read
again here. Root owns serial strict/default checks, any proof repair, module
installation, full Audit/public validation, commits and publication.
