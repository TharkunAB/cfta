# Discovery ledger

Declaration and exact-match locators are retained in LOCATOR-LEDGER.json and cuts/locators-*.txt. The same matched lines were replayed for retention. No broader body was read during that retention step.

One filename-only discovery used rg --files lean/MicroCFTA -g '*.lean' -g '!restart-evidence/**', filtered for Native physical/trace/effects/prefix/Stored/complete/semantic names, Raw Native names, and DemandTarget Worker names. It returned file paths only. No restart-evidence source body was read.

Additional call-site searches used SourceCurrent*.lean and SourceEquality*Worker*.lean, then current conjunction/physical globs. Positive SharedTarget/ClassFold call locators are retained with exact source pins. The current failed-check route was then read through named bounded cuts.

The initial memory registry keyword search used mcfta, execution.path.control, and26b76c6f. Historical line536 supplied proof-boundary guidance only. No rollout or memory skill was opened. No current proof status was inferred from memory.
