# Retained source-only drafts

All versions remain UNCOMPILED. No proof execution ran.

V1: 179 lines, 11874 bytes, SHA256
8f667ac5afadc7e0a27c05d6e97f22ee1721bcef6c3b606e94e691654b8ef691.
It contains the complete all-branch actual IncomingNode.run Known maintenance
proof and a literal finish/member split helper.

V2: 179 lines, 11873 bytes, SHA256
6ab4bb067406e8ae194ddf8860db7e8994ccfe45a4b058b96afc356d39f83e86.
It moves the theorem documentation inside the open scoped Classical command
and removes the leading theorem indentation. The public contract/proof are
otherwise unchanged. This is source preflight, not a compiler repair.

Root must check scoped Classical elaboration, match/let/generalize reductions,
the actual Some slot equations, literal finish reduction and both answer cases.
No kernel result is claimed for any candidate.

V3: 179 lines, 11890 bytes, SHA256
41a44af68ef781ca08782f3e2e952109d5c1ffe5e40c81df3cc50cd9f660e9d2.
It permits arbitrary actual endpoint queries, rather than fixing the run argument
to Context memos.query. No new gate is added. The physical query/check producer
proofs still use the current Context memos. The pure endpoint guard only selects
the actual check phase. All branches remain covered.
