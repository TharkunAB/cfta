# Required-path physical closure

Status: SOURCE-ONLY UNCOMPILED FUTURE R20. The final candidate is `SourceEqualityRequiredWorkerEffects-v2-UNCOMPILED.lean`. It has 209 lines and 15967 bytes. Its SHA256 is `9f382dd6f84adffac569d36ae1899d98a704e582d4de1830b8dd1bf13fd79488`.

The complete proof draft implements actual `require_effects`. Its current inputs are `SemanticHeap`, `Covered []`, query availability, and query closure. Fuel, read fuel, and Needed are arbitrary. It has no public future result, trace, effect, lookup, or semantic postcondition supplier. It has no `Ready.depth` input. Scoped Classical supplies proof-only decisions without a public equality-instance premise.

Each actual result exposes a heap that retains `SemanticHeap`, `Covered []`, physical `Grows`, and issued-history `Extends`. A completed value is available in that same heap and has no free references. These statements are uncompiled proposals with complete source proof bodies. They are not checked claims.

The proof follows actual control:

- Fuel zero retains the worker-exhausted state.
- Empty Needed returns the current value before inspecting its shape.
- Each child lookup follows its actual None or Some result. An unchanged earlier child is carried through later sibling effects.
- Each row follows the actual `fits` test. A rejected row does no child or constructor work. An accepted row uses actual child results, then actual `makeEdge` and `makeNode` requests.
- Mu and Union execute actual `head`. Recursion occurs only after `.done`. Pending, unresolved, head-exhausted, and worker-exhausted results retain their actual reached heaps.

The new local equality `head_eq_forest` identifies actual `head fuel query before` with actual `forest 0 fuel [] [query] before`, including every outcome. The singleton reader adds only an empty tail and `edges ++ []`. Thus `head_verified` uses the checked public `forest_effects` producer. It does not assume a future head certificate or duplicate the cold exposure induction.

The remaining primitive proofs use bounded public `SourceEqualityRequiredCache` source cuts. They obtain semantic, coverage, growth, history, exact edge children, availability, and closure from actual constructor producers. They omit the separate depth component of the older `Keeps` API.

The private proof record and list-carry lemmas are local proof machinery. Actual recursive calls are fixed to smaller-fuel `require`. The smaller-call premise is supplied only by internal fuel induction. The public theorem accepts no arbitrary callback or transition supplier. No successful stability theorem was used to assume future completion.

## Checked dependency and current candidate

Root reported at 09:04 CET that normalized `SourceEqualityProjectionWorkerEffects.lean`, 225 lines, SHA256 `8ff865b0ae105396936c4c2ce139f60447d63cfff025acfba7763fe204d8ddc5`, passed final default and strict checks. Its public project and forest API was acquired through bounded cuts. The source hash matches that checked pin.

The normalized physical helper is 149 lines, SHA256 `fc822fb9dfa82fee735de9578f4b44115df1907b95cb2ac39e237136efff69ad`. Only public declaration and notation context was acquired from it. The new proof does not call a private helper from either module.

The old frozen project219 provider retains its historical UNCOMPILED label. The new require209 is also UNCOMPILED. Neither source snapshot is silently relabeled as the normalized checked module. Root's report of R19's six checked production modules and final Audit/public results is retained in `ROOT-STATUS.md`.

## Exact remaining boundary

The actual internal required child and row recursions are covered by this proof draft. The actual `SourceEqualityRequiredExecution.requireAll` entry still needs its closed list-result companion. The next header is retained in `NEXT-REQUIREALL-CONTRACT.lean.txt` and is not a proof.

The constraint-class fold, the outer conjunction rows and decision workers, and the final call wrapper must then derive physical retention on their actual failed results. The original `failed_call_lookup` remains open. No supplied successful `Post`, failed outcome, `Keeps`, or lookup transport replaces that missing producer.

No ordinary-only or all-slot condition was added. Original Mu, Union, and opaque inputs remain in scope. This local draft does not prove sufficient original resources, Native or Prepared whole-worker progress, captured sibling restoration, terminal and alias maintenance, global finite requested-prefix coverage under the configured policy, public-adapter correctness, or Haskell correspondence. No Haskell defect or fix was established.

## Source controls and retained incidents

Two OLD whole originals were named before acquisition: `SourceEqualityRequiredWorker.lean` and `SourceEqualityRequiredWorkerStability.lean`. All other source reads have exact bounded ranges or declaration line vectors, full source hashes, and copy hashes. The prior provider document and metadata closure is complete. No old Lean proof body was copied through that closure.

Two guessed RequiredCache ranges returned `node_ordinary` and `constructed` instead of the intended edge or residency material. Their 25 lines remain retained and explicitly unused. Correct source was then located by declaration lines. Their source notes remain in the acquisition ledger. No source cut is omitted. The cumulative RequiredCache union is reported explicitly in `ORIGINAL-FILE-UNIONS.json`.

No Nodes body was read or copied. The inherited 51-of-76-line source concern remains in `INHERITED-SCOPE.json` and the prior provider closure. No additional range was added to that original.

Only source reads, text writes, metadata calculations, and hash checks ran. No compiler, evaluator, native or Haskell process, Git command, network or board operation, production edit, or child task ran here.
