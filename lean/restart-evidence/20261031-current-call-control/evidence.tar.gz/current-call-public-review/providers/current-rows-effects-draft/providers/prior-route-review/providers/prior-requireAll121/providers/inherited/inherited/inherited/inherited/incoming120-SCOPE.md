# Actual incoming ordinary result

Started 2026-10-31 05:42 CET. SOURCE-ONLY R17. Root owns all execution.
Root clarified the actual target at 05:47 CET. The target is the stateful
SourcePruningEnumerationIncomingNode.run Some/Some branch. The pure
EnumerationState.Graph.intersect field is not a native query producer.

The draft uses checkEmpty=false. It classifies the actual returned handle and
every returned successful Core write. It retains physical lookup, recursive
ordinary Node, both input height bounds, and CURRENT native Stored.
No future QueryReceipt, Trace, MemoOrd, result certificate, or completion is an
input. Cold native Stored derives from the literal caller initializer. Warm
native Stored is an explicit maintained CURRENT invariant.

TWO OLD whole ORIGINAL paths are acquired. Slot 1 is the private 112-line V2 result
producer. Slot 2 is SourcePruningEnumerationIncomingNode.lean, 296 lines. All other
source acquisitions use named bounded cuts or declaration locators. The
original-path cumulative unions and complete private 112-line provider metadata are
retained. The private 112-line import is not assumed installed or checked.

No compiler, evaluator, native/Haskell execution, Git, network, board, production
edit, or spawn is permitted. Root owns all checks and installation. The draft
and this bundle are source-only evidence. Keep Native/Prepared outer workers,
failure states, terminal/alias work, arbitrary raw targets, whole-cache transport,
original sufficient resources, global progress, and Haskell correspondence open.
