# Draft versions

V1: 196 lines, 13236 bytes, SHA256 `1897863afee5b075eb5e2ca57146d822e91fc2dc72daebfb9863ee87177b6ced`. It implements the project contract with private current-effect proofs.

V2: 217 lines, 14677 bytes, SHA256 `c0b2a41c1a247b3f8960801c5939e18bd84e3491764b9909daa91dc695e8e710`. It adds the actual forest wrapper with the same current gates.

V3: 219 lines, 14781 bytes, SHA256 `d408ce1b79c746cd94e37dce358b8fee74785921008772c2dba2256506f7f2ac`. It makes the actual union and project-node definitions explicit before bind reasoning. This is the final candidate. It was sent to Root at 08:37 CET. Its bytes remain fixed.

All versions are source-only and uncompiled. The prior 145-line public helper is a separate retained provider. Root repairs to its implementation do not establish this new candidate.
