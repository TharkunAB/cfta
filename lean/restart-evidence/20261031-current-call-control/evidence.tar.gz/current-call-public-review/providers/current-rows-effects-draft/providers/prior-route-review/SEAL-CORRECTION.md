# Seal correction

Root found two files absent from the first root manifest. Both files were preserved metadata from the prior provider:

- providers/prior-requireAll121/FROZEN-PINS.txt
- providers/prior-requireAll121/MANIFEST.json

The manifest script excluded matching basenames at every directory level. It should have excluded only the two root seal paths. No source payload was missing or changed. No evidence was removed.

The first root manifest and pins remain byte exact in superseded-seals/. The replacement manifest covers every regular file except the two root seal paths. This correction is authorized by Root10:02.
