# Actual incoming result with either empty-check flag

The final source-only draft is
SourceCurrentAllocatedFiniteOrdinaryIncomingCheckedResult-v3-UNCOMPILED.lean.
It has 145 lines and 9765 bytes. Its SHA256 is
48f132ae424eaa052c333cdc80d028d1fc3bcf6600a6325303e4f780b5d8be5a.
It has one public generalized law and one private finish helper. No compiler,
evaluator, native/Haskell execution, Git, network, board, production edit or
spawn ran. Root owns all proof checks and installation.

## Current entry gates and conclusion

some_some_result generalizes the exact frozen 120-line Some/Some statement to any
checkEmpty Bool. Current Context, PendingRealized, incoming Available/closed,
ordinary Node for both actual operands, Fits/Room, native Stored, actual current
findRoot result, actual Some old slot, and actual old physical lookup remain.
It adds no public semantic/resource gate. Following Root's strict-check
feedback, V3 drops the proof-only public DecidableEq Node assumption and uses
classical inside the proof. The original EdgeKey instance remains.

Every exposed caller retains native Stored. On actual .ok(some rows), the law
provides an encoded ordinary replacement and literal physical lookup at the
actual returned caller heap. Replacement height is at most each input height.
Every returned successful Core row writes that exact Some handle and the exact
incomingScs++oldScs at found.representative. Existential query in the public
statement denotes this encoded replacement. It can be Empty after a true answer.

The private finish helper copies the literal source setValue/inheritAncestry
reduction. It uses the representative-slot bound from the actual current read.
No StorageValid, nonterminal-only cache condition, all-slot supplier or future
Core postcondition is added. The literal cold initial_caller_stored helper
remains in the imported false-result module. It derives native Stored for the
actual initializer over a supplied physical heap. This generalization does
not add a cold Stored input.

## Actual enabled-empty transport

The true branch can run physical work, update memos and fail. It does more than
an empty rejection at the operational level. SourcePruningEnumerationEnabledEmpty.check
first runs the pure endpoint-memo guard. A false guard retains queried state.
A true guard invokes SourceCurrentAllocatedConjunctionWorker.call p h 1000.
That wrapper lifts the actual physical reached heap with advancePhysical.
Native Stored alone does not give physical query-handle lookup at that heap.

The draft derives the missing lookup transport from actual source producers:

1. At an observed actual native .done, raw_done_caller_initial derives the
   QueryReceipt and caller Post internally from the CURRENT entry gates and
   Fits.room's three current numeric bounds. The existing receipt_result gives
   ordinary query, both height bounds, encoding and physical query lookup.
2. The draft cases the actual selected phase. On observed successful physical
   check, AllocatedConjunctionWorker.call_done exposes its actual physical call
   and literal advancePhysical endpoint. WorkerCompletion.call_sound derives
   the actual Call relation from that observed equation.
3. ConjunctionCaller.actual consumes this internally derived Call,
   queryPost.context and receipt.available. It produces the actual caller Post.
   Its effects.keeps supplies physical old-handle retention. lookupNode_keeps
   carries the original query lookup to the returned checked heap.
4. For disabled checking or a false endpoint guard, actual success retains
   queried state. For answer=false, the encoded replacement is the ordinary
   query. For answer=true, it is Empty at handle 0, with height 0 and literal
   lookup at every physical heap.

Thus the new phase proof adds no supplied future Receipt, Post, Call, Trace,
Ready, result invariant, success, completion or memo certificate. The query's
current readiness/availability for the enabled caller derive from the actual
raw query producer. Current native Stored remains the maintained finite
ordinary native-table predicate. It is not inferred from arbitrary Ready/At.
The actual endpoint memo output is threaded by source code. No correspondence
between a supplied pure Graph.intersect and the native call is asserted.

## Outcomes and remaining boundary

r/n/p/h are supplied fuels. The public current findRoot=some observation selects
the actual Some/Some branch. This does not prove that original resources make
that observation or any native/check success occur. A failed native/check phase
has no returned-handle/Core claim. Its actual exposed caller still has Stored.
The phase classified by this law uses the actual returned checked state.

Empty rejection returns no Core rows. The universal slot statement claims only
actual successful returned Core rows. It establishes no Core existence or hidden
state fact for an absent Core, error, unhandled or none wrapper. It does not turn
an empty language into a failed requested-prefix guarantee.

The None-fill branch and other slot kinds are not classified here. Whole
returned-cache KnownOrdinary preservation, new current entry admission,
terminal/alias work, captured sibling restoration, Native/Prepared outer-worker
progress, original sufficient resources, finite ordered public prefix
completeness and Haskell correspondence remain open. The next local step is
whole-cache preservation from this actual new-slot result, actual other-slot
retention and physical old-handle effects. This draft does not supply that step.
No new Haskell defect or fix is established.

## Check status and source scope

At assignment Root reported TargetResult111 default+strict PASS. At06:23 Root
reported false-result kernel/default PASS after adding reduceCtorEq and
reduceIte before its encoded rewrite. Strict then rejected its proof-only
DecidableEq Node assumption. Root removed that assumption, added classical,
and was retrying. These are Root message reports. No checked source body is
silently substituted for the exact frozen 120-line baseline in this owner. V3 copies
those source controls. The generalized 145-line source is UNCOMPILED.

There are 30 acquisition records across 15 ORIGINAL paths. Exactly TWO OLD
whole/near-whole originals are used: the immutable 120-line false draft and actual
IncomingNode, 296 lines. All other source acquisitions use named bounded cuts or
locators. The largest other cumulative union is 46/77 lines of
SourceCurrentAllocatedTargetCallerObserved. All exact unions are retained.
Source full hashes/sizes/line counts, range bytes, locator contents and copy
hashes verify without differences. The 22 copied provider metadata payloads
also verify byte-exact against their immutable sources. No additional ancestor
proof body is copied. All provider manifests and pins remain available in the
complete metadata closure. Root owns serial strict/default and full validation.
