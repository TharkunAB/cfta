# Incidents and scope controls

No compiler or evaluator attempt ran. No source acquisition failed. There is no discarded semantic payload or omitted proof failure.

V1 contains the project closure draft. V2 adds the actual forest wrapper. V3 makes unfolding explicit at the actual union and project-node bind sites. All three versions remain complete and uncompiled.

The inherited Nodes 51/76 concern is retained as provider provenance. No Nodes body was read or copied in this fresh task. No source range was added to that original.

Root's separate physical-helper default failure is recorded in `ROOT-STATUS.md`. This is external probe evidence. It is not a probe of the new candidate.
