# Whole known cache after actual incoming calls

Final source-only candidate:
SourceCurrentAllocatedNativeIncomingKnown-v3-UNCOMPILED.lean.
179 lines, 11890 bytes, SHA256
41a44af68ef781ca08782f3e2e952109d5c1ffe5e40c81df3cc50cd9f660e9d2.
It contains one public run_known law and one private finish_known helper.
No compiler, evaluator, native/Haskell execution, Git, network, board,
production edit or spawn ran. Root owns checking and installation.

## Actual top-level contract

run_known uses the real SourcePruningEnumerationIncomingNode.run with arbitrary
checkEmpty and representative/native/p/h fuels. It takes the current Context,
PendingRealized, incoming Available/closed, incoming recursive ordinary Node,
incoming height at most bound, current whole KnownOrdinary at the same bound,
Fits/Room, and CURRENT native Stored. The actual supplied endpoint queries are arbitrary current data. The Context
memos remain the query/physical proof environment. No endpoint-memo validity
gate is added. It adds no public find result, slot read,
old-node decode/domain certificate, successful outcome, query/check receipt,
Post, Call, heap transport or future invariant supplier.

The conclusion retains native Stored at every actual exposed caller. For each
actual .ok(some rows), every returned successful Unit/Core row has whole
KnownOrdinary at the actual returned caller heap and the same original bound.
The typed cached record is {before with core:=returnedCore}. Its flags are the
original flags solely to form a Cached value. KnownOrdinary reads only core.values.
The statement makes no claim that an outer actual adapter keeps flags unchanged.
It has no Core or hidden-state claim when a successful Core is absent.

No public Node equality premise is added. open scoped Classical covers the
theorem statement, following Root's checked IncomingResult121 control. Classical
reasoning inside the proof also supports local case/equality steps. The
original EdgeKey instance and current semantic/resource gates remain.

## Derived producer edges

The proof cases the actual findRoot result, current slot lookup, actual slot
constructor and optional old handle. No branch observation is an entry gate.
Representative compression changes the forest and retains values. The local
read cached value therefore derives Known directly from current Known.

In the None old-handle branch, Available/closed and current ready coherence give
actual encode/physical readback of incoming. The source retains beforeCaller.
Incoming's supplied current Node and height bound give the new-slot certificate.

In the Some old-handle branch, PendingRealized gives the actual old decode,
Available and closedness from the actual slot. List.mem_of_getElem? puts that
slot's value in the original value list. Current Known gives its decoded
ordinary value and shared bound. Physical lookup uniqueness identifies that
value with the actual old operand. Old ordinary is therefore derived internally.

Fits.room gives all three current native bounds. On an actual raw .done,
raw_done_caller_initial derives the actual QueryReceipt and caller Post.
The checked receipt_result supplies recursive ordinary query, both input height
bounds, and actual encoded-handle lookup. KnownHeap.query_known transports all
old handles to queried state through the actual receipt.effects.keeps.

The proof then cases the actual enabled/disabled phase. For actual successful
physical checking, AllocatedConjunctionWorker.call_done exposes the actual
physical call and advancePhysical endpoint. WorkerCompletion.call_sound derives
the Call relation. ConjunctionCaller.actual consumes that derived relation,
queryPost.context and receipt.available. Its actual Post supplies old-cache
transport via KnownHeap.post_known and physical query-handle retention via
lookupNode_keeps. Disabled checking and a false endpoint guard retain queried.
A false answer keeps the ordinary query, whose height is bounded by incoming
and thus bound. A true answer selects Empty/0 with height 0 and literal lookup.
No future check Context or other admission is supplied.

The private finish_known helper reduces the literal source finish operations.
A returned successful row equals the exact value-list set and ancestry update.
List.mem_or_eq_of_mem_set splits each actual returned known-handle membership:
an old member uses transported current Known; the new member uses the internally
constructed new-slot certificate. This derives all old-row/new-row obligations.
The helper's certificate argument is private support. The public top producer
derives it for every actual positive branch. It does not take it as a future gate.

## Full branch boundary

Representative-fuel failure and missing slot return their actual error rows.
Enumerated and eliminated slots return invalidIntersection error rows. The proof
handles them without requiring a cache-wide nonterminal condition. There are no
returned successful Core rows in those cases. None-fill and Some/Some use their
literal source branches. The latter's physically missing old lookup is excluded
by current PendingRealized for the actual Some slot, not by a new hypothesis.
The None-fill encode succeeds by actual Available readback, also internally.

Raw native non-done outcomes and check failure expose their actual caller with
native Stored and no returned Core claim. Empty replacement rejects to no Core
rows. The universal Known statement therefore does not assert a write, a Core
existence, a completed enumeration or a nonempty language there. No hidden state
from an enclosing unhandled/none wrapper is exposed or certified.

## Initialization and limits

Warm native Stored is a maintained CURRENT native-table predicate. It is not
inferred from arbitrary Ready/At or merge memo Stored. Cold known and cold native
Stored already have actual producers: SourceSizedPrefixKnownOrdinary.initial_packet_known
and SourceCurrentAllocatedFiniteOrdinaryIncomingResult.initial_caller_stored.
The first uses the same original product root/heap/bound/startup; the second uses
the literal native initialization over its supplied heap. No new cold supplier
is needed. This candidate focuses on maintenance after that current entry.

This is not a whole-worker invariant or progress theorem. It does not close
other cache operations, terminal/alias work, selected-child admission, captured
sibling restoration, Native/Prepared loops, sufficient original resources,
finite ordered requested-prefix completeness, public/Haskell correspondence or
literal runtime reification. Current Context, PendingRealized, Fits/Room and
Stored still require actual outer-caller maintenance. No new Haskell defect or
fix is established. The pure Graph.intersect interface is not used as a native
query producer.

## Source and check status

Root reported IncomingResult121 default+strict PASS at 06:30 and was starting
Audit/public of seven modules. Root reported TargetResult111 checked earlier.
These are Root message reports. This 179-line candidate is UNCOMPILED. It imports no
uncompiled Bool145 or None92 module. A named 31-line cut of frozen Bool145 V3 is
retained as the exact phase-proof source reuse. None92 is not acquired or used.

There are 21 acquisition records across 15 ORIGINAL paths, including the matching
Lean 4.34.1 standard-library membership lemma. Exactly TWO OLD whole originals
are used: installed SourceSizedPrefixKnownOrdinary, 110 lines SHA
3accfc1bd3d6c97c1fbe3af317fd87751d7990e1e1fcb90135eaf878cbb98cbe,
and actual IncomingNode, 296 lines SHA
ff3a4fa83ad6f3368a1141cf6b908f5d1e5a56d500b4efc3c480d2b263b508c4.
All other acquisitions are named bounded cuts or locators. The largest other
line union is 36/96 lines of KnownOrdinaryHeap. All exact original-path unions,
source full hashes/sizes/line counts, range bytes, locator contents and copy
hashes are retained and verify with no differences. The 35 copied provider
metadata payloads are byte-exact. No additional ancestor proof body is copied.
Root owns serial strict/default checks, repairs, full validation and publication.
