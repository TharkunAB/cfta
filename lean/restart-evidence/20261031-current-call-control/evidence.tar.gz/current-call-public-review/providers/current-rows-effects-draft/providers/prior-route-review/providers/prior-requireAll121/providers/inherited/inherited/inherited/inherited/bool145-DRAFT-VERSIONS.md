# Retained source-only versions

All versions are UNCOMPILED. No Lean evaluator/compiler ran in this owner.

V1: 144 lines, 9748 bytes, SHA256
2eef85fd6a56004fc5d54290a03b8a7622a78ab43f39dfe10706042a6bc66b95.
This first generalizes the Bool and derives actual enabled-check lookup via
call_done, call_sound, ConjunctionCaller.actual and lookupNode_keeps.

V2: 144 lines, 9758 bytes, SHA256
1651e1c71af782427e0fe009fcee93940b2acbaa673b0868cb2f63210f1699e2.
It prefixes unused phase-query/failed-outcome/final-memo binders. The public
header and proof structure remain unchanged.

V3: 145 lines, 9765 bytes, SHA256
48f132ae424eaa052c333cdc80d028d1fc3bcf6600a6325303e4f780b5d8be5a.
It follows Root's 06:23 false-law preflight feedback. It removes public
DecidableEq Node, adds classical in the proof, and adds reduceCtorEq before the
false-answer encoded rewrite. The Bool/current semantic/resource gates remain.

Root must check match/let/generalize reductions, the proof-only instance
removal and both answer branches. No generalized typing result is claimed.
