# Draft versions

V1 is retained unchanged. V2 replaces explicit endpoint names with inferred
arguments under dependent Step.run elimination. Public statements are identical.
All versions remain UNCOMPILED.

V1: 112 lines, 8301 bytes, SHA256 04db57b3440bf518f499e28f21b2772aa0e798c1431e2a9bad4b442a0ab0abb2.

V2: 112 lines, 8288 bytes, SHA256 19ce4d1b72374516495c3e4255e90287c5a4e7c55ed5a6da402be7c20019a583.

