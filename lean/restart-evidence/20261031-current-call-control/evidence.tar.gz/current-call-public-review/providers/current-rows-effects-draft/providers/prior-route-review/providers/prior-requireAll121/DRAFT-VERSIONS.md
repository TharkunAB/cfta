# Draft versions

V1: 121 lines, 7898 bytes, SHA256 `400e78d42f3ed1960bc2f1fa04db3a10fdbbeb74513b98b69e05292236310346`. This is the initial complete list-entry draft. Its require dependency was proposed at creation.

V2: 121 lines, 7937 bytes, SHA256 `7fa43d3550ba56df5975bb3045779ff84c7fe4fffa707af2e08a458aed1b96f5`. This is the final candidate. It explicitly substitutes the child in cons cases and unfolds ValuePost when consuming the public require finish. These controls follow Root's reported normalization repairs. It was sent to Root at 09:41 CET and remains byte exact.

Both candidates remain uncompiled. Normalized require210 is separately checked, with public API source SHA256 `50c7fa76998aaf81d9543700e61c6c05141cdb3792261e01877a4298d7011dcd`. The old require209 provider remains unchanged. No private require, project, or physical helper is called. The next-contract documents are explicitly unproved scope records.

The candidate files retain the initial dependency-status comment. Current checked210 status is recorded above and in ROOT-STATUS.md. The candidate itself remains uncompiled.
