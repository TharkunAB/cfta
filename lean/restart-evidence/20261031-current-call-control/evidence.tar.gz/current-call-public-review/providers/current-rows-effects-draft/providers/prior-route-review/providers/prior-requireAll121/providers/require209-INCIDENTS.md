# Retained incidents

1. The named RequiredCache cut 73–89 was intended to show edge construction. It contains `node_ordinary`. All 17 lines remain retained. The proof does not use that cut.
2. The named RequiredCache cut 45–52 was intended to identify edge residency. It contains the `constructed` producer. All eight lines remain retained. The proof does not use that cut.
3. A declaration locator identified the actual public edge producer at line 53. Its exact 53–70 cut was then acquired. The proof uses singleton `Edges` and `ClosedEdges`; it needs no new residency-definition assumption.

The acquisition ledger preserves original cut names and adds explicit scope notes. The cumulative original-path union includes both unused ranges. No data was deleted or concealed. There was no third whole-file acquisition.

No compiler or evaluator attempt ran. There is no omitted compiler failure. Old frozen providers remain unchanged. No Nodes body was acquired or reused directly.
