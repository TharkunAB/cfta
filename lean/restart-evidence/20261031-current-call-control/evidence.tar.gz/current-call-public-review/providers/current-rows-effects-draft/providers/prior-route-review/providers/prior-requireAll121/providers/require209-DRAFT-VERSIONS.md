# Draft versions

V1: 208 lines, 15967 bytes, SHA256 `fe162d4e3254b95cfbd13ed04087e92042e857ac8e44e7d7655bbe4a669529c2`. It contains the full actual require induction and public contract.

V2: 209 lines, 15967 bytes, SHA256 `9f382dd6f84adffac569d36ae1899d98a704e582d4de1830b8dd1bf13fd79488`. It gives the reference branch a separate tactic block. This is the final source-only candidate. It was sent to Root at 09:07 CET and remains byte exact.

Both versions are complete uncompiled drafts. Scoped Classical removes proof-only public equality-instance gates. Guard parameters in the private postconditions are explicit. The public final match uses `generalizing := false`, as Root's prior checked normalization requires.
