# Root scope response

Root message, 2026-10-31 08:13 CET:

> Retain the exact51/76 Nodes union and explicit scope incident; do not acquire/reuse any further body from that original. Root will report the67% union as a scope concern rather than silently call it a narrow signature-only acquisition. It is not a third complete file, but your extra encode/preamble cut was unnecessary. Continue from the acquired data within the named2wholes and freeze all vectors. The growth/history-only observation is useful: prefer the smallest actual all-outcome producer, with existing Verified supplying those fields internally; no Ready.depth or future Keeps premise. No production/check execution. R18 remains closed5; this is future evidence.

No additional body from `SourcePruningEnumerationNodes.lean` was acquired or reused after this message. The existing retained cut supplied the private lookup proof.
