# Incidents

The first declaration locator included the guessed SourceCurrentAllocatedKnownOrdinary.lean path. That path does not exist. The locator returned exit 2. No source body was acquired from that path. The actual Known provider will be identified from checked API opens.

The initial SharedTargetState named cut107–124 is a source locator, not a claimed advance definition. Any irrelevant acquired lines remain in provenance and cumulative source vectors.

Inherited concerns remain in SCOPE.md. No execution or production edits occur in this task.

The actual-route cut script first requested RowsWorker113–124. The file has119 lines. Its pre-copy assertion failed before acquiring that cut. The previous three exact cuts had already been copied. Their records were recovered from the same original paths/ranges, and their existing bytes were verified before serialization. The corrected rows cut is113–119. No payload was discarded.

A declaration locator also included the guessed SourceRecursiveIntersectionNativeComplete.lean path. It does not exist. The locator returned exit2. No body was acquired from that path.

The SharedTargetState107–124 cut acquired an existing Ready.store proof before the advance locator was corrected. It was unnecessary for the final route correction. Its exact bytes and vectors remain retained. The warm-complete46–63 cut includes two proof lines62–63. They are not treated as header-only acquisition.

No proof approach was evaluated. The proposed raw/checked endpoint substitution was rejected by source inspection. The later actual-route test rejected use of the SharedTarget/ClassFold route for current failed_call_lookup. No runtime counterexample or Haskell defect was established.

Additional scope concern: the repeated current rows branch/declaration locators plus named body cuts cover77/119 original lines. NativeDemand covers86/160, SharedTargetState59/124, and CurrentConjunctionWorker54/108. Exact body/locator overlap and vectors are retained. These are not described as narrow signature-only acquisitions. The rows branch locator was unnecessary for the final route correction. No further source expansion follows.
