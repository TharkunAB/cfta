# Retained source-only versions

V1: 147 lines, 10300 bytes, SHA256
ce1db53ce2fc169538e4e7e88429877b29aa31cf67cc9bd92512ca00b0b4548d.
It proves source draft native-prefix Known plus old-cache Known on all outer .ok
returns, including empty rejection/no Core. All outer errors are unclaimed.

V2: 150 lines, 10580 bytes, SHA256
9ec62f58e4a1dc868a5ff8f696f0a702d9239b2e6985fa56792c47e68a71a372.
It strengthens the main conclusion to cover native outer errors as well, using
the internally derived actual-prefix Known result. Its explicit sole exception
is outer .error(.inr physical check). No new gate is added. Native Stored remains
proved in the source draft for every exposed caller.

Both versions are UNCOMPILED. No typing/kernel result is claimed. Root must
check inferred root Fields, actual prefix rewriting, match/generalize reductions
and dependent outcome binders. The missing failure header has no proof body.
