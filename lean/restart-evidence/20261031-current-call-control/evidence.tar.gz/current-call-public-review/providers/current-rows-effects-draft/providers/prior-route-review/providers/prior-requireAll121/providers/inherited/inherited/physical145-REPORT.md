# Failed physical lookup review

Status: SOURCE-ONLY FUTURE R19. No compiler or evaluator has checked this draft. R18 remains closed at five checked modules.

The complete candidate is `SourceEqualityProjectionWorkerPhysical-v2-UNCOMPILED.lean`. It has 145 lines. Its SHA256 is `c332808095bc6c21c3e7f4ca223a654f77f2d7d1cdaffc1083454e37bf0705a6`. V1 remains in this directory.

The candidate proves four local statements about the actual functions:

- `readAll_verified` derives the existing cold-reader `Verified` record for the actual projection `readAll` result.
- `readAll_lookup` retains the exact payload of every old physical node handle at the actual returned heap.
- `union_lookup` includes the actual `makeNode` call after the reader completes. It retains old physical payloads at every outcome.
- `head_lookup` covers the actual `SourceEqualityRequiredWorker.head`, including exhausted reads.

These are proposed statements with complete source proof bodies. They are not checked claims. All read fuels are allowed. Current inputs are `SemanticHeap`, `Covered []`, and availability and closure of the actual input values. There is no future outcome, trace, lookup-transport, or `Keeps` input. The actual `head` and projection-union results expose their physical heap in each constructor.

The proofs reuse `MergedFreshOrdinaryColdEffects.nodeEdges_verified`, `Verified.prepend`, and `Verified.extend`. The mandatory native cold-effect export was read first. That export already gives `Verified` for every bounded `nodeEdges` read at its returned native operand. The general cold-reader producer is the smaller direct dependency for this draft.

The private physical lookup proof uses only `Grows` and issued-history `Extends`. The existing `lookupNode_keeps` proof does not use its `Keeps.ready` field. Thus this support does not need to construct an additional `Ready.depth` certificate after an exhausted read. Primitive reconstruction obtains both fields from the actual `InternedNestedFacts.node_verified` producer. It does not accept them as future public inputs.

The `exposure` adapter preserves each reader payload and its physical heap. `MergedSourceExposure.Result` has no worker-limit tag. The adapter therefore removes that tag. The public lookup conclusions use `reached` on the actual worker result and do not claim an outcome-tag identity. No source caller is hidden by these result types.

The existing cold-reader producer includes Mu and Union exposure under its current semantic, coverage, availability, and closure gates. The new local laws do not add an ordinary-only or all-slot admission gate. The symbols are the concrete `SourcePruningTemplates.Symbol` used by `lookupNode`. Guards remain generic.

## Exact remaining work

The requested `failed_call_lookup` is NOT proved. Its exact prior header is retained in `providers/old-cache150-NEXT-MISSING-CONTRACT.lean.txt`.

The next smallest producer is actual `project` transport with current semantic and coverage preservation, growth, issued history, and availability and closure on a completed value. The proposed header is in `NEXT-PROJECT-CONTRACT.lean.txt`. It has no future supplier. The `rows` recursion must transport its remaining input edge certificates and earlier returned values through the actual recursive result. The current candidate packages the reader and reconstruction lookup part only. It does not package this full recursive postcondition.

The required-class fold, the rows worker, and the actual conjunction decision/call wrapper must then retain old physical lookups on their failed results. A successful-call `Post` does not establish this failed-result property. The current entry `Context` must supply the reader gates at the actual call sites. This review has not added a theorem that transports those gates through all these workers.

This leaves the failed physical-check route in the prior all-caller old-cache statement open. It also leaves original Mu/Union/opaque source coverage, terminal and alias work, new-slot preservation, captured sibling restoration, Native and Prepared whole-worker progress, and the original sufficient-resource requested-prefix theorem open. The full goal still includes both workers, public adapters, and Haskell correspondence.

No Haskell source or runtime was executed. No Haskell defect or fix was established. There is no new FINDINGS entry.

## Source controls

Two OLD whole files were named before acquisition: `SourceCurrentAllocatedConjunctionWorker.lean` and `SourceEqualityProjectionWorker.lean`. Every other source read has exact bounded ranges or declaration line vectors in `acquisitions.json`. `ORIGINAL-FILE-UNIONS.json` gives their cumulative unions.

The two `SourcePruningEnumerationNodes.lean` cuts cover 51 of 76 lines. The second cut included unneeded encoding and namespace text. Root accepted continued work from this acquired data at 08:13 CET, required that the 67 percent union remain an explicit scope concern, and forbade further source acquisition or reuse from that original. No later source body was read from it. This is not described as a narrow signature-only read. See `INCIDENTS.md`.

All 62 documents and metadata files from the prior provider closure were copied byte for byte. Their hashes and original locations are in `PROVIDER-REUSE.json`. No prior Lean proof body was copied through that closure. The complete prior manifests remain available for reconstruction. Direct source acquisitions and inherited document reuse are counted separately.

Only source reads, file writes, metadata calculations, and hash checks ran. No compiler, evaluator, native or Haskell process, Git command, network operation, board operation, production edit, or child task ran.
