# Actual incoming old-cache retention

Started 2026-10-31 07:18 CET. SOURCE-ONLY strengthening task.
Target: the OLD BEFORE Cached KnownOrdinary at every actual exposed caller heap,
including empty/error/rejection/absent Core paths. Keep existing current admission,
arbitrary checkEmpty/fuels/endpoint queries. Derive actual native/check physical
transport internally. No supplied future Post/Keeps/Trace/lookup/global invariant.
Separate useful theorem at most180 lines or exact obstruction. No hidden state
claim for endpoints not exposed by actual source.

OLD whole slot1 is SourceCurrentAllocatedNativeIncomingKnown.lean current180L,
explicitly UNCOMPILED while Root repairs. OLD whole slot2 is actual IncomingNode296L.
Each acquisition pins exact bytes. Later Root changes to the production180 source
must be recorded rather than silently replacing that snapshot. Other source uses
named bounded cuts/locators and cumulative ORIGINAL-path unions. Root owns all
compiler/evaluator/native/Haskell/Git/network/board/production actions. No spawning.
Preserve cold native Stored derivation, warm current maintenance, worker progress,
original capacity and Haskell boundaries. No new Haskell defect/fix is established.
