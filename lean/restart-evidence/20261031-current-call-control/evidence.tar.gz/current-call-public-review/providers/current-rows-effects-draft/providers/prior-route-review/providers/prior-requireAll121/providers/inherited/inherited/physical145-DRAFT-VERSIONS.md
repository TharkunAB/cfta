# Draft versions

V1: 144 lines, 8783 bytes, SHA256 `c7764172ed718e50715029fb3340ccba9f4153bac8f973a088c37bc586253b1d`. It imports the native cold-effect export through the first attempted dependency choice. It retains the first done-case proof spelling.

V2: 145 lines, 8933 bytes, SHA256 `c332808095bc6c21c3e7f4ca223a654f77f2d7d1cdaffc1083454e37bf0705a6`. This is the final candidate. It imports the directly used generic cold-effect module. Its done-case proof constructs the existing `nodeEdges_verified` theorem at the exact observed equation. This avoids relying on whether `cases` has already rewritten a prior local copy of that theorem.

Both versions are complete source-only proof drafts. Neither version was compiled or evaluated here. V2 was sent to Root at 08:19 CET and will remain byte exact.
