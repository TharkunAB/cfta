# Retained draft versions

Both versions are UNCOMPILED. No kernel/evaluator test ran in this owner.

V1: SourceCurrentAllocatedFiniteOrdinaryIncomingResult-v1-UNCOMPILED.lean.
115 lines, 7677 bytes, SHA256 5f65226e38bef62a69c23feca6e1f5061fadaac5a9c282d5c61be26b8c83a0c0.
This is the first actual incoming result/cache-write draft. It uses the literal
native Some/Some path rather than the pure Graph interface.

V2: SourceCurrentAllocatedFiniteOrdinaryIncomingResult-v2-UNCOMPILED.lean.
120 lines, 7990 bytes, SHA256 3912d9d66cad22b1f63e37be6501e9e9008bccd683ff1a22957f124b8c7e9715.
Public laws are unchanged. V2 removes an unused section width variable. It
copies the existing finish_complete constructor-specific match reductions so
that the empty case does not receive an unused reduceCtorEq simp argument.
This is a source preflight change. No compiler failure or repair is claimed.

The private helper may still need Lean match or projection simplification.
Root must check both the pinned 112-line dependency and this 120-line candidate.
