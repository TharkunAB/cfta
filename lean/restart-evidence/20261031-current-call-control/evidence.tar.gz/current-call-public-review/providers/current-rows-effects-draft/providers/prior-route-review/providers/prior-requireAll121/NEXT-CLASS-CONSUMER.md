# Exact next class consumer

The actual source call is:

```lean
SourceEqualityClassFoldWorker.classEdit
  emptyGuard conjoin clear top e p h c n record values before
```

Here `before : SourceRecursiveIntersectionThunks.State width Symbol Guard`, `record : SourceEqualityClassOrder.Record`, and `values : List (Value Symbol Guard)`. The literal body calls:

```lean
SourceEqualitySharedEditWorker.editAll
  emptyGuard conjoin clear top record values e p h c n
  (SourceEqualityClassEdits.edits record.paths id) values
  (SourceEqualitySharedTargetState.initial before)
```

The intended current entry has cold semantic and coverage facts at `before.machine.heap`, plus availability and closure of `values`. The initialized target map is literally None. Native memo families are retained. Their current admission has not been derived from these heap-only gates.

Required output on actual `.done results after` is semantic and coverage at `after.machine.heap`, growth and issued history from the entry heap, and availability and closure of `results`. Required incomplete output is physical retention at the actual nested observation endpoints. It is not enough to use the old outer SharedState.

For shared `.native other beforeShared`, the actual native endpoint is `other.state`. For shared `.target other beforeShared`, the demand-target observation still needs its exact endpoint transport. This task did not acquire that worker body and does not invent an endpoint accessor for it.

The concrete missing call inside shared `step` has the fully bounded open header in `NEXT-NATIVE-PHYSICAL-CONTRACT.lean.txt`. Target cache misses also need the actual demand-target producer. Target cache hits need an invariant derived from None initialization, actual stores, and actual native heap growth. None of these is supplied as a public future premise.

Once these actual producers exist, shared edit recursion and the finite class-list right fold can compose them. The final `pass` also applies literal empty propagation to the returned value list. Its value certificates must follow that actual function. No whole class, pass, or failed-call law is claimed here.
