#!/usr/bin/env python3
"""Check retained bytes and bounded source scopes. Do not run Lean or access original paths."""
from pathlib import Path
import hashlib
import json

P = Path(__file__).resolve().parent
ROOT_CONTROL = {Path('MANIFEST.json'), Path('PINS.json'), Path('FROZEN.json')}
def digest(data):
    return hashlib.sha256(data).hexdigest()
def checked(row, key='path'):
    relative = Path(row[key])
    assert not relative.is_absolute() and '..' not in relative.parts
    data = (P / relative).read_bytes()
    assert len(data) == row['bytes'], relative
    assert digest(data) == row['sha256'], relative
    return data

def sources():
    index = json.loads((P / 'source-index.json').read_text())
    seen = set()
    old_wholes = []
    totals = {'OLD': 0, 'NEW': 0}
    for row in index['sources']:
        assert row['source'] not in seen
        seen.add(row['source'])
        category = row['classification'].split()[0]
        if 'whole' in row:
            data = checked(row['whole'])
            assert len(data) == row['source_bytes']
            assert digest(data) == row['source_sha256']
            assert len(data.splitlines()) == row['source_lines']
            union = set(range(1, row['source_lines'] + 1))
            if category == 'OLD':
                old_wholes.append(Path(row['source']).name)
        else:
            recovered = {}
            for cut in row['cuts']:
                data = checked(cut)
                lines = data.splitlines(keepends=True)
                if cut.get('numbered'):
                    numbered = []
                    for line in lines:
                        number, literal = line.split(b':', 1)
                        numbered.append((int(number), literal))
                    assert [n for n, _ in numbered] == cut['actual_lines']
                else:
                    numbers = list(range(cut['first_line'], cut['last_line'] + 1))
                    assert len(lines) == len(numbers)
                    numbered = list(zip(numbers, lines))
                for number, line in numbered:
                    assert 1 <= number <= row['source_lines']
                    if number in recovered:
                        assert recovered[number] == line
                    recovered[number] = line
            union = set(recovered)
            assert 2 * len(union) < row['source_lines'], row['source']
        assert sorted(union) == row['reviewed_union_lines']
        totals[category] += len(union)
    assert sorted(old_wholes) == sorted(['SourceCurrentConjunctionDecisionSoundness.lean', 'SourceCurrentConjunctionWorker.lean'])
    assert totals == {'OLD': 415, 'NEW': 684}
    assert len(seen) == 16
    for row in json.loads((P / 'metadata/input-origins.json').read_text())['records']:
        checked(row, 'copy')
    attempts = 0
    failures = 0
    for report_path in sorted((P / 'metadata/checks').glob('*/report.json')):
        report = json.loads(report_path.read_text())
        raw = (report_path.parent / 'raw.log').read_bytes()
        assert len(raw) == report['bytes'] and digest(raw) == report['sha256']
        assert report['caps_verified_before_command'] is True
        assert report['cgroup_limits_before']['memory.max'] == '4294967296'
        assert report['cgroup_limits_before']['memory.swap.max'] == '0'
        assert report['cgroup_limits_before']['memory.high'] == '4294967296'
        if 'source_sha256' in report:
            module = report_path.parent.name.split('-strict-', 1)[0] + '.lean'
            source = next(row for row in index['sources'] if Path(row['source']).name == module)
            assert report['source_sha256'] == source['source_sha256']
        attempts += 1
        failures += report['exit_code'] != 0
    assert (attempts, failures) == (8, 1)
    comparison = json.loads((P / 'metadata/contract-comparison.json').read_text())
    for name in ['same_original_admissions_modulo_whitespace', 'entire_old_retained_result_first_modulo_outer_group_and_whitespace', 'owner_v2_final_public_declaration_byte_identical']:
        assert comparison[name] is True
    norm = lambda data: b''.join(data.split())
    assert norm((P / 'metadata/contracts/old-gates.txt').read_bytes()) == norm((P / 'metadata/contracts/new-gates.txt').read_bytes())
    assert norm((P / 'metadata/contracts/old-retained-result.txt').read_bytes()) == norm((P / 'metadata/contracts/new-first-result.txt').read_bytes())
    final = (P / 'checked/SourceCurrentConjunctionCallSound.lean').read_bytes()
    assert digest(final) == '6a7102e317ab8d9d223f31fcf1f14b1652d5edc1182994010594e2844bc592b9'
    original = (P / 'drafts/v2/SourceCurrentConjunctionCallSound.lean').read_bytes()
    assert original.split(b'theorem call_correct', 1)[1].split(b':= by', 1)[0] == final.split(b'theorem call_correct', 1)[1].split(b':= by', 1)[0]
    print('PASS source scopes: OLD 415/11 paths; NEW 684/5 paths; two OLD wholes; eight Root checks/one failure')

def manifest():
    if not (P / 'MANIFEST.json').exists():
        return
    ledger = json.loads((P / 'MANIFEST.json').read_text())
    expected = set()
    for row in ledger['payloads']:
        checked(row)
        assert row['path'] not in expected
        expected.add(row['path'])
    actual = {str(path.relative_to(P)) for path in P.rglob('*') if path.is_file() and path.relative_to(P) not in ROOT_CONTROL}
    assert actual == expected, {'missing': sorted(expected - actual), 'extra': sorted(actual - expected)}
    assert len(expected) == ledger['payload_count']
    pins = json.loads((P / 'PINS.json').read_text())
    checked(pins['manifest'])
    seal = json.loads((P / 'FROZEN.json').read_text())
    checked(seal['pins'])
    checked(seal['manifest'])
    assert seal['payload_count'] == len(expected)
    assert seal['exact_file_count'] == len(expected) + 3
    assert len([path for path in P.rglob('*') if path.is_file()]) == seal['exact_file_count']
    print(f"PASS exact full tree: {len(expected)} payloads; {seal['exact_file_count']} files; nested control basenames remain payloads")

sources()
manifest()
