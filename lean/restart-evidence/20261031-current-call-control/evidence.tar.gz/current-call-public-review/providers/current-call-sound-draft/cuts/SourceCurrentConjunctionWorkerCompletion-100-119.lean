/-- A literal decision success has the current open shortcut or actual worklist and fixed point. -/
theorem decision_sound [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] [DecidableEq (Value Symbol Guard)]
    (p h budget : Nat) (start : Value Symbol Guard) (before : Physical Symbol Formula)
    (answer : Bool) (after : Physical Symbol Formula)
    (actual : decision p h budget start before = .done answer after) :
    SourceCurrentConjunctionDecision.Decision budget start before answer after := by
  cases admitted : closed start with
  | false => simp only [decision, admitted, Bool.false_eq_true, ite_false] at actual; cases actual; exact .open_input admitted
  | true =>
      simp only [decision, admitted, ite_true] at actual
      cases explored : explore p h budget [] [[start]] before with
      | failed => simp only [explored, Outcome.bind] at actual; cases actual
      | done table current =>
          simp only [explored, Outcome.bind] at actual
          cases grown : SourceCurrentConjunctionEmptinessTable.grow .empty key closed table (budget + 1) (fun _ => false) with
          | none => simp only [grown] at actual; cases actual
          | some known =>
              simp only [grown] at actual
              cases actual
              exact .closed admitted (explore_sound p h budget [] [[start]] before _ _ explored) grown
