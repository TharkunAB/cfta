theorem verified [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] [DecidableEq Value]
    (formulas : SourceGuards.Formulas FullSyntax.Formula) (solver : SourceGuards.Entailment FullSyntax.Formula)
    {budget : Nat} {query : Value} {before after : Physical} {answer : Bool} {memo saved : Memo}
    (call : Call budget memo query before answer after saved) (ready : Ready before)
    (available : Available before.heap query) (correct : Correct formulas solver before.heap memo) :
    Effects before after ∧ Correct formulas solver after.heap saved ∧
      AnswerSound formulas solver query answer ∧ Extends memo saved := by
  cases call with
  | hit found =>
      obtain ⟨identity, originalAvailable, sound⟩ := correct _ _ _ found
      have same := InternedFreshProbeKeys.resident_reference_injective before.heap
        ready.semantic.ready.semantic.1.normal.facts.coherent _ query
        originalAvailable.resident available.resident identity
      subst_vars
      exact ⟨Effects.refl before ready, correct, sound, fun _ _ present => present⟩
  | miss absent actual =>
      have checked := SourceCurrentConjunctionDecision.Decision.verified actual ready available formulas solver
      have effects := checked.1
      have sound := checked.2
      have old := SourceCurrentEmptinessMemo.grows formulas solver effects.keeps memo correct
      refine ⟨effects, ?_, sound, ?_⟩
      · intro key original result found
        dsimp only [SourceCurrentEmptinessMemo.insert] at found
        split at found
        · rename_i same
          have pair : query = original ∧ answer = result := by
            simpa only [Option.some.injEq, Prod.mk.injEq] using found
          rcases pair with ⟨rfl, rfl⟩
          exact ⟨same.symm, effects.keeps.available query available, sound⟩
        · exact old key original result found
      · intro key entry found
        have different : key ≠ query.referenceOf := by
          intro same
          subst key
          rw [absent] at found
          cases found
        simp only [SourceCurrentEmptinessMemo.insert, different, ↓reduceIte, found]

