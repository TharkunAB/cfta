/-- A supplied memo success derives its literal current hit or completed miss. -/
theorem call_sound [DecidableEq ConcreteSymbol] [DecidableEq (EdgeKey ConcreteSymbol ConcreteGuard)]
    [DecidableEq (Value ConcreteSymbol ConcreteGuard)]
    (p h budget : Nat) (memo : Memo) (query : Value ConcreteSymbol ConcreteGuard)
    (before : Physical ConcreteSymbol FullSyntax.Formula) (answer : Bool)
    (after : Physical ConcreteSymbol FullSyntax.Formula) (saved : Memo)
    (actual : call p h budget memo query before = .done (answer, saved) after) :
    SourceCurrentConjunctionMemo.Call budget memo query before answer after saved := by
  cases found : memo query.referenceOf with
  | some entry =>
      obtain ⟨original, result⟩ := entry
      simp only [call, found] at actual
      cases actual
      exact .hit found
  | none =>
      cases done : decision p h budget query before with
      | failed => simp only [call, found, done, Outcome.bind] at actual; cases actual
      | done result current =>
          simp only [call, found, done, Outcome.bind] at actual
          cases actual
          exact .miss found (decision_sound p h budget query before _ _ done)
