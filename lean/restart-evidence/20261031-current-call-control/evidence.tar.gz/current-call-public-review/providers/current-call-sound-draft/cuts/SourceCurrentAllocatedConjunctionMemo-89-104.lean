theorem call_effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    [DecidableEq (Value Symbol Guard)]
    (formulas : SourceGuards.Formulas FullSyntax.Formula) (solver : SourceGuards.Entailment FullSyntax.Formula)
    {budget : Nat} {memo saved : SourceCurrentEmptinessMemo.Memo} {query : Value Symbol Guard}
    {before : Checked width} {answer : Bool} {after : Physical}
    (actual : SourceCurrentConjunctionMemo.Call budget memo query (physical before) answer after saved)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap)
    (costs : CostHeap before.native.machine.heap) (idle : SourceRecursiveIntersectionNative.Idle before.native)
    (available : Available before.native.machine.heap query)
    (correct : SourceCurrentEmptinessMemo.Correct formulas solver before.native.machine.heap memo) :
    Receipt before after ∧ SourceCurrentEmptinessMemo.Correct formulas solver after.heap saved ∧
      SourceCurrentEmptinessMemo.AnswerSound formulas solver query answer ∧
      SourceCurrentEmptinessMemo.Extends memo saved := by
  obtain ⟨effects, finalCorrect, sound, retained⟩ := SourceCurrentConjunctionMemo.verified formulas solver
    actual (ready before good semantic costs) available correct
  exact ⟨lift_effects before after good idle effects, finalCorrect, sound, retained⟩
