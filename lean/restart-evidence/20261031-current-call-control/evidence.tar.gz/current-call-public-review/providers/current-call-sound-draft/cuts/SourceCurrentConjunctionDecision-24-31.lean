inductive Decision [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] [DecidableEq (Value Symbol Guard)]
    (budget : Nat) (start : Value Symbol Guard) : Physical → Bool → Physical → Prop where
  | open_input (openInput : closed start = false) : Decision budget start before false before
  | closed (closedInput : closed start = true)
      (explored : Run budget [] [[start]] before table after)
      (grown : SourceCurrentConjunctionEmptinessTable.grow .empty key closed table (budget + 1)
        (fun _ => false) = some known) :
      Decision budget start before (SourceCurrentConjunctionEmptinessTable.answer .empty key closed table known start) after
