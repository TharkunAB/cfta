def AnswerSound (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (input : Value) (answer : Bool) : Prop :=
  (input.free ≠ [] → answer = false) ∧
    (answer = true → ∀ ambient term, ¬meaning (SourceEqualityPCSGuard.holds formulas solver) ambient input term)

/-- Every completed entry has its actual physical key and conservative semantic law. -/
def Correct (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (heap : State Symbol Guard) (memo : Memo) : Prop :=
