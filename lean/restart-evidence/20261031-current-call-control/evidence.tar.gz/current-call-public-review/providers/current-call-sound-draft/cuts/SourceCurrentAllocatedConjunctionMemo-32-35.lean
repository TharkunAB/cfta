theorem ready (before : Checked width) (good : Good before)
    (semantic : SemanticReady before.native.machine.heap) (costs : CostHeap before.native.machine.heap) :
    Ready (physical before) := ⟨semantic, costs, good.operations, good.fields⟩

