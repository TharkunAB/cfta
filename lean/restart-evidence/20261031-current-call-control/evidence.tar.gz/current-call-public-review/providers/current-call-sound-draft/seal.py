"""Seal the complete owner tree once. Keep nested metadata in the payload set."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

P = Path(__file__).resolve().parent
assert not (P / 'FROZEN.json').exists()
controls = {Path('MANIFEST.json'), Path('PINS.json'), Path('FROZEN.json')}
def digest(data):
    return hashlib.sha256(data).hexdigest()
def record(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(P)), 'bytes': len(data), 'sha256': digest(data)}
subprocess.run([sys.executable, str(P / 'verify.py')], check=True)
files = sorted(path for path in P.rglob('*') if path.is_file() and path.relative_to(P) not in controls)
manifest = {'scope': 'Complete fresh source-owner tree. Exclude only three top-level controls; retain all nested metadata.', 'payload_count': len(files), 'payloads': [record(path) for path in files]}
(P / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
pins = {'manifest': record(P / 'MANIFEST.json'), 'payload_count': len(files), 'exact_file_count': len(files) + 3}
(P / 'PINS.json').write_text(json.dumps(pins, indent=2) + '\n')
seal = {'status': 'FROZEN_WRITE_HALT', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'owner': '/root/arity_meaning', 'manifest': record(P / 'MANIFEST.json'), 'pins': record(P / 'PINS.json'), 'payload_count': len(files), 'exact_file_count': len(files) + 3, 'checked_source_sha256': '6a7102e317ab8d9d223f31fcf1f14b1652d5edc1182994010594e2844bc592b9', 'owner_compiler_evaluator_commands': 0}
(P / 'FROZEN.json').write_text(json.dumps(seal, indent=2) + '\n')
subprocess.run([sys.executable, str(P / 'verify.py')], check=True)
for path in P.rglob('*'):
    if path.is_file():
        path.chmod(0o444)
for path in sorted((path for path in P.rglob('*') if path.is_dir()), key=lambda item: len(item.parts), reverse=True):
    path.chmod(0o555)
P.chmod(0o555)
for name in ['REPORT.md', 'MANIFEST.json', 'PINS.json', 'FROZEN.json']:
    print(json.dumps(record(P / name)))
print(json.dumps({'payload_count': len(files), 'exact_file_count': len(files) + 3, 'status': 'WRITE HALT'}))
