from pathlib import Path
import difflib, hashlib, json
P = Path(__file__).resolve().parent
R = Path('/tmp/mcfta-current-call-control-20261031')
REPO = Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
def pin(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
origins = []
def capture(source, relative, scope):
    data = source.read_bytes()
    target = P / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    origins.append({'source': str(source), 'copy': relative, 'read_scope': scope, **pin(data)})
    return data
for name in ['modules.json', 'verification-plan.json']:
    capture(R / name, 'metadata/final-root-' + name, 'WHOLE metadata snapshot; may differ from earlier historical snapshot')
checks = [
    'SourceCurrentConjunctionRowsWorkerEffects-strict-v1',
    'SourceCurrentConjunctionWorkerEffects-strict-v1',
    'SourceCurrentAllocatedNativeIncomingOldKnownAll-strict-v1',
    'SourceCurrentConjunctionCallRetained-default-v2',
    'SourceCurrentConjunctionCallRetained-strict-v2',
    'SourceCurrentConjunctionCallSound-default-v1',
    'SourceCurrentConjunctionCallSound-default-v2',
    'SourceCurrentConjunctionCallSound-strict-v2',
]
for name in checks:
    for leaf in ['report.json', 'inputs.json', 'started-command.json', 'raw.log']:
        source = R / name / leaf
        capture(source, f'metadata/checks/{name}/{leaf}', 'WHOLE actual recorded check metadata or raw diagnostic')
final_path = REPO / 'SourceCurrentConjunctionCallSound.lean'
final = capture(final_path, 'checked/SourceCurrentConjunctionCallSound.lean', 'WHOLE checked NEW source: 70 lines')
assert pin(final)['sha256'] == '6a7102e317ab8d9d223f31fcf1f14b1652d5edc1182994010594e2844bc592b9'
v2 = (P / 'drafts/v2/SourceCurrentConjunctionCallSound.lean').read_bytes()
(P / 'metadata/v2-final.diff').write_text(''.join(difflib.unified_diff(v2.decode().splitlines(True), final.decode().splitlines(True), fromfile='owner-v2-69L', tofile='root-checked-final-70L')))
assert v2.split(b'theorem call_correct', 1)[1].split(b':= by', 1)[0] == final.split(b'theorem call_correct', 1)[1].split(b':= by', 1)[0]
index = json.loads((P / 'source-index.json').read_text())
assert not any(r['source'] == str(final_path) for r in index['sources'])
index['sources'].append({'source': str(final_path), 'classification': 'NEW checked whole', 'source_lines': len(final.splitlines()), 'source_bytes': len(final), 'source_sha256': pin(final)['sha256'], 'whole': {'path': 'checked/SourceCurrentConjunctionCallSound.lean', **pin(final)}, 'reviewed_union_lines': list(range(1, len(final.splitlines()) + 1))})
for row in index['sources']:
    if row['source'].endswith('SourceCurrentConjunctionCallRetained.lean'):
        row['checked_status'] = 'default-v2 PASS; strict-v2 PASS; 125 lines; classification records acquisition-time label'
(P / 'source-index.json').write_text(json.dumps(index, indent=2) + '\n')
retained = (P / 'sources/SourceCurrentConjunctionCallRetained.lean').read_text()
final_text = final.decode()
old_decl = retained.split('theorem call_retained ', 1)[1].split(' := by', 1)[0]
new_decl = final_text.split('theorem call_correct ', 1)[1].split(' := by', 1)[0]
old_gates = old_decl.split(':\n    let actual :=', 1)[0]
new_gates = new_decl.split(':\n    let actual :=', 1)[0]
old_result = old_decl.split('\n    At ', 1)[1]
old_result = 'At ' + old_result
new_result = new_decl.split('\n    (At ', 1)[1].split('before.fourth) ∧', 1)[0]
new_result = 'At ' + new_result + 'before.fourth'
norm = lambda text: ''.join(text.split())
assert norm(old_gates) == norm(new_gates)
assert norm(old_result) == norm(new_result)
for leaf, text in [('old-gates.txt', old_gates), ('new-gates.txt', new_gates), ('old-retained-result.txt', old_result), ('new-first-result.txt', new_result)]:
    target = P / 'metadata/contracts' / leaf
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)
comparison = {'same_original_admissions_modulo_whitespace': True, 'entire_old_retained_result_first_modulo_outer_group_and_whitespace': True, 'owner_v2_final_public_declaration_byte_identical': True, 'scope': 'call_retained parameters and retained endpoint result; no claim that the extended full declaration is identical', 'old_gates': pin(old_gates.encode()), 'new_gates': pin(new_gates.encode()), 'old_result': pin(old_result.encode()), 'new_first_result': pin(new_result.encode())}
(P / 'metadata/contract-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
(P / 'metadata/input-origins.json').write_text(json.dumps({'records': origins, 'note': 'Current proof sources are recorded separately in source-index.json. Historical root-modules/root-verification-plan snapshots remain separate payloads.'}, indent=2) + '\n')
status = {'final_status': 'ROOT_DEFAULT_V2_AND_STRICT_V2_PASS', 'owner_v1': 'UNTESTED; corrected nonexistent Memos namespace in v2 before Root checking', 'owner_v2': '69L; first Root default check failed; frozen unchanged', 'root_final': {'copy': 'checked/SourceCurrentConjunctionCallSound.lean', 'lines': len(final.splitlines()), **pin(final)}, 'proof_only_repair': 'Add SourceRecursiveIntersectionThunks.advance to success simplification. Public declaration remains byte-identical.', 'owner_compiler_or_evaluator_commands': 0, 'check_scope': 'Retained eight actual Root check attempts; no claim to review final aggregate/public/docs pipeline.'}
(P / 'metadata/candidate-status.json').write_text(json.dumps(status, indent=2) + '\n')
print(json.dumps(status, indent=2))
