# Actual current-call answer soundness

The inserted-answer gap has a checked local solution. `SourceCurrentConjunctionCallSound.call_correct` retains the entire result of `call_retained` first. It also proves correctness of the actual returned fourth memo at the actual returned heap. If the literal call completes, it proves the existing `AnswerSound` predicate for that actual answer. Failure retains correctness of the unchanged returned memo. All public inputs are the original current `Context`, query availability, query closure, and the original execution bounds. There is no supplied future call receipt, rows result, answer law, completed execution, or returned `Context`.

The final module has 70 lines and 4,155 bytes. Its SHA256 is `6a7102e317ab8d9d223f31fcf1f14b1652d5edc1182994010594e2844bc592b9`. Root ran the default build and the strict check. Both passed. The strict log is empty. This owner ran no Lean command, compiler, evaluator, modeled program, Haskell operation, Git command, network call, or board operation. This owner changed only this fresh review subtree. Root alone installed and checked production changes.

## Exact Boolean meaning

`SourceCurrentEmptinessMemo.lean:28–31` defines:

```lean
(input.free ≠ [] → answer = false) ∧
  (answer = true → ∀ ambient term,
    ¬meaning (SourceEqualityPCSGuard.holds formulas solver) ambient input term)
```

A true answer excludes every accepted term under every ambient assignment. A false answer supplies no nonempty witness. The original closed-query admission makes the first implication vacuous in this theorem. Consequently, the result supports conservative rejection. It does not establish decision completeness, accepted-branch existence, or successful enumeration.

## Actual proof route

1. The checked `SourceCurrentConjunctionCallRetained.call_retained` supplies the original endpoint inventory admission, old merge-table storage, and correctness of the old fourth table at the reached heap.
2. `SourceCurrentAllocatedConjunctionMemo.ready` constructs the exact physical `Ready` value from `context.ready.good`, `context.ready.semantic`, and `context.ready.costs`. `context.correct` is correctness of the original fourth table. These are facts of the original current caller.
3. The proof splits the literal `SourceCurrentConjunctionWorker.call` at the actual physical input. In the completed case, `SourceCurrentConjunctionWorkerCompletion.call_sound` derives the semantic call receipt from that same completed execution. This readback has no supplied future rows or semantic result premise.
4. `SourceCurrentConjunctionMemo.verified` consumes the derived receipt, initial `Ready`, query availability, and original memo correctness. It derives correctness of the returned memo and `AnswerSound` for the returned answer. Its miss branch calls the actual `Decision.verified` and proves the inserted entry. Its hit branch identifies the resident query through the original correct memo and ready heap.
5. In the failed case, the allocated wrapper returns the original fourth table. The retained original correctness fact therefore proves correctness of this actual returned table. Its actual reached heap remains the failed call's heap.

The existing completed-run equation appears only inside the proof after the actual outcome split. It is not a public admission. No `Complete`, universal continuation invariant, arbitrary rows supplier, or new resource ceiling appears in the theorem.

## Original contract and source review

`metadata/contract-comparison.json` records exact parameter-token equality after whitespace removal. It also records recovery of the complete original `call_retained` result from the first grouped result. The final extended declaration is larger; no whole-declaration identity claim is made. The owner's submitted V2 public declaration and the Root-checked final declaration are byte-identical.

All five current sources were read in full: RowsWorkerEffects186, WorkerEffects153, IncomingOldKnownAll150, CallRetained125, and CallSound70. They total 684 lines. The rows effect proof follows the current literal exposures, `CurrentConjunctionEquality.fold`, requirements, projections, and tuples. It retains the reached heap on errors and proves closed available requirements on success. It does not use the separate SharedTarget/ClassFold route. The worker effect proof follows actual explore/decision/call outcomes. The incoming consumer retains old decoded handles and old cache facts at every actual incoming caller, including failed checks. Its dictionary transports use equality and proof irrelevance. The new answer theorem uses the canonical local equality convention of the current call producer.

The theorem keeps Mu and Union in the native value type. It does not substitute an ordinary-only input restriction or an assumed normalized row model.

## Acquisition budget and precise scopes

Exactly two OLD whole originals were named before acquisition:

- `lean/MicroCFTA/SourceCurrentConjunctionDecisionSoundness.lean`: 47 lines.
- `lean/MicroCFTA/SourceCurrentConjunctionWorker.lean`: 108 lines.

Other OLD acquisitions are literal bounded cuts and named locator lines. Their cumulative unions at the original production paths are:

| Original basename | Acquired union / original lines |
| --- | --- |
| SourceCurrentConjunctionWorkerCompletion | 81 / 196 |
| SourceCurrentConjunctionRowsWorkerActual | 25 / 176 |
| SourceCurrentConjunctionWorkerStability | 6 / 133 |
| SourceCurrentConjunctionMemo | 42 / 92 |
| SourceCurrentConjunctionDecision | 14 / 55 |
| SourceCurrentAllocatedPartialInvariant | 22 / 89 |
| SourceCurrentAllocatedConjunctionMemo | 33 / 124 |
| SourceCurrentAllocatedConjunctionWorker | 29 / 105 |
| SourceCurrentEmptinessMemo | 8 / 129 |

Every secondary OLD union is strictly below half its original file. No third whole or near-whole OLD source was acquired. No 1,291-line family was read. OLD scope totals 415 distinct lines across 11 original paths. NEW scope totals 684 lines across five original paths. Total scope is 1,099 distinct lines across 16 original production paths. Overlapping cuts count once per ORIGINAL path. A complete-file hash or line count is source metadata; it is not a claim to have read the unsaved body. `source-index.json` and `source-vectors.json` retain all exact original paths, source hashes, literal cut hashes, and union vectors.

The verified semantic providers used here are public declarations. Their required factual and semantic gates are visible in the retained complete theorem cuts. The new effects modules and their consulted private helper bodies are retained in full. This owner does not claim an independent rereading of every transitive library proof. Historical restart-provider bodies were not recopied. The Root evidence archive remains responsible for its broader closure.

## Candidate and check lineage

- Owner V1 is source-only and untested. It used an unverified Memos namespace. V2 replaces it with the exact `EndpointMemoGateTrace.Memos` from the checked original header. Both 69-line variants remain unchanged. Together they are 138 authored lines. The final production module is 70 lines, below the 210-line limit.
- Root checked owner V2 first. The default build failed with a 1,936-byte log, SHA256 `b4e0dfea0b533d96a71b0d8a2ecc16eef3c66b3f97c69ae9b922a077c4db4e65`. This whole log was read and retained. The failure exposed only the nested `SourceRecursiveIntersectionThunks.advance` heap reduction.
- Root added that existing definition to the successful branch's simplification list. The original declaration and all runtime definitions stayed unchanged. `metadata/v2-final.diff` retains the complete repair.
- Root final default V2 passed with a 554-byte log. Root final strict V2 passed with an empty log. Both reports record measured 4 GiB memory limits and zero swap. The strict command records warning-as-error and all linters. Default Lake commands are not described as strict checks. The default log replays an older warning; it is not a new target warning.
- Eight exact Root check records are retained here: the four prerequisite strict passes, the retained-call default pass, the sound-call failed default attempt, and the final sound-call default and strict passes. Thus this subset has seven passes and one failure. It is not the denominator for Root's complete stage. The input origins identify the exact source snapshots and metadata copies. Historical four-module plan copies remain separate from the later five-module snapshot.

## Remaining full-goal obligations

This theorem establishes a local completed-answer law and all-outcome returned-table correctness. It does not construct the whole reached `Ready` or returned `Context`. The failed-check route still needs its complete current state obligations. Both original and prepared workers still need the fixed-original-D resume/continuation induction and actual post-hook caller/query facts with the same captured cache. Prepared inner failure heaps remain distinct from outer endpoint `None`. Original resource sufficiency, whole-cache propagation, terminal/alias/renewal progress, global accepted-output coverage, generic/default/Map/signed public order, and Haskell correspondence remain open. No Haskell defect is asserted.

No final aggregate Audit, public appendix, documentation, archive, commit, push, or publication is certified by this source-owner report. Root's later stage evidence covers those actions. The full objective remains active.

## Portable evidence replay

`verify.py` reads retained copies only. It checks exact hashes, duplicate original-path exclusion, overlapping literal cuts, deduplicated vectors, the two-OLD-whole budget, every secondary OLD half-file limit, original admission/result recovery, public-declaration preservation, and the eight recorded check logs and caps. Its seal replay compares the exact full relative-path tree with the manifest. It excludes only this owner's three top-level seal-control paths; a nested file named MANIFEST or PINS remains a payload. It does not execute Lean or a modeled program. After the exact seal is made, all writes to this subtree stop.
