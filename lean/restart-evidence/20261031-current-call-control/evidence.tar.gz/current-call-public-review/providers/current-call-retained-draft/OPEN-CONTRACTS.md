# Exact open producers

These are proposed next targets. They are UNIMPLEMENTED and UNELABORATED.
They are not public assumptions for the new126-line candidate.

## Actual physical row effects

For the literal CurrentConjunctionRowsWorker.rows p h nodes before:

- Start from CURRENT RowsAllocation.Ready before.
- Retain the CURRENT FreshOrdinaryProbeHeap.Heap premise when needed from Context.probes.
- Start from Values before.heap nodes and ClosedValues nodes.
- Derive RowsAllocation.Effects before actual.state for EVERY actual outcome.
- Derive FreshOrdinaryProbeHeap.Heap actual.state.heap for every actual outcome.

The reached Effects must contain actual equality-cache growth, Valid, Fields, CostHeap, SemanticReady, and OpenDepthReadback.Heap.
It must retain the reached state on every failed prefix.
The actual tuple equality operation and its returned equality cache must remain literal.
Projection, exposure, and reconstruction must produce their own new heap facts.
No future Effects record, reader trace, rows certificate, equality validity function, or ordinary-only operand gate may be supplied.
Then lift through the actual budget/pending-list exploration and decision, as the checked heap proof does.
Current Context derives the initial physical Ready via the existing ConjunctionMemo.ready API.

## Actual returned-answer law

For the literal current call from CURRENT Context, Available query, and query.free = []:

    let actual := SourceCurrentConjunctionWorker.call p h budget before.fourth query (physical before.checked)
    match actual with
    | .done (answer, _saved) _after => SourceCurrentEmptinessMemo.AnswerSound formulas solver query answer
    | .failed _ _ => True

Warm hits use the actual current Correct field.
A completed miss needs the actual current exploration/rows/constraint/fixed-point semantic proof.
It must not substitute the relational ClassFold or SharedTarget route for CurrentConjunctionEquality/ProjectionWorker.forest.
It must not accept a future sound result table or future answer certificate.
The new retained-table law gives no semantic proof for a new answer.

## Computed full Post

Fix original formulas, solver, inventory, before Caller, and endpoint memos.
Use CURRENT Context and Available/closed query.
The final target computes the actual allocated call:

    let actual := SourceCurrentAllocatedConjunctionWorker.call p h budget query before.checked before.fourth
    let reached := SourceCurrentAllocatedPartialState.advance before actual.state actual.memo before.merge
    SourceCurrentAllocatedPartialInvariant.Post formulas solver inventory before reached memos

The reached Context and full physical Effects are conclusions.
They are not input witnesses.
The same inventory and unchanged endpoint memo arguments must be justified at the actual state.
All actual outcomes remain included.
No full Post theorem is drafted here.

## Worker consumer

A future fixed-D worker proof may consume the derived call Post at the literal call site.
It must keep primitive workFuel D fixed while recursiveFuel k decreases.
It must still derive actual Context, Fits, annotations, remaining resources, and the original reservation lineage across the other source branches.
It must restore the SAME captured sibling cache and metadata at the actual after-hook Caller/query pair.
It must cover Native and Prepared, and keep Prepared raw inner heap distinct from an absent outer endpoint.
No global original resource or public/Haskell theorem follows from a single-call producer.
