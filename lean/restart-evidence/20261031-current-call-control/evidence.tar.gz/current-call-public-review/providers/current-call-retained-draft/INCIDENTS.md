# Incidents and read limits

No compiler, evaluator, native, Haskell, Git, network, board, production, or spawn command occurred.
No helper command failed in this task.

The Sound.advance header selector used the first later `:= by` line as its stop condition.
Sound.advance uses a term proof after `:=`.
The selector therefore retained lines128–148, including unused private helper material136–148.
The exact copied bytes and original line vector are retained.
No private helper is invoked by the new candidate.
No additional source from that region was read.

The named Covered declaration locator in InternedNestedProvenance matched no line.
Its empty payload and exact empty vector remain retained.
The initial Context supplies Covered through ready.semantic.ready.covered.
No further Covered body was needed or acquired.

Prior provider incidents remain in the complete unchanged providers.
This owner retains their manifest/pins and closure metadata.
Both new root indexes use the same full relative-path payload set.
Only the two root index files are excluded. Nested manifest and pins payloads remain included.
