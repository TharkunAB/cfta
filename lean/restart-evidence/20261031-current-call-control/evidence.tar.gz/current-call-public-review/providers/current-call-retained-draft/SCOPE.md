# Scope

Source only. No compiler/evaluator/native/Haskell/Git/network/board/production/spawn.
The two OLD whole originals were named before acquisition:
/home/tritlo/Code/mcfta/lean/MicroCFTA/SourceCurrentAllocatedPartialInvariant.lean
/home/tritlo/Code/mcfta/lean/MicroCFTA/SourceCurrentAllocatedPartialState.lean
All other OLD source reads are named bounded cuts or locators with cumulative ORIGINAL-path vectors.
The Root checked153 source is NEW and was explicitly permitted whole.
The new126 source candidate is UNCOMPILED.
All complete referenced private providers remain immutable and retained whole by Root.
Consulted metadata and reused source cuts have exact local copies and hashes.
No full Context/Post, future supplier, ordinary-only gate, or whole-worker/global/public/Haskell claim is introduced.
Both root indexes list the same complete payload set. Only those two ROOT index files are excluded.
