#!/usr/bin/env python3
"""Replay retained bytes and provenance. Do not run a source proof or worker."""
from pathlib import Path
import hashlib
import json
import sys
ROOT = Path(__file__).resolve().parent
LIVE = '--live' in sys.argv
EXCLUDED = {'MANIFEST.json', 'PINS.json'}
def sha(data):
    return hashlib.sha256(data).hexdigest()
records = json.loads((ROOT / 'acquisitions.json').read_text())
summary = json.loads((ROOT / 'source-unions.json').read_text())
actual = {}
for record in records:
    payload = (ROOT / record['copy']).read_bytes()
    assert sha(payload) == record['copy_sha256']
    assert record['read_status'].startswith('complete')
    vector = record['actual_lines']
    assert vector == sorted(set(vector))
    assert all(1 <= index <= record['source_lines'] for index in vector)
    lines = payload.splitlines(keepends=True)
    assert len(lines) == len(vector)
    if record['copy_format'] == 'numbered-lines':
        assert all(line.startswith((str(index) + ':').encode()) for index, line in zip(vector, lines))
    else:
        assert record['copy_format'] == 'plain-source-lines'
        assert len(payload) == record['source_bytes'] and sha(payload) == record['source_sha256']
    actual.setdefault(record['source_path'], set()).update(vector)
    if LIVE:
        source = Path(record['source_path']).read_bytes()
        source_lines = source.splitlines(keepends=True)
        assert len(source) == record['source_bytes'] and sha(source) == record['source_sha256']
        assert len(source_lines) == record['source_lines']
        expected = b''.join((b'' if record['copy_format'] == 'plain-source-lines' else (str(index) + ':').encode()) + source_lines[index - 1] for index in vector)
        assert expected == payload
assert summary['source_acquisitions'] == len(records)
assert summary['original_paths'] == len(actual)
assert summary['all_unique_semantic_lines'] == sum(map(len, actual.values()))
wholes = []
for source in summary['sources']:
    assert source['actual_lines'] == sorted(actual[source['source_path']])
    assert source['semantic_union_lines'] == len(source['actual_lines'])
    if source['old'] and source['whole']:
        wholes.append(source['source_path'])
        assert len(source['actual_lines']) == source['source_lines']
    elif source['old']:
        assert 2 * len(source['actual_lines']) < source['source_lines']
assert wholes == summary['old_whole_original_paths'] and len(wholes) == 2
for record in json.loads((ROOT / 'metadata-inputs.json').read_text())['files']:
    payload = (ROOT / record['copy']).read_bytes()
    assert len(payload) == record['bytes'] and sha(payload) == record['sha256']
    if LIVE:
        assert Path(record['original_path']).read_bytes() == payload
for version in json.loads((ROOT / 'draft-versions.json').read_text())['versions']:
    payload = (ROOT / version['file']).read_bytes()
    assert len(payload) == version['bytes'] and len(payload.splitlines()) == version['lines']
    assert sha(payload) == version['sha256'] and version['status'] == 'UNCOMPILED'
closure = json.loads((ROOT / 'provider-closure.json').read_text())
if LIVE:
    first = closure['direct_provider']; owner = Path(first['path'])
    m = json.loads((owner / 'MANIFEST.json').read_text())
    assert sha((owner / 'MANIFEST.json').read_bytes()) == first['manifest_sha256']
    assert sha((owner / 'PINS.json').read_bytes()) == first['pins_sha256']
    disk = {str(f.relative_to(owner)) for f in owner.rglob('*') if f.is_file()}
    assert disk - {'MANIFEST.json', 'PINS.json'} == set(m['files'])
    for name in m['files']:
        data = (owner / name).read_bytes()
        assert len(data) == m['pins'][name]['bytes'] and sha(data) == m['pins'][name]['sha256']
    second = closure['transitive_rows_provider']; owner = Path(second['path'])
    assert sha((owner / 'MANIFEST.json').read_bytes()) == second['manifest_sha256']
    assert sha((owner / second['pins_name']).read_bytes()) == second['pins_sha256']
    m = json.loads((owner / 'MANIFEST.json').read_text())
    for row in m['payloads']:
        data = (owner / row['path']).read_bytes()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
indexes = []
for name in sorted(EXCLUDED):
    path = ROOT / name
    if not path.exists():
        continue
    index = json.loads(path.read_text())
    assert sorted(index['files']) == sorted(index['pins'])
    files = sorted(str(f.relative_to(ROOT)) for f in ROOT.rglob('*') if f.is_file() and f.relative_to(ROOT).as_posix() not in EXCLUDED)
    assert files == sorted(index['files'])
    for relative in index['files']:
        data = (ROOT / relative).read_bytes()
        assert len(data) == index['pins'][relative]['bytes'] and sha(data) == index['pins'][relative]['sha256']
    indexes.append(index)
if len(indexes) == 2:
    assert indexes[0]['files'] == indexes[1]['files'] and indexes[0]['pins'] == indexes[1]['pins']
print(json.dumps({'status': 'PASS', 'live_replay': LIVE, 'source_acquisitions': len(records),
                  'original_paths': len(actual), 'old_whole_original_paths': len(wholes),
                  'old_unique_semantic_lines': summary['old_unique_semantic_lines'],
                  'all_unique_semantic_lines': summary['all_unique_semantic_lines'],
                  'compiler_or_source_evaluator': 0}))
