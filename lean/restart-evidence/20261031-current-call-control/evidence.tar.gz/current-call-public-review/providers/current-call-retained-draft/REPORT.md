# Actual current call fields before a full Post

Status: SOURCE ONLY. The new126-line candidate is UNCOMPILED.

## Result

The current Context/Post definitions have been read in full.
A concrete lower-field producer is drafted.
It consumes CURRENT Context and the actual query Available/closed facts.
It derives the call endpoint internally.
It does not accept a future Context, Post, Trace, row certificate, or endpoint witness.

SourceCurrentConjunctionCallRetained has three proposed public laws.

- call_fourth_extends follows actual hit, miss, successful decision, and failed decision branches.
  It derives exact preservation of all earlier fourth-table entries.
  It uses the actual missing-key test before insert.
  It requires no semantic or ordinary-domain gate.
- call_retained derives the SAME inventory At at every actual allocated-call endpoint.
  It also transports the OLD completed merge memo Stored and OLD fourth memo Correct to the actual heap.
  The current Context already supplies the checked heap law's SemanticHeap and Covered premises through ready.semantic.ready.
  The helper uses actual growth/history from checked call_effects.
  It clones the unchanged native-table admission fields and composes original inventory histories.
  It transports actual old merge inputs/results and old fourth inputs with Available.grows.
- call_failed_correct gives Correct for the actually returned fourth memo on a failed call.
  It derives this from the unchanged failure memo and call_retained.
  The success branch is explicitly True.
  It makes no claim about a newly inserted successful answer.

The helper physical_retained consumes growth/history only inside these actual-call proofs.
No public theorem takes those future endpoint properties as an input.
Stored here means SourceCurrentMemoMergeEffects.Stored for the completed merge memo.
It is distinct from Native Stored and from slot-cache Known.
This work does not duplicate the separate failed-check old-cache consumer.

## Context fields

Context has eight fields.

1. ready: SourceCurrentConjunctionClassScan.Ready.
   Its good, SemanticReady, CostHeap, Scoped cache, and Idle facts are separate obligations.
   SemanticReady contains RequiredCache.Ready, guarded probes, and budget probes.
   RequiredCache.Ready contains SemanticHeap, Covered [], and OpenDepthReadback.Heap.
   The checked physical call gives the first two endpoint heap facts and actual histories.
   It does not by that statement derive endpoint OpenDepthReadback.Heap, CostHeap, equality-cache Valid, or equality Fields.
   Existing advance_ready can use a full actual RowsAllocation.Effects producer once that is proved.
2. admitted: inventory At.
   This is the proposed actual call_retained result.
   It retains the same native tables and input model with composed heap histories.
3. sound: both caller result-table families and their phase laws.
   Existing Sound.advance uses full RowsAllocation.Effects, including actual equality-cache constraint growth.
   The heap-only call statement does not supply that full Effects record.
4. stored: completed merge memo Stored.
   The OLD merge memo is transported by call_retained.
   Caller.advance retains it when the actual call endpoint is installed with the same merge argument.
5. covered: completed merge memo CacheCovers.
   This predicate is independent of the constructor heap.
   It remains the same current context field when the merge memo is unchanged.
6. correct: fourth memo Correct.
   Correct for the OLD memo is transported at every endpoint.
   Correct for the RETURNED memo is proposed for failed calls.
   A completed miss inserts a new answer.
   Its AnswerSound clause needs a real actual decision/rows/table semantic producer.
   Constructor growth and table extension do not prove that clause.
7. globals: EndpointMemoGateTrace.Valid.
   The allocated call does not replace these endpoint memo arguments.
   Their unfolding and query validity still need an actual heap transport proof.
   This owner does not derive that complete warm-table transport.
8. probes: FreshOrdinaryProbeHeap.Heap.
   This requires Clean for Mu probe records in the reached heap.
   The existing preserve law takes NoNewMu.
   NoNewMu is not supplied by heap growth and cannot be assumed for the generic call route.
   A real producer must cover any newly created Mu records.

These are proof boundaries. This review does not prove that any missing field is false or independent of all existing facts.

## Post fields

Post.context needs all eight reached Context fields.
Post.effects needs literal physical RowsAllocation.Effects.
That record includes complete Keeps, complete reached physical Ready, and actual equality-cache Grows.
The current four-component constructor heap certificate is narrower.

Post.retained follows by reflexivity when Caller.advance retains before.merge.
Post.fourthRetained is the proposed call_fourth_extends law at the literal returned memo.
Neither table extension proves semantic correctness of new entries.
OPEN-CONTRACTS.md records exact next producers and the final computed-call target.
They are explicitly unimplemented headers, not checked theorems.

## Source and checked status

The two named OLD whole originals are PartialInvariant89 and PartialState250.
Both were read in full.
Every other OLD acquisition is a named bounded cut or locator.
The cumulative unions include explicit reuse from the previous frozen physical-call owner.
No third OLD near-whole source was acquired.
The fresh Root checked153 call source was read in full as permitted NEW input.
Root reported strict PASS with zero diagnostics for that source and its186-line rows dependency.
This owner ran no compiler or modeled source evaluator.
The new candidate still needs Root checking.

The source-scope overread for the Sound.advance term-proof header is retained in INCIDENTS.md.
All exact vectors, full-source hashes, and copy hashes are retained.
The empty Covered locator is retained too.
Direct40-file and transitive196-file providers were byte-verified and remain complete and immutable.
Both new indexes cover the same full payload set, including nested index payloads.

## Full objective

This is a lower-field result for the actual allocated emptiness call.
It is not a full current call Post or full worker Context theorem.
Fits, annotations, remaining reservations, and original resource sufficiency require their actual producers in the enclosing worker.
The fixed-original-D induction for BOTH workers remains open.
The SAME captured sibling cache must still be restored at the hook's actual Caller/query endpoint.
Prepared endpoint none still gives no hidden Caller certificate, even when the raw preparation contains an inner heap.
Generic Mu/Union/opaque cases remain in scope. No ordinary-only gate is introduced.
Termination, public coverage, ordered prefixes, default getter correspondence, host demand/publication, and Haskell correspondence remain open.
No Haskell defect, edit, or fix is established.
