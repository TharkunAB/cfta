# Proposed public contracts

SOURCE ONLY. UNCOMPILED. Namespace MicroCFTA.SourceCurrentConjunctionCallRetained.
Actual Symbol is SourcePruningTemplates.Symbol. Guard is Constraint FullSyntax.Formula.
Caller, Checked, Memo, Physical, Context, Inventory and At aliases match the exact source imports.
No explicit equality-instance or future endpoint premise is proposed.

```lean
theorem call_fourth_extends {width : Nat} (p h budget : Nat) (query : Node)
    (before : Checked width) (memo : Memo) :
    SourceCurrentEmptinessMemo.Extends memo
      (SourceCurrentAllocatedConjunctionWorker.call p h budget query before memo).memo := by
```

```lean
theorem call_retained {width : Nat}
    {formulas : SourceGuards.Formulas FullSyntax.Formula}
    {solver : SourceGuards.Entailment FullSyntax.Formula} {inventory : Inventory}
    (p h budget : Nat) (query : Node) (before : Caller width) (memos : EndpointMemoGateTrace.Memos)
    (context : Context formulas solver inventory before memos)
    (available : Available before.checked.native.machine.heap query) (closed : query.free = []) :
    let actual := SourceCurrentAllocatedConjunctionWorker.call p h budget query before.checked before.fourth
    At formulas solver inventory actual.state ∧
      SourceCurrentMemoMergeEffects.Stored actual.state.native.machine.heap before.merge ∧
      SourceCurrentEmptinessMemo.Correct formulas solver actual.state.native.machine.heap before.fourth := by
```

```lean
theorem call_failed_correct {width : Nat}
    {formulas : SourceGuards.Formulas FullSyntax.Formula}
    {solver : SourceGuards.Entailment FullSyntax.Formula} {inventory : Inventory}
    (p h budget : Nat) (query : Node) (before : Caller width) (memos : EndpointMemoGateTrace.Memos)
    (context : Context formulas solver inventory before memos)
    (available : Available before.checked.native.machine.heap query) (closed : query.free = []) :
    let actual := SourceCurrentAllocatedConjunctionWorker.call p h budget query before.checked before.fourth
    match actual with
    | .done _ _ _ => True
    | .failed _ after saved => SourceCurrentEmptinessMemo.Correct formulas solver after.native.machine.heap saved := by
```

