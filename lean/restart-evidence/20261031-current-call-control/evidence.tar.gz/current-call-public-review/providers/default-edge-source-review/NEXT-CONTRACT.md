# Required actual canonical edge producer

Status: specification only. UNIMPLEMENTED and UNELABORATED. This is not a theorem header or a new admission rule.

Construct the getter that the actual default or weighted initializer installs. Take the actual original root and original operational weight choice. Compute the literal reachable table and canonical-class row ordering. Retain the actual captured-root lookup, the per-node fallback, and the optional stable weight sort. Model the memo with its actual Node key equality. Do not accept an arbitrary row callback or a graph with supplied correct rows in place of this construction.

Derive these facts internally:

1. Every inserted ordinary source node has its actual complete rows attached to its issued identity. Every skip preserves the established binding. The pending list uses the actual rows' children. Do not assume a future visited-node or membership certificate.
2. For the actual current ordinary decoded parent, a captured-root hit identifies the same complete parent rows. Derive this from current native readback, identity/key reservation, and preserved old records. If the initial and current heaps differ, prove the required retention through the actual effects. Do not accept the desired row equality as an input.
3. A fallback starts from the current node and preserves its first root binding. Its memo meaning follows from actual empty origin, actual insertKeepingFirst operations, and a function that respects the source Node equality. Preserve all pre-existing valid entries through the actual history. Do not accept a future MemoValid supplier.
4. Each sort permutes the complete input EdgeValue list. Preserve edge constraint, child list, label, and multiplicity. Do not replace full edge payloads with canonical comparison keys. Canonical-class correctness for ordering does not itself identify the source rows.

The output for an actual ordinary selection must include permutation of the complete rows returned by the concrete getter with InternedEdgeResidency.nodeEdges of that exact decoded parent. It must hold for both captured hits and fallback results, and for the actual default and weighted choices. Its source and target nodes are the actual values read or constructed by the program.

Use the existing actual entry and fold operations to identify the selected row. Derive literal parent-row membership from the produced permutation and the actual fold head/tail. Compose the existing current KnownOrdinary target and actual EdgeInputs.children observations to derive the child's ordinary domain, strict parent-to-child height decrease, and the inherited common cap. Do not add a new height premise. Do not infer a node certificate for a None slot.

Retain the actual raw entry outcomes, nonterminal test, query and constructor gates, and unsupported cases. A source-order adapter does not eliminate terminal aliases, reset steps, opaque renewals, or native worker failure. Keep the Prepared worker route separate. Do not claim a global worker bound or full caller progress from this local result.

If an ordinary initial root is needed, derive it from the actual original producer. Otherwise retain the source Mu/Union exposure in the graph construction. Do not silently replace the original input family with a convenient finite graph or with all current heap nodes.

The sorting key can remain a parameter of a separate sorting-permutation lemma. That lemma is only a component. The actual default getter must compute its own key and graph, and must retain the actual cached lookup choice. Do not identify the component with the full source getter without that construction.
