Source-only default/weighted canonicalEdgesOf review. No compiler, evaluator, Haskell/native execution, Git, network, board, production edit, or spawn. No OLD whole path is reserved yet. Use bounded named cuts and count exact ORIGINAL-path unions, including reuse. Retain all acquired payloads and private provider closure. At most140 new source lines.

Final scope: no OLD whole or near-whole acquisition was needed. No new Lean source was written. Exact source map and required construction are retained instead of a false default/weighted specialization.
