# Default and weighted edge source

The actual default producer sorts complete edge lists. A faithful origin proof must connect its captured graph and memo entries to the complete rows of the current ordinary parent. Sorting alone does not supply that connection.

This bounded review does not supply a complete default or weighted adapter. No new Lean draft was written. Replacing the getter with a sort of the current parent's rows would bypass the actual captured lookup and memo. Such a replacement is not justified by this review.

The prior 93-line interned-order draft remains unchanged. This review does not establish Haskell correspondence, arbitrary narrowing callback safety, global worker progress, or an original-input depth bound. No Haskell defect, edit, or fix was established. There is no fix to add to FINDINGS.

## Exact producer

| Current original source | Operation |
| --- | --- |
| `Enumeration.hs:1246` | `runs` installs `canonicalEdgesOf Nothing` |
| `Enumeration.hs:1256` | `runsBy` installs `canonicalEdgesOf (Just weight)` |
| `Enumeration.hs:1289-1294` | `runsFrom` initializes the stored edge function with the actual original root |
| `Enumeration.hs:674-684` | `canonicalOrder root` sorts each whole row list from `reachable root`; it computes the comparison keys from edge shape and child canonical classes |
| `Enumeration.hs:689` | `byWeight` applies stable descending weight sorting |
| `Enumeration.hs:700-702` | `canonicalEdges` memoizes the root's row lookup in its own canonical order |
| `Enumeration.hs:708-718` | `canonicalEdgesOf` first looks up the current identity in the captured root table; on a miss it uses the memoized fallback, then the optional weight sort |
| `Interned.hs:204-216` | `reachable` starts from an empty map; it skips EmptyNode; it skips an already stored identity; otherwise it inserts literal `nodeEdges node` and visits those rows' children before the pending tail |
| `Interned/Type.hs:289-296` | Ordinary Node equality compares the interned identity; other constructors have their own equality cases |
| `Interned/Type.hs:321-330` | Node hashing uses the identity and constructor-specific cases |
| `Interned/Type.hs:362-367` | `nodeIdentity` exposes the stored identity; an integer Rec reference also exposes its identity |
| `Interned/Type.hs:452-478` | Typed node caches share the identity supply; ordinary identification stores the source edge list in the identified node |
| `Interned/Memo.hs:79-128` | The typed memo family selects the symbol-specific table and invokes `insertKeepingFirst` on the actual Node argument |
| `Interned/Cache.hs:142-180` | Cache hits return the stored value; insertion retains the first value; interning attaches a fresh identity for a new uninterned key |

The source documentation requires a weight that is not NaN. This review retains that original API condition.

The source has two different key spaces. `reachable` and the captured root table use bare NodeId integers. The fallback memo uses Node keys and their constructor-sensitive equality. A faithful model must preserve this distinction.

For an uncached fallback whose root is an ordinary nonempty node, the first traversal insertion is its own literal row list. Later traversal steps do not overwrite that identity. This gives a useful direct route for that branch. It does not discharge a captured-root hit or an earlier memo hit.

The captured-root hit needs identity-to-row coherence between an earlier source node and the current decoded node. A new filtered/intersection node may use the fallback; an already interned node may hit an existing entry. The proof must cover the actual choice. It must derive row equality from the actual allocation, readback, and retained history. The caller must not supply the desired equality.

For memo hits, the function value must respect the actual Node equality and remain stable for the preserved node. The dedicated cache starts empty and stores this function's values. The proof must derive the memo meaning through those actual operations. It must not assume a future correct table.

## Existing formal primitives and limits

`CanonicalClasses.Graph` has a finite complete identity domain and a supplied `rows` function. It does not construct the actual `reachable` traversal or the captured root table. `final_sorted_rows_rename` compares sorted projected edge-key sequences. That conclusion does not identify complete EdgeValue payloads. Different edges can share a canonical comparison key.

`Cache.MemoValid`, `keepFirst_memo`, and `memo_correct` provide the generic memo invariant and preservation step. They can support the missing producer. The actual canonical cache must derive this invariant from its origin and operations. Adding MemoValid as a replacement caller gate would leave that work undone.

`SymbolicCanonicalOrder.memo_canonical` concerns ordered pairs for a binary operation. It assumes a valid memo table. It is not an implementation of the enumeration getter. Its `stored_payload_same` law identifies exact interned payload keys from a valid intern table and equal identities. A complete decoded-row readback still has to connect that key result to the current parent's actual rows.

The inspected native Ready contract carries semantic heap, coverage, and depth facts. Native `Cache.Valid` ties identities to issued payload keys. Those are useful current-state facts. They do not themselves return the captured canonical graph or its memo history.

Three similarly named operations must remain separate. Haskell `Enumeration.canonicalEdges` is the memoized canonical-class ordering fallback. Lean `InternedConstructorTemplates.canonicalEdges` orders and removes duplicate edge identities for node construction. `SymbolicCanonicalOrder` normalizes a pair of operand identities. None can replace another by name.

`canonicalOrder` and `byWeight` retain complete edge payloads and list multiplicity. An eventual adapter must prove permutation of the current parent's full row list, not equality of projected key sets. It must not use `sortedSet`, which removes duplicates, as the enumeration row sorter.

## Required next construction

`NEXT-CONTRACT.md` gives the exact missing producer contract. It requires the actual generated graph, captured lookup, and memo branches. It derives complete parent-row origin internally. It then composes the existing actual child-input grade route. It adds no callback equality, row membership, height certificate, or future completion supplier.

The source getter handles Mu and Union through the actual `nodeEdges` operations. The row-origin target is an ordinary current parent. A proof must retain all original roots admitted by the driver. If it uses an ordinary initial-root specialization, that property must come from the actual original constructor packet. It cannot be a new root-admission condition. General native/prepared worker coverage remains open.

## Evidence and scope

All returned source cuts and declaration lines were fully read. Exact original paths, full source hashes, copy hashes, and original line vectors are in `acquisitions.json`. Cumulative original-path unions are in `OLD-SOURCE-UNIONS.json`. Source use from the prior task is counted again at the original paths. No private provider was copied. This review reacquired exact current original-source cuts; the prior frozen bundle remains Root-owned and unchanged.

No OLD whole or near-whole source was acquired. No such path needed reservation. The authoritative corrected ledger and its exact replay pass. A requested Memo.hs cut ended at line130 although that file has128 lines. Python retained the actual available bytes; the initial metadata vector overstated that endpoint. The corrected vector is93-128. The failed metadata predecessor and recovery are retained. No source bytes were changed.

There was no compiler, evaluator, Haskell/native execution, Git, network, board, production edit, or spawn. No public proof readback was generated. The result is a source-grounded construction boundary, not a new checked theorem.
