#!/usr/bin/env python3
"""Verify retained bytes and source vectors. Do not run Lean or modeled workers."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
LIVE = '--live' in sys.argv
INDEXES = {'MANIFEST.json', 'PINS.json'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

records = json.loads((ROOT / 'acquisitions.json').read_text())
summary = json.loads((ROOT / 'source-unions.json').read_text())
unions = {}
for record in records:
    payload = (ROOT / record['copy']).read_bytes()
    assert sha(payload) == record['copy_sha256']
    assert record['read_status'].startswith('complete')
    vector = record['actual_lines']
    assert vector == sorted(set(vector))
    assert all(1 <= index <= record['source_lines'] for index in vector)
    lines = payload.splitlines(keepends=True)
    assert len(lines) == len(vector)
    if record['copy_format'] == 'numbered-lines':
        assert all(line.startswith((str(index) + ':').encode()) for index, line in zip(vector, lines))
    else:
        assert record['copy_format'] == 'plain-source-lines'
        assert sha(payload) == record['source_sha256']
        assert len(payload) == record['source_bytes']
    unions.setdefault(record['source_path'], set()).update(vector)
    if LIVE:
        source = Path(record['source_path']).read_bytes()
        assert len(source) == record['source_bytes'] and sha(source) == record['source_sha256']
        source_lines = source.splitlines(keepends=True)
        assert len(source_lines) == record['source_lines']
        expected = b''.join((b'' if record['copy_format'] == 'plain-source-lines' else (str(index) + ':').encode()) + source_lines[index - 1] for index in vector)
        assert payload == expected
assert summary['source_acquisitions'] == len(records)
assert summary['original_paths'] == len(unions)
assert summary['all_unique_semantic_lines'] == sum(map(len, unions.values()))
wholes = []
for source in summary['sources']:
    assert source['actual_lines'] == sorted(unions[source['source_path']])
    assert source['semantic_union_lines'] == len(source['actual_lines'])
    if source['old'] and source['whole']:
        wholes.append(source['source_path'])
        assert len(source['actual_lines']) == source['source_lines']
    elif source['old']:
        assert 2 * len(source['actual_lines']) < source['source_lines']
assert wholes == summary['old_whole_original_paths'] and len(wholes) == 2
for record in json.loads((ROOT / 'metadata-inputs.json').read_text())['files']:
    data = (ROOT / record['copy']).read_bytes()
    assert len(data) == record['bytes'] and sha(data) == record['sha256']
    if LIVE:
        assert Path(record['original_path']).read_bytes() == data
for version in json.loads((ROOT / 'draft-versions.json').read_text())['versions']:
    data = (ROOT / version['file']).read_bytes()
    assert len(data) == version['bytes'] and len(data.splitlines()) == version['lines']
    assert sha(data) == version['sha256'] and version['status'] == 'UNCOMPILED'
provider = json.loads((ROOT / 'provider-closure.json').read_text())
manifest = (ROOT / 'metadata' / 'rows-provider-MANIFEST.json').read_bytes()
pins = (ROOT / 'metadata' / 'rows-provider-FROZEN-PINS.txt').read_bytes()
assert sha(manifest) == provider['provider_manifest_sha256']
assert sha(pins) == provider['provider_pins_sha256']
provider_rows = json.loads(manifest)['payloads']
assert len(provider_rows) == provider['provider_payloads']
if LIVE:
    owner = Path(provider['provider_path'])
    expected = {row['path'] for row in provider_rows}
    actual = {str(f.relative_to(owner)) for f in owner.rglob('*') if f.is_file()}
    assert actual - {'MANIFEST.json', 'FROZEN-PINS.txt'} == expected
    for row in provider_rows:
        data = (owner / row['path']).read_bytes()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
indexes = []
for name in sorted(INDEXES):
    path = ROOT / name
    if not path.exists():
        continue
    index = json.loads(path.read_text())
    assert sorted(index['files']) == sorted(index['pins'])
    for relative in index['files']:
        data = (ROOT / relative).read_bytes()
        assert len(data) == index['pins'][relative]['bytes']
        assert sha(data) == index['pins'][relative]['sha256']
    actual = sorted(str(f.relative_to(ROOT)) for f in ROOT.rglob('*') if f.is_file() and f.relative_to(ROOT).as_posix() not in INDEXES)
    assert actual == sorted(index['files']), name
    indexes.append(index)
if len(indexes) == 2:
    assert indexes[0]['files'] == indexes[1]['files']
    assert indexes[0]['pins'] == indexes[1]['pins']
print(json.dumps({'status': 'PASS', 'live_replay': LIVE, 'source_acquisitions': len(records),
                  'original_paths': len(unions), 'old_whole_original_paths': len(wholes),
                  'old_unique_semantic_lines': summary['old_unique_semantic_lines'],
                  'all_unique_semantic_lines': summary['all_unique_semantic_lines'],
                  'compiler_or_product_execution': 0}))
