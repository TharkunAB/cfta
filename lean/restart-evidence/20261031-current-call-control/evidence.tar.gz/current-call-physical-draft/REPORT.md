# Actual current explore and call effects

Status: SOURCE ONLY. UNCOMPILED next-phase candidate.

The final candidate is SourceCurrentConjunctionWorkerEffects-v3-UNCOMPILED.lean.
It has 155 lines and four public proposed laws.
No compiler or source evaluator was run in this owner.

## Proposed result

explore_effects follows the actual current worklist.
Its inputs are current SemanticHeap, Covered [], and closed available values in the pending groups.
Its table is arbitrary.
Its projection, reader, and algorithmic budgets are arbitrary.
Every actual outcome retains SemanticHeap and Covered [].
Every actual outcome derives constructor Grows and issued-node Extends from the initial heap.
No completed-run premise, future row certificate, Trace, Post, or table meaning is supplied.

The recursive proof uses the exact source measure: algorithmic budget and pending-list length.
The empty pending list returns the current state.
The any-empty branch drops the head without changing the heap or budget.
The skip branch also drops the head without changing the heap or budget.
The completed-row branch takes all newly generated groups from rows_effects.
It transports the old pending suffix through the actual row heap growth and history.
It recurses at budget - 1 and the literal returned physical state.
The existing source admission test proves that this budget was positive.
The failed-row branch retains the actual failed-row heap.
The proof composes growth and history after the recursive call.

The prerequisite rows producer follows CURRENT RowsWorker, CurrentConjunctionEquality, and ProjectionWorker.forest.
It does not use SharedTarget or ClassFold as a replacement route.
The historical 182-line rows draft is retained unchanged.
Root then reported a strict-passing 186-line isolated repaired rows source.
Only its exact six-line public rows_effects header was acquired from that repair.
Root's reported probe status is not a production-install or independent check claim by this owner.

## Decision, call, and allocated call

decision_effects uses the actual explore producer internally.
The body-guard false branch preserves the input physical state.
The true branch starts with the actual singleton pending group.
An exploration failure retains its reached heap.
Both fixed-point outcomes retain the actual explored heap, including grow failure.
No equality-cache correctness or table interpretation premise is added.

call_effects uses the actual memo lookup first.
A memo hit retains the identical physical state.
A miss uses decision_effects and keeps the actual success or failure heap.
The current cold premises are SemanticHeap, Covered [], Available query, and query.free = [].
There is no ordinary-only, native admission, or output-state premise.

allocated_call_effects follows both literal allocated wrapper branches.
Its heap is the actual checked endpoint's native.machine.heap.
It unfolds advancePhysical and uses its constructor heap projection.
It does not substitute the initial checked state for a failed physical endpoint.
No statement about equality-cache validity, fourth-memo semantics, full Context, or Post follows from these heap-only results.

## Type scope and retained versions

V1 has 130 lines. It proposes explore, decision, and call.
V2 has 156 lines. It adds the allocated wrapper result.
Both original drafts have an abstract Symbol and explicit equality-instance binders.
They were never compiled.

Root's isolated rows probe showed that the checked forest producer uses the actual runtime Symbol.
V3 specializes explore and decision to SourcePruningTemplates.Symbol.
Formula remains generic for those two laws.
Call and its allocated wrapper use the actual current Symbol and FullSyntax.Formula.
V3 removes proof-only explicit equality binders and uses scoped Classical synthesis.
This changes the proposed type scope to the actual runtime API.
It does not add a runtime condition or an ordinary-domain restriction.
No typed equivalence with the original uncompiled generic drafts is claimed.
The cold physical predicates and all-outcome result shape stay the same.

## Remaining scope

Root must kernel-check this candidate and its dependency before any installation claim.
The recursive equation rewrite, decreasing proof, Classical instance alignment, and allocated heap projection remain subject to that check.
No table soundness, guard equality validity, native cache admission, language equivalence, or Haskell correspondence is proved here.
No Haskell defect, edit, or fix is established.

The fixed-original-D induction for BOTH workers remains open.
So do full Post, current admissions, original reservation lineage, captured sibling transport, and original resource sufficiency.
Generic Mu/Union/opaque behavior remains in the full goal.
These heap-only cold gates do not restrict operands to ordinary nodes.
Public ordered prefixes and default/weighted Haskell getter correspondence remain open.
The R20 five-module checked checkpoint is unchanged by this future owner.

## Acquisition and closure

The only complete OLD originals are CurrentConjunctionWorker108 and AllocatedConjunctionWorker105.
All other OLD source acquisitions are named bounded runtime cuts or declaration locators.
The attempted NativeDemand advance locator acquired no semantic source line.
The cumulative original-path unions include every reused line.
No OLD source body from the provider's historical private cuts was redisplayed or reused.
The complete provider remains frozen and is retained whole by Root.
Its 194 payload hashes and exact 196-file tree were independently byte-verified here.
Every consulted provider metadata copy has an exact original path and hash.
This owner preserves the original182, all three new drafts, all helper failures, and the repaired public dependency header.
