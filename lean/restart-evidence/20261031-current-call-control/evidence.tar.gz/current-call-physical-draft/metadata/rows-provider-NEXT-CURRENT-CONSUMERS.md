# Next current consumers

HEADER ONLY. UNIMPLEMENTED. UNELABORATED. These are exact next targets, not proved statements.

Use the current SourceCurrentConjunctionWorker aliases. Heap means the constructor heap in Physical. Symbol and Guard have their concrete current meanings for call.

```lean
theorem explore_effects
    (p h budget : Nat) (table : Table Symbol Formula)
    (pending : List (List (Value Symbol (SourceSymbolicIndex.Constraint Formula))))
    (before : Physical Symbol Formula)
    (semantic : SemanticHeap before.heap) (covered : Covered [] before.heap)
    (inputs : ∀ nodes ∈ pending, Values before.heap nodes ∧ ClosedValues nodes) :
    let actual := SourceCurrentConjunctionWorker.explore p h budget table pending before
    SemanticHeap actual.state.heap ∧ Covered [] actual.state.heap ∧
      Grows before.heap actual.state.heap ∧
      Extends before.heap.nodes.issued actual.state.heap.nodes.issued
```

The source recursion follows its existing budget and pending-length measure. Derive the remaining pending groups and actual newly returned groups from rows_effects inside that recursion. Keep the empty, any-empty, skip, failed-row, and completed-row branches. Do not require the initial table to describe a future exploration trace. Table meaning is outside this heap-only target.

```lean
theorem call_effects
    (p h budget : Nat) (memo : SourceCurrentEmptinessMemo.Memo)
    (query : Node) (before : Physical Symbol FullSyntax.Formula)
    (semantic : SemanticHeap before.heap) (covered : Covered [] before.heap)
    (available : Available before.heap query) (closed : query.free = []) :
    let actual := SourceCurrentConjunctionWorker.call p h budget memo query before
    SemanticHeap actual.state.heap ∧ Covered [] actual.state.heap ∧
      Grows before.heap actual.state.heap ∧
      Extends before.heap.nodes.issued actual.state.heap.nodes.issued
```

The call target consumes the proven explore producer internally. It handles memo hits, body guard rejection, table-grow failure, and both actual outcomes. The allocated call adapter then uses its literal physical endpoint. Old physical lookup follows from actual constructor growth/history. The exact old-cache consumer is the preserved failed_call_lookup target. No language-equivalence replacement is sufficient for that consumer.

No future Post, Trace, failure witness, rows-effects supplier, native admission, or completed run belongs in these public headers. The ordinary-only original input condition may remain in the outer existing consumer, but the proposed heap-effect targets do not use it.
