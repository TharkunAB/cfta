# Incidents

Three guessed declaration-locator filenames were absent: MergedColdReaderReadiness.lean, SourceRecursiveIntersectionCompileReadiness.lean, and MergedReaderReadiness.lean. Their locator commands returned exit2. No body was acquired from those paths. An exact SemanticReady declaration locator found SourceEqualityRequiredSemanticCache.lean.

The closed/edge locator used a broad regex. It matched proof lines in MergedColdReaderClosedInputs and InternedEdgeResidency. Those exact payloads and cumulative vectors remain retained. No further body from those originals was acquired. This was broader than needed. It is a source-scope incident. The precise union is in ORIGINAL-FILE-UNIONS.json.

The existing canonical_values theorem needs SemanticReady. The candidate instead derives the forward canonical membership fact from the literal map. It does not add SemanticReady to its public admission. The unused current SemanticReady/header explorations remain retained.

V1 was not checked. Source review found two avoidable proof risks: a cons branch used a semicolon before subst, and a combined failure case left a fault placeholder. V2 uses explicit branches and a direct failure constructor. Both complete versions remain retained. No compiler or evaluator was used.
