# Actual current rows effects

Status: SOURCE ONLY. UNCOMPILED future phase. One public law is proposed.

Final source: SourceCurrentConjunctionRowsWorkerEffects-v2-UNCOMPILED.lean. It has182 lines and SHA638e24e6a986c5a27ef2fd531ed2fee27254d7d9cb2348049e8a8e2926c1c0b4.

## Proposed statement

For the actual CurrentConjunctionRowsWorker.rows call, current SemanticHeap, Covered[], available operands, and closed operands derive semantic heap, coverage, constructor growth, and issued-node history at every exposed outcome. An actual done result also has closed available values in each returned requirement row. The projection and read bounds remain arbitrary. No ordinary-only operand restriction is added.

## Actual composition

The private finite-list inductions follow projections, exposures, classes, requirements, tuple, tuples, and rows. The physical state includes the equality-operation cache. The Verified record indexes the initial constructor heap. This permits literal equality-cache updates without a fictitious constructor effect.

Actual forest calls use checked225 public forest_effects. Actual node exposures use MergedFreshOrdinaryColdEffects.nodeEdges_verified. That public law covers the actual reached heap on exhaustion. Its closed, covered inputs exclude pending and unresolved observations. The candidate eliminates only those impossible exposure branches from the actual certificate; it does not hide their state. Forest pending, unresolved, and exhausted branches retain the actual returned heap.

The tuple equality fold retains before.heap on every return. Its error and missing-equality returns therefore use the same heap certificate. No validity, completeness, or source meaning of an arbitrary equality-operation cache is claimed. The public heap law does not require a stronger equality cache gate.

Actual jobs derive their available closed forests from current tuple children and the literal jobs_inputs producer. Actual columns use the existing columns_member producer. Actual tuple edges derive from tuples_members and the completed exposure rows. Old forest and edge inputs move through actual growth and issued history.

The existing canonical_values theorem requires SemanticReady. That stronger premise is unnecessary for the forward value certificate here. The candidate follows the literal canonical constructor. The empty branch returns the available closed empty value. The map branch uses lookup_of_mem, fromList_ascending, and fromList_origin to derive membership in the original available closed values. It does not assume faithful keys, unique values, or future source semantics.

## Proof status

No compiler, evaluator, native run, Haskell run, or proof check was performed. The complete V1 and V2 source files remain retained. V2 addresses two source-level elaboration risks found in V1. It does not change the public header. Root owns strict/default checks and any installation. Classical and instance elaboration at the public forest API remains subject to Root checking. No new runtime instance gate was intended.

The checked dependencies have exact full-source pins in acquisitions.json. Project225 SHA8ff865b0ae105396936c4c2ce139f60447d63cfff025acfba7763fe204d8ddc5 and physical149 SHAfc822fb9dfa82fee735de9578f4b44115df1907b95cb2ac39e237136efff69ad are Root-reported checked artifacts. The candidate calls no private helper from either module.

## Next actual boundary

No explore, decision, call, failed_call_lookup, or old-cache Known corollary was added. The next physical explore law needs current closed available pending groups and the actual rows producer. Its internal induction must carry the unprocessed groups through actual heap growth and admit every newly returned requirement from the actual completed rows result. The public header must not take a future rows certificate.

A successful/failed physical call can then use the actual decision and memo branches. The allocated wrapper exposes advancePhysical's reached heap. No raw Native/NativeDemand or legacy SharedTarget/ClassFold substitution is involved. Exact next contracts are in NEXT-CURRENT-CONSUMERS.md.

These heap facts do not prove that native cache admission, original sufficient capacity, worker progress, finite requested prefixes, public API correspondence, or Haskell correspondence hold at later operations. Both-worker and Mu/Union/opaque scope stays explicit. No Haskell defect or fix was established.

## Source scope

The named complete OLD originals are RowsWorker119L and CurrentConjunctionEquality213L. Every other source acquisition is bounded. Original-path unions include all repeated locator lines. No third near-whole source was acquired. The broad closed/edge locator incident remains recorded, including its exact vectors. No Nodes or RequiredCache body was acquired.
