from pathlib import Path
import json
p=Path('/tmp/mcfta-current-call-physical-review-20261031');q=Path('/tmp/mcfta-current-rows-physical-review-20261031');m=json.loads((q/'MANIFEST.json').read_text());print('PROVIDER KEYS',list(m));print('ROOT FILES',[x.name for x in q.iterdir() if x.is_file()]);print('DRAFT CANDIDATES',[x for x in m['files'] if x.endswith('.lean')]);print('METADATA COPIED',[x.name for x in (p/'metadata').iterdir()])
