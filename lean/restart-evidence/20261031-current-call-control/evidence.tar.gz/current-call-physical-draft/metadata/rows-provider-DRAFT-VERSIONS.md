# Draft versions

V1:176L16685B SHA62fc34bcedad02ecc9571da088dc953a32058834ebb06c42ac671d431a4e3493. Uncompiled.

V2:182L16642B SHA638e24e6a986c5a27ef2fd531ed2fee27254d7d9cb2348049e8a8e2926c1c0b4. Uncompiled. The public header is unchanged. It uses explicit cons equality branches and direct failure constructors.

No failed compiler output exists in this owner. No code was evaluated. Source-only concerns are retained in INCIDENTS.md and REPORT.md.
