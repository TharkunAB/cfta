from pathlib import Path
import hashlib,json
p=Path('/tmp/mcfta-current-call-physical-review-20261031');p.mkdir();(p/'inputs').mkdir();(p/'cuts').mkdir();(p/'metadata').mkdir();H=lambda b:hashlib.sha256(b).hexdigest();rs=[]
for n in ['SourceCurrentConjunctionWorker.lean','SourceCurrentAllocatedConjunctionWorker.lean']:
 f=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')/n;b=f.read_bytes();ls=b.splitlines(keepends=True);q=p/'inputs'/n;q.write_bytes(b);rs.append({'source_path':str(f),'source_sha256':H(b),'source_bytes':len(b),'source_lines':len(ls),'actual_lines':list(range(1,len(ls)+1)),'copy':str(q.relative_to(p)),'copy_sha256':H(b),'copy_format':'plain-source-lines','classification':'Named OLD whole worker original, named before acquisition','read_status':'acquired; pending full read'});print(n,len(ls),len(b),H(b));print(b.decode())
(p/'acquisitions.json').write_text(json.dumps(rs,indent=2)+'\n')
q=Path('/tmp/mcfta-current-rows-physical-review-20261031');a=[]
for n in ['NEXT-CURRENT-CONSUMERS.md','MANIFEST.json','PINS.json']:
 f=q/n;b=f.read_bytes();c=p/'metadata'/('rows-provider-'+n);c.write_bytes(b);a.append({'original_path':str(f),'copy':str(c.relative_to(p)),'bytes':len(b),'sha256':H(b),'semantic_kind':'task specification' if n.endswith('.md') else 'provider metadata'})
(p/'metadata-inputs.json').write_text(json.dumps({'files':a},indent=2)+'\n')
