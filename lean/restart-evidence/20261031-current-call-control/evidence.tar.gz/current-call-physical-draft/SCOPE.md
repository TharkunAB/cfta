# Bounded next-phase source-only task

The two OLD whole original paths were named to Root before acquisition:
- /home/tritlo/Code/mcfta/lean/MicroCFTA/SourceCurrentConjunctionWorker.lean
- /home/tritlo/Code/mcfta/lean/MicroCFTA/SourceCurrentAllocatedConjunctionWorker.lean

All other OLD bodies use named bounded cuts or locators. Cumulative unions use ORIGINAL paths.
The 182-line provider draft is NEW and explicitly permitted whole.
The repaired isolated dependency is acquired only at its public header.
No compiler, evaluator, native, Haskell, Git, network, board, production change, child spawn, or external communication occurs here.
The four proposed laws are UNCOMPILED. Root owns all checks and installations.
Both workers and all original resource, Post, public, generic, and Haskell boundaries remain in the full objective.
Root warned about a prior basename-based manifest exclusion. This owner excludes only its two ROOT index files.
Its MANIFEST and PINS index the same complete payload set, including every nested manifest and pins payload.
