# Proposed public contracts

SOURCE ONLY. UNCOMPILED. Namespace: MicroCFTA.SourceCurrentConjunctionWorkerEffects.

explore/decision: concrete SourcePruningTemplates.Symbol; Formula : Type remains generic.
call/allocated: concrete SourcePruningTemplates.Symbol and FullSyntax.Formula.
No explicit DecidableEq hypothesis is proposed. Scoped Classical supplies proof synthesis.

```lean
theorem explore_effects (p h budget : Nat) (table : Table Symbol Formula)
    (pending : List (List (Value Symbol Guard))) (before : Physical Symbol Formula)
    (semantic : SemanticHeap before.heap) (covered : Covered [] before.heap)
    (inputs : ∀ nodes ∈ pending, Values before.heap nodes ∧ ClosedValues nodes) :
    let actual := SourceCurrentConjunctionWorker.explore p h budget table pending before
    SemanticHeap actual.state.heap ∧ Covered [] actual.state.heap ∧
      Grows before.heap actual.state.heap ∧
      Extends before.heap.nodes.issued actual.state.heap.nodes.issued := by
```

```lean
theorem decision_effects (p h budget : Nat)
    (query : Value Symbol Guard) (before : Physical Symbol Formula)
    (semantic : SemanticHeap before.heap) (covered : Covered [] before.heap)
    (available : Available before.heap query) (closed : query.free = []) :
    let actual := SourceCurrentConjunctionWorker.decision p h budget query before
    SemanticHeap actual.state.heap ∧ Covered [] actual.state.heap ∧
      Grows before.heap actual.state.heap ∧
      Extends before.heap.nodes.issued actual.state.heap.nodes.issued := by
```

```lean
theorem call_effects (p h budget : Nat) (memo : Memo) (query : Node) (before : Physical)
    (semantic : SemanticHeap before.heap) (covered : Covered [] before.heap)
    (available : Available before.heap query) (closed : query.free = []) :
    let actual := SourceCurrentConjunctionWorker.call p h budget memo query before
    SemanticHeap actual.state.heap ∧ Covered [] actual.state.heap ∧
      Grows before.heap actual.state.heap ∧
      Extends before.heap.nodes.issued actual.state.heap.nodes.issued := by
```

```lean
theorem allocated_call_effects {width : Nat} (p h budget : Nat) (memo : Memo)
    (query : Node) (before : SourceEqualityNativeDemand.State width)
    (semantic : SemanticHeap before.native.machine.heap)
    (covered : Covered [] before.native.machine.heap)
    (available : Available before.native.machine.heap query) (closed : query.free = []) :
    let actual := SourceCurrentAllocatedConjunctionWorker.call p h budget query before memo
    SemanticHeap actual.state.native.machine.heap ∧ Covered [] actual.state.native.machine.heap ∧
      Grows before.native.machine.heap actual.state.native.machine.heap ∧
      Extends before.native.machine.heap.nodes.issued actual.state.native.machine.heap.nodes.issued := by
```

