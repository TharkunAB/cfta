# Metadata helper failures

Three metadata helpers failed. No frozen source or provider was changed.

1. The first acquisition helper assumed a PINS.json provider name. The actual provider uses FROZEN-PINS.txt. The helper copied both complete worker sources and wrote their ledger, then stopped on FileNotFoundError. The source reads succeeded. The metadata ledger was recovered from exact retained copies.
2. The metadata discovery helper assumed a files manifest key. The provider manifest uses payloads with path/bytes/sha256 entries. It stopped on KeyError after displaying the root metadata filenames. Recovery read the explicit payloads schema.

The final verifier uses the actual provider schema. All failed helper programs and error records are retained. No compiler, source evaluator, or product command was run.

3. The advance helper assumed an exact def advance declaration in NativeDemand. It found no such declaration and stopped on AssertionError before writing a source cut. The recovery locator also found no alias declaration. It retains an empty exact vector. No NativeDemand source body was semantically read. The allocated proof uses the literal advancePhysical projection and remains subject to Root checking.

Root later reported an isolated rows dependency probe failure and repair. Those compiler commands and diagnostics belong to Root. This owner did not run them or acquire their log bodies. The original182 and repaired public header are retained separately.

The prior basename-exclusion warning is recorded in index-policy-context.json. The new indexes use full relative paths and exclude only the two root index files.
