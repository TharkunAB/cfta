# Original query profiles across generator histories

Status: SOURCE-ONLY AUDIT. No new proof candidate is supplied.

## Main result

The checked sources provide two real finite results.
First, one admitted query has an all-runtime-fuel Mu-degree bound derived from its own original caller admission.
Second, a supplied finite recursive capacity has an original numeric planner that constructs its actual finite producer.
The missing connection is a uniform bound at every actual query entry in the whole generator invocation, including preceding siblings and callbacks that return no output.
A finite original physical source closure is sufficient for some restricted query streams.
It is not required for every fixed-capacity generator proof.
No obstruction to such a fixed-capacity bound was established.

Operational scope correction: seven whole Lean sources were reviewed against a requested limit of six.
An intended cut of the82-line InventoryRebase file reached EOF.
Parent was notified as soon as this was counted.
No later whole source was acquired.
All identities and literal reviewed ranges are retained in the manifest.

## What is already derived

`IncomingQuery.native_prefix_bounded` takes the query's original Context, operand availability and closedness, Fits profile, and Room bits profile.
It derives a completed physical query receipt from those inputs.
Its `Trace.prefix_bounded` then derives one bound for every runtime fuel of that same query.
The completed trace is produced internally; it is not an extra future-trace input to this public theorem.
The existential degree bound still depends on that particular admitted query.
It is not a uniform bound over later generator entries.

`OriginalForecast.cost_le` derives an ordinary alternative scan cost from the supplied original heap profile, finite guard alphabet, selected-edge membership/length policies, and inherited suspended-bucket length.
The conclusion is a numeric scan-cost bound, not a theorem counting every query made by the recursive generator.
Its current-heap HeapFits premise is derived from Fits by `RequiredResources.of_checked` at a properly attached original caller.
Calling it independently at future callers without that attachment would move the missing resource proof into a premise.

`PreparedReservation.final D seed ceiling` is computed from an original seed, original suspended-mass ceiling, and supplied recursive capacity D.
`preparedSeed` also pays actual native normalization.
`Reserved` recursively plans the incoming and smaller-depth callback entries.
`reserved_computed` computes a mathematical word width from this complete finite forecast.
The width depends on D through final.
It is not a width or global resource bound derived before the sufficient D is known.

`PreparedRecursive.Complete` and `CompleteWithHistory` retain original Packet, Fits, annotation Heap, selected-edge membership/length policies, initial suspended-mass bound, and this original reservation.
They derive their common stable work bound and outcome.
They do not merely assume future endpoint Fits.
This genuinely covers fixed-capacity producer work.
It does not establish an original-model-derived sufficient recursive capacity or a global query-entry bound for arbitrary larger capacities.

## Fixed-source finite families

`SourceRecursiveIntersectionInputInventory.inventory` is a finite tagged carrier computed from one fixed source.nodes.next.
`inventory_available` and `OriginalInput.inventory` derive membership from actual source availability and complete encoding.
`SourceInventory.names`, `pairs`, and `domains` derive finite binder and domain carriers from the same original issued counter.
`OriginalSupport` preserves literal source support through bodies, ordinary children, union members, joined rows, domain entry, and reference readback within a native query.
These are existing source theorems. A new wrapper would duplicate them.

`StaticQueries.complete_many` constructs every supplied finite list whose operands all remain Available in that same fixed source.
Its own documentation states that using new returned values as later operands needs a larger source proof.
It cannot cover arbitrary actual generated operands by identifying the old source with the current heap.

`FiniteOrdinaryKeys` is restricted to its explicit ordinary domain: Empty and ordinary nodes with recursively certified ordinary children.
It has no Mu or Union node constructor.
`of_available` also requires current counter bounds and the finite ordinary domain certificate.
It does not derive a global generated-Mu operand family from the initial model.
The filename is not evidence of such a family.

## Actual rebasing and generated operands

`InventoryRebase.extend` sets its source to the actual current target heap and appends the two current operands to the roots.
It derives their Original status at that new heap from actual closedness and coherence.
`rebase` preserves old semantic/cache admission and gives valid new input roots.
It supplies no equality between the current source and the first source, no fixed initial counter bound, and no fixed initial source membership for the new roots.

`IncomingQuery.complete_resources` exposes this exact behavior: next.source equals the actual pre-query heap and next.roots equals old roots plus both operands.
The generated native resources producer uses the same concrete rebase.
Thus Original at an actual rebased source is a syntactic support property.
It does not mean that the operand was already stored in the first source.

`GeneratedQuerySequence.complete_many` is a stronger genuine finite result than StaticQueries for result feeding.
Its Supported index schedule is an original finite input.
Each query selects two current pool entries and appends its actual result before the next query.
Initial Fits plus Reserved profile requests.length derive all executions and final Fits at advance profile requests.length.
The theorem does not assume a complete future finite trace.
It does, however, receive the request list and its finite length as input.
It does not derive that list or its length from the actual generator.

There is another concrete attachment gap.
The indexed sequence's pool grows only by appending native query results.
Actual generator operands can also arise from preparation/unfold, projection, and rebuilt parents.
Those operands need their own literal allocation/support attachment.
The indexed theorem cannot be used through an identity cast or by assuming all those values were already in its original pool.
The prepared planner already pays nonquery effects for supplied D; a query-only profile advance must not silently omit them.

## Canonical storage and historical origins

`EnumerationValidity.Canonical` requires canonical suspended tries in the stored enumeration values.
It does not bound the native node/edge/domain supplies, payload mass, Mu degree, or a semantic quotient of native values.
Native coherence ties complete payloads to their actual interned keys.
No reviewed theorem identifies all physically distinct records that have the same meaning on a finite original model.
A finite assignment or term model alone therefore does not discharge physical-family membership through these Canonical APIs.
This states a missing theorem, not a counterexample to fixed-model generator termination.

`SourceHistory.Origin` retains one actual expression, capture environment, pre-probe context, both probe executions, the reservation, and the actual body callback for each completed Mu.
`build_origins` and `closed_origins` preserve this evidence constructively.
The existential origin does not restrict every later expression/environment to a finite family computed from the first input.
The module explicitly supplies neither a guard-profile observation nor a cap law.

`Cap Plain depth` is a guard-depth contract.
Its hereditary branch admits a value at every depth, including Mu values whose ordinary unfolding can have arbitrary height.
It is not the native stored-plan Mu-degree ceiling, native payload-mass profile, or recursive generator capacity.
Using its depth as one of those bounds would change the meaning of the theorem.

## Why ResourceHistory is not the full query schedule

A ResourceHistory contains original admission at each retained path point.
Its selected constructor carries an actual invocation and selected receipt, then the successful false callback record and one recursive output tail.
The callbackSeed and callbackCeiling are indices with their own admission.
The constructor does not relate them numerically to the first seed through final or stage.
Its parked tail has the same issue for tailSeed and tailCeiling.

Consequently, bare ResourceHistory cannot prove original-profile monotonicity simply by following those arbitrary seed indices.
It also represents one emitted output lineage rather than an explicit count of every preceding, rejected, stopped, or no-output sibling callback.
The actual invocation provenance is useful for attaching a complete count.
It does not already state that count.
Adding a future-entry Fits premise to the history theorem would leave the central obligation open.

## Recommended next obligation

For a supplied original recursive capacity D, extend the existing whole finite producer proof with a query-entry observation.
Keep exactly its current original gates and its same derived common work bound/outcome.
Derive that each actual incoming-query entry in the full invocation fits the original `PreparedReservation.final D seed ceiling` envelope, or derive a concrete charged schedule that includes all native and nonquery effects.
This must include earlier sibling callbacks, callbacks with no emitted outputs, preparation/unfold, and failed/stopped paths that retain native effects.
Do not limit the observation to ResourceHistory output tails.

The implementation route is local to the existing producer induction.
Use OriginalForecast.cost_le for actual head/scan costs, the existing stage/final monotonicity for original planner seeds, and actual completed head/callback receipts at the literal returned callers.
At a selected callback, preserve the explicit relation between its chosen planner seed and the original final envelope before invoking the smaller-capacity induction hypothesis.
An explicit native-query counter can be charged by these same original slots if needed.
This is a concrete producer conclusion, not a new original-input bounded-stream predicate.
No standalone proof draft was made because the reviewed dependencies do not yet expose that whole-invocation query-entry observation or query counter.

Once a uniform query/cost capacity is derived, the existing finite indexed-query resource theorem can help with native result feeding.
The generator's additional allocations still need their exact planner attachment.
For model/size-driven completeness, separately derive a sufficient D from original data that controls all earlier callbacks.
A chosen model witness's height does not by itself count work in preceding branches through the reviewed APIs.
No admitted counterexample to that final derivation was established in this audit.

## Current Haskell boundary

The reviewed IncomingQuery resource forecast and enabled emptiness receipts still contain the older1000-conjunction budget.
They remain the dated secondary target discussed in the tuple-budget audit.
The new per-query native-prefix bounded theorem itself uses the native query producer and does not invoke the enabled emptiness phase.
Its standalone native scope is therefore separate from the PR193 tuple-resource integration gap.
No Haskell defect, fix, or edit is introduced by this audit.

## Evidence

The manifest records seven whole-source identities and every credited literal cut.
The acquisition overrun is retained plainly.
All source/copy hashes pass readback.
Search-only hits were used for navigation and were not treated as complete proof evidence.
No compiler, evaluator, native execution, Git, network, board, repository edit, or old-evidence write was performed.
