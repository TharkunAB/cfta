# Actual enumeration storage progress: source-only candidate

Status: SOURCE-ONLY UNTESTED. No Lean compiler, evaluator, native execution or build ran for this candidate. No repository, Git, network or board operation ran. All writes are confined to this owned subtree. All earlier evidence areas remain unchanged.

## Candidate and exact scope

The additive candidate is drafts/v2/SourcePruningEnumerationStorageProgress.lean. It has 252 lines / 14145 bytes, SHA256 0a782e145f0d435391c1b8bcedfa16d555e3dd472fc2103a7b57768d1d088a73. It imports existing definitions. It does not copy or change any operational worker. The candidate has one public cost definition and eight public theorem declarations. All proofs are written out. They have not been checked.

EnumerationStorageProgress.pendingSize scans the ACTUAL state.values list at its raw indexes. A slot contributes NumberedTerms.size (assignment uv) exactly when its stored value is .unenumerated (some handle) scs. Pure equality slots, enumerated fragments and eliminated slots contribute zero. Representatives, waiting indexes, flags, suspended buckets and ancestry are not used to compute this cost. This is constructor count from NumberedTerms, not the separate FEAT size notion in the glossary.

The following candidate laws concern actual existing operations:

- initial_pendingSize reads the literal EnumerationState.initial: its cost is the assigned root term's size.
- EnumerationStorageProgress.allocate_pendingSize consumes actual Success (EnumerationState.allocate node). It derives the actual fresh index and allocated state from allocate_exact. Original counter/list alignment and agreement of the constructed assignment on all old allocated IDs transfer the old cost. Allocation of none adds zero. Allocation of some handle adds the fresh assigned term's size.
- setValue_enumerated_pendingSize consumes an actual Success (setValue target (.enumerated fragment)) and the original stored graph slot. The exact equation is after-cost + size(assignment target) = before-cost. No final model or assumed cost decrease is supplied.
- SourcePruningEnumerationStorageProgress.allocate_pendingSize derives the same law from an actual successful CachedChild.allocate observation. It extracts the exact core allocation. Flag and waiting updates stay in the real returned cache.
- suspendMany_pendingSize inducts over the actual CachedOwn.suspendMany execution. Each real cached allocation uses none. The whole own-equality allocation schedule therefore preserves cost for the same assignment. This law does not need counter alignment because every appended slot has zero cost.
- finalize_pendingSize extracts the real SourcePruningEnumerationFinalize.run and NativeIndex.write endpoints. The reset changes ancestry only. The actual raw captured-slot write removes exactly the target's assigned term cost. The waiting and flag computations are not replaced by synthetic endpoints.
- finalize_pendingSize_lt derives strict decrease for that finalizer alone from positivity of NumberedTerms.size.
- opaque_transfer_pendingSize composes actual CachedChild.allocate (some freshHandle) with actual Finalize.run target (.hole fresh). Under original storage alignment, old-ID agreement and assignment fresh = old assignment target, the cost is EXACTLY preserved across the whole two-operation schedule.

The last law is intentionally neutral. It does not conclude nontermination. It rules out using this cost as a strict measure at every actual opaque alias step. It also shows why the finalizer-only strict law must not be reported as strict decrease for the complete opaque transition.

## Actual source connection

NumberedTerms.lean:23-31 defines size(.node symbol children) = 1 + forestSize children. EnumerationState.lean:103-104 defines the raw setValue update. Lines132-138 define allocation, including ancestry inheritance. Lines569-591 give its concrete allocated state, exact execution, supply alignment and fresh slot.

CachedChild.lean:10-22 adds the native candidate flag to that same core allocation. NativeIndex.lean:39-49 writes the supplied raw slot after actual waiting-count operations. CachedOwn.lean:12-20 repeats the real none allocation for own classes. Finalize.lean:13-35 resets ancestry, reads the captured raw target and calls that actual native write. Its existing complete theorem, lines46-136, already exposes the exact final core shape and full storage/index facts; the candidate observes the literal operation instead of adding endpoint resource assumptions.

ShallowChild.lean:16-34 implements real nonterminal graph-hole allocation. Ordinary node children also write their inherited bucket; Mu/Union children retain the allocated empty bucket. The existing child producer's exact endpoint is at lines50-61. SelectedOpaqueDispatch.lean:35-47 runs an actual child and finalizes the original target with its returned fragment. These paths support the neutral alias assessment. No claim is made that arbitrary imported runtime states satisfy the full prepared driver admission.

SelectedValue.lean:19-34 performs one Mu unfolding, while Union exposure can rebuild an ordinary node. Thus the neutral schedule is a remaining-opaque branch assessment. It does not replace full recursive scope with an ordinary-only theorem or assume a returned prepared value is always ordinary.

EnumerationCorrectness.Success and EnumerationDriver.modify_success connect the pure state update proof to actual successful action branches. The candidate does not introduce a new operational relation or a supplier of desired mass decrease.

## Proof boundary

For an ordinary constructor model, 1 + sum(child sizes) gives the intended one-constructor decrease after charging all actual graph-child allocations and removing the parent slot. This module does NOT prove that complete edge transition. It stops at the concrete operation laws selected for this bounded task.

The complete proof must still account for ordinary child bucket writes, terminal representative lookup/union/assimilation, graph intersections, eliminated source slots, narrowing, actual callback recording, parked/restart paths and earlier sibling callbacks. It must retain the SAME constructed assignment through those operations. The candidate's old-ID agreement is local to its actual allocation theorem; it does not posit a universal future assignment or an endpoint model.

Neutral opaque transfers and other unchanged-storage operations need a separate progress argument or a finite bound on their repetition. The accepted finite root term alone is not turned into a sufficient recursive capacity here. No termination, global depth, accepted-output existence, enumeration coverage, public API correctness, or Haskell defect is claimed.

## Versions and validation

V1 is preserved as an untested predecessor: 252 lines / 14061 bytes, SHA256 is recorded in candidate-status.json. V2 only renames the private list scan from `from` to `scanCost`, so it does not rely on a possible keyword as an identifier. All eight public theorem declarations are literally identical across versions. Neither draft has a compiler receipt. Any later root check must be recorded separately against its exact copied bytes; it must not change the untested status of this frozen source-only bundle.

Six original Lean files have whole-source provenance copies: NumberedTerms, EnumerationState, CachedChild, Finalize, CachedOwn and NativeIndex. All other acquired Lean content is retained as literal cuts only. source-index.json records each original source identity and the exact read intervals. It distinguishes a whole provenance copy from a whole-content reading claim. The glossary is retained only as a literal cut. Source/cut hashes and exact line slices were checked against current read-only repository files.

The source-only checks verify identities and scope. They do not establish elaboration, strict-linter success or theorem validity. Root owns compiler checking and integration. No proof limits, linter suppressions, placeholders, custom axioms or runtime-copy definitions are added in the candidate.

The manifest covers every payload except pins.json and FROZEN.json. The immutable seal binds its exact byte count, hash and file count. All writes halt after the seal.
