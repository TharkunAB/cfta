from pathlib import Path
import hashlib,json
own=Path('/tmp/mcfta-generator-sequence-progress-20261029/model-progress')
repo=Path('/home/tritlo/Code/mcfta')
def sha(b):return hashlib.sha256(b).hexdigest()
# Exactly six whole Lean sources. Other Lean acquisitions retain literal cuts only.
whole={
'NumberedTerms.lean':[(1,144)],
'EnumerationState.lean':[(1,170),(190,237),(550,591)],
'SourcePruningEnumerationCachedChild.lean':[(1,255)],
'SourcePruningEnumerationFinalize.lean':[(1,136)],
'SourcePruningEnumerationCachedOwn.lean':[(1,99)],
'SourcePruningEnumerationNativeIndex.lean':[(1,145)],
}
cuts_only={
'EnumerationProgress.lean':[(1,100)],
'EnumerationCorrectness.lean':[(1,61)],
'EnumerationDriver.lean':[(193,205)],
'EnumerationWaitingIndex.lean':[(110,140)],
'SourcePruningEnumerationShallowChild.lean':[(1,80)],
'SourcePruningEnumerationOwnFinalizeCanonical.lean':[(1,100)],
'SourcePruningEnumerationSelectedEdge.lean':[(1,95)],
'SourcePruningEnumerationSelectedOpaqueDispatch.lean':[(28,72)],
'SourcePruningEnumerationSelectedValue.lean':[(12,49)],
}
records=[]
for name,intervals in list(whole.items())+list(cuts_only.items()):
 src=repo/'lean/MicroCFTA'/name;b=src.read_bytes();lines=b.splitlines(keepends=True);rec=dict(source=str(src),source_bytes=len(b),source_sha256=sha(b),acquisition='whole-source-copy' if name in whole else 'literal-cuts-only',cuts=[],read_scope='Only the listed literal cuts are claimed as read. Whole copying is provenance, not an additional reading claim.')
 if name in whole:
  dest=own/'sources'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);rec['whole']=dict(path=str(dest.relative_to(own)),bytes=len(b),sha256=sha(b))
 for a,z in intervals:
  assert 1<=a<=z<=len(lines);cb=b''.join(lines[a-1:z]);dest=own/'cuts'/f'{src.stem}-L{a}-L{z}.lean';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(cb);rec['cuts'].append(dict(path=str(dest.relative_to(own)),first_line=a,last_line=z,bytes=len(cb),sha256=sha(cb)))
 records.append(rec)
context=(repo/'CONTEXT.md').read_bytes();cb=b''.join(context.splitlines(keepends=True)[:150]);dest=own/'cuts/CONTEXT-L1-L150.md';dest.write_bytes(cb)
records.append(dict(source=str(repo/'CONTEXT.md'),source_bytes=len(context),source_sha256=sha(context),acquisition='literal-cuts-only',cuts=[dict(path=str(dest.relative_to(own)),first_line=1,last_line=150,bytes=len(cb),sha256=sha(cb))],read_scope='Literal glossary cut read; historical remainder not read.'))
index=dict(whole_lean_acquisitions=6,sources=records,scope='Six whole Lean source copies maximum. Subsequent and other Lean source content is retained only as literal read cuts. Identity hashing does not claim a whole-content review.')
(own/'source-index.json').write_text(json.dumps(index,indent=2)+'\n')
# Validate copies and exact line intervals against the current read-only repository.
for r in records:
 b=Path(r['source']).read_bytes();assert len(b)==r['source_bytes'] and sha(b)==r['source_sha256'];lines=b.splitlines(keepends=True)
 if 'whole' in r:assert (own/r['whole']['path']).read_bytes()==b
 for c in r['cuts']:
  cb=(own/c['path']).read_bytes();assert cb==b''.join(lines[c['first_line']-1:c['last_line']]);assert len(cb)==c['bytes'] and sha(cb)==c['sha256']
print(json.dumps(dict(whole_lean_acquisitions=6,literal_cuts=sum(len(r['cuts']) for r in records),validation='PASS'),indent=2))
