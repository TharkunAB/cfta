import MicroCFTA.EnumerationSoundness

/-!
# Strict suspended dependencies

Stored pending constraints refer to proper descendants. A finite complete
assignment therefore rules out a scheduler result in which all work is blocked.
-/

namespace MicroCFTA.EnumerationProgress
open Language Fragments EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationDriver EnumerationSemantics EnumerationFrame EnumerationValidity EnumerationSoundness

local instance : Monad List where
  pure value := [value]
  bind values continuation := values.flatMap continuation

/-- A stored pending trie contains at least one proper descendant path. -/
def ProperTrie (trie : EqualityTrie.Trie) : Prop :=
  EqualityTrie.Valid trie ∧ EqualityTrie.isEmpty trie = false ∧ EqualityTrie.isTerminal trie = false

/-- Pure equality slots carry no paths; graph slots carry only proper pending paths. -/
def ProperValue : UVarValue Symbol → Prop
  | .unenumerated none scs => scs = []
  | .unenumerated (some _) scs => ∀ sc ∈ scs, ProperTrie sc.trie
  | _ => True

/-- All stored pending slots meet the source scheduler's strict-path invariant. -/
def ProperState (state : State Symbol Guard) : Prop := ∀ value ∈ state.values, ProperValue value

/-- Inherited inputs contain canonical nonempty tries, including terminals. -/
def ProperInputs (scs : List Suspended) : Prop :=
  ∀ sc ∈ scs, EqualityTrie.Valid sc.trie ∧ EqualityTrie.isEmpty sc.trie = false

/-- Every stored pending input is a canonical nonempty trie. -/
theorem proper_inputs (value : UVarValue Symbol) (proper : ProperValue value) : ProperInputs (references value) := by
  cases value with
  | eliminated | enumerated _ => simp [references, ProperInputs]
  | unenumerated node scs =>
      cases node with
      | none => simp [ProperValue] at proper; simp [references, proper, ProperInputs]
      | some node => exact fun sc member => ⟨(proper sc member).1, (proper sc member).2.1⟩

/-- Filtering reached terminals leaves only proper descendant constraints. -/
theorem proper_below (scs : List Suspended) (inputs : ProperInputs scs) :
    ∀ sc ∈ scs.filter (fun sc => !EqualityTrie.isTerminal sc.trie), ProperTrie sc.trie := by
  intro sc member
  obtain ⟨present, below⟩ := List.mem_filter.mp member
  exact ⟨(inputs sc present).1, (inputs sc present).2, by simpa using below⟩

/-- Child descent supplies canonical nonempty inputs. -/
theorem descend_proper (scs : List Suspended) (index : Nat) (valid : ValidSuspended scs) :
    ProperInputs (descendScs index scs) := by
  intro sc member
  have canonical := descend_valid scs index valid sc member
  have nonempty := (List.mem_filter.mp member).2
  exact ⟨canonical, by simpa using nonempty⟩

/-- The initial pending root has no suspended dependencies. -/
theorem initial_proper (root : Nat) : ProperState (initial root : State Symbol Guard) := by
  simp [ProperState, initial, ProperValue]

/-- Updating one stored slot preserves the pending-path invariant. -/
theorem setValue_proper (uv : Nat) (value : UVarValue Symbol) (before after : State Symbol Guard)
    (proper : ProperState before) (payload : ProperValue value)
    (success : Success (setValue uv value) before () after) : ProperState after := by
  obtain rfl := (modify_success _ before after).mp success
  intro stored member
  rcases List.mem_or_eq_of_mem_set member with old | same
  · exact proper stored old
  · simpa [same] using payload

/-- Raw reads retain proper pending paths and expose their payload invariant. -/
theorem rawValue_proper (uv : Nat) (before after : State Symbol Guard) (value : UVarValue Symbol)
    (proper : ProperState before) (success : Success (rawValue uv) before value after) :
    ProperState after ∧ ProperValue value := by
  obtain ⟨stored, same⟩ := (rawValue_success uv before after value).mp success
  subst after
  exact ⟨proper, proper value (List.mem_of_getElem? stored)⟩

/-- Representative lookup changes no pending payload. -/
theorem representative_proper (fuel uv root : Nat) (before after : State Symbol Guard)
    (proper : ProperState before) (success : Success (representative fuel uv) before root after) : ProperState after := by
  obtain ⟨found, _, _, rfl⟩ := (representative_success fuel uv before after root).mp success
  exact proper

/-- Union changes no pending payload. -/
theorem unionVariables_proper (fuel left right : Nat) (before after : State Symbol Guard)
    (proper : ProperState before) (success : Success (unionVariables fuel left right) before () after) : ProperState after := by
  obtain ⟨forest, _, rfl⟩ := (unionVariables_success fuel left right before after).mp success
  exact proper

/-- Intersecting proper pending payloads retains empty pure slots and proper graph paths. -/
theorem intersection_proper (graph : Graph Symbol Guard) (left right merged : UVarValue Symbol)
    (leftProper : ProperValue left) (rightProper : ProperValue right)
    (success : intersectValues graph left right = some merged) : ProperValue merged := by
  cases left <;> cases right <;> simp only [intersectValues] at success
  all_goals try cases success
  rename_i left leftScs right rightScs
  cases left <;> cases right
  · simp only [ProperValue] at leftProper rightProper ⊢
