import MicroCFTA.EnumerationState

/-!
# Concrete suspended-enumeration step invariants

The operations in this module are the executable `EnumerationState` actions.
Complete assignments interpret holes. Stored node restrictions and residual
guards remain explicit. Diagnostic recursion truncation is not acceptance.
-/

namespace MicroCFTA.EnumerationCorrectness

open Language Fragments EnumerationState

local instance : Monad List where
  pure value := [value]
  bind values continuation := values.flatMap continuation

local instance : LawfulMonad List where
  map_const := rfl
  id_map := by intro α xs; simp [Functor.map]
  seqLeft_eq := by
    intros
    simp [SeqLeft.seqLeft, Seq.seq, Functor.map, List.flatMap_map, ← List.map_eq_flatMap]
    simp only [List.map_const']
  seqRight_eq := by
    intros
    simp only [SeqRight.seqRight, Seq.seq, Functor.map, List.flatMap_map]
    simp
  pure_seq := by intros; simp [Seq.seq, Functor.map, pure]
  bind_pure_comp := by intros; simp [bind, pure, Functor.map, ← List.map_eq_flatMap]
  bind_map := by intros; rfl
  pure_bind := by intros; simp [pure, bind]
  bind_assoc := by intros; exact List.flatMap_assoc

/-- A successful branch of an actual state action. Errors remain separate list entries. -/
def Success (action : EnumerateM Symbol Guard α) (before : State Symbol Guard)
    (value : α) (after : State Symbol Guard) : Prop :=
  Except.ok (value, after) ∈ ExceptT.run (action before)

/-- Binding runs each successful branch in its own stored state and retains error branches. -/
theorem run_bind (action : EnumerateM Symbol Guard α) (next : α → EnumerateM Symbol Guard β)
    (state : State Symbol Guard) :
    ExceptT.run ((action >>= next) state) = (ExceptT.run (action state)).flatMap
      (fun result => match result with
        | .error error => [.error error]
        | .ok (value, after) => ExceptT.run (next value after)) := by
  simp only [bind, StateT.bind, ExceptT.run, ExceptT.bind, ExceptT.mk]
  congr 1
  funext result
  cases result with
  | error error => rfl
  | ok pair => cases pair; rfl

/-- Successful sequential execution is exactly composition through one successful intermediate state. -/
theorem success_bind (action : EnumerateM Symbol Guard α) (next : α → EnumerateM Symbol Guard β)
    (before : State Symbol Guard) (value : β) (after : State Symbol Guard) :
    Success (action >>= next) before value after ↔
      ∃ middle intermediate, Success action before middle intermediate ∧ Success (next middle) intermediate value after := by
  simp only [Success, run_bind, List.mem_flatMap]
  constructor
