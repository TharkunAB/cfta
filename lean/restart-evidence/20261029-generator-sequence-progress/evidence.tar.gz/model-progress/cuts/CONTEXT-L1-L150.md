# Glossary

The words this repository uses for its domain, with the words of the sources
where they differ. Sources: the ECTA paper (Koppel et al., *Searching
Entangled Program Spaces*, ICFP 2022) and the `ecta` library; the LTA paper
(*Liquid Tree Automata*, arXiv:2605.13456); TATA (Comon et al., *Tree
Automata Techniques and Applications*); CLRS (union-find); Nijenhuis and
Wilf, and Feat (ranking).

## Terms and automata

- **Term**: a tree of symbols.
- **Arity**: the number of children of a symbol or a transition. All sources
  say arity.
- **Path**: the child indexes from the root of a term to one of its nodes.
  TATA and the LTA paper call this a *position* (`Pos(t)`, `t|p`, `i.j.k`);
  ECTA calls it a path. In this repository the list is a path. "Position"
  has its plain meaning: the place of one item in a sequence, such as a
  child among the children of a node, or a member in its size class.
- **Child index**: one step of a path: the zero-based position of a child
  among the children of a term node or a transition. The LTA paper says
  *position index*.
- **Transition**: a rule `f(q1, ..., qn) -> q`. An **edge** is a transition
  of an interned automaton (the `ecta` library's `Edge`; the ECTA thesis says
  *hyperedge*). A **transition index** selects one transition of a state or
  node.
- **Node, state**: a node of an interned automaton is a state; ECTA uses both
  words for one thing.
- **Node identity, edge identity, symbol identity**: the identity that
  interning gives a node, an edge, or a symbol. The three are different
  types; the `ecta` library has one `Id` for all three.
- **View, view path, view step**: a tree view unfolds a graph; a view path
  locates one occurrence in it; each step is a transition index, then a
  child index.
- **Depth**: the longest root-to-leaf path of a term, in edges; a leaf has
  depth 0. TATA's *height* counts a constant as 1, so height = depth + 1.
  **Mu depth** is the nesting depth of `Mu` binders, a different quantity.
- **Graph snapshot**: a stored explicit graph with its symbols, refinements,
  constraints, states, and transitions. It need not retain the source facts
  from which its compiled constraints were made.

## Constraints

- **Equality class**: a set of paths that must hold equal subterms (ECTA:
  *path equivalence class*, PEC; type `PathEClass`).
- **Equality constraints**: the equality classes of a transition (ECTA:
  *path constraint set*, PCS; type `EqConstraints`).
- **Guard**: the formula on a transition: equal terms at two paths,
  refinements that a path satisfies or entails, formulas over the terms at
  paths, substitutions, and Boolean connectives. The LTA paper calls this the
  transition's *constraint* `ψ`.
- **Constraint**: the whole label of a transition: equality constraints and
  a guard.
- **Contract**: a guard about the children of a constructor, written as a
  function with one term for each child, in order.
- **Measure**: the integer of each term of a constructor, written as a term
  of the measures of its children (`measured`). The refinement of a constructed
  term is `v == measure`, so the contract of a parent reads it. Liquid Haskell
  says measure; the LTA paper calls a constructor's refinement its *result
  refinement*.
- **Observed**: what a guard can read at one path of a term: the symbol there
  and its **leafness** (leaf, inner, or mixed when some members of a group
  are leaves and some are not).
- **Similarity pair**: two transitions where the first (the **subtype**)
  refines the second (the **supertype**); the LTA paper writes `δi ≲ δj`.
  Minimization keeps the **representative** and removes the supertype.

## E-graphs

- **E-graph**: a set of terms with a congruence of them, as in egg
  (`Data.CFTA.EGraph`). An e-graph is a bottom-up deterministic tree
  automaton.
- **E-class**: a set of equal terms of an e-graph; a state of its automaton.
  An e-class is not an equality class, which is a set of paths.
- **E-node**: a symbol with an e-class for each child; a transition of the
  automaton of an e-graph.
- **Sort**: the term, such as a type, that each e-class of a sorted e-graph
  has. Sorts never merge. An ECTA of typed terms puts the type in a child
  instead.
- **Pattern**: a term with variables and sort variables. A variable that
  occurs twice is an equality class of paths.
- **Match**: an e-class of an instance of a pattern, and an e-class for each
  variable of the pattern.
- **Rule**: a left and a right pattern; each instance of the left side is
  equal to the instance of the right side.
- **Equality saturation**: the application of rules to an e-graph until no
  rule changes it, or a limit stops it.
- **E-class analysis**: data for each e-class, the merge of the data of its
  e-nodes, a bottom-up evaluation of the automaton of the e-graph. A
  **condition** of a rule reads it. A refinement of the value is such data,
  and its merge is the meet, because the terms of an e-class have one value.
- **Stamp**: the iteration of the last change of an e-class. **Semi-naive
  matching** finds only the matches through e-classes with a stamp after the
  last run of the rule.

## Editable languages

- **Language**: a set of terms. A `Language` value is the source of one: a
  source document and named exclusions. Its terms are the terms of the
  compiled document that no exclusion rejects.
- **Source document**: an editable language definition that retains named
  productions and their separate facts before compilation.
- **Production**: a transition of a source document, with a name that is
  unique in its state, and named facts.
- **Language update**: a reusable expression that changes a source document or
  named exclusions. It does not contain an expected source version.
- **Named exclusion**: an exclusion with a name in a language. An update can
  remove it again. The source document does not change.
- **Production reference**: a source state and the stable name of one
  production in that state.
- **Source fact**: one named constraint attached to a production.
  Removing a fact removes that obligation. It does not negate the constraint.
- **Patch**: an ordered batch of edits together with the source document it
  expects. A valid patch produces a new source document.
- **Three-way merge**: the merge of two versions of a language, the left and
  the right, that come from one base. It merges by key: the initial state, the
  state rows, the production names, the fact names, and the exclusion names.
  A key that one side changes takes that change. A key that both sides change
  in the same way takes that change.
- **Conflict**: a key that the two sides of a three-way merge change in
  different ways, or that one side deletes and the other side changes. A
  conflict holds its key and its three versions.

## Transformations

- **Exact transformation**: an operation on an automaton that keeps its
  language, the set of terms it accepts. Equality reduction
  (`reducePartially`), `prune`, `withoutRedundantEdges`, `refold`, and `trim`
  are exact. A path that lists, counts, or ranks accepted terms, such as the
  generator imports, uses only exact transformations.
- **Over-approximation**: an operation whose result accepts every term of
  its input and possibly more, such as `mergeAlternatives` and
  `dropConstraints`. It enters an exact path only where the caller checks the
  original constraints again: the narrowing set of `reduceEqConstraints` is
  merged, and enumeration and `accepts` still check each equality class.
- **Representative selection**: `minimize` replaces a transition by the
  representative of its similarity class, so the result can accept fewer
  terms. No exact path uses it. The user applies it: to a pool with
  `minimizePoolOn`, or as the last step of the paper's reduction, `reduce`,
  which keeps the most specific term of each refinement, as a synthesizer
  needs.

## Ranking and sampling

- **Rank**: the zero-based index of a term or value in the enumeration
  order. **Unrank** is its inverse (Nijenhuis and Wilf). Not the CLRS rank
  of a union-find tree.
- **Cardinality**: the number of members of a language (Feat).
- **Size**: the number of pays of a generated member, as in FEAT: `pure` has
  size zero, an atom one, a product the sum of its sides, and a pay, such as
