namespace MicroCFTA.SourcePruningEnumerationSelectedValue
open Cache Language InternedConstructorTemplates InternedProbeProvenance
open SourceEqualityRequiredCache SourceEqualityRequiredSemanticCache
variable {Symbol Guard : Type}
variable [DecidableEq (EdgeKey Symbol Guard)]

/-- Prepare the selected value with the source's two distinct operations. -/
def run (fuel : Nat) (value : Value Symbol Guard) (before : State Symbol Guard) :
    MergedSourceComparison.Result Symbol Guard (Value Symbol Guard) :=
  match value with
  | value@(.mu ..) =>
      match InternedFreshOrdinaryStoredSubstitution.unfold value before with
      | .done result after => .done result after
      | .pending key after => .failed (.pending key) after
  | value@(.union ..) =>
      match MergedFreshOrdinaryExposure.nodeEdges fuel value before with
      | .done rows middle =>
          let rebuilt := InternedConstructorTemplates.run (makeNode rows) middle
          .done rebuilt.1 rebuilt.2
      | .unresolved name after => .failed (.unresolved name) after
      | .pending key after => .failed (.pending key) after
      | .exhausted after => .failed .exhausted after
  | _ => .done value before

/-- Original native cache facts derive one stable result and its exact least language. -/
theorem run_complete (value : Value Symbol Guard) (before : State Symbol Guard)
    (semantic : SemanticReady before) (available : Available before value)
    (closed : value.free = []) :
    ∃ bound result after,
      (∀ extra, run (bound + extra) value before = .done result after) ∧
      Keeps before after ∧ SemanticReady after ∧ Available after result ∧ result.free = [] ∧
      ∀ holds ambient term,
        InternedGuardedLanguage.meaning holds ambient result term ↔
          InternedGuardedLanguage.meaning holds ambient value term := by
  cases value with
  | empty | reference | node =>
      refine ⟨0, _, before, ?_, pure_keeps before semantic.ready, semantic, available, closed, ?_⟩
      · intro extra
