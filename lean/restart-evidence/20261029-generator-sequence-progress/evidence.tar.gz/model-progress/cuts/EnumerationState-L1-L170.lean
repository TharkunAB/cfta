import MicroCFTA.Fragments
import MicroCFTA.EqualityTrie

/-!
# Suspended-constraint enumeration state machine

The transitions follow `Enumeration.hs`. Graph identity, intersection, and
recursive unfolding are explicit interfaces. Execution bounds report errors;
they do not silently reject branches. Residual guards remain in the output.
-/
set_option maxHeartbeats 2000000

namespace MicroCFTA.EnumerationState
open Language Fragments

local instance : Monad List where
  pure value := [value]
  bind values continuation := values.flatMap continuation

/-- The existing checked path-trie model supplies suspended equality variables. -/
abbrev Suspended := EqualityTrie.Suspended Nat

/-- Use the source-equivalent checked trie descent. -/
abbrev descendScs := @EqualityTrie.descendScs Nat

/-- Every represented path must reach the assigned equality variable. -/
def Suspended.Holds (assignment : Nat → Term Symbol) (term : Term Symbol) (sc : Suspended) : Prop :=
  ∀ path ∈ EqualityTrie.fromPathTrie sc.trie, term.atPath path = some (assignment sc.var)

/-- Source UVar states. A missing node is a pure equality variable. -/
inductive UVarValue (Symbol : Type) where
  | unenumerated : Option Nat → List Suspended → UVarValue Symbol
  | enumerated : Fragment Symbol → UVarValue Symbol
  | eliminated

/-- One graph edge and its two kinds of constraints. -/
structure Edge (Symbol Guard : Type) where
  symbol : Symbol
  children : List Nat
  equalities : List EqualityTrie.Trie
  residual : Option Guard

/-- The recursive case supplies the unfolded outer body. -/
inductive Node (Symbol Guard : Type) where
  | empty
  | alternatives : List (Edge Symbol Guard) → Node Symbol Guard
  | recursive : Nat → Node Symbol Guard
  | unresolved : Nat → Node Symbol Guard

/-- Graph primitives supplied by the interned-graph implementation. -/
structure Graph (Symbol Guard : Type) where
  node : Nat → Node Symbol Guard
  intersect : Nat → Nat → Nat

/-- Recursion keys omit equality-variable identities. -/
structure RecursionKey where
  node : Nat
  tries : List (List (List Nat))
  deriving DecidableEq

/-- Canonical path sets represent the source's set of suspended tries. -/
def recursionKey (node : Nat) (scs : List Suspended) : RecursionKey :=
  ⟨node, (scs.map fun sc => EqualityTrie.fromPathTrie sc.trie).eraseDups.mergeSort
    (fun left right => compare left right != .gt)⟩

/-- Mutable state copied separately for each nondeterministic branch. -/
structure State (Symbol Guard : Type) where
  counter : Nat
  representatives : UnionFind.Forest
  values : List (UVarValue Symbol)
  obligations : List (Guard × Fragment Symbol)
  recursionAncestry : Nat → List RecursionKey
  expansionAncestry : List RecursionKey

/-- The root starts in UVar zero. -/
def initial (root : Nat) : State Symbol Guard :=
  ⟨1, UnionFind.withInitialValues [0], [.unenumerated (some root) []], [], fun _ => [], []⟩

/-- Source invariant failures and explicit finite execution bounds. -/
inductive Error where
  | fuelExhausted | representativeFuel | invalidSlot | invalidIntersection
  | unresolvedReference | unfinishedFragment
  deriving DecidableEq, Repr

/-- State and errors are local to each nondeterministic alternative. -/
abbrev EnumerateM (Symbol Guard : Type) := StateT (State Symbol Guard) (ExceptT Error List)

/-- Reject one branch, as the list monad does. -/
def reject : EnumerateM Symbol Guard α := fun _ => []

/-- Choose each alternative with the same input state. -/
def choose (values : List α) : EnumerateM Symbol Guard α := fun state =>
  values.map fun value => .ok (value, state)

/-- Report an execution limit or source invariant failure. -/
def failure (error : Error) : EnumerateM Symbol Guard α := fun _ => [.error error]

/-- Retain a branch exactly when its Boolean guard is true. -/
def require (condition : Bool) : EnumerateM Symbol Guard Unit :=
  if condition then pure () else reject

/-- Write the supplied UVar, not its representative. -/
def setValue (uv : Nat) (value : UVarValue Symbol) : EnumerateM Symbol Guard Unit :=
  modify fun state => {state with values := state.values.set uv value}

/-- Read one raw slot. -/
def rawValue (uv : Nat) : EnumerateM Symbol Guard (UVarValue Symbol) := do
  match (← get).values[uv]? with
  | none => failure .invalidSlot
  | some value => pure value

/-- Find and path-compress a representative. -/
def representative (fuel uv : Nat) : EnumerateM Symbol Guard Nat := do
  let state ← get
  match UnionFind.findRoot fuel state.representatives uv with
  | none => failure .representativeFuel
  | some found =>
      set {state with representatives := found.forest}
      pure found.representative

/-- Read the current representative's slot. -/
def getValue (fuel uv : Nat) : EnumerateM Symbol Guard (UVarValue Symbol) := do
  rawValue (← representative fuel uv)

/-- Give a variable the ancestry of the current expansion. -/
def inheritAncestry (uv : Nat) : EnumerateM Symbol Guard Unit :=
  modify fun state => {state with recursionAncestry := (fun other =>
    if other = uv then (state.expansionAncestry ++ state.recursionAncestry uv).eraseDups
    else state.recursionAncestry other)}

/-- Allocate a slot and inherit the current recursion ancestry. -/
def allocate (node : Option Nat) : EnumerateM Symbol Guard Nat := do
  let state ← get
  let uv := state.counter
  set {state with counter := uv + 1, values := state.values ++ [UVarValue.unenumerated node []]}
  inheritAncestry uv
  pure uv

/-- A new equality class starts with a pure equality variable. -/
def suspend (trie : EqualityTrie.Trie) : EnumerateM Symbol Guard Suspended := do
  pure ⟨trie, ← allocate none⟩

/-- Only two unenumerated slots can be intersected. -/
def intersectValues (graph : Graph Symbol Guard) :
    UVarValue Symbol → UVarValue Symbol → Option (UVarValue Symbol)
  | .unenumerated left ls, .unenumerated right rs =>
      some (.unenumerated (match left, right with
        | none, node => node
        | node, none => node
        | some a, some b => some (graph.intersect a b)) (ls ++ rs))
  | _, _ => none

/-- Structural emptiness rejects an intersection branch. -/
def hasEmptyContents (graph : Graph Symbol Guard) : UVarValue Symbol → Bool
  | .unenumerated (some node) _ => match graph.node node with | .empty => true | _ => false
  | _ => false

/-- Move an old representative's contents into the current representative. -/
def assimilate (graph : Graph Symbol Guard) (target source : Nat) : EnumerateM Symbol Guard Unit := do
  if target = source then pure () else
    let sourceValue ← rawValue source
    match sourceValue with
    | .eliminated => pure ()
    | _ =>
        let targetValue ← rawValue target
        match intersectValues graph sourceValue targetValue with
        | none => failure .invalidIntersection
        | some merged =>
            require (!hasEmptyContents graph merged)
            setValue target merged
