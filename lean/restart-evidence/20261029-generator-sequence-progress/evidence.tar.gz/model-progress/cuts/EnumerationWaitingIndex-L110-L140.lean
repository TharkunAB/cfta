/-- The full reference count follows a valid slot replacement exactly. -/
theorem total_set (uv index : Nat) (values : List (UVarValue Symbol)) (old new : UVarValue Symbol)
    (stored : values[index]? = some old) :
    total uv (values.set index new) = total uv values - occurrences uv (references old) + occurrences uv (references new) := by
  induction values generalizing index with
  | nil => simp at stored
  | cons first rest ih =>
      cases index with
      | zero =>
          simp only [List.getElem?_cons_zero, Option.some.injEq] at stored
          subst first
          simp [total]
          omega
      | succ index =>
          simp only [List.getElem?_cons_succ] at stored
          simp only [List.set_cons_succ, total, ih index stored]
          omega

/-- A valid slot replacement derives the new cached counts from the previous scan invariant. -/
theorem replace_correct (values : List (UVarValue Symbol)) (index : Nat) (old new : UVarValue Symbol)
    (stored : values[index]? = some old) (waiting : Waiting) (correct : Correct values waiting) :
    Correct (values.set index new) (replace old new waiting) := by
  intro uv
  rw [replace_canonical old new waiting correct.facts.1 uv, replace_read, correct.facts.2 uv,
    total_set uv index values old new stored]

/-- The full scan count adds over adjacent slot lists. -/
theorem total_append (uv : Nat) (first second : List (UVarValue Symbol)) :
    total uv (first ++ second) = total uv first + total uv second := by
  induction first with
  | nil => simp [total]
