          · exact Nat.le_trans (maximal uv present) (by omega)

/-- A finite nonempty set cannot consist only of strict subtree dependencies.
The scheduler's stuck case needs its reachable-slot invariants to establish these dependencies. -/
theorem strict_dependency_stuck_impossible (variables : List Nat) (nonempty : variables ≠ [])
    (assignment : Nat → Term Symbol)
    (blocked : ∀ target ∈ variables, ∃ source ∈ variables,
      ∃ path, path ≠ [] ∧ (assignment source).atPath path = some (assignment target)) : False := by
  obtain ⟨largest, member, maximal⟩ :=
    finite_height_maximum variables (fun uv => (assignment uv).height) nonempty
  obtain ⟨source, sourceMember, path, proper, reaches⟩ := blocked largest member
  have bound := atPath_height_bound _ _ path reaches
  have largestHeight := maximal source sourceMember
  have positive : 0 < path.length := by
    have nonzero : path.length ≠ 0 := fun zero => proper (List.length_eq_zero_iff.mp zero)
    omega
  omega

/-- The concrete state update performed by allocation. -/
def allocated (node : Option Nat) (state : State Symbol Guard) : State Symbol Guard :=
  {state with
    counter := state.counter + 1
    values := state.values ++ [UVarValue.unenumerated node []]
    recursionAncestry := (fun other =>
      if other = state.counter then (state.expansionAncestry ++ state.recursionAncestry state.counter).eraseDups
      else state.recursionAncestry other)}

/-- Allocation has exactly one result and retains all old value slots. -/
theorem allocate_exact (node : Option Nat) (state : State Symbol Guard) :
    allocate node state = [.ok (state.counter, allocated node state)] := rfl

/-- The fresh-name supply remains equal to the slot count after allocation. -/
theorem allocated_supply (node : Option Nat) (state : State Symbol Guard)
    (aligned : state.counter = state.values.length) :
    (allocated node state).counter = (allocated node state).values.length := by
  simp [allocated, aligned]

/-- The newly allocated UVar names precisely the appended unenumerated slot. -/
theorem allocated_slot (node : Option Nat) (state : State Symbol Guard)
    (aligned : state.counter = state.values.length) :
    (allocated node state).values[state.counter]? = some (.unenumerated node []) := by
  simp [allocated, aligned]
