# Explicit query resources and chosen-term storage progress

The full formalization goal remains ACTIVE.
Read final-documents/lean/notes-current-generator-sequence-progress.md first.
Checked query prefixes have the explicit original-profile payload ceiling.
Actual storage and callback laws include neutral opaque transfers.
Sufficient recursive capacity and global chosen-output coverage remain open.

Every regular file is archived without filtering. Keep this tree and all
reconstructions immutable. Continue in a fresh writable area. Historical
UNTESTED labels, the read-scope overrun and failed attempts remain. The exact
four final strict sources supersede drafts. Verification executes no code.
