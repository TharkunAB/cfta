import MicroCFTA.SourcePruningEnumerationCheckedQueryPrefixBounded
import MicroCFTA.InternedValueMassBinderDepth

namespace MicroCFTA.SourceCurrentAllocatedNativePhysicalTraceCompletion
open InternedConstructorTemplates InternedRecordCoherence SourceEqualityNativeDemand
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Checked" => SourceEqualityNativeDemand.State
variable {A : Type} {width steps bound : Nat} {control : Control A}
variable {before after : Checked width} {value : A}

/-- The final body ceiling bounds each actual prefix of a completed checked trace. -/
theorem Trace.prefix_bounded_of_final
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (trace : Trace steps control before (.code (.pure value)) after)
    (valid : SourceCurrentAllocatedNativePhysicalCache.Valid before.native)
    (ready : SourceEqualityRequiredCache.Ready before.native.machine.heap)
    (bounded : InternedMuDepthInventory.Bounded after.native.machine.heap bound) :
    ∀ runtimeFuel, InternedMuDepthInventory.Bounded
      (execute runtimeFuel control before).state.native.machine.heap bound := by
  induction steps generalizing control before bound with
  | zero =>
      cases trace
      intro runtimeFuel
      have same : (execute runtimeFuel (.code (.pure value)) after).state = after := by
        cases runtimeFuel <;> rfl
      rw [same]
      exact bounded
  | succ count ih =>
      cases trace with
      | cons start initial resume middle final result count inputs one tail =>
          have effects := SourceCurrentAllocatedNativePhysicalExecution.step_invariants
            control before valid ready inputs
          have middleValid : SourceCurrentAllocatedNativePhysicalCache.Valid middle.native := by
            simpa only [one, Outcome.state] using effects.1
          have middleReady : SourceEqualityRequiredCache.Ready middle.native.machine.heap := by
            simpa only [one, Outcome.state] using effects.2.2.ready
          have middleExtension : SourceRecursiveIntersectionKernel.Extension
              before.native.machine middle.native.machine := by
            simpa only [one, Outcome.state] using effects.2.1
          have laterBounded := ih tail middleValid middleReady bounded
          intro runtimeFuel
          cases runtimeFuel with
          | zero =>
              have boundedAtMiddle := laterBounded 0
              intro key entry body depth ordinary present
              exact boundedAtMiddle key entry body depth ordinary
                (middleExtension.heap.nodeRecords key _ present)
          | succ fuel =>
              change InternedMuDepthInventory.Bounded
                (execute (fuel + 1) control before).state.native.machine.heap bound
              rw [execute, one]
              exact laterBounded fuel

end MicroCFTA.SourceCurrentAllocatedNativePhysicalTraceCompletion

namespace MicroCFTA.SourcePruningEnumerationIncomingQuery
open InternedConstructorTemplates InternedProbeProvenance SourceCurrentAllocatedNativeInventoryState
open SourceCurrentAllocatedPartialInvariant SourceCurrentAllocatedNativeResourceForecast
open SourceCurrentConstrainedCapGeneratedQueryResources (Fits)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => InternedConstructorTemplates.Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
variable {bits : Nat}

/-- Original caller resources compute one body ceiling for every checked query observation. -/
theorem native_prefix_bounded_profile
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)]
    (profile : Profile)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (beforeCaller : Caller (bits + 2))
    (left right : Node) (memos : Memos)
    (initial : Context formulas solver inventory beforeCaller memos)
    (leftAvailable : Available beforeCaller.checked.native.machine.heap left)
    (rightAvailable : Available beforeCaller.checked.native.machine.heap right)
    (leftClosed : left.free = []) (rightClosed : right.free = [])
    (fits : Fits profile beforeCaller.checked) (room : Room bits profile) :
    ∀ nativeFuel, InternedMuDepthInventory.Bounded
      (SourceEqualityNativeDemand.execute nativeFuel
        (.code (SourceRecursiveIntersectionCode.requestNode
          IntersectionEmptyDomain.emptyDomain left right))
        beforeCaller.checked).state.native.machine.heap (step profile).mass := by
  obtain ⟨_next, _query, queried, _source, _roots, receipt, _post, _done, returnedFits, _mass⟩ :=
    SourceCurrentAllocatedTargetQuery.finite_caller_resources profile formulas solver inventory
      beforeCaller left right memos initial fits room leftAvailable rightAvailable leftClosed rightClosed
  have returnedBounded := InternedValueMassBinderDepth.stored_bounded
    queried.native.machine.heap (step profile).mass returnedFits.stored
  cases receipt.actual with
  | run trace =>
      exact trace.prefix_bounded_of_final initial.ready.good.native initial.ready.good.heap returnedBounded

end MicroCFTA.SourcePruningEnumerationIncomingQuery
