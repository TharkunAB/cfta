# Generator sequence resource audit

Date: 2026-10-29, Europe/Stockholm.
Status: SOURCE-ONLY. The new Lean candidate is UNTESTED. Root owns all checks.

## Result

The fixed-recursive-capacity resource producer already derives a finite resource forecast from original inputs. It does not assume a future query list or future query bounds. The smallest useful missing connection is quantitative: the existing checked-prefix theorem returns an existential ceiling, while the generator resource plan needs a ceiling identified with its computed profile. The new candidate supplies that connection at the actual checked query caller.

The candidate has no original-input theorem for sufficient recursive capacity. It has no ceiling independent of recursive capacity. It does not assert that every chosen model reaches an emitted output.

## Existing original-input resource result

`PreparedRecursive.Complete` quantifies the original inventory, caller, Memos, cached enumeration state, seed and suspended-mass ceiling. Its admissions are Packet, Fits, annotation-alphabet Heap, the global selection membership and length policies, the original suspended-mass inequality, and PreparedReservation.Reserved for the supplied recursiveFuel. There is no later caller, later model, finite query family, or later body-bound admission.

`PreparedRecursive.finite_complete` derives this contract by induction on recursiveFuel. The zero case uses the actual zero-capacity result. The successor case closes the callback contract with its induction hypothesis. Thus the contract's recursive supplier is discharged by the final producer.

`PreparedReservation.Reserved` is an arithmetic plan over original data. At depth zero it is True. Its successor branch checks each original planned stage and recursively checks the next fixed smaller capacity at the computed afterHead and massCeil. It does not quantify actual future query heaps as assumptions. `reserved_of_final_room` derives the plan from Room at the computed final profile. `reserved_computed` chooses a sufficient word width from that final profile. This width construction is for a chosen original configuration. It does not resize an already typed fixed-width caller.

The stable result may be complete or stopped. `OutcomeResources` retains an existential aggregate reached caller and its Fits, even when outputs are empty. It also retains the old OutputResources for each actual output. A stopped result with no attached endpoint is not assigned a fabricated actual endpoint. Each OutputResources retains Packet, Post, full Memos and Fits at that output's own caller.

`InternedValueMassBinderDepth.stored_bounded` already turns the Stored field of Fits into a strict Mu-body depth ceiling. In particular, the aggregate resource witness and every actual output have body ceiling

    (PreparedReservation.final recursiveFuel seed ceiling).2.mass

This is a derived fixed-capacity forecast. Writing another large endpoint wrapper around this theorem would add little.

`OriginalForecast.count` bounds one ordinary native scan from the original seed and inherited suspended count. It is not a bound on every recursive restart independently of recursiveFuel.

## New candidate

Path:

`candidate-v1/MicroCFTA/SourcePruningEnumerationCheckedQueryPrefixForecast.lean`

95 lines, 5412 bytes. SHA256:

`ad8a728c8bf94fd045d65fd7d70dcea30a78efd91571a68edaae32499cf5d069`

The candidate exports two theorems.

1. `PhysicalTraceCompletion.Trace.prefix_bounded_of_final`: a literal completed checked trace, original physical-cache Valid and required-cache Ready, and a bound at that trace's exact final heap imply the same bound at every runtime-fuel observation of the original checked control. This is an intermediate trace lemma. Its endpoint-bound premise is explicit.
2. `IncomingQuery.native_prefix_bounded_profile`: the same original inputs and admissions as `IncomingQuery.native_prefix_bounded` imply the explicit ceiling `(SourceCurrentAllocatedNativeResourceForecast.step profile).mass` at every nativeFuel. The caller theorem takes original Context, two Available closed operands, original Fits and original Room. It does not take a trace, completed return, final bound, annotation alphabet, DecidableEq Node, semantic-rank family, or future-query supplier.

The final theorem calls `TargetQuery.finite_caller_resources` once. This derives the actual completed Receipt, full checked endpoint and Fits at step profile from the original caller. The Stored field gives the endpoint body ceiling. The actual Receipt's Step.run trace discharges the local trace lemma. It preserves the exact original call, checked state and all observations of that state. It does not substitute the separate bare native interpreter.

The local proof uses actual PhysicalExecution.step_invariants. For runtimeFuel zero, old Mu records survive into the next trace state by Extension.heap.nodeRecords. The induction hypothesis therefore reflects the same final ceiling back to the original heap. For successor fuel, the literal yielded step exposes the actual suffix. This avoids a maximum over an externally supplied finite family.

There were no compiler attempts or compiler diagnostics in this task. There are no alternate failed candidate versions. Candidate-v1 is frozen and remains historically UNTESTED until Root checks its installed copy.

## How this helps successive actual queries

At a query site whose original caller has the resource profile used by the existing producer, the new theorem gives a numeric prefix ceiling from that profile. A later site uses its own actual caller and its own derived stage profile. Operands need to be Available in that actual query-entry heap. No backward reflection of operands into an older rebased inventory source is needed.

The next integration is to retain this explicit fact at the existing IncomingQuery/IncomingNode completion sites and transport the local stage ceilings through the original arithmetic forecast inequalities already used by the finite producer. This needs no finite list of future queries as a top-level admission. The candidate itself does not add a query-event trace or prove a theorem enumerating every internal query invocation of an outer driver run. The completed finite resource theorem currently exposes endpoints, outputs and selected receipt/history paths; it does not expose an all-query event inventory.

The result is sufficient to connect checked native prefixes to the existing fixed-capacity resource plan. It does not remove that plan's dependence on recursiveFuel. Root is auditing sufficient recursive capacity separately.

## What the model and history APIs do

PreparedPrefixModels supplies local forward Satisfies transport through the actual admitted parked or narrowed prefix. Its semantic interpretation uses the actual reached native heap. It still requires its exact unary/application/filter/type/admission gates. It does not supply a globally sufficient recursive capacity.

PreparedFiniteReceiptModels derives the actual callback record singleton and a false callback result under the supplied model, fill, Refutes, Avoids and encoding gates. It preserves the model into the exact recursive restart at the same supplied recursiveFuel. It does not assert that a later emitted output contains that model.

PreparedFiniteHeadCoverage retains the full original resource result and derives an actual completed accepting head with an extended assignment. Its exported semantic suffix stops at the head's afterCache. It does not give semantic models for the recursive callback's eventual outputs.

PreparedFiniteSiblingCoverage has an exact earlier-stop alternative. Given a chosen accepting selected edge and supported earlier edges, the theorem either reaches that chosen head or retains an actual strictly earlier recursive-hook stop. It records the exact processed-prefix length, actual completed prefix, actual callback receipt, full Posts and Memos, and the stopped resource outcome. Its result is not unconditional chosen-output coverage. The inspected complete exported statement is lines 49–164. The 475-line proof body was not reviewed here.

PreparedCallbackProgress preserves Packet, RenderStable, Frame, ProperState and Satisfies at an actually observed callback recording. It excludes a stuck restart from those gates. PreparedTerminalEmissionModels emits the actual model only under the explicit empty-candidates gate and the callback's model/avoidance/encoding conditions. Neither theorem proves that every chosen initial model reaches that empty-candidates situation.

ResourceHistoryCanonical and ResourceHistoryProper preserve their original predicates along an actual emitted output's resource history. The top combined original producer derives those histories at the chosen fixed capacity. The histories are not evidence that all desired model paths emit. OutputHistory and ResourceHistory are output-path relations, not a supplied sequence of all future native queries.

BoundaryPreparationBudget already connects a literal successful boundary prefix to actual entry and child allocation. It gives a strict unused-key-shape decrease at the exact same native handle. The finite shape carrier depends on the original whole model. It does not bound the set of future native handles. A history key's native node field must not be erased when using this decrease. An unconditional global rank cannot be inferred by summing this fixed-handle decrease without a proved handle-domain invariant.

The existing GeneratedQuerySequence.complete_many derives actual finite query receipts from an original supplied request list and a count reservation. This is a valid finite-sequence producer. Supplying that list is not proof that every future whole-generator query belongs to a bounded sequence. Its Pool.depth is a constrained guard cap, not the native Mu-body degree.

## Remaining scope

A single bound independent of arbitrary recursive capacity is not established by the inspected APIs. The final forecast is indexed by capacity, and the actual driver can return an exhausted stop at zero capacity. Exact complete-result monotonicity at greater capacity proves preservation of a completed observation; it does not prove the existence of such a capacity. Resource completion alone also permits empty outputs and stop-policy outputs.

A sufficient-capacity or global model-coverage proof must address the actual earlier recursive-hook stop, retain the chosen model through every relevant callback, and justify its ranking domain across native-handle changes. This report does not replace any of those obligations with a finite-family assumption. It also does not assert that global termination is false. The intended partial/opaque output semantics and concrete discharged rendering coverage remain distinct.

No Haskell change or new Haskell defect was found in this bounded audit.

## Read scope and evidence

There are 40 recorded content acquisitions from 31 source identities. Four are explicit whole-source requests and whole reviews: OriginalForecast (58 lines), PreparedFiniteContract (51 lines), InternedValueMassBinderDepth (72 lines), and PreparedOutcomeResources (162 lines). The other 36 are exact numbered cuts. This is below the limit of six whole sources.

`read-scope.json` retains full source SHA256/byte/line identities, literal requested cut endpoints, actual returned endpoints, copied-cut SHA256/bytes and the whole flag. Hash collection reads source bytes for identity; it does not imply that unrequested source text was reviewed. Input copies retain exactly the acquired scope. Some symbol-location rg searches were truncated. Those searches served only to locate definitions. No exhaustive review claim relies on their output. No compiler, evaluator, native job, Git, network, board operation or repository mutation was used.

The source-only proof and report are frozen. Root may repair the installed source without changing this candidate or its historical status.
