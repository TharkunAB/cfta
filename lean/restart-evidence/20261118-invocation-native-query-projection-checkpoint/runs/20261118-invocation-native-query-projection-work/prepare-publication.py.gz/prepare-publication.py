from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root/'lean/restart-evidence'
control = base/'20261118-invocation-native-query-projection-publication-control-draft'
stage_control = base/'20261118-invocation-native-query-projection-staging-control-draft'
work = base/'20261118-invocation-native-query-projection-work'
runtime = base/'20261118-invocation-native-query-projection-publication'
prior_work = base/'20261118-child-dispatch-query-seeds-work'
prior_run = base/'20261118-child-dispatch-query-seeds-publication'
prior_archive = base/'20261118-child-dispatch-query-seeds-checkpoint'
source_commit = json.loads((prior_work/'SOURCE-COMMIT.json').read_text())['source_commit']
assert Path(__file__).resolve().parent == work.resolve()
assert Path(__file__).read_bytes() == (control/'prepare-publication.py').read_bytes()
assert not runtime.exists(), 'Preserve every previous runtime.'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
bound = set()


def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256']if isinstance(record,dict)else record),str(path)
    if isinstance(record,dict)and 'bytes'in record:
        assert len(data) == record['bytes'],str(path)
    bound.add(path)
    return data


def records(value):
    if isinstance(value,list):
        return [(entry.get('file',entry.get('path')),entry)for entry in value]
    if 'files'in value:
        return records(value['files'])
    if 'pins'in value:
        return records(value['pins'])
    return value.items()


for name,record in records(read(control/'MANIFEST.json')['files']):
    verify(control/name,record)
bound.add(control/'MANIFEST.json')
for name,record in records(read(control/'ACTUAL-INPUT-PINS.json')):
    verify(root/name,record)
for name,record in records(read(stage_control/'MANIFEST.json')['files']):
    verify(stage_control/name,record)
bound.add(stage_control/'MANIFEST.json')
stage_bytes = (work/'SOURCES-NORMAL-STAGING.json').read_bytes()
assert stage_bytes == (control/'EXPECTED-STAGE.json').read_bytes()
stage = json.loads(stage_bytes)
assert stage['status'] == 'SOURCE_NORMAL_STAGING_COMPLETED'
assert stage['source_baseline'] == source_commit and stage['normal_Source_changed']and not stage['published']
assert (stage['source_files'],stage['audit_imports'],stage['audit_reports'],stage['independent_reports']) == (6286,5286,744,339)
assert (stage['fresh_reports'],stage['inherited_reports'],stage['combined_reports']) == (1,537,538)
assert stage['new_public_theorems'] == 1 and stage['new_private_helpers_transitive'] == 0
assert stage['new_Prop_definitions'] == stage['explicit_private_reports'] == 0
assert stage['new_definitions'] == stage['new_projection_definitions'] == stage['definition_checks'] == 1
assert stage['definition_axiom_credit'] == 0
assert stage['resource_owner_reports_inherited'] == 264 and stage['fresh_credit_for_old_owner_theorems'] == 0
stage_actual = read(work/'STAGING-ACTUAL-RUN.json')
assert stage_actual == read(control/'EXPECTED-STAGING-ACTUAL-RUN.json')
assert stage_actual['actual_terminal']and stage_actual['actual_terminal_exit'] == 0
assert stage_actual['control_manifest_sha256'] == sha((stage_control/'MANIFEST.json').read_bytes())
assert stage_actual['script_sha256'] == sha((stage_control/'stage-normal-sources.py').read_bytes())
assert stage_actual['normal_source_pins_sha256'] == stage['normal_source_pins_sha256']
assert stage_actual['exact_Source_write_paths'] == stage['exact_Source_write_paths']and stage_actual['git_index_empty']
bound.update([work/'SOURCES-NORMAL-STAGING.json',work/'STAGING-ACTUAL-RUN.json'])
overrides = stage['baseline_overrides']
components = stage['components']
assert len(components) == 1
component = components[0]
assert set(overrides) == {'lean/MicroCFTA/Audit.lean'}


def historical(name, record):
    digest = record['sha256']if isinstance(record,dict)else record
    for path in [root/name,root/overrides.get(name,name)]:
        if path.is_file()and sha(path.read_bytes()) == digest:
            return verify(path,record)
    raise AssertionError(name)


private = stage['private_subsets'][0]
private_control = base/private['control']
verify(private_control/'MANIFEST.json',private['control_manifest_sha256'])
for name,record in records(read(private_control/'MANIFEST.json')['files']):
    verify(private_control/name,record)
run = base/private['runtime']
receipt_path,actual_path = root/private['verified_receipt'],root/private['actual_receipt']
receipt,actual = read(receipt_path),read(actual_path)
assert receipt['actual_session'] == actual['actual_session'] == private['actual_session']
assert receipt['actual_terminal']and actual['actual_terminal']
assert receipt['actual_terminal_exit'] == actual['actual_terminal_exit'] == 0
assert receipt['selected_control'] == actual['selected_control'] == private['control']
assert receipt['selected_control_manifest_sha256'] == actual['selected_control_manifest_sha256'] == private['control_manifest_sha256']
checked = json.loads(verify(run/'checked.json',receipt['checked_sha256']))
assert checked == json.loads(verify(run/'results.json',receipt['results_sha256']))
assert checked['checks'] == receipt['checks']and checked['proof_credit']and checked['source_pins_unchanged']
assert len(checked['checks']) == 1
check = checked['checks'][0]
assert check['exit'] == 0 and not check['diagnostics']and not check['sorryAx']and not check['nonstandard_axioms']
assert check['total_axiom_reports'] == 1 and check['declaration_checks'] == 1
assert check['axiom_groups'] == private['axiom_groups']and check['axiom_free_reports'] == private['axiom_free_reports']
assert checked['definition_axiom_credit'] == checked['new_private_helpers_transitive'] == 0
assert checked['limits'] == {'memory.max':'8589934592','memory.high':'8589934592','memory.swap.max':'0'}
pins = json.loads(verify(run/'source-pins.json',receipt['source_pins_sha256']))
assert len(pins) == receipt['pins_independently_reverified'] == private['pins']
for name,record in pins.items():
    historical(name,record)
bound.update([receipt_path,actual_path,run/(component['module']+'.txt')])
chosen = {item['module']:item for item in read(private_control/'SELECTION.json')['components']}
assert list(chosen) == stage['compile_order']
# Failed original checks retain their actual generated sorryAx and zero credit.
for rejected in stage['rejected_checks']:
    rejected_path = root/rejected['receipt']
    failed_receipt = read(rejected_path)
    failed_run = base/rejected['runtime']
    assert failed_receipt['actual_terminal']and failed_receipt['actual_terminal_exit'] == 1
    assert failed_receipt['actual_session'] == rejected['actual_session']
    failed = json.loads(verify(failed_run/'results.json',failed_receipt['results_sha256']))
    assert not failed['proof_credit']and failed['credited_public_reports'] == 0 and not (failed_run/'checked.json').exists()
    assert failed['checks'] == failed_receipt['checks']
    assert sum(item['diagnostics']for item in failed['checks']) == rejected['diagnostics']
    assert any(item['sorryAx']for item in failed['checks']) == rejected['sorryAx']
    failed_pins = json.loads(verify(failed_run/'source-pins.json',failed_receipt['source_pins_sha256']))
    assert len(failed_pins) == rejected['pins']
    for name,record in failed_pins.items():
        historical(name,record)
    bound.add(rejected_path)
    for item in failed['checks']:
        bound.add(failed_run/(item['name']+'.txt'))
baseline_path = root/stage['source_baseline_path']
baseline_wrapper = read(baseline_path)
assert baseline_wrapper['source_commit'] == source_commit and baseline_wrapper['source_files'] == 6285
baseline = {name:record['sha256']for name,record in baseline_wrapper['sources'].items()}
for name,record in {**baseline_wrapper['sources'],**baseline_wrapper['toolchain']}.items():
    historical(name,record)
current = sorted((root/'lean/MicroCFTA').glob('*.lean'))
assert component['source_path']not in baseline
assert len(current) == 6286 and {str(path.relative_to(root))for path in current} == set(baseline)|{component['source_path']}
assert len(set(baseline)-set(overrides)) == 6284
normal_pins_path = work/'NORMAL-SOURCE-PINS.json'
normal_pins = json.loads(verify(normal_pins_path,stage['normal_source_pins_sha256']))
assert len(normal_pins) == 6290
for name,record in normal_pins.items():
    verify(root/name,record)
push = read(prior_work/'PUSH-VERIFIED.json')
prior_source = read(prior_work/'SOURCE-COMMIT.json')
prior_publication = read(prior_work/'PUBLICATION-VERIFIED.json')
assert push['source_commit'] == prior_source['source_commit'] == source_commit
assert push['checkpoint_commit'] == push['remote_commit']
assert push['actual_push_terminal']and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal']and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
assert prior_publication['actual_session'] == prior_source['publication_actual_session'] == 72804
assert prior_publication['actual_terminal']and prior_publication['actual_terminal_exit'] == 0
assert prior_publication['combined_reports'] == 537 and prior_publication['resource_reports_inherited'] == 264
verify(prior_archive/'manifest.json',push['archive_manifest_sha256'])
subprocess.run(['git','merge-base','--is-ancestor',push['checkpoint_commit'],'HEAD'],cwd=root,check=True)
prior_checked = read(prior_run/'checked.json')
assert prior_checked['all_five_gates_passed']and prior_checked['source_pins_unchanged']
assert (prior_checked['source_files'],prior_checked['independent_reports'],prior_checked['resource_and_component_probes']) == (6285,338,537)
for name,record in read(prior_run/'source-pins.json').items():
    historical(name,record)
bound.update([prior_work/'PUSH-VERIFIED.json',prior_work/'SOURCE-COMMIT.json',prior_work/'PUBLICATION-VERIFIED.json',
    prior_work/'PUBLICATION-ACTUAL-RUN.json',prior_run/'checked.json',prior_run/'source-pins.json',prior_run/'IndependentProbes.lean',
    prior_archive/'manifest.json',prior_archive/'verify.py',prior_archive/'archived-inputs.json'])
original = chosen[component['module']]
for key in ['module','packet','manifest_sha256','source','raw_sha256','raw_bytes','probe','probe_sha256','public_qnames','expected_axiom_reports','expected_declaration_checks','definition_qname','headers']:
    assert component[key] == original[key],key
packet = base/component['packet']
verify(packet/'MANIFEST.json',component['manifest_sha256'])
for name,record in records(read(packet/'MANIFEST.json')['files']):
    verify(packet/name,record)
for filename in ['SOURCE-PINS.json','ADDITIONAL-SOURCE-PINS.json','DEPENDENCY-PINS.json']:
    if (packet/filename).exists():
        for name,record in records(read(packet/filename)):
            historical(name,record)
raw = verify(root/component['source_path'],{'sha256':component['raw_sha256'],'bytes':component['raw_bytes']})
assert raw == (packet/component['source']).read_bytes()
for filename,digest in component['headers'].items():
    header = verify(packet/filename,digest).rstrip()
    assert raw.count(header) == 1 and raw[raw.index(header)+len(header):].lstrip().startswith(b':=')
assert len(re.findall(rb'^theorem ',raw,re.M)) == 1 and len(re.findall(rb'^noncomputable def ',raw,re.M)) == 1
assert not re.search(rb'^private theorem |set_option\s+(maxHeartbeats|maxRecDepth|warningAsError|linter\.)',raw,re.M)
public = verify(packet/component['public_probe'],component['public_probe_sha256'])
definition = verify(packet/component['definition_probe'],component['definition_probe_sha256'])
combined = verify(packet/component['probe'],component['probe_sha256'])
assert definition == ('#check '+component['definition_qname']+'\n').encode()
assert combined == definition+public and public.count(b'#print axioms ') == 1 and b'#check 'not in public
assert re.findall(r'^#print axioms (\S+)',public.decode(),re.M) == component['public_qnames']
assert definition == (control/'EXPECTED-DEFINITION-CHECK.lean.txt').read_bytes()
assert public == (control/'EXPECTED-PUBLIC-PROBES.lean.txt').read_bytes()
fixture = run/'source/MicroCFTA'/component['source']
assert fixture.read_bytes() == raw+b'\n'+combined
bound.add(fixture)
raw_sources = {component['module']:raw}
old_audit = verify(root/overrides['lean/MicroCFTA/Audit.lean'],{'sha256':stage['old_audit_sha256'],'bytes':436549})
audit_import = (stage_control/'IMPORTS.lean.txt').read_bytes()
assert audit_import == ('import MicroCFTA.'+component['module']+'\n').encode()and len(audit_import) == 73
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes() == audit_import+old_audit+b'\n'+public
assert old_audit.count(b'#print axioms ') == 743
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes().count(b'#print axioms ') == 744
assert sum(line.startswith(b'import ')for line in (root/'lean/MicroCFTA/Audit.lean').read_bytes().splitlines()) == 5286
assert definition not in (root/'lean/MicroCFTA/Audit.lean').read_bytes()
prior_independent = (prior_run/'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 338
assert audit_import not in prior_independent.splitlines(keepends=True)
resource_owner = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = sha((root/resource_owner).read_bytes())
assert owner_sha == baseline[resource_owner]
normal_objects = root/'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()
edges,active,visited,ordered = {},set(),set(),[]


def walk(module):
    if module in visited:
        return
    assert module not in active,('import cycle',module)
    active.add(module)
    edges[module] = re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$',(root/'lean/MicroCFTA'/(module+'.lean')).read_text(),re.M)
    if module not in chosen:
        assert (normal_objects/(module+'.olean')).is_file(),module
    for child in edges[module]:
        walk(child)
    active.remove(module)
    visited.add(module)
    ordered.append(module)


for module in stage['compile_order']:
    walk(module)
dag = read(control/'TOPOLOGICAL-ORDER.json')
assert edges == dag['direct_imports']and ordered == dag['full_transitive_order']
assert [module for module in ordered if module in chosen] == stage['compile_order']
for name in ['strict-bind.py.txt','publication-driver.py.txt','shadow-compile.py.txt']:
    ast.parse((control/name).read_text())
# Root materializes a fresh publication namespace after every read-only gate passes.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-invocation-native-projection-publication-'))
(objects/'MicroCFTA').mkdir()
for obj in normal_objects.glob('*.olean'):
    if obj.stem not in chosen:
        (objects/'MicroCFTA'/obj.name).symlink_to(obj)
for module in chosen:
    assert not (objects/'MicroCFTA'/(module+'.olean')).exists()
(runtime/'objects.json').write_text(json.dumps({'path':str(objects)},indent=2)+'\n')
for module,raw in raw_sources.items():
    fixture = runtime/'source/MicroCFTA'/(module+'.lean')
    fixture.parent.mkdir(parents=True,exist_ok=True)
    fixture.write_bytes(raw)
    bound.add(fixture)
fresh_imports = ''.join('import MicroCFTA.'+module+'\n'for module in stage['compile_order']).encode()
(runtime/'FreshPublicProbes.lean').write_bytes(fresh_imports+definition+public)
(runtime/'IndependentProbes.lean').write_bytes(fresh_imports+prior_independent+b'\n'+public)
for src,dst in [('strict-bind.py.txt','strict-new-and-bind.py'),('publication-driver.py.txt','check.py'),('shadow-compile.py.txt','shadow-compile.py')]:
    (runtime/dst).write_bytes((control/src).read_bytes())
(runtime/'REPORT-BASE.json').write_bytes((control/'REPORT-BASE.json').read_bytes())
inheritance = {'compile_order':stage['compile_order'],'definition_names':[component['definition_qname']],'prior_checkpoint':push['checkpoint_commit'],
    'prior_archive_manifest_sha256':push['archive_manifest_sha256'],'prior_checked_sha256':sha((prior_run/'checked.json').read_bytes()),
    'prior_pins_sha256':sha((prior_run/'source-pins.json').read_bytes()),'stage_sha256':sha(stage_bytes),
    'baseline_sha256':sha(baseline_path.read_bytes()),'baseline_path':str(baseline_path.relative_to(root)),
    'baseline_overrides':overrides,'override_digests':{name:sha((root/path).read_bytes())for name,path in overrides.items()},
    'inherited_reports':537,'fresh_reports':1,'combined_reports':538,'resource_owner_sha256':owner_sha,
    'resource_owner_reports_inherited':264,'owner_preflight_reports_fresh_this_batch':0,'new_private_helpers':0,
    'Prop_declaration_checks':0,'Prop_axiom_credit':0,'actual_private_sessions':[private['actual_session']],
    'definition_axiom_credit':0,'new_projection_definitions':1,
    'fresh_axiom_groups':private['axiom_groups'],'fresh_axiom_free_reports':private['axiom_free_reports'],
    'independent_axiom_groups':prior_checked['checks'][2]['axiom_groups']+private['axiom_groups'],
    'independent_axiom_free_reports':prior_checked['checks'][2]['axiom_free_reports']+private['axiom_free_reports'],
    'audit_axiom_groups':prior_checked['checks'][4]['axiom_groups']+private['axiom_groups'],
    'audit_axiom_free_reports':prior_checked['checks'][4]['axiom_free_reports']+private['axiom_free_reports'],'fresh_owner_theorem_credit':0,'cache_data_copied':False}
(runtime/'INHERITANCE-SELECTION.json').write_text(json.dumps(inheritance,indent=2)+'\n')
bound.update([Path(__file__),baseline_path,control/'TOPOLOGICAL-ORDER.json'])
bound.update(current)
bound.update(path for path in runtime.iterdir()if path.is_file())
(runtime/'source-pins.json').write_text(json.dumps({str(path.relative_to(root)):sha(path.read_bytes())for path in sorted(bound)},indent=2,sort_keys=True)+'\n')
print(json.dumps({'runtime':str(runtime),'gates':5,'fresh_modules':1,'fresh_reports':1,'inherited_reports':537,
    'combined_reports':538,'source_files':6286,'audit_imports':5286,'audit_reports':744,'independent_reports':339,'normal_Source_changed':False}))
