import MicroCFTA.SourcePruningEnumerationSelectedOpaqueDispatch
import MicroCFTA.SourcePruningEnumerationChildCanonical
import MicroCFTA.SourcePruningEnumerationOwnFinalizeCanonical

/-!
# Canonical storage through actual prepared opaque dispatch

The actual successful child row supplies its exact attached cache.
The captured-target finalizer preserves canonical stored suspended tries.
-/
namespace MicroCFTA.SourcePruningEnumerationSelectedOpaqueDispatch
open EnumerationState EnumerationCorrectness EnumerationValidity InternedConstructorTemplates
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Fragment" => Fragments.Fragment Symbol
variable {width : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Actual completed opaque or terminal dispatch preserves canonical storage. -/
theorem complete_canonical
    {checkEmpty : Bool} {r n p h k target : Nat} {scs : List Suspended} {value : Node}
    {caller reached : Caller width} {before after : Cached} {queries saved : Queries} {fragment : Fragment}
    (canonical : Canonical before.core) (inputs : ValidSuspended scs)
    (completed : run checkEmpty r n p h k target scs value caller before queries =
      some (.complete fragment reached saved after)) : Canonical after.core := by
  unfold run at completed
  split at completed
  · cases completed
  · split at completed
    · cases completed
    · split at completed
      next produced returned childCaller childQueries outer waiting middle childRun =>
        simp only [Option.map_eq_some_iff] at completed
        obtain ⟨finished, finishRun, fields⟩ := completed
        have cacheSame : finished = after :=
          (SourcePruningEnumerationSelectedEdge.Result.complete.inj fields).2.2.2
        rw [← cacheSame]
        exact SourcePruningEnumerationFinalize.run_canonical
          childCaller.checked.native.machine.heap k target produced middle finished
          (SourcePruningEnumerationChildDispatch.successful_canonical canonical inputs childRun) finishRun
      next => cases completed

end MicroCFTA.SourcePruningEnumerationSelectedOpaqueDispatch
