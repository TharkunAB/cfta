"""Check checkpoint identities before sealing the complete evidence area."""
from pathlib import Path
import hashlib
import json

area = Path(__file__).parent
repo = Path('/home/tritlo/Code/mcfta')

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def read_json(path):
    return json.loads(path.read_text())

def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': digest(raw)}

manifest = read_json(area/'root-review/public-block-manifest.json')
expected = {row['index']: row for row in manifest}
assert len(expected) == 49
public = (area/'public-readback-final/raw.log').read_bytes()
prior = (area/'prior-public-readback/raw.log').read_bytes()
assert len(prior) == 2610680 and public.startswith(prior)
assert b''.join((area/row['path']).read_bytes() for row in manifest) == public[len(prior):]
seen = set()
reviews = []
for owner, filename, rows_key, copy_key in [
    ('ordinary-gates', 'review.json', 'blocks', 'copy'),
    ('canonical', 'REPORT.json', 'block_reviews', 'copied_path'),
    ('opaque', 'review.json', 'blocks', 'copied_block'),
]:
    folder = area/owner/'public-review-v1'
    report = read_json(folder/filename)
    assert not report.get('findings', []) and not report.get('blocking_findings', [])
    rows = report[rows_key]
    for row in rows:
        original = expected[row['index']]
        assert row['index'] not in seen
        for key in ['index', 'declaration', 'module', 'path', 'bytes', 'sha256']:
            assert row[key] == original[key], (owner, row['index'], key)
        assert row['whole_block_read'] is True
        assert identity(folder/row[copy_key]) == {k: row[k] for k in ['bytes', 'sha256']}
        assert (folder/row[copy_key]).read_bytes() == (area/row['path']).read_bytes()
        source = repo/'lean/MicroCFTA'/f"{row['module']}.lean"
        source_hash = row['source']['sha256'] if 'source' in row else row['source_sha256']
        assert identity(source)['sha256'] == source_hash
        seen.add(row['index'])
    reviews.append({'owner': owner, 'path': str((folder/filename).relative_to(area)),
                    **identity(folder/filename), 'blocks': len(rows),
                    'public_bytes': sum(row['bytes'] for row in rows)})
assert seen == set(expected)
assert sum(row['public_bytes'] for row in reviews) == 149602
assert len({row['module'] for row in manifest}) == 30

preservation = {}
for filename, count in [('prior-lean-sources.json', 4432),
                        ('prior-strong-sources.json', 281),
                        ('prior-haskell-sources.json', 817)]:
    records = read_json(area/filename)
    assert len(records) == count
    for row in records:
        actual = identity(repo/row['path'])
        assert actual['sha256'] == row['sha256']
        if 'bytes' in row:
            assert actual['bytes'] == row['bytes']
    preservation[filename] = len(records)

doc_rows = read_json(area/'root-review/document-prefixes.json')
assert len(doc_rows) == 10
for row in doc_rows:
    raw = (repo/row['path']).read_bytes()
    prefix, old = raw[:row['prefix_bytes']], raw[row['prefix_bytes']:]
    assert len(raw) == row['bytes'] and digest(raw) == row['sha256']
    assert digest(prefix) == row['prefix_sha256']
    assert len(old) == row['prior_bytes'] and digest(old) == row['prior_sha256']
    assert old == (area/row['prior_path']).read_bytes()

doc_review = read_json(area/'ordinary-gates/document-review-v1/review.json')
assert doc_review['status'] == 'PASS' and doc_review['remaining_corrections'] == []
note = repo/doc_review['new_note']['path']
assert identity(note) == {k: doc_review['new_note'][k] for k in ['bytes', 'sha256']}
assert doc_review['prefix_count'] == 10 and doc_review['all_retained_bodies_byte_equal']
assert all(row['verdict'] == 'PASS' for row in doc_review['comparisons'])
assert len(doc_review['strict_results']) == 31
for row in doc_review['strict_results']:
    assert row['exit_code'] == 0 and row['flags_match'] and row['raw_identity_match']
    assert row['current_source_identity_match']

source_report = read_json(area/'source-validation.json')
assert source_report['status'] == 'pass'
for module, sha in source_report['source_hashes'].items():
    assert identity(repo/'lean/MicroCFTA'/f'{module}.lean')['sha256'] == sha
assert identity(repo/'lean/MicroCFTA/Audit.lean')['sha256'] == '8abc13d48a38c77d46d897ae9e10769ecd1c4c4eb91023aec93db8101a585e64'

request = read_json(area/'semantic-gates-board-request.json')
readback = read_json(area/'semantic-gates-board-readback.json')['structuredContent']['items'][0]
assert readback['id'] == request['request_id']
assert readback['content'] == request['content'] and readback['metadata'] == request['metadata']

for module in [*source_report['source_hashes'], 'Audit']:
    source = repo/'lean/MicroCFTA'/f'{module}.lean'
    target = area/'final-sources'/source.relative_to(repo)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
for rel in [*(row['path'] for row in doc_rows), str(note.relative_to(repo))]:
    target = area/'final-documents'/rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((repo/rel).read_bytes())

result = {'status': 'pass', 'source_commit': '1115481c15dec8193b8d0594366ee5d068c24331',
          'whole_public_blocks': 49, 'new_public_bytes': 149602,
          'independent_reviews': reviews, 'preservation': preservation,
          'old_document_bodies_preserved': 10, 'old_document_bytes': sum(r['prior_bytes'] for r in doc_rows),
          'document_review': 'pass; initialMass omission resolved',
          'source_snapshots': 31, 'document_snapshots': 11,
          'board_exact_readback': request['request_id'], 'whole_goal_complete': False,
          'remaining': ['global stable opaque history decoration', 'forward whole-driver input arity',
                        'backward semantic induction', 'public rendering/discharge and accepted coverage',
                        'sufficient recursive depth', 'full public API and Haskell correspondence']}
(area/'root-review/final-review.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
