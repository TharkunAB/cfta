from pathlib import Path
import json,re
r=Path('/home/tritlo/Code/mcfta');a=Path('/tmp/mcfta-prepared-history-semantics-20261028')
modules=json.loads((a/'modules.json').read_text());new=[]
for m in modules:
 namespace=''
 scopes=[]
 for line in (r/'lean/MicroCFTA'/(m+'.lean')).read_text().splitlines():
  if line.startswith('namespace '):
   name=line.split()[1]
   scopes.append(namespace)
   namespace=(namespace+'.'+name if namespace else name)
  elif re.match(r'^(?:noncomputable\s+)?section(?:\s|$)',line):scopes.append(namespace)
  elif re.match(r'^end(?:\s|$)',line):namespace=scopes.pop()
  match=re.match(r'^theorem ([A-Za-z_][A-Za-z_0-9.]*)(?:\s|$)',line)
  if match:
   assert namespace,(m,line)
   assert namespace.startswith('MicroCFTA.'),(m,line,namespace)
   new.append(namespace.removeprefix('MicroCFTA.')+'.'+match.group(1))
 assert not scopes,m
assert len(new)==len(set(new))
old=json.loads((a/'prior-public-declarations.json').read_text());assert not set(old)&set(new)
(a/'new-public-declarations.json').write_text(json.dumps(new,indent=2)+'\n')
(a/'public-declarations.json').write_text(json.dumps(old+new,indent=2)+'\n')
print(json.dumps(dict(modules=len(modules),new_theorems=len(new),total=len(old)+len(new),new=new)))
