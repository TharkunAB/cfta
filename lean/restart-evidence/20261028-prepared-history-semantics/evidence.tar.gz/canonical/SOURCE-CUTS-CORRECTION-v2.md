# Source cut line bounds

Use literal-cuts-v2 and arity-literal-cuts-v2 as the exact source range manifests.
The earlier v1 cut bytes were literal and their hashes were correct.
Some requested v1 line ranges extended beyond the end of their source file.
The v2 names and manifests use the actual last source line.
All earlier files remain preserved.
