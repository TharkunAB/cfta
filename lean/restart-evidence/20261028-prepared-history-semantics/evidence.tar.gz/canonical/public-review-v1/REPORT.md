# Assigned public statement review

Completed: 2026-10-28T16:13:20+01:00.

Result: PASS with the explicit scope gates below. No declaration mismatch or path-binding defect was found.

I read all 13 assigned whole blocks. They contain 53,148 bytes. Each copied block matches its assigned byte count and SHA-256 value. The assigned modules and the old opaque producer were read whole. The source snapshots had the same hashes on the final repository reread.

This review did not run Lean or change the repository or Root review area. Root reports that all 30 modules and Audit passed strict checking. Root also reports the public readback counts and exact old-prefix retention. This report independently reviews only the 13 assigned blocks.

## Old result and observer retention

The new local producer keeps the same eight witnesses and all 17 old result fields. A mechanical comparison confirms that the entire old producer signature is a literal whitespace-normalized prefix of the new signature after the theorem name changes. The new stable observer is the last added field.

The retained old fields are: stable head run; full native Post; saved-query equality; receipt advance; Admitted; Pending; original FragmentHistory; head Fits; head annotation Heap; complete/stopped/rejected shape and its exact Packet and bounds; padded Fits; padded Heap; continuation outcome equation; receipt-fold equation; finished OutcomeResources; composed opaque-fold equation; and the old output-history observer.

OpaqueOutputStableHistoryAt keeps the complete old OpaqueOutputHistoryAt as its first conjunct. Its forget theorem returns that exact observer with the same arguments and output. The old observer retains the full returned Memos and the exact false callback tail.

The global PreparedFiniteHistoryContract is byte-identical to baseline 4a7e3e5a8. Stable resource evidence remains a result of the local opaque producer. The new wrapper still requires the smaller-depth CompleteWithHistory premise. It does not promote that local result into every global ResourceHistory.

## Whole block conclusions and gates

### 00. SourcePruningEnumerationPreparedNativeHookResources.OpaqueOutputStableHistoryAt

The exact old OpaqueOutputHistoryAt observer is the first conjunct. The added conjunct retains an original opaque resource seed and the same complete receipt at every larger diagonal work fuel.

Premises: The old observer keeps the same policies, caller, full Memos, input cache, captured target, inherited bucket, prepared value, recursive depth, and output. The resource observer is conditional on an actual complete dispatcher result at the indexed workFuel.

Scope: This is a new local observer. The global ResourceHistory contract does not supply it. The stable family preserves the same fragment, reached caller, saved queries, and full attached cache. It does not reconstruct full Memos from saved queries. The seed must satisfy Fits, Reserved for scs.length + 1, and the original annotation Heap.

Path binding: The old observer fixes the actual receipt and its exact callback/output path. The additional resource family uses the identical dispatcher input and complete-result fields.

### 13. SourcePruningEnumerationSelectedOpaqueDispatch.stable_complete_neutral_resources

Satisfies at the actual completed cache implies Satisfies of the original cache with the captured target neutralized, prepared-value meaning, the exact effective suspended bucket, and fill(fragment) = assignment(target).

Premises: Original Packet, selected Ready, stored handle and bucket, available closed prepared value, and opaque dispatch gate. Original Fits, Reserved for scs.length + 1, and annotation Heap. An actual stable family of complete dispatcher observations at all bound + extra work fuels.

Scope: The theorem retains the bucket actually stored by that child branch. A nonterminal non-node branch can retain an empty bucket. The conclusion does not restore the original target payload or all original bucket restrictions. Satisfies of the reached cache is the antecedent of a backward implication. The theorem does not assume the existence of a future satisfying assignment. A single complete point observation does not supply the stable-family premise.

Path binding: The same fragment, reached caller, saved queries, and attached cache occur in the stable family and finalizer reconstruction.

### 14. SourcePruningEnumerationSelectedOpaqueDispatch.stable_complete_sound_retained_resources

Under exact source/prepared meaning equivalence and retained-bucket admission, reached Satisfies restores the full original Satisfies, prepared and source value meaning at the target, all original suspended restrictions, and fragment fill equality.

Premises: All original resource and actual stable-completion premises of the neutral theorem. The stored source handle decodes to sourceValue. The prepared value remains a separate value. Prepared and source values have equal meaning under the same PCS guard semantics. Retained means an ordinary node, a terminal inherited bucket, or an empty bucket.

Scope: The retained condition remains explicit. No discarded nonempty bucket is silently restored. The prepared value is not equated with the stored source value. Only the stated semantic equivalence connects them. This is a local conditional semantic theorem. It does not establish global output soundness or generate the stable family.

Path binding: The proof restores the exact stored source slot and exact inherited scs at the same captured target from the same completed fragment.

### 15. SourcePruningEnumerationSelectedOpaqueDispatch.complete_boundary_of_nonterminal

An actual completed closed nonterminal selected opaque value is a recursive boundary.

Premises: The value is closed. The inherited bucket has no terminal trie. One actual complete dispatcher observation at the supplied r, n, p, h, k fuels.

Scope: No stable family, reservation, future bound, or semantic model is assumed. The result classifies successful nonterminal dispatch. It does not classify every input or every stopped result.

Path binding: The completed observation fixes the same input value, caller, cache, query state, target, and reached result.

### 16. SourcePruningEnumerationSelectedOpaqueDispatch.complete_opaque_isolated

The actual nonterminal opaque completion keeps the caller and query state, returns the fresh-counter hole, and leaves an encoded and decoded isolated pending boundary at that fresh slot in its exact attached cache.

Premises: Original Packet, captured target strictly below the original counter, and available closed recursive-boundary value. The inherited bucket is nonterminal. One actual complete dispatcher observation is supplied.

Scope: No stability family or additional reservation is supplied. The isolated marker is the fresh slot at before.core.counter. The captured finalizer writes a different target. The theorem does not itself attach a later callback or output history.

Path binding: The encoded value, reached heap lookup, hole fragment, and isolated marker belong to this exact actual child/finalizer result.

### 41. SourcePruningEnumerationPreparedNativeHookResources.OpaqueOutputStableHistoryAt.forget

Forgetting the added resource observer returns precisely the old OpaqueOutputHistoryAt at every identical argument and the same output.

Premises: An OpaqueOutputStableHistoryAt at the same work and recursive fuels and exact caller, full Memos, metadata, input cache, target, bucket, value, and output.

Scope: The proof is the first projection. It changes no output or observer index. It does not infer the added stable resources from the old observer.

Path binding: Every caller, cache, full memo state, captured argument, and output index is retained literally.

### 42. SourcePruningEnumerationPreparedNativeHookResources.opaque_finite_complete_resources_with_stable_history

The old opaque finite producer runs once and keeps its same eight witnesses and all 17 old result fields. The result appends OpaqueOutputStableHistoryAt for each exact output of the same folded continuation at the same chosen bound + extra.

Premises: The smaller-depth CompleteWithHistory contract remains an explicit premise. Original Packet, Ready, stored target handle/bucket, IncomingAvoid, available closed value, and opaque dispatch gate. Original Fits and annotation Heap, selector membership and length laws, captured mass and inherited bucket bounds, and HeadReserved.

Scope: This result is local. It does not add stable resource evidence to global ResourceHistory or to the top-level finite history producer. All old receipt shapes remain: complete with Packet and counter/mass bounds, empty-row stopped result with bounds, or original rejection. All original Posts, full Memos, saved-query equality, receipt admission, pending facts, fragment history, resource fits/heaps, continuation equations, folded result, final resources, and old output observer remain. The added resource seed is derived from the original seed and reservation. The theorem does not replace the old work bound or outcome.

Path binding: Both observers quantify over the same foldOutputs folded output and bound + extra. Actual receipt equality identifies the stable family with that exact output head, not another sibling or endpoint.

### 43. SourcePruningEnumerationNativeIndex.count_some_moreFuel

A successful waiting-count pass returns the identical saved waiting map at fuel + extra.

Premises: An actual count result some saved at the original fuel, forest, signed change, bucket, and initial waiting map.

Scope: This applies to a successful some result. It does not assert stability of failure or general dispatcher outcomes. The forest and all other inputs stay fixed.

Path binding: The exact saved map is unchanged.

### 44. SourcePruningEnumerationNativeIndex.write_some_moreFuel

A successful native indexed write returns the identical entire attached cache at fuel + extra.

Premises: An actual write result some after with the fixed native heap, target, new value, gained/lost buckets, and input cache.

Scope: Only the indexed representative/count fuel increases. The native heap and write inputs stay fixed. The theorem does not imply whole selected-worker or history stability.

Path binding: The complete after cache, including core and cached indexes, remains identical.

### 45. SourcePruningEnumerationFinalize.run_some_moreFuel

A successful captured finalizer returns the identical entire cache at every larger index fuel.

Premises: An actual finalizer result some after for the fixed native heap, captured target, fragment, and input cache.

Scope: This is finalizer index-fuel stability. It does not establish child or native-query stability. It assumes a successful point result and does not classify none outcomes.

Path binding: The original captured target, fragment, input cache, and entire returned cache remain identical.

### 46. SourcePruningEnumerationEnabledEmpty.check_done_stable

A completed enabled emptiness check retains the same Bool answer, entire checked state, fourth memo, and endpoint query memo at larger p and h bounds.

Premises: An actual done answer after saved result and its returnedQueries. p <= P and h <= H.

Scope: Only completed done results are covered. No stability of pending, failed, or exhausted results is claimed. The query, original checked state, fourth memo, and input query memo remain fixed.

Path binding: Every done-result field and the returned endpoint query memo are unchanged.

### 47. SourcePruningEnumerationSelectedOpaqueDispatch.completed_opaque_output_not_discharged

A nonterminal opaque completion followed by its actual false callback and recorded remaining ResourceHistory cannot have a structurally Discharged output cache.

Premises: Original Packet, target inside the original counter, available closed value, nonterminal bucket, and one actual complete receipt. The completed Packet uses this reached caller, returnedInventory, returnedMemos, metadata, and exact after cache. The actual recordTypes singleton is false with the supplied fragment, recorded metadata, and callbackCore. The tail ResourceHistory uses exactly returnedInventory, reached, full returnedMemos, recorded metadata, frame callbackCore after, actual restart decision, and this output.

Scope: The result excludes only the stated nonterminal opaque route. It does not exclude terminal opaque branches. It uses a point completion and actual path, without requiring a stable family or output semantic model. The conclusion is structural non-discharge. It does not restore discarded suspended restrictions.

Path binding: The same complete receipt supplies the fragment/cache; that exact cache feeds the false callback; its exact returned core and metadata feed this tail and this output.

### 48. SourcePruningEnumerationPreparedRecursive.parked_tail_created_isolated

The actual parked prefix creates an isolated recursive-boundary marker at its selected existing root. The same marker and native decode survive to this output, so its cache is not Discharged.

Premises: Original Packet and actual restart decision selecting expand uv. PrefixValid for the actual same diagonal workFuel runPrefix. The observed parked result contains the exact checked core, parked cache, and singleton updated metadata/next/core restart row. The actual tail ResourceHistory keeps the original caller, inventory, full Memos, updated metadata, frame core parked, same next, and this output.

Scope: The actual restart row determines the tail metadata, core, and decision. No arbitrary endpoint equality is supplied. The result excludes discharged outputs through this parked path. It does not claim the removed bucket restrictions follow from ancestry alone. No Canonical or ProperState premise and no stable future execution are added.

Path binding: The original source handle, bucket, selected uv, parked cache, restart singleton, and output native heap belong to one exact actual path.

## Review boundaries

The neutral opaque theorem proves only the original cache with the captured target neutralized. Its effective bucket matches the actual child branch. The restoration theorem explicitly requires retained bucket evidence and source/prepared meaning equivalence. Neither theorem constructs a future model or derives a stable family from a point completion.

The point stability theorems cover successful count, indexed write, and finalizer results, or completed emptiness results. They retain the exact returned maps, caches, checked states, and memo fields. They do not establish general recursive-worker stability.

The opaque attachment excludes the exact nonterminal opaque path. The parked attachment excludes the exact parked path. Each uses its own actual callback or restart row and its own actual ResourceHistory output. Neither borrows a sibling endpoint. Neither claims that ancestry restores removed suspended restrictions.

Every assigned theorem axiom list uses only propext and Quot.sound, with Classical.choice where printed. The assigned definition block has no separate printed axiom list.

No proof fixes or Haskell fixes were identified in this review. No additional proof scope was started.

## Artifacts

- assignment.json preserves the exact assignment.
- assigned-whole-blocks preserves all 13 complete copied blocks.
- ASSIGNED-SHA256SUMS identifies every copied block.
- current-source and SOURCE-SHA256SUMS preserve the compared source files.
- producer-signature-comparison preserves both complete producer signatures.
- source-observations.json records the mechanical source comparisons.
- REPORT.json records the named conclusion, premises, scope gates, source identity, and path binding for each block.
