# Prepared history canonical preservation

Measured start: 2026-10-28 15:18 CET.
Baseline head: 4a7e3e5a8e8fd881466c85e3f659cf5e4c6e8d6e.
No compiler, native run, Git mutation, or repository write was performed here.
All candidate files are uncompiled drafts for Root to check.
The original source files and their SHA-256 identities are in baseline-4a7e3e5a8.
Exact literal cuts are in literal-cuts-v1. Their manifest gives source ranges and whole-file identities.

The candidate chain adds five modules in this order:
1. SourcePruningEnumerationPreparedCapturedCanonical.lean
2. SourcePruningEnumerationPreparedHeadReceiptCanonical.lean
3. SourcePruningEnumerationSelectedOpaqueCanonical.lean
4. SourcePruningEnumerationPreparedHistoryReceiptCanonical.lean
5. SourcePruningEnumerationPreparedResourceHistoryCanonical.lean

The public history result is ResourceHistory.canonical_output in the prepared recursive namespace.
It requires only initial Canonical and the actual ResourceHistory.
The history retains all original full memo states and actual native callers.
The prepared ordinary parent is never equated with its stored source handle.
Its availability and closure proofs come from the actual prepared admission.
The opaque arm uses the actual child singleton and finalizer.
The callback frame preserves the actual stored values.
The parked restart frame is identified from its actual singleton row.

The only expected tactic risk is the binder order of the split on the opaque dispatcher match.
The split should introduce produced, returned, childCaller, childQueries, outer, waiting, middle, childRun.
Root owns all compilation and final repository edits.
The ordinary-gates agent owns prepared parked marker exclusion and semantic gates.
The opaque-meaning agent owns local opaque backward meaning and top opaque exclusion.
Root owns the whole semantic induction.

Parked semantics must preserve its exact limitation:
PrefixMeaning gives original Satisfies iff parked Satisfies and all removed bucket restrictions.
It does not derive those restrictions from ancestry alone.
The existing checked route instead excludes parked histories at a fully Discharged output.
No semantic endpoint oracle or future cache invariant is added by these candidates.
