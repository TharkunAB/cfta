# Canonical preservation candidates, version 1

Baseline: 4a7e3e5a8e8fd881466c85e3f659cf5e4c6e8d6e.
These files are uncompiled drafts. Root owns compilation and repository changes.
The baseline directory preserves the whole source files used for these drafts.
Each candidate file adds a new module. Existing modules remain unchanged.
The captured helper uses separate native availability and closure for the prepared parent.
It does not identify that parent with the original source handle.
The opaque helper uses only the actual child row and captured finalizer.
