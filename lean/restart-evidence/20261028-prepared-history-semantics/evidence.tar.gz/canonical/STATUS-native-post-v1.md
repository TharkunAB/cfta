# Actual prepared native Posts and backward arity

Measured draft report: 2026-10-28 15:40 CET.
Root owns all compilation, repository mutation, Git, and native execution.
These candidate modules are uncompiled drafts.
Whole source files and exact identities are in native-post-baseline-v1.
Literal source cuts are in native-post-literal-cuts-v1.

The candidate modules are in native-post-candidate-v1, in this import order:
1. SourcePruningEnumerationPreparedHistoryReceiptPost.lean
2. SourcePruningEnumerationPreparedHistoryPost.lean
3. SourcePruningEnumerationPreparedHistoryBackwardArity.lean

SelectedHistoryReceipt.native_post composes the original preparation Post
with the actual ordinary head scan and completed receipt, or the actual opaque Post.
It returns the exact supplied returnedInventory, reached caller, and returnedMemos.
ResourceHistory.native_post preserves the actual output caller and full endpoint memo state.
It returns an actual final Inventory and Memos with final.query equal to output.queries.
Every native Post comes from the same actual operation history.
No memo state is reconstructed from its query field.

ArityOrigins.Heap.of_grows restricts a reached arity certificate to earlier complete edge records.
The proof uses only the actual growth.edgeRecords extension.
Heap.of_keeps and Post.arity_before apply that result to actual native effects.
The SelectedHistoryReceipt.arity_before and ResourceHistory.arity_before wrappers
therefore use the same exact output's physical arity certificate.
These helpers do not construct a future endpoint certificate.
Root must obtain that certificate from an actual native arity producer.
They add no semantic model or replacement history contract.
