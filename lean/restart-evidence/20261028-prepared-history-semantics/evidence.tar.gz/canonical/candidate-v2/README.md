# Canonical opaque repair, version 2

This is an uncompiled immutable draft.
The opaque child-match argument is proved before any native-value case split.
Its type contains only the actual child dispatcher match.
The outer native-value split uses constructor reduction and actual ordinary_deferred.
It does not match a separately elaborated Boolean gate expression.
The root failed source and full raw logs are preserved in opaque-repair-baseline-v2.
