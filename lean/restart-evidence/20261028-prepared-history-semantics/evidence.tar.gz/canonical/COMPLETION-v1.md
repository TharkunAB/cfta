# Canonical area completion

Observed at: 2026-10-28T15:51:41+01:00.

The bounded canonical, selected arity, native Post, and backward arity work is complete.
There are no unfinished additional drafts in this area.
All 11 candidate targets were integrated. Eight match the last owned draft byte for byte.
Three were integrated with Root's repairs. Root also added the finite canonical producer wrapper.

Root reports that all 19 installed modules passed exact-source strict checking.
The check used warningAsError and linter.all. Each raw log was empty.
This area did not run a compiler or independently repeat those checks.
The snapshots below record the installed sources observed after that report.
Each source had the same hash on an immediate read after the snapshot.

| Installed module | Integration |
|---|---|
| `SourcePruningEnumerationPreparedCapturedCanonical.lean` | integrated byte-identically |
| `SourcePruningEnumerationPreparedHeadReceiptCanonical.lean` | integrated byte-identically |
| `SourcePruningEnumerationSelectedOpaqueCanonical.lean` | integrated with root repairs |
| `SourcePruningEnumerationPreparedHistoryReceiptCanonical.lean` | integrated with root repairs |
| `SourcePruningEnumerationPreparedResourceHistoryCanonical.lean` | integrated byte-identically |
| `SourcePruningEnumerationSelectedValueArity.lean` | integrated byte-identically |
| `SourcePruningEnumerationSelectedPreparationArity.lean` | integrated byte-identically |
| `SourcePruningEnumerationPreparedArityHeapHead.lean` | integrated byte-identically |
| `SourcePruningEnumerationPreparedHistoryReceiptPost.lean` | integrated with root repairs |
| `SourcePruningEnumerationPreparedHistoryPost.lean` | integrated byte-identically |
| `SourcePruningEnumerationPreparedHistoryBackwardArity.lean` | integrated byte-identically |
| `SourcePruningEnumerationPreparedFiniteHistoryCanonical.lean` | root-added finite canonical producer wrapper; no owned draft |

## Integrated repairs

- SelectedOpaqueCanonical: Root added EnumerationSemantics. Root replaced the fragile gate and nested match split with an actual child-row finalizer helper. The proof cases on the native value and terminal Boolean before it splits the child result. The complete constructor is qualified. The proof still uses the actual child observation and actual captured finalizer.
- PreparedHistoryReceiptCanonical: Root added EnumerationSemantics for ValidSuspended. Root renamed the reserved opaque branch binder to otherBranch.
- PreparedHistoryReceiptPost: Root renamed the reserved opaque branch binder to otherBranch.
- PreparedFiniteHistoryCanonical: Root added the public wrapper. It retains the original finite bound, outcome, resources, and actual histories. It appends Canonical for each actual output.

The installed source copies and their hashes are in completion-observation-v1.
The draft-to-installed-diffs directory records each repair against the last owned candidate.
readiness.json records all source paths, exact SHA-256 values, draft identities, and immediate reread results.
OWNED-INVENTORY-BEFORE-COMPLETION-SHA256SUMS identifies the prior owned artifacts.
Earlier candidate files, failed attempt snapshots, and failed raw logs remain preserved.
Those earlier candidate versions are historical drafts. They are not separate pending changes.

## Scope and readiness

The canonical result uses the actual original Packet and initial Canonical.
It handles preparation, ordinary and opaque completion, parked restarts, and actual callbacks.
The prepared ordinary parent uses separate availability and closure proofs.
The proof does not identify that parent with its stored source handle.
The arity helpers retain every actual selected-value endpoint.
The native Post results retain exact callers and full memo states.
Backward arity follows the actual complete edge-record extension.
It does not construct a reached arity certificate.

Whole-source baselines and exact source cuts remain in this area.
Use literal-cuts-v2 and arity-literal-cuts-v2 for corrected end-of-file line bounds.
Use native-post-literal-cuts-v1 for the native Post source cuts.
SOURCE-CUTS-CORRECTION-v2.md records the earlier range correction.

This completion note does not freeze Root or any other owner.
The repository remains under Root's sole write and compiler control.
No repository file, Git state, network state, board state, or native process was changed by this area.
Root will seal this subtree before the final archive.
