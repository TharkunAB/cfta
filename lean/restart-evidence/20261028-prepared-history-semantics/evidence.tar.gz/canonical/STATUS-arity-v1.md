# Prepared selected arity candidates

Measured draft report: 2026-10-28 15:30 CET.
Root owns compilation and all repository changes.
All candidate Lean files remain uncompiled drafts.
No compiler, build, native run, Git, or network operation was run here.

The whole source files used by these drafts are in arity-baseline-v1.
The source manifest gives their SHA-256 identities.
Exact literal source cuts and their identities are in arity-literal-cuts-v1.
The three candidate modules are in arity-candidate-v1.

SourcePruningEnumerationSelectedValueArity adds SelectedValue.run_heap.
It requires original physical Facts, original ArityOrigins.Heap, and actual input Available.
It proves arity for the exact result state at every done or failed endpoint.
It does not require a successful future exposure or closed input.
Mu follows the actual stored unfold outcome.
Union follows the actual bounded row exposure and node reconstruction.

SourcePruningEnumerationSelectedPreparationArity adds SelectedPreparation.run_heap.
It consumes the original Packet, original stored source slot, decoded source lookup,
and the actual singleton entry plus native outcome equation.
Every supplied observation already occurs in SelectedHistoryReceipt.
The original Packet supplies native source availability through PendingRealized.
This result does not require native outcome stability or a future bound.
Its complete_heap wrapper consumes the actual stable preparation family.
The wrapper derives its source lookup from the checked identify_complete theorem.

SourcePruningEnumerationPreparedArityHeapHead adds ArityOrigins.Heap.parent_edge.
It checks any available ordinary parent's selected resident edge in its actual origin heap.
Its prepared CompletedHeadReceipt.freshArity_of_origin_heap uses admission.parentAvailable.
It does not identify the prepared parent with the original stored source handle.
The generic parent_edge result can instead run at the actual preparation heap.
That application avoids a later sibling head heap premise.
Root owns the whole-history arity decoration and semantic induction.
