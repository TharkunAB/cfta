# Opaque semantic restoration report

Date: 2026-10-28 15:47 CET.
Owner: opaque task. The root owns repository writes and validation.

## Current candidates

- `candidate-v2/MicroCFTA/SourcePruningEnumerationPreparedOpaqueLanguage.lean`:
  two public theorems. Original Packet and resource admission derive exact
  backward restrictions for an actual stable diagonal opaque completion.
  The first theorem keeps the branch's actual effective bucket. The second
  restores original Satisfies for ordinary, terminal, or empty buckets.
  It keeps the original decoded source value separate from the prepared
  value. The preparation's actual meaning theorem must supply their
  equivalence. Final Satisfies is an implication antecedent.
- `candidate-v2/MicroCFTA/SourcePruningEnumerationPreparedOpaqueIsolation.lean`:
  two public theorems. A nonterminal successful point observation of a closed
  value must be a Mu/Union boundary. Its exact completed cache contains the
  fresh isolated boundary. It retains the actual unchanged caller and query,
  the exact returned hole, and native readback at the reached caller.
  No ProperState, stable family or new reservation is an input.
- `additive-wrapper-v1/MicroCFTA/SourcePruningEnumerationPreparedOpaqueStableOutputHistory.lean`:
  one new certificate definition, its exact old-history forget theorem, and
  a producer wrapper. The wrapper calls the old opaque finite producer once
  and retains every returned old field. Its added output observer supplies
  original Fits, Reserved, known alphabet, and exact larger-work stability.
- `point-stability-v1/MicroCFTA/SourcePruningEnumerationNativeIndexStability.lean`:
  count, write and finalizer successful-point stability candidates.
- `point-stability-v1/MicroCFTA/SourcePruningEnumerationEnabledEmptyStability.lean`:
  enabled-check successful-point stability candidate.

`ADDITIVE-ROUTE.md` states the remaining type and proof route. The existing
old receipt does not yet expose the local resource/stability bundle required
by the backward resource helper. Do not claim that its current premises
already discharge that interface.

## Validation boundary

This task ran no Lean compiler, build, native test, Git, network or board
operation. All candidates are source-only until the root validates them.
The root compiled v1 and reported failures in gate rewriting, match
elaboration and unused instance scope. v2 repairs those diagnostics by
explicit native cases, generalizing := false on local bucket matches and
moving the private finalizer helper before the instances. No v2 PASS was
reported to this task when this report was written.

The three-file patch in `certificate-enrichment-v1` is a proposal only.
The root requires all 4432 old non-Audit Lean source files and the complete
old public readback to remain unchanged. The additive candidates do not
modify those files.

## Scope and Haskell comparison

The exact child language theorem retains the full bucket for terminal
inputs and ordinary children. Nonterminal Mu/Union allocation stores an
empty bucket. The finalizer stores the selected fragment equation and
removes the old selected payload. Thus the local exact theorem must retain
this branch distinction. A final structurally discharged output can exclude
an isolated opaque boundary through the actual false callback and tail
history. ordinary_gates owns that history transport.

The Haskell source agrees with the local allocation model at
`cfta/src/Data/CFTA/Enumeration.hs`, lines 715-751 and 777-801. With no
terminal input, enumerateNode allocates Mu and InternedUnion without a
bucket write. prepareShallowChild writes the full bucket only for ordinary
Node inputs. The rendering code at lines 1010-1080 emits recursive markers.
These source observations do not constitute a Haskell defect or an
end-to-end correspondence proof. No Haskell change or new defect claim is
made by this task.

## Evidence

`source-index.json` retains complete source identities and exact inclusive
literal cuts. Each whole source and each cut has a byte count and SHA256.
Read scope is explicit. A whole retained source identity does not claim that
every source line was read. The candidate-v1 and candidate-v2 payloads are
immutable. Root compiler outputs belong to the root evidence tree.
