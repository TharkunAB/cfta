# Additive opaque history route

Date: 2026-10-28 15:47 CET.
Status: source review. The root owns all compiler validation.

The old files must remain unchanged. The three-file patch in
`certificate-enrichment-v1` is a proposal. Do not apply it under the current
checkpoint rule.

## Existing evidence

`SelectedHistoryReceipt` retains one stable preparation. Its opaque arm
retains one opaque observation at `workFuel`. It also retains the actual
Post, both captured and completed Packets, Admitted, Pending, and
FragmentHistory. It does not retain a stable opaque receipt family or the
opaque producer's original Fits, reservation, and known alphabet.

The old opaque finite producer exports its stable receipt family. It also
exports every resource field and the exact callback histories. The new
`OpaqueOutputStableHistoryAt` wrapper appends a resource observer to this
old result. It keeps all old fields. Its forget theorem returns the same old
opaque output history. It does not change the old recursive contract.

An old point Invocation does not by itself supply these extra facts through
an existing theorem. The native workers do have successful-run stability.
The missing parts are the enumeration-level lifts and local resource
admission extraction. Do not assume those lifts or add them as original
admission premises.

## Minimum type route

Use a new namespace, for example
`SourcePruningEnumerationPreparedSemanticHistory`.

1. Define `OpaqueEvidenceAt` for one selected opaque call. It contains an
   original seed, Fits, Reserved for `scs.length + 1`, known guard alphabet,
   and the exact completed receipt at every larger work bound. Its cache,
   caller, returned query and fragment are the actual point observation's
   fields. It contains no model or language-equivalence premise.
2. Define an inductive `Decoration` over an EXISTING old ResourceHistory.
   The stopped and done constructors add no evidence. The parked constructor
   decorates the exact old tail. The selected constructor retains the exact
   old SelectedHistoryReceipt, its actual false recording and the exact old
   tail. The selected constructor adds `OpaqueEvidenceAt` only for the
   actual opaque arm. An ordinary arm retains its old CompletedHeadReceipt.
3. Define `ResourceHistory` in the new namespace as an old ResourceHistory
   with its Decoration. The forget theorem returns the exact old history,
   with all indices unchanged. Do not replace old source/prepared identities.
4. Define `CompleteWithHistory` in the new namespace by the SAME original
   public inputs and output packet as the old contract. Replace only its
   output history predicate by the decorated history. Its forget theorem
   keeps the chosen bound, outcome, running family and OutcomeResources.

## Preferred proof route: decorate old histories at the same work fuel

First prove successful-point stability for the actual opaque worker.
The existing primitive theorems are:

- SourceEqualityNativeDemand.done_stable.
- SourceCurrentAllocatedConjunctionWorkerActual.call_done_stable.
- UnionFind.findRoot_moreFuel.
- SourceUnionFindRoot.root_moreFuel.

The new point-stability candidates in `point-stability-v1` lift the last
primitive through waiting counts, indexed writes and the actual finalizer.
They also lift completed fourth-memo calls through EnabledEmpty.check.
They have not been compiled by this worker.

The remaining lifts are:

1. A successful Dispatch.dispatch observation remains equal when native,
   p and h bounds increase. Split its actual native and enabled-check arms.
2. A successful Fold and CachedFold singleton remains equal. Use induction
   over the actual source list and the preceding dispatcher result.
3. A successful IncomingNode singleton remains equal. Keep its actual
   representative result, native return and enabled check. Lift its cache
   adapter through the new indexed-write stability theorem.
4. A successful TerminalPrefix observation remains equal when representative
   fuel increases. Existing TerminalPrefixUnique has the needed proof as a
   private run_moreFuel lemma. Use the same proof in a new additive module.
5. Combine these facts through CachedTerminalAdapter, ChildDispatch and the
   actual SelectedOpaqueDispatch finalizer. The result must retain the
   entire returned cache and caller, not only the output fragment.

Then derive local opaque resource admission in the selected constructor of
an old ResourceHistory. Start from that constructor's HistoryAdmission.
Use PrefixAdmission.narrowed_admission with its actual PrefixValid and point
prefix observation to recover narrowed Fits and the known alphabet. The
existing full memo state in the old constructor stays separate from these
scalar and heap facts. Use the actual SelectedHistoryReceipt preparation to
identify the prepared value and entered cache. SelectedValueResources has
an any-fuel fits_after theorem; check that interface before replaying a
second preparation producer. Otherwise compare against the ALREADY STABLE
preparation family at common bounds. Use the original PreparedReservation
step and first reservation to pay `scs.length + 1`.

This permits a structural induction that decorates every old history at its
SAME workFuel. The public strengthened finite theorem can then call the old
finite_complete_with_history once and decorate each exact emitted history.
This route preserves the old all-depth producer and avoids a parallel
operational induction.

## Alternative proof route

Use the additive opaque stable-output wrapper in a parallel decorated
callback producer. Thread decorated callback histories through the selected
and sibling producers, then prove the new contract by all-depth induction.
The old contract is the forget projection at each stage. This route needs
new callback, receipt, opaque, ordinary scan, selected expansion, parked,
positive-step, all-depth and run wrappers. Do not pass a forgotten decorated
IH to old producers and assume that they return its decoration. Their
public results discard that information.

The parallel route is a valid fallback. The opaque wrapper alone does not
establish its all-depth result.
