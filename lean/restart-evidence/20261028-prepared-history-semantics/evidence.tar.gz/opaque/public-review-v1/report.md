# Independent public review: terminal, isolation and retention

[2026-10-28 16:14:38 CET] PASS within the stated scope. I found no mismatch between the 16 assigned public declarations and their current source proofs. I found no additional admission gate hidden behind their public signatures.

I read all 16 assigned public blocks in full: 47,824 bytes. I also read all 11 assigned source modules in full. The block copies retain their original byte counts and SHA-256 hashes. All 16 block copies and all 16 preserved source files still match their originals at the final identity check. The five additional source copies support the admission, pending-slot, recording and discharge checks. Their exact read scopes are in `source-identities.json`.

## Required checks

The terminal path uses the actual terminal prefix, fold, dispatch and incoming observations. It does not require `ProperState`. The fold parameter named `proper` has type `IsolatedPending`. The fold theorem first concerns its outer core. The terminal theorem then identifies the successful row with that core. The pure incoming-write helper requires its explicit write shape; the actual incoming proof derives that shape from its real successful row.

The marker survives the exact false `recordTypes` callback and the exact `ResourceHistory` tail. The native readback remains at the same handle and reaches the actual output caller. The selected receipt carries full native `Post` and returned memos. The history proof uses those effects and the real tail indices. It does not replace them with a query-only observation or a different successful tail.

Final `Discharged` derives the ordinary retained-child disjunction. The proof first attaches the actual nonterminal opaque marker to the head, callback and output. That marker contradicts `Discharged`. Retention is the conclusion. It is not an added original-admission premise.

The stored source handle and the prepared ordinary parent remain separate. The completed-head proofs use `admission.stored` for the original pending slot and `parentAvailable`, `parentClosed` and the selected edge for the prepared parent. They do not cast the original native readback to that parent.

All assigned axiom lists contain only the listed standard axioms: `propext`, `Classical.choice` and `Quot.sound`. Two elementary helpers use only `propext`. No assigned block lists `sorryAx` or a new custom axiom. This is a source and public-output review. I did not run a compiler.

## Per-block results

`review.json` records each exact declaration, named conclusion, actual premises, scope gates, current source identity, literal signature cut, axiom list and proof comparison.

| Index | Declaration | Result |
| --- | --- | --- |
| 17 | `SourcePruningEnumerationTerminalPrefix.run_isolated` | PASS |
| 18 | `SourcePruningEnumerationDispatch.dispatch_isolated` | PASS |
| 19 | `SourcePruningEnumerationFold.run_isolated` | PASS |
| 20 | `SourcePruningEnumerationIncomingNode.written_isolated` | PASS |
| 21 | `SourcePruningEnumerationIncomingNode.run_isolated` | PASS |
| 22 | `SourcePruningEnumerationTerminal.successful_isolated` | PASS |
| 23 | `SourcePruningEnumerationPreparedNativeHookResources.CompletedHeadReceipt.isolated` | PASS |
| 24 | `SourcePruningEnumerationPreparedOpaqueEvent.opaque_prepare_fuel` | PASS |
| 25 | `SourcePruningEnumerationPreparedOpaqueEvent.completed_head_opaque_isolated` | PASS |
| 34 | `SourcePruningEnumerationChildDispatch.successful_isolated` | PASS |
| 35 | `SourcePruningEnumerationSelectedOpaqueDispatch.completed_isolated` | PASS |
| 36 | `SourcePruningEnumerationPreparedRecursive.SelectedHistoryReceipt.isolated_post` | PASS |
| 37 | `SourcePruningEnumerationPreparedRecursive.ResourceHistory.isolated_boundary` | PASS |
| 38 | `SourcePruningEnumerationPreparedRecursive.ResourceHistory.not_discharged` | PASS |
| 39 | `SourcePruningEnumerationPreparedOpaqueEvent.completed_head_opaque_output_not_discharged` | PASS |
| 40 | `SourcePruningEnumerationPreparedOpaqueEvent.completed_head_output_retained` | PASS |

## Scope limits

These declarations establish structural isolation and retention. They do not by themselves prove backward `Satisfies` restoration, whole-driver language equality, coverage or termination.

`Discharged` is an explicit condition on the selected final cache. This chain does not prove that every emitted cache is discharged. Recursive-marker rendering remains outside that conclusion. The retained-child conclusion permits an ordinary node, a terminal bucket or an empty bucket. It is not a standalone semantic equivalence theorem.

The completed ordinary head receipt includes its original resource gates and stable completion family. The opaque receipt isolation theorem instead consumes its actual point observation. The review does not promote that point observation into a uniform semantic or resource family.

The parent reported strict success for the 30 modules and Audit, plus the complete public readback. I did not rerun those checks. I wrote no repository file, changed no assigned block and ran no native check. This review establishes no Haskell defect and makes no Haskell fix.

No blocking finding was identified in the assigned scope.
