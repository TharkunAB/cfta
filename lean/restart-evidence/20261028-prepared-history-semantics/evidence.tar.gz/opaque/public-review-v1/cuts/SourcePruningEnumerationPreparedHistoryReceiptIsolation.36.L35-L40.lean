theorem SelectedHistoryReceipt.isolated_post
    (receipt : SelectedHistoryReceipt formulas solver metadata checkEmpty workFuel uv
      inventory caller memos before fragment reached after returnedInventory returnedMemos)
    (isolated : IsolatedPending held heldHandle before.core) (different : held ≠ uv) :
    IsolatedPending held heldHandle after.core ∧
      Post formulas solver returnedInventory caller reached returnedMemos := by
