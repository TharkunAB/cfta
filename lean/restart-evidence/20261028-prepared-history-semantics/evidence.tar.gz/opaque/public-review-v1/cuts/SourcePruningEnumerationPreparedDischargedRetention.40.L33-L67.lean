theorem completed_head_output_retained
    (seed : Seed) (inherited : Nat)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos) (metadata : Metadata Typing)
    (before : Cached) (checkEmpty : Bool) (uv handle : Nat) (scs : List Suspended)
    (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
    (edges : List (EdgeValue Symbol Constraint)) (depth : Nat)
    (free : List InternedBinderProtocol.Reference) (edge : EdgeValue Symbol Constraint) (bound : Nat) (fragment : Fragment)
    (reached : Caller (bits + 2)) (saved : Queries) (headCache : Cached)
    (returnedInventory : Inventory) (returnedMemos : Memos)
    (head : CompletedHeadReceipt seed inherited formulas solver inventory caller memos metadata before
      checkEmpty uv handle scs parentEntry edges depth free edge bound fragment reached saved headCache returnedInventory returnedMemos)
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool)) (order : Metadata Typing → List Nat → Option Nat)
    (workFuel recursiveFuel : Nat) (recorded : Metadata Typing) (callbackCore : Core)
    (tailSeed : Seed) (tailCeiling : Nat)
    (output : SourcePruningEnumerationRecursive.Output (bits + 2) Typing)
    (callback : ExceptT.run (SourcePruningRecordTypes.recordTypes graph templates workFuel metadata uv
      (.inl fragment) headCache.core) = [.ok ((false, recorded), callbackCore)])
    (tail : SourcePruningEnumerationPreparedRecursive.ResourceHistory
      holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver workFuel
      recursiveFuel returnedInventory reached returnedMemos recorded
      (EnumerationExpandableIndex.frame callbackCore headCache) tailSeed tailCeiling
      (SourcePruningEnumerationRestart.decision stop order recorded
        (EnumerationExpandableIndex.frame callbackCore headCache)) output)
    (discharged : SourcePruningEnumerationRendering.Discharged output.cache.core) :
    ∀ tries residual,
      SourcePruningEnumerationConstraint.project edge.entry.key.constraint = some (tries, residual) →
      ∀ incoming bucket,
        (incoming, bucket) ∈ SourcePruningEnumerationEdgeInputs.children edge scs before.core.counter tries →
        (match incoming with | .node _ _ _ _ => True | _ => False) ∨
          bucket.any (fun sc => EqualityTrie.isTerminal sc.trie) = true ∨ bucket = [] := by
