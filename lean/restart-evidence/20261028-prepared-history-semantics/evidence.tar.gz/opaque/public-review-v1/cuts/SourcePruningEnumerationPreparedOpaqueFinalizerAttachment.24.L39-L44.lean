theorem opaque_prepare_fuel
    (heap : InternedConstructorTemplates.State Symbol Constraint) (firstFuel nextFuel : Nat)
    (bucket : List Suspended) (value : Node) (before : Cached)
    (boundary : MergedOrdinaryHeight.recursiveBoundary value = true) :
    SourcePruningEnumerationCachedPrepare.prepareChild heap firstFuel bucket value before =
      SourcePruningEnumerationCachedPrepare.prepareChild heap nextFuel bucket value before := by
