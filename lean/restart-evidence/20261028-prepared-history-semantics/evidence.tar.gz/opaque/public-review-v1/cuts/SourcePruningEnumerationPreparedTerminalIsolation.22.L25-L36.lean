theorem successful_isolated
    (checkEmpty : Bool) (r n p h : Nat) (first : Suspended) (rest : List Suspended)
    (waiting : EnumerationWaitingIndex.Waiting) (caller : Caller width) (before : Core)
    (incoming : Node) (incomingScs : List Suspended) (queries : Queries)
    (fragment : Fragment) (afterCaller : Caller width) (savedQueries : Queries)
    (outer after : Core) (moved : EnumerationWaitingIndex.Waiting)
    (held heldHandle : Nat) (total : UnionFind.Total before.representatives)
    (isolated : IsolatedPending held heldHandle before)
    (active : Avoids before.representatives held (first :: rest))
    (inputs : Avoids before.representatives held incomingScs)
    (observed : run checkEmpty r n p h first rest waiting caller before incoming incomingScs queries =
      (.ok (some [.ok (fragment, after)]), afterCaller, savedQueries, outer, moved)) : IsolatedPending held heldHandle after := by
