theorem run_isolated
    (fuel held heldHandle : Nat) (first : Suspended) (rest : List Suspended)
    (waiting : EnumerationWaitingIndex.Waiting)
    (before after : State Symbol EnumGuard) (recorded : List Nat) (winner : Nat)
    (moved : EnumerationWaitingIndex.Waiting)
    (total : UnionFind.Total before.representatives)
    (isolated : IsolatedPending held heldHandle before)
    (avoids : Avoids before.representatives held (first :: rest))
    (success : Success (run fuel first rest waiting) before (recorded, winner, moved) after) :
    UnionFind.Total after.representatives ∧ IsolatedPending held heldHandle after ∧
      (∀ source ∈ recorded, source ≠ held) ∧
      ¬UnionFind.SameClass after.representatives held winner ∧
      (∀ uv, UnionFind.SameClass after.representatives held uv ↔
        UnionFind.SameClass before.representatives held uv) := by
