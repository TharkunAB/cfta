theorem run_isolated
    (checkEmpty : Bool) (r n p h : Nat) (caller : Caller width) (before : Core)
    (target : Nat) (incoming : Node) (incomingScs : List Suspended) (queries : Queries)
    (held heldHandle : Nat) (total : UnionFind.Total before.representatives)
    (isolated : IsolatedPending held heldHandle before)
    (separate : ¬UnionFind.SameClass before.representatives held target)
    (inputs : Avoids before.representatives held incomingScs) :
    (UnionFind.Total (run checkEmpty r n p h caller before target incoming incomingScs queries).2.2.2.representatives ∧
      IsolatedPending held heldHandle
        (run checkEmpty r n p h caller before target incoming incomingScs queries).2.2.2) ∧
      ∀ returned, (run checkEmpty r n p h caller before target incoming incomingScs queries).1 =
        .ok (some [.ok ((), returned)]) →
        UnionFind.Total returned.representatives ∧ IsolatedPending held heldHandle returned := by
