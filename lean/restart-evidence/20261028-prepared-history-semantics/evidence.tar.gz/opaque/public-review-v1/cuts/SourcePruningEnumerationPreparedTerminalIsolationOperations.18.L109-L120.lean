theorem dispatch_isolated
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
    (checkEmpty : Bool) (nativeFuel p h : Nat)
    (beforeCaller : Caller width) (before : EnumerationState.State Symbol EnumGuard)
    (source target : Nat) (queries : Queries) (action : EnumerateM Symbol EnumGuard Unit)
    (afterCaller : Caller width) (savedQueries : Queries) (after : EnumerationState.State Symbol EnumGuard)
    (held heldHandle : Nat) (isolated : IsolatedPending held heldHandle before)
    (sourceOther : source ≠ held) (targetOther : target ≠ held)
    (selected : dispatch checkEmpty nativeFuel p h beforeCaller before source target queries =
      (.ok (some action), afterCaller, savedQueries))
    (completed : ExceptT.run (action before) = [.ok ((), after)]) :
    IsolatedPending held heldHandle after ∧ after.representatives = before.representatives := by
