theorem written_isolated
    (before after : Core) (target handle held heldHandle : Nat) (oldNode : Option Nat)
    (incomingScs oldScs : List Suspended)
    (total : UnionFind.Total before.representatives)
    (isolated : IsolatedPending held heldHandle before)
    (different : target ≠ held) (inputs : Avoids before.representatives held incomingScs)
    (stored : before.values[target]? = some (.unenumerated oldNode oldScs))
    (shape : after = {before with
      values := before.values.set target (.unenumerated (some handle) (incomingScs ++ oldScs))
      recursionAncestry := fun other => if other = target then
        (before.expansionAncestry ++ before.recursionAncestry target).eraseDups
        else before.recursionAncestry other}) :
    UnionFind.Total after.representatives ∧ IsolatedPending held heldHandle after := by
