theorem completed_isolated
    (checkEmpty : Bool) (r n p h k target : Nat) (scs : List Suspended) (value : Node)
    (caller reached : Caller width) (before after : Cached) (queries saved : Queries) (fragment : Fragment)
    (held heldHandle : Nat) (safe : Safe before.core)
    (isolated : IsolatedPending held heldHandle before.core)
    (different : target ≠ held)
    (bounded : ∀ sc ∈ scs, sc.var < before.core.counter)
    (inputs : Avoids before.core.representatives held scs)
    (observed : run checkEmpty r n p h k target scs value caller before queries =
      some (.complete fragment reached saved after)) :
    IsolatedPending held heldHandle after.core := by
