from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

root = Path('/home/tritlo/Code/mcfta')
area = Path('/tmp/mcfta-prepared-history-semantics-20261028')
snapshot = root / 'lean/restart-evidence/20261028-prepared-semantic-history-reboot'
mapping = {
    'public-declarations.json':'prior-public-declarations.json',
    'public-definitions.json':'prior-public-definitions.json',
    'prior-strong-sources.json':'inherited-strong-sources.json',
    'modules.json':'inherited-modules.json',
}
for name in ['raw.log','public.lean','report.json','inputs.json']:
    mapping['public-readback-final/'+name] = 'prior-public-readback/'+name
for name in ['check-installed.py','pipeline.py','validate.py','public-validation.py','catalog.py','commit-checked.py']:
    mapping[name] = name
found = set()
with tarfile.open(snapshot/'evidence.tar.gz','r:gz') as tar:
    for member in tar:
        if member.name not in mapping:
            continue
        raw = tar.extractfile(member).read()
        target = area / mapping[member.name]
        assert not target.exists()
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.suffix == '.py':
            raw = raw.replace(b'/tmp/mcfta-prepared-semantic-history-20261028',str(area).encode())
        target.write_bytes(raw)
        found.add(member.name)
assert found == set(mapping)
tracked = subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
def record(name):
    raw = (root / name).read_bytes()
    return {'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
lean = [record(name) for name in tracked if name.startswith('lean/MicroCFTA/') and name.endswith('.lean') and not name.endswith('/Audit.lean')]
haskell = [record(name) for name in tracked if name.endswith(('.hs','.lhs','.hsc'))]
strong = json.loads((area/'inherited-strong-sources.json').read_text())
for row in strong:
    assert record(row['path'])['sha256'] == row['sha256']
for module in json.loads((area/'inherited-modules.json').read_text()):
    strong.append(dict(record('lean/MicroCFTA/'+module+'.lean'),module=module))
for name,rows in [('prior-lean-sources.json',lean),('prior-haskell-sources.json',haskell),('prior-strong-sources.json',strong)]:
    (area/name).write_text(json.dumps(rows,indent=2)+'\n')
for name in ['FINDINGS.md','HANDOFF.md','NEXT-PROMPT.md','lean/API-COVERAGE.md','lean/COVERAGE.md','lean/README.md','lean/SYSTEM.md','lean/notes-current-system-claim.md','lean/notes-proof-status-20261017.md']:
    target = area/'prior-documents'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((root/name).read_bytes())
(area/'prior-Audit.lean').write_bytes((root/'lean/MicroCFTA/Audit.lean').read_bytes())
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
(area/'published-base.txt').write_text(head+'\n')
for name,value in [('modules.json',[]),('strict-checks.json',{}),('new-public-declarations.json',[])]:
    (area/name).write_text(json.dumps(value,indent=2)+'\n')
(area/'public-definitions.json').write_bytes((area/'prior-public-definitions.json').read_bytes())
(area/'public-declarations.json').write_bytes((area/'prior-public-declarations.json').read_bytes())
state={'previous_goal_turn':'progress','evidence':'Six published commits through 4a7e3e5a8; complete verified reboot snapshot; new resource-history theorem and actual semantic bridges.','current_head':head,'upstream_pull':'Already up to date','reboot_archive_payloads':2720,'old_evidence_write_halt':True,'prior_lean':len(lean),'prior_strong':len(strong),'prior_haskell':len(haskell),'full_goal_complete':False,'current_target':'Actual prepared ResourceHistory semantic induction for discharged outputs, derive local gates and preserve opaque/parked scope.'}
(area/'bootstrap.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(state))
