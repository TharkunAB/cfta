import MicroCFTA.SourcePruningEnumerationSelectedOpaqueDispatch
import MicroCFTA.SourcePruningEnumerationChildCanonical
import MicroCFTA.SourcePruningEnumerationOwnFinalizeCanonical

/-!
# Canonical storage through actual prepared opaque dispatch

The actual successful child row supplies its exact attached cache.
The captured-target finalizer preserves canonical stored suspended tries.
-/
namespace MicroCFTA.SourcePruningEnumerationSelectedOpaqueDispatch
open EnumerationState EnumerationCorrectness EnumerationSemantics EnumerationValidity InternedConstructorTemplates
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Fragment" => Fragments.Fragment Symbol
variable {width : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Actual completed opaque or terminal dispatch preserves canonical storage. -/
theorem complete_canonical
    {checkEmpty : Bool} {r n p h k target : Nat} {scs : List Suspended} {value : Node}
    {caller reached : Caller width} {before after : Cached} {queries saved : Queries} {fragment : Fragment}
    (canonical : Canonical before.core) (inputs : ValidSuspended scs)
    (completed : run checkEmpty r n p h k target scs value caller before queries =
      some (.complete fragment reached saved after)) : Canonical after.core := by
  have childCompletion
      (observed : (match SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k
          scs value caller before queries with
        | ((.ok (some [.ok (produced, returned)]), childCaller, childQueries, outer, waiting), some middle) =>
            (SourcePruningEnumerationFinalize.run childCaller.checked.native.machine.heap k target produced middle).map
              (fun finished => .complete produced childCaller childQueries finished)
        | (observation, candidate) => some (.stopped [] observation candidate)) =
          some (.complete fragment reached saved after)) : Canonical after.core := by
    split at observed
    next produced returned childCaller childQueries outer waiting middle childRun =>
      simp only [Option.map_eq_some_iff] at observed
      obtain ⟨finished, finishRun, fields⟩ := observed
      have cacheSame : finished = after :=
        (SourcePruningEnumerationSelectedEdge.Result.complete.inj fields).2.2.2
      rw [← cacheSame]
      exact SourcePruningEnumerationFinalize.run_canonical
        childCaller.checked.native.machine.heap k target produced middle finished
        (SourcePruningEnumerationChildDispatch.successful_canonical canonical inputs childRun) finishRun
    next => cases observed
  apply childCompletion
  cases value with
  | empty =>
      simp only [run, ↓reduceIte, Option.some.injEq, reduceCtorEq] at completed
  | reference | mu | union =>
      simpa only [run, reduceCtorEq, Bool.false_eq_true, ↓reduceIte] using completed
  | node entry edges depth free =>
      by_cases terminal : scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = true
      · simpa only [run, reduceCtorEq, terminal, Bool.not_true, Bool.false_eq_true, ↓reduceIte] using completed
      · have nonterminal : scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = false :=
          Bool.eq_false_iff.mpr terminal
        rw [ordinary_deferred checkEmpty r n p h k target scs entry edges depth free
          caller before queries nonterminal] at completed
        cases completed

end MicroCFTA.SourcePruningEnumerationSelectedOpaqueDispatch
