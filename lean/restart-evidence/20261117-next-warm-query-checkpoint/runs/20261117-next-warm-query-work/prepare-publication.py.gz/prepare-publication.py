from pathlib import Path
import hashlib
import json
import re
import shlex
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
work = base / '20261117-next-warm-query-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this candidate into the active Work directory'
prior_run = base / '20261117-warm-equal-key-transport-publication'
prior_archive = base / '20261117-warm-equal-key-transport-checkpoint'
runtime = base / '20261117-next-warm-query-publication'
prior_commit = '5535b223b6f3de67706096a9eab337e160faae47'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
native_module = 'SourceSynthesisCurrentUniverseNativeAllocation'
gamma_module = 'SourceCurrentAllocatedNativePastGammaEqualEntryPayload'
native_name = 'lean/MicroCFTA/' + native_module + '.lean'
gamma_name = 'lean/MicroCFTA/' + gamma_module + '.lean'
expected_components = [
    {'module': native_module, 'source_path': native_name,
     'raw_sha256': '99dd852e3352b671b10840634608f3fad029b7c493aec3de1854a5a3d61b51c7',
     'theorems': ['cold_source_control_prefix_full_admission',
        'original_universe_node_query_prefix_full_admission',
        'original_universe_edge_query_prefix_full_admission',
        'original_universe_returned_node_full_admission',
        'original_universe_returned_edge_full_admission'],
     'old_owner_bytes': 169023,
     'old_owner_sha256': '136dfc05f774d575363d82768582b0db637f0a6c2a79f2e198baa10ef15093e3',
     'old_owner_offset': 62, 'actual_normal_check_reports': 5},
    {'module': gamma_module, 'source_path': gamma_name,
     'raw_sha256': '8af44f1cd4e8ae81fa92d202bd1d27267c42ddbac3f416e65f51827b23983c62',
     'theorems': ['closed_root_returned_or_authentic_entry_at',
        'closed_root_cold_returned_mixed_profile_after_later_entry',
        'old_returned_edge_profiles_after_equal_key_entries'],
     'old_owner_bytes': 26430,
     'old_owner_sha256': '35d8435e20a4273842887f966e52334c06ed2acfcc8966fb47ae1d9e07fca16a',
     'old_owner_offset': 0, 'actual_normal_check_reports': 3}]
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage = json.loads(stage_path.read_text())
components = stage['components']
assert len(components) == 2
assert [{key: c[key] for key in expected} for c, expected in zip(components, expected_components)] == expected_components
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6251, 5251, 676, 271)
assert (stage['new_normal_modules'], stage['new_public_theorems'], stage['new_private_theorems'], stage['new_private_predicates']) == (0, 7, 1, 0)
assert stage['new_theorem_declarations'] == 8
assert (stage['fresh_strict_reports'], stage['inherited_bound_reports'], stage['combined_component_reports']) == (8, 462, 470)
assert stage['old_reports_replaced'] == 0
assert stage['old_non_audit_non_changed_owner_sources_exact'] == 6248
assert stage['old_audit_exact_prefix'] and stage['new_audit_imports'] == 0
assert stage['all_old_proof_bodies_and_limits_unchanged'] and stage['all_selected_normal_module_checks_passed']
for name in ['generic_closed_root_returned_node_entry_proved',
             'cold_returned_node_Profile_without_supplied_old_entry_proved',
             'all_old_edge_children_requalified_jointly_proved',
             'full_prefix_source_admission_with_past_inventory_proved',
             'all_old_cold_returned_node_and_edge_full_admission_proved',
             'earlier_exact_source_variant_preserved',
             'first_failed_edge_and_exact_header_syntax_repair_preserved',
             'input_pair_qualifications_still_explicit']:
    assert stage[name], name
for name in ['every_warm_worker_call_qualification_proved', 'warm_query_no_new_mu_proved',
             'joint_finite_completion_proved', 'compiled_haskell_correspondence_proved', 'haskell_changed']:
    assert not stage[name], name
prior = json.loads((prior_run / 'checked.json').read_text())
assert len(prior['checks']) == 5 and all(c['exit'] == 0 and not c['nonstandard_axioms']
    and not c['diagnostics'] and not c['sorryAx'] for c in prior['checks'])
assert (prior['source_files'], prior['independent_reports'], prior['resource_and_component_probes']) == (6251, 264, 462)
assert prior['whole_worker_program_slots_proved'] and prior['whole_worker_roles_proved']
assert prior['owner_resource_probes'] == 264
baseline = json.loads((work / 'baseline-source-pins.json').read_text())
assert len(baseline) == 6251
assert {str(p.relative_to(root)) for p in (root / 'lean/MicroCFTA').glob('*.lean')} == set(baseline)
old_audit = (work / 'Audit-BEFORE.lean.txt').read_bytes()
assert old_audit.count(b'#print axioms ') == 669
snapshots = {audit_name: 'Audit-BEFORE.lean.txt'}
old_owners = {}
for component in components:
    module = component['module']
    assert component.get('namespace', module) == module
    assert component['theorems'] == component['private_theorem_names'] + component['public_theorem_names']
    assert len(component['public_theorem_names']) == component['new_public_theorems']
    assert len(component['private_theorem_names']) == component['new_private_theorems']
    assert len(component['theorems']) == component['total_strict_reports'] == component['actual_normal_check_reports']
    assert component['old_owner_contiguous_exact']
    snapshot = module + '-BEFORE.lean.txt'
    snapshots[component['source_path']] = snapshot
    old = (work / snapshot).read_bytes()
    old_owners[module] = old
    assert len(old) == component['old_owner_bytes'] and sha(old) == component['old_owner_sha256']
    normal = (root / component['source_path']).read_bytes()
    assert sha(normal) == component['raw_sha256']
    offset = component['old_owner_offset']
    assert normal[offset:offset + len(old)] == old
    assert component['old_owner_exact_prefix'] == (offset == 0)
for name, digest in baseline.items():
    data = (work / snapshots[name]).read_bytes() if name in snapshots else (root / name).read_bytes()
    assert sha(data) == digest, name
assert len(set(baseline) - set(snapshots)) == 6248
assert sha((root / owner_name).read_bytes()) == owner_sha
selected_packet = base / '20261117-source-prefix-full-call-admission-past-inventory-draft'
returned_packet = base / '20261117-returned-cells-full-source-admission-draft'
node_packet = base / '20261117-closed-root-returned-node-entry-draft'
edge_packet = base / '20261117-old-returned-edge-record-syntax-repair'
assembly_packet = base / '20261117-next-warm-node-edge-assembly'
import_prefix = (returned_packet / 'IMPORTS.lean.txt').read_bytes()
assert import_prefix == b'import MicroCFTA.SourceCurrentAllocatedNativeNodeReturnOrigin\n' and len(import_prefix) == 62
assert (root / native_name).read_bytes() == import_prefix + old_owners[native_module] + (selected_packet / 'APPEND.lean.txt').read_bytes() + b'\n' + (returned_packet / 'APPEND.lean.txt').read_bytes()
assert (root / gamma_name).read_bytes() == (assembly_packet / (gamma_module + '.lean')).read_bytes()
assert (root / gamma_name).read_bytes() == old_owners[gamma_module] + b'\n' + (node_packet / 'APPEND.lean.txt').read_bytes() + b'\n' + (edge_packet / 'APPEND.lean.txt').read_bytes()
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
qnames = ['MicroCFTA.' + c.get('namespace', c['module']) + '.' + name
          for c in components for name in c['public_theorem_names']]
assert len(qnames) == 7
assert public == ''.join('#check ' + q + '\n#print axioms ' + q + '\n' for q in qnames).encode()
audit = (root / audit_name).read_bytes()
assert audit == old_audit + b'\n' + public
assert sum(line.startswith(b'import ') for line in audit.splitlines()) == 5251
assert audit.count(b'#print axioms ') == 676
header_specs = [
    (native_name, selected_packet / 'PRIVATE-CONTROL-HEADER.lean.txt'),
    (native_name, selected_packet / 'NODE-PUBLIC-HEADER.lean.txt'),
    (native_name, selected_packet / 'EDGE-PUBLIC-HEADER.lean.txt'),
    (native_name, returned_packet / 'NODE-FIRST-HEADER.lean.txt'),
    (native_name, returned_packet / 'EDGE-FIRST-HEADER.lean.txt'),
    (gamma_name, node_packet / 'GENERIC-FIRST-HEADER.lean.txt'),
    (gamma_name, node_packet / 'COLD-FIRST-HEADER.lean.txt'),
    (gamma_name, edge_packet / 'FIRST-HEADER.lean.txt')]
for name, header_path in header_specs:
    header = header_path.read_text()
    declaration = header[:header.index('\n')]
    text = (root / name).read_text()
    start = text.index(declaration)
    assert text[start:text.index(' := by', start)].rstrip() == header.rstrip(), header_path
checked_inputs = []
for component in components:
    receipt_path = work / component['verified_receipt']
    receipt = json.loads(receipt_path.read_text())
    normal_check = base / component['actual_normal_check']
    checked = json.loads((normal_check / 'checked.json').read_text())
    assert receipt['actual_terminal_exit'] == 0 and receipt['run'] == component['actual_normal_check']
    assert checked['normal_module_checked'] and all(checked['passed']) and checked['source_pins_unchanged']
    assert receipt['checks'] == checked['checks']
    assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx'] for c in checked['checks'])
    assert checked['checks'][1]['total_axiom_reports'] == component['actual_normal_check_reports']
    checked_source = normal_check / 'source/MicroCFTA' / (component['module'] + '.lean')
    assert checked_source.read_bytes().startswith((root / component['source_path']).read_bytes())
    selection = json.loads((normal_check / 'selection.json').read_text())
    assert selection['sha256'] == component['raw_sha256']
    checked_inputs += [receipt_path, checked_source]
    checked_inputs += [normal_check / name for name in ['checked.json', 'selection.json', 'normal-module.txt', 'source-pins.json']]

# Validation above is read-only. Only Root may create the publication run.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-next-warm-query-publication-'))
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
(runtime / 'PUBLIC-PROBES.lean.txt').write_bytes(public)
commands = []
strict_sources = []
fresh_count = 0
for component in components:
    normal = root / component['source_path']
    namespace = component.get('namespace', component['module'])
    probes = ''.join('#check @MicroCFTA.' + namespace + '.' + name + '\n#print axioms MicroCFTA.'
                     + namespace + '.' + name + '\n' for name in component['theorems'])
    fresh_count += len(component['theorems'])
    source = runtime / 'source/MicroCFTA' / normal.name
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_bytes(normal.read_bytes() + b'\n' + probes.encode())
    (runtime / (component['module'] + '-PROBES.lean.txt')).write_text(probes)
    strict_sources.append(source)
    commands.append(['lake', 'env', 'lean', '-j1', '-DwarningAsError=true', '-R',
        str(source.parent.parent), '-o', str(objects / (component['module'] + '.olean')), str(source)])
assert fresh_count == 8
independent = runtime / 'IndependentProbes.lean'
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 264
assert b'import MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation\n' in prior_independent
assert b'import MicroCFTA.SourceCurrentAllocatedNativePastGammaEqualEntryPayload\n' in prior_independent
independent.write_bytes(prior_independent + b'\n' + public)
assert independent.read_bytes().count(b'#print axioms ') == 271
selection = {'prior_checkpoint': prior_commit,
    'prior_archive_manifest_sha256': sha((prior_archive / 'manifest.json').read_bytes()),
    'prior_checked_sha256': sha((prior_run / 'checked.json').read_bytes()),
    'prior_pins_sha256': sha((prior_run / 'source-pins.json').read_bytes()),
    'baseline_sha256': sha((work / 'baseline-source-pins.json').read_bytes()),
    'stage_sha256': sha(stage_path.read_bytes()),
    'snapshots': snapshots,
    'snapshot_sha256': {name: sha((work / file).read_bytes()) for name, file in snapshots.items()},
    'unchanged_resource_owner_sha256': owner_sha,
    'prior_source_files': 6251, 'prior_combined_reports': 462,
    'replaced_old_reports': 0, 'inherited_reports': 462, 'fresh_reports': 8, 'combined_reports': 470,
    'new_theorem_declarations': 8, 'new_public_theorems': 7, 'new_private_theorems': 1,
    'old_normal_sources_byte_exact_except_audit_and_two_owners': 6248,
    'old_native_bytes': 169023, 'old_native_exact_offset': 62,
    'old_gamma_bytes': 26430, 'old_gamma_exact_offset': 0,
    'old_audit_bytes_retained_as_prefix_without_new_import': True,
    'owner_preflight_reports_fresh_this_batch': 0, 'owner_reports_inherited': 264,
    'old_toolchain_and_proof_inputs_reverified': True, 'axiom_strings_replayed': False}
(runtime / 'INHERITANCE-SELECTION.json').write_text(json.dumps(selection, indent=2) + '\n')
STRICT_BINDING_TEMPLATE = '''from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/home/tritlo/Code/mcfta')
runtime = Path(__file__).parent
prior = root / 'lean/restart-evidence/20261117-warm-equal-key-transport-publication'
archive = root / 'lean/restart-evidence/20261117-warm-equal-key-transport-checkpoint'
work = root / 'lean/restart-evidence/20261117-next-warm-query-work'
sha = lambda data: hashlib.sha256(data).hexdigest()
selection = json.loads((runtime / 'INHERITANCE-SELECTION.json').read_text())
assert sha((archive / 'manifest.json').read_bytes()) == selection['prior_archive_manifest_sha256']
committed = subprocess.check_output(['git', 'show', selection['prior_checkpoint'] + ':'
    + str((archive / 'manifest.json').relative_to(root))], cwd=root)
assert committed == (archive / 'manifest.json').read_bytes()
subprocess.run(['python3', str(archive / 'verify.py')], check=True)
records = json.loads((archive / 'archived-inputs.json').read_text())
for name in ['checked.json', 'source-pins.json']:
    path = prior / name
    record = next(item for item in records if item['original'] == str(path))
    archived = (archive / record['archived']).read_bytes()
    if record['gzip']:
        archived = gzip.decompress(archived)
    assert archived == path.read_bytes()
assert sha((prior / 'checked.json').read_bytes()) == selection['prior_checked_sha256']
assert sha((prior / 'source-pins.json').read_bytes()) == selection['prior_pins_sha256']
assert sha((work / 'baseline-source-pins.json').read_bytes()) == selection['baseline_sha256']
assert sha((work / 'SOURCES-NORMAL-STAGING.json').read_bytes()) == selection['stage_sha256']
for name, file in selection['snapshots'].items():
    assert sha((work / file).read_bytes()) == selection['snapshot_sha256'][name]
for name, digest in json.loads((prior / 'source-pins.json').read_text()).items():
    data = (work / selection['snapshots'][name]).read_bytes() if name in selection['snapshots'] else (root / name).read_bytes()
    assert sha(data) == digest, name
assert sha((root / 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean').read_bytes()) == selection['unchanged_resource_owner_sha256']
print(json.dumps({'inherited_component_reports_verified': 462,
                  'fresh_component_reports_expected': 8,
                  'fresh_owner_preflight_reports': 0,
                  'unchanged_owner_reports_inherited': 264,
                  'old_sources_and_toolchain_byte_exact': True}), flush=True)
'''
strict = runtime / 'strict-new-and-bind.py'
strict.write_text(STRICT_BINDING_TEMPLATE + '\ncommands = ' + repr(commands)
    + '\nfor command in commands:\n    subprocess.run(command, check=True)\n')
template = (prior_run / 'check.py').read_text()
driver = template[:template.index('\njobs =')]
jobs = [('public-build', 'exec lake build', 0),
    ('strict-new-components-and-prior-bindings', 'exec python3 ' + shlex.quote(str(strict)), 8),
    ('independent-imports', 'exec lake env lean -j1 -DwarningAsError=true ' + shlex.quote(str(independent)), 271),
    ('audit-build', 'exec lake build MicroCFTA.Audit', 0),
    ('audit-strict', 'exec lake env lean -j1 -DwarningAsError=true MicroCFTA/Audit.lean', 676)]
driver += '\njobs = ' + repr(jobs) + '''
for name, command, count in jobs:
    run(name, command, count)
assert len(checks) == 5
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx']
           and (not job[2] or c['total_axiom_reports'] == job[2]) for c, job in zip(checks, jobs))
assert checks[1]['axiom_groups'] == 8 and checks[1]['axiom_free_reports'] == 0
assert checks[2]['axiom_groups'] == 268 and checks[2]['axiom_free_reports'] == 3
assert checks[4]['axiom_groups'] == 670 and checks[4]['axiom_free_reports'] == 6
match = re.search(r'Checked axiom dependencies of (\\d+) MicroCFTA theorems\\.', (runtime / 'audit-strict.txt').read_text())
assert match
'''
report = dict(prior)
for name in ['checks', 'limits', 'at', 'audited_theorems', 'checked_code', 'owner_preflight_evidence',
             'legacy_new_private_reports', 'legacy_new_private_reports_caveat', 'new_owner_export_maxHeartbeats',
             'old_transport_entire_bytes_preserved', 'old_transport_exact_offset',
             'new_ordinary_import_to_transport_owner_only']:
    report.pop(name, None)
for name in list(report):
    if name.startswith('old_non_audit_'):
        report.pop(name)
report.update(source_files=6251, direct_audit_imports=5251, individual_reports=676,
    independent_reports=271, resource_and_component_probes=470,
    inherited_resource_component_reports=462, fresh_resource_component_reports=8,
    replaced_old_reports=0, fresh_owner_preflight_reports=0,
    fresh_strict_normal_reports=8, actual_publication_strict_reports=8,
    resource_component_evidence='8 actual fresh strict reports (5 Native and3 Gamma,7 public+1 private) plus462 inherited reports; no report replacement, fresh resource-owner preflight or axiom-string replay; older exact-source/private checks add no fresh reports',
    new_component_reports=8, new_theorem_reports=8, new_modules=0, new_public_theorems=7,
    new_private_component_reports=1, new_public_component_reports=7, new_private_predicates=0,
    new_relation_declaration_checks=0, new_relation_declaration_reports=0,
    owner_resource_probes=264, previous_owner_resource_probes=264,
    owner_recompiled_in_publication_strict_gate=False, fresh_owner_preflight_evidence=None,
    inherited_owner_preflight_evidence={'prior_run': str(prior_run), 'reports': 264,
        'normal_owner_sha256': owner_sha, 'fresh_this_batch': False, 'included_in_inherited_462': True},
    old_non_audit_non_changed_owner_source_files_byte_exact=6248,
    old_non_audit_source_files_byte_exact=6248, entire_previous_resource_owner_byte_exact=True,
    old_resource_owner_sha256=owner_sha, changed_existing_owners=2,
    old_native_entire_bytes_preserved=169023, old_native_exact_offset=62,
    old_gamma_entire_bytes_preserved_as_prefix=26430, old_gamma_exact_offset=0,
    new_ordinary_imports_to_changed_owners=1, new_ordinary_import_bytes=62,
    old_audit_bytes_preserved_as_prefix=True, new_audit_imports=0,
    all_old_proof_bodies_and_limits_unchanged=True,
    generic_closed_root_returned_node_entry_proved=True,
    cold_returned_node_Profile_without_supplied_old_entry_proved=True,
    all_old_edge_children_requalified_jointly_proved=True,
    full_prefix_source_admission_with_past_inventory_proved=True,
    all_old_cold_returned_node_and_edge_full_admission_proved=True,
    earlier_exact_source_variant_preserved=True,
    first_failed_edge_and_exact_header_syntax_repair_preserved=True,
    input_pair_qualifications_still_explicit=True,
    every_warm_worker_call_qualification_proved=False, warm_query_no_new_mu_proved=False,
    all_warm_cells_source_qualification_proved=False,
    earlier_source_family_semantic_IH_discharged=False,
    every_cell_joint_query_attachment_proved=False, inherited_cell_semantic_chronology_proved=False,
    mixed_qualified_profile_height_orientation_derived=False,
    independent_query_inherited_warm_tables_proved=False, warm_across_independent_queries_proved=False,
    joint_finite_completion_proved=False, all_native_inhabitance_proved=False,
    source_terminal_marker_native_inhabitance_proved=False, source_type_marker_class_consistency_proved=False,
    compiled_haskell_correspondence_proved=False, haskell_changed=False,
    same_original_runtime_fuels=True, whole_worker_roles_proved=True,
    whole_worker_program_slots_proved=True, whole_worker_program_slots_fixed_marks_proved=True,
    proof_limits='unchanged defaults; unchanged owner proof settings inherited',
    prior_checkpoint=prior_commit, prior_immutable_archive=prior_archive.name, public_run=str(runtime))
driver += 'report = ' + repr(report) + '\n'
driver += '''report.update(checks=checks, limits=limits, at=datetime.datetime.now().astimezone().isoformat(),
              audited_theorems=int(match.group(1)))
(runtime / 'checked.json').write_text(json.dumps(report, indent=2) + '\\n')
print(json.dumps(report), flush=True)
'''
(runtime / 'check.py').write_text(driver)
files = list((root / 'lean/MicroCFTA').glob('*.lean'))
files += [root / name for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']]
files += [p for p in runtime.iterdir() if p.is_file()] + strict_sources
files += [Path(__file__), stage_path, work / 'baseline-source-pins.json', work / 'PUBLIC-PROBES.lean.txt']
files += [work / name for name in snapshots.values()]
files += [path for _, path in header_specs] + checked_inputs
files += [returned_packet / name for name in ['IMPORTS.lean.txt', 'APPEND.lean.txt', 'ASSEMBLY.json']]
files += [selected_packet / 'APPEND.lean.txt', node_packet / 'APPEND.lean.txt', edge_packet / 'APPEND.lean.txt', assembly_packet / 'ASSEMBLY.json']
(runtime / 'source-pins.json').write_text(json.dumps(
    {str(p.relative_to(root)): sha(p.read_bytes()) for p in files}, indent=2) + '\n')
print(json.dumps({'run': str(runtime), 'gates': 5, 'fresh_component_reports': 8,
    'inherited_component_reports': 462, 'combined_component_reports': 470,
    'replaced_old_reports': 0, 'fresh_owner_preflight_reports': 0,
    'inherited_owner_reports': 264, 'independent_reports': 271,
    'audit_reports': 676, 'objects': str(objects)}))
