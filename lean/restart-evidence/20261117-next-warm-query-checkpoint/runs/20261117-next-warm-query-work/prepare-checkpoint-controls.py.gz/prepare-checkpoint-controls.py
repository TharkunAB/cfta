from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/tritlo/Code/mcfta')
BASE = ROOT / 'lean/restart-evidence'
WORK = Path(__file__).resolve().parent
assert WORK == BASE / '20261117-next-warm-query-work'
PUBLIC = BASE / '20261117-next-warm-query-publication'
ARCHIVE = '20261117-next-warm-query-checkpoint'
BOARD_PREFIX = 'current-board-next-warm-query-'
SHA = lambda data: hashlib.sha256(data).hexdigest()
GIT = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
read = lambda path: json.loads(path.read_text())
bindings = read(WORK / 'prior-bindings.json')
prior = bindings['prior_checkpoint']
commit = read(WORK / 'SOURCE-COMMIT.json')
code = commit['source_commit']
assert re.fullmatch(r'[0-9a-f]{40}', code)
assert commit['parent'] == prior
assert GIT('rev-parse', 'HEAD').decode().strip() == code
assert GIT('rev-parse', code + '^').decode().strip() == prior
assert GIT('branch', '--show-current').decode().strip() == 'formalize'
assert not GIT('status', '--porcelain', '--untracked-files=no')
report = read(PUBLIC / 'checked.json')
verified = read(WORK / 'PUBLICATION-VERIFIED.json')
assert verified['actual_terminal'] and verified['pins_unchanged']
assert verified['checks'] == report['checks']
assert len(report['checks']) == 5
assert [item['total_axiom_reports'] for item in report['checks']] == [676, 8, 271, 676, 676]
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['nonstandard_axioms']
           and not item['sorryAx'] for item in report['checks'])
for key, expected in {'source_files': 6251, 'direct_audit_imports': 5251,
                      'individual_reports': 676, 'independent_reports': 271,
                      'fresh_resource_component_reports': 8,
                      'inherited_resource_component_reports': 462,
                      'resource_and_component_probes': 470,
                      'fresh_owner_preflight_reports': 0,
                      'actual_publication_strict_reports': 8,
                      'new_modules': 0, 'new_public_theorems': 7,
                      'new_private_component_reports': 1, 'new_private_predicates': 0,
                      'new_theorem_reports': 8, 'replaced_old_reports': 0}.items():
    assert report[key] == expected, key
assert [(item['axiom_groups'], item['axiom_free_reports']) for item in report['checks']] == [
    (670, 6), (8, 0), (268, 3), (670, 6), (670, 6)]
assert not report['owner_recompiled_in_publication_strict_gate']
assert report['fresh_owner_preflight_evidence'] is None
assert report['inherited_owner_preflight_evidence']['reports'] == 264
assert not report['inherited_owner_preflight_evidence']['fresh_this_batch']
assert report['inherited_owner_preflight_evidence']['included_in_inherited_462']
for key in ['generic_closed_root_returned_node_entry_proved',
            'cold_returned_node_Profile_without_supplied_old_entry_proved',
            'all_old_edge_children_requalified_jointly_proved',
            'full_prefix_source_admission_with_past_inventory_proved',
            'all_old_cold_returned_node_and_edge_full_admission_proved',
            'earlier_exact_source_variant_preserved',
            'first_failed_edge_and_exact_header_syntax_repair_preserved',
            'input_pair_qualifications_still_explicit',
            'whole_worker_program_slots_fixed_marks_proved']:
    assert report[key], key
for key in ['every_warm_worker_call_qualification_proved', 'warm_query_no_new_mu_proved',
            'all_warm_cells_source_qualification_proved',
            'earlier_source_family_semantic_IH_discharged', 'every_cell_joint_query_attachment_proved',
            'inherited_cell_semantic_chronology_proved', 'mixed_qualified_profile_height_orientation_derived',
            'independent_query_inherited_warm_tables_proved', 'warm_across_independent_queries_proved',
            'all_native_inhabitance_proved', 'source_type_marker_class_consistency_proved',
            'joint_finite_completion_proved', 'compiled_haskell_correspondence_proved', 'haskell_changed']:
    assert not report[key], key
pins = read(PUBLIC / 'source-pins.json')
for name, digest in pins.items():
    assert SHA((ROOT / name).read_bytes()) == digest, name
source_pins = {name: digest for name, digest in pins.items()
               if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
actual = {str(path.relative_to(ROOT)) for path in (ROOT / 'lean/MicroCFTA').glob('*.lean')}
assert len(source_pins) == 6251 and actual == set(source_pins)
assert verified['reverified_pins'] == len(pins)
for name in commit['files']:
    assert GIT('show', code + ':' + name) == (ROOT / name).read_bytes(), name
native = 'lean/MicroCFTA/SourceSynthesisCurrentUniverseNativeAllocation.lean'
gamma = 'lean/MicroCFTA/SourceCurrentAllocatedNativePastGammaEqualEntryPayload.lean'
audit = 'lean/MicroCFTA/Audit.lean'
changed = {native, gamma, audit}
stage = read(WORK / 'SOURCES-NORMAL-STAGING.json')
assert len(stage['components']) == 2
assert set(commit['files']) == changed
assert set(GIT('diff', '--name-only', prior, code).decode().splitlines()) == changed
baseline = read(WORK / 'baseline-source-pins.json')
assert len(baseline) == 6251 and actual == set(baseline)
for name, digest in baseline.items():
    if name not in changed:
        assert source_pins[name] == digest, name
assert len(set(baseline) - changed) == 6248
old = {}
for item in stage['components']:
    name = item['source_path']
    data = (WORK / (item['module'] + '-BEFORE.lean.txt')).read_bytes()
    old[name] = data
    assert GIT('show', prior + ':' + name) == data
    assert len(data) == item['old_owner_bytes'] and SHA(data) == item['old_owner_sha256']
    normal = (ROOT / name).read_bytes()
    offset = item['old_owner_offset']
    assert normal[offset:offset + len(data)] == data
    assert source_pins[name] == item['raw_sha256']
assert len(old[native]) == 169023 and stage['components'][0]['old_owner_offset'] == 62
assert len(old[gamma]) == 26430 and stage['components'][1]['old_owner_offset'] == 0
old_audit = (WORK / 'Audit-BEFORE.lean.txt').read_bytes()
assert GIT('show', prior + ':' + audit) == old_audit
selected_packet = BASE / '20261117-source-prefix-full-call-admission-past-inventory-draft'
returned_packet = BASE / '20261117-returned-cells-full-source-admission-draft'
node_packet = BASE / '20261117-closed-root-returned-node-entry-draft'
edge_packet = BASE / '20261117-old-returned-edge-record-syntax-repair'
import_prefix = (returned_packet / 'IMPORTS.lean.txt').read_bytes()
assert import_prefix == b'import MicroCFTA.SourceCurrentAllocatedNativeNodeReturnOrigin\n' and len(import_prefix) == 62
assert (ROOT / native).read_bytes() == import_prefix + old[native] + (selected_packet / 'APPEND.lean.txt').read_bytes() + b'\n' + (returned_packet / 'APPEND.lean.txt').read_bytes()
assert (ROOT / gamma).read_bytes() == old[gamma] + b'\n' + (node_packet / 'APPEND.lean.txt').read_bytes() + b'\n' + (edge_packet / 'APPEND.lean.txt').read_bytes()
assert old_audit.count(b'#print axioms ') == 669
public = (WORK / 'PUBLIC-PROBES.lean.txt').read_bytes()
assert public.count(b'#check ') == public.count(b'#print axioms ') == 7
assert (ROOT / audit).read_bytes() == old_audit + b'\n' + public
owner = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
assert source_pins[owner] == baseline[owner] == report['old_resource_owner_sha256']
prior_archive = BASE / bindings['prior_archive']
for name, key in [('manifest.json', 'prior_manifest_sha256'),
                  ('checkpoint.json', 'prior_checkpoint_json_sha256')]:
    data = (prior_archive / name).read_bytes()
    assert SHA(data) == bindings[key]
    assert GIT('show', prior + ':' + str((prior_archive / name).relative_to(ROOT))) == data
old_checkpoint = read(prior_archive / 'checkpoint.json')
assert old_checkpoint['resource_and_component_probes'] == 462
assert report['inherited_resource_component_reports'] == old_checkpoint['resource_and_component_probes']
assert old_checkpoint['checked_code'] == GIT('rev-parse', prior + '^').decode().strip()
prior_files = {item['path']: item for item in read(prior_archive / 'manifest.json')['files']}
for name in ['source-pins.json.gz', 'verification.json', 'archived-inputs.json']:
    data = (prior_archive / name).read_bytes()
    assert len(data) == prior_files[name]['bytes']
    assert SHA(data) == prior_files[name]['sha256']
    assert GIT('show', prior + ':' + str((prior_archive / name).relative_to(ROOT))) == data
old_verification = read(prior_archive / 'verification.json')
assert old_verification['checked_code'] == old_checkpoint['checked_code']
assert old_verification['source_tree_sha256'] == old_checkpoint['source_tree_sha256']
assert old_verification['prior_document_bytes_preserved']
old_pins = json.loads(gzip.decompress((prior_archive / 'source-pins.json.gz').read_bytes()))
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    assert old_pins[name] == pins[name], name
assert baseline == {name: digest for name, digest in old_pins.items()
                    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
request = read(WORK / (BOARD_PREFIX + 'request.json'))
canonical = read(WORK / (BOARD_PREFIX + 'canonical.json'))
assert canonical.get('verified', True)
post = canonical.get('post', canonical)
assert post['id'] == request['request_id']
assert type(post['sequence']) is int and post['sequence'] > 0
for key, expected in [('author', request['username']), ('thread_id', request['thread_id']),
                      ('post_type', request['post_type']), ('content', request['content']),
                      ('metadata', request['metadata'])]:
    assert post[key] == expected, key
assert post['metadata']['source'] == code
receipt_specs = [
    ('NODE-ENTRY-FIRST-VERIFIED.json', 12868, 2),
    ('FULL-ADMISSION-EXACT-SOURCE-FIRST-VERIFIED.json', 56339, 3),
    ('FULL-ADMISSION-PAST-INVENTORY-FIRST-VERIFIED.json', 69474, 3),
    ('EDGE-REPAIR-VERIFIED.json', 12716, 1),
    ('RETURNED-CELLS-ADMISSION-FIRST-VERIFIED.json', 24095, 5),
    ('NODE-EDGE-COMBINED-VERIFIED.json', 92023, 3)]
for filename, session, count in receipt_specs:
    receipt = read(WORK / filename)
    assert receipt['actual_session'] == session and receipt['actual_terminal_exit'] == 0
    checked = read(BASE / receipt['run'] / 'checked.json')
    assert receipt['checks'] == checked['checks']
    assert checked['normal_module_checked'] and checked['source_pins_unchanged']
    assert checked['checks'][-1]['total_axiom_reports'] == count
    assert all(item['exit'] == 0 and not item['diagnostics'] and not item['nonstandard_axioms']
               and not item['sorryAx'] for item in checked['checks'])
failed_edge = read(WORK / 'EDGE-FIRST-FAILED.json')
assert failed_edge['actual_session'] == 2133 and failed_edge['actual_terminal_exit'] == 1
assert failed_edge['first_packet_preserved']
failed_run = BASE / failed_edge['run']
failed_result = read(failed_run / ('checked.json' if (failed_run / 'checked.json').exists() else 'results.json'))
assert failed_result['checks'][-1]['exit'] == 1 and failed_result['checks'][-1]['sorryAx']
preparation_failure = read(BASE / '20261117-next-warm-node-edge-assembly-check/PREPARATION-FAILED.json')
assert not preparation_failure['compiler_started'] and not preparation_failure['source_or_object_output_created']
assert not preparation_failure['proof_or_header_changed']
assert preparation_failure['actual_sha256'] == stage['components'][1]['raw_sha256']
cleanup = read(WORK / 'combined-terminal-cleanup-result.json')
assert cleanup['no_double_counting'] and cleanup['all_terminal_directories_distinct']
cleanup_paths = [item.get('directory', item.get('path')) for item in cleanup['targets']]
assert all(isinstance(path, str) and path for path in cleanup_paths)
assert len(set(cleanup_paths)) == len(cleanup_paths)
assert cleanup['all_targets_absent']
assert cleanup['sources_logs_live_jobs_normal_lake_unknown_entries_preserved']
assert cleanup['removed_bytes'] == sum(item['bytes'] for item in cleanup['targets'])
assert cleanup['cumulative_removed_bytes'] >= cleanup['removed_bytes']
assert all(item['terminal_exit'] in [0, 1] for item in cleanup['targets'])
usage = read(WORK / 'USAGE.json')
assert 0 <= usage['rate_limits']['primary']['used_percent'] <= 80
roots = read(WORK / 'selection-roots.json')
additional_path = WORK / 'archive-additional-roots.json'
additional = read(additional_path) if additional_path.exists() else []
for item in additional:
    assert re.fullmatch(r'20261117-[a-z0-9-]+', item['root'])
    assert item['manifest'] in ['MANIFEST.json', 'manifest.json', 'MANIFEST.sha256']
    assert SHA((BASE / item['root'] / item['manifest']).read_bytes()) == item['sha256']
    roots.append(item['root'])
assert len(roots) == len(set(roots))
assert all((BASE / name).is_dir() and not (BASE / name).is_symlink() for name in roots)
# Each selected compiler run must have an actual terminal result.
for name in roots:
    run = BASE / name
    if (run / 'PREPARATION-FAILED.json').exists():
        failure = read(run / 'PREPARATION-FAILED.json')
        assert not failure['compiler_started']
        assert not failure['source_or_object_output_created']
    elif (run / 'check.py').exists():
        result = read(run / ('checked.json' if (run / 'checked.json').exists() else 'results.json'))
        assert result['checks'] and all(type(item['exit']) is int for item in result['checks']), name
assert SHA((BASE / '20261117-authentic-auxiliary-base-key-recovery-layout-draft/MANIFEST.sha256').read_bytes()) == 'f2cb87f7ce31005040de4ae552f8ce5e1e57041d657f5db31f9f3c76d9193b30'
auxiliary = read(BASE / '20261117-authentic-auxiliary-base-key-recovery-layout-draft/STATUS.json')
assert not auxiliary['compiler_executed'] and not auxiliary['source_mutations']
assert auxiliary['status'].startswith('FROZEN UNCOMPILED')
for item in read(WORK / 'original-header-files.json'):
    assert SHA((ROOT / item['path']).read_bytes()) == item['sha256'], item['path']
    assert SHA((ROOT / item['original']).read_bytes()) == item['sha256'], item['original']
selected = sorted(str((BASE / name).relative_to(ROOT)) for name in roots)
assert not (BASE / ARCHIVE).exists()
config = dict(report)
tree = hashlib.sha256()
for name, digest in sorted(source_pins.items()):
    tree.update(name.encode() + b'\0' + digest.encode() + b'\n')
config.update(checked_code=code, prior_checkpoint=prior, public_run=str(PUBLIC), public_gates=5,
    explicit_reports=report['individual_reports'], board_prefix=BOARD_PREFIX,
    board_post_id=post['id'], board_sequence=post['sequence'],
    source_tree_sha256=tree.hexdigest(),
    old_non_audit_non_changed_owner_source_files_byte_exact=6248,
    old_native_entire_bytes_preserved=169023, old_native_exact_offset=62,
    old_gamma_entire_bytes_preserved_as_prefix=26430, old_gamma_exact_offset=0,
    ordinary_owner_import_bytes=62, new_audit_imports=0, old_audit_bytes_preserved_as_prefix=True,
    old_owner_proof_bodies_unchanged=True, old_owner_proof_limits_unchanged=True,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],
    cleanup_receipt='combined-terminal-cleanup-result.json',
    primary_usage_percent=usage['rate_limits']['primary']['used_percent'],
    primary_usage_checked_at=usage['event_timestamp'],
    prior_immutable_archive=bindings['prior_archive'],
    prior_manifest_sha256=bindings['prior_manifest_sha256'],
    new_theorem_declarations=8, fresh_strict_reports=8,
    inherited_component_reports=462, replaced_old_reports=0,
    all_new_formal_proof_checks_first_pass=False,
    first_edge_syntax_failure_and_exact_header_repair_preserved=True,
    combined_preparation_checksum_failure_before_compiler_preserved=True,
    uncompiled_auxiliary_key_candidate_adds_no_theorem_credit=True,
    additional_frozen_roots=additional,
    joint_finite_completion_proved=False,
    compiled_haskell_correspondence_proved=False, haskell_changed=False, goal_active=True)
skipped = sorted(str(path.relative_to(ROOT)) for path in BASE.iterdir()
    if path.is_dir() and path.name.startswith('20261117-') and str(path.relative_to(ROOT)) not in selected)
review = {
    'prior_checkpoint': prior, 'prior_immutable_archive': bindings['prior_archive'],
    'prior_manifest_sha256': bindings['prior_manifest_sha256'], 'selected_roots': len(selected),
    'base_roots': len(read(WORK / 'selection-roots.json')), 'additional_frozen_roots': additional,
    'policy': 'Keep both source-admission variants and scope repairs, all original headers, the original node and edge proofs, the failed edge compiler attempt and exact-header repair, checksum-only rejected combined preparation and terminal successful combined check, actual publication, and frozen open warm-design and auxiliary-key candidates. The auxiliary candidate adds no theorem credit.',
    'new_public_theorem_reports': 7, 'new_private_component_reports': 1,
    'new_private_predicates': 0, 'new_theorem_declarations': 8,
    'fresh_owner_preflight_reports': 0, 'actual_publication_strict_reports': 8,
    'fresh_reports_this_batch': 8, 'inherited_bound_reports': 462,
    'prior_component_reports': 462, 'replaced_old_reports': 0,
    'inherited_owner_reports_included': 264,
    'all_new_formal_proof_checks_first_pass': False,
    'first_edge_failed_and_repaired_exact_header_preserved': True,
    'combined_checksum_preparation_failed_before_compiler': True,
    'uncompiled_auxiliary_key_candidate_theorem_credit': 0,
    'all_old_cold_returned_full_admission_proved': True,
    'input_pair_qualifications_still_explicit': True,
    'all_warm_worker_call_qualifications_proved': False,
    'warm_query_no_new_mu_proved': False,
    'earlier_source_family_semantic_IH_discharged': False,
    'every_cell_joint_query_attachment_proved': False,
    'inherited_cell_semantic_chronology_proved': False,
    'warm_across_independent_queries_proved': False, 'all_native_inhabitance_proved': False,
    'type_marker_class_consistency_proved': False, 'joint_finite_completion_proved': False,
    'haskell_changed': False, 'no_axiom_string_replay': True,
    'no_compiled_objects_or_import_overlays': True,
}
note = (WORK / 'checkpoint-note.md').read_text()
for key, value in {'THEOREMS': report['audited_theorems'], 'REMOVED': cleanup['removed_bytes'],
                   'CLEANUP': cleanup['cumulative_removed_bytes'],
                   'USAGE': config['primary_usage_percent']}.items():
    note = note.replace('{{' + key + '}}', str(value))
assert set(re.findall(r'\{\{(.*?)\}\}', note)) == {'TIME', 'TREE', 'CODE'}
outputs = {'checkpoint-config.json': config, 'archive-roots.json': selected,
           'skipped-published-roots.json': skipped, 'selection-review.json': review}
assert all(not (WORK / name).exists() for name in outputs)
for name, value in outputs.items():
    (WORK / name).write_text(json.dumps(value, indent=2) + '\n')
(WORK / 'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code': code, 'packet': ARCHIVE,
                  'roots': len(selected), 'board_sequence': post['sequence'],
                  'new_theorem_declarations': 8, 'fresh_strict_reports': 8, 'inherited_reports': 462}))
