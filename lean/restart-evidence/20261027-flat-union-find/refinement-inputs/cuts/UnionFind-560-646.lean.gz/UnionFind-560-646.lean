def SizesCorrect (forest : Forest) (domain : List Nat) : Prop :=
  ∀ uv ∈ domain, ∀ root size, Reaches forest uv root size → size = classCount forest domain uv

/-- Compression preserves exact size metadata on the allocated domain. -/
theorem findRoot_sizes (valid : Total forest) (sizes : SizesCorrect forest domain)
    (result : findRoot fuel forest uv = some found) : SizesCorrect found.forest domain := by
  intro other member root size path
  rw [findRoot_counts valid result]
  exact sizes other member root size ((findRoot_reaches_iff valid result ..).mp path)

/-- Adding two correct root sizes retains all class cardinality metadata. -/
theorem link_sizes (valid : Total forest) (sizes : SizesCorrect forest domain)
    (loserRoot : read forest loser = .root loserSize)
    (winnerRoot : read forest winner = .root winnerSize) (different : loser ≠ winner)
    (loserCount : loserSize = classCount forest domain loser)
    (winnerCount : winnerSize = classCount forest domain winner) :
    SizesCorrect (link forest loser winner loserSize winnerSize) domain := by
  intro uv member root size path
  obtain ⟨oldRoot, oldSize, oldPath⟩ := valid uv
  have newPath := link_reaches loserRoot winnerRoot different oldPath
  have sameSize := (reaches_unique newPath path).2
  rw [← sameSize, classCount_same (sameClass_root newPath)]
  by_cases wasLoser : oldRoot = loser
  · subst oldRoot
    simp only [redirect, mergedSize, ↓reduceIte, true_or]
    rw [link_winner_count valid loserRoot winnerRoot different, loserCount, winnerCount]
  · by_cases wasWinner : oldRoot = winner
    · subst oldRoot
      simp only [redirect, mergedSize, wasLoser, ↓reduceIte, or_true]
      rw [link_winner_count valid loserRoot winnerRoot different, loserCount, winnerCount]
    · simp only [redirect, mergedSize, wasLoser, wasWinner, ↓reduceIte, or_self]
      rw [link_other_count valid loserRoot winnerRoot different (reaches_terminal oldPath) wasLoser wasWinner]
      rw [← classCount_same (sameClass_root oldPath)]
      exact sizes uv member _ _ oldPath

/-- Singleton initialization gives exact root sizes on a domain without duplicates. -/
theorem initial_sizes (variables domain : List Nat) (unique : domain.Nodup) :
    SizesCorrect (withInitialValues variables) domain := by
  intro uv member root size path
  have same := reaches_unique path (.root (read_initial variables uv))
  rw [same.2]
  classical
  unfold classCount
  have predicates : (fun other => decide (SameClass (withInitialValues variables) uv other)) =
      (fun other => other == uv) := by
    funext other
    by_cases same : uv = other
    · subst other; simp [initial_classes]
    · simp [initial_classes, same, Ne.symm same]
  rw [predicates, ← List.count_eq_countP, unique.count_of_mem member]

/-- Union retains exact root sizes when both queried variables are allocated. -/
theorem union_sizes (valid : Total forest) (sizes : SizesCorrect forest domain)
    (leftMember : left ∈ domain) (rightMember : right ∈ domain)
    (result : union leftFuel rightFuel forest left right = some output) : SizesCorrect output domain := by
  cases firstResult : findRoot leftFuel forest left with
  | none => simp [union, firstResult] at result
  | some first =>
    cases secondResult : findRoot rightFuel first.forest right with
    | none => simp [union, firstResult, secondResult] at result
    | some second =>
      have firstValid := findRoot_total valid firstResult
      have secondValid := findRoot_total firstValid secondResult
      have firstSizes := findRoot_sizes valid sizes firstResult
      have secondSizes := findRoot_sizes firstValid firstSizes secondResult
      have leftPath := (findRoot_correct _ _ _ _ secondResult).2
        ((findRoot_correct _ _ _ _ firstResult).2 (findRoot_correct _ _ _ _ firstResult).1)
      have rightPath := (findRoot_correct _ _ _ _ secondResult).2
        (findRoot_correct _ _ _ _ secondResult).1
      have leftCount : first.size = classCount second.forest domain first.representative :=
        (secondSizes left leftMember _ _ leftPath).trans (classCount_same (sameClass_root leftPath) domain)
      have rightCount : second.size = classCount second.forest domain second.representative :=
        (secondSizes right rightMember _ _ rightPath).trans (classCount_same (sameClass_root rightPath) domain)
      by_cases same : first.representative = second.representative
      · simp [union, firstResult, secondResult, same] at result
        subst output
        exact secondSizes
      · by_cases smaller : first.size < second.size
        · simp [union, firstResult, secondResult, same, smaller] at result
          subst output
          exact link_sizes secondValid secondSizes (reaches_terminal leftPath) (reaches_terminal rightPath)
            same leftCount rightCount
        · simp [union, firstResult, secondResult, same, smaller] at result
          subst output
          exact link_sizes secondValid secondSizes (reaches_terminal rightPath) (reaches_terminal leftPath)
            (Ne.symm same) rightCount leftCount

