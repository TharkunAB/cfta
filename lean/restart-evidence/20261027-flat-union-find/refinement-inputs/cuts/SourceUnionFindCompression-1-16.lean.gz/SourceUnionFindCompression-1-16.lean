import MicroCFTA.UnionFind

/-!
# Conditional path-compression writes

The source writes the current parent entry only when its old parent differs
from the final representative. Compression uses the state returned by the
recursive call. This worker has the same representative, stored size, and
entire extensional forest as the earlier unconditional-write worker.
The finite bound remains an execution witness, not a source failure mode.
-/

namespace MicroCFTA.SourceUnionFindCompression

open UnionFind

