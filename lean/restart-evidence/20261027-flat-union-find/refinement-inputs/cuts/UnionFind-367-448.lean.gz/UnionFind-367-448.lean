theorem union_correct (valid : Total forest)
    (result : union leftFuel rightFuel forest left right = some output) :
    Total output ∧ ∀ x y,
      SameClass output x y ↔
        SameClass forest x y ∨
        (SameClass forest x left ∧ SameClass forest y right) ∨
        (SameClass forest x right ∧ SameClass forest y left) := by
  cases firstResult : findRoot leftFuel forest left with
  | none => simp [union, firstResult] at result
  | some first =>
    cases secondResult : findRoot rightFuel first.forest right with
    | none => simp [union, firstResult, secondResult] at result
    | some second =>
      have firstValid := findRoot_total valid firstResult
      have secondValid := findRoot_total firstValid secondResult
      have leftPath := (findRoot_correct _ _ _ _ secondResult).2
        ((findRoot_correct _ _ _ _ firstResult).2 (findRoot_correct _ _ _ _ firstResult).1)
      have rightPath := (findRoot_correct _ _ _ _ secondResult).2
        (findRoot_correct _ _ _ _ secondResult).1
      have leftRoot := reaches_terminal leftPath
      have rightRoot := reaches_terminal rightPath
      have unchanged (x y : Nat) : SameClass second.forest x y ↔ SameClass forest x y :=
        (findRoot_classes firstValid secondResult x y).trans (findRoot_classes valid firstResult x y)
      by_cases same : first.representative = second.representative
      · simp [union, firstResult, secondResult, same] at result
        subst output
        refine ⟨secondValid, ?_⟩
        have sameBefore : SameClass forest left right :=
          (unchanged left right).mp ((sameClass_iff_roots leftPath rightPath).mpr same)
        intro x y
        exact (unchanged x y).trans (redundant_merge sameBefore x y).symm
      · by_cases smaller : first.size < second.size
        · simp [union, firstResult, secondResult, same, smaller] at result
          subst output
          refine ⟨link_total secondValid leftRoot rightRoot same, ?_⟩
          intro x y
          rw [link_classes secondValid leftRoot rightRoot same]
          simp only [root_membership secondValid leftPath, root_membership secondValid rightPath, unchanged]
        · simp [union, firstResult, secondResult, same, smaller] at result
          subst output
          refine ⟨link_total secondValid rightRoot leftRoot (Ne.symm same), ?_⟩
          intro x y
          rw [link_classes secondValid rightRoot leftRoot (Ne.symm same)]
          simp only [root_membership secondValid leftPath, root_membership secondValid rightPath, unchanged]
          grind only

/-- Every requested union of a total forest has sufficient finite execution bounds. -/
theorem union_terminates (valid : Total forest) (left right : Nat) :
    ∃ leftFuel rightFuel output, union leftFuel rightFuel forest left right = some output := by
  obtain ⟨root, size, path⟩ := valid left
  obtain ⟨leftFuel, first, firstResult⟩ := findRoot_terminates path
  obtain ⟨root', size', path'⟩ := findRoot_total valid firstResult right
  obtain ⟨rightFuel, second, secondResult⟩ := findRoot_terminates path'
  refine ⟨leftFuel, rightFuel, ?_⟩
  simp [union, firstResult, secondResult]
  split <;> (try split) <;> exact ⟨_, rfl⟩

/-- The empty Haskell map. -/
def empty : Forest := fun _ => none

/-- Initialize the supplied variables as singleton roots. -/
def withInitialValues (variables : List Nat) : Forest :=
  fun uv => if uv ∈ variables then some (.root 1) else none

@[simp] theorem read_empty (uv : Nat) : read empty uv = .root 1 := rfl

@[simp] theorem read_initial (variables : List Nat) (uv : Nat) :
    read (withInitialValues variables) uv = .root 1 := by
  simp only [read, withInitialValues]
  split <;> rfl

/-- Empty and initialized forests both give terminating singleton paths. -/
theorem empty_total : Total empty := fun uv => ⟨uv, 1, .root rfl⟩

theorem initial_total (variables : List Nat) : Total (withInitialValues variables) :=
  fun uv => ⟨uv, 1, .root (read_initial variables uv)⟩

/-- Initial classes identify no distinct variables, including missing entries. -/
theorem initial_classes (variables : List Nat) (left right : Nat) :
    SameClass (withInitialValues variables) left right ↔ left = right :=
  sameClass_iff_roots (.root (read_initial variables left)) (.root (read_initial variables right))

