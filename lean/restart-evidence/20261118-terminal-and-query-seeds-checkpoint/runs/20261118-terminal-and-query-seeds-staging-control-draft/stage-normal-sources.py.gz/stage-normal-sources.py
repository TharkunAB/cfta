from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/tritlo/Code/mcfta')
BASE = ROOT / 'lean/restart-evidence'
CONTROL = BASE / '20261118-terminal-and-query-seeds-staging-control-draft'
WORK = BASE / '20261118-terminal-query-resources-work'
assert Path(__file__).resolve().parent == WORK.resolve(), 'Root reviews and copies this exact staging controller.'
assert Path(__file__).read_bytes() == (CONTROL/'stage-normal-sources.py').read_bytes()
assert not (WORK/'SOURCES-NORMAL-STAGING.json').exists()
SHA = lambda data: hashlib.sha256(data).hexdigest()
bound = set()


def verify(path, record):
    data = path.read_bytes()
    assert SHA(data) == (record['sha256'] if isinstance(record, dict) else record), str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data


def records(manifest):
    files = manifest['files']
    return files.items() if isinstance(files, dict) else [(r.get('file', r.get('path')), r) for r in files]


def packet_files(packet, digest):
    manifest = json.loads(verify(packet/'MANIFEST.json', digest))
    for name, record in records(manifest):
        verify(packet/name, record)


for name, record in records(json.loads((CONTROL/'MANIFEST.json').read_text())):
    verify(CONTROL/name, record)
bound.add(CONTROL/'MANIFEST.json')
for name, record in json.loads((CONTROL/'RECEIPT-PINS.json').read_text()).items():
    verify(ROOT/name, record)
stage = json.loads((CONTROL/'EXPECTED-STAGE.json').read_text())
assert stage['source_baseline'] == '04e2eb843816747cab7ec59a150d0897619274b4'
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6284, 5284, 738, 333)
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (3, 529, 532)
assert stage['new_public_theorems'] == stage['new_private_helpers_transitive'] == 3
assert stage['new_definitions'] == stage['new_Prop_definitions'] == stage['definition_checks'] == stage['explicit_private_reports'] == 0
assert stage['resource_reports_inherited'] == 264 and stage['extra_fresh_incoming_recheck_credit'] == 0
prior = BASE/'20261118-ordered-fold-query-resources-work'
publication = BASE/'20261118-fold-query-resources-publication'
commit = json.loads((prior/'SOURCE-COMMIT.json').read_text())
commit_actual = json.loads((prior/'SOURCE-COMMIT-ACTUAL-RUN.json').read_text())
pub_verified = json.loads((prior/'PUBLICATION-VERIFIED.json').read_text())
pub_actual = json.loads((prior/'PUBLICATION-ACTUAL-RUN.json').read_text())
published = json.loads((publication/'checked.json').read_text())
assert commit['source_commit'] == commit_actual['source_commit'] == stage['source_baseline']
assert commit['actual_terminal'] and commit_actual['actual_terminal']
assert commit['actual_terminal_exit'] == commit_actual['actual_terminal_exit'] == 0
assert commit_actual['actual_session'] == 22154
assert pub_verified['actual_session'] == pub_actual['actual_session'] == commit['publication_actual_session'] == 72663
assert pub_verified['actual_terminal'] and pub_actual['actual_terminal']
assert pub_verified['actual_terminal_exit'] == pub_actual['actual_terminal_exit'] == 0
assert published == json.loads((publication/'results.json').read_text())
assert pub_verified['checks'] == published['checks']
assert [c['total_axiom_reports'] for c in published['checks']] == [735, 2, 330, 735, 735]
assert all(c['exit'] == 0 and not c['diagnostics'] and not c['sorryAx'] and not c['nonstandard_axioms']
    and c['declaration_checks'] == 0 for c in published['checks'])
assert published['all_five_gates_passed'] and published['source_pins_unchanged']
assert SHA((publication/'checked.json').read_bytes()) == pub_verified['checked_sha256']
assert SHA((publication/'source-pins.json').read_bytes()) == pub_verified['source_pins_sha256']
pub_pins = json.loads((publication/'source-pins.json').read_text())
assert len(pub_pins) == pub_verified['pins_independently_reverified'] == 8398
for name, digest in pub_pins.items():
    verify(ROOT/name, digest)
push = json.loads((ROOT/stage['prior_checkpoint_push_receipt']).read_text())
assert push['source_commit'] == stage['source_baseline']
assert push['checkpoint_commit'] == push['remote_commit'] == stage['prior_checkpoint'] == 'e5fc00c2a9ccf70322b4f0a2780e1293ecb2ead9'
assert push['actual_push_terminal'] and push['actual_remote_check_terminal']
assert push['actual_push_terminal_exit'] == push['actual_remote_check_terminal_exit'] == push['postpush_current_tree_verifier_terminal_exit'] == 0
assert push['normal_Source_files'] == 6283
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT).decode().strip() == 'formalize'
subprocess.run(['git', 'merge-base', '--is-ancestor', stage['source_baseline'], 'HEAD'], check=True, cwd=ROOT)
changes = subprocess.check_output(['git', 'diff', '--name-only', stage['source_baseline'], 'HEAD'], cwd=ROOT).decode().splitlines()
assert all(n in ['NEXT-PROMPT.md', 'HANDOFF.md', 'FINDINGS.md'] or n.startswith('lean/restart-evidence/') for n in changes), changes
subprocess.run(['git', 'diff', '--quiet', stage['source_baseline'], 'HEAD', '--', 'lean/MicroCFTA',
    'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json', 'shell.nix'], check=True, cwd=ROOT)
baseline = json.loads(verify(ROOT/stage['source_baseline_path'], stage['source_baseline_sha256']))
assert len(baseline['sources']) == 6283 and len(baseline['toolchain']) == 4
assert {str(p.relative_to(ROOT)) for p in (ROOT/'lean/MicroCFTA').glob('*.lean')} == set(baseline['sources'])
for name, record in {**baseline['sources'], **baseline['toolchain']}.items():
    verify(ROOT/name, record)
    assert pub_pins[name] == record['sha256']

# The first two checks supply three distinct laws. Incoming alone is a prerequisite.
checks = json.loads((CONTROL/'PRIVATE-CHECKS.json').read_text())
assert [c['actual_session'] for c in checks] == [99821, 32584, 69321]
assert [c['fresh_public_reports'] for c in checks] == [1, 2, 0]
for check in checks:
    verified = json.loads((ROOT/check['verified_receipt']).read_text())
    actual = json.loads((ROOT/check['actual_receipt']).read_text())
    runtime = BASE/check['runtime']
    checked = json.loads((runtime/'checked.json').read_text())
    assert verified['actual_session'] == actual['actual_session'] == check['actual_session']
    assert verified['actual_terminal'] and actual['actual_terminal']
    assert verified['actual_terminal_exit'] == actual['actual_terminal_exit'] == 0
    assert verified['checks'] == checked['checks'] and checked == json.loads((runtime/'results.json').read_text())
    assert verified['proof_credit'] and verified['source_pins_unchanged'] and all(checked['passed'])
    assert sum(c['total_axiom_reports'] for c in checked['checks']) == check['expected_reports']
    assert all(c['exit'] == 0 and not c['diagnostics'] and not c['sorryAx'] and not c['nonstandard_axioms']
        and c['declaration_checks'] == 0 for c in checked['checks'])
    assert SHA((runtime/'checked.json').read_bytes()) == verified['checked_sha256']
    assert SHA((runtime/'source-pins.json').read_bytes()) == verified['source_pins_sha256']
    pins = json.loads((runtime/'source-pins.json').read_text())
    assert len(pins) == verified['pins_independently_reverified'] == check['pins']
    for name, digest in pins.items():
        verify(ROOT/name, digest)
    packet_files(BASE/check['control'], check['control_manifest_sha256'])
    if check['name'] == 'incomingPrerequisite':
        assert verified['executed_control'] == actual['executed_control'] == check['control']
        assert verified['executed_control_manifest_sha256'] == actual['executed_control_manifest_sha256'] == check['control_manifest_sha256']
for failed in json.loads((CONTROL/'REJECTED-CHECKS.json').read_text()):
    rejected = json.loads((ROOT/failed['receipt']).read_text())
    runtime = BASE/failed['runtime']
    result = json.loads((runtime/'results.json').read_text())
    assert rejected['actual_session'] == failed['actual_session'] and rejected['actual_terminal'] and rejected['actual_terminal_exit'] == 1
    assert rejected['checks'] == result['checks'] and rejected['credited_public_reports'] == result['credited_public_reports'] == 0
    assert not result['proof_credit'] and not (runtime/'checked.json').exists()
    assert sum(c['diagnostics'] for c in result['checks']) == failed['diagnostics']
    assert any(c['sorryAx'] for c in result['checks']) == failed['sorryAx']
    assert SHA((runtime/'results.json').read_bytes()) == rejected['results_sha256']
    assert SHA((runtime/'source-pins.json').read_bytes()) == rejected['source_pins_sha256']
    pins = json.loads((runtime/'source-pins.json').read_text())
    assert len(pins) == rejected['pins_independently_reverified'] == failed['pins']
    for name, digest in pins.items():
        verify(ROOT/name, digest)
preflight = json.loads((ROOT/stage['rejected_preparer_receipt']).read_text())
assert preflight['original_control_manifest_sha256'] == '6b65d8fca7328ccf7e07b5ed15937bdccdd118560791a93632659f118b78263e'
assert preflight['actual_terminal_exit'] == 1 and not preflight['compiler_started'] and not preflight['runtime_or_tmp_created']
assert preflight['proof_credit'] == 0

components = json.loads((CONTROL/'COMPONENTS.json').read_text())['components']
assert components == stage['components'] and len(components) == 2
term, seeds = components
raws = {}
for component in components:
    packet = BASE/component['packet']
    packet_files(packet, component['manifest_sha256'])
    for record in json.loads((packet/'SOURCE-PINS.json').read_text())['files']:
        path = ROOT/record['file']
        if component['module'] == term['module'] and record['file'] == 'lean/MicroCFTA/SourcePruningEnumerationSharedTerminalFoldQueryEvents.lean':
            assert record['sha256'] == 'a84aa92503c88ee0b320d70a41cb31419e43ed81917bc9c0e1eb5065bb0b4290'
            path = prior/'TerminalFoldQueryEvents-BEFORE.lean.txt'
        verify(path, record)
    raw = verify(packet/component['source'], {'sha256': component['raw_sha256'], 'bytes': component['raw_bytes']})
    for header in component['all_headers']:
        data = verify(ROOT/header['file'], header['sha256'])
        body = data.rstrip()
        assert raw.count(body) == 1
        start = raw.index(body)
        assert re.match(rb'\s*:= by', raw[start + len(body):])
    probes = verify(packet/component['probe'], component['probe_sha256'])
    assert re.findall(r'^#print axioms (\S+)', probes.decode(), re.M) == component['public_qnames']
    assert b'#check ' not in probes and b'#print axioms ' not in raw and b'#check ' not in raw
    assert not re.search(rb'\b(?:sorry|axiom)\b', raw)
    raws[component['module']] = raw
before_term = verify(ROOT/term['source_path'], {'sha256': term['owner_sha256'], 'bytes': 19079})
assert before_term == (CONTROL/'TERMINAL-BEFORE.lean.txt').read_bytes()
term_packet = BASE/term['packet']
assert raws[term['module']] == (term_packet/'IMPORTS.lean.txt').read_bytes() + before_term + (term_packet/'APPEND.lean.txt').read_bytes()
assert raws[term['module']][208:208 + 19079] == before_term
assert not (ROOT/seeds['source_path']).exists()
seeds_packet = BASE/seeds['packet']
base_packet = BASE/seeds['base_packet']
packet_files(base_packet, seeds['base_manifest_sha256'])
seed_base = verify(base_packet/seeds['base_source'], seeds['base_raw_sha256'])
assert len(seed_base) == 17283 and raws[seeds['module']] == (seeds_packet/'IMPORTS.lean.txt').read_bytes() + seed_base + (seeds_packet/'APPEND.lean.txt').read_bytes()
assert raws[seeds['module']][75:75 + 17283] == seed_base
for name, digest in json.loads((seeds_packet/'CURRENT-BASE-PINS.json').read_text()).items():
    verify(ROOT/name, digest)
rebase = json.loads((seeds_packet/'REBASE.json').read_text())
old_dispatch = BASE/rebase['original_packet']
packet_files(old_dispatch, rebase['original_manifest_sha256'])
for name in rebase['dispatch_source_files_byte_exact']:
    assert (old_dispatch/name).read_bytes() == (seeds_packet/name).read_bytes()
assert len(re.findall(rb'^private theorem ', (term_packet/'APPEND.lean.txt').read_bytes(), re.M)) == 1
assert len(re.findall(rb'^private theorem ', raws[seeds['module']], re.M)) == 2
assert not re.findall(rb'^private theorem ', (seeds_packet/'APPEND.lean.txt').read_bytes(), re.M)

# Recompute the complete two-output dependency graph from actual source text.
normal = {p.stem: p for p in (ROOT/'lean/MicroCFTA').glob('*.lean')}
active, seen, order, graph = [], set(), [], {}


def visit(name):
    assert name not in active, name
    if name in seen:
        return
    active.append(name)
    data = raws[name].decode() if name in raws else normal[name].read_text()
    graph[name] = re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$', data, re.M)
    for dependency in graph[name]:
        visit(dependency)
    active.pop()
    seen.add(name)
    order.append(name)


for name in stage['compile_order']:
    visit(name)
topology = json.loads((CONTROL/'TOPOLOGICAL-ORDER.json').read_text())
assert graph == topology['direct_imports'] and order == topology['full_transitive_order']
assert len(order) == 2542 and len(seen-set(raws)) == 2540
assert [n for n in order if n in raws] == stage['compile_order']
audit_path = ROOT/'lean/MicroCFTA/Audit.lean'
old_audit = verify(audit_path, {'sha256': stage['old_audit_sha256'], 'bytes': 435489})
assert old_audit == (CONTROL/'AUDIT-BEFORE.lean.txt').read_bytes()
imports = verify(CONTROL/'IMPORTS.lean.txt', stage['audit_import_prefix_sha256'])
probes = verify(CONTROL/'PUBLIC-PROBES.lean.txt', stage['public_probes_sha256'])
assert len(imports) == 66 and imports == b'import MicroCFTA.SourcePruningEnumerationSharedIncomingQuerySeeds\n'
assert imports not in old_audit and probes == b''.join((BASE/c['packet']/c['probe']).read_bytes() for c in components)
assert len(re.findall(rb'^#print axioms ', probes, re.M)) == 3
new_audit = imports + old_audit + b'\n' + probes
assert SHA(new_audit) == stage['staged_audit_sha256'] and len(new_audit) == stage['staged_audit_bytes'] == 435886
assert new_audit[66:66 + 435489] == old_audit
assert len(re.findall(rb'^import ', old_audit, re.M)) == 5283 and len(re.findall(rb'^import ', new_audit, re.M)) == 5284
assert len(re.findall(rb'^#print axioms ', old_audit, re.M)) == 735 and len(re.findall(rb'^#print axioms ', new_audit, re.M)) == 738
for component in components:
    for qname in component['public_qnames']:
        assert ('#print axioms ' + qname).encode() not in old_audit
expected = json.loads((CONTROL/'EXPECTED-NORMAL-SOURCE-PINS.json').read_text())
assert SHA((CONTROL/'EXPECTED-NORMAL-SOURCE-PINS.json').read_bytes()) == stage['expected_normal_source_pins_sha256']
assert len(expected) == 6288
assert set(stage['exact_Source_write_paths']) == {term['source_path'], seeds['source_path'], 'lean/MicroCFTA/Audit.lean'}
assert set(stage['baseline_overrides']) == {term['source_path'], 'lean/MicroCFTA/Audit.lean'}
assert stage['old_other_Source_files_byte_exact'] == 6281 and stage['new_modules'] == 1
snapshots = {ROOT/term['old_snapshot']: before_term, ROOT/stage['baseline_overrides']['lean/MicroCFTA/Audit.lean']: old_audit}
assert all(not path.exists() for path in snapshots)
assert all(not (WORK/name).exists() for name in ['IMPORTS.lean.txt', 'PUBLIC-PROBES.lean.txt', 'NORMAL-SOURCE-PINS.json'])
assert stage['baseline_overrides'][term['source_path']] == term['old_snapshot']
for name, record in {**baseline['sources'], **baseline['toolchain']}.items():
    expected_digest = SHA(raws[term['module']]) if name == term['source_path'] else SHA(new_audit) if name == 'lean/MicroCFTA/Audit.lean' else record['sha256']
    assert expected[name] == expected_digest
assert expected[seeds['source_path']] == SHA(raws[seeds['module']])
bound.add(Path(__file__))
preflight_pins = {str(path.relative_to(ROOT)): SHA(path.read_bytes()) for path in bound}
for name, digest in preflight_pins.items():
    assert SHA((ROOT/name).read_bytes()) == digest, name

# Only Root executes the following three normal Source writes after all gates pass.
for path, data in snapshots.items():
    path.write_bytes(data)
for component in components:
    (ROOT/component['source_path']).write_bytes(raws[component['module']])
audit_path.write_bytes(new_audit)
assert len(list((ROOT/'lean/MicroCFTA').glob('*.lean'))) == 6284
for name, digest in expected.items():
    assert SHA((ROOT/name).read_bytes()) == digest, name
for name, digest in preflight_pins.items():
    assert SHA((ROOT/stage['baseline_overrides'].get(name, name)).read_bytes()) == digest, name
for name in ['IMPORTS.lean.txt', 'PUBLIC-PROBES.lean.txt']:
    (WORK/name).write_bytes((CONTROL/name).read_bytes())
(WORK/'NORMAL-SOURCE-PINS.json').write_bytes((CONTROL/'EXPECTED-NORMAL-SOURCE-PINS.json').read_bytes())
actual_stage = dict(stage)
actual_stage.update(status='SOURCE_NORMAL_STAGING_COMPLETED', staged_at=datetime.datetime.now().astimezone().isoformat(),
    actual_private_sessions=[99821, 69321, 32584], selected_private_sessions=[99821, 32584],
    incoming_prerequisite_session=69321, normal_Source_changed=True, published=False,
    actual_Source_files=6284, actual_audit_imports=5284, actual_audit_reports=738,
    prior_source_checkpoint_push_verified=True,
    normal_source_pins_sha256=SHA((WORK/'NORMAL-SOURCE-PINS.json').read_bytes()))
(WORK/'SOURCES-NORMAL-STAGING.json').write_text(json.dumps(actual_stage, indent=2) + '\n')
print(json.dumps(actual_stage, indent=2))
