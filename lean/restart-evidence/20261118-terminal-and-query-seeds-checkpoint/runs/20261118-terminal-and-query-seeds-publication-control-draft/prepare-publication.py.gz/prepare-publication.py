from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root/'lean/restart-evidence'
control = base/'20261118-terminal-and-query-seeds-publication-control-draft'
stage_control = base/'20261118-terminal-and-query-seeds-staging-control-draft'
work = base/'20261118-terminal-query-resources-work'
runtime = base/'20261118-terminal-and-query-seeds-publication'
prior_work = base/'20261118-ordered-fold-query-resources-work'
prior_run = base/'20261118-fold-query-resources-publication'
prior_archive = base/'20261118-fold-query-resources-checkpoint'
source_commit = '04e2eb843816747cab7ec59a150d0897619274b4'
assert Path(__file__).resolve().parent == work.resolve()
assert Path(__file__).read_bytes() == (control/'prepare-publication.py').read_bytes()
assert not runtime.exists(), 'Preserve every previous runtime.'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
bound = set()


def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256']if isinstance(record,dict)else record),str(path)
    if isinstance(record,dict)and 'bytes' in record:
        assert len(data) == record['bytes'],str(path)
    bound.add(path)
    return data


def records(value):
    if isinstance(value,list):
        return [(entry.get('file',entry.get('path')),entry)for entry in value]
    if 'files' in value:
        return records(value['files'])
    if 'pins' in value:
        return records(value['pins'])
    return value.items()


for name,record in records(read(control/'MANIFEST.json')['files']):
    verify(control/name,record)
bound.add(control/'MANIFEST.json')
for name,record in records(read(control/'ACTUAL-INPUT-PINS.json')):
    verify(root/name,record)
for name,record in records(read(stage_control/'MANIFEST.json')['files']):
    verify(stage_control/name,record)
bound.add(stage_control/'MANIFEST.json')
stage_bytes = (work/'SOURCES-NORMAL-STAGING.json').read_bytes()
assert stage_bytes == (control/'EXPECTED-STAGE.json').read_bytes()
stage = json.loads(stage_bytes)
assert stage['status'] == 'SOURCE_NORMAL_STAGING_COMPLETED'
assert stage['source_baseline'] == source_commit and stage['normal_Source_changed'] and not stage['published']
assert (stage['source_files'],stage['audit_imports'],stage['audit_reports'],stage['independent_reports']) == (6284,5284,738,333)
assert (stage['fresh_reports'],stage['inherited_reports'],stage['combined_reports']) == (3,529,532)
assert stage['new_public_theorems'] == stage['new_private_helpers_transitive'] == 3
assert stage['new_Prop_definitions'] == stage['definition_checks'] == stage['explicit_private_reports'] == 0
assert stage['resource_owner_reports_inherited'] == 264 and stage['fresh_credit_for_old_owner_theorems'] == 0
bound.add(work/'SOURCES-NORMAL-STAGING.json')
stage_actual = read(work/'STAGING-ACTUAL-RUN.json')
assert stage_actual['actual_session'] == 25478 and stage_actual['actual_terminal'] and stage_actual['actual_terminal_exit'] == 0
assert stage_actual['control_manifest_sha256'] == sha((stage_control/'MANIFEST.json').read_bytes())
assert stage_actual['script_sha256'] == sha((stage_control/'stage-normal-sources.py').read_bytes())
assert stage_actual['normal_source_pins_sha256'] == stage['normal_source_pins_sha256']
assert stage_actual['exact_Source_write_paths'] == stage['exact_Source_write_paths'] and stage_actual['git_index_empty']
bound.add(work/'STAGING-ACTUAL-RUN.json')
overrides = stage['baseline_overrides']
terminal_source = 'lean/MicroCFTA/SourcePruningEnumerationSharedTerminalQueryEvents.lean'
fold_source = 'lean/MicroCFTA/SourcePruningEnumerationSharedTerminalFoldQueryEvents.lean'
assert set(overrides) == {terminal_source,'lean/MicroCFTA/Audit.lean'}


def historical(name, record):
    digest = record['sha256']if isinstance(record,dict)else record
    for path in [root/name,root/overrides.get(name,name)]:
        if path.is_file()and sha(path.read_bytes()) == digest:
            return verify(path,record)
    raise AssertionError(name)


# This old Fold pin belongs only to the terminal candidate's frozen history.
old_fold = root/'lean/restart-evidence/20261118-ordered-fold-query-resources-work/TerminalFoldQueryEvents-BEFORE.lean.txt'
assert len(old_fold.read_bytes()) == 15875 and sha(old_fold.read_bytes()) == 'a84aa92503c88ee0b320d70a41cb31419e43ed81917bc9c0e1eb5065bb0b4290'
assert sha((root/fold_source).read_bytes()) == '72097a29507a6928afd927619a75f0182253353e2980036d1bea7c38011bc2c5'
chosen = {}
all_checks = stage['private_subsets']+stage['prerequisite_checks']
assert [(entry['actual_session'],entry['expected_reports'],entry['pins'])for entry in all_checks] == [(99821,1,8521),(32584,2,8600),(69321,1,8527)]
for entry in all_checks:
    private_control = base/entry['control']
    verify(private_control/'MANIFEST.json',entry['control_manifest_sha256'])
    for name,record in records(read(private_control/'MANIFEST.json')['files']):
        verify(private_control/name,record)
    selection = read(private_control/'SELECTION.json')
    run = base/entry['runtime']
    receipt_path = root/entry['verified_receipt']
    receipt = read(receipt_path)
    actual_path = root/entry['actual_receipt']
    actual = read(actual_path)
    assert receipt['actual_session'] == actual['actual_session'] == entry['actual_session']
    assert receipt['actual_terminal'] and actual['actual_terminal']
    assert receipt['actual_terminal_exit'] == actual['actual_terminal_exit'] == 0
    assert receipt['runtime'] == actual['runtime'] == run.name
    checked = json.loads(verify(run/'checked.json',receipt['checked_sha256']))
    assert checked == json.loads(verify(run/'results.json',receipt['results_sha256']))
    assert checked['checks'] == receipt['checks'] and checked['proof_credit'] and checked['source_pins_unchanged']
    assert len(checked['checks']) == 1
    assert all(check['exit'] == 0 and not check['diagnostics'] and not check['sorryAx'] and not check['nonstandard_axioms']
        and check['total_axiom_reports'] == check['axiom_groups'] == entry['expected_reports']
        and check['axiom_free_reports'] == check['declaration_checks'] == 0 for check in checked['checks'])
    assert checked['limits'] == {'memory.max':'8589934592','memory.high':'8589934592','memory.swap.max':'0'}
    pins = json.loads(verify(run/'source-pins.json',receipt['source_pins_sha256']))
    assert len(pins) == receipt['pins_independently_reverified'] == entry['pins']
    for name,record in pins.items():
        historical(name,record)
    bound.update([receipt_path,actual_path,run/(checked['checks'][0]['name']+'.txt')])
    if entry['name'] != 'incomingPrerequisite':
        for component in selection['components']:
            assert component['module'] not in chosen
            chosen[component['module']] = component
assert len(chosen) == 2 and sum(entry['fresh_public_reports']for entry in all_checks) == 3
# Retain failed compiler runs without credit. A failed preflight is not a compiler run.
for entry in stage['rejected_checks']:
    receipt_path = root/entry['receipt']
    receipt = read(receipt_path)
    assert receipt['actual_session'] == entry['actual_session'] and receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 1
    run = base/entry['runtime']
    result = json.loads(verify(run/'results.json',receipt['results_sha256']))
    assert result['checks'] == receipt['checks'] and not result['proof_credit'] and result['credited_public_reports'] == 0
    assert not (run/'checked.json').exists()
    assert len(result['checks']) == 1 and result['checks'][0]['diagnostics'] == entry['diagnostics']
    assert result['checks'][0]['sorryAx'] == entry['sorryAx']
    pins = json.loads(verify(run/'source-pins.json',receipt['source_pins_sha256']))
    assert len(pins) == receipt['pins_independently_reverified'] == entry['pins']
    for name,record in pins.items():
        historical(name,record)
    bound.update([receipt_path,run/(result['checks'][0]['name']+'.txt')])
preflight_path = root/stage['rejected_preparer_receipt']
preflight = read(preflight_path)
assert preflight['actual_terminal'] and preflight['actual_terminal_exit'] == 1
assert not preflight['compiler_started'] and not preflight['runtime_or_tmp_created']
assert preflight['proof_credit'] == 0 and preflight['original_control_manifest_sha256'] == '6b65d8fca7328ccf7e07b5ed15937bdccdd118560791a93632659f118b78263e'
bound.add(preflight_path)
original_controller = base/'20261118-incoming-query-seeds-repair-check-control-draft'
executed_controller = base/'20261118-incoming-query-seeds-repair-topology-control-draft'
verify(original_controller/'MANIFEST.json',preflight['original_control_manifest_sha256'])
verify(executed_controller/'MANIFEST.json','3868b83588528d76b3f55c299aa92c86f8804907335098151f0068b2e5109ec3')
assert (executed_controller/'TOPOLOGICAL-ORDER.json').read_bytes() == (base/'20261118-incoming-query-seeds-check-control-draft/TOPOLOGICAL-ORDER.json').read_bytes()
expected_preparer = (original_controller/'prepare-incoming-seeds-repair-check.py').read_bytes().replace(
    original_controller.name.encode(),executed_controller.name.encode()).replace(
    b'prepare-incoming-seeds-repair-check.py',b'prepare-incoming-seeds-repair-topology-check.py')
assert expected_preparer == (executed_controller/'prepare-incoming-seeds-repair-topology-check.py').read_bytes()
components = stage['components']
assert len(components) == 2 and set(stage['compile_order']) == set(chosen)
baseline_path = root/stage['source_baseline_path']
baseline_wrapper = read(baseline_path)
assert baseline_wrapper['source_commit'] == source_commit and baseline_wrapper['source_files'] == 6283
baseline = {name:record['sha256']for name,record in baseline_wrapper['sources'].items()}
for name,record in {**baseline_wrapper['sources'],**baseline_wrapper['toolchain']}.items():
    historical(name,record)
new_source = components[1]['source_path']
assert new_source not in baseline and components[1]['module'] == 'SourcePruningEnumerationSharedIncomingQuerySeeds'
current = sorted((root/'lean/MicroCFTA').glob('*.lean'))
assert len(current) == 6284 and {str(path.relative_to(root))for path in current} == set(baseline)|{new_source}
assert len(set(baseline)-set(overrides)) == 6281
normal_pins_path = work/'NORMAL-SOURCE-PINS.json'
normal_pins = json.loads(verify(normal_pins_path,stage['normal_source_pins_sha256']))
assert len(normal_pins) == 6288
for name,record in normal_pins.items():
    verify(root/name,record)
push = read(prior_work/'PUSH-VERIFIED.json')
prior_source = read(prior_work/'SOURCE-COMMIT.json')
prior_publication = read(prior_work/'PUBLICATION-VERIFIED.json')
assert push['source_commit'] == prior_source['source_commit'] == source_commit
assert push['checkpoint_commit'] == push['remote_commit'] == 'e5fc00c2a9ccf70322b4f0a2780e1293ecb2ead9'
assert push['actual_push_terminal'] and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal'] and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
assert prior_publication['actual_session'] == prior_source['publication_actual_session'] == 72663
assert prior_publication['actual_terminal'] and prior_publication['actual_terminal_exit'] == 0
assert prior_publication['combined_reports'] == 529 and prior_publication['resource_reports_inherited'] == 264
verify(prior_archive/'manifest.json',push['archive_manifest_sha256'])
subprocess.run(['git','merge-base','--is-ancestor',push['checkpoint_commit'],'HEAD'],cwd=root,check=True)
prior_checked = read(prior_run/'checked.json')
assert prior_checked['all_five_gates_passed'] and prior_checked['source_pins_unchanged']
assert (prior_checked['source_files'],prior_checked['independent_reports'],prior_checked['resource_and_component_probes']) == (6283,330,529)
for name,record in read(prior_run/'source-pins.json').items():
    historical(name,record)
bound.update([prior_work/'PUSH-VERIFIED.json',prior_work/'SOURCE-COMMIT.json',prior_work/'PUBLICATION-VERIFIED.json',
    prior_work/'PUBLICATION-ACTUAL-RUN.json',prior_run/'checked.json',prior_run/'source-pins.json',prior_run/'IndependentProbes.lean',
    prior_archive/'manifest.json',prior_archive/'verify.py',prior_archive/'archived-inputs.json'])
raw_sources = {}
public = b''
private_count = 0
for item in components:
    original = chosen[item['module']]
    for key in ['module','kind','packet','manifest_sha256','source','raw_sha256','raw_bytes','probe','probe_sha256',
            'public_qnames','expected_axiom_reports','expected_declaration_checks']:
        assert item[key] == original[key],(item['module'],key)
    packet = base/item['packet']
    verify(packet/'MANIFEST.json',item['manifest_sha256'])
    for name,record in records(read(packet/'MANIFEST.json')['files']):
        verify(packet/name,record)
    for filename in ['SOURCE-PINS.json','ADDITIONAL-SOURCE-PINS.json','DEPENDENCY-PINS.json']:
        if (packet/filename).exists():
            for name,record in records(read(packet/filename)):
                digest = record['sha256']if isinstance(record,dict)else record
                if item['module'] == 'SourcePruningEnumerationSharedTerminalQueryEvents' and name == fold_source and digest == sha(old_fold.read_bytes()):
                    verify(old_fold,record)
                else:
                    historical(name,record)
    raw = verify(root/item['source_path'],{'sha256':item['raw_sha256'],'bytes':item['raw_bytes']})
    assert raw == (packet/item['source']).read_bytes()
    if item['module'] == 'SourcePruningEnumerationSharedTerminalQueryEvents':
        old = verify(root/item['old_snapshot'],{'sha256':item['owner_sha256'],'bytes':19079})
        imports = verify(packet/item['imports'],item['imports_sha256'])
        declarations = verify(packet/item['append'],item['append_sha256'])
        assert len(imports) == 208 and raw == imports+old+declarations
    else:
        parent = base/item['base_packet']
        verify(parent/'MANIFEST.json',item['base_manifest_sha256'])
        for name,record in records(read(parent/'MANIFEST.json')['files']):
            verify(parent/name,record)
        incoming = verify(parent/item['base_source'],{'sha256':item['base_raw_sha256'],'bytes':17283})
        imports = verify(packet/item['imports'],item['imports_sha256'])
        appended = verify(packet/item['append'],item['append_sha256'])
        assert len(imports) == 75 and raw == imports+incoming+appended
        declarations = raw
        prerequisite_run = base/stage['prerequisite_checks'][0]['runtime']
        assert (prerequisite_run/'source/MicroCFTA'/item['source']).read_bytes() == incoming+b'\n'+(parent/'PROBES.lean.txt').read_bytes()
    assert not re.search(rb'set_option\s+(maxHeartbeats|maxRecDepth|warningAsError|linter\.)',declarations)
    assert not re.findall(rb'^(?:private )?(?:def|inductive|structure) ',declarations,re.M)
    private_count += len(re.findall(rb'^private theorem ',declarations,re.M))
    for header in item['all_headers']:
        data = verify(root/header['file'],header['sha256'])
        full = data.rstrip()
        assert raw.count(full) == 1
        assert raw[raw.index(full)+len(full):].lstrip().startswith(b':= by')
    assert b'#print axioms ' not in raw and b'#check ' not in raw
    probe = verify(packet/item['probe'],item['probe_sha256'])
    assert re.findall(r'^#print axioms (\S+)',probe.decode(),re.M) == item['public_qnames']
    assert probe.count(b'#print axioms ') == item['expected_axiom_reports'] and b'#check ' not in probe
    subset = next(entry for entry in stage['private_subsets']if entry['name'] == ('terminal'if item['module']=='SourcePruningEnumerationSharedTerminalQueryEvents'else 'combinedSeeds'))
    fixture = base/subset['runtime']/'source/MicroCFTA'/item['source']
    assert fixture.read_bytes() == raw+b'\n'+probe
    bound.add(fixture)
    raw_sources[item['module']] = raw
    public += probe
assert private_count == 3 and public.count(b'#print axioms ') == 3
assert public == (control/'EXPECTED-PUBLIC-PROBES.lean.txt').read_bytes()
old_audit = verify(root/overrides['lean/MicroCFTA/Audit.lean'],{'sha256':stage['old_audit_sha256'],'bytes':435489})
audit_imports = (stage_control/'IMPORTS.lean.txt').read_bytes()
assert len(audit_imports) == 66 and sha(audit_imports) == stage['audit_import_prefix_sha256']
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes() == audit_imports+old_audit+b'\n'+public
assert old_audit.count(b'#print axioms ') == 735
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes().count(b'#print axioms ') == 738
assert sum(line.startswith(b'import ')for line in (root/'lean/MicroCFTA/Audit.lean').read_bytes().splitlines()) == 5284
prior_independent = (prior_run/'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 330
resource_owner = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = sha((root/resource_owner).read_bytes())
assert owner_sha == baseline[resource_owner]
normal_objects = root/'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()
edges = {}
active = set()
visited = set()
ordered = []


def walk(module):
    if module in visited:
        return
    assert module not in active,('import cycle',module)
    active.add(module)
    data = (root/'lean/MicroCFTA'/(module+'.lean')).read_text()
    edges[module] = re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$',data,re.M)
    if module not in chosen:
        assert (normal_objects/(module+'.olean')).is_file(),module
    for child in edges[module]:
        walk(child)
    active.remove(module)
    visited.add(module)
    ordered.append(module)


for module in stage['compile_order']:
    walk(module)
dag = read(control/'TOPOLOGICAL-ORDER.json')
assert edges == dag['direct_imports'] and ordered == dag['full_transitive_order']
assert [module for module in ordered if module in chosen] == stage['compile_order']
for name in ['strict-bind.py.txt','publication-driver.py.txt','shadow-compile.py.txt']:
    ast.parse((control/name).read_text())
# Root materializes a fresh publication namespace after every read-only gate passes.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-terminal-query-seeds-publication-'))
(objects/'MicroCFTA').mkdir()
for obj in normal_objects.glob('*.olean'):
    if obj.stem not in chosen:
        (objects/'MicroCFTA'/obj.name).symlink_to(obj)
for module in chosen:
    assert not (objects/'MicroCFTA'/(module+'.olean')).exists()
(runtime/'objects.json').write_text(json.dumps({'path':str(objects)},indent=2)+'\n')
for module,raw in raw_sources.items():
    fixture = runtime/'source/MicroCFTA'/(module+'.lean')
    fixture.parent.mkdir(parents=True,exist_ok=True)
    fixture.write_bytes(raw)
    bound.add(fixture)
fresh_imports = ''.join('import MicroCFTA.'+module+'\n'for module in stage['compile_order']).encode()
(runtime/'FreshPublicProbes.lean').write_bytes(fresh_imports+public)
independent_imports = b''.join(('import MicroCFTA.'+module+'\n').encode()for module in stage['compile_order']
    if ('import MicroCFTA.'+module+'\n').encode()not in prior_independent.splitlines(keepends=True))
(runtime/'IndependentProbes.lean').write_bytes(independent_imports+prior_independent+b'\n'+public)
for src,dst in [('strict-bind.py.txt','strict-new-and-bind.py'),('publication-driver.py.txt','check.py'),('shadow-compile.py.txt','shadow-compile.py')]:
    (runtime/dst).write_bytes((control/src).read_bytes())
(runtime/'REPORT-BASE.json').write_bytes((control/'REPORT-BASE.json').read_bytes())
inheritance = {'compile_order':stage['compile_order'],'definition_names':[],'prior_checkpoint':push['checkpoint_commit'],
    'prior_archive_manifest_sha256':push['archive_manifest_sha256'],'prior_checked_sha256':sha((prior_run/'checked.json').read_bytes()),
    'prior_pins_sha256':sha((prior_run/'source-pins.json').read_bytes()),'stage_sha256':sha(stage_bytes),
    'baseline_sha256':sha(baseline_path.read_bytes()),'baseline_path':str(baseline_path.relative_to(root)),
    'baseline_overrides':overrides,'override_digests':{name:sha((root/path).read_bytes())for name,path in overrides.items()},
    'inherited_reports':529,'fresh_reports':3,'combined_reports':532,'resource_owner_sha256':owner_sha,
    'resource_owner_reports_inherited':264,'owner_preflight_reports_fresh_this_batch':0,'new_private_helpers':3,
    'Prop_declaration_checks':0,'Prop_axiom_credit':0,'actual_private_sessions':[99821,69321,32584],
    'incoming_recheck_not_double_counted':True,'fresh_owner_theorem_credit':0,'cache_data_copied':False}
(runtime/'INHERITANCE-SELECTION.json').write_text(json.dumps(inheritance,indent=2)+'\n')
bound.update([Path(__file__),baseline_path,control/'TOPOLOGICAL-ORDER.json'])
bound.update(current)
bound.update(path for path in runtime.iterdir()if path.is_file())
(runtime/'source-pins.json').write_text(json.dumps({str(path.relative_to(root)):sha(path.read_bytes())for path in sorted(bound)},indent=2,sort_keys=True)+'\n')
print(json.dumps({'runtime':str(runtime),'gates':5,'fresh_modules':2,'fresh_reports':3,'inherited_reports':529,
    'combined_reports':532,'source_files':6284,'audit_imports':5284,'audit_reports':738,'independent_reports':333,'normal_Source_changed':False}))
