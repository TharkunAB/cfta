from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root/'lean/restart-evidence'
control = base/'20261118-terminal-and-query-seeds-publication-control-draft'
stage_control = base/'20261118-terminal-and-query-seeds-staging-control-draft'
work = base/'20261118-terminal-query-resources-work'
runtime = base/'20261118-terminal-and-query-seeds-publication'
prior_work = base/'20261118-ordered-fold-query-resources-work'
prior_run = base/'20261118-fold-query-resources-publication'
prior_archive = base/'20261118-fold-query-resources-checkpoint'
source_commit = '04e2eb843816747cab7ec59a150d0897619274b4'
assert Path(__file__).resolve().parent == work.resolve()
archive_control = base/'20261118-terminal-and-query-seeds-checkpoint-control-draft'
assert Path(__file__).read_bytes() == (archive_control/'prepare-checkpoint-controls.py').read_bytes()
assert runtime.is_dir(), 'The actual successful publication must exist.'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
bound = set()


def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256']if isinstance(record,dict)else record),str(path)
    if isinstance(record,dict)and 'bytes' in record:
        assert len(data) == record['bytes'],str(path)
    bound.add(path)
    return data


def records(value):
    if isinstance(value,list):
        return [(entry.get('file',entry.get('path')),entry)for entry in value]
    if 'files' in value:
        return records(value['files'])
    if 'pins' in value:
        return records(value['pins'])
    return value.items()


for name,record in records(read(control/'MANIFEST.json')['files']):
    verify(control/name,record)
bound.add(control/'MANIFEST.json')
for name,record in records(read(control/'ACTUAL-INPUT-PINS.json')):
    verify(root/name,record)
for name,record in records(read(stage_control/'MANIFEST.json')['files']):
    verify(stage_control/name,record)
bound.add(stage_control/'MANIFEST.json')
stage_bytes = (work/'SOURCES-NORMAL-STAGING.json').read_bytes()
assert stage_bytes == (control/'EXPECTED-STAGE.json').read_bytes()
stage = json.loads(stage_bytes)
assert stage['status'] == 'SOURCE_NORMAL_STAGING_COMPLETED'
assert stage['source_baseline'] == source_commit and stage['normal_Source_changed'] and not stage['published']
assert (stage['source_files'],stage['audit_imports'],stage['audit_reports'],stage['independent_reports']) == (6284,5284,738,333)
assert (stage['fresh_reports'],stage['inherited_reports'],stage['combined_reports']) == (3,529,532)
assert stage['new_public_theorems'] == stage['new_private_helpers_transitive'] == 3
assert stage['new_Prop_definitions'] == stage['definition_checks'] == stage['explicit_private_reports'] == 0
assert stage['resource_owner_reports_inherited'] == 264 and stage['fresh_credit_for_old_owner_theorems'] == 0
bound.add(work/'SOURCES-NORMAL-STAGING.json')
stage_actual = read(work/'STAGING-ACTUAL-RUN.json')
assert stage_actual['actual_session'] == 25478 and stage_actual['actual_terminal'] and stage_actual['actual_terminal_exit'] == 0
assert stage_actual['control_manifest_sha256'] == sha((stage_control/'MANIFEST.json').read_bytes())
assert stage_actual['script_sha256'] == sha((stage_control/'stage-normal-sources.py').read_bytes())
assert stage_actual['normal_source_pins_sha256'] == stage['normal_source_pins_sha256']
assert stage_actual['exact_Source_write_paths'] == stage['exact_Source_write_paths'] and stage_actual['git_index_empty']
bound.add(work/'STAGING-ACTUAL-RUN.json')
overrides = stage['baseline_overrides']
terminal_source = 'lean/MicroCFTA/SourcePruningEnumerationSharedTerminalQueryEvents.lean'
fold_source = 'lean/MicroCFTA/SourcePruningEnumerationSharedTerminalFoldQueryEvents.lean'
assert set(overrides) == {terminal_source,'lean/MicroCFTA/Audit.lean'}


def historical(name, record):
    digest = record['sha256']if isinstance(record,dict)else record
    for path in [root/name,root/overrides.get(name,name)]:
        if path.is_file()and sha(path.read_bytes()) == digest:
            return verify(path,record)
    raise AssertionError(name)


# This old Fold pin belongs only to the terminal candidate's frozen history.
old_fold = root/'lean/restart-evidence/20261118-ordered-fold-query-resources-work/TerminalFoldQueryEvents-BEFORE.lean.txt'
assert len(old_fold.read_bytes()) == 15875 and sha(old_fold.read_bytes()) == 'a84aa92503c88ee0b320d70a41cb31419e43ed81917bc9c0e1eb5065bb0b4290'
assert sha((root/fold_source).read_bytes()) == '72097a29507a6928afd927619a75f0182253353e2980036d1bea7c38011bc2c5'
chosen = {}
all_checks = stage['private_subsets']+stage['prerequisite_checks']
assert [(entry['actual_session'],entry['expected_reports'],entry['pins'])for entry in all_checks] == [(99821,1,8521),(32584,2,8600),(69321,1,8527)]
for entry in all_checks:
    private_control = base/entry['control']
    verify(private_control/'MANIFEST.json',entry['control_manifest_sha256'])
    for name,record in records(read(private_control/'MANIFEST.json')['files']):
        verify(private_control/name,record)
    selection = read(private_control/'SELECTION.json')
    run = base/entry['runtime']
    receipt_path = root/entry['verified_receipt']
    receipt = read(receipt_path)
    actual_path = root/entry['actual_receipt']
    actual = read(actual_path)
    assert receipt['actual_session'] == actual['actual_session'] == entry['actual_session']
    assert receipt['actual_terminal'] and actual['actual_terminal']
    assert receipt['actual_terminal_exit'] == actual['actual_terminal_exit'] == 0
    assert receipt['runtime'] == actual['runtime'] == run.name
    checked = json.loads(verify(run/'checked.json',receipt['checked_sha256']))
    assert checked == json.loads(verify(run/'results.json',receipt['results_sha256']))
    assert checked['checks'] == receipt['checks'] and checked['proof_credit'] and checked['source_pins_unchanged']
    assert len(checked['checks']) == 1
    assert all(check['exit'] == 0 and not check['diagnostics'] and not check['sorryAx'] and not check['nonstandard_axioms']
        and check['total_axiom_reports'] == check['axiom_groups'] == entry['expected_reports']
        and check['axiom_free_reports'] == check['declaration_checks'] == 0 for check in checked['checks'])
    assert checked['limits'] == {'memory.max':'8589934592','memory.high':'8589934592','memory.swap.max':'0'}
    pins = json.loads(verify(run/'source-pins.json',receipt['source_pins_sha256']))
    assert len(pins) == receipt['pins_independently_reverified'] == entry['pins']
    for name,record in pins.items():
        historical(name,record)
    bound.update([receipt_path,actual_path,run/(checked['checks'][0]['name']+'.txt')])
    if entry['name'] != 'incomingPrerequisite':
        for component in selection['components']:
            assert component['module'] not in chosen
            chosen[component['module']] = component
assert len(chosen) == 2 and sum(entry['fresh_public_reports']for entry in all_checks) == 3
# Retain failed compiler runs without credit. A failed preflight is not a compiler run.
for entry in stage['rejected_checks']:
    receipt_path = root/entry['receipt']
    receipt = read(receipt_path)
    assert receipt['actual_session'] == entry['actual_session'] and receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 1
    run = base/entry['runtime']
    result = json.loads(verify(run/'results.json',receipt['results_sha256']))
    assert result['checks'] == receipt['checks'] and not result['proof_credit'] and result['credited_public_reports'] == 0
    assert not (run/'checked.json').exists()
    assert len(result['checks']) == 1 and result['checks'][0]['diagnostics'] == entry['diagnostics']
    assert result['checks'][0]['sorryAx'] == entry['sorryAx']
    pins = json.loads(verify(run/'source-pins.json',receipt['source_pins_sha256']))
    assert len(pins) == receipt['pins_independently_reverified'] == entry['pins']
    for name,record in pins.items():
        historical(name,record)
    bound.update([receipt_path,run/(result['checks'][0]['name']+'.txt')])
preflight_path = root/stage['rejected_preparer_receipt']
preflight = read(preflight_path)
assert preflight['actual_terminal'] and preflight['actual_terminal_exit'] == 1
assert not preflight['compiler_started'] and not preflight['runtime_or_tmp_created']
assert preflight['proof_credit'] == 0 and preflight['original_control_manifest_sha256'] == '6b65d8fca7328ccf7e07b5ed15937bdccdd118560791a93632659f118b78263e'
bound.add(preflight_path)
original_controller = base/'20261118-incoming-query-seeds-repair-check-control-draft'
executed_controller = base/'20261118-incoming-query-seeds-repair-topology-control-draft'
verify(original_controller/'MANIFEST.json',preflight['original_control_manifest_sha256'])
verify(executed_controller/'MANIFEST.json','3868b83588528d76b3f55c299aa92c86f8804907335098151f0068b2e5109ec3')
assert (executed_controller/'TOPOLOGICAL-ORDER.json').read_bytes() == (base/'20261118-incoming-query-seeds-check-control-draft/TOPOLOGICAL-ORDER.json').read_bytes()
expected_preparer = (original_controller/'prepare-incoming-seeds-repair-check.py').read_bytes().replace(
    original_controller.name.encode(),executed_controller.name.encode()).replace(
    b'prepare-incoming-seeds-repair-check.py',b'prepare-incoming-seeds-repair-topology-check.py')
assert expected_preparer == (executed_controller/'prepare-incoming-seeds-repair-topology-check.py').read_bytes()
components = stage['components']
assert len(components) == 2 and set(stage['compile_order']) == set(chosen)
baseline_path = root/stage['source_baseline_path']
baseline_wrapper = read(baseline_path)
assert baseline_wrapper['source_commit'] == source_commit and baseline_wrapper['source_files'] == 6283
baseline = {name:record['sha256']for name,record in baseline_wrapper['sources'].items()}
for name,record in {**baseline_wrapper['sources'],**baseline_wrapper['toolchain']}.items():
    historical(name,record)
new_source = components[1]['source_path']
assert new_source not in baseline and components[1]['module'] == 'SourcePruningEnumerationSharedIncomingQuerySeeds'
current = sorted((root/'lean/MicroCFTA').glob('*.lean'))
assert len(current) == 6284 and {str(path.relative_to(root))for path in current} == set(baseline)|{new_source}
assert len(set(baseline)-set(overrides)) == 6281
normal_pins_path = work/'NORMAL-SOURCE-PINS.json'
normal_pins = json.loads(verify(normal_pins_path,stage['normal_source_pins_sha256']))
assert len(normal_pins) == 6288
for name,record in normal_pins.items():
    verify(root/name,record)
push = read(prior_work/'PUSH-VERIFIED.json')
prior_source = read(prior_work/'SOURCE-COMMIT.json')
prior_publication = read(prior_work/'PUBLICATION-VERIFIED.json')
assert push['source_commit'] == prior_source['source_commit'] == source_commit
assert push['checkpoint_commit'] == push['remote_commit'] == 'e5fc00c2a9ccf70322b4f0a2780e1293ecb2ead9'
assert push['actual_push_terminal'] and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal'] and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
assert prior_publication['actual_session'] == prior_source['publication_actual_session'] == 72663
assert prior_publication['actual_terminal'] and prior_publication['actual_terminal_exit'] == 0
assert prior_publication['combined_reports'] == 529 and prior_publication['resource_reports_inherited'] == 264
verify(prior_archive/'manifest.json',push['archive_manifest_sha256'])
subprocess.run(['git','merge-base','--is-ancestor',push['checkpoint_commit'],'HEAD'],cwd=root,check=True)
prior_checked = read(prior_run/'checked.json')
assert prior_checked['all_five_gates_passed'] and prior_checked['source_pins_unchanged']
assert (prior_checked['source_files'],prior_checked['independent_reports'],prior_checked['resource_and_component_probes']) == (6283,330,529)
for name,record in read(prior_run/'source-pins.json').items():
    historical(name,record)
bound.update([prior_work/'PUSH-VERIFIED.json',prior_work/'SOURCE-COMMIT.json',prior_work/'PUBLICATION-VERIFIED.json',
    prior_work/'PUBLICATION-ACTUAL-RUN.json',prior_run/'checked.json',prior_run/'source-pins.json',prior_run/'IndependentProbes.lean',
    prior_archive/'manifest.json',prior_archive/'verify.py',prior_archive/'archived-inputs.json'])
raw_sources = {}
public = b''
private_count = 0
for item in components:
    original = chosen[item['module']]
    for key in ['module','kind','packet','manifest_sha256','source','raw_sha256','raw_bytes','probe','probe_sha256',
            'public_qnames','expected_axiom_reports','expected_declaration_checks']:
        assert item[key] == original[key],(item['module'],key)
    packet = base/item['packet']
    verify(packet/'MANIFEST.json',item['manifest_sha256'])
    for name,record in records(read(packet/'MANIFEST.json')['files']):
        verify(packet/name,record)
    for filename in ['SOURCE-PINS.json','ADDITIONAL-SOURCE-PINS.json','DEPENDENCY-PINS.json']:
        if (packet/filename).exists():
            for name,record in records(read(packet/filename)):
                digest = record['sha256']if isinstance(record,dict)else record
                if item['module'] == 'SourcePruningEnumerationSharedTerminalQueryEvents' and name == fold_source and digest == sha(old_fold.read_bytes()):
                    verify(old_fold,record)
                else:
                    historical(name,record)
    raw = verify(root/item['source_path'],{'sha256':item['raw_sha256'],'bytes':item['raw_bytes']})
    assert raw == (packet/item['source']).read_bytes()
    if item['module'] == 'SourcePruningEnumerationSharedTerminalQueryEvents':
        old = verify(root/item['old_snapshot'],{'sha256':item['owner_sha256'],'bytes':19079})
        imports = verify(packet/item['imports'],item['imports_sha256'])
        declarations = verify(packet/item['append'],item['append_sha256'])
        assert len(imports) == 208 and raw == imports+old+declarations
    else:
        parent = base/item['base_packet']
        verify(parent/'MANIFEST.json',item['base_manifest_sha256'])
        for name,record in records(read(parent/'MANIFEST.json')['files']):
            verify(parent/name,record)
        incoming = verify(parent/item['base_source'],{'sha256':item['base_raw_sha256'],'bytes':17283})
        imports = verify(packet/item['imports'],item['imports_sha256'])
        appended = verify(packet/item['append'],item['append_sha256'])
        assert len(imports) == 75 and raw == imports+incoming+appended
        declarations = raw
        prerequisite_run = base/stage['prerequisite_checks'][0]['runtime']
        assert (prerequisite_run/'source/MicroCFTA'/item['source']).read_bytes() == incoming+b'\n'+(parent/'PROBES.lean.txt').read_bytes()
    assert not re.search(rb'set_option\s+(maxHeartbeats|maxRecDepth|warningAsError|linter\.)',declarations)
    assert not re.findall(rb'^(?:private )?(?:def|inductive|structure) ',declarations,re.M)
    private_count += len(re.findall(rb'^private theorem ',declarations,re.M))
    for header in item['all_headers']:
        data = verify(root/header['file'],header['sha256'])
        full = data.rstrip()
        assert raw.count(full) == 1
        assert raw[raw.index(full)+len(full):].lstrip().startswith(b':= by')
    assert b'#print axioms ' not in raw and b'#check ' not in raw
    probe = verify(packet/item['probe'],item['probe_sha256'])
    assert re.findall(r'^#print axioms (\S+)',probe.decode(),re.M) == item['public_qnames']
    assert probe.count(b'#print axioms ') == item['expected_axiom_reports'] and b'#check ' not in probe
    subset = next(entry for entry in stage['private_subsets']if entry['name'] == ('terminal'if item['module']=='SourcePruningEnumerationSharedTerminalQueryEvents'else 'combinedSeeds'))
    fixture = base/subset['runtime']/'source/MicroCFTA'/item['source']
    assert fixture.read_bytes() == raw+b'\n'+probe
    bound.add(fixture)
    raw_sources[item['module']] = raw
    public += probe
assert private_count == 3 and public.count(b'#print axioms ') == 3
assert public == (control/'EXPECTED-PUBLIC-PROBES.lean.txt').read_bytes()
old_audit = verify(root/overrides['lean/MicroCFTA/Audit.lean'],{'sha256':stage['old_audit_sha256'],'bytes':435489})
audit_imports = (stage_control/'IMPORTS.lean.txt').read_bytes()
assert len(audit_imports) == 66 and sha(audit_imports) == stage['audit_import_prefix_sha256']
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes() == audit_imports+old_audit+b'\n'+public
assert old_audit.count(b'#print axioms ') == 735
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes().count(b'#print axioms ') == 738
assert sum(line.startswith(b'import ')for line in (root/'lean/MicroCFTA/Audit.lean').read_bytes().splitlines()) == 5284
prior_independent = (prior_run/'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 330
resource_owner = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = sha((root/resource_owner).read_bytes())
assert owner_sha == baseline[resource_owner]
normal_objects = root/'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()
edges = {}
active = set()
visited = set()
ordered = []


def walk(module):
    if module in visited:
        return
    assert module not in active,('import cycle',module)
    active.add(module)
    data = (root/'lean/MicroCFTA'/(module+'.lean')).read_text()
    edges[module] = re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$',data,re.M)
    if module not in chosen:
        assert (normal_objects/(module+'.olean')).is_file(),module
    for child in edges[module]:
        walk(child)
    active.remove(module)
    visited.add(module)
    ordered.append(module)


for module in stage['compile_order']:
    walk(module)
dag = read(control/'TOPOLOGICAL-ORDER.json')
assert edges == dag['direct_imports'] and ordered == dag['full_transitive_order']
assert [module for module in ordered if module in chosen] == stage['compile_order']
for name in ['strict-bind.py.txt','publication-driver.py.txt','shadow-compile.py.txt']:
    ast.parse((control/name).read_text())

import gzip

archive = base/'20261118-terminal-and-query-seeds-checkpoint'
board_prefix = 'current-board-terminal-and-query-seeds-'
git = lambda *args: subprocess.check_output(['git',*args],cwd=root)
for name,record in records(read(archive_control/'MANIFEST.json')['files']):
    verify(archive_control/name,record)
for name,record in records(read(archive_control/'SOURCE-PINS.json')):
    verify(root/name,record)
bindings = read(archive_control/'prior-bindings.json')
assert bindings['prior_checkpoint'] == push['checkpoint_commit']
source_receipt = read(work/'SOURCE-COMMIT.json')
code = source_receipt['source_commit']
assert source_receipt['parent'] == push['checkpoint_commit']
assert source_receipt['actual_terminal'] and source_receipt['actual_terminal_exit'] == 0
assert source_receipt['private_actual_sessions'] == [99821,69321,32584]
assert source_receipt['selected_private_sessions'] == [99821,32584] and source_receipt['incoming_prerequisite_extra_credit'] == 0
assert source_receipt['publication_actual_session'] == 88140
assert source_receipt['all_FIRST_headers_checked_by_full_body']
assert source_receipt['rejected_sessions'] == [23666,54752] and source_receipt['rejected_proof_credit'] == 0
assert not source_receipt['joint_finite_completion_proved'] and not source_receipt['haskell_changed']
assert git('rev-parse','HEAD').decode().strip() == code
assert git('rev-parse',code+'^').decode().strip() == push['checkpoint_commit']
assert git('branch','--show-current').decode().strip() == 'formalize'
assert not git('status','--porcelain','--untracked-files=no')
changed = {item['source_path']for item in components}|{'lean/MicroCFTA/Audit.lean'}
assert len(changed) == 3
assert set(source_receipt['files']) == set(git('diff','--name-only',push['checkpoint_commit'],code).decode().splitlines()) == changed
for name in changed:
    assert git('show',code+':'+name) == (root/name).read_bytes(),name
    if name in overrides:
        assert git('show',push['checkpoint_commit']+':'+name) == (root/overrides[name]).read_bytes(),name
    else:
        assert name not in baseline and not git('ls-tree','--name-only',push['checkpoint_commit'],'--',name)
# All three root documents must match committed bytes before any archive write.
for name in ['NEXT-PROMPT.md','HANDOFF.md','FINDINGS.md']:
    assert (root/name).read_bytes() == git('show',code+':'+name),name
report = read(runtime/'checked.json')
publication = read(work/'PUBLICATION-VERIFIED.json')
actual = read(work/'PUBLICATION-ACTUAL-RUN.json')
assert publication['actual_session'] == actual['actual_session'] == 88140
assert publication['actual_terminal'] and publication['actual_terminal_exit'] == 0
assert actual['actual_terminal'] and actual['actual_terminal_exit'] == 0
assert actual['preparer_actual_tool_chunk'] == '7aac8b' and actual['preparer_terminal_exit'] == 0
assert 'preparer_actual_session' not in actual
assert publication['runtime'] == actual['runtime'] == runtime.name
assert publication['checks'] == report['checks']
assert [check['total_axiom_reports']for check in report['checks']] == [738,3,333,738,738]
assert [(check['axiom_groups'],check['axiom_free_reports'])for check in report['checks']] == [(732,6),(3,0),(330,3),(732,6),(732,6)]
assert all(check['exit'] == 0 and not check['diagnostics'] and not check['sorryAx']
    and not check['nonstandard_axioms'] and check['declaration_checks'] == 0 for check in report['checks'])
assert report['all_five_gates_passed'] and report['source_pins_unchanged']
assert (report['source_files'],report['direct_audit_imports'],report['individual_reports'],report['independent_reports']) == (6284,5284,738,333)
assert (report['fresh_reports'],report['inherited_reports'],report['combined_reports']) == (3,529,532)
assert (report['new_public_theorems'],report['new_private_theorems'],report['new_theorem_declarations']) == (3,3,6)
assert report['new_prop_definitions'] == report['new_definition_declaration_checks'] == 0
assert report['resource_owner_reports_inherited'] == 264 and report['owner_preflight_reports_fresh_this_batch'] == 0
assert report['audited_theorems'] == publication['audited_theorems'] == source_receipt['audited_theorems'] == 100233
assert report['actual_terminal_query_event_resources_checked'] and report['actual_incoming_source_Seeds_transition_checked']
assert report['actual_dispatch_source_Seeds_transition_checked'] and report['incoming_prerequisite_rebuilt_not_double_counted']
assert report['all_original_supplied_fuels_and_endpoints_retained']
for field in ['all_original_eager_worker_query_admissions_proved','original_eager_worker_all_calls_Seeds_propagation_proved',
        'native_inhabitance_proved','actual_source_type_marker_role_preservation_proved','guard_truth_proved','joint_finite_completion_proved','haskell_changed']:
    assert not report[field],field
public_pins = read(runtime/'source-pins.json')
for name,record in public_pins.items():
    verify(root/name,record)
assert len(public_pins) == publication['pins_independently_reverified'] == 8803
assert sha((runtime/'source-pins.json').read_bytes()) == publication['source_pins_sha256']
assert sha((runtime/'checked.json').read_bytes()) == publication['checked_sha256']
assert sha((runtime/'results.json').read_bytes()) == publication['results_sha256']
assert read(runtime/'results.json') == report
source_pins = {name:digest for name,digest in public_pins.items()if name.startswith('lean/MicroCFTA/')and name.endswith('.lean')}
assert len(source_pins) == 6284
# Bind only the Source commit control that Root actually executed.
provenance = read(work/'SOURCE-COMMIT-ACTUAL-RUN.json')
assert provenance['source_commit'] == code
assert provenance['actual_terminal'] and provenance['actual_terminal_exit'] == 0
assert provenance['parent'] == push['checkpoint_commit']
commit_control = base/provenance['control']
assert commit_control.name == '20261118-terminal-and-query-seeds-source-commit-control-draft'
verify(commit_control/'MANIFEST.json','6eb230cc88a7cf223f94f211c288c4be7a2529e5d53216f21e918b7b2bf66c9a')
for name,record in records(read(commit_control/'MANIFEST.json')['files']):
    verify(commit_control/name,record)
for name,record in records(read(commit_control/'SOURCE-PINS.json')):
    verify(root/name,record)
assert (work/'commit-source.py').read_bytes() == (commit_control/'commit-source.py').read_bytes()
assert provenance['control_manifest_sha256'] == sha((commit_control/'MANIFEST.json').read_bytes())
assert provenance['script_sha256'] == sha((work/'commit-source.py').read_bytes())
assert provenance['actual_session'] == 68342 and provenance['source_payload_files'] == 3
assert provenance['final_publication_receipts_bound_before_control_freeze']
assert not provenance['root_documents_or_checkpoint_committed']
# Bind the committed old archive. Never select or recursively copy it.
for name,field in [('manifest.json','prior_manifest_sha256'),('checkpoint.json','prior_checkpoint_json_sha256')]:
    data = (prior_archive/name).read_bytes()
    assert sha(data) == bindings[field]
    assert git('show',push['checkpoint_commit']+':'+str((prior_archive/name).relative_to(root))) == data
prior_checkpoint_data = read(prior_archive/'checkpoint.json')
assert prior_checkpoint_data['checked_code'] == bindings['prior_source_commit'] == source_commit
assert prior_checkpoint_data['resource_and_component_probes'] == 529
old_pins = json.loads(gzip.decompress((prior_archive/'source-pins.json.gz').read_bytes()))
assert baseline == {name:digest for name,digest in old_pins.items()if name.startswith('lean/MicroCFTA/')and name.endswith('.lean')}
for name,record in old_pins.items():
    historical(name,record)
for name in ['shell.nix','lean/lean-toolchain','lean/lakefile.toml','lean/lake-manifest.json']:
    assert old_pins[name] == public_pins[name]
request = read(work/(board_prefix+'request.json'))
canonical = read(work/(board_prefix+'canonical.json'))
assert canonical['verified']
post = canonical.get('post',canonical)
assert post['id'] == request['request_id'] and type(post['sequence']) is int and post['sequence'] > 0
for key,expected in [('author',request['username']),('thread_id',request['thread_id']),('post_type',request['post_type']),
        ('content',request['content']),('metadata',request['metadata'])]:
    assert post[key] == expected,key
assert post['metadata']['source'] == code
cleanup = read(work/'COMBINED-TMP-CLEANUP.json')
assert cleanup['all_targets_removed'] and cleanup['unknown_tmp_entries_preserved'] and cleanup['no_cache_data_copied']
actual_runs = [(23666,'20261118-terminal-query-resources-check'),(99821,'20261118-terminal-query-resources-repair-check'),
    (54752,'20261118-incoming-query-seeds-check'),(69321,'20261118-incoming-query-seeds-repair-check'),
    (32584,'20261118-dispatch-query-seeds-check'),(88140,runtime.name)]
assert len(cleanup['runs']) == cleanup['owned_terminal_directories'] == 6
paths = []
cumulative = 6582141085
for entry,(session,name) in zip(cleanup['runs'],actual_runs):
    assert entry['actual_session'] == session and entry['runtime'] == name
    assert entry['path'] == read(base/name/'objects.json')['path']
    assert entry['owned_terminal_only'] and entry['normal_cache_preserved'] and entry['unknown_tmp_entries_preserved']
    assert entry['all_targets_removed'] and entry['no_cache_data_copied']
    assert not entry['live_process_references'] and not entry['process_scan_errors']
    assert not Path(entry['path']).exists() and not Path(entry['path']).is_symlink()
    assert entry['prior_cumulative_removed_bytes'] == cumulative
    cumulative += entry['regular_bytes_removed']
    assert entry['cumulative_removed_bytes'] == cumulative
    paths.append(entry['path'])
assert len(set(paths)) == 6
assert cleanup['regular_bytes_removed_this_batch'] == sum(entry['regular_bytes_removed']for entry in cleanup['runs']) == 13183248
assert cleanup['symlinks_removed_this_batch'] == sum(entry['symlinks_removed']for entry in cleanup['runs']) == 37899
assert cumulative == cleanup['cumulative_removed_bytes'] == 6595324333
assert cleanup['normal_cache_targets'] == 6318
assert cleanup['normal_target_stat_sha256'] == cleanup['runs'][-1]['normal_target_stat_sha256'] == 'd35d96966099003934a20f67a4a471e501af3e69e8c5b4afbfb2f3a1179c39e5'
start = read(work/'START.json')
assert start['source_commit'] == source_commit and start['full_goal_remains_open']
assert start['expected_public_reports'] == 1 and start['new_private_helpers'] == 1
scope_update = read(work/'BATCH-SCOPE-UPDATE.json')
assert scope_update['original_START_preserved'] and scope_update['distinct_verified_public_theorems'] == 3
assert scope_update['new_private_helpers_transitive'] == 3 and scope_update['normal_publication_combined_reports'] == 532
combined_private = read(work/'COMBINED-PRIVATE-VERIFIED.json')
assert [entry['actual_session']for entry in combined_private['subsets']] == [99821,69321,32584]
assert combined_private['distinct_public_reports'] == combined_private['distinct_private_helpers_transitive'] == 3
assert combined_private['all_selected_public_statements_checked'] and combined_private['no_subsets_recounted']
assert combined_private['incoming_counted_once'] and combined_private['rejected6b65_preparer_is_not_a_compiler_run']
future_review = read(work/'FUTURE-FOLD-SEEDS-ROOT-REVIEW.json')
assert future_review['source60_credit'] == 0 and future_review['outside_source60_batch']
assert not future_review['whole_worker_proved'] and not future_review['joint_finite_completion_proved']
resume = read(work/'RESUME-AUTHORIZATION.json')
assert resume['manual_work_explicitly_authorized'] and resume['earlier_usage_pause_lifted']
assert "Keep going. We'll use a reset if needed." in resume['authorizing_instructions']
assert resume['persistent_goal_control_status'] == 'paused'
assert not resume['goal_operation_performed'] and not resume['goal_completion_claimed']
usage = read(work/'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int,float] and 0 <= percent <= 100
assert usage['current_usage_not_measured'] and usage['earlier_usage_pause_lifted_by_user_resume']
assert percent == 81 and '17:53:' in usage['checked_at']
handoff = (work/'LIVE-HANDOFF.md').read_text()
assert code in handoff and 'open' in handoff.lower()
roots = read(archive_control/'selection-roots.json')
assert len(roots) == len(set(roots)) == 25
additional = read(archive_control/'archive-additional-roots.json')
assert len(additional) == 2
for extra in additional:
    assert extra['current_batch_theorem_credit'] == 0 and not extra['private_runtime_selected']
    candidate = base/extra['root']
    verify(candidate/extra['manifest'],extra['sha256'])
    for name,record in records(read(candidate/extra['manifest'])['files']):
        verify(candidate/name,record)
    for filename in ['SOURCE-PINS.json','ADDITIONAL-SOURCE-PINS.json','DEPENDENCY-PINS.json']:
        if (candidate/filename).exists():
            for name,record in records(read(candidate/filename)):
                historical(name,record)
    roots.append(extra['root'])
assert len(roots) == len(set(roots)) == 27 and prior_archive.name not in roots
assert all((base/name).is_dir()and not (base/name).is_symlink()for name in roots)
assert not any('Work61' in name or 'fold-query-seeds-work' in name or 'fold-query-seeds-check' in name for name in roots)
for header in read(archive_control/'original-header-files.json'):
    assert sha((root/header['path']).read_bytes()) == sha((root/header['original']).read_bytes()) == header['sha256']
selected_roots = sorted(str((base/name).relative_to(root))for name in roots)
assert not archive.exists()
tree = hashlib.sha256()
for name,digest in sorted(source_pins.items()):
    tree.update(name.encode()+b'\0'+digest.encode()+b'\n')
config = dict(report)
config.update(checked_code=code,prior_checkpoint=push['checkpoint_commit'],public_run=str(runtime),public_gates=5,
    explicit_reports=738,board_prefix=board_prefix,board_post_id=post['id'],board_sequence=post['sequence'],
    source_tree_sha256=tree.hexdigest(),old_other_Source_files_byte_exact=6281,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],cleanup_receipt='COMBINED-TMP-CLEANUP.json',
    removed_regular_bytes=cleanup['regular_bytes_removed_this_batch'],removed_symlinks=cleanup['symlinks_removed_this_batch'],
    historical_primary_usage_percent=percent,historical_primary_usage_checked_at=usage['checked_at'],current_usage_not_measured=True,
    prior_immutable_archive=prior_archive.name,prior_manifest_sha256=bindings['prior_manifest_sha256'],
    actual_terminal_private_session=99821,actual_incoming_prerequisite_session=69321,actual_combined_seed_private_session=32584,
    actual_publication_session=88140,actual_source_commit_session=provenance['actual_session'],
    publication_preparer_actual_tool_chunk='7aac8b',executed_source_commit_control=commit_control.name,
    source_commit_control_bound_after_final_publication=True,
    old_usage_pause_reintroduced=False,persistent_goal_control_status='paused',work_authorized_by_explicit_user_resume=True,
    goal_active=False,goal_completion_claimed=False,existing_resource_FieldsThrough_observers_exported=True,
    original_per_event_worker_resource_attachment_proved=False,original_worker_admissions_proved=False,
    native_inhabitance_proved=False,joint_finite_completion_proved=False,compiled_haskell_correspondence_proved=False,haskell_changed=False,
    additional_frozen_roots=additional,additional_frozen_roots_theorem_credit=0,future_Work61_runtime_selected=False)
skipped = sorted(str(path.relative_to(root))for path in base.iterdir()
    if path.is_dir()and path.name.startswith(('20261117-','20261118-'))and str(path.relative_to(root))not in selected_roots)
review = {'selected_roots':27,'base_roots':25,'additional_frozen_roots':additional,'additional_frozen_roots_theorem_credit':0,
    'fresh_public_reports':3,'inherited_reports':529,'combined_reports':532,'new_public_theorems':3,'new_private_theorems':3,
    'new_theorem_declarations':6,'new_Prop_definitions':0,'Prop_declaration_checks':0,'Prop_axiom_credit':0,
    'resource_owner_reports_inherited':264,'current_batch_failures_preserved':[23666,54752],
    'failed_preparer_preserved':'6b65 missing topology before runtime or compiler',
    'successful_private_and_public_runs_preserved':[99821,69321,32584,88140],'source_commit_executed_control':commit_control.name,
    'all_root_documents_preserved_as_suffix':True,'existing_resource_FieldsThrough_observers_exported':True,
    'future_Work61_runtime_selected':False,'joint_finite_completion_proved':False}
note = (archive_control/'checkpoint-note.md').read_text()
normalized_note = ' '.join(note.lower().split())
assert 'historical' in normalized_note and 'current usage was not measured' in normalized_note
assert 'outside this checkpoint' in normalized_note and 'consult their separate receipts' in normalized_note
assert 'ONE' in note and 'SAME' in note
for key,value in {'THEOREMS':report['audited_theorems'],'PINS':publication['pins_independently_reverified'],
        'REMOVED':cleanup['regular_bytes_removed_this_batch'],'SYMLINKS':cleanup['symlinks_removed_this_batch'],
        'CLEANUP':cleanup['cumulative_removed_bytes'],'USAGE':percent,'BOARD':post['sequence']}.items():
    note = note.replace('{{'+key+'}}',str(value))
assert set(re.findall(r'\{\{(.*?)\}\}',note)) == {'TIME','TREE','CODE'}
outputs = {'checkpoint-config.json':config,'archive-roots.json':selected_roots,'skipped-published-roots.json':skipped,'selection-review.json':review}
assert all(not (work/name).exists()for name in outputs)
# No Work, archive or document mutation occurs before every preceding guard passes.
for name,value in outputs.items():
    (work/name).write_text(json.dumps(value,indent=2)+'\n')
(work/'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code':code,'archive':archive.name,'roots':27,'board_sequence':post['sequence'],
    'fresh_public_reports':3,'inherited_reports':529,'combined_reports':532,'current_usage_not_measured':True}))
