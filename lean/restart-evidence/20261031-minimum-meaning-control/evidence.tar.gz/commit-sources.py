from pathlib import Path
import json,subprocess
r=Path('/tmp/mcfta-minimum-meaning-control-20261031');repo=Path('/home/tritlo/Code/mcfta')
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert git('branch','--show-current')=='formalize' and git('rev-parse','HEAD')=='7b410d1d66737d3f091ef5171a0b2f15ef4bc28a'
assert git('remote','get-url','origin')=='git@github.com:TharkunAB/cfta.git' and not git('diff','--cached','--name-only')
mods=json.loads((r/'modules.json').read_text());audit=repo/'lean/MicroCFTA/Audit.lean';final=audit.read_bytes();original=(r/'prior-Audit.lean').read_bytes()
expected={'lean/MicroCFTA/Audit.lean','lean/MicroCFTA/SourceSizedMinimumConvergence.lean'}|{'lean/MicroCFTA/'+name+'.lean' for name in mods}
status=subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=repo).split(b'\0');assert {v[3:].decode() for v in status if v}==expected
result=subprocess.run(['git','diff','--check'],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/'pre-source-diff-check.raw.log').write_bytes(result.stdout);assert result.returncode==0
rows=[]
def commit(label,message,files):
 subprocess.run(['git','add','--',*files],cwd=repo,check=True);assert set(git('diff','--cached','--name-only').splitlines())==set(files)
 result=subprocess.run(['git','commit','-m',message],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/f'source-commit-{len(rows)+1}.raw.log').write_bytes(result.stdout);assert result.returncode==0,result.stdout
 rows.append({'module':label,'commit':git('rev-parse','HEAD'),'message':message,'files':files});(r/'source-commits.json').write_text(json.dumps(rows,indent=2)+'\n')
messages=['Derive row costs and guard-erased size lower bounds','Prove attained minima for guard-erased row languages','Track known ordinary nodes through initial and callback frames','Initialize bounded products from computed minimum sizes','Preserve known ordinary handles through native heap effects']
try:
 audit.write_bytes(original)
 commit('SourceSizedMinimumConvergence','Derive finite pass reachability of computed minima',['lean/MicroCFTA/SourceSizedMinimumConvergence.lean'])
 for index,(name,message) in enumerate(zip(mods,messages),1):
  audit.write_bytes((''.join('import MicroCFTA.'+m+'\n' for m in mods[:index])).encode()+original)
  commit(name,message,['lean/MicroCFTA/'+name+'.lean','lean/MicroCFTA/Audit.lean'])
finally:audit.write_bytes(final)
assert not git('diff','--','lean/MicroCFTA/Audit.lean') and len(rows)==6
print(json.dumps(rows))
