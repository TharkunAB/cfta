from pathlib import Path
import json,subprocess
r=Path('/tmp/mcfta-minimum-meaning-control-20261031');repo=Path('/home/tritlo/Code/mcfta')
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert git('branch','--show-current')=='formalize' and git('rev-parse','HEAD')=='0b9dc1637d1752eca39d3bc4c375a1035edabd4f';assert not git('diff','--cached','--name-only')
subprocess.run(['python3',str(r/'verify-documents.py')],check=True)
files=['NEXT-PROMPT.md','HANDOFF.md','FINDINGS.md','lean/notes-current-minimum-meaning-and-known-nodes.md'];subprocess.run(['git','add','--',*files],cwd=repo,check=True);assert set(git('diff','--cached','--name-only').splitlines())==set(files)
result=subprocess.run(['git','diff','--cached','--check'],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/'docs-diff-check.raw.log').write_bytes(result.stdout);assert result.returncode==0
result=subprocess.run(['git','commit','-m','Record structural minima and known-handle proof boundaries'],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/'docs-commit.raw.log').write_bytes(result.stdout);assert result.returncode==0,result.stdout
row={'commit':git('rev-parse','HEAD'),'source_head':'0b9dc1637d1752eca39d3bc4c375a1035edabd4f','files':files,'clean':not git('status','--porcelain=v1')};assert row['clean'];(r/'docs-commit.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
