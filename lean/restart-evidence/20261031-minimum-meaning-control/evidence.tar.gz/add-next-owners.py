from pathlib import Path
import hashlib,json,shutil
r=Path('/tmp/mcfta-minimum-meaning-control-20261031')
def sha(data):return hashlib.sha256(data).hexdigest()
rows=json.loads((r/'owners.json').read_text());assert len(rows)==18
new=[
('next-slot-creation-draft','/tmp/mcfta-ordinary-slot-creation-review-20261031','MANIFEST.json','3b0adee3055a0f15e8e5b94368b9d5f5b3cdab7bab8a79b7ebf08e74789206da','PINS.json','7b57e3310d65d41174f59013e1151572d6e3b958effbf11e0095025351b94379'),
('next-equality-filter-review','/tmp/mcfta-original-equality-filter-producer-review-20261031','MANIFEST.json','6ab5bde861e14ecfb3c71e48033edfc0ced887954916dc012fd79d76c7e9cfa5','pins.json','91082d457a8510e38596ddc2a7beed1713a38accdbdd7804b72b5c8ab6d8eb52'),
('equality-source-review-provider','/tmp/mcfta-equal-sizes-source-review-20261031','MANIFEST.json','8c0b06acf3315c648121ce9537d8f2ba4f542c533dea2650376c62655a66dc80','FROZEN-PINS.json','0805d0886818d968fe1e0bcd0b242c1d54847855c7fb19dde3ad5840f3e4d51f'),
('equality-numeric-provider','/tmp/mcfta-sized-minimum-equalsizes-next-review-20261031','MANIFEST.sha256','e71a3a0e886ea071b6b9e7a3af81c6333ab6a80dd686454cdafe46d148682f40','FROZEN-PINS.json','4af10393e289f2ba1fe2436290cc313ba3168f667127438c525a6d74164d5e87')]
acquired=[]
for name,origin,manifest,mhash,pins,phash in new:
 src=Path(origin);assert sha((src/manifest).read_bytes())==mhash;assert sha((src/pins).read_bytes())==phash
 files={str(p.relative_to(src)):p for p in src.rglob('*') if p.is_file()};assert all(not p.is_symlink() and not (p.stat().st_mode&0o222) for p in files.values())
 if manifest.endswith('.json'):
  payloads=json.loads((src/manifest).read_text())['files']
  for item in payloads:
   data=files[item['path']].read_bytes();assert len(data)==item['bytes'] and sha(data)==item['sha256']
  expected={item['path'] for item in payloads}
 else:
  payloads=[x.split('  ',1) for x in (src/manifest).read_text().splitlines()];expected={leaf for digest,leaf in payloads}
  for digest,leaf in payloads:assert sha(files[leaf].read_bytes())==digest
 extras=set(files)-expected-{manifest,pins};assert extras<={'FROZEN'}
 row={'name':name,'original':origin,'manifest':manifest,'manifest_sha256':mhash,'pins':pins,'pins_sha256':phash}
 if extras:row['extra_metadata']={leaf:{'bytes':files[leaf].stat().st_size,'sha256':sha(files[leaf].read_bytes())} for leaf in sorted(extras)}
 dst=r/name;assert not dst.exists();shutil.copytree(src,dst)
 assert {str(p.relative_to(dst)):sha(p.read_bytes()) for p in dst.rglob('*') if p.is_file()}=={leaf:sha(p.read_bytes()) for leaf,p in files.items()}
 rows.append(row);acquired.append({'owner':name,'full_provider':True,'files':len(files),'semantic_read_scope':'Reports and contracts only here; source bodies require named bounded reads in next phase','manifest_sha256':mhash,'pins_sha256':phash})
(r/'owners.json').write_text(json.dumps(rows,indent=2)+'\n');(r/'next-owner-acquisition.json').write_text(json.dumps(acquired,indent=2)+'\n');shutil.copyfile(__file__,r/'add-next-owners.py')
(r/'root-metadata-incidents.json').write_text(json.dumps([{'kind':'read-only metadata filename lookup','attempted':'/tmp/mcfta-original-equality-filter-producer-review-20261031/PINS.json','error':'FileNotFoundError: [Errno 2] No such file or directory','repair':'Read actual declared lowercase pins.json; retained original owner unchanged','source_or_proof_change':False,'native_or_haskell_execution':False}],indent=2)+'\n')
print(json.dumps({'owners':len(rows),'added':acquired}))
