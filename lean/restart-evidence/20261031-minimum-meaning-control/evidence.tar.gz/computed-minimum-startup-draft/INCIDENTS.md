# Incidents

No read or metadata command failed in this task.
The KnownOrdinary provider uses FROZEN-PINS.txt, not pins.json.
Its actual metadata filename was discovered before access.
The provider marker and manifest were retained with exact hashes.
Root reported a namespace-open repair in installed KnownOrdinary110.
V2 adds that same required open to the new bridge.
No compiler or runtime error is claimed from this source-only review.
