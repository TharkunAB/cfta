# Versions

V1 defines the computed natural table, exact embedding and same-root startup.
V2 adds open SourcePruningEnumerationNodes.
Root reported that the installed KnownOrdinary source required this open.
The new producer uses the same names in its copied result contract.
V2 is selected.
Both local versions remain uncompiled owner source.
