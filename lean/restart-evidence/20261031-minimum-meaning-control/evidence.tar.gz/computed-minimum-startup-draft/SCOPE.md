# Scope

Source-only computed signed minimum to natural minimum and actual bounded startup.
Two OLD wholes named before acquisition:
1. current SourceSizedPrefixProductInitial.lean133;
2. frozen SourceSizedPrefixKnownOrdinary-v2-UNCOMPILED.lean110.
All minimum/convergence and cast APIs use named bounded cuts.
Root owns compilation/evaluation/native/Haskell/Git/network/board/production.
No spawning is permitted.
The public startup producer has no free minimum or supplied embedding witness.
All original guard/cache/filter/width/pending gates and actual same-root results remain.
