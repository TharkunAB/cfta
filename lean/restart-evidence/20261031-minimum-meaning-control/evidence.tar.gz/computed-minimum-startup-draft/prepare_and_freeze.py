from pathlib import Path
import hashlib,json,re
r=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
selected=r/'SourceSizedPrefixComputedMinimum-v2-UNCOMPILED.lean'
assert sha(selected)=='3fa4c11d90cdc04cd6162afb834688e84e0c8f0bbf5403fc246a684c0527ac1b'
assert len(selected.read_bytes().splitlines())==76
assert not re.findall(r'\b(?:sorry|admit|axiom|unsafe|noncomputable|Classical)\b',selected.read_text())
providers=[]
provider_specs=[('/tmp/mcfta-sized-product-initial-admission-next-review-20261031','22f42b3020d04e0724d86d5b200ff574d7d4b10f5144a149e5e6c51846c9ba45','pins.json','8ea14e6127b323b6474f2780c2bc39456e27fc99508823c64d24c92e03bb0747'),('/tmp/mcfta-known-ordinary-cache-review-20261031','3a5930d51d7fa96a96c8ab10acb8ab9790e8d58f91739d47ebd047bd07bcfb8b','FROZEN-PINS.txt','bc6bb1f87c6162b684cd5d32f05542f1ff2f39692f8f1441b58b9d84ff825250'),('/tmp/mcfta-minimum-convergence-review-20261031','98e6db5dc10f879918423e4eb8c1f2549b3bc6fe88519bbbff7fd9fe793ce7cf','pins.json','a4a63c33e783c16bad181586fa8da55803e2fc3824e43581f6b10c38e0ce7d54'),('/tmp/mcfta-minimum-reachability-review-20261031','fa279e5a7e1456090bec53fd05ea9b59e1783b2ed3e8f9fe79daa2f094f182b3','pins.json','14b47a383923584983a10779f373f720d0e89524d83554f3fbb72c22bf9f34f2')]
for path,m,pin_name,pin_sha in provider_specs:
 provider=Path(path)
 assert sha(provider/'MANIFEST.json')==m
 assert sha(provider/pin_name)==pin_sha
 full=json.loads((provider/'MANIFEST.json').read_text())
 for e in full['files']:
  assert sha(provider/e['path'])==e['sha256']
 key=provider.name.removeprefix('mcfta-').removesuffix('-20261031')
 metadata=['MANIFEST.json',pin_name,'FROZEN','acquisitions.json','ACQUISITION-UNIONS.json','ORIGINAL-FILE-UNIONS.json','SOURCE-VERIFICATION.json']
 for name in metadata:
  file=provider/name
  if file.exists():
   (r/'reused'/(key+'-'+name)).write_bytes(file.read_bytes())
 providers.append({'path':path,'manifest_sha256':m,'pin_file':pin_name,'pin_sha256':pin_sha,'full_closure_retained_in_place':True,'all_payload_hashes_match':True})
(r/'PROVIDER-CLOSURES.json').write_text(json.dumps(providers,indent=2)+'\n')
entries=json.loads((r/'acquisitions.json').read_text())
by={}
for e in entries:
 source=Path(e['original_path'])
 assert sha(source)==e['source_sha256']
 assert sha(r/e['copy'])==e['copy_sha256']
 key=(e['original_path'],e['source_sha256'])
 b=by.setdefault(key,{'original_path':e['original_path'],'source_sha256':e['source_sha256'],'source_lines':e['source_lines'],'lines':set()})
 if 'actual_lines' in e:
  lines=e['actual_lines']
 else:
  lines=[n for a,z in e['line_ranges']for n in range(a,z+1)]
 b['lines'].update(lines)
rows=[]
for b in by.values():
 lines=sorted(b.pop('lines'))
 ranges=[]
 for n in lines:
  if ranges and n==ranges[-1][1]+1:
   ranges[-1][1]=n
  else:
   ranges.append([n,n])
 b.update({'retained_unique_lines':len(lines),'cumulative_ranges':ranges,'fraction':len(lines)/b['source_lines'],'whole_or_near_whole':len(lines)/b['source_lines']>=0.75})
 rows.append(b)
assert sum(b['whole_or_near_whole']for b in rows)==2
(r/'ACQUISITION-UNIONS.json').write_text(json.dumps({'old_whole_limit':2,'old_wholes_used':2,'sources':rows},indent=2)+'\n')
(r/'SOURCE-REVERIFY.json').write_text(json.dumps({'all_original_source_hashes_match':True,'all_retained_copy_hashes_match':True,'acquisition_records':len(entries),'distinct_original_path_hashes':len(rows)},indent=2)+'\n')
(r/'VERSION-NOTES.md').write_text('''# Versions

V1 defines the computed natural table, exact embedding and same-root startup.
V2 adds open SourcePruningEnumerationNodes.
Root reported that the installed KnownOrdinary source required this open.
The new producer uses the same names in its copied result contract.
V2 is selected.
Both local versions remain uncompiled owner source.
''')
(r/'INCIDENTS.md').write_text('''# Incidents

No read or metadata command failed in this task.
The KnownOrdinary provider uses FROZEN-PINS.txt, not pins.json.
Its actual metadata filename was discovered before access.
The provider marker and manifest were retained with exact hashes.
Root reported a namespace-open repair in installed KnownOrdinary110.
V2 adds that same required open to the new bridge.
No compiler or runtime error is claimed from this source-only review.
''')
(r/'REPORT.md').write_text('''# Computed minimum table to bounded startup

## Status

Selected: SourceSizedPrefixComputedMinimum-v2-UNCOMPILED.lean, 76 lines.
SHA256: 3fa4c11d90cdc04cd6162afb834688e84e0c8f0bbf5403fc246a684c0527ac1b.
The owner has not run Lean, an evaluator, native code or Haskell.
The owner has not edited production, Git, the board or the network.
The source remains uncompiled owner evidence.

Root reports that Convergence227 and installed KnownOrdinary110 passed strict checks.
The installed KnownOrdinary full hash is
3accfc1bd3d6c97c1fbe3af317fd87751d7990e1e1fcb90135eaf878cbb98cbe.
Only its required open and producer-name lines were acquired here.
The owner retained the full frozen original KnownOrdinary110 separately.
Its original hash is
819f6308c1b400b79841efcfabd6fdfae667e87b3653608e42144a2a7092280b.
Root reports that the same intended contract was retained after the open repair.
The owner does not infer that this new bridge has passed any check.

## Computed table

minimumNat input is defined by mapping Int.toNat over minimumSizes input.
The table and original root are not free producer arguments.
minimumNat_embedded proves that mapping the natural values back to Int gives
exactly the original computed signed table, including absent entries.
The proof uses minimum_spec internally.
Every present signed value is strictly positive.
That positivity proves the exact cast equation by omega.
No embedding certificate or positive-table invariant is supplied by the caller.
No standard-library source was acquired for the cast step.

The original finite Input and DecidableEq Q are the computation inputs.
The equality instance is needed by the actual pass implementation.
It is not a future-result certificate.
The original Input.root and Input.rows are the values used below.

## Actual same-root startup

initial_packet_computed returns the derived embedding and the full result of
initial_packet_known specialized to input.rows, minimumNat input and input.root.
It calls the actual existing producer.
It does not take a future expression, build result, run, heap or domain witness.

The following original inputs remain explicit:

- Source formulas and entailment solver.
- The original partial-constraint cache and Cache.Valid proof.
- The equalSizes filter and signed public bound.
- Cached equality readback for every original row annotation.
- Typing metadata and metadata.pending = [].
- The original width parameter and edge-key equality instance.

The result retains the same expression, root value, heap, build observation,
Facts, Available, closed free variables and recursive ordinary Node.
Its height bound remains bound.toNat + 1, including the synthetic-root envelope.
It retains the actual guard annotation heap and encoded/decoded root handle.
It retains the literal singleton startup cache, Packet, computed initial Fits,
canonical core, stored slot-zero handle and zero suspended mass.
It retains KnownOrdinary at the caller's same native heap and the same bound.
No component is replaced by a separately chosen witness.

## Check boundary

Root must elaborate and strict-check the selected new module.
The imports name Convergence and the now-installed KnownOrdinary module.
The main proof is direct specialization of initial_packet_known.
The cast proof and any namespace reduction still need checking.
Both local source versions remain retained.
The owner has run no compiler or evaluator.

## Remaining system boundary

The computed table is the actual formal minimum-pass result.
This is not a proof of the literal Haskell Map implementation.
Map domain recoding, key order and table representation remain open.
The equalSizes and full source semantic adapters remain open.
The ranked product construction is not yet the literal SCC/memo/fromRows model.
The bridge gives startup admission and KnownOrdinary at that actual startup.
It does not preserve KnownOrdinary through every worker branch.
It does not derive sufficient global worker depth or ordered prefix coverage.
Captured sibling restoration, source replacement and terminal renewals remain open.
The original-input/both-worker/public/Haskell objective remains open.
No Haskell defect or fix was established.
There is no FINDINGS defect candidate from this source-only task.

## Acquisitions and providers

Exactly two OLD wholes were named before acquisition:
current Initial133 and frozen KnownOrdinary110.
Convergence and original Input use bounded named cuts.
The installed KnownOrdinary source contributes only two named locator lines.
ACQUISITION-UNIONS.json records cumulative unions at original paths.
The ledger records full source hashes and exact retained copies.
The Initial45, KnownOrdinary36, Convergence26 and Reachability25 full providers
remain frozen at the exact paths in PROVIDER-CLOSURES.json.
Their complete manifests, pin/marker files and acquisition metadata are retained.
Every provider payload hash was reverified.
No previous provider source or metadata was changed.
''')
(r/'STATIC-AUDIT.json').write_text(json.dumps({'status':'UNCOMPILED owner source','selected':selected.name,'lines':76,'sha256':sha(selected),'old_wholes':2,'free_minimum_argument':False,'free_root_argument':False,'supplied_embedding_witness':False,'future_build_run_heap_domain_supplier':False,'retains_all_original_startup_gates':True,'retains_same_root_packet_fits_knownordinary':True,'compiler_evaluator_native_haskell_invocations':0,'production_git_network_board_mutations':0},indent=2)+'\n')
manifest={'kind':'source-only computed minimum bounded startup','selected':selected.name,'status':'UNCOMPILED owner source','files':[]}
for q in sorted(r.rglob('*')):
 if q.is_file() and q.name not in {'MANIFEST.json','pins.json','FROZEN'}:
  manifest['files'].append({'path':str(q.relative_to(r)),'bytes':q.stat().st_size,'sha256':sha(q)})
(r/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
pins={'scope':str(r),'selected':selected.name,'selected_sha256':sha(selected),'selected_lines':76,'manifest_sha256':sha(r/'MANIFEST.json'),'report_sha256':sha(r/'REPORT.md'),'payload_files':len(manifest['files']),'status':'UNCOMPILED owner source'}
(r/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(r/'FROZEN').write_text('Source-only computed-minimum startup bridge frozen.\nSelected source remains UNCOMPILED.\nMANIFEST.json SHA256 '+pins['manifest_sha256']+'\npins.json SHA256 '+sha(r/'pins.json')+'\n')
for e in manifest['files']:
 assert sha(r/e['path'])==e['sha256']
for q in r.rglob('*'):
 if q.is_file():
  q.chmod(0o444)
for q in sorted([q for q in r.rglob('*')if q.is_dir()],reverse=True):
 q.chmod(0o555)
r.chmod(0o555)
result={'files':sum(q.is_file()for q in r.rglob('*')),'selected':sha(selected),'manifest':sha(r/'MANIFEST.json'),'pins':sha(r/'pins.json'),'report':sha(r/'REPORT.md'),'frozen':sha(r/'FROZEN'),'unions':[(b['retained_unique_lines'],b['source_lines'])for b in rows]}
print(json.dumps(result,indent=2))
