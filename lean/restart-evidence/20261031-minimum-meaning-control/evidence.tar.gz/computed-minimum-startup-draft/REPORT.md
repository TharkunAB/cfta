# Computed minimum table to bounded startup

## Status

Selected: SourceSizedPrefixComputedMinimum-v2-UNCOMPILED.lean, 76 lines.
SHA256: 3fa4c11d90cdc04cd6162afb834688e84e0c8f0bbf5403fc246a684c0527ac1b.
The owner has not run Lean, an evaluator, native code or Haskell.
The owner has not edited production, Git, the board or the network.
The source remains uncompiled owner evidence.

Root reports that Convergence227 and installed KnownOrdinary110 passed strict checks.
The installed KnownOrdinary full hash is
3accfc1bd3d6c97c1fbe3af317fd87751d7990e1e1fcb90135eaf878cbb98cbe.
Only its required open and producer-name lines were acquired here.
The owner retained the full frozen original KnownOrdinary110 separately.
Its original hash is
819f6308c1b400b79841efcfabd6fdfae667e87b3653608e42144a2a7092280b.
Root reports that the same intended contract was retained after the open repair.
The owner does not infer that this new bridge has passed any check.

## Computed table

minimumNat input is defined by mapping Int.toNat over minimumSizes input.
The table and original root are not free producer arguments.
minimumNat_embedded proves that mapping the natural values back to Int gives
exactly the original computed signed table, including absent entries.
The proof uses minimum_spec internally.
Every present signed value is strictly positive.
That positivity proves the exact cast equation by omega.
No embedding certificate or positive-table invariant is supplied by the caller.
No standard-library source was acquired for the cast step.

The original finite Input and DecidableEq Q are the computation inputs.
The equality instance is needed by the actual pass implementation.
It is not a future-result certificate.
The original Input.root and Input.rows are the values used below.

## Actual same-root startup

initial_packet_computed returns the derived embedding and the full result of
initial_packet_known specialized to input.rows, minimumNat input and input.root.
It calls the actual existing producer.
It does not take a future expression, build result, run, heap or domain witness.

The following original inputs remain explicit:

- Source formulas and entailment solver.
- The original partial-constraint cache and Cache.Valid proof.
- The equalSizes filter and signed public bound.
- Cached equality readback for every original row annotation.
- Typing metadata and metadata.pending = [].
- The original width parameter and edge-key equality instance.

The result retains the same expression, root value, heap, build observation,
Facts, Available, closed free variables and recursive ordinary Node.
Its height bound remains bound.toNat + 1, including the synthetic-root envelope.
It retains the actual guard annotation heap and encoded/decoded root handle.
It retains the literal singleton startup cache, Packet, computed initial Fits,
canonical core, stored slot-zero handle and zero suspended mass.
It retains KnownOrdinary at the caller's same native heap and the same bound.
No component is replaced by a separately chosen witness.

## Check boundary

Root must elaborate and strict-check the selected new module.
The imports name Convergence and the now-installed KnownOrdinary module.
The main proof is direct specialization of initial_packet_known.
The cast proof and any namespace reduction still need checking.
Both local source versions remain retained.
The owner has run no compiler or evaluator.

## Remaining system boundary

The computed table is the actual formal minimum-pass result.
This is not a proof of the literal Haskell Map implementation.
Map domain recoding, key order and table representation remain open.
The equalSizes and full source semantic adapters remain open.
The ranked product construction is not yet the literal SCC/memo/fromRows model.
The bridge gives startup admission and KnownOrdinary at that actual startup.
It does not preserve KnownOrdinary through every worker branch.
It does not derive sufficient global worker depth or ordered prefix coverage.
Captured sibling restoration, source replacement and terminal renewals remain open.
The original-input/both-worker/public/Haskell objective remains open.
No Haskell defect or fix was established.
There is no FINDINGS defect candidate from this source-only task.

## Acquisitions and providers

Exactly two OLD wholes were named before acquisition:
current Initial133 and frozen KnownOrdinary110.
Convergence and original Input use bounded named cuts.
The installed KnownOrdinary source contributes only two named locator lines.
ACQUISITION-UNIONS.json records cumulative unions at original paths.
The ledger records full source hashes and exact retained copies.
The Initial45, KnownOrdinary36, Convergence26 and Reachability25 full providers
remain frozen at the exact paths in PROVIDER-CLOSURES.json.
Their complete manifests, pin/marker files and acquisition metadata are retained.
Every provider payload hash was reverified.
No previous provider source or metadata was changed.
