# Incidents

None during initial acquisition. No compilation or evaluation.

The filename-only Equality*.lean query returned more names than needed. Its full stdout/stderr are retained. No incidental body was acquired. Follow-up acquisitions use only the named SourceSizedNormalizedConstraints and SourceSizedPreprocessing targets.

The Size.hs declaration locator matched more interior lines than needed. The full stdout was saved before display. The tool display truncated that saved output. No follow-up body was acquired from the truncated portion. This numeric SizeIndex module is not needed for the selected filter route.

Named stdlib ControlLemmas.lean path was absent. Exact stderr retained. No source body acquired from that path.
