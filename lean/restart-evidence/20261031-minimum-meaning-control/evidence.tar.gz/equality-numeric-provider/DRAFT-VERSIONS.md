# Draft versions

V1 is retained unchanged. V2 changes only the positive-case simplifier lemma
in sizeOf_map from if_pos to ite_eq_left. This matches the checked current Rank
module's explicit if reduction. All public headers and definitions are unchanged.
No draft was compiled or evaluated.

V3 retains all V2 definitions and public headers. It adds filtered_splits_integer,
which preserves arbitrary Integer residual totals through an explicit negative
case and the checked splits_negative law. No draft was compiled or evaluated.
