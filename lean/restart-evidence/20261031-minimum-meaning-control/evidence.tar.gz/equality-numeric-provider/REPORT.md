# Numeric equality-size filter next step

The smallest candidate replaces the opaque numeric filter body with the source
algorithm on its current equality view. It proves that embedding Nat parts into
Integer parts preserves the result. It then proves exact equality of the filtered
Integer splits and the filtered Nat allocations. It retains order and multiplicity.
The candidate is SOURCE-ONLY and UNCOMPILED. Root must check it before use.

## Candidate

Use SourceSizedPrefixEqualSizes-v3-UNCOMPILED.lean.
It has 118 lines and 5414 bytes.
SHA256: b71aa401c28fc7bfd445ca663407889ef02e6e08bcab16650472174116655128.
V1 and V2 are retained. V2 changes one private simplifier lemma to the checked
Rank style. V3 adds the arbitrary-Integer residual-total companion. All prior
public headers are unchanged. No compiler or evaluator ran.

The candidate imports the current checked Integer and Rank modules. Their complete
byte-exact copies are the two named OLD whole acquisitions. The new candidate is
next-phase work. Root has not checked or installed it for the current checkpoint.

## Exact source behavior

Prefix.hs612-625 reads equalities constraint, not just constraintEqualities.
EqConstraints classes runs all classes. The other case, EqContradiction, returns
True from this numeric prefilter. The candidate retains that behavior explicitly.
This filter does not decide satisfiability of the full retained constraint.

For each class, the source keeps only paths with exactly one ChildIndex. It drops
root paths and deeper paths from this numeric test. It reads the selected parts
with sizeOf. A negative or out-of-range selected index returns Nothing and rejects
the class. An empty selected class returns True. Otherwise every selected size
must equal the first. The candidate retains the current class/path list order.
Its raw signed-index view includes the negative-index branch. It does not silently
replace all original ChildIndex Int values with natural indexes.

sizeOf uses the source drop/head behavior. readSizes is its explicit Maybe
traversal. allSame has the three literal traversal-result cases. equalSizes has
the literal class-conjunction and contradiction cases. Existing map_drop and
head?_map prove lookup transport. The remaining cast proofs use actual traversal
and filter computations, without an output certificate or semantic supplier.

## Candidate public laws

- equalSizes_contradiction exposes the source numeric default True.
- equalSizes_cast gives identical Boolean decisions before and after Nat-to-Int
  embedding for every current equality view, including signed indexes.
- filtered_splits_embedded composes the checked splits_embedded law and derives
  exact ordered-list equality after the concrete numeric filter.
- filtered_splits_integer extends the same result to every Integer residual total,
  with an explicit negative-total empty branch. It does not truncate a negative
  residual into a zero allocation.

The last law uses only the current minimum table, original ordered child list,
original total, and current equality view. It accepts no future trace, rank, Ready,
completion, native output, or desired result. No list is converted to a set.
The source row constraint is not replaced or erased. This law concerns allocations.

## Remaining equality-view producer

The equality view is CURRENT ORIGINAL DATA. It is the result of the source
Constraint.equalities projection. It is not a future execution certificate.
The candidate models and transports the exact numeric body after that projection.
It does not claim that the full original projection has already been modeled.

Constraint.hs129-136 combines stored normalized equalities with the positive Same
atoms extracted from the guard, when positiveEqualities recognizes that guard.
The existing SourceSymbolicIndex.Constraint stores classes plus a separate guard.
Its stored classes cannot be identified with the Haskell equalities result for
all guards. That producer and Set.toList/class/path representation remain open.
The existing SourceGuards.Path is List Nat. A complete original adapter must also
justify how signed original paths are validated or retained. The present raw
signed view does not need that restriction for its numeric transport law.
NEXT-TARGETS.md gives the exact missing source projection contract.

## Minimum table producer

Table.hs390-403 starts at Map.empty. A pass uses Map.foldrWithKey. Each state
inserts the minimum of successful 1 + sum child-lookups with Map.insertWith min.
The function repeats until the whole map stops changing. It ignores transition
constraints. Its minima are structural row minima, not a proof that every state
has a semantically accepted term when its constraints are considered.

No literal total Lean producer for that fixed-point function was found in these
bounded reads or the coordinated bounded inventory. This is not a claim of
repository-wide absence. The actual producer remains open. A future successful
run, output table, arbitrary iteration bound, or positivity supplier is not an
acceptable replacement. NEXT-TARGETS.md states an original-input producer target
and a concrete finite-map termination measure.

## Boundaries and provenance

The current explicit original bound is retained by the checked Rank/Integer
modules. This candidate does not select that bound or a sufficient worker depth.
The Nat total in filtered_splits_embedded is the current residual allocation
budget. filtered_splits_integer covers negative residuals too. The checked Rank
module retains the direct synthetic root and empty rows at nonpositive original
bounds. The original bound is not replaced by this residual total.
It does not prove reachable table construction, literal native SCC/memo reification,
whole-worker admission, public requested-prefix adequacy, or Haskell correspondence.
Both workers and exact configured policies remain in the full goal. Unknown and
empty-language outcomes remain distinct. No Haskell bug or fix was established.
FINDINGS needs no source-only defect entry.

acquisitions.json records all original source paths, full hashes, and exact cuts.
cumulative-source-unions.json records every acquired original-line union. Both
OLD whole slots are used only by the specified current checked modules. All other
bodies are bounded named cuts or locators. INCIDENTS.md retains the filename scope,
truncated-display, and absent ControlLemmas path incidents. Full saved payloads and
all stderr are present. No production edit, Git/network/board action, or spawn ran.
