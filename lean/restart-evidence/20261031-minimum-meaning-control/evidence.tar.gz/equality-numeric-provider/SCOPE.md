# Minimum-size and numeric equality-size next step

Started 2026-10-31 03:25 CET. SOURCE-ONLY. Root owns evaluation.
Find the smallest actual minimumSizes/equalSizes correspondence producer for the
current size-product model. Prefer a source-grounded candidate at most 200 lines.
Preserve exact Integer arithmetic, output order, multiplicity, and filtering.
No future execution, rank, Ready, or native-output supplier may be an input.
No production edits, compilation/evaluation/native/Haskell, Git/network/board/spawn.
Exactly TWO OLD whole paths are named and acquired: current installed
SourceSizedPrefixProductInteger.lean and SourceSizedPrefixProductRank.lean.
All Haskell and other dependencies use named bounded cuts or declaration locators.
Full original/public both-worker and Haskell correspondence goals remain open.
