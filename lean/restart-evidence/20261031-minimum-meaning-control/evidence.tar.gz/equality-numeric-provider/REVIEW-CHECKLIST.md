# Source-only review

- The candidate is at most 200 lines and uses the current checked numeric modules.
- The numeric body has explicit current source data, not an opaque filter supplier.
- Raw signed paths retain negative-index behavior.
- Only singleton paths participate in the numeric class test.
- Root and deeper paths are omitted exactly as in the source comprehension.
- Out-of-range selected paths reject the class through Maybe traversal.
- Empty projected classes and EqContradiction retain source True behavior.
- The full source row constraint is not replaced by this numeric test.
- Nat-to-Int embedding preserves lookup, traversal, equality tests, and filtering.
- The final law is exact list equality, with order and multiplicity retained.
- The actual positive-guard equality extraction and minimumSizes producer remain open.
- No future trace, success, native state, or invariant supplier enters a header.
- Original resource sufficiency and both-worker/public/Haskell adequacy remain open.
- All acquired source bytes, ranges, locators, errors, and versions are retained.
- No draft was compiled, evaluated, or installed by this owner.
