# Exact remaining original-input producers

These are next targets. They are not implemented or elaborated declarations.
Do not add their desired conclusions as new current-caller hypotheses.

## Original equality extraction

For each original full Constraint c, compute this current view from its own fields:

    case positiveEqualities c.constraintGuard of
      Just EmptyConstraints -> c.constraintEqualities
      Just guardEqualities  -> combineEqConstraints c.constraintEqualities guardEqualities
      Nothing               -> c.constraintEqualities

Then render EqContradiction as None. Render EqConstraints classes as Some classes,
with each PathEClass read through Set.toList . unPathEClass and each Path read
through unPath. Retain signed ChildIndex values in the original ordered list view.
This is the exact input type of the new equalSizes model.

The next source-row theorem must derive that view from the ORIGINAL constraint.
It must not take a supplied view-correctness or desired-filter-result certificate.
Stored classes alone do not suffice when positive guard equalities add relations.
An equality-only constraint is produced by equalityConstraint eqs = Constraint eqs
Top. That concrete branch can reduce extraction directly, but it does not establish
extraction for every original guard. The full guard stays on the copied source row.

## Literal minimumSizes producer

First define the actual Map.foldrWithKey pass and converge expression on the
original finite row map. Preserve key order and the current known-map updates
within each pass. Retain the source Integer Size arithmetic and minimum insertion.
No arbitrary count of future iterations belongs in the public producer inputs.

The minimal unconditional original-input transport target has this shape:

    minimumNat original state :=
      (minimumSizesLiteral original state).map Int.toNat

    theorem minimumNat_embed
      (original : SourceSizedPreprocessing.Input State Symbol Annotation) :
      forall state,
        (minimumNat original state).map Int.ofNat =
          minimumSizesLiteral original state

SourceSizedPreprocessing.Input is the existing finite original row input. Its
finite states and row function must construct the actual source row map in source
key order. It is not an output witness or a replacement desired-language API.
minimumSizesLiteral is not yet defined. This header is only a precise target and
is not a compilable proof file.
Its needed positivity companion is determined by the same original input:

    theorem minimumSizesLiteral_positive
      (original : SourceSizedPreprocessing.Input State Symbol Annotation) :
      forall state value,
        minimumSizesLiteral original state = some value -> 0 < value

A source-aligned proof can preserve positivity from the empty map. Each successful
transition gives 1 + sum positive known child values. Minimum insertion preserves
positivity. Prove domain containment in the original row keys at the same time.

For totality, use lexicographic natural measures:

    (number of original row keys still absent,
     sum of the known natural minimum values)

A newly known key lowers the first component. When support is unchanged, every
value is nonincreasing because insertion uses min. A changed map then strictly
lowers the second component. Derive those facts from the actual pass; do not
supply them as an abstract transition invariant. This plan does not need an
original upper bound on the final minimum sizes or a future stopping witness.

After defining that producer and proving the embedding law, instantiate the
checked Integer and new numeric filter correspondence from the ORIGINAL table.
Reachable exploration, trim, literal fromRows/SCC/memo construction, cached
admission, sufficient worker resources, and public/Haskell adequacy still follow
as separate obligations. A numeric prefilter pass does not prove satisfaction of
the full source constraint, and EqContradiction passing it is not a bug claim.
