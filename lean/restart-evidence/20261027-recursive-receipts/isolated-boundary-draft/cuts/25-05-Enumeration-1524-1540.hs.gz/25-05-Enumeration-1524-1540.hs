        ExpansionNext uv -> do
            UVarUnenumerated (Just node) scs <- getUVarValue uv
            let prepare = do
                    (reject, updated) <- orderedOracle config global local uv (Right node)
                    guard (not reject)
                    pure (updated, OrderedPrepared uv)
            if recursiveBoundary node
                then do
                    representative <- getUVarRepresentative uv
                    ancestry <- gets $ IntMap.findWithDefault HashSet.empty (uvarToInt representative) . _recursionAncestry
                    if HashSet.member (recursionKey node scs) ancestry
                        then do
                            setUVarValue representative (UVarUnenumerated (Just node) Sequence.Empty)
                            orderedPrepare marker config global local
                        else prepare
                else prepare

