structure Protected (held : Nat) (before after : State Symbol Guard) : Prop where
  value : after.values[held]? = before.values[held]?
  root : IsRoot after.representatives held
  classes : ∀ uv, UnionFind.SameClass after.representatives held uv ↔
    UnionFind.SameClass before.representatives held uv

/-- An unchanged state retains its protected root. -/
theorem Protected.refl (held : Nat) (state : State Symbol Guard) (root : IsRoot state.representatives held) :
    Protected held state state := ⟨rfl, root, fun _ => Iff.rfl⟩

/-- Consecutive traversals retain the same protected value and class. -/
theorem Protected.trans (left : Protected held before middle) (right : Protected held middle after) :
    Protected held before after :=
  ⟨right.value.trans left.value, right.root, fun uv => (right.classes uv).trans (left.classes uv)⟩

