# Traversal and captured observation paths

The full CFTA formalization goal remains active.
Retain original public inputs, finite-prefix coverage with sufficient original resources, exact configured order and stops, the optimized interned core, both recursive workers, public Prefix/table/count/checkpoint adapters, and Haskell correspondence.
Retain all older constructor, equality, node-count, size, rank, and unrank results.

This phase composes the checked all-row ChildDispatch property through the actual stopping ChildTraversal trace and actual captured edge preparation.
It also covers the separate prepared opaque and terminal dispatcher needed by the second recursive worker.
Keep the existing receipt paths for complete, rejected, outer, and candidate states.
Add the same observation's every successful raw row.
Do not add a returned singleton premise, a future path-preserving callback, or a satisfying model.
Keep all existing resource and admission clauses in any later worker strengthening.
Whole execution paths must include discarded intermediate receipts and actual hook and false-callback inputs.
Sufficient original recursive capacity remains the main open result.

Root owns production changes, all compiler/evaluator/native commands, Git, network, and board actions.
One child owns only the fresh whole-worker-path-review directory.
Its source review has a two-new-whole-or-near-whole-body limit.
It must retain all acquisitions, drafts, incidents, and pins before freezing.

Compiler checks stay serial under Lean 4.34.1, 4 GiB memory maximum and high, zero swap, and a five-minute cap.
The runner helpers are exact prior bytes with only the evidence-area path replaced.
The launch environment supplies the existing uid-1000 runtime bus because the inherited variables are absent.
No runner, cap, heartbeat, service, or queue setting changed.

Main and formalize were refreshed before new proof work.
The base head is 2eca69da5d10184774231d91929af9103d55c0fb.
Main remains bd5a406a6a3f84b7e3ae0906082783911509df83.
All prior 527 protected, 4726 Lean, and 835 native sources match their pinned bytes.
The prior 1147 public checks and 100 definitions stay in the public run.
No Haskell source changed and no native command ran.
Record any established Haskell fix or candidate in FINDINGS.
