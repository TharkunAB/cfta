
/-- Every returned caller retains the original closed guard alphabet, including raw failures. -/
theorem run_heap (alphabet : List Constraint)
    (closed : SourceCurrentNativeClosedGuardAlphabet.Closed alphabet)
    (profile : Profile) (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (checkEmpty : Bool) (representativeFuel nativeFuel p h : Nat)
    (beforeCaller : Caller (bits + 2)) (before : EnumerationState.State Symbol EnumGuard)
    (uv : Nat) (incoming : Node) (incomingScs : List EnumerationState.Suspended)
    (queries : Queries) (memos : Memos)
    (initial : Context formulas solver inventory beforeCaller memos)
    (fits : Fits profile beforeCaller.checked) (room : Room bits profile)
    (realized : PendingRealized beforeCaller.checked.native.machine.heap before)
    (incomingAvailable : Available beforeCaller.checked.native.machine.heap incoming)
    (incomingClosed : incoming.free = [])
    (known : Heap (fun guard => guard ∈ alphabet) beforeCaller.checked.native.machine.heap) :
    Heap (fun guard => guard ∈ alphabet)
      (run checkEmpty representativeFuel nativeFuel p h beforeCaller before uv incoming incomingScs queries).2.1.checked.native.machine.heap := by
  unfold run
  cases foundEq : UnionFind.findRoot representativeFuel before.representatives uv with
  | none => exact known
  | some found =>
      dsimp only
      cases stored : before.values[found.representative]? with
