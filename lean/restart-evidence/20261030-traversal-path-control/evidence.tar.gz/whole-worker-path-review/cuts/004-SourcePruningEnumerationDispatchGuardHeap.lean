/-- Every actual dispatch caller retains the same closed guard alphabet. -/
theorem dispatch_heap (alphabet : List Constraint)
    (closed : SourceCurrentNativeClosedGuardAlphabet.Closed alphabet)
    (profile : Profile) (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (checkEmpty : Bool) (nativeFuel p h : Nat)
    (beforeCaller : Caller (bits + 2)) (before : EnumerationState.State Symbol EnumGuard)
    (source target : Nat) (queries : Queries) (memos : Memos)
    (initial : Context formulas solver inventory beforeCaller memos)
    (fits : Fits profile beforeCaller.checked) (room : Room bits profile)
    (realized : PendingRealized beforeCaller.checked.native.machine.heap before)
    (known : Heap (fun guard => guard ∈ alphabet) beforeCaller.checked.native.machine.heap) :
    Heap (fun guard => guard ∈ alphabet)
      (dispatch checkEmpty nativeFuel p h beforeCaller before source target queries).2.1.checked.native.machine.heap := by
  by_cases same : source = target
  · simp only [dispatch, ite_eq_left same, Id.run]
    exact known
  · simp only [dispatch, ite_eq_right same, Id.run]
    cases sourceStored : before.values[source]? with
    | none => exact known
