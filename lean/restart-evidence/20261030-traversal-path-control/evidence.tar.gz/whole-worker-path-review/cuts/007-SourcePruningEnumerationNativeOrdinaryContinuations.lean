variable {width : Nat} {Output : Type u} {Reason : Type v}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Enter once and run each completed edge's continuation before its next sibling. -/
noncomputable def run
    (hook : Fragment → Caller width → Queries → Cached →
      SourcePruningEnumerationNativeContinuations.HookResult Output Reason width)
    (checkEmpty : Bool) (r n p h k uv : Nat)
    (edgesOf : Node → List (EdgeValue Symbol Constraint)) (caller : Caller width)
    (before : Cached) (queries : Queries) :
    Raw × Option (SourcePruningEnumerationNativeContinuations.Result Output Reason width) :=
  let raw := ExceptT.run (SourcePruningEnumerationEntry.enter caller.checked.native.machine.heap r uv before.core)
  (raw, match raw with
    | [.ok ((target, _handle, scs, parent@(.node _ _ _ _)), entered)] =>
        if scs.any (fun sc => EqualityTrie.isTerminal sc.trie) then none
        else some (SourcePruningEnumerationNativeContinuations.run hook checkEmpty r n p h k target scs
          (EnumerationExpandableIndex.frame entered before) (edgesOf parent) caller queries)
    | _ => none)

/-- The wrapper retains every actual entry error, rejection and unsupported observation. -/
