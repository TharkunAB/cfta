variable {Typing Key : Type} {width : Nat}

/-- Every reached caller in the actual selected prefix retains the original annotation heap. -/
theorem runPrefix_heap (P : Constraint → Prop) [DecidableEq (EdgeKey Symbol Constraint)]
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing)
    (readFuel checkFuel nativeFuel representativeFuel indexFuel callbackFuel uv : Nat)
    (caller : Caller width) (before : Cached) (queries : Queries)
    (good : SourceCurrentAllocatedNativePhysicalCompletion.Good caller.checked)
    (realized : SourcePruningEnumerationObservation.PendingRealized
      caller.checked.native.machine.heap before.core)
    (initialHeap : Heap P caller.checked.native.machine.heap) :
    match runPrefix holeKey fits admits graph templates stop order metadata readFuel checkFuel nativeFuel
      representativeFuel indexFuel callbackFuel uv caller before queries with
    | .narrowed _ _ reached _ _ _ _ _ => Heap P reached.checked.native.machine.heap
    | _ => True := by
  unfold runPrefix
  dsimp only
  generalize readEq : ExceptT.run (getValue readFuel uv before.core) = read
  cases read with
  | nil => trivial
  | cons first rest =>
      cases rest with
      | cons _ _ =>
          cases first with
          | error _ => trivial
          | ok pair =>
              obtain ⟨value, _readAfter⟩ := pair
              cases value with
              | eliminated | enumerated _ => trivial
              | unenumerated handle _ => cases handle <;> trivial
      | nil =>
          cases first with
          | error _ => trivial
          | ok pair =>
              obtain ⟨value, readAfter⟩ := pair
              cases value with
              | eliminated | enumerated _ => trivial
              | unenumerated handle scs =>
                  cases handle with
                  | none => trivial
