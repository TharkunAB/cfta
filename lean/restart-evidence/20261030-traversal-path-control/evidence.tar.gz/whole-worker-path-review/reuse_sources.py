from pathlib import Path
import json,hashlib
owner=Path('/tmp/mcfta-traversal-path-control-20261030/whole-worker-path-review');(owner/'reused').mkdir()
repo=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
sha=lambda b:hashlib.sha256(b).hexdigest()
items=[]
def reuse(bundle,filename,module,first,last):
 bdir=Path(bundle);p=bdir/filename;copied=p.read_bytes(); source=repo/(module+'.lean');full=source.read_bytes()
 pins=json.loads((bdir/'pins.json').read_text());hits=[x for x in pins if x['path']==filename];assert len(hits)==1 and hits[0]['sha256']==sha(copied)
 assert copied==b''.join(full.splitlines(keepends=True)[first-1:last])
 dest=owner/'reused'/f'{len(items)+1:03}-{module}-{first}-{last}.lean';dest.write_bytes(copied)
 items.append({'source_path':str(source),'source_bytes':len(full),'source_lines':len(full.splitlines()),'source_sha256':sha(full),'requested_start':first,'requested_end':last,'actual_start':first,'actual_end':last,'copy':str(dest.relative_to(owner)),'copy_bytes':len(copied),'copy_sha256':sha(copied),'frozen_bundle':str(bdir),'frozen_copy':filename,'frozen_pins_sha256':sha((bdir/'pins.json').read_bytes()),'whole':first==1 and last==len(full.splitlines()),'new_whole':False})
native='/tmp/mcfta-finite-prefix-control-20261030/native-path-review'
for module,last in [('SourcePruningEnumerationRecursive',128),('SourcePruningEnumerationFiniteContract',50),('SourcePruningEnumerationFiniteResources',80)]:reuse(native,'sources/reused-'+module+'.lean',module,1,last)
reuse(native,'sources/001-SourcePruningEnumerationFiniteRunStep-1-70.lean','SourcePruningEnumerationFiniteRunStep',1,70)
prepared='/tmp/mcfta-finite-prefix-control-20261030/prepared-path-review'
for module,last in [('SourcePruningEnumerationPreparedRecursive',120),('SourcePruningEnumerationPreparedFiniteResources',81)]:reuse(prepared,'reused/'+module+'.lean',module,1,last)
prior=json.loads((Path(prepared)/'reused.json').read_text())
for module in ['SourcePruningEnumerationPreparedFiniteContract','SourcePruningEnumerationPreparedFiniteRunStep','SourcePruningEnumerationPreparedFiniteCallbackResources','SourcePruningEnumerationPreparedPreparationResources','SourcePruningEnumerationPathHookInvocation','SourcePruningEnumerationSelectedContinuations']:
 for r in prior:
  if Path(r['source_path']).stem==module:reuse(prepared,r['copy'],module,r['first'],r['last'])
(owner/'reuse-ledger.json').write_text(json.dumps(items,indent=2)+'\n')
print('Verified frozen/current exact copies:',len(items))
