  have callback : ∀ extra,
      Success (recordTypes graph templates (callbackFuel + extra) metadata uv (.inl fragment)) before.core result after ∧
      ExceptT.run (recordTypes graph templates (callbackFuel + extra) metadata uv (.inl fragment) before.core) =
        [.ok (result, after)] ∧
      ∀ (recur : Metadata Typing → Caller (bits + 2) → Queries → Cached → Option Next → Result) stop order,
        continueWith recur graph templates stop order (callbackFuel + extra) metadata uv fragment caller memos.query before =
          if result.1 then .complete [] caller memos.query
          else recur result.2 caller memos.query (EnumerationExpandableIndex.frame after before)
            (SourcePruningEnumerationRestart.decision stop order result.2
              (EnumerationExpandableIndex.frame after before)) := by
    intro extra
    have actual := originalCallback extra
    refine ⟨actual.1, actual.2.1, ?_⟩
    intro recur stop order
    simp only [continueWith, actual.2.1]
    cases result with
    | mk accepted updated => cases accepted <;> rfl
  by_cases rejected : result.1 = true
  · have resources : OutcomeResources (Typing := Typing) formulas solver caller seed (.complete [] caller memos.query) := by
      refine ⟨caller, inventory, memos, Post.refl packet.context, bounded, known, rfl, rfl, ?_⟩
      intro output member
      exact False.elim (List.not_mem_nil member)
    have growth := SourcePruningEnumerationPreparedReservation.final_ge recursiveFuel seed ceiling
    refine ⟨callbackFuel, result, after, .complete [] caller memos.query,
      returned, stable, frame, types, holes, typing, callback, ?_, resources.mono growth.1 growth.2⟩
    intro extra
