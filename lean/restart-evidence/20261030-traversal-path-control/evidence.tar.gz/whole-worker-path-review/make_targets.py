from pathlib import Path
owner=Path(__file__).parent
out=['# Proposed public targets — UNCOMPILED\n\nThese are target signatures, not implemented Lean declarations. `SourcePruningEnumerationExecutionPaths.Native` and `.Prepared` are the concrete operation predicates specified in OPERATIONS-UNCOMPILED.md. No future predicate or certificate is an input. The old definitions and proofs stay unchanged.\n']
for variant,fn,reservation in [('Native','003-SourcePruningEnumerationFiniteResources-1-80.lean','SourcePruningEnumerationFiniteReservation'),('Prepared','006-SourcePruningEnumerationPreparedFiniteResources-1-81.lean','SourcePruningEnumerationPreparedReservation')]:
 s=(owner/'reused'/fn).read_text()
 context=s[s.index('namespace '):s.index('/-- Depth induction')]
 start=s.index('theorem run_finite_complete_resources\n');end=s.index(' :=\n',start)
 old=s[start:end]
 (owner/(variant.lower()+'-old-header.txt')).write_text(context+old+'\n')
 pivot=old.index('    ∃ bound outcome,')
 inputs=old[:pivot]
 last=inputs.rfind(') :\n');assert last>=0
 inputs=inputs[:last+1]+'\n    (P : EqualityTrie.Path → Prop)\n    (paths : SourcePruningEnumerationPathTransport.StatePaths P before.core)\n    (tails : ∀ index path, P (index :: path) → P path)\n    (projected : SourcePruningEnumerationPathTransport.ProjectionPaths\n      ('+reservation+'.final recursiveFuel seed ceiling).1 P) :\n'
 expr='SourcePruningEnumerationExecutionPaths.'+variant+' P holeKey fits admits graph templates\n          checkEmpty edgesOf stop order (bound + extra) recursiveFuel metadata caller memos.query before'
 eventual=inputs.replace('theorem run_finite_complete_resources\n','theorem eventual_execution_paths\n',1)+'    ∃ bound, ∀ extra,\n      '+expr.replace('          checkEmpty','        checkEmpty')
 combined=inputs.replace('theorem run_finite_complete_resources\n','theorem run_finite_complete_resources_paths\n',1)+old[pivot:]+' ∧\n      ∀ extra, '+expr
 # Check literal old-header recovery after removing only added inputs/name/conjunct.
 recover=inputs[:inputs.index('\n    (P : EqualityTrie.Path')]+ ' :\n'+old[pivot:]
 assert recover==old
 out.append('\n## '+variant+'\n\nExact existing namespace, aliases, implicit variables, and three typeclasses:\n\n```lean\n'+context+'```\n\nPath-only companion. Prove this by depth induction with current original gates. Invoke existing finite_complete internally when a local resource producer needs the smaller worker.\n\n```lean\n'+eventual+'\n```\n\nFinal additive result. Reuse the old stable outcome and every old resource clause. The new bound is the sum of the old resource bound and the path companion bound.\n\n```lean\n'+combined+'\n```\n')
out.append('\n## Exact recovery and scope\n\nThe generator checked that deleting only the three path inputs plus P, restoring the old theorem name, and deleting the last execution conjunct recovers each complete old explicit header. Both complete old contexts remain above. All old Packet/Fits/known-Heap/selection-members/selection-length/mass/reservation inputs remain. The entire old stable-running equation and OutcomeResources conjunct remain. No Complete premise, model witness, later Packet, callback supplier, or safe-trace supplier is added.\n\nThe proposed `eventual_execution_paths` result does not assert that every local-work amount is safe. It supplies a common lower bound. The operation predicate is stronger than final OutcomePaths. It includes all local raw observations, processed/current receipts, actual hooks, and nested literal continuations.\n')
(owner/'PUBLIC-TARGETS-UNCOMPILED.md').write_text(''.join(out))
print('Target specification bytes:',(owner/'PUBLIC-TARGETS-UNCOMPILED.md').stat().st_size)
