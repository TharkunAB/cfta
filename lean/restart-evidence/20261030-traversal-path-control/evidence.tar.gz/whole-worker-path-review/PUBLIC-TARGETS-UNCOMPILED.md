# Proposed public targets — UNCOMPILED

These are target signatures, not implemented Lean declarations. `SourcePruningEnumerationExecutionPaths.Native` and `.Prepared` are the concrete operation predicates specified in OPERATIONS-UNCOMPILED.md. No future predicate or certificate is an input. The old definitions and proofs stay unchanged.

## Native

Exact existing namespace, aliases, implicit variables, and three typeclasses:

```lean
namespace MicroCFTA.SourcePruningEnumerationRecursive
open EnumerationState InternedConstructorTemplates
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentConstrainedCapGeneratedQueryResources (Fits)
open SourcePruningEnumerationIncomingReservation (Seed)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Metadata" => SourcePruningRecordTypes.Metadata
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
variable {Typing Key : Type} {bits : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

```

Path-only companion. Prove this by depth induction with current original gates. Invoke existing finite_complete internally when a local resource producer needs the smaller worker.

```lean
theorem eventual_execution_paths
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool)) (order : Metadata Typing → List Nat → Option Nat)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (recursiveFuel : Nat) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos) (before : Cached) (metadata : Metadata Typing)
    (seed : Seed) (ceiling : Nat)
    (packet : Packet formulas solver inventory caller memos metadata before)
    (bounded : Fits seed.2 caller.checked)
    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)
    (selectionMembers : ∀ entry rows depth free, ∀ edge ∈ edgesOf (.node entry rows depth free), edge ∈ rows)
    (selectionLength : ∀ entry rows depth free, (edgesOf (.node entry rows depth free)).length ≤ rows.length)
    (initialMass : SourcePruningEnumerationPrefixAdmission.suspendedBound before.core ≤ ceiling)
    (reserved : SourcePruningEnumerationFiniteReservation.Reserved bits recursiveFuel seed ceiling)
    (P : EqualityTrie.Path → Prop)
    (paths : SourcePruningEnumerationPathTransport.StatePaths P before.core)
    (tails : ∀ index path, P (index :: path) → P path)
    (projected : SourcePruningEnumerationPathTransport.ProjectionPaths
      (SourcePruningEnumerationFiniteReservation.final recursiveFuel seed ceiling).1 P) :
    ∃ bound, ∀ extra,
      SourcePruningEnumerationExecutionPaths.Native P holeKey fits admits graph templates
        checkEmpty edgesOf stop order (bound + extra) recursiveFuel metadata caller memos.query before
```

Final additive result. Reuse the old stable outcome and every old resource clause. The new bound is the sum of the old resource bound and the path companion bound.

```lean
theorem run_finite_complete_resources_paths
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool)) (order : Metadata Typing → List Nat → Option Nat)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (recursiveFuel : Nat) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos) (before : Cached) (metadata : Metadata Typing)
    (seed : Seed) (ceiling : Nat)
    (packet : Packet formulas solver inventory caller memos metadata before)
    (bounded : Fits seed.2 caller.checked)
    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)
    (selectionMembers : ∀ entry rows depth free, ∀ edge ∈ edgesOf (.node entry rows depth free), edge ∈ rows)
    (selectionLength : ∀ entry rows depth free, (edgesOf (.node entry rows depth free)).length ≤ rows.length)
    (initialMass : SourcePruningEnumerationPrefixAdmission.suspendedBound before.core ≤ ceiling)
    (reserved : SourcePruningEnumerationFiniteReservation.Reserved bits recursiveFuel seed ceiling)
    (P : EqualityTrie.Path → Prop)
    (paths : SourcePruningEnumerationPathTransport.StatePaths P before.core)
    (tails : ∀ index path, P (index :: path) → P path)
    (projected : SourcePruningEnumerationPathTransport.ProjectionPaths
      (SourcePruningEnumerationFiniteReservation.final recursiveFuel seed ceiling).1 P) :
    ∃ bound outcome,
      (∀ extra, run holeKey fits admits graph templates checkEmpty edgesOf stop order (bound + extra) recursiveFuel
        metadata caller memos.query before = outcome) ∧
      OutcomeResources formulas solver caller
        (SourcePruningEnumerationFiniteReservation.final recursiveFuel seed ceiling) outcome ∧
      ∀ extra, SourcePruningEnumerationExecutionPaths.Native P holeKey fits admits graph templates
          checkEmpty edgesOf stop order (bound + extra) recursiveFuel metadata caller memos.query before
```

## Prepared

Exact existing namespace, aliases, implicit variables, and three typeclasses:

```lean
namespace MicroCFTA.SourcePruningEnumerationPreparedRecursive
open EnumerationState InternedConstructorTemplates
open SourcePruningEnumerationRecursive (Packet Output)
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentConstrainedCapGeneratedQueryResources (Fits)
open SourcePruningEnumerationIncomingReservation (Seed)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Metadata" => SourcePruningRecordTypes.Metadata
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
variable {Typing Key : Type} {bits : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

```

Path-only companion. Prove this by depth induction with current original gates. Invoke existing finite_complete internally when a local resource producer needs the smaller worker.

```lean
theorem eventual_execution_paths
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool)) (order : Metadata Typing → List Nat → Option Nat)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (recursiveFuel : Nat) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos) (before : Cached) (metadata : Metadata Typing)
    (seed : Seed) (ceiling : Nat)
    (packet : Packet formulas solver inventory caller memos metadata before)
    (bounded : Fits seed.2 caller.checked)
    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)
    (selectionMembers : ∀ entry rows depth free, ∀ edge ∈ edgesOf (.node entry rows depth free), edge ∈ rows)
    (selectionLength : ∀ entry rows depth free, (edgesOf (.node entry rows depth free)).length ≤ rows.length)
    (initialMass : SourcePruningEnumerationPrefixAdmission.suspendedBound before.core ≤ ceiling)
    (reserved : SourcePruningEnumerationPreparedReservation.Reserved bits recursiveFuel seed ceiling)
    (P : EqualityTrie.Path → Prop)
    (paths : SourcePruningEnumerationPathTransport.StatePaths P before.core)
    (tails : ∀ index path, P (index :: path) → P path)
    (projected : SourcePruningEnumerationPathTransport.ProjectionPaths
      (SourcePruningEnumerationPreparedReservation.final recursiveFuel seed ceiling).1 P) :
    ∃ bound, ∀ extra,
      SourcePruningEnumerationExecutionPaths.Prepared P holeKey fits admits graph templates
        checkEmpty edgesOf stop order (bound + extra) recursiveFuel metadata caller memos.query before
```

Final additive result. Reuse the old stable outcome and every old resource clause. The new bound is the sum of the old resource bound and the path companion bound.

```lean
theorem run_finite_complete_resources_paths
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool)) (order : Metadata Typing → List Nat → Option Nat)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (recursiveFuel : Nat) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos) (before : Cached) (metadata : Metadata Typing)
    (seed : Seed) (ceiling : Nat)
    (packet : Packet formulas solver inventory caller memos metadata before)
    (bounded : Fits seed.2 caller.checked)
    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)
    (selectionMembers : ∀ entry rows depth free, ∀ edge ∈ edgesOf (.node entry rows depth free), edge ∈ rows)
    (selectionLength : ∀ entry rows depth free, (edgesOf (.node entry rows depth free)).length ≤ rows.length)
    (initialMass : SourcePruningEnumerationPrefixAdmission.suspendedBound before.core ≤ ceiling)
    (reserved : SourcePruningEnumerationPreparedReservation.Reserved bits recursiveFuel seed ceiling)
    (P : EqualityTrie.Path → Prop)
    (paths : SourcePruningEnumerationPathTransport.StatePaths P before.core)
    (tails : ∀ index path, P (index :: path) → P path)
    (projected : SourcePruningEnumerationPathTransport.ProjectionPaths
      (SourcePruningEnumerationPreparedReservation.final recursiveFuel seed ceiling).1 P) :
    ∃ bound outcome,
      (∀ extra, run holeKey fits admits graph templates checkEmpty edgesOf stop order (bound + extra) recursiveFuel
        metadata caller memos.query before = outcome) ∧
      OutcomeResources formulas solver caller
        (SourcePruningEnumerationPreparedReservation.final recursiveFuel seed ceiling) outcome ∧
      ∀ extra, SourcePruningEnumerationExecutionPaths.Prepared P holeKey fits admits graph templates
          checkEmpty edgesOf stop order (bound + extra) recursiveFuel metadata caller memos.query before
```

## Exact recovery and scope

The generator checked that deleting only the three path inputs plus P, restoring the old theorem name, and deleting the last execution conjunct recovers each complete old explicit header. Both complete old contexts remain above. All old Packet/Fits/known-Heap/selection-members/selection-length/mass/reservation inputs remain. The entire old stable-running equation and OutcomeResources conjunct remain. No Complete premise, model witness, later Packet, callback supplier, or safe-trace supplier is added.

The proposed `eventual_execution_paths` result does not assert that every local-work amount is safe. It supplies a common lower bound. The operation predicate is stronger than final OutcomePaths. It includes all local raw observations, processed/current receipts, actual hooks, and nested literal continuations.
