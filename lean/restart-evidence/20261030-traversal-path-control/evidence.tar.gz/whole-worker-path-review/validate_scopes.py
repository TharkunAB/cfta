from pathlib import Path
import json,hashlib,collections
owner=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
acq=json.loads((owner/'acquisitions.json').read_text());loc=json.loads((owner/'locators.json').read_text());reuse=json.loads((owner/'reuse-ledger.json').read_text())
expected={'SourcePruningEnumerationFiniteSiblingResources.lean','SourcePruningEnumerationPreparedFiniteSiblingResources.lean'}
assert {Path(r['source_path']).name for r in acq if r['whole']}==expected
assert sum(r['whole'] for r in acq)==2
scope={}
for kind,records in [('new_cut',acq),('new_locator',loc),('reused',reuse)]:
 for r in records:
  src=Path(r['source_path']);full=src.read_bytes();assert len(full)==r['source_bytes'] and sha(full)==r['source_sha256']
  b=(owner/r['copy']).read_bytes();assert len(b)==r['copy_bytes'] and sha(b)==r['copy_sha256']
  if kind=='new_locator':
   indexes=r['actual_lines'];lines=full.decode().splitlines(keepends=True)
   assert b==''.join(f'{i}:{lines[i-1]}' for i in indexes).encode()
  else:
   indexes=list(range(r['actual_start'],r['actual_end']+1));assert b==b''.join(full.splitlines(keepends=True)[r['actual_start']-1:r['actual_end']])
  if kind=='reused':
   bundle=Path(r['frozen_bundle']);pins=(bundle/'pins.json').read_bytes();assert sha(pins)==r['frozen_pins_sha256']
   original=(bundle/r['frozen_copy']).read_bytes();assert original==b
  q=scope.setdefault(str(src),{'source_bytes':len(full),'source_lines':len(full.splitlines()),'source_sha256':sha(full),'new_cut':set(),'new_locator':set(),'reused':set()});q[kind].update(indexes)
result=[]
for src,r in sorted(scope.items()):
 new=r['new_cut']|r['new_locator'];reused=r['reused'];newonly=new-reused;union=new|reused
 result.append({'source_path':src,'source_bytes':r['source_bytes'],'source_lines':r['source_lines'],'source_sha256':r['source_sha256'],'new_cut_lines':sorted(r['new_cut']),'new_locator_lines':sorted(r['new_locator']),'reused_lines':sorted(reused),'new_union_lines':sorted(new),'new_only_lines':sorted(newonly),'all_union_lines':sorted(union),'new_fraction':len(new)/r['source_lines'],'all_fraction':len(union)/r['source_lines']})
(owner/'scope-unions.json').write_text(json.dumps(result,indent=2)+'\n')
note=json.loads((owner/'note-pin.json').read_text());assert sha((owner/'current-note.md').read_bytes())==note['sha256']
records=[]
for variant,fn in [('native','003-SourcePruningEnumerationFiniteResources-1-80.lean'),('prepared','006-SourcePruningEnumerationPreparedFiniteResources-1-81.lean')]:
 s=(owner/'reused'/fn).read_text();start=s.index('theorem run_finite_complete_resources\n');end=s.index(' :=\n',start);header=s[start:end]
 saved=(owner/(variant+'-old-header.txt')).read_text();assert saved.endswith(header+'\n')
 records.append({'variant':variant,'old_header_sha256':sha(header.encode()),'saved_context_and_header_sha256':sha(saved.encode()),'old_implicit_instances':['DecidableEq Symbol','DecidableEq (EdgeKey Symbol Constraint)','DecidableEq Node'],'header_recovery':'make_targets.py executed its literal recovery assertion successfully; all added inputs/conjuncts are in PUBLIC-TARGETS-UNCOMPILED.md'})
(owner/'target-header-checks.json').write_text(json.dumps(records,indent=2)+'\n')
(owner/'scope-decision.json').write_text(json.dumps({'whole_body_limit':2,'new_whole_bodies':sorted(expected),'named_before_acquisition':True,'parent_explicitly_approved_named_bodies':True,'new_source_displays_truncated':False,'compiler_commands_by_owner':0,'new_lean_declarations_by_owner':0,'new_lean_proofs_claimed':0},indent=2)+'\n')
print('Validated',len(acq),'new cuts,',len(loc),'locators,',len(reuse),'frozen reuses and',len(scope),'current source identities.')
print('New whole source bodies:',sum(r['whole'] for r in acq))
print('Other new source fractions:')
for r in result:
 if r['new_fraction'] and Path(r['source_path']).name not in expected:print(Path(r['source_path']).name,len(r['new_union_lines']),r['source_lines'])
