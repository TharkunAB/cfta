from pathlib import Path
import sys,re,hashlib,json
owner=Path(__file__).parent
source=Path(sys.argv[1]);pattern=sys.argv[2];b=source.read_bytes();lines=b.decode().splitlines(keepends=True)
ledger=owner/'locators.json';records=json.loads(ledger.read_text()) if ledger.exists() else []
matched=[i for i,l in enumerate(lines,1) if re.search(pattern,l)]
copy=''.join(f'{i}:{lines[i-1]}' for i in matched).encode()
(owner/'locators').mkdir(exist_ok=True);p=owner/'locators'/f'{len(records)+1:03}-{source.name}.txt';p.write_bytes(copy)
r={'source_path':str(source),'source_bytes':len(b),'source_lines':len(lines),'source_sha256':hashlib.sha256(b).hexdigest(),'requested_regex':pattern,'actual_lines':matched,'copy':str(p.relative_to(owner)),'copy_bytes':len(copy),'copy_sha256':hashlib.sha256(copy).hexdigest()}
records.append(r);ledger.write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(r));print(copy.decode(),end='')
