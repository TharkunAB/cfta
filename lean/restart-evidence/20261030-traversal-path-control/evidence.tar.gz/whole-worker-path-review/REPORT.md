# Whole-worker path contract review

Status: completed bounded source-only design review. No new Lean theorem or definition was compiled or installed by this owner. The full CFTA goal remains active.

## Recommendation

Prove a separate eventual execution-path theorem for each actual fixed-depth worker. Then conjoin it with the unchanged existing `finite_complete` result. Do not copy the resource induction. Do not add a future Complete, callback, Packet, or trace certificate as a new public input.

The path companion should retain the old current Packet/Fits/known-Heap/selection/mass/reservation gates. Its only added inputs should be initial StatePaths, suffix closure, and ProjectionPaths for the COMPUTED final reservation forecast. Its conclusion should be:

```text
exists pathBound, forall extra,
  ExecutionPaths P (the literal run at pathBound+extra and recursive capacity D)
```

`OPERATIONS-UNCOMPILED.md` specifies ExecutionPaths by recursion on D and the actual source operations. `PUBLIC-TARGETS-UNCOMPILED.md` contains both complete proposed public interfaces, their unchanged original contexts, and the additive resource/path results. These documents are specifications, not checked Lean declarations. There is no `.lean` skeleton with an unproved theorem or placeholder.

## Concrete scope of ExecutionPaths

The operation property must require all of the following:

- Initial cache StatePaths and paths for every retained output/failure Core.
- The actual selected prefix's retained checked caches and every successful raw read/check/action/restart/right-recording row.
- Every actual native entry or prepared preparation raw row, including unsupported or malformed observations.
- All processed receipts and the current stopped receipt of the actual fold BEFORE finish. Include each retained ChildDispatch observation through the checked all-row observation predicate.
- Every actual ordinary HookInvocation input and its full callback raw rows. Include callbacks with no outputs and the current stopped hook outside the processed prefix.
- Both Prepared opaque branches. They use ReceiptContinuation rather than an ordinary list Invocation. A complete opaque receipt invokes the same literal callback and can recurse.
- The exact smaller-depth parked call and every literal singleton-false Left callback call, recursively with the SAME P.

OutcomePaths alone cannot state this. Both actual finish functions erase processed receipts in the complete case. The proposed operation property includes retained OutcomePaths AND the intermediate fold/callback facts. It does not depend on output membership.

The exact argument distinctions are material:

1. Parked recursion uses the returned `next`. An equality with a fresh restart decision needs the existing actual restart equations.
2. The false Right case enters its stage with the retained candidate `after`. The source ignores the displayed Right callback Core. SelectedPrefixPaths still checks that Core.
3. The Left false call uses the updated Left metadata, actual head caller and queries, `frame observed headCache`, and the original configured stop/order functions.
4. Later siblings retain the captured enumeration cache and metadata. They receive native effects from the completed earlier hook.
5. A Prepared parent can differ from the original stored native handle. Preserve actual prepared-parent availability and free=[]; do not replace them with the Native worker's stored-handle lookup premise.
6. Ordinary scans use the returned entry target. The callback closure records at the outer selected uv. Identify them only with existing actual entry/resource equations.

## Existing local facts must be reused

The local hook-input bridge is already proved. Existing Invocation.paths, paths_of_forecast, paths_of_native_initial, and paths_of_prepared_initial derive actual hook input paths once captured input paths and physical guard coverage are available. The checked PathCallbackExecution native/prepared false laws already expose the literal recursive call and frame paths. Neither local bridge is a missing theorem.

The current note records the selected-prefix, Entry/Opaque, recording, raw observation, and captured receipt foundations. Root subsequently reported three more checked laws for stopped ChildTraversal observations, captured observation composition, and prepared opaque observation composition. Those new laws are local arbitrary-work laws. This owner did not rerun their checks or review all their proof bodies.

The new obligation is to compose these local facts through the ACTUAL nested recursive calls and all their reached native endpoints. An input path fact does not supply the nested execution property.

## Why not claim a completely arbitrary-work worker theorem

The named endpoint heap laws preserve the original closed guard alphabet for every local outcome, including raw faults. They still retain genuine initial resources:

- IncomingNode.run_heap: Closed alphabet, Context, Fits profile, Room bits profile, PendingRealized, incoming availability, incoming free=[], and initial alphabet Heap.
- Dispatch.dispatch_heap: Closed alphabet, Context, Fits, Room, PendingRealized, and initial alphabet Heap.
- SelectedStep.runPrefix_heap: initial native Good, PendingRealized, and initial Heap. Its conclusion covers the actual narrowed caller.

Their exact headers and implicit equality contexts are retained in bounded cuts. None is an arbitrary-state Context law. A path-only smaller-depth IH does not itself supply those reached resources at low work. A completely arbitrary-work whole-worker result is not disproved here, but these local APIs alone do not establish it. Proving such a result would need an additional current-resource invariant at every continuing endpoint.

The eventual companion avoids that new obligation. Existing resource producers already establish actual reached resources at a sufficient common local-work amount. Use them, with the already proved smaller-depth finite_complete internally, and add the new path IH at those actual inputs. No satisfying-model gate is needed.

## Exact induction obligations

The two newly read sibling bodies make the common structure explicit. Native uses SourcePruningEnumerationNativeFiniteSiblingResources; Prepared uses SourcePruningEnumerationPreparedFiniteSiblingResources.

At D=0, the exact starting decision gives output at before, no output, or an exhausted failure retaining before. Initial StatePaths suffices. A non-expanding decision also needs no recursive IH at positive D.

At D=n+1, obtain the existing actual stable prefix and its current resource facts. Apply the checked prefix path theorem at every larger work amount. Then follow the same ordered source cases:

- Empty parked/action or true Right result: retain all raw paths; there is no nested call.
- Singleton parked restart: use the exact raw frame/restart equations and old current resource packet, then apply the n path IH.
- Native stage: retain every entry row. Only the actual singleton node/nonterminal case enters the sibling scan.
- Prepared stage: retain every preparation row and its exact native result. The done/singleton branch selects ordinary or either opaque route exactly as the source does.
- Unsupported remainder: retain the selected/ordinary/preparation failure paths. Do not assert Context at a retained fault heap.

For a sibling list, the old resource proof's exact cases are:

1. Empty list: no receipt and no Invocation.
2. Unsupported head: stop at the actual unhandled receipt; no hook or suffix.
3. Completed continuation: retain actual receipt paths, all callback observations and any n recursive execution. Use the old callback Post/Packet/Fits/known facts at the actual hook endpoint. Apply the suffix path induction there with the same captured cache and metadata.
4. Stopped continuation: retain the complete current receipt plus the nested reason and outputs. This current receipt is not in processed.
5. Rejected or continuable stopped receipt: no hook. Use the exact advance endpoint. NativeBranches.advance continues a stopped receipt only for the explicit successful empty observation with a candidate; arbitrary raw faults do not advance.

Use old `head_finite_complete_resources` producers and their receipt/path companions to obtain actual local witnesses. The Native source calls SourcePruningEnumerationNativeHookResources; Prepared calls SourcePruningEnumerationPreparedNativeHookResources. Keep the old recursive Complete parameter internal by instantiating the already proved finite_complete at n. It must not become a new public premise.

At each smaller-depth application, derive Packet/Fits/known/mass/reservation from the old resource producer. Derive StatePaths from the checked local path producer. Use existing stage/final inclusions to transport the smaller computed final guard forecast into the outer one. Instantiate the SAME P. Align the actual stable head/callback equations at a bound that also pays the path IH and suffix path bound.

This review does not claim a completed Lean proof of those inclusions or a new global bound. The current source budget is sufficient for the concrete contract and case plan. Before full implementation, inspect the complete callback packet/forecast construction in SourcePruningEnumerationFiniteCallbackResources (118 lines) and SourcePruningEnumerationPreparedFiniteCallbackResources (136 lines) under a fresh scope. Only the Prepared slices 15-64 and 83-108 were reused here. These are precise next proof-body accesses, not new public hypotheses.

## Final composition preserves every old clause

Let B and outcome be supplied by the unchanged old resource theorem. Let C be the new path companion's bound. Choose W=B+C.

- Use the old stable-running equation with extra=C+extra.
- Use the path companion with extra=B+extra.
- Rewrite addition by associativity and commutativity.
- Keep the exact old outcome and its entire OutcomeResources conjunct.

The final result appends execution paths at every W+extra. It preserves all old resource/Packet clauses through OutcomeResources. It does not replace them with a path predicate. The target generator checked literal recovery of both old explicit headers after deleting only added P inputs/conjuncts and restoring the old name. Both original contexts retain all three equality instances.

## Original input and global control boundary

The intermediate computed forecast premise must later be discharged using the SAME fixed guard-derived carrier:

```text
ForecastPathDomain.carrier
  (SourceCurrentNativeClosedGuardAlphabet.originalAlphabet literals) initial
```

This is a finite list of concrete initial/projected paths and their suffixes. It bounds member path lengths. It is independent of D and later native handles. Existing original guard/forecast inclusion and projected-path laws should supply the temporary projection premise under their exact admission gates. The eventual original wrapper must prove that implication; it must not request a future trace certificate.

The new whole-execution path theorem would still be a fixed-D theorem. It would permit exhaustion. Sufficient original recursive capacity for a policy-permitted finite ordered prefix remains open. In particular, finite key shapes at the same handle do not bound native handle renewal, raw multiplicity, branch/slot work, or neutral steps. A chosen satisfying finite witness does not rank incompatible earlier alternatives. This review proves no unrestricted coverage result and no full-worker counterexample.

No Haskell source was read or changed. No Haskell fix or runtime defect was established. Root retains FINDINGS ownership.

## Source scopes and status evidence

The exact current note was copied first and pinned in note-pin.json. It describes source dce9c1fc82ce2b14221783657537d0977639c29d. Root later reported pushed source 12447ebf0f388a2047a9e6cdafcbf42080f8ebdb, Audit4729/82866, public1150/100, and three new passing laws. This later status is Root-reported context, not an independent Git/compiler/public-output verification by this owner.

There are exactly TWO new whole production bodies. They were named to Root before acquisition and explicitly approved:

- SourcePruningEnumerationFiniteSiblingResources: 1-226/226, 16219 bytes, SHA256 b49f81afb8c80c9dfdfc9c516b8d720f41118160edc61075896b1ee81702e0a8.
- SourcePruningEnumerationPreparedFiniteSiblingResources: 1-229/229, 16487 bytes, SHA256 dac763a18d72f6dd54fdca3c2a9716079bc8dca823eaebd0aa6c554be82d71b6.

Both complete proof-bearing displays were read without truncation. No third whole or near-whole body was acquired through cuts. The remaining new contiguous unions are IncomingGuardHeap 1-51/112, DispatchGuardHeap 1-48/131, SelectedPrefixGuardHeap 1-64/157, NativeBranches 13-27/116 plus sparse locators, and NativeOrdinaryContinuations 16-35/100 plus sparse locators. PathCallbackExecution has only five locator lines.

Fourteen exact frozen copies were reused after frozen-manifest hash checks and equality with the corresponding CURRENT source slice. They include full Native Recursive, FiniteContract and FiniteResources, full PreparedRecursive and PreparedFiniteResources, and the earlier Native RunStep 1-70/75 near-whole scope. These are recorded as frozen reuse, not new whole acquisitions. Other Prepared contract/run-step/callback/preparation/Invocation/SelectedContinuations scopes remain exact partial copies in reuse-ledger.json.

Every acquisition records requested and actual endpoints, current full source bytes/lines/SHA, and copied bytes/SHA. Locator records retain exact matched lines. scope-unions.json includes new, reused, and combined per-source unions. The filename/line-count discovery read metadata only; it did not acquire other proof bodies.

No source display was truncated in this task. No compiler/evaluator/native/network/Git/board command ran. No compiler failure or experimental Lean draft was created. All scripts and mutations stayed in this owner directory. All prior frozen bundles stayed unchanged. All final files are pinned and read-only after sealing.
