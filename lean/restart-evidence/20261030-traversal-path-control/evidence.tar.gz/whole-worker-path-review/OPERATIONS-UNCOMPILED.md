# Concrete execution-path property — UNCOMPILED specification

This document specifies new propositions. It does not claim that they exist in production or have a proof. PUBLIC-TARGETS-UNCOMPILED.md gives the proposed public signatures. Existing theorem and function names below refer to the pinned current sources.

## Fixed parameters and recursion

Fix the exact current configuration:

```text
holeKey fits admits graph templates checkEmpty edgesOf stop order
P : EqualityTrie.Path -> Prop
w : Nat
```

Keep the three original equality instances. The native and prepared propositions remain separate. Their Failure types differ. Their ordinary/preparation stages also differ.

Proposed curried predicates:

```text
ResumeNative   P configuration w D metadata caller queries before decision : Prop
ResumePrepared P configuration w D metadata caller queries before decision : Prop
Native         P configuration w D metadata caller queries before          : Prop
Prepared       P configuration w D metadata caller queries before          : Prop
```

`Native` is `ResumeNative` at `SourcePruningEnumerationRestart.decision stop order metadata before`. `Prepared` uses the same decision and `ResumePrepared`. These are exact aliases for the starting calls in each actual worker's `run`.

Define the Resume predicates by recursion on D. All nested Resume occurrences below use n while the enclosing expanding call has n+1. No future execution certificate is an argument.

## Retained data predicates

Use the checked `PathSelectedRaw.RawPaths`, `PathSelectedRaw.SelectedPrefixPaths`, `PathObservationRaw.ObservationPaths`, and `PathPreparedOpaque.ReceiptPaths`. Do not add a second version of those definitions.

A proposed `FullReceiptPaths P receipt` conjoins the existing ReceiptPaths with this clause:

```text
receipt = stopped outer observation candidate -> ObservationPaths P observation
```

Use the actual observation tuple. Other receipt constructors add no observation clause. Optional receipt `none` adds no receipt-path clause. This checks current stored observations only. It does not invent a discarded observation history.

Define separate retained Failure predicates by the actual constructors:

| Failure constructor | Required paths |
| --- | --- |
| exhausted uv metadata before | StatePaths P before.core |
| selected uv observed | SelectedPrefixPaths P observed |
| callback uv raw | RawPaths P raw |
| Native ordinary uv raw | RawPaths P raw |
| Prepared preparation uv observation | RawPaths P observation.1 |
| alternatives uv processed (edge current) | FullReceiptPaths for every processed receipt and each optional current receipt |
| alternatives uv processed (continuation receipt reason endpoint) | FullReceiptPaths for every processed receipt and the current receipt, plus the same variant's retained Failure predicate for reason |

The Prepared preparation's native result can retain a fault heap. A stored-path predicate on enumeration Core does not assert Context or semantic validity at that heap.

`OutcomePaths` requires StatePaths P at every output.cache.core. For a stopped outcome it also requires the corresponding retained Failure predicate. Define Native and Prepared versions with their exact Failure types.

`FoldDataPaths` requires FullReceiptPaths for every processed receipt, StatePaths at every output cache, and the corresponding current-stop predicate for a stopped fold. It applies to the actual fold value BEFORE `finish`. This clause is required even when `finish` completes with no outputs. Successful finish discards its processed list.

## Exact Left callback property

For variant F, define the literal hook at smaller capacity n:

```text
hook := F.continueWith
  (F.resume holeKey fits admits graph templates checkEmpty edgesOf stop order w n)
  graph templates stop order w capturedMetadata selectedUV
```

At a hook input `(fragment, headCaller, headQueries, headCache)`, set:

```text
raw := ExceptT.run
  (SourcePruningRecordTypes.recordTypes graph templates w capturedMetadata
    selectedUV (inl fragment) headCache.core)
```

The proposed `LeftPathsF n` requires:

1. StatePaths P headCache.core.
2. RawPaths P raw, for EVERY successful raw row, including true rows and malformed multirow observations.
3. OutcomePaths for the literal `hook fragment headCaller headQueries headCache`.
4. Only in the exact singleton-false branch `raw = [ok ((false, updated), observed)]`, let `after := EnumerationExpandableIndex.frame observed headCache`. Require StatePaths P after.core and:

```text
ResumeF P configuration w n updated headCaller headQueries after
  (SourcePruningEnumerationRestart.decision stop order updated after)
```

A singleton true row causes no recursive call. A malformed raw list causes no recursive call. Both remain covered by RawPaths and the callback's actual OutcomePaths.

The checked `PathCallbackExecution.native_false_paths_of_forecast` and `prepared_false_paths_of_forecast` already expose the literal false call and its input paths. Reuse them. Do not list their local frame/call-equation bridge as missing. The new obligation is the nested Resume property and transport through its actual reached native endpoint.

## Actual ordered sibling scan

For the exact captured inputs `(target, scs, captured, edges, scanCaller, scanQueries)`, set:

```text
folded := SourcePruningEnumerationNativeContinuations.run hook checkEmpty
  w w w w w target scs captured edges scanCaller scanQueries
```

The proposed `SiblingPathsF n` requires FoldDataPaths for this exact folded value. It also requires, for EVERY actual invocation:

```text
SourcePruningEnumerationHookInvocation.Invocation hook checkEmpty
  w w w w w target scs captured edges scanCaller scanQueries
  fragment headCaller headQueries headCache
```

that `LeftPathsF n` holds at that literal input.

This quantification has no output-membership condition. It includes complete hooks with no outputs. It includes the current stopped hook, which is outside the processed prefix. The checked Invocation.paths variants already supply the local hook input path fact from captured input paths and physical guard coverage. Reuse those laws. The stronger property adds the callback observations and nested literal recursive call.

Later siblings use the same captured enumeration cache and metadata. They use the native caller and queries returned by the preceding completed hook. The new proof must transport current native resources and guard inclusion at that exact endpoint. It must not replace the captured cache with a prior sibling's output cache.

## Native stage

The native worker calls:

```text
ordinary := SourcePruningEnumerationNativeOrdinaryContinuations.run hook
  checkEmpty w w w w w selectedUV edgesOf reached after saved
```

The stage property requires RawPaths P ordinary.1 and FoldDataPaths for each actual `ordinary.2 = some folded`.

Expand only the actual source case:

```text
raw := ExceptT.run
  (SourcePruningEnumerationEntry.enter reached.checked.native.machine.heap
    w selectedUV after.core)
```

When this raw value is exactly `[ok ((target, handle, scs, parent@(node ...)), entered)]` and no suspended trie is terminal, require SiblingPathsF n at:

```text
captured  = EnumerationExpandableIndex.frame entered after
edges     = edgesOf parent
scanCaller = reached
scanQueries = saved
```

The scan target is the returned target. The hook still records at the outer selectedUV, as the actual source closure does. Do not identify them without the existing entry/resource equations. Other entry shapes, including terminal buckets, yield no native ordinary scan. Their full raw rows still satisfy RawPaths.

## Prepared stage, including both opaque cases

The prepared worker calls:

```text
prepared := SourcePruningEnumerationSelectedContinuations.run hook checkEmpty
  w w w w w w w selectedUV edgesOf reached after saved
observation := SourcePruningEnumerationSelectedPreparation.run w w selectedUV reached after
```

Require RawPaths P observation.1, which is the same preparation raw list retained by the actual result. Require FoldDataPaths for every actual `prepared.2 = some folded`.

Only when the actual observation has `observation.2 = some (done value heap)` and `observation.1 = [ok ((target, handle, scs, decoded), entered)]`, form:

```text
captured   = EnumerationExpandableIndex.frame entered after
scanCaller = SourcePruningEnumerationSelectedValueCaller.advance reached heap
```

Use the source branch order:

- If any suspended trie is terminal, use the opaque property below, even if value is a node.
- Otherwise, if value is a node parent, require SiblingPathsF n for `edgesOf parent`, target, scs, captured, scanCaller, and saved.
- Otherwise use the opaque property.

The opaque property inspects the exact value:

```text
receipt := SourcePruningEnumerationSelectedOpaqueDispatch.run checkEmpty
  w w w w w target scs value scanCaller captured saved
folded := SourcePruningEnumerationReceiptContinuation.run hook receipt
```

Require FullReceiptPaths for each actual optional receipt and FoldDataPaths for this actual folded value. If the receipt is exactly `some (complete fragment headCaller headQueries headCache)`, require LeftPathsF n at that input. This direct hook clause is separate from ordinary HookInvocation over a list of edges. It covers both opaque branches.

The checked all-row prepared opaque law supplies the actual receipt/observation path part. It is not a whole recursive-callback theorem. Its new Root validation is recorded as Root-reported status in REPORT.md, not as an independently rerun check here.

The prepared parent can differ from the original stored native handle. The resource proof must retain actual prepared-parent availability and free=[], rather than substitute the native worker's old-handle lookup premise.

## Resume predicates and branch order

Each ResumeF requires StatePaths P before.core and OutcomePaths for the literal actual `F.resume ... w D metadata caller queries before decision`. It then requires the following local-operation clauses.

For decision none, done, or stuck, there are no nested local operations. An expanding call at D=0 retains the actual exhausted cache. These cases need no path forecast at another state.

For decision `some (expand uv)` at D=n+1, form the exact common prefix:

```text
prefix := SourcePruningEnumerationSelectedStep.runPrefix holeKey fits admits
  graph templates stop order metadata w w w w w w uv caller before queries
```

Require SelectedPrefixPaths P prefix. Follow the SAME ordered cases as the actual worker:

1. Parked with a staged cache and an empty raw restart: no nested call.
2. Parked with staged cache parked and exactly `[ok ((updated, next), core)]`: require ResumeF at capacity n with metadata updated, the same caller and queries, cache `frame core parked`, and the RETURNED next. Do not recompute next without the actual restart equation.
3. Narrowed with an empty action list: no nested call.
4. Narrowed with a singleton true right callback: no nested call.
5. Narrowed with reached/saved, candidate `some after`, singleton false right callback with metadata updated, and ordinary=None: require the corresponding Native or Prepared stage above at capacity n, captured callback metadata updated, and outer selected uv.
6. Every other actual prefix shape: no recursive or stage call. Its retained selected failure is covered by SelectedPrefixPaths and OutcomePaths.

In case 5 the worker passes the retained `after` cache to the stage. It ignores the displayed right callback Core. The specification must retain paths for that Core through SelectedPrefixPaths without substituting it for after.

This finishes the recursive definition. No clause ranges over an arbitrary unrelated continuation. Every nested obligation follows an exact source match, actual hook Invocation, or actual complete opaque receipt.

## Proof obligations at the existing sibling induction

The pinned Native sibling proof has its main cases at lines 92-224. Prepared uses lines 95-227.

- Empty list: FoldDataPaths has empty receipt/output lists. There is no Invocation.
- Unsupported head: retain the actual `.unhandled` current receipt. There is no hook or tail scan.
- Head whose actual continuation completes: prove FullReceiptPaths at the actual receipt; prove LeftPaths for a complete receipt; use the old callback resources to obtain the actual hook caller, memos, Context/Packet/Fits/known facts; apply the new suffix path induction at that endpoint and the same captured cache/metadata. Retain both append halves and all actual Invocation constructors.
- Head whose actual continuation stops: processed is empty at this head, and the current stop is `.continuation (complete ...) reason endpoint`. Prove both the current receipt paths and the nested reason paths. Do not require that this receipt belongs to processed.
- Rejected or continuable stopped receipts do not invoke the hook. The existing advance cases determine their exact suffix endpoint. NativeBranches.advance continues a stopped receipt only for the explicit successful empty observation with a candidate; arbitrary raw faults do not advance.

The smaller-depth path IH applies at each literal parked or Left-false input. The old finite_complete supplies smaller-depth Complete internally when an existing resource helper requires it. The new public target must not take that Complete as a new input.

At every IH application, obtain Packet/Fits/known Heap/mass/reservation from the existing resource producer, and derive current StatePaths by the checked local path law. Prove the smaller computed final guard list is included in the outer computed final forecast by the existing reservation stage/final inclusions. This carries the SAME P. No later Packet or trace assumption is permitted.
