from pathlib import Path
import hashlib, json, sys

area = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/tmp/mcfta-traversal-path-control-20261030')
out = Path(sys.argv[2]) if len(sys.argv) > 2 else area
review = area / 'whole-worker-path-review'
digest = lambda data: hashlib.sha256(data).hexdigest()
seal = json.loads((review / 'FROZEN').read_text())
pins = json.loads((review / 'pins.json').read_text())
assert seal['status'] == 'FROZEN; write halt'
assert digest((review / 'pins.json').read_bytes()) == seal['pins_sha256'] == 'c7c275f0f2163c8f0402d7303620a39782271e20049fbc53a2a6531f3801e4a4'
expected = {row['path']: row for row in pins}
assert len(expected) == len(pins) == seal['pinned_payload_files'] == 46
files = [path for path in review.rglob('*') if path.is_file()]
assert {str(path.relative_to(review)) for path in files} == set(expected) | {'pins.json', 'FROZEN'}
for path in files:
    assert not path.is_symlink()
    assert path.stat().st_mode & 0o222 == 0
    name = str(path.relative_to(review))
    if name in expected:
        raw = path.read_bytes()
        assert len(raw) == expected[name]['bytes'] and digest(raw) == expected[name]['sha256']
for name, field in [('REPORT.md', 'report_sha256'), ('OPERATIONS-UNCOMPILED.md', 'operations_sha256'), ('PUBLIC-TARGETS-UNCOMPILED.md', 'targets_sha256')]:
    assert digest((review / name).read_bytes()) == seal[field]
assert seal['report_sha256'] == 'ed0c26bb7347279391fdcbe24c24442f9cd8dd7ecdcbffa3426c2057b20cc55b'
acquisitions = json.loads((review / 'acquisitions.json').read_text())
reuses = json.loads((review / 'reuse-ledger.json').read_text())
for row in acquisitions + reuses:
    source = Path(row['source_path']).read_bytes()
    assert len(source) == row['source_bytes'] and digest(source) == row['source_sha256']
    lines = source.decode().splitlines(keepends=True)
    assert len(lines) == row['source_lines']
    copied = (review / row['copy']).read_bytes()
    assert copied == ''.join(lines[row['actual_start'] - 1:row['actual_end']]).encode()
    assert len(copied) == row['copy_bytes'] and digest(copied) == row['copy_sha256']
    if row in reuses:
        frozen = Path(row['frozen_bundle'])
        assert (frozen / row['frozen_copy']).read_bytes() == copied
        assert digest((frozen / 'pins.json').read_bytes()) == row['frozen_pins_sha256']
whole = [Path(row['source_path']).name for row in acquisitions if row['whole']]
scope = json.loads((review / 'scope-decision.json').read_text())
assert len(whole) == scope['whole_body_limit'] == 2
assert whole == scope['new_whole_bodies']
assert scope['named_before_acquisition'] and scope['parent_explicitly_approved_named_bodies']
assert not scope['new_source_displays_truncated']
assert scope['compiler_commands_by_owner'] == scope['new_lean_declarations_by_owner'] == scope['new_lean_proofs_claimed'] == 0
result = dict(pass_status=True, payloads=46, files_including_seals=len(files), new_whole_bodies=whole,
    new_acquisitions=len(acquisitions), exact_frozen_reuses=len(reuses), exact_current_source_slices=True,
    all_three_reports_read_in_full=True, proposal_status='UNCOMPILED', owner_compiler_commands=0,
    report_sha256=seal['report_sha256'], pins_sha256=seal['pins_sha256'])
out.mkdir(exist_ok=True)
(out / 'owned-review-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
