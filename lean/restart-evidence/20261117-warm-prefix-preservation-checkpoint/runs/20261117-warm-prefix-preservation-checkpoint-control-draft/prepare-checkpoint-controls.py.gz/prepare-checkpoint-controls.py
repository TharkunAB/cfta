from pathlib import Path
import hashlib
import json
import re
import shlex
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
work = base / '20261117-warm-prefix-preservation-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this candidate into the active Work directory'
prior_run = base / '20261117-warm-edge-initial-profile-publication'
prior_archive = base / '20261117-warm-edge-initial-profile-checkpoint'
runtime = base / '20261117-warm-prefix-preservation-publication'
prior_commit = '9182ceb0e4e374d0a2c05a8ac18bfde48ec178ea'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
resource_owner = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
resource_owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
expected = [{'kind': 'appended_owner', 'module': 'SourceCurrentAllocatedNativeCompileDispatchOrigin', 'source_path': 'lean/MicroCFTA/SourceCurrentAllocatedNativeCompileDispatchOrigin.lean', 'candidate_packet': '20261117-warm-actual-prefix-returned-interfaces-draft', 'candidate_file': 'SourceCurrentAllocatedNativeCompileDispatchOrigin.lean', 'candidate_manifest_sha256': 'c86d0d4f0a955f925d49f5983f23079f348bfb93bdfda8d218fe99951acf9114', 'raw_sha256': '3a28c3abb339aca1df4a42a3266d83501add61af555859ca7d7aa6e84efe010f', 'private_run': '20261117-warm-actual-prefix-interfaces-import-overlay-repair-check', 'private_receipt': 'INTERFACE-OVERLAY-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentAllocatedNativeCompileDispatchOrigin.compiled_node_origin_from_warm_query_finish'], 'new_private_helper_names': [], 'header_files': [{'file': 'NODE-FIRST-HEADER.lean.txt', 'sha256': 'ec2bf3e980befdf3e0bbd14da23c3bedab6ada8f9ed1a882f47281868c496fb3'}], 'append_file': 'NODE-APPEND.lean.txt', 'append_sha256': '0037372787205052f1fe0846e414553a28104144a842e9591d623ba96eaac967', 'raw_bytes': 23535, 'old_snapshot': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeCompileDispatchOrigin.lean.txt', 'old_bytes': 20549, 'old_sha256': '5ede4cb6ae69f17d711f4aad652b5282c658a296f5364ebdd0c97dbeb24abdea', 'append_offset': 20550, 'old_owner_entire_prefix_preserved': True}, {'kind': 'appended_owner', 'module': 'SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin', 'source_path': 'lean/MicroCFTA/SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin.lean', 'candidate_packet': '20261117-warm-actual-prefix-returned-interfaces-draft', 'candidate_file': 'SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin.lean', 'candidate_manifest_sha256': 'c86d0d4f0a955f925d49f5983f23079f348bfb93bdfda8d218fe99951acf9114', 'raw_sha256': '07bf47dba40902c2a24ddb09283f6828f4726682f39d7ac3d991874fa32b3bf3', 'private_run': '20261117-warm-actual-prefix-interfaces-import-overlay-repair-check', 'private_receipt': 'INTERFACE-OVERLAY-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin.checked_edge_body_origin_from_warm_query_finish'], 'new_private_helper_names': [], 'header_files': [{'file': 'EDGE-FIRST-HEADER.lean.txt', 'sha256': '336c4806b27a8b2541600e42d3b4c56eef5aa316738e370f8ca3bea62c50321d'}], 'append_file': 'EDGE-APPEND.lean.txt', 'append_sha256': '76d98dc9c3559cb48e2e3ed7b55048fb662308ffefef900a26b2dfbc0d956935', 'raw_bytes': 26840, 'old_snapshot': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin.lean.txt', 'old_bytes': 24151, 'old_sha256': 'f1b5072b7f66612d5849b990a2e862e96208c3789165f038e36fd08c1056e9fe', 'append_offset': 24152, 'old_owner_entire_prefix_preserved': True}, {'kind': 'appended_owner', 'module': 'SourceCurrentAllocatedNativeActualPrefixReturnedInduction', 'source_path': 'lean/MicroCFTA/SourceCurrentAllocatedNativeActualPrefixReturnedInduction.lean', 'candidate_packet': '20261117-warm-actual-prefix-returned-interfaces-draft', 'candidate_file': 'SourceCurrentAllocatedNativeActualPrefixReturnedInduction.lean', 'candidate_manifest_sha256': 'c86d0d4f0a955f925d49f5983f23079f348bfb93bdfda8d218fe99951acf9114', 'raw_sha256': '87f391c14509b1a22d93db95fdda31082b10ca3eb326fad90b23a885ce77abd8', 'private_run': '20261117-warm-actual-prefix-interfaces-import-overlay-repair-check', 'private_receipt': 'INTERFACE-OVERLAY-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentAllocatedNativeActualPrefixReturnedInduction.returned_at_every_actual_warm_prefix'], 'new_private_helper_names': [], 'header_files': [{'file': 'RETURNED-FIRST-HEADER.lean.txt', 'sha256': 'e24bba944ba2151e5c2eaec99f53f418d87d189f03fd06770cea7b5c90054250'}], 'append_file': 'RETURNED-APPEND.lean.txt', 'append_sha256': '056c8b8bcf93e158c6d17401ae5afd37cb3352790d24f0577c24538aad3458c7', 'raw_bytes': 24360, 'old_snapshot': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeActualPrefixReturnedInduction.lean.txt', 'old_bytes': 16207, 'old_sha256': '12318c748fc83735732bae5e2e1447c1b1563b7d64918dbe6f04857c7c123b77', 'append_offset': 16208, 'old_owner_entire_prefix_preserved': True}, {'kind': 'appended_owner', 'module': 'SourceCurrentAllocatedNativeSamePrefixKeyedChildResult', 'source_path': 'lean/MicroCFTA/SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.lean', 'candidate_packet': '20261117-warm-actual-child-reader-exports-draft', 'candidate_file': 'NODE-OWNER.lean.txt', 'candidate_manifest_sha256': 'b9622885f99465a7c9bed819747eb9da420d0054d7281c9e92e2df87e95e8360', 'raw_sha256': 'bb65734294d9f78cc574b053b2f0d4f4e0c63a98bbe41e93a8af878c871a2bc3', 'private_run': '20261117-warm-node-reader-first-check', 'private_receipt': 'NODE-READER-FIRST-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.keyed_child_law_at_actual_warm_reader'], 'new_private_helper_names': [], 'header_files': [{'file': 'NODE-FIRST-HEADER.lean.txt', 'sha256': 'adcffc043509dc566f43d6590abd8b708a1ffef15886e079ad348de8f373ed81'}], 'append_file': 'NODE-APPEND.lean.txt', 'append_sha256': '8e94e8209ebdc4ff5233fa24eb01018756868d52a874107d47656824f40df277', 'normalized_check_packet': '20261117-warm-node-reader-normal-check-layout', 'normalized_check_manifest_sha256': 'c74d48b08968d45e50702e808dbbbe17c5d5d5aafb27b5326b34ef0f468f6ab7', 'raw_bytes': 22991, 'old_snapshot': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.lean.txt', 'old_bytes': 18241, 'old_sha256': 'b843352cf3cccc4a3a87eae50ab24f4703f96e4d1a123aa099a7ad823ff9b9ce', 'append_offset': 18242, 'old_owner_entire_prefix_preserved': True}, {'kind': 'appended_owner', 'module': 'SourceCurrentAllocatedNativeSamePrefixEdgeChildResult', 'source_path': 'lean/MicroCFTA/SourceCurrentAllocatedNativeSamePrefixEdgeChildResult.lean', 'candidate_packet': '20261117-warm-actual-child-reader-exports-draft', 'candidate_file': 'EDGE-OWNER.lean.txt', 'candidate_manifest_sha256': 'b9622885f99465a7c9bed819747eb9da420d0054d7281c9e92e2df87e95e8360', 'raw_sha256': 'e889ee75375190ec7fe5c9bd22f1f9d6f3562303ddcce275eea6d5da049a3e74', 'private_run': '20261117-warm-edge-reader-first-check', 'private_receipt': 'EDGE-READER-FIRST-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentAllocatedNativeSamePrefixEdgeChildResult.edge_child_law_at_actual_warm_reader'], 'new_private_helper_names': [], 'header_files': [{'file': 'EDGE-FIRST-HEADER.lean.txt', 'sha256': '8bc50d70bfda8bbecfc67dc09e20711c1ec3b2061cf5522817b0e91e4cf6b492'}], 'append_file': 'EDGE-APPEND.lean.txt', 'append_sha256': '00cf1aeb29dd46348e3dc15747e13284eafc0b0198040a9dafc814755faca726', 'normalized_check_packet': '20261117-warm-edge-reader-normal-check-layout', 'normalized_check_manifest_sha256': '254dd23c23da8a8d0b93b2527ad433f22e8ce8e0512bc116869e6a328b64e8c6', 'raw_bytes': 17641, 'old_snapshot': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeSamePrefixEdgeChildResult.lean.txt', 'old_bytes': 13171, 'old_sha256': '17008f09917e2c8503806b9d6e458d1656efeeae8720cc27bb003cd13bd24664', 'append_offset': 13172, 'old_owner_entire_prefix_preserved': True}, {'kind': 'new_module', 'module': 'SourceCurrentNativeWarmAuxiliaryPrefixes', 'source_path': 'lean/MicroCFTA/SourceCurrentNativeWarmAuxiliaryPrefixes.lean', 'candidate_packet': '20261117-actual-warm-prefix-auxiliary-payloads-draft', 'candidate_file': 'SourceCurrentNativeWarmAuxiliaryPrefixes.lean', 'candidate_manifest_sha256': 'db16abeb585c03d27d3cd1f9da087cf52be3d9b5fd39f4819a83e79ec4cca86b', 'raw_sha256': 'e956ca145345d8e3afc96d522e597f0bd0ff937e2badd40f228ca9ebca043f97', 'private_run': '20261117-warm-auxiliary-prefixes-first-check', 'private_receipt': 'AUXILIARY-PREFIX-FIRST-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentNativeWarmAuxiliaryPrefixes.auxiliary_payloads_at_every_actual_warm_prefix'], 'new_private_helper_names': ['reference_code', 'reference_read_step'], 'header_files': [{'file': 'FIRST-HEADER.lean.txt', 'sha256': '36948f2e4affac35abb02ed8d1bf539d9bc9efa503e56ae73db037f6030f0920'}], 'raw_bytes': 31398}]
expected_overrides = {'lean/MicroCFTA/SourceCurrentAllocatedNativeCompileDispatchOrigin.lean': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeCompileDispatchOrigin.lean.txt', 'lean/MicroCFTA/SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin.lean': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin.lean.txt', 'lean/MicroCFTA/SourceCurrentAllocatedNativeActualPrefixReturnedInduction.lean': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeActualPrefixReturnedInduction.lean.txt', 'lean/MicroCFTA/SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.lean': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.lean.txt', 'lean/MicroCFTA/SourceCurrentAllocatedNativeSamePrefixEdgeChildResult.lean': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeSamePrefixEdgeChildResult.lean.txt', 'lean/MicroCFTA/Audit.lean': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/Audit-BEFORE.lean.txt'}
expected_prior_manifest = '3e53a171aa5a71d27be39804cd837a080a2b19d94e33c3f1e3b74c6b89ea0e1b'
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage = json.loads(stage_path.read_text())
assert stage['prior_checkpoint'] == prior_commit and stage['components'] == expected
assert stage['baseline_overrides'] == expected_overrides
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6258, 5258, 690, 285)
assert (stage['new_modules'], stage['changed_existing_owners'], stage['new_public_theorems'], stage['new_private_helpers']) == (1, 5, 6, 2)
assert stage['new_private_predicates'] == 0 and stage['new_theorem_declarations'] == 8
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (6, 478, 484)
assert stage['fresh_explicit_axiom_reports'] == 6 and stage['private_helpers_covered_transitively']
assert not stage['private_helpers_counted_as_explicit_fresh_reports']
assert stage['old_source_files_byte_exact'] == 6251
for name in ['all_five_old_owner_prefixes_byte_exact', 'old_audit_contiguous_bytes_preserved',
        'all_old_proof_bodies_and_limits_unchanged', 'first_import_setup_failure23315_preserved',
        'candidate_proofs_and_headers_not_repaired', 'four_auxiliary_laws_at_every_actual_warm_prefix_proved',
        'entry_qualifier_keeps_same_full_newCount_H', 'generic_warm_origin_and_prefix_interfaces_proved',
        'warm_child_reader_interfaces_proved']:
    assert stage[name], name
for name in ['all_new_formal_proof_checks_first_pass', 'source_warm_C_and_M_body_callbacks_proved',
        'warm_query_no_new_mu_proved', 'every_warm_worker_call_qualification_proved',
        'joint_finite_completion_proved', 'haskell_changed']:
    assert not stage[name], name
baseline = json.loads((work / 'baseline-source-pins.json').read_text())
assert len(baseline) == 6257
new_sources = {i['source_path'] for i in expected if i['kind'] == 'new_module'}
changed_owners = {i['source_path'] for i in expected if i['kind'] == 'appended_owner'}
assert len(new_sources) == 1 and len(changed_owners) == 5
assert set(expected_overrides) == changed_owners | {audit_name}
assert not (new_sources & set(baseline))
assert {str(p.relative_to(root)) for p in (root / 'lean/MicroCFTA').glob('*.lean')} == set(baseline) | new_sources

def historical_bytes(name):
    return (root / expected_overrides.get(name, name)).read_bytes()

for name, digest in baseline.items():
    assert sha(historical_bytes(name)) == digest, name
assert len(set(baseline) - set(expected_overrides)) == 6251
old_audit = historical_bytes(audit_name)
assert len(old_audit) == stage['old_audit_bytes'] == 427041
assert sha(old_audit) == stage['old_audit_sha256']
assert old_audit.count(b'#print axioms ') == 684
assert sha((root / resource_owner).read_bytes()) == resource_owner_sha
prior = json.loads((prior_run / 'checked.json').read_text())
assert (prior['source_files'], prior['independent_reports'], prior['resource_and_component_probes']) == (6257, 279, 478)
assert all(c['exit'] == 0 and not c['diagnostics'] and not c['sorryAx'] and not c['nonstandard_axioms'] for c in prior['checks'])
assert sha((prior_archive / 'manifest.json').read_bytes()) == expected_prior_manifest
for name, digest in json.loads((prior_run / 'source-pins.json').read_text()).items():
    assert sha(historical_bytes(name)) == digest, name

def records_of_manifest(manifest):
    if 'artifacts' in manifest:
        return [(item['path'], item) for item in manifest['artifacts']]
    records = manifest['files']
    if isinstance(records, list):
        return [(item.get('file', item.get('path')), item) for item in records]
    return list(records.items())

def verify_manifest(packet, digest):
    path = packet / 'MANIFEST.json'
    assert sha(path.read_bytes()) == digest
    for name, record in records_of_manifest(json.loads(path.read_text())):
        data = (packet / name).read_bytes()
        assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), name
        if isinstance(record, dict):
            assert len(data) == record['bytes'], name

def verify_historical_pin_file(path):
    value = json.loads(path.read_text())
    if isinstance(value, list):
        records = [(item['path'], item) for item in value]
    else:
        records = list(value.items())
    for name, record in records:
        data = historical_bytes(name)
        assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), name
        if isinstance(record, dict):
            assert len(data) == record['bytes'], name

packets = []
headers = []
normal_sources = []
checked_inputs = []
qnames = []
seen_runs = set()
private_explicit_reports = 0
sessions = {'20261117-warm-actual-prefix-interfaces-import-overlay-repair-check': 54736,
    '20261117-warm-node-reader-first-check': 85770, '20261117-warm-edge-reader-first-check': 54797,
    '20261117-warm-auxiliary-prefixes-first-check': 54687}
for item in expected:
    packet = base / item['candidate_packet']
    packets.append(packet)
    normal = (root / item['source_path']).read_bytes()
    normal_sources.append(normal)
    assert normal == (packet / item['candidate_file']).read_bytes()
    assert len(normal) == item['raw_bytes'] and sha(normal) == item['raw_sha256']
    verify_manifest(packet, item['candidate_manifest_sha256'])
    verify_historical_pin_file(packet / 'SOURCE-PINS.json')
    if item['kind'] == 'appended_owner':
        before = (root / item['old_snapshot']).read_bytes()
        assert item['old_snapshot'] == expected_overrides[item['source_path']]
        assert len(before) == item['old_bytes'] and sha(before) == item['old_sha256'] == baseline[item['source_path']]
        appended = (packet / item['append_file']).read_bytes()
        assert sha(appended) == item['append_sha256']
        assert normal == before + b'\n' + appended
        assert item['append_offset'] == len(before) + 1 and item['old_owner_entire_prefix_preserved']
        new_body = appended.decode()
    else:
        new_body = normal.decode()
    assert re.findall(r'^private theorem ([A-Za-z0-9_]+)', new_body, re.M) == item['new_private_helper_names']
    assert ['MicroCFTA.' + item['module'] + '.' + name for name in re.findall(r'^theorem ([A-Za-z0-9_]+)', new_body, re.M)] == item['names']
    assert not re.findall(r'^private def ', new_body, re.M)
    qnames += item['names']
    for header in item['header_files']:
        path = packet / header['file']
        assert sha(path.read_bytes()) == header['sha256']
        assert path.read_text().rstrip() in new_body
        headers.append(path)
    if 'normalized_check_packet' in item:
        normalized = base / item['normalized_check_packet']
        verify_manifest(normalized, item['normalized_check_manifest_sha256'])
        assert (normalized / (item['module'] + '.lean')).read_bytes() == normal
        verify_historical_pin_file(normalized / 'SOURCE-PINS.json')
        checked_inputs += [normalized / 'MANIFEST.json', normalized / 'SOURCE-PINS.json', normalized / 'SELECTION.json']
    run = base / item['private_run']
    receipt_path = work / item['private_receipt']
    receipt = json.loads(receipt_path.read_text())
    assert receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
    assert receipt['actual_session'] == sessions[item['private_run']] and receipt['run'] == item['private_run']
    checked = json.loads((run / 'checked.json').read_text())
    assert receipt['checks'] == checked['checks']
    assert checked['normal_module_checked'] and all(checked['passed']) and checked['source_pins_unchanged']
    assert all(c['exit'] == 0 and not c['diagnostics'] and not c['sorryAx'] and not c['nonstandard_axioms'] for c in checked['checks'])
    if item['private_run'] not in seen_runs:
        private_explicit_reports += sum(c['total_axiom_reports'] for c in checked['checks'])
        seen_runs.add(item['private_run'])
        verify_historical_pin_file(run / 'source-pins.json')
        checked_inputs += [run / n for n in ['checked.json', 'source-pins.json']]
        checked_inputs += [run / (c['name'] + '.txt') for c in checked['checks']]
        checked_inputs.append(receipt_path)
    selected_check = next((c for c in checked['checks'] if c['name'] == item['module']), None)
    if selected_check is None:
        selected_check = next(c for c in checked['checks'] if c['name'] == 'normal-module')
    assert selected_check['total_axiom_reports'] == 1
    checked_source = run / 'source/MicroCFTA' / (item['module'] + '.lean')
    assert checked_source.read_bytes().startswith(normal)
    checked_inputs.append(checked_source)
assert private_explicit_reports == 6 and len(seen_runs) == 4
assert len(qnames) == len(set(qnames)) == 6
assert sum(len(i['new_private_helper_names']) for i in expected) == 2
rejected_path = work / 'INTERFACE-FIRST-CHECK-REJECTED.json'
rejected = json.loads(rejected_path.read_text())
assert rejected['actual_session'] == 23315 and rejected['actual_terminal_exit'] == 1
assert not rejected['candidate_source_or_header_changed'] and not rejected['candidate_proof_checked']
failed_run = base / rejected['run']
failed_result = json.loads((failed_run / 'results.json').read_text())
assert failed_result['checks'] == rejected['checks']
assert all(c['exit'] == 1 and c['total_axiom_reports'] == 0 and not c['sorryAx'] for c in rejected['checks'])
checked_inputs += [rejected_path, failed_run / 'results.json', failed_run / 'source-pins.json']
checked_inputs += [failed_run / (c['name'] + '.txt') for c in rejected['checks']]
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
assert public == ''.join('#check ' + q + '\n#print axioms ' + q + '\n' for q in qnames).encode()
new_import = (work / 'IMPORTS.lean.txt').read_bytes()
assert new_import == ''.join('import MicroCFTA.' + i['module'] + '\n' for i in expected if i['kind'] == 'new_module').encode()
assert len(new_import) == 58 and stage['new_ordinary_audit_imports'] == 1
assert (root / audit_name).read_bytes() == new_import + old_audit + b'\n' + public
assert sum(line.startswith(b'import ') for line in (root / audit_name).read_bytes().splitlines()) == 5258
assert (root / audit_name).read_bytes().count(b'#print axioms ') == 690


# Checkpoint preflight. Historical pins use exact BEFORE snapshots; current public
# pins use actual new Source. Only Root executes the reviewed controller.
import gzip
import subprocess

ROOT = root
BASE = base
WORK = work
PUBLIC = runtime
ARCHIVE = '20261117-warm-prefix-preservation-checkpoint'
BOARD_PREFIX = 'current-board-warm-prefix-preservation-'
read = lambda path: json.loads(path.read_text())
GIT = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
bindings = read(WORK / 'prior-bindings.json')
assert bindings['prior_checkpoint'] == prior_commit
verify_historical_pin_file(failed_run / 'source-pins.json')
commit = read(WORK / 'SOURCE-COMMIT.json')
code = commit['source_commit']
assert re.fullmatch(r'[0-9a-f]{40}', code) and commit['parent'] == prior_commit
assert commit['actual_terminal'] and commit['actual_terminal_exit'] == 0
assert not commit['joint_finite_completion_proved']
assert GIT('rev-parse', 'HEAD').decode().strip() == code
assert GIT('rev-parse', code + '^').decode().strip() == prior_commit
assert GIT('branch', '--show-current').decode().strip() == 'formalize'
assert not GIT('status', '--porcelain', '--untracked-files=no')
changed = new_sources | changed_owners | {audit_name}
assert len(changed) == 7 and set(commit['files']) == changed
assert set(GIT('diff', '--name-only', prior_commit, code).decode().splitlines()) == changed
for name in changed:
    assert GIT('show', code + ':' + name) == (ROOT / name).read_bytes(), name
for name in expected_overrides:
    assert GIT('show', prior_commit + ':' + name) == historical_bytes(name), name
report = read(PUBLIC / 'checked.json')
verified = read(WORK / 'PUBLICATION-VERIFIED.json')
assert verified['actual_session'] == 82650 and verified['actual_terminal'] and verified['actual_terminal_exit'] == 0
assert verified['checks'] == report['checks']
assert [c['total_axiom_reports'] for c in report['checks']] == [690, 6, 285, 690, 690]
assert [(c['axiom_groups'], c['axiom_free_reports']) for c in report['checks']] == [
    (684, 6), (6, 0), (282, 3), (684, 6), (684, 6)]
assert all(c['exit'] == 0 and not c['diagnostics'] and not c['nonstandard_axioms'] and not c['sorryAx'] for c in report['checks'])
for name, value in {'source_files': 6258, 'direct_audit_imports': 5258,
        'individual_reports': 690, 'independent_reports': 285,
        'fresh_resource_component_reports': 6, 'inherited_resource_component_reports': 478,
        'resource_and_component_probes': 484, 'new_modules': 1, 'changed_existing_owners': 5,
        'new_public_theorems': 6, 'new_private_helpers': 2, 'new_private_theorems': 2,
        'new_private_predicates': 0, 'new_theorem_declarations': 8,
        'actual_publication_strict_reports': 6, 'new_private_component_reports': 0,
        'fresh_owner_preflight_reports': 0, 'replaced_old_reports': 0,
        'old_source_files_byte_exact': 6251}.items():
    assert report[name] == value, name
for name in ['all_six_original_first_headers_exact', 'all_five_old_owner_prefixes_byte_exact',
        'historical_pins_use_exact_before_snapshots', 'current_public_pins_use_new_source_bytes',
        'first_import_setup_failure23315_preserved', 'candidate_proofs_and_headers_not_repaired',
        'compiler_import_overlay_only_repaired', 'generic_warm_origin_and_prefix_interfaces_proved',
        'warm_child_reader_interfaces_proved', 'four_auxiliary_laws_at_every_actual_warm_prefix_proved',
        'entry_qualifier_keeps_same_full_newCount_H']:
    assert report[name], name
for name in ['first_check_passed_without_repair', 'all_new_formal_proof_checks_first_pass',
        'private_helpers_counted_as_explicit_fresh_reports', 'owner_recompiled_in_publication_strict_gate',
        'source_warm_C_and_M_body_callbacks_proved', 'source_semantic_finish_callbacks_proved',
        'warm_result_callbacks_proved', 'warm_query_no_new_mu_proved',
        'every_warm_worker_call_qualification_proved', 'joint_finite_completion_proved', 'haskell_changed']:
    assert not report[name], name
assert report['inherited_owner_preflight_evidence']['reports'] == 264
assert report['inherited_owner_preflight_evidence']['included_in_inherited_478']
assert report['baseline_overrides'] == expected_overrides
assert report['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
pins = read(PUBLIC / 'source-pins.json')
# Do not apply historical overrides to the current publication pin map.
for name, digest in pins.items():
    assert sha((ROOT / name).read_bytes()) == digest, name
assert verified['pins_independently_reverified'] == len(pins) == 6336
source_pins = {name: digest for name, digest in pins.items()
    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
assert len(source_pins) == 6258 and set(source_pins) == set(baseline) | new_sources
prior_path = BASE / bindings['prior_archive']
for name, key in [('manifest.json', 'prior_manifest_sha256'), ('checkpoint.json', 'prior_checkpoint_json_sha256')]:
    data = (prior_path / name).read_bytes()
    assert sha(data) == bindings[key]
    assert GIT('show', prior_commit + ':' + str((prior_path / name).relative_to(ROOT))) == data
old_checkpoint = read(prior_path / 'checkpoint.json')
assert old_checkpoint['resource_and_component_probes'] == 478
assert old_checkpoint['checked_code'] == GIT('rev-parse', prior_commit + '^').decode().strip()
prior_files = {item['path']: item for item in read(prior_path / 'manifest.json')['files']}
for name in ['source-pins.json.gz', 'verification.json', 'archived-inputs.json']:
    data = (prior_path / name).read_bytes()
    assert len(data) == prior_files[name]['bytes'] and sha(data) == prior_files[name]['sha256']
    assert GIT('show', prior_commit + ':' + str((prior_path / name).relative_to(ROOT))) == data
old_pins = json.loads(gzip.decompress((prior_path / 'source-pins.json.gz').read_bytes()))
assert baseline == {name: digest for name, digest in old_pins.items()
    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
for name, digest in old_pins.items():
    assert sha(historical_bytes(name)) == digest, name
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    assert old_pins[name] == pins[name], name
request = read(WORK / (BOARD_PREFIX + 'request.json'))
canonical = read(WORK / (BOARD_PREFIX + 'canonical.json'))
assert canonical.get('verified', True)
post = canonical.get('post', canonical)
assert post['id'] == request['request_id'] and type(post['sequence']) is int and post['sequence'] > 0
for key, value in [('author', request['username']), ('thread_id', request['thread_id']),
        ('post_type', request['post_type']), ('content', request['content']), ('metadata', request['metadata'])]:
    assert post[key] == value, key
assert post['metadata']['source'] == code
cleanup = read(WORK / 'combined-terminal-cleanup-result.json')
preview = read(WORK / 'TMP-CLEANUP-PREVIEW.json')
assert cleanup['all_owned_terminal_only'] and cleanup['all_six_actual_runs_terminal']
assert cleanup['unknown_tmp_entries_preserved'] and cleanup['normal_lake_symlink_targets_preserved']
assert not cleanup['symlink_target_bytes_counted']
paths = [item['path'] for item in cleanup['removed_targets']]
assert len(paths) == len(set(paths)) == 6
assert all(not Path(path).exists() and not Path(path).is_symlink() for path in paths)
actual_runs = [failed_run] + [BASE / name for name in seen_runs] + [PUBLIC]
owned = {read(run / 'objects.json')['path'] for run in actual_runs}
assert set(paths) == owned
assert cleanup['removed_targets'] == preview['owned_terminal_targets']
assert preview['all_six_actual_runs_terminal'] and not preview['live_process_references']
assert preview['terminal_sessions'] == [23315, 54736, 54687, 85770, 54797, 82650]
assert preview['normal_lake_symlink_targets_preserved']
assert all(not item['symlink_target_bytes_counted'] for item in cleanup['removed_targets'])
assert cleanup['removed_bytes'] == sum(item['bytes'] for item in cleanup['removed_targets']) == 11731872
assert cleanup['removed_symlinks'] == sum(item['symlinks'] for item in cleanup['removed_targets']) == 6288
assert cleanup['prior_cumulative_removed_bytes'] + cleanup['removed_bytes'] == cleanup['cumulative_removed_bytes']
start = read(WORK / 'START.json')
resume = read(WORK / 'RESUME-AUTHORIZATION.json')
assert start['user_explicitly_resumed'] and start['earlier_usage_pause_lifted'] and start['active_work_authorized']
assert start['persistent_goal_control_status'] == 'paused'
assert not start['goal_resume_operation_performed'] and not start['goal_completion_claimed']
assert resume['user_instruction'] == "Keep going. We'll use a reset if needed."
assert resume['user_explicitly_resumed'] and resume['earlier_usage_pause_lifted'] and resume['work_authorized']
assert resume['persistent_goal_control_at_resume'] == 'paused' and resume['no_goal_resume_operation_available']
usage = read(WORK / 'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int, float] and 0 <= percent <= 100
assert usage['earlier_usage_pause_lifted_by_user_resume']
roots = read(WORK / 'selection-roots.json')
assert len(roots) == 14
additional = read(WORK / 'archive-additional-roots.json')
assert len(additional) == 7
for item in additional:
    assert re.fullmatch(r'20261117-[a-z0-9-]+', item['root'])
    assert item['manifest'] == 'MANIFEST.json' and item['current_batch_theorem_credit'] == 0
    manifest_path = BASE / item['root'] / item['manifest']
    verify_manifest(manifest_path.parent, item['sha256'])
    manifest = read(manifest_path)
    if item['kind'] == 'future_proof_candidate':
        assert 'UNCOMPILED' in manifest['status']
    else:
        assert item['kind'] == 'independent_read_only_review' and 'REVIEW' in manifest['status'].upper()
    roots.append(item['root'])
assert len(roots) == len(set(roots)) == 21
assert all((BASE / name).is_dir() and not (BASE / name).is_symlink() for name in roots)
for name in roots:
    run = BASE / name
    if (run / 'check.py').exists():
        result = read(run / ('checked.json' if (run / 'checked.json').exists() else 'results.json'))
        assert result['checks'] and all(type(item['exit']) is int for item in result['checks']), name
for item in read(WORK / 'original-header-files.json'):
    assert sha((ROOT / item['path']).read_bytes()) == item['sha256']
    assert sha((ROOT / item['original']).read_bytes()) == item['sha256']
selected = sorted(str((BASE / name).relative_to(ROOT)) for name in roots)
assert not (BASE / ARCHIVE).exists()
tree = hashlib.sha256()
for name, digest in sorted(source_pins.items()):
    tree.update(name.encode() + b'\0' + digest.encode() + b'\n')
config = dict(report)
config.update(checked_code=code, prior_checkpoint=prior_commit, public_run=str(PUBLIC), public_gates=5,
    explicit_reports=report['individual_reports'], board_prefix=BOARD_PREFIX,
    board_post_id=post['id'], board_sequence=post['sequence'], source_tree_sha256=tree.hexdigest(),
    old_source_files_byte_exact=6251, old_owner_full_prefixes_preserved=5,
    old_audit_contiguous_bytes_preserved=427041, old_audit_exact_offset=58,
    ordinary_audit_import_bytes=58, new_audit_imports=1, old_audit_is_prefix=False,
    historical_pins_use_exact_before_snapshots=True, current_public_pins_use_new_source_bytes=True,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],
    cleanup_receipt='combined-terminal-cleanup-result.json', removed_symlinks=cleanup['removed_symlinks'],
    symlink_target_bytes_counted=False, normal_lake_symlink_targets_preserved=True,
    tmp_readable_regular_file_bytes_after=cleanup['tmp_readable_regular_file_bytes_after'],
    tmp_census_errors=cleanup['tmp_census_errors'], unknown_tmp_entries_preserved=True,
    primary_usage_percent=percent, primary_usage_checked_at=usage['event_timestamp'],
    prior_immutable_archive=bindings['prior_archive'], prior_manifest_sha256=bindings['prior_manifest_sha256'],
    fresh_strict_reports=6, inherited_component_reports=478,
    all_new_formal_proof_checks_first_pass=False, first_check_passed_without_repair=False,
    first_import_setup_failure23315_preserved=True, candidate_proofs_and_headers_not_repaired=True,
    historical_failed_proofs_preserved_in_prior_immutable_chain=True,
    additional_frozen_roots=additional, additional_frozen_roots_theorem_credit=0,
    semantic_finish_callback_gap_preserved=True,
    user_explicitly_resumed=True, earlier_usage_pause_lifted=True,
    work_authorized_by_explicit_user_resume=True, persistent_goal_control_status='paused',
    goal_resume_operation_performed=False, goal_completion_claimed=False, goal_active=False,
    joint_finite_completion_proved=False, compiled_haskell_correspondence_proved=False, haskell_changed=False)
skipped = sorted(str(path.relative_to(ROOT)) for path in BASE.iterdir()
    if path.is_dir() and path.name.startswith('20261117-') and str(path.relative_to(ROOT)) not in selected)
review = {'prior_checkpoint': prior_commit, 'selected_roots': len(selected), 'base_roots': 14,
    'additional_frozen_roots': additional, 'additional_frozen_roots_theorem_credit': 0,
    'fresh_reports_this_batch': 6, 'inherited_reports': 478, 'combined_reports': 484,
    'new_public_theorems': 6, 'new_private_helpers': 2, 'new_theorem_declarations': 8,
    'new_private_explicit_reports': 0, 'private_helpers_counted_as_explicit_reports': False,
    'all_current_component_first_checks_passed': False, 'inherited_owner_reports': 264,
    'first_import_setup_failure23315_preserved': True,
    'compiler_import_overlay_only_repaired': True, 'candidate_proofs_and_headers_not_repaired': True,
    'historical_override_count': 6, 'current_public_pins_use_new_source_bytes': True,
    'generic_warm_origin_and_prefix_interfaces_proved': True, 'warm_child_reader_interfaces_proved': True,
    'four_auxiliary_laws_at_every_actual_warm_prefix_proved': True,
    'semantic_finish_callback_gap_preserved': True, 'source_semantic_finish_callbacks_proved': False,
    'warm_query_no_new_mu_proved': False, 'joint_finite_completion_proved': False,
    'haskell_changed': False, 'goal_completion_claimed': False}
note = (WORK / 'checkpoint-note.md').read_text()
for key, value in {'THEOREMS': report['audited_theorems'], 'REMOVED': cleanup['removed_bytes'],
                   'CLEANUP': cleanup['cumulative_removed_bytes'], 'USAGE': percent}.items():
    note = note.replace('{{' + key + '}}', str(value))
assert set(re.findall(r'\{\{(.*?)\}\}', note)) == {'TIME', 'TREE', 'CODE'}
outputs = {'checkpoint-config.json': config, 'archive-roots.json': selected,
           'skipped-published-roots.json': skipped, 'selection-review.json': review}
assert all(not (WORK / name).exists() for name in outputs)
for name, value in outputs.items():
    (WORK / name).write_text(json.dumps(value, indent=2) + '\n')
(WORK / 'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code': code, 'packet': ARCHIVE, 'roots': len(selected),
    'board_sequence': post['sequence'], 'fresh_reports': 6, 'inherited_reports': 478,
    'combined_reports': 484, 'future_root_credit': 0}))
