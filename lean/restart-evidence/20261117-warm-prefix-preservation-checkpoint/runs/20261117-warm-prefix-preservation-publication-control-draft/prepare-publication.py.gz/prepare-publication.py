from pathlib import Path
import hashlib
import json
import re
import shlex
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
work = base / '20261117-warm-prefix-preservation-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this candidate into the active Work directory'
prior_run = base / '20261117-warm-edge-initial-profile-publication'
prior_archive = base / '20261117-warm-edge-initial-profile-checkpoint'
runtime = base / '20261117-warm-prefix-preservation-publication'
prior_commit = '9182ceb0e4e374d0a2c05a8ac18bfde48ec178ea'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
resource_owner = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
resource_owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
expected = [{'kind': 'appended_owner', 'module': 'SourceCurrentAllocatedNativeCompileDispatchOrigin', 'source_path': 'lean/MicroCFTA/SourceCurrentAllocatedNativeCompileDispatchOrigin.lean', 'candidate_packet': '20261117-warm-actual-prefix-returned-interfaces-draft', 'candidate_file': 'SourceCurrentAllocatedNativeCompileDispatchOrigin.lean', 'candidate_manifest_sha256': 'c86d0d4f0a955f925d49f5983f23079f348bfb93bdfda8d218fe99951acf9114', 'raw_sha256': '3a28c3abb339aca1df4a42a3266d83501add61af555859ca7d7aa6e84efe010f', 'private_run': '20261117-warm-actual-prefix-interfaces-import-overlay-repair-check', 'private_receipt': 'INTERFACE-OVERLAY-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentAllocatedNativeCompileDispatchOrigin.compiled_node_origin_from_warm_query_finish'], 'new_private_helper_names': [], 'header_files': [{'file': 'NODE-FIRST-HEADER.lean.txt', 'sha256': 'ec2bf3e980befdf3e0bbd14da23c3bedab6ada8f9ed1a882f47281868c496fb3'}], 'append_file': 'NODE-APPEND.lean.txt', 'append_sha256': '0037372787205052f1fe0846e414553a28104144a842e9591d623ba96eaac967', 'raw_bytes': 23535, 'old_snapshot': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeCompileDispatchOrigin.lean.txt', 'old_bytes': 20549, 'old_sha256': '5ede4cb6ae69f17d711f4aad652b5282c658a296f5364ebdd0c97dbeb24abdea', 'append_offset': 20550, 'old_owner_entire_prefix_preserved': True}, {'kind': 'appended_owner', 'module': 'SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin', 'source_path': 'lean/MicroCFTA/SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin.lean', 'candidate_packet': '20261117-warm-actual-prefix-returned-interfaces-draft', 'candidate_file': 'SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin.lean', 'candidate_manifest_sha256': 'c86d0d4f0a955f925d49f5983f23079f348bfb93bdfda8d218fe99951acf9114', 'raw_sha256': '07bf47dba40902c2a24ddb09283f6828f4726682f39d7ac3d991874fa32b3bf3', 'private_run': '20261117-warm-actual-prefix-interfaces-import-overlay-repair-check', 'private_receipt': 'INTERFACE-OVERLAY-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin.checked_edge_body_origin_from_warm_query_finish'], 'new_private_helper_names': [], 'header_files': [{'file': 'EDGE-FIRST-HEADER.lean.txt', 'sha256': '336c4806b27a8b2541600e42d3b4c56eef5aa316738e370f8ca3bea62c50321d'}], 'append_file': 'EDGE-APPEND.lean.txt', 'append_sha256': '76d98dc9c3559cb48e2e3ed7b55048fb662308ffefef900a26b2dfbc0d956935', 'raw_bytes': 26840, 'old_snapshot': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin.lean.txt', 'old_bytes': 24151, 'old_sha256': 'f1b5072b7f66612d5849b990a2e862e96208c3789165f038e36fd08c1056e9fe', 'append_offset': 24152, 'old_owner_entire_prefix_preserved': True}, {'kind': 'appended_owner', 'module': 'SourceCurrentAllocatedNativeActualPrefixReturnedInduction', 'source_path': 'lean/MicroCFTA/SourceCurrentAllocatedNativeActualPrefixReturnedInduction.lean', 'candidate_packet': '20261117-warm-actual-prefix-returned-interfaces-draft', 'candidate_file': 'SourceCurrentAllocatedNativeActualPrefixReturnedInduction.lean', 'candidate_manifest_sha256': 'c86d0d4f0a955f925d49f5983f23079f348bfb93bdfda8d218fe99951acf9114', 'raw_sha256': '87f391c14509b1a22d93db95fdda31082b10ca3eb326fad90b23a885ce77abd8', 'private_run': '20261117-warm-actual-prefix-interfaces-import-overlay-repair-check', 'private_receipt': 'INTERFACE-OVERLAY-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentAllocatedNativeActualPrefixReturnedInduction.returned_at_every_actual_warm_prefix'], 'new_private_helper_names': [], 'header_files': [{'file': 'RETURNED-FIRST-HEADER.lean.txt', 'sha256': 'e24bba944ba2151e5c2eaec99f53f418d87d189f03fd06770cea7b5c90054250'}], 'append_file': 'RETURNED-APPEND.lean.txt', 'append_sha256': '056c8b8bcf93e158c6d17401ae5afd37cb3352790d24f0577c24538aad3458c7', 'raw_bytes': 24360, 'old_snapshot': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeActualPrefixReturnedInduction.lean.txt', 'old_bytes': 16207, 'old_sha256': '12318c748fc83735732bae5e2e1447c1b1563b7d64918dbe6f04857c7c123b77', 'append_offset': 16208, 'old_owner_entire_prefix_preserved': True}, {'kind': 'appended_owner', 'module': 'SourceCurrentAllocatedNativeSamePrefixKeyedChildResult', 'source_path': 'lean/MicroCFTA/SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.lean', 'candidate_packet': '20261117-warm-actual-child-reader-exports-draft', 'candidate_file': 'NODE-OWNER.lean.txt', 'candidate_manifest_sha256': 'b9622885f99465a7c9bed819747eb9da420d0054d7281c9e92e2df87e95e8360', 'raw_sha256': 'bb65734294d9f78cc574b053b2f0d4f4e0c63a98bbe41e93a8af878c871a2bc3', 'private_run': '20261117-warm-node-reader-first-check', 'private_receipt': 'NODE-READER-FIRST-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.keyed_child_law_at_actual_warm_reader'], 'new_private_helper_names': [], 'header_files': [{'file': 'NODE-FIRST-HEADER.lean.txt', 'sha256': 'adcffc043509dc566f43d6590abd8b708a1ffef15886e079ad348de8f373ed81'}], 'append_file': 'NODE-APPEND.lean.txt', 'append_sha256': '8e94e8209ebdc4ff5233fa24eb01018756868d52a874107d47656824f40df277', 'normalized_check_packet': '20261117-warm-node-reader-normal-check-layout', 'normalized_check_manifest_sha256': 'c74d48b08968d45e50702e808dbbbe17c5d5d5aafb27b5326b34ef0f468f6ab7', 'raw_bytes': 22991, 'old_snapshot': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.lean.txt', 'old_bytes': 18241, 'old_sha256': 'b843352cf3cccc4a3a87eae50ab24f4703f96e4d1a123aa099a7ad823ff9b9ce', 'append_offset': 18242, 'old_owner_entire_prefix_preserved': True}, {'kind': 'appended_owner', 'module': 'SourceCurrentAllocatedNativeSamePrefixEdgeChildResult', 'source_path': 'lean/MicroCFTA/SourceCurrentAllocatedNativeSamePrefixEdgeChildResult.lean', 'candidate_packet': '20261117-warm-actual-child-reader-exports-draft', 'candidate_file': 'EDGE-OWNER.lean.txt', 'candidate_manifest_sha256': 'b9622885f99465a7c9bed819747eb9da420d0054d7281c9e92e2df87e95e8360', 'raw_sha256': 'e889ee75375190ec7fe5c9bd22f1f9d6f3562303ddcce275eea6d5da049a3e74', 'private_run': '20261117-warm-edge-reader-first-check', 'private_receipt': 'EDGE-READER-FIRST-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentAllocatedNativeSamePrefixEdgeChildResult.edge_child_law_at_actual_warm_reader'], 'new_private_helper_names': [], 'header_files': [{'file': 'EDGE-FIRST-HEADER.lean.txt', 'sha256': '8bc50d70bfda8bbecfc67dc09e20711c1ec3b2061cf5522817b0e91e4cf6b492'}], 'append_file': 'EDGE-APPEND.lean.txt', 'append_sha256': '00cf1aeb29dd46348e3dc15747e13284eafc0b0198040a9dafc814755faca726', 'normalized_check_packet': '20261117-warm-edge-reader-normal-check-layout', 'normalized_check_manifest_sha256': '254dd23c23da8a8d0b93b2527ad433f22e8ce8e0512bc116869e6a328b64e8c6', 'raw_bytes': 17641, 'old_snapshot': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeSamePrefixEdgeChildResult.lean.txt', 'old_bytes': 13171, 'old_sha256': '17008f09917e2c8503806b9d6e458d1656efeeae8720cc27bb003cd13bd24664', 'append_offset': 13172, 'old_owner_entire_prefix_preserved': True}, {'kind': 'new_module', 'module': 'SourceCurrentNativeWarmAuxiliaryPrefixes', 'source_path': 'lean/MicroCFTA/SourceCurrentNativeWarmAuxiliaryPrefixes.lean', 'candidate_packet': '20261117-actual-warm-prefix-auxiliary-payloads-draft', 'candidate_file': 'SourceCurrentNativeWarmAuxiliaryPrefixes.lean', 'candidate_manifest_sha256': 'db16abeb585c03d27d3cd1f9da087cf52be3d9b5fd39f4819a83e79ec4cca86b', 'raw_sha256': 'e956ca145345d8e3afc96d522e597f0bd0ff937e2badd40f228ca9ebca043f97', 'private_run': '20261117-warm-auxiliary-prefixes-first-check', 'private_receipt': 'AUXILIARY-PREFIX-FIRST-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentNativeWarmAuxiliaryPrefixes.auxiliary_payloads_at_every_actual_warm_prefix'], 'new_private_helper_names': ['reference_code', 'reference_read_step'], 'header_files': [{'file': 'FIRST-HEADER.lean.txt', 'sha256': '36948f2e4affac35abb02ed8d1bf539d9bc9efa503e56ae73db037f6030f0920'}], 'raw_bytes': 31398}]
expected_overrides = {'lean/MicroCFTA/SourceCurrentAllocatedNativeCompileDispatchOrigin.lean': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeCompileDispatchOrigin.lean.txt', 'lean/MicroCFTA/SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin.lean': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeEdgeCompileDispatchOrigin.lean.txt', 'lean/MicroCFTA/SourceCurrentAllocatedNativeActualPrefixReturnedInduction.lean': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeActualPrefixReturnedInduction.lean.txt', 'lean/MicroCFTA/SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.lean': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.lean.txt', 'lean/MicroCFTA/SourceCurrentAllocatedNativeSamePrefixEdgeChildResult.lean': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/OWNER-BEFORE/SourceCurrentAllocatedNativeSamePrefixEdgeChildResult.lean.txt', 'lean/MicroCFTA/Audit.lean': 'lean/restart-evidence/20261117-warm-prefix-preservation-work/Audit-BEFORE.lean.txt'}
expected_prior_manifest = '3e53a171aa5a71d27be39804cd837a080a2b19d94e33c3f1e3b74c6b89ea0e1b'
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage = json.loads(stage_path.read_text())
assert stage['prior_checkpoint'] == prior_commit and stage['components'] == expected
assert stage['baseline_overrides'] == expected_overrides
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6258, 5258, 690, 285)
assert (stage['new_modules'], stage['changed_existing_owners'], stage['new_public_theorems'], stage['new_private_helpers']) == (1, 5, 6, 2)
assert stage['new_private_predicates'] == 0 and stage['new_theorem_declarations'] == 8
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (6, 478, 484)
assert stage['fresh_explicit_axiom_reports'] == 6 and stage['private_helpers_covered_transitively']
assert not stage['private_helpers_counted_as_explicit_fresh_reports']
assert stage['old_source_files_byte_exact'] == 6251
for name in ['all_five_old_owner_prefixes_byte_exact', 'old_audit_contiguous_bytes_preserved',
        'all_old_proof_bodies_and_limits_unchanged', 'first_import_setup_failure23315_preserved',
        'candidate_proofs_and_headers_not_repaired', 'four_auxiliary_laws_at_every_actual_warm_prefix_proved',
        'entry_qualifier_keeps_same_full_newCount_H', 'generic_warm_origin_and_prefix_interfaces_proved',
        'warm_child_reader_interfaces_proved']:
    assert stage[name], name
for name in ['all_new_formal_proof_checks_first_pass', 'source_warm_C_and_M_body_callbacks_proved',
        'warm_query_no_new_mu_proved', 'every_warm_worker_call_qualification_proved',
        'joint_finite_completion_proved', 'haskell_changed']:
    assert not stage[name], name
baseline = json.loads((work / 'baseline-source-pins.json').read_text())
assert len(baseline) == 6257
new_sources = {i['source_path'] for i in expected if i['kind'] == 'new_module'}
changed_owners = {i['source_path'] for i in expected if i['kind'] == 'appended_owner'}
assert len(new_sources) == 1 and len(changed_owners) == 5
assert set(expected_overrides) == changed_owners | {audit_name}
assert not (new_sources & set(baseline))
assert {str(p.relative_to(root)) for p in (root / 'lean/MicroCFTA').glob('*.lean')} == set(baseline) | new_sources

def historical_bytes(name):
    return (root / expected_overrides.get(name, name)).read_bytes()

for name, digest in baseline.items():
    assert sha(historical_bytes(name)) == digest, name
assert len(set(baseline) - set(expected_overrides)) == 6251
old_audit = historical_bytes(audit_name)
assert len(old_audit) == stage['old_audit_bytes'] == 427041
assert sha(old_audit) == stage['old_audit_sha256']
assert old_audit.count(b'#print axioms ') == 684
assert sha((root / resource_owner).read_bytes()) == resource_owner_sha
prior = json.loads((prior_run / 'checked.json').read_text())
assert (prior['source_files'], prior['independent_reports'], prior['resource_and_component_probes']) == (6257, 279, 478)
assert all(c['exit'] == 0 and not c['diagnostics'] and not c['sorryAx'] and not c['nonstandard_axioms'] for c in prior['checks'])
assert sha((prior_archive / 'manifest.json').read_bytes()) == expected_prior_manifest
for name, digest in json.loads((prior_run / 'source-pins.json').read_text()).items():
    assert sha(historical_bytes(name)) == digest, name

def records_of_manifest(manifest):
    if 'artifacts' in manifest:
        return [(item['path'], item) for item in manifest['artifacts']]
    records = manifest['files']
    if isinstance(records, list):
        return [(item.get('file', item.get('path')), item) for item in records]
    return list(records.items())

def verify_manifest(packet, digest):
    path = packet / 'MANIFEST.json'
    assert sha(path.read_bytes()) == digest
    for name, record in records_of_manifest(json.loads(path.read_text())):
        data = (packet / name).read_bytes()
        assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), name
        if isinstance(record, dict):
            assert len(data) == record['bytes'], name

def verify_historical_pin_file(path):
    value = json.loads(path.read_text())
    if isinstance(value, list):
        records = [(item['path'], item) for item in value]
    else:
        records = list(value.items())
    for name, record in records:
        data = historical_bytes(name)
        assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), name
        if isinstance(record, dict):
            assert len(data) == record['bytes'], name

packets = []
headers = []
normal_sources = []
checked_inputs = []
qnames = []
seen_runs = set()
private_explicit_reports = 0
sessions = {'20261117-warm-actual-prefix-interfaces-import-overlay-repair-check': 54736,
    '20261117-warm-node-reader-first-check': 85770, '20261117-warm-edge-reader-first-check': 54797,
    '20261117-warm-auxiliary-prefixes-first-check': 54687}
for item in expected:
    packet = base / item['candidate_packet']
    packets.append(packet)
    normal = (root / item['source_path']).read_bytes()
    normal_sources.append(normal)
    assert normal == (packet / item['candidate_file']).read_bytes()
    assert len(normal) == item['raw_bytes'] and sha(normal) == item['raw_sha256']
    verify_manifest(packet, item['candidate_manifest_sha256'])
    verify_historical_pin_file(packet / 'SOURCE-PINS.json')
    if item['kind'] == 'appended_owner':
        before = (root / item['old_snapshot']).read_bytes()
        assert item['old_snapshot'] == expected_overrides[item['source_path']]
        assert len(before) == item['old_bytes'] and sha(before) == item['old_sha256'] == baseline[item['source_path']]
        appended = (packet / item['append_file']).read_bytes()
        assert sha(appended) == item['append_sha256']
        assert normal == before + b'\n' + appended
        assert item['append_offset'] == len(before) + 1 and item['old_owner_entire_prefix_preserved']
        new_body = appended.decode()
    else:
        new_body = normal.decode()
    assert re.findall(r'^private theorem ([A-Za-z0-9_]+)', new_body, re.M) == item['new_private_helper_names']
    assert ['MicroCFTA.' + item['module'] + '.' + name for name in re.findall(r'^theorem ([A-Za-z0-9_]+)', new_body, re.M)] == item['names']
    assert not re.findall(r'^private def ', new_body, re.M)
    qnames += item['names']
    for header in item['header_files']:
        path = packet / header['file']
        assert sha(path.read_bytes()) == header['sha256']
        assert path.read_text().rstrip() in new_body
        headers.append(path)
    if 'normalized_check_packet' in item:
        normalized = base / item['normalized_check_packet']
        verify_manifest(normalized, item['normalized_check_manifest_sha256'])
        assert (normalized / (item['module'] + '.lean')).read_bytes() == normal
        verify_historical_pin_file(normalized / 'SOURCE-PINS.json')
        checked_inputs += [normalized / 'MANIFEST.json', normalized / 'SOURCE-PINS.json', normalized / 'SELECTION.json']
    run = base / item['private_run']
    receipt_path = work / item['private_receipt']
    receipt = json.loads(receipt_path.read_text())
    assert receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
    assert receipt['actual_session'] == sessions[item['private_run']] and receipt['run'] == item['private_run']
    checked = json.loads((run / 'checked.json').read_text())
    assert receipt['checks'] == checked['checks']
    assert checked['normal_module_checked'] and all(checked['passed']) and checked['source_pins_unchanged']
    assert all(c['exit'] == 0 and not c['diagnostics'] and not c['sorryAx'] and not c['nonstandard_axioms'] for c in checked['checks'])
    if item['private_run'] not in seen_runs:
        private_explicit_reports += sum(c['total_axiom_reports'] for c in checked['checks'])
        seen_runs.add(item['private_run'])
        verify_historical_pin_file(run / 'source-pins.json')
        checked_inputs += [run / n for n in ['checked.json', 'source-pins.json']]
        checked_inputs += [run / (c['name'] + '.txt') for c in checked['checks']]
        checked_inputs.append(receipt_path)
    selected_check = next((c for c in checked['checks'] if c['name'] == item['module']), None)
    if selected_check is None:
        selected_check = next(c for c in checked['checks'] if c['name'] == 'normal-module')
    assert selected_check['total_axiom_reports'] == 1
    checked_source = run / 'source/MicroCFTA' / (item['module'] + '.lean')
    assert checked_source.read_bytes().startswith(normal)
    checked_inputs.append(checked_source)
assert private_explicit_reports == 6 and len(seen_runs) == 4
assert len(qnames) == len(set(qnames)) == 6
assert sum(len(i['new_private_helper_names']) for i in expected) == 2
rejected_path = work / 'INTERFACE-FIRST-CHECK-REJECTED.json'
rejected = json.loads(rejected_path.read_text())
assert rejected['actual_session'] == 23315 and rejected['actual_terminal_exit'] == 1
assert not rejected['candidate_source_or_header_changed'] and not rejected['candidate_proof_checked']
failed_run = base / rejected['run']
failed_result = json.loads((failed_run / 'results.json').read_text())
assert failed_result['checks'] == rejected['checks']
assert all(c['exit'] == 1 and c['total_axiom_reports'] == 0 and not c['sorryAx'] for c in rejected['checks'])
checked_inputs += [rejected_path, failed_run / 'results.json', failed_run / 'source-pins.json']
checked_inputs += [failed_run / (c['name'] + '.txt') for c in rejected['checks']]
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
assert public == ''.join('#check ' + q + '\n#print axioms ' + q + '\n' for q in qnames).encode()
new_import = (work / 'IMPORTS.lean.txt').read_bytes()
assert new_import == ''.join('import MicroCFTA.' + i['module'] + '\n' for i in expected if i['kind'] == 'new_module').encode()
assert len(new_import) == 58 and stage['new_ordinary_audit_imports'] == 1
assert (root / audit_name).read_bytes() == new_import + old_audit + b'\n' + public
assert sum(line.startswith(b'import ') for line in (root / audit_name).read_bytes().splitlines()) == 5258
assert (root / audit_name).read_bytes().count(b'#print axioms ') == 690

# Only Root executes the mutation phase after reviewing this candidate.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-warm-prefix-preservation-publication-'))
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
(runtime / 'PUBLIC-PROBES.lean.txt').write_bytes(public)
commands = []
strict_sources = []
for item, normal in zip(expected, normal_sources):
    module = item['module']
    probes = ''.join('#check @' + name + '\n#print axioms ' + name + '\n' for name in item['names'])
    assert probes.count('#print axioms ') == 1
    source = runtime / 'source/MicroCFTA' / (module + '.lean')
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_bytes(normal + b'\n' + probes.encode())
    strict_sources.append(source)
    commands.append(['lake', 'env', 'lean', '-j1', '-DwarningAsError=true', '-R',
        str(source.parent.parent), '-o', str(objects / (module + '.olean')), str(source)])
independent = runtime / 'IndependentProbes.lean'
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 279 and new_import not in prior_independent
independent.write_bytes(new_import + prior_independent + b'\n' + public)
assert independent.read_bytes().count(b'#print axioms ') == 285
selection = {'prior_checkpoint': prior_commit,
    'prior_archive_manifest_sha256': expected_prior_manifest,
    'prior_checked_sha256': sha((prior_run / 'checked.json').read_bytes()),
    'prior_pins_sha256': sha((prior_run / 'source-pins.json').read_bytes()),
    'baseline_sha256': sha((work / 'baseline-source-pins.json').read_bytes()),
    'stage_sha256': sha(stage_path.read_bytes()), 'baseline_overrides': expected_overrides,
    'override_digests': {name: sha((root / path).read_bytes()) for name, path in expected_overrides.items()},
    'resource_owner_sha256': resource_owner_sha,
    'prior_source_files': 6257, 'prior_combined_reports': 478,
    'replaced_old_reports': 0, 'inherited_reports': 478, 'fresh_reports': 6, 'combined_reports': 484,
    'new_theorem_declarations': 8, 'new_public_theorems': 6, 'new_private_theorems': 2,
    'new_private_explicit_reports': 0, 'private_helpers_counted_as_explicit_fresh_reports': False,
    'unchanged_existing_source_files': 6251, 'old_owner_full_prefixes_preserved': 5,
    'old_audit_offset': 58, 'new_audit_imports': 1,
    'owner_preflight_reports_fresh_this_batch': 0, 'resource_owner_reports_inherited': 264,
    'axiom_strings_replayed': False}
(runtime / 'INHERITANCE-SELECTION.json').write_text(json.dumps(selection, indent=2) + '\n')
STRICT_BINDING_TEMPLATE = "from pathlib import Path\nimport gzip\nimport hashlib\nimport json\nimport subprocess\n\nroot = Path('/home/tritlo/Code/mcfta')\nruntime = Path(__file__).parent\nprior = root / 'lean/restart-evidence/20261117-warm-edge-initial-profile-publication'\narchive = root / 'lean/restart-evidence/20261117-warm-edge-initial-profile-checkpoint'\nwork = root / 'lean/restart-evidence/20261117-warm-prefix-preservation-work'\nsha = lambda data: hashlib.sha256(data).hexdigest()\nselection = json.loads((runtime / 'INHERITANCE-SELECTION.json').read_text())\nassert sha((archive / 'manifest.json').read_bytes()) == selection['prior_archive_manifest_sha256']\nassert selection['prior_archive_manifest_sha256'] == '3e53a171aa5a71d27be39804cd837a080a2b19d94e33c3f1e3b74c6b89ea0e1b'\ncommitted = subprocess.check_output(['git', 'show', selection['prior_checkpoint'] + ':'\n    + str((archive / 'manifest.json').relative_to(root))], cwd=root)\nassert committed == (archive / 'manifest.json').read_bytes()\nsubprocess.run(['python3', str(archive / 'verify.py')], check=True)\nrecords = json.loads((archive / 'archived-inputs.json').read_text())\nfor name in ['checked.json', 'source-pins.json']:\n    path = prior / name\n    record = next(item for item in records if item['original'] == str(path))\n    archived = (archive / record['archived']).read_bytes()\n    if record['gzip']:\n        archived = gzip.decompress(archived)\n    assert archived == path.read_bytes()\nassert sha((prior / 'checked.json').read_bytes()) == selection['prior_checked_sha256']\nassert sha((prior / 'source-pins.json').read_bytes()) == selection['prior_pins_sha256']\nassert sha((work / 'baseline-source-pins.json').read_bytes()) == selection['baseline_sha256']\nassert sha((work / 'SOURCES-NORMAL-STAGING.json').read_bytes()) == selection['stage_sha256']\noverrides = selection['baseline_overrides']\nbaseline = json.loads((work / 'baseline-source-pins.json').read_text())\nfor name, path in overrides.items():\n    assert sha((root / path).read_bytes()) == selection['override_digests'][name] == baseline[name]\nfor name, digest in json.loads((prior / 'source-pins.json').read_text()).items():\n    assert sha((root / overrides.get(name, name)).read_bytes()) == digest, name\nassert sha((root / 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean').read_bytes()) == selection['resource_owner_sha256']\nprint(json.dumps({'inherited_component_reports_verified': 478,\n                  'fresh_public_reports_expected': 6,\n                  'new_private_helper_declarations': 2,\n                  'new_private_explicit_reports': 0,\n                  'fresh_owner_preflight_reports': 0,\n                  'unchanged_owner_reports_inherited': 264,\n                  'historical_snapshots_and_toolchain_byte_exact': True}), flush=True)\n"
strict = runtime / 'strict-new-and-bind.py'
strict.write_text(STRICT_BINDING_TEMPLATE + '\ncommands = ' + repr(commands)
    + '\nfor command in commands:\n    subprocess.run(command, check=True)\n')
template = (prior_run / 'check.py').read_text()
driver = template[:template.index('\njobs =')]
jobs = [('public-build', 'exec lake build', 0),
    ('strict-new-components-and-prior-bindings', 'exec python3 ' + shlex.quote(str(strict)), 6),
    ('independent-imports', 'exec lake env lean -j1 -DwarningAsError=true ' + shlex.quote(str(independent)), 285),
    ('audit-build', 'exec lake build MicroCFTA.Audit', 0),
    ('audit-strict', 'exec lake env lean -j1 -DwarningAsError=true MicroCFTA/Audit.lean', 690)]
driver += '\njobs = ' + repr(jobs) + '''
for name, command, count in jobs:
    run(name, command, count)
assert len(checks) == 5
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx']
           and (not job[2] or c['total_axiom_reports'] == job[2]) for c, job in zip(checks, jobs))
assert checks[1]['axiom_groups'] == 6 and checks[1]['axiom_free_reports'] == 0
assert checks[2]['axiom_groups'] == 282 and checks[2]['axiom_free_reports'] == 3
assert checks[4]['axiom_groups'] == 684 and checks[4]['axiom_free_reports'] == 6
match = re.search(r'Checked axiom dependencies of (\\d+) MicroCFTA theorems\\.', (runtime / 'audit-strict.txt').read_text())
assert match
'''
report = dict(prior)
for name in ['checks', 'limits', 'at', 'audited_theorems', 'checked_code', 'owner_preflight_evidence',
        'old_audit_bytes_preserved_as_prefix', 'old_audit_bytes_preserved_contiguously_after_three_imports']:
    report.pop(name, None)
for name in list(report):
    if name.startswith('old_non_audit_'):
        report.pop(name)
report.update(source_files=6258, direct_audit_imports=5258, individual_reports=690,
    independent_reports=285, resource_and_component_probes=484,
    inherited_resource_component_reports=478, fresh_resource_component_reports=6,
    replaced_old_reports=0, fresh_owner_preflight_reports=0,
    fresh_strict_normal_reports=6, actual_publication_strict_reports=6,
    resource_component_evidence='6 actual fresh public strict reports plus478 inherited reports;2 new private Aux helpers add no explicit report; no replacement or resource-owner strict preflight',
    new_component_reports=6, new_theorem_reports=6, new_theorem_declarations=8,
    new_modules=1, changed_existing_owners=5, new_public_theorems=6, new_private_theorems=2,
    new_private_component_reports=0, new_public_component_reports=6, new_private_predicates=0,
    new_private_helpers=2, private_helpers_checked_transitively=True,
    private_helpers_counted_as_explicit_fresh_reports=False,
    owner_resource_probes=264, previous_owner_resource_probes=264,
    owner_recompiled_in_publication_strict_gate=False, fresh_owner_preflight_evidence=None,
    inherited_owner_preflight_evidence={'prior_run': str(prior_run), 'reports': 264,
        'normal_owner_sha256': resource_owner_sha, 'fresh_this_batch': False, 'included_in_inherited_478': True},
    entire_previous_resource_owner_byte_exact=True, old_resource_owner_sha256=resource_owner_sha,
    old_source_files_byte_exact=6251, all_five_old_owner_prefixes_byte_exact=True,
    baseline_overrides=expected_overrides, historical_pins_use_exact_before_snapshots=True,
    current_public_pins_use_new_source_bytes=True,
    old_audit_bytes_preserved_contiguously_after_one_import=True,
    old_audit_exact_offset=58, new_audit_imports=1,
    all_old_proof_bodies_and_limits_unchanged=True,
    first_check_passed_without_repair=False, all_new_formal_proof_checks_first_pass=False,
    first_import_setup_failure23315_preserved=True, candidate_proofs_and_headers_not_repaired=True,
    compiler_import_overlay_only_repaired=True,
    all_six_original_first_headers_exact=True,
    generic_warm_origin_and_prefix_interfaces_proved=True, warm_child_reader_interfaces_proved=True,
    four_auxiliary_laws_at_every_actual_warm_prefix_proved=True,
    entry_qualifier_keeps_same_full_newCount_H=True,
    source_warm_C_and_M_body_callbacks_proved=False, source_semantic_finish_callbacks_proved=False,
    warm_result_callbacks_proved=False, warm_query_no_new_mu_proved=False,
    every_warm_worker_call_qualification_proved=False,
    all_warm_cells_source_qualification_proved=False, joint_finite_completion_proved=False,
    all_native_inhabitance_proved=False, source_type_marker_class_consistency_proved=False,
    compiled_haskell_correspondence_proved=False, haskell_changed=False,
    same_original_runtime_fuels=True,
    proof_limits='unchanged old owner settings and defaults for new proofs; no limit increase',
    prior_checkpoint=prior_commit, prior_immutable_archive=prior_archive.name, public_run=str(runtime))
driver += 'report = ' + repr(report) + '\n'
driver += '''report.update(checks=checks, limits=limits, at=datetime.datetime.now().astimezone().isoformat(),
              audited_theorems=int(match.group(1)))
(runtime / 'checked.json').write_text(json.dumps(report, indent=2) + '\\n')
print(json.dumps(report), flush=True)
'''
(runtime / 'check.py').write_text(driver)
# Current publication pins always bind the actual NEW Source files.
files = list((root / 'lean/MicroCFTA').glob('*.lean'))
files += [root / n for n in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']]
files += [p for p in runtime.iterdir() if p.is_file()] + strict_sources
files += [Path(__file__), stage_path, work / 'baseline-source-pins.json', work / 'PUBLIC-PROBES.lean.txt',
    work / 'IMPORTS.lean.txt'] + [root / p for p in expected_overrides.values()] + headers + checked_inputs
for packet in set(packets):
    files += [packet / n for n in ['MANIFEST.json', 'SOURCE-PINS.json']]
(runtime / 'source-pins.json').write_text(json.dumps({str(p.relative_to(root)): sha(p.read_bytes()) for p in files}, indent=2) + '\n')
print(json.dumps({'run': str(runtime), 'gates': 5, 'fresh_component_reports': 6,
    'inherited_component_reports': 478, 'combined_component_reports': 484,
    'new_theorem_declarations': 8, 'new_private_explicit_reports': 0,
    'fresh_resource_owner_reports': 0, 'inherited_resource_owner_reports': 264,
    'source_files': 6258, 'independent_reports': 285, 'audit_reports': 690,
    'objects': str(objects)}))
