"""Verify retained source identities and literal read cuts."""
from pathlib import Path
import hashlib,json,re
ROOT=Path('/home/tritlo/Code/mcfta');AREA=Path('/tmp/mcfta-recursive-ancestry-progress-20261029');checked=[]
def verify(path,record,field='sha256'):
 p=Path(path);data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==record[field],str(p)
 if field=='sha256' and 'bytes' in record:assert len(data)==record['bytes'],str(p)
 checked.append({'path':str(p),'sha256':record[field]});return data
p=json.loads((AREA/'prefix/evidence-v1/manifest.json').read_text())
for item in p['sources']:
 source=verify(item['source'],item);assert verify(item['whole_snapshot'],item)==source
 for cut in item.get('cuts',[]):assert verify(cut['path'],cut)==b''.join(source.splitlines(keepends=True)[cut['first']-1:cut['last']])
for field in ['candidate','public_signature','report']:verify(p[field]['path'],p[field])
for block in p['copied_private_blocks']:
 source=(ROOT/'lean/MicroCFTA/SourcePruningEnumerationPrefixCanonicalHistory.lean').read_bytes();candidate=Path(p['candidate']['path']).read_bytes();start=('private theorem '+block['name']).encode();a=source[source.index(start):source.index(start)+block['bytes']];b=candidate[candidate.index(start):candidate.index(start)+block['bytes']];assert a==b and hashlib.sha256(a).hexdigest()==block['sha256']
p=json.loads((AREA/'opaque/audit-v1/source-manifest.json').read_text())
for item in p['inputs']:
 preserved=verify(item['preserved'],item)
 if 'source_sha256' in item:source=verify(item['source'],item,'source_sha256');assert preserved==b''.join(source.splitlines(keepends=True)[item['first']-1:item['last']])
 else:assert preserved==verify(item['source'],item)
for field in ['candidate','public_statement']:verify(p[field]['path'],p[field])
p=json.loads((AREA/'output/inputs-v1-manifest.json').read_text())
for item in p['files']:
 source=Path(item['source']);source=source if source.is_absolute() else ROOT/source;copy=AREA/'output'/item['copy'];preserved=verify(copy,item)
 if 'source_sha256' in item:
  data=verify(source,item,'source_sha256');scope=re.search(r'CUT (\d+)-(\d+)',item['read_scope']);assert scope;assert preserved==b''.join(data.splitlines(keepends=True)[int(scope[1])-1:int(scope[2])])
 else:assert verify(source,item)==preserved
(AREA/'scope-verification.json').write_text(json.dumps({'identity_records':len(checked),'unique_paths':len({r['path'] for r in checked}),'records':checked},indent=2)+'\n');print('Verified scope identities:',len(checked),'at',len({r['path'] for r in checked}),'paths')
