"""Verify diagnostic planning inputs and retain the literal reviewed ranges."""
from pathlib import Path
import hashlib,json
AREA=Path('/tmp/mcfta-recursive-ancestry-progress-20261029');base=AREA/'diagnostic-next/audit-v1';manifest=json.loads((base/'manifest.json').read_text());records=[];cuts=[]
for record in manifest['files']:
 source=Path(record['source']);snapshot=base/record['snapshot'];data=source.read_bytes();assert data==snapshot.read_bytes();assert len(data)==record['bytes'];assert hashlib.sha256(data).hexdigest()==record['sha256']
 for p in [source,snapshot]:records.append({'path':str(p),'sha256':record['sha256']})
 lines=data.splitlines(keepends=True)
 for first,last in record['reviewed_ranges']:
  assert 1<=first<=last<=len(lines);raw=b''.join(lines[first-1:last]);target=AREA/'diagnostic-read-cuts'/(source.stem+'.L'+str(first)+'-'+str(last)+'.lean');target.parent.mkdir(exist_ok=True);assert not target.exists();target.write_bytes(raw);cuts.append({'source':str(source),'source_sha256':record['sha256'],'first':first,'last':last,'path':str(target),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(AREA/'diagnostic-scope-verification.json').write_text(json.dumps({'identity_records':len(records),'records':records,'retained_review_cuts':cuts,'status':'Source-only planning; no new theorem or runtime predicate installed'},indent=2)+'\n');print('Verified diagnostic input identities:',len(records),'and literal review cuts:',len(cuts))
