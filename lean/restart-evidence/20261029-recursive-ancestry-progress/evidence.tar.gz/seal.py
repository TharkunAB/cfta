"""Seal every regular file after final source and document identity checks."""
from pathlib import Path
import hashlib,json,subprocess,datetime,os
ROOT=Path('/home/tritlo/Code/mcfta');AREA=Path('/tmp/mcfta-recursive-ancestry-progress-20261029');assert not (AREA/'FROZEN.json').exists()
for name in ['prior-lean-sources.json','prior-strong-sources.json','inherited-prior-haskell-sources.json','final-proof-sources.json','final-documents.json']:
 for record in json.loads((AREA/name).read_text()):
  data=(ROOT/record['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==record['sha256'];assert 'bytes' not in record or len(data)==record['bytes']
for record in json.loads((AREA/'prior-documents.json').read_text()):assert (ROOT/record['path']).read_bytes().endswith((AREA/'prior-document-bodies'/record['path']).read_bytes())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head==json.loads((AREA/'docs-commit.json').read_text())['head'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT);subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],cwd=ROOT,check=True)
assert json.loads((AREA/'root-progress-final.json').read_text())['goal']['status']=='active';assert json.loads((AREA/'root-progress-final.json').read_text())['full_objective_complete'] is False
state={'head':head,'main':subprocess.check_output(['git','rev-parse','origin/main'],cwd=ROOT,text=True).strip(),'main_is_ancestor':True};(AREA/'upstream-state.json').write_text(json.dumps(state,indent=2)+'\n')
paths=sorted(AREA.rglob('*'));assert not any(p.is_symlink() for p in paths);payloads=[]
for p in paths:
 if p.is_file():
  data=p.read_bytes();payloads.append({'path':str(p.relative_to(AREA)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
seal={'write_halt':True,'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':(AREA/'source-head.txt').read_text().strip(),'docs_head':head,'full_goal':'active','payloads':payloads};(AREA/'FROZEN.json').write_text(json.dumps(seal,indent=2)+'\n')
for p in AREA.rglob('*'):os.chmod(p,0o555 if p.is_dir() else 0o444)
os.chmod(AREA,0o555);print(json.dumps({'write_halt':True,'payloads':len(payloads),'raw_bytes':sum(p['bytes'] for p in payloads),'source_head':seal['source_head'],'docs_head':head}))
