import MicroCFTA.SourcePruningEnumerationClear
import MicroCFTA.SourcePruningEnumerationEntry
import MicroCFTA.SourcePruningEnumerationSelection

namespace MicroCFTA.SourcePruningEnumerationRecursion
open EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationCompressionFrame
open InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes SourcePruningEnumerationObservation
local notation "Symbol" => SourcePruningTemplates.Symbol
variable {EnumGuard NativeGuard : Type}

local instance recursionMonadList : Monad List where
  pure value := [value]
  bind values continuation := values.flatMap continuation

/-- Check the actual native boundary and clear the bucket only for a repeated recursion key. -/
def checkRepeated (heap : InternedConstructorTemplates.State Symbol NativeGuard)
    (fuel uv handle : Nat) (scs : List Suspended) : EnumerateM Symbol EnumGuard Bool := do
  match lookupNode heap handle with
  | none => failure .unresolvedReference
  | some value =>
      if MergedOrdinaryHeight.recursiveBoundary value then
        let root ← representative fuel uv
        let current : EnumerationState.State Symbol EnumGuard ← get
        if recursionKey handle scs ∈ current.recursionAncestry root then
          setValue root (.unenumerated (some handle) [])
          pure true
        else pure false
      else pure false

/-- The actual native recursion guard derives finite execution and both indexed cache outcomes. -/
theorem complete
    (heap : InternedConstructorTemplates.State Symbol NativeGuard)
    (before : EnumerationExpandableIndex.Cached Symbol EnumGuard)
    (uv handle : Nat) (scs : List Suspended) (value : Value Symbol NativeGuard) (roots : Nat → Nat)
    (ready : EnumerationDriver.Ready uv before.core)
    (stored : before.core.values[uv]? = some (.unenumerated (some handle) scs))
    (realized : PendingRealized heap before.core)
    (decoded : lookupNode heap handle = some value)
