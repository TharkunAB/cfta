import MicroCFTA.SourcePruningEnumerationSelectedStep
import MicroCFTA.SourcePruningEnumerationSelectedOrdinary

namespace MicroCFTA.SourcePruningEnumerationSelectedStep
open EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationCompressionFrame
open InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes SourcePruningEnumerationObservation
open SourceCurrentAllocatedQueryMemo (advancePhysical)
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Context Post)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Core" => EnumerationState.State Symbol Constraint
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Metadata" => SourcePruningRecordTypes.Metadata

variable {Typing Key : Type} {width : Nat}
variable [DecidableEq (EdgeKey Symbol Constraint)]
variable (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
variable (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
variable (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
variable (stop : Option (Metadata Typing → Nat → Bool))
variable (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing)

attribute [local instance] SourcePruningEnumerationAction.actionMonadList

/-- The actual nonempty preparation fixes its pure or representative-and-write action. -/
theorem prepared_action
    (nativeFuel representativeFuel uv oldHandle newHandle : Nat) (scs : List Suspended)
    (oldValue value : Node) (heap nextHeap : InternedConstructorTemplates.State Symbol Constraint)
    (narrowed : SourcePruningOuterNarrow.narrow holeKey fits admits metadata nativeFuel uv oldValue heap =
      .done value nextHeap)
    (nonempty : value ≠ .empty) (encoded : encodeNode value = some newHandle) :
    SourcePruningEnumerationAction.prepare holeKey fits admits metadata nativeFuel representativeFuel
      uv oldHandle scs oldValue heap =
      .done (value, some (if newHandle = oldHandle then (pure () : EnumerateM Symbol Constraint Unit)
        else representative representativeFuel uv >>= fun selected =>
          setValue selected (.unenumerated (some newHandle) scs))) nextHeap := by
  cases value with
  | empty => exact False.elim (nonempty rfl)
  | reference name => simp [encodeNode] at encoded
  | node entry edges depth free => simp only [SourcePruningEnumerationAction.prepare, narrowed, encoded]
  | union entry members depth free => simp only [SourcePruningEnumerationAction.prepare, narrowed, encoded]
  | mu entry body depth ordinary => simp only [SourcePruningEnumerationAction.prepare, narrowed, encoded]

/-- Successful preparation has one raw row at its actual reached core. -/
theorem prepared_singleton
    (nativeFuel representativeFuel uv oldHandle newHandle : Nat) (scs : List Suspended)
    (oldValue value : Node) (heap nextHeap : InternedConstructorTemplates.State Symbol Constraint)
    (action : EnumerateM Symbol Constraint Unit) (checked after : Core)
    (narrowed : SourcePruningOuterNarrow.narrow holeKey fits admits metadata nativeFuel uv oldValue heap =
      .done value nextHeap)
    (nonempty : value ≠ .empty) (encoded : encodeNode value = some newHandle)
    (prepared : SourcePruningEnumerationAction.prepare holeKey fits admits metadata nativeFuel representativeFuel
      uv oldHandle scs oldValue heap = .done (value, some action) nextHeap)
    (observed : Success action checked () after) :
    ExceptT.run (action checked) = [.ok ((), after)] := by
  have actual := prepared_action holeKey fits admits metadata nativeFuel representativeFuel uv oldHandle newHandle
    scs oldValue value heap nextHeap narrowed nonempty encoded
  rw [prepared] at actual
  have actionSame : action =
      (if newHandle = oldHandle then (pure () : EnumerateM Symbol Constraint Unit)
        else representative representativeFuel uv >>= fun selected =>
          setValue selected (.unenumerated (some newHandle) scs)) :=
    Option.some.inj (Prod.mk.inj (MergedSourceComparison.Result.done.inj actual).1).2
  rw [actionSame] at observed ⊢
  by_cases same : newHandle = oldHandle
  · rw [ite_eq_left same] at observed ⊢
    obtain ⟨_unit, rfl⟩ := (success_pure () () checked after).mp observed
    rfl
  · rw [ite_eq_right same] at observed ⊢
    obtain ⟨selected, resolved, reading, writing⟩ := (success_bind _ _ checked () after).mp observed
    obtain ⟨found, lookup, selectedSame, resolvedSame⟩ :=
      (representative_success representativeFuel uv checked resolved selected).mp reading
    have raw : representative representativeFuel uv checked = [.ok (selected, resolved)] := by
      rw [selectedSame, resolvedSame]
      exact representative_exact representativeFuel uv checked found lookup
    rw [bind_single _ _ checked resolved selected raw]
    have afterSame := (EnumerationDriver.modify_success _ resolved after).mp writing
    rw [afterSame]
    rfl

variable [DecidableEq Symbol] [DecidableEq Node]

/-- Factoring the prefix preserves the entire original observation at every input and bound. -/
theorem run_eq_legacy
    (readFuel checkFuel nativeFuel representativeFuel indexFuel callbackFuel r n p h k uv : Nat)
    (caller : Caller width) (before : Cached) (queries : Queries) :
    run holeKey fits admits graph templates checkEmpty edgesOf stop order metadata
      readFuel checkFuel nativeFuel representativeFuel indexFuel callbackFuel r n p h k uv caller before queries =
    (let read := ExceptT.run (getValue readFuel uv before.core)
     match read with
     | [.ok (.unenumerated (some oldHandle) scs, readAfter)] =>
         let check := ExceptT.run (SourcePruningEnumerationRecursion.checkRepeated
           caller.checked.native.machine.heap checkFuel uv oldHandle scs readAfter)
         match check with
         | [.ok (true, checked)] =>
             let candidate := SourcePruningEnumerationParkedRestart.adapt
               caller.checked.native.machine.heap indexFuel uv oldHandle scs before checked
             .parked checked candidate (candidate.map fun parked =>
               ExceptT.run (SourcePruningEnumerationRestart.run stop order metadata parked checked))
         | [.ok (false, checked)] =>
             match lookupNode caller.checked.native.machine.heap oldHandle with
             | none => .stopped read (some check)
             | some oldValue =>
                 let prepared := SourcePruningEnumerationAction.prepare holeKey fits admits metadata nativeFuel
                   representativeFuel uv oldHandle scs oldValue caller.checked.native.machine.heap
                 let reached := SourceCurrentAllocatedPartialState.advance caller
                   (advancePhysical caller.checked ⟨prepared.state, caller.checked.operations⟩) caller.fourth caller.merge
                 match prepared with
                 | .failed _fault _heap => .narrowed checked prepared reached queries none none none none
                 | .done (_value, none) _heap => .narrowed checked prepared reached queries none none none none
                 | .done (value, some action) heap =>
                     let raw := ExceptT.run (action checked)
                     match raw with
                     | [.ok ((), observed)] =>
                         match encodeNode value with
                         | none => .narrowed checked prepared reached queries (some raw) none none none
                         | some newHandle =>
                             let candidate := SourcePruningEnumerationNarrowAdapter.adapt heap indexFuel
                               uv oldHandle newHandle scs before observed
                             match candidate with
                             | none => .narrowed checked prepared reached queries (some raw) none none none
                             | some attached =>
                                 let right := ExceptT.run (SourcePruningRecordTypes.recordTypes
                                   graph templates callbackFuel metadata uv (.inr newHandle) attached.core)
