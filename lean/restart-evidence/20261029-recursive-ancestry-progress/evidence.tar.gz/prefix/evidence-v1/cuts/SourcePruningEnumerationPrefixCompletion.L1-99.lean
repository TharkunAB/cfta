import MicroCFTA.SourcePruningEnumerationPreparedFuel
import MicroCFTA.SourcePruningEnumerationPrefixHistory

namespace MicroCFTA.SourcePruningEnumerationSelectedStep
open EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationCompressionFrame
open InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes SourcePruningEnumerationObservation
open SourceCurrentAllocatedQueryMemo (advancePhysical)
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Context Post)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Core" => EnumerationState.State Symbol Constraint
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Metadata" => SourcePruningRecordTypes.Metadata
variable {Typing Key : Type} {width : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
variable (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
variable (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
variable (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
variable (stop : Option (Metadata Typing → Nat → Bool))
variable (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing)
attribute [local instance] SourcePruningEnumerationAction.actionMonadList

/-- Retain the complete earlier capability and the prefix endpoint's counter and dependency levels.
The finish expression embeds the observation in the earlier proposition.
The recursive worker does not execute this finish expression. -/
def PrefixValid
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (fuel uv : Nat) (caller : Caller width) (before : Cached) (memos : Memos)
    (result : Result width Typing) : Prop :=
  (match result with
    | .narrowed _ _ _ _ _ _ _ ordinary => ordinary = none
    | _ => True) ∧
  Valid holeKey fits admits graph templates checkEmpty edgesOf stop order metadata formulas solver inventory
    fuel fuel fuel fuel fuel fuel 0 0 0 0 0 uv caller before memos
    (finish checkEmpty edgesOf 0 0 0 0 0 uv result) ∧
  match result with
  | .parked _ (some after) _ | .narrowed _ _ _ _ _ (some after) _ _ =>
      after.core.counter = before.core.counter ∧
      ∀ level frontier, EnumerationOrder.Stratified before.core level frontier →
        EnumerationOrder.Stratified after.core level frontier
  | _ => True

/-- Original selected inputs derive one sufficient fuel for every prefix operation and every larger bound. -/
theorem prefix_complete
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (caller : Caller width) (memos : Memos) (before : Cached)
    (preference : List Nat → Option Nat) (uv : Nat) (roots : Nat → Nat)
    (initial : Context formulas solver inventory caller memos) (safe : Safe before.core)
    (pending : EnumerationReferences.PendingReferences before.core)
    (selection : EnumerationPureSelection.next preference before = .expand uv)
    (realized : PendingRealized caller.checked.native.machine.heap before.core)
    (paths : Roots before.core.representatives roots)
    (counts : EnumerationCanonicalWaiting.Correct roots before.core.values before.waiting)
    (flags : ∀ slot, SourcePruningEnumerationNativeIndex.candidate caller.checked.native.machine.heap
      ((before.core.values[slot]?).getD .eliminated) = some (before.expandable slot)) :
    ∃ fuel, ∀ extra,
      PrefixValid holeKey fits admits graph templates checkEmpty edgesOf stop order metadata
        formulas solver inventory (fuel + extra) uv caller before memos
        (runPrefix holeKey fits admits graph templates stop order metadata
          (fuel + extra) (fuel + extra) (fuel + extra) (fuel + extra) (fuel + extra) (fuel + extra)
          uv caller before memos.query) := by
  obtain ⟨readFuel, oldHandle, scs, oldValue, readAfter, checkFuel, repeated, checked, stored, oldDecoded,
    _oldAvailable, _oldClosed, readExact, checkExact, checkReady, checkPaths, checkRealized,
    checkCounts, checkFlags, _checkIncoming, checkPending, parked, continued⟩ :=
    SourcePruningEnumerationSelectedOrdinary.complete_with_history formulas solver inventory caller memos
      holeKey fits admits metadata graph templates checkEmpty edgesOf before preference uv roots
      initial safe pending selection realized paths counts flags
  cases repeated with
  | true =>
      obtain ⟨_boundary, _cleared, _disabled, _waiting, resolved, countFuel, frame, _reading,
        _seen, written, indexed⟩ := parked rfl
      obtain ⟨counter, ordered⟩ := SourcePruningEnumerationParkedRestart.parked_order uv oldHandle scs
        before.core resolved checked.core stored frame written
      let bound := readFuel + checkFuel + countFuel
      refine ⟨bound, ?_⟩
      intro extra
      let w := bound + extra
      have readLe : readFuel ≤ w := by dsimp [w, bound]; omega
      have checkLe : checkFuel ≤ w := by dsimp [w, bound]; omega
      have countLe : countFuel ≤ w := by dsimp [w, bound]; omega
      have reading := readExact (w - readFuel)
      have checking := checkExact (w - checkFuel)
      rw [Nat.add_sub_of_le readLe] at reading
      rw [Nat.add_sub_of_le checkLe] at checking
      have index := indexed (w - countFuel)
      rw [Nat.add_sub_of_le countLe] at index
      have adapted := SourcePruningEnumerationParkedRestart.adapt_after_write caller.checked.native.machine.heap
        w uv oldHandle scs before checked resolved checked.core written index rfl
      have prefixRun : runPrefix holeKey fits admits graph templates stop order metadata w w w w w w
          uv caller before memos.query = .parked checked.core (some checked)
          (some (ExceptT.run (SourcePruningEnumerationRestart.run stop order metadata checked checked.core))) := by
        simp only [runPrefix, reading, checking, adapted, Option.map_some]
