# Actual selected-prefix recursion ancestry

[2026-10-29 Europe/Stockholm] Status: UNTESTED SOURCE-ONLY CANDIDATE v1.

Candidate: `candidate-v1/MicroCFTA/SourcePruningEnumerationPrefixAncestryExtension.lean`.
One additive module. One public theorem. Four private proof helpers. No producer wrapper.

## Contract

`SelectedStep.prefix_recursion_ancestry` uses the exact explicit input order of
`PrefixCanonicalHistory.prefix_canonical`. Its original `canonical` input is replaced by
`total : UnionFind.Total before.core.representatives`. The final input remains the exact
`PrefixValid` for the actual common-fuel `runPrefix`.

The conclusion matches that same literal actual prefix result. A parked Some cache or
narrowed Some cache has `after.core.recursionAncestry = before.core.recursionAncestry`.
Every other result yields True. The complete function equality includes every raw slot,
including slots outside the current counter. It does not require a future heap or
history-preservation supplier.

`public-signature.lean.txt` preserves the complete exact candidate declaration without its proof.
The existing DecidableEq instances and implicit Typing/Key/width parameters are retained.
No model, Origins, Canonical, ProperState, output-arity, output-projectability, action oracle,
post-Entry model or source/prepared value cast is an admission.

## Proof route

1. The actual getValue singleton supplies its original full compression Frame.
   Original Total transfers through that Frame.
2. For a parked result, the actual successful recursion check is decomposed.
   Representative compression retains recursionAncestry. Reading the state changes no field.
   A repeated key causes setValue, which changes only values. A nonrepeated or nonboundary
   check is pure. The check therefore retains the whole ancestry function for either Boolean.
3. For a narrowed retained cache, PrefixValid exposes the literal read/check/prepare equations.
   The private retained-action inversion is copied exactly from the old canonical proof.
   It simplifies the ACTUAL runPrefix, its singleton action row, adapter and pure Right recording.
   It derives Success of the same selectedAction at checked and the actual retained cache core.
   An arbitrary action-preservation premise is not used.
4. The existing prepared_action theorem identifies that actual nonempty action as pure when
   handles agree, or representative followed by setValue when handles differ. The latter write
   changes values only. This derives unchanged ancestry at the actual cache.
5. The actual false recursion check supplies an existing full Frame only for that false-check
   substep. Its Total and ancestry equalities compose with the first read and actual action.
   A full Frame is not claimed for the entire prefix, because bucket clears and narrowing
   can change values.

The prepared action still uses distinct oldValue and value witnesses. Original decoding,
native narrowing, prepared action and the actual observed retained cache remain linked by
literal equations. Right recording is justified by recordTypes_inr, not a future callback assumption.

## Reused source

Two inaccessible private helpers are copied byte-for-byte from the observed old source:
`retained_action_success` and `finish_cache_fields`. Their source and copied-block SHA256 values
are in manifest.json. The public tuple inversion follows the existing checked canonical proof.
The new private helpers prove only the structural ancestry equalities at the actual check and
prepared nonempty action. Existing `Frame.total`, `getValue_frame`, `prepared_action` and
`checkRepeated_false_frame` are reused.

## Validation and ownership

No Lean, lake, compiler, native evaluator, Git, network, board or repository mutation ran.
Root owns compilation and all repository work. The module remains UNTESTED until Root checks it.
No budgets, linter suppressions, sorry, admit, custom axioms or runtime definitions were added.
No Haskell fix or Haskell change occurred.

The original candidate is immutable. Later root-side repairs must preserve it and record a
separate source identity. The whole source snapshots preserve exact inputs. Read scopes are
listed separately; copying a whole file is not a claim that its whole body was reviewed.
