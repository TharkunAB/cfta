# Diagnostic cache ancestry: bounded source audit

Date: 2026-10-29, Europe/Stockholm. Status: source-only report. No Lean candidate, compiler, evaluator, native run, repository change, Git operation, network operation, or board operation was made. Root owns validation. The manifest records 23 whole-file snapshots and the narrower ranges actually reviewed. A whole snapshot does not assert whole-file review.

## Result

The current output ancestry theorem does not cover caches attached to a stopped diagnostic. A separate diagnostic certificate must be proved through the existing finite-depth construction. No additional primitive cache-retention observer appears necessary. The missing information is the smaller-depth diagnostic certificate and its composition through callback and sibling control flow.

ResourceHistory is indexed by one emitted Output. Its stopped/done/parked/selected constructors prove a path to that output. A stopped result can have no outputs. The actual depth-zero expand case returns `.stopped [] (.exhausted uv metadata before) ...`. Its output-history assertion is vacuous, although the diagnostic contains `before`. This is an insufficiency of that certificate, not a runtime counterexample to ancestry retention. OutcomeResources also ignores the stopped reason: its stopped arm checks the optional native endpoint and emitted outputs only. Consequently neither certificate alone supplies ancestry for a reason payload.

## All data-valued Cached attachments

Use the actual PreparedRecursive.Failure, not the legacy worker Failure.

| Actual constructor | Cached attachments to include |
| --- | --- |
| exhausted uv metadata before | before |
| selected uv observed | SelectedStep.parked candidate, when Some; SelectedStep.narrowed candidate, when Some; plus receipt caches inside an optional ordinary NativeBranches.Result |
| callback uv raw | None. The raw rows contain Core, not Cached. |
| preparation uv raw | None. EntryRaw contains Core. The optional native preparation result is not an enumeration Cached. |
| alternatives uv processed current | Every attached cache of every processed receipt; then the current-stop attachments below |

For SelectedEdge.Result, rejected and complete each contain one Cached. Stopped contains its candidate when Some. Unhandled has none. Its completed-prefix fragments and ChildDispatch.Observation contain no additional Cached. Observation raw rows can contain Core. They are outside this Cached-only target.

For NativeContinuations.Stop, edge current contributes the attached cache of its optional receipt. Continuation receipt reason endpoint contributes BOTH the current receipt cache AND every cache recursively attached to reason. Endpoint contains only native Caller and query memos. Do not stop recursion after the first continuation.

The optional ordinary NativeBranches.Result in SelectedStep.narrowed contributes all processed receipts, plus its optional current receipt when stopped. The actual prepared worker uses runPrefix; prefix_no_ordinary excludes this ordinary attachment on its actual selected-prefix observations. It remains part of the full Failure datatype inventory.

A processed receipt can be rejected or stopped with `.ok (some [])` and Some cache, as well as complete. NativeBranches.advance allows these pruning receipts to continue. CompletedHeadReceipt alone therefore does not cover every processed cache. The all-cache CapturedEdge observer is the correct local input. A COMPLETE folded result discards processed receipts in PreparedRecursive.finish; those discarded receipts are not attachments of the returned HookResult. Emitted output caches remain covered by the existing output theorem.

## Minimal public extension

Propose `PreparedRecursive.run_finite_complete_resources_with_all_cache_ancestry`, with EXACTLY the original arguments of current `run_finite_complete_resources_with_ancestry`. Keep Packet, Fits, annotation Heap, BOTH original global selection gates, original suspended-mass bound, and PreparedReservation.Reserved. Add no model, Discharged, later-heap, hook-retention, or future-history premise.

Retain the entire existing existential bound/outcome, actual run equality for every extra work fuel, OutcomeResources, every ResourceHistory, and per-output Extends field. Append only:

    match outcome with
    | .complete _ _ _ => True
    | .stopped _ reason _ =>
        forall cache in the concrete Cached attachments of reason,
          Extends before.core cache.core

Here concrete attachments means exactly the constructor inventory above. An implementation can use a concrete Failure-cache occurrence relation or extractor, plus a receipt-cache helper. This report adds neither. The proposed relation is a necessary target of the producer proof; it must not be introduced as a supplied generic hook property.

Keep the original producer witness if desired. Derive a second closed diagnostic-producing witness by finite-depth induction. Compare its actual run at `diagnosticBound + oldBound` with the existing producer run at `oldBound + diagnosticBound`. The two exact run equalities identify the outcomes. The diagnostic conclusion has no work-fuel index, so transport it to the OLD outcome without changing its original bound, histories, or resource fields. This avoids reconstructing the existing output-history proof. It does not avoid the new diagnostic depth induction.

## Exact induction points

1. Zero depth: use the actual zero-outcome constructor classification. Exhausted carries the exact input cache, so Extends.refl closes it. Complete cases have no Failure. No emitted-output premise is needed.
2. Parked recursive restart: keep the actual prefix ancestry equality and the actual restart singleton/frame. Apply the diagnostic depth IH to its returned cache, then compose with prefix/frame Extends. This is the same concrete transport used by the output history proof, without requiring an output to exist.
3. Accepted preparation: retain literal preparation success and Entry/frame ancestry preservation. Carry the actual prepared parent separately from its stored source handle. The existing preparation history producer supplies the actual singleton prepared entry, packet, Ready and stored fields.
4. Native head/receipt: invoke CapturedEdge.observed_cache_ancestry_extension on headRun at a concrete common bound. It covers complete, rejected and stopped Some cache. The opaque alternative uses SelectedOpaqueDispatch.observed_cache_ancestry_extension. These are actual observations and need no arbitrary child-property supplier.
5. Callback: the actual finite callback producer has a literal singleton Bool/metadata/Core observation. True returns complete []; false supplies an actual frame and invokes the smaller-depth worker. Compose the local receipt Extends with the recording frame and diagnostic IH. Current SelectedHistoryReceipt.ancestry_extension_after_callback already shows the completed-receipt/frame composition; a diagnostic callback overlay must retain it even when the recursive outcome emits [].
6. Sibling scan: strengthen the actual alternatives_finite_complete_resources construction at its stopped head-outcome branch (reviewed lines 189-227). That branch constructs `.continuation (.complete ... after) reason reached` and currently retains only OutcomeResources for reason. Add current-receipt retention and the callback diagnostic certificate there. On a successful head followed by a stopped suffix, preserve the head receipt and every suffix receipt while prepending. This is the other place where diagnostic information is currently dropped.
7. Fold finish/driver: wrap these certificates in the actual `.alternatives uv processed current` Failure, and pass them unchanged through finish and the run-step wrapper. Close the strengthened finite-depth contract using the same original reservations and prefix/native/callback resource producers.

Siblings start from the SAME captured enumeration cache while native caller/query resources advance. Compare each head/receipt to its own actual captured input, then to the outer original cache. Do not chain unrelated sibling output caches. Post relates native caller resources; it is not an enum-cache ancestry rule.

## Reachability and limits

The positive-depth finite construction uses prefix_checkpoint_complete, actual successful preparation and the finite callback singleton. Those branches exclude transient selected/callback/preparation failures at its produced sufficiently-large work bound; exhausted and alternatives remain, including arbitrary nested prepared reasons supplied by the smaller-depth result. A diagnostic induction can prove this narrower reachable grammar alongside retention, but it must derive it from these actual constructions. Do not assume it as an original admission gate.

In particular, NativeHookResources.PreparedStoppedAt in PreparedHookCertificates is a DIFFERENT narrow certificate: it describes an unsupported edge or an exhausted continuation. It cannot restrict the general finite worker. The actual PreparedFiniteSiblingResources.StoppedAt explicitly quantifies an arbitrary PreparedRecursive.Failure reason. Its ReceiptAt and OutcomeResources fields do not state diagnostic ancestry.

This route covers data-valued Cached attachments of the returned diagnostic, including nested reasons and processed pruning receipts. It does not prove all Core-valued raw observations retain keys, arbitrary small-work-fuel error behavior, active expansion-key equality, transfer to a different representative slot, a finite handle universe, a strict global measure, termination, semantic completeness, or Discharged. Extends is same-raw-slot retention and can hold across finalization that clears expansionAncestry. No source defect or Haskell defect was found.
