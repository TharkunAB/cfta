import MicroCFTA.SourcePruningEnumerationPreparedFiniteSiblingFinishHistory
import MicroCFTA.SourcePruningEnumerationPreparedSelectedHistory
import MicroCFTA.SourcePruningEnumerationPreparedPreparationResources
import MicroCFTA.SourcePruningEnumerationSelectedContinuations
import MicroCFTA.SourcePruningEnumerationSuspendedMass

/-!
# Actual prepared ordinary dispatch with finite recursive callbacks

The preparation producer runs once before the actual value case split.
Its entire packet remains available for every case. An ordinary prepared
parent supplies its actual rows. The captured target remains unchanged.
The native callback runs before each next sibling at its actual endpoint.
-/
namespace MicroCFTA.SourcePruningEnumerationPreparedNativeOrdinaryResources
open EnumerationState EnumerationCorrectness InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Post)
open SourceCurrentConstrainedCapGeneratedQueryResources (Fits)
open SourcePruningEnumerationIncomingReservation (Seed)
open SourcePruningEnumerationPreparedReservation (stage ScanReserved)
open SourcePruningEnumerationRecursive (Packet Output)
open SourcePruningEnumerationPreparedRecursive (Failure continueWith resume endpoint OutcomeResources)
open SourcePruningEnumerationPreparedFiniteSiblingResources (ReceiptAt OutputAt StoppedAt)
attribute [local irreducible] SourcePruningEnumerationPreparedReservation.step
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Receipt" => SourcePruningEnumerationSelectedEdge.Result
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
local notation "Result" => SourcePruningEnumerationNativeContinuations.Result
local notation "scalar" => SourceCurrentConstrainedCapTargetForecast.scalar
local notation "suspendedBound" => SourcePruningEnumerationPrefixAdmission.suspendedBound
variable {Typing Key : Type} {bits : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Original current resources fix preparation before the actual ordinary sibling result. -/
theorem complete_resources_with_history
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (SourcePruningRecordTypes.Metadata Typing → Nat → Bool))
    (order : SourcePruningRecordTypes.Metadata Typing → List Nat → Option Nat)
    (metadata : SourcePruningRecordTypes.Metadata Typing) (recursiveFuel : Nat)
    (seed : Seed) (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (recursive : SourcePruningEnumerationPreparedRecursive.CompleteWithHistory (bits := bits)
      holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver recursiveFuel)
    (inventory : Inventory) (caller : Caller (bits + 2)) (memos : Memos) (before : Cached)
    (uv handle : Nat) (scs : List Suspended)
    (packet : Packet formulas solver inventory caller memos metadata before)
    (ready : EnumerationDriver.Ready uv before.core)
    (stored : before.core.values[uv]? = some (.unenumerated (some handle) scs))
    (bounded : Fits seed.2 caller.checked)
    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)
    (incoming : EnumerationReferences.IncomingAvoid uv before.core)
    (selectionMembers : ∀ entry rows depth free, ∀ edge ∈ edgesOf (.node entry rows depth free), edge ∈ rows)
    (selectionLength : ∀ entry rows depth free, (edgesOf (.node entry rows depth free)).length ≤ rows.length)
    (capturedMass inherited : Nat) (initialMass : suspendedBound before.core ≤ capturedMass)
    (inheritedLength : scs.length ≤ inherited)
    (reserved : ScanReserved bits recursiveFuel
      (seed.1, SourcePruningEnumerationSelectedValueCaller.normalizationProfile seed.2)
      capturedMass inherited (scalar (SourcePruningEnumerationSelectedValueCaller.normalizationProfile seed.2) + 1)) :
    ∃ (preparationBound : Nat) (decoded result : Node)
      (heap : InternedConstructorTemplates.State Symbol Constraint) (entered : Cached),
      ((((∀ extra, SourcePruningEnumerationSelectedPreparation.run (preparationBound + extra) (preparationBound + extra) uv caller before =
        ([.ok ((uv, handle, scs, decoded), entered.core)], some (.done result heap))) ∧
      lookupNode caller.checked.native.machine.heap handle = some decoded ∧
      Post formulas solver inventory caller
        (SourcePruningEnumerationSelectedValueCaller.advance caller heap) memos ∧
      Packet formulas solver inventory
        (SourcePruningEnumerationSelectedValueCaller.advance caller heap) memos metadata entered ∧
      EnumerationDriver.RenderStable before.core entered.core ∧
      EnumerationDriver.Ready uv entered.core ∧
      entered.core.values[uv]? = some (.unenumerated (some handle) scs) ∧
      entered.core.counter = before.core.counter ∧ entered.core.values = before.core.values ∧
      entered.expandable = before.expandable ∧ entered.waiting = before.waiting ∧
      Available heap result ∧ result.free = [] ∧
      (∀ holds ambient term,
        InternedGuardedLanguage.meaning holds ambient result term ↔
          InternedGuardedLanguage.meaning holds ambient decoded term) ∧
      ∀ holds ambient residualMeaning assignment,
        (Satisfies (SourcePruningEnumerationNativeLanguage.handles holds ambient heap)
          residualMeaning assignment entered.core ↔
        Satisfies (SourcePruningEnumerationNativeLanguage.handles holds ambient
          caller.checked.native.machine.heap) residualMeaning assignment before.core) ∧
        (Satisfies (SourcePruningEnumerationNativeLanguage.handles holds ambient
          caller.checked.native.machine.heap) residualMeaning assignment before.core →
          InternedGuardedLanguage.meaning holds ambient result (assignment uv))) ∧
      SourceCurrentConstrainedCapGeneratedQueryResources.Fits
        (SourcePruningEnumerationSelectedValueCaller.normalizationProfile seed.2)
        (SourcePruningEnumerationSelectedValueCaller.advance caller heap).checked ∧
      InternedValueMass.value result ≤
        (SourcePruningEnumerationSelectedValueCaller.normalizationProfile seed.2).mass) ∧
      SourceEqualityAnnotationHeap.Heap (fun guard => guard ∈ seed.1) heap) ∧
      (∀ (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
        (storedEdges : List (EdgeValue Symbol Constraint))
        (depth : Nat) (free : List InternedBinderProtocol.Reference),
        result = .node parentEntry storedEdges depth free →
        scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = false →
        ∃ (scanBound : Nat) (processed : List (Receipt (bits + 2)))
          (outputs : List (Output (bits + 2) Typing)) (afterCaller : Caller (bits + 2))
          (next : Inventory) (final : Memos)
          (folded : Result (Output (bits + 2) Typing) (Failure (bits + 2) Typing) (bits + 2)),
        ((∀ extra, SourcePruningEnumerationNativeContinuations.run
        (continueWith (resume holeKey fits admits graph templates checkEmpty edgesOf stop order (scanBound + extra) recursiveFuel)
          graph templates stop order (scanBound + extra) metadata uv)
        checkEmpty (scanBound + extra) (scanBound + extra) (scanBound + extra) (scanBound + extra) (scanBound + extra)
        uv scs entered (edgesOf (.node parentEntry storedEdges depth free)) (SourcePruningEnumerationSelectedValueCaller.advance caller heap) memos.query = folded) ∧
      Post formulas solver next (SourcePruningEnumerationSelectedValueCaller.advance caller heap) afterCaller final ∧
      Packet formulas solver next afterCaller final metadata entered ∧
