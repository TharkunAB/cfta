import MicroCFTA.SourcePruningEnumerationEdgeInputs
import MicroCFTA.SourcePruningEnumerationTraversalCompletion

namespace MicroCFTA.SourcePruningEnumerationSelectedEdge
open EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationDependencies
open InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes SourcePruningEnumerationObservation
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Context Post)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => InternedConstructorTemplates.Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Fragment" => Fragments.Fragment Symbol
variable {width : Nat}

/-- Retain prefix rejection, unsupported preparation, stopped children and a completed edge. -/
inductive Result (width : Nat) where
  /-- The prefix does not supply the supported singleton packet. -/
  | unhandled
  /-- The arity check rejects before any child runs. -/
  | rejected (caller : Caller width) (queries : Queries) (after : Cached)
  /-- Retain the exact first stopping child observation and optional cache. -/
  | stopped (completedPrefix : List Fragment)
      (observation : SourcePruningEnumerationChildDispatch.Observation width) (candidate : Option Cached)
  /-- Every child succeeds and the edge residual is recorded. -/
  | complete (fragment : Fragment) (caller : Caller width) (queries : Queries) (after : Cached)

/-- Record the residual in the actual completed cache. -/
def finish (residual : Option Constraint) (fragment : Fragment) (before : Cached) : Cached :=
  EnumerationExpandableIndex.frame {before.core with obligations :=
    match residual with
    | none => before.core.obligations
    | some guard => (guard, fragment) :: before.core.obligations} before

