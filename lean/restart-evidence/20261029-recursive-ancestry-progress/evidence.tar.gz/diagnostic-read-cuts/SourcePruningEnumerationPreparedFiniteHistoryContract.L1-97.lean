import MicroCFTA.SourcePruningEnumerationPreparedFiniteContract
import MicroCFTA.SourcePruningEnumerationPreparedOutputHistory
import MicroCFTA.SourcePruningEnumerationPreparedHeadAdmission
import MicroCFTA.SourcePruningEnumerationPreparedZeroOutcomeResources

/-!
# Original resource admission along actual finite output histories

Each recursive input retains its full memo state and original resource plan.
Each selected transition retains actual prefix validity and execution.
A selected transition retains its actual preparation and full callback input.
The contract chooses its common work bound before all emitted histories.
-/
namespace MicroCFTA.SourcePruningEnumerationPreparedRecursive
open EnumerationState InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationRecursive (Packet Output)
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Post)
open SourceCurrentConstrainedCapGeneratedQueryResources (Fits)
open SourcePruningEnumerationIncomingReservation (Seed)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Fragment" => Fragments.Fragment Symbol
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Metadata" => SourcePruningRecordTypes.Metadata
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
local notation "suspendedBound" => SourcePruningEnumerationPrefixAdmission.suspendedBound
variable {Typing Key : Type} {bits : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- The original finite input data at one actual recursive cache and native caller. -/
def HistoryAdmission
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos) (metadata : Metadata Typing) (before : Cached)
    (recursiveFuel : Nat) (seed : Seed) (ceiling : Nat) : Prop :=
  Packet formulas solver inventory caller memos metadata before ∧
  Fits seed.2 caller.checked ∧
  Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap ∧
  suspendedBound before.core ≤ ceiling ∧
  SourcePruningEnumerationPreparedReservation.Reserved bits recursiveFuel seed ceiling

/-- The exact callback input retains its original finite resource plan. -/
def RecursiveCallbackAdmission
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos) (metadata : Metadata Typing) (before : Cached)
    (_uv : Nat) (fragment : Fragment) (recursiveFuel : Nat) (seed : Seed) (ceiling : Nat) : Prop :=
  Packet formulas solver inventory caller memos metadata before ∧
  EnumerationCorrectness.FragmentBound before.core.counter fragment ∧
  Fits seed.2 caller.checked ∧
  Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap ∧
  suspendedBound before.core ≤ ceiling ∧
  SourcePruningEnumerationPreparedReservation.Reserved bits recursiveFuel seed ceiling

/-- A selected invocation retains one actual preparation and its ordinary or opaque completed receipt. -/
def SelectedHistoryReceipt
    (formulas : SourceGuards.Formulas FullSyntax.Formula) (solver : SourceGuards.Entailment FullSyntax.Formula)
    (metadata : Metadata Typing) (checkEmpty : Bool) (workFuel uv : Nat)
    (inventory : Inventory) (caller : Caller (bits + 2)) (memos : Memos) (before : Cached)
    (fragment : Fragment) (reached : Caller (bits + 2)) (after : Cached)
    (returnedInventory : Inventory) (returnedMemos : Memos) : Prop :=
  ∃ (entered : Cached) (handle : Nat) (scs : List Suspended) (decoded prepared : Node)
    (heap : InternedConstructorTemplates.State Symbol Constraint) (preparationBound : Nat),
    Packet formulas solver inventory caller memos metadata before ∧
    EnumerationDriver.Ready uv before.core ∧
    before.core.values[uv]? = some (.unenumerated (some handle) scs) ∧
    (∀ extra, SourcePruningEnumerationSelectedPreparation.run (preparationBound + extra)
      (preparationBound + extra) uv caller before =
        ([.ok ((uv, handle, scs, decoded), entered.core)], some (.done prepared heap))) ∧
    SourcePruningEnumerationSelectedPreparation.run workFuel workFuel uv caller before =
      ([.ok ((uv, handle, scs, decoded), entered.core)], some (.done prepared heap)) ∧
    SourcePruningEnumerationNodes.lookupNode caller.checked.native.machine.heap handle = some decoded ∧
    Post formulas solver inventory caller
      (SourcePruningEnumerationSelectedValueCaller.advance caller heap) memos ∧
    Packet formulas solver inventory
      (SourcePruningEnumerationSelectedValueCaller.advance caller heap) memos metadata entered ∧
    EnumerationDriver.RenderStable before.core entered.core ∧
    EnumerationDriver.Ready uv entered.core ∧
    entered.core.values[uv]? = some (.unenumerated (some handle) scs) ∧
    entered.core.counter = before.core.counter ∧ entered.core.values = before.core.values ∧
    entered.expandable = before.expandable ∧ entered.waiting = before.waiting ∧
    Available heap prepared ∧ prepared.free = [] ∧
    (∀ holds ambient term,
      InternedGuardedLanguage.meaning holds ambient prepared term ↔
        InternedGuardedLanguage.meaning holds ambient decoded term) ∧
    ((∃ (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
        (edges : List (EdgeValue Symbol Constraint)) (depth : Nat)
        (free : List InternedBinderProtocol.Reference) (edge : EdgeValue Symbol Constraint)
        (headSeed : Seed) (inherited : Nat) (headInventory : Inventory)
        (headCaller : Caller (bits + 2)) (headMemos : Memos) (headBound : Nat),
        prepared = .node parentEntry edges depth free ∧
        scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = false ∧
        Post formulas solver headInventory
