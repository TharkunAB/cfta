        stop order metadata formulas solver inventory (prefixFuel + 0) uv caller memos before packet _ valid prefixAt)
        initialMass
    have inheritedBound : scs.length ≤ inherited := Nat.le_trans lengths initialMass
    obtain ⟨preparationFuel, preparedDecoded, preparedValue, preparedHeap, entered, retained, ordinary⟩ :=
      SourcePruningEnumerationPreparedNativeOrdinaryResources.complete_resources_with_history
        holeKey fits admits graph templates checkEmpty edgesOf stop order metadata recursiveFuel
        (SourcePruningEnumerationExpansionAdmission.narrowSeed seed) formulas solver recursive inventory
        reached middleMemos after uv handle scs middlePacket ready stored middleFits middleKnown incoming
        selectionMembers selectionLength inherited inherited currentMass inheritedBound reserved.scan
    obtain ⟨preparation, preparedKnown⟩ := retained
    obtain ⟨preparedPacket, preparedFits, _preparedMass⟩ := preparation
    obtain ⟨preparationRun, preparedLookup, preparationPost, enteredPacket, stable,
      enteredReady, enteredStored, _enteredCounter, enteredValues, enteredFlags, enteredWaiting,
      preparedAvailable, preparedClosed, preparedLanguage, _preparedModels⟩ := preparedPacket
    by_cases ordinaryShape : ∃ entry rows depth free,
        preparedValue = .node entry rows depth free ∧
          scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = false
    · obtain ⟨entry, rows, depth, free, same, nonterminal⟩ := ordinaryShape
      obtain ⟨scanFuel, _processed, _outputs, _afterCaller, _next, _final, folded,
        _scanPacket, dispatchRun, _fullPost, resources, histories⟩ := ordinary entry rows depth free same nonterminal
      have preparedHeapEq :
          (SourcePruningEnumerationSelectedValueCaller.advance reached preparedHeap).checked.native.machine.heap =
            preparedHeap := rfl
      have countBound := SourcePruningEnumerationPreparedReservation.selected_length_le seed
        (SourcePruningEnumerationSelectedValueCaller.advance reached preparedHeap) preparedFits
        entry rows (edgesOf (.node entry rows depth free)) depth free
        (by simpa only [preparedHeapEq, same] using preparedAvailable) (selectionLength entry rows depth free)
      have growth := SourcePruningEnumerationPreparedReservation.count_mono recursiveFuel start inherited inherited countBound
      refine ⟨prefixFuel + (preparationFuel + scanFuel), finish uv folded, ?_,
        (resources.mono growth.1 growth.2).post middlePost, ?_⟩
      · apply resume_depth_stable holeKey fits admits graph templates checkEmpty edgesOf stop order
