    have fields := SourcePruningEnumerationSelectedOpaqueDispatch.observed_cache_ancestry_extension running
    exact enteredExtends.trans fields.1

/-- The actual recording callback retains every original per-slot recursion key. -/
theorem SelectedHistoryReceipt.ancestry_extension_after_callback
    (receipt : SelectedHistoryReceipt formulas solver metadata checkEmpty workFuel uv
      inventory caller memos before fragment reached after returnedInventory returnedMemos)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (callbackFuel : Nat) (result : Bool × Metadata Typing) (callbackCore : Core)
    (recorded : Success (SourcePruningRecordTypes.recordTypes graph templates callbackFuel metadata uv
      (.inl fragment)) after.core result callbackCore) : Extends before.core callbackCore := by
  have completed := receipt.ancestry_extension
  have packet := receipt.completed_packet
  have frame := SourcePruningRecordTypes.recordTypes_frame graph templates callbackFuel metadata uv (.inl fragment)
    after.core callbackCore result packet.safe.1.total recorded
  exact completed.trans (Extends.frame frame)

end MicroCFTA.SourcePruningEnumerationPreparedRecursive
