            cases terminal : scs.any (fun sc => EqualityTrie.isTerminal sc.trie) with
            | false => exact False.elim (ordinaryShape ⟨entry, rows, depth, free, rfl, terminal⟩)
            | true => rfl
        | empty | reference _ | union _ _ _ _ | mu _ _ _ _ => rfl
      have enteredMass : mass entered.core ≤ inherited := by
        rw [SourcePruningEnumerationPrefixAdmission.suspendedBound_values after.core entered.core enteredValues]
        exact currentMass
      obtain ⟨opaqueFuel, _receipt, _middleCaller, _saved, _middleMemos, _middleInventory, _outcome, folded,
        _headRun, _headPost, _headQuery, _advanced, _admitted, _pending, _history, _headFits, _headKnown,
        _shape, _paddedFits, _paddedKnown, _callbackRun, _receiptRun, resources, opaqueFoldRun, opaqueHistories⟩ :=
        SourcePruningEnumerationPreparedNativeHookResources.opaque_finite_complete_resources_with_history
          holeKey fits admits graph templates checkEmpty edgesOf stop order metadata recursiveFuel
          start formulas solver recursive inventory
          (SourcePruningEnumerationSelectedValueCaller.advance reached preparedHeap) middleMemos entered
          uv handle scs preparedValue enteredPacket enteredReady enteredStored
          (EnumerationReferences.incoming_read uv after.core entered.core stable incoming)
          preparedAvailable preparedClosed dispatchGate preparedFits preparedKnown selectionMembers selectionLength
          inherited inherited enteredMass inheritedBound reserved.first
      have growth := SourcePruningEnumerationPreparedReservation.first_le_final recursiveFuel seed ceiling
      have padded : OutcomeResources formulas solver
          (SourcePruningEnumerationSelectedValueCaller.advance reached preparedHeap)
          (Forecast (recursiveFuel + 1) seed ceiling) (finish uv folded) :=
        resources.mono growth.1 growth.2
      have original := (padded.post preparationPost).post middlePost
      refine ⟨prefixFuel + (preparationFuel + opaqueFuel), finish uv folded, ?_, by
        simpa only [SourcePruningEnumerationPreparedReservation.final_succ] using original, ?_⟩
      · apply resume_depth_stable holeKey fits admits graph templates checkEmpty edgesOf stop order
          prefixFuel (preparationFuel + opaqueFuel) recursiveFuel uv metadata metadata caller reached
          memos.query memos.query before after
          ([.ok ((uv, handle, scs, preparedDecoded), entered.core)], some (.done preparedValue preparedHeap)) folded
        · intro extra
          obtain ⟨currentAction, currentPrefix, _valid⟩ := phase extra
          exact ⟨checked, .done (phaseValue, some currentAction) heap, currentPrefix⟩
        · intro extra
          have preparationAt : SourcePruningEnumerationSelectedPreparation.run
              (preparationFuel + opaqueFuel + extra) (preparationFuel + opaqueFuel + extra) uv reached after =
