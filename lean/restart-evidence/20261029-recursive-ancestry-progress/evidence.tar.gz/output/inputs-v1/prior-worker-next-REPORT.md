# Source-only next-worker gap map

Date: 2026-10-29 Europe/Stockholm. Owner: history_canonical. Status: PLANNING ONLY.

The eleven local modules already prove actual storage, adapter, terminal, child, traversal and prepared-head retention. The missing closure is the actual prepared recursive worker, including diagnostic caches at a stop. No new proof is supplied here. No compiler, evaluator, Git, network, board or repository write was used.

## First useful proofs

1. Prove all-tag valid-prefix retention of `recursionAncestry` at a retained cache. A full compression `Frame` is too strong: the true repeated check clears a bucket, and changed-handle narrowing writes a value. Both preserve the ancestry field. Use original `Total` from the input Packet, actual getValue/check observations, the actual prepared action, NarrowAdapter.adapt_core, and pure Right recording. `PrefixCanonicalHistory.prefix_canonical` provides the valid-prefix inversion template. Its private `retained_action_success` supplies the actual action observation; do not assume a prepared action preserves arbitrary states. The runtime action is only reject, pure, or representative followed by setValue.
2. Prove the actual SelectedOpaqueDispatch all-cache observer, parallel to CapturedEdge.observed_cache_ancestry_extension. ChildDispatch.observed_cache_ancestry_extension and Finalize.run_ancestry_extension supply it. Include complete, rejection and a stopped candidate Some cache. A missing candidate contributes no cache. This covers the actual terminal bucket/opaque path, including the ordinary-node-with-terminal-bucket route. No model or native projection admission is needed for this structural property.
3. Reuse Entry.enter_history, rather than invent a new carrier proof. An actual successful Entry under original Total gives exact recursionAncestry equality. It sets expansionAncestry, so it is not a full Frame. SelectedPreparation.run changes only the native preparation after the same Entry. Preserve decoded source and prepared value separately.

Proposed local APIs, with the existing parameter types and order from the cited sources:

```lean
-- Same inputs through before/memos as prefix_canonical, replacing its
-- canonical input by original Total; retain literal actual PrefixValid.
SelectedStep.prefix_recursion_ancestry
  ... (total : UnionFind.Total before.core.representatives)
  (valid : PrefixValid ... (runPrefix ...)) :
  match runPrefix ... with
  | .parked _ (some after) _
  | .narrowed _ _ _ _ _ (some after) _ _ =>
      after.core.recursionAncestry = before.core.recursionAncestry
  | _ => True

SelectedOpaqueDispatch.observed_cache_ancestry_extension
  {checkEmpty r n p h k target scs value caller before queries result}
  (observed : run checkEmpty r n p h k target scs value caller before queries = some result) :
  match result with
  | .complete _ _ _ after | .rejected _ _ after
  | .stopped _ _ (some after) => Extends before.core after.core
  | _ => True

-- From the actual preparation retained in receipt, existing enter_history
-- plus the checked CapturedEdge or proposed opaque observer.
SelectedHistoryReceipt.ancestry_extension
  (receipt : SelectedHistoryReceipt formulas solver metadata checkEmpty
    workFuel uv inventory caller memos before fragment reached after
    returnedInventory returnedMemos) : Extends before.core after.core
```

These are proposed interfaces, not checked declarations. A stronger arbitrary-success prefix observer may be possible with Total and independent fuels alone. The valid-prefix interface is sufficient for the existing original-resource producer and avoids proving more than that producer needs.

## Actual cache attachments at a stop

HookResult.stopped contains outputs, a prepared Failure and an optional NATIVE Caller/Queries endpoint. It has no aggregate cached enumeration endpoint. Native endpoint None must remain None.

A precise attachment relation needs only the actual Cached-typed fields:

- A receipt attaches its cache in complete, rejected, or stopped Some candidate. Unhandled and stopped None attach none.
- Failure.exhausted attaches its literal before cache.
- Failure.selected attaches the actual prefix candidate, and any receipt cache contained in its optional ordinary observation if present. Actual runPrefix leaves that ordinary field None; PrefixValid also retains this fact. A generic diagnostic attachment relation must not silently ignore a present ordinary field.
- Failure.alternatives attaches each processed receipt cache, the current edge receipt cache when present, and the current continuation receipt cache. For a continuation stop it also includes attachments in the nested Failure. The recursion is on the actual Failure value.
- Failure.callback and Failure.preparation contain raw Core rows and native heaps, but no Cached value. They attach no Cached by this definition. If raw successful Core rows are also desired, state that stronger scope separately. It is not proved by an observer of Some Cached candidates.

No runtime cache collector is required. A Prop relation with those constructors suffices. Before defining a selected diagnostic attachment, inspect NativeBranches.Result to cover its exact cached fields. The actual worker only stores runPrefix results with ordinary=None, so no new native ordinary traversal is needed on its reachable path.

A small outcome predicate can then state:

```lean
OutcomeAncestry (before : Core) (outcome : PreparedHookResult) : Prop :=
  (forall output in hookOutputs outcome, Extends before output.cache.core) and
  match outcome with
  | .complete .. => True
  | .stopped _ reason _ =>
      forall after, FailureCache reason after -> Extends before after.core
```

`FailureCache` and `OutcomeAncestry` above are specification sketches. Neither is installed or assumed as a future-state oracle. Add a transitivity lemma that changes the ORIGINAL enumeration core using Extends. Native OutcomeResources.post cannot provide that relation.

## Dependency order for the closed original-input theorem

Use the actual prepared Failure, not the nominal old Failure. Mirror the original Complete gates. Append OutcomeAncestry of the SAME produced outcome. A local stronger Complete contract is the induction target, not a public assumption. Its forget theorem recovers the existing Complete.

1. Establish the three local bridges above. Storage through traversal is already supplied by the eleven new modules. CapturedEdge's all-cache observer already includes stopped/rejected heads; CompletedHeadReceipt.ancestry_extension alone would miss these cases.
2. Strengthen the actual finite callback producer at depth d. Its existing producer derives the singleton callback, original Packet at frame(callbackCore,before), exact Frame and original reservation at that input. For false, apply the depth-d induction hypothesis to THAT own input core, metadata, Caller, full Memos and Restart.decision. Transpose the resulting extension through Extends.frame. For true, the actual result is complete [] and the property is vacuous. The stable producer rules out malformed callback raw at its chosen bound; it must retain the actual singleton equation that proves this. No future callback Frame or outcome retention is a premise.
3. Strengthen the finite receipt producer. Only complete invokes continueWith. Its existing admitted/pending/history facts derive the callback Packet and fragment bound from that exact receipt. Other handled receipts produce complete [], with no invented cache endpoint. Keep the original receipt's own cache retention separately for scan diagnostics.
4. Strengthen finite prepared heads. Use the actual CapturedEdge observer at the old stable receipt and the strengthened receipt/callback producer. Preserve all original Ready/stored source/separate prepared Available and closed fields. If two stable witnesses are produced, compare their actual runs at the sum of their work bounds; transport by literal outcome equality. Do not cast prepared parent to the stored decoded value.
5. Strengthen actual finite sibling scans by induction on the selected edge list. Each head and its callback extends that HEAD'S actual cache input. Its outputs and nested failure attachments therefore extend the fixed captured scan input by transitivity. Append earlier outputs at a later stop, and retain earlier processed receipt caches. The suffix starts with the SAME captured enumeration cache and sibling metadata, but the actual native Caller/Queries returned by the previous complete callback. Reconstruct the captured Packet at that returned Caller with completed_captured_packet and the existing Posts/full Memos. Do not use any earlier emitted output.cache as the next sibling's input.
6. Strengthen ReceiptContinuation/finish and selected preparation. A stopped hook retains its actual completed head receipt plus nested reason; a complete hook retains its outputs. None/unhandled edge stops have no candidate cache. Entry's per-slot equality moves the local scan result back to selected-preparation input. The terminal bucket and non-node routes use the opaque observer plus ReceiptContinuation; the node/nonterminal route uses NativeContinuations.
7. Strengthen parked, ordinary and opaque selected finite producers, then selected expansion and run-step. The parked Restart singleton has core=parked.core and updated metadata equal original metadata; use the exact Restart.run equation before the smaller-depth call. A blocked parked restart emits []. A selected narrowed prefix first uses the all-tag prefix lemma, then actual preparation/scan and the transitive outcome predicate. Prefix Right recording is pure, not another recursive hook.
8. Discharge CompleteWithAncestry by Nat induction on recursiveFuel. Zero emits the original cache, emits [], or stops with exhausted carrying the original cache. Every case is reflexive or vacuous. At a successor, the only recursive hypothesis is the smaller-depth contract already quantified over ALL original admitted inputs. The final theorem has no hook-preservation or smaller-depth supplier premise.

The existing finite callback/history and projection families provide the source templates. Preserve old outcome/resource witnesses with forget; resource padding changes only the original resource bounds. It does not supply an enumeration extension.

## Exact public contract to target

Use the exact arguments and gates of PreparedRecursive.run_finite_complete_resources_with_history, or the original Complete contract. Do not add initial model/Origins/Canonical/Proper/Arity/Projection or finite native-handle admissions for this structural result. The original Packet supplies Total. This is a route assessment, not a compiled proof that no other premise is needed.

```lean
theorem run_finite_complete_resources_with_ancestry
  (holeKey : Typing -> Nat -> Key)
  (fits : Key -> Symbol -> Bool) (admits : Key -> Node -> Bool)
  (graph : Graph Symbol Constraint)
  (templates : List (Template.Pattern Symbol))
  (checkEmpty : Bool) (edgesOf : Node -> List (EdgeValue Symbol Constraint))
  (stop : Option (Metadata Typing -> Nat -> Bool))
  (order : Metadata Typing -> List Nat -> Option Nat)
  (formulas : SourceGuards.Formulas FullSyntax.Formula)
  (solver : SourceGuards.Entailment FullSyntax.Formula)
  (recursiveFuel : Nat) (inventory : Inventory)
  (caller : Caller (bits + 2)) (memos : Memos)
  (before : Cached) (metadata : Metadata Typing) (seed : Seed) (ceiling : Nat)
  (packet : Packet formulas solver inventory caller memos metadata before)
  (bounded : Fits seed.2 caller.checked)
  (known : Heap (fun guard => guard in seed.1) caller.checked.native.machine.heap)
  (selectionMembers : forall entry rows depth free,
    forall edge in edgesOf (.node entry rows depth free), edge in rows)
  (selectionLength : forall entry rows depth free,
    (edgesOf (.node entry rows depth free)).length <= rows.length)
  (initialMass : suspendedBound before.core <= ceiling)
  (reserved : PreparedReservation.Reserved bits recursiveFuel seed ceiling) :
  exists bound outcome,
    (forall extra, run holeKey fits admits graph templates checkEmpty edgesOf
      stop order (bound + extra) recursiveFuel metadata caller memos.query before = outcome) and
    OutcomeResources formulas solver caller
      (PreparedReservation.final recursiveFuel seed ceiling) outcome and
    OutcomeAncestry before.core outcome
```

This is exact at the level of types, parameters, gates and conclusion; the displayed ASCII forall/in/and/exists notation is specification prose, not an elaborated Lean source candidate. All caches and output objects are the literal ones in the actual outcome. The native endpoint, queries, full old resource witnesses and bound remain unchanged.

This producer covers every sufficiently large work fuel at each supplied finite recursive depth, including stopped outcomes and outputs emitted before a stop. It does not by itself prove the property at arbitrary smaller workFuel. Such an all-work observer would need successful callback-entry Total/Safe derived at every actual reachable input, or a new structural callback ancestry observer which avoids that Frame admission. Do not infer the broader scope from this producer.

## Cheaper output-only consequence and its limit

After the local prefix/Entry/opaque bridges, ResourceHistory.ancestry_extension can be proved directly by induction on its four constructors. stopped/done are reflexive; parked uses prefix equality and Restart core identity; selected uses prefix, actual selected receipt, callback Frame from callbackAdmission's Packet, then tail IH. It needs no final model/arity/discharge premise and no original KeyAncestry carrier.

The existing run_finite_complete_resources_with_history has already discharged its depth contract. Composing this small history lemma with that producer yields output retention without another copy of the finite-depth proof family. This is the smallest output-only theorem. It does not establish the diagnostic-cache part: ResourceHistory is indexed by an emitted Output and contains no path for the final Failure's attached caches. That is why the stopped outcome observer and its closed induction remain a genuine additional task.

## Representative scope and limits

Extends compares the SAME RAW slot before and after, for every Nat slot, including stale history at the fresh counter. The new allocated proof unions the fresh slot's old history instead of overwriting it; assimilation retains target old keys and does not erase source history. Compression leaves every history field unchanged. Therefore representative movement is not an obstruction to this requested same-slot statement.

Extends.unused_le also fixes BOTH slot and native handle. It does not compare an old slot's budget with a different new representative's budget, or an old handle with a narrowed handle. A later termination proof that follows representatives must use actual source-to-target transfer and representative/handle identity facts separately. Global expansionAncestry equality is also false as an invariant: Entry sets it and captured finalization clears it.

No theorem here gives a sufficient recursive depth, global completion, a finite universe of native key.node handles, or accepted-model/output coverage. No Haskell file or FINDINGS was changed; there was no Haskell fix in this source-only audit.

## Evidence

manifest.json records whole source snapshot identities and separate exact source-read cuts. A whole source copy does not mean its whole proof was reviewed. The seven lower modules used through the prepared-head observer were retained as dependency identities; their declaration-name search is labelled as such. Root owns build evidence. This task ran no verification tools.
