  ⟨EnumerationState.initial root,
    fun uv => if uv = 0 then candidate graph (.unenumerated (some root) []) else false,
    fun _ => none⟩

/-- Allocation adds the fresh slot only when the source predicate accepts it. -/
def allocate (graph : Graph Symbol Guard) (node : Option Nat) (state : Cached Symbol Guard) : Cached Symbol Guard :=
  ⟨allocated node state.core,
    fun uv => if candidate graph (.unenumerated node []) && uv == state.core.counter then true else state.expandable uv,
    state.waiting⟩

/-- One raw-slot write removes old suspended counts before adding the new counts. -/
def write (graph : Graph Symbol Guard) (uv : Nat) (value : UVarValue Symbol) (state : Cached Symbol Guard) :
    Option (Cached Symbol Guard) := do
  let old ← state.core.values[uv]?
  pure ⟨{state.core with values := state.core.values.set uv value},
    fun other => if other = uv then candidate graph value else state.expandable other,
    EnumerationWaitingIndex.replace old value state.waiting⟩

/-- Other source effects update the original state without changing either index. -/
def frame (core : State Symbol Guard) (state : Cached Symbol Guard) : Cached Symbol Guard :=
  {state with core := core}

/-- Initialization derives both indexes and their slot-domain bound. -/
theorem initial_correct (graph : Graph Symbol Guard) (root : Nat) : Correct graph (initial graph root) := by
  refine ⟨rfl, ?_, EnumerationWaitingIndex.initial_correct root⟩
  intro uv
  cases uv <;> simp [initial, EnumerationState.initial]

/-- Fresh allocation preserves the exact expandable slots and waiting multiplicities. -/
theorem allocate_correct (graph : Graph Symbol Guard) (node : Option Nat) (state : Cached Symbol Guard)
    (correct : Correct graph state) : Correct graph (allocate graph node state) := by
  refine ⟨allocated_supply node state.core correct.aligned, ?_, EnumerationWaitingIndex.allocate_correct _ node _ correct.waiting⟩
  intro uv
  by_cases before : uv < state.core.values.length
  · have different : uv ≠ state.core.counter := by rw [correct.aligned]; omega
    simp only [allocate, allocated, List.getElem?_append_left before]
