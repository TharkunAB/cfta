# Recursive output ancestry retention

Checked at 2026-10-29 01:42 CET. Source `bd75ee348c17f4946fadb5c5a676bf7252180725` is pushed on formalize.
The complete formalization objective remains ACTIVE and incomplete.

## Top-level objective

Show that the optimized implementation enumerates exactly the intended
constrained and refined tree language. Every emitted complete term must belong
to that language. For each intended finite term, derive sufficient bounds that
make the actual search emit it. Preserve the specified order, resources and
stop behavior. Connect the public API and concrete Haskell representation to
the model. An infinite language does not require one finite exhaustive run.

Keep the optimized interned core primary. Preserve the older constructor and
equality proofs as secondary targets. Derive admission and sufficient bounds
from the original input and its branch model.

## Strongest current statement

The optimized interned Lean model has conditional checked rendered soundness
under its semantic and resource contracts, fixed-PCS and whole-Discharged.
Greater recursive depth retains the ordered output prefix. Earlier work
constructs the actual terminal callback emission with the same original
assignment. DONE does not imply Discharged. A configured stop can emit a
partial result. These semantic limits remain unchanged.

This checkpoint proves a stronger structural result for the actual prepared
recursive worker. For ANY fixed finite recursive capacity, the existing
original-input resource contracts derive a common work bound and an exact
stable outcome at every extra work budget. The outcome retains all earlier
resources and all actual admitted output histories. Every emitted output also
retains every original recursion key at its SAME RAW SLOT. This includes
outputs produced before a stopped outcome. No new input gate is added.

The result is a property of emitted outputs. It does not assert that an output
exists, that a chosen model is emitted, or that the recursive capacity is
sufficient. It does not assert retention at arbitrary smaller work fuel or at
caches attached only to a stopped diagnostic. It states no global equality of
expansion ancestry. Entry can change that field.

## Exact relation and input gates

The existing relation `SourcePruningEnumerationAncestryExtension.Extends`
compares key membership at each Nat slot. It includes slots at and beyond the
fresh counter. It preserves neither list order nor multiplicity. The existing
`Extends.unused_le` gives budget nonincrease at one FIXED native handle and one
SAME RAW SLOT. It supplies no strict global decrease or native-handle bound.

The finite producer keeps the old gates in their old order: the original
Packet; Fits for the seed bounds; the original annotation Heap; selection
membership and length laws; the original suspended-mass ceiling; and the
finite-depth PreparedReservation. It adds no model, carrier, Canonical,
Origins, future hook-output retention or new finite-depth completion premise.
The same chosen original bound and exact outcome remain in its conclusion.

Per-slot extension alone gives no transfer to a different representative.
Use the actual source-to-target assimilation facts when the live root changes.
Each sibling resets its enumeration input to the captured cache. Native callers
and full Memos advance. Do not compare a previous sibling's output cache with
the next sibling's reset input as one monotone enumeration branch.

## Four checked additive modules

The modules contain six public theorems and four private helpers. They total
587 lines and 35,942 bytes. They add no runtime function or certificate type.
Enumerator, native and existing proof definitions are unchanged.

1. `SourcePruningEnumerationPrefixAncestryExtension` exports
   `SelectedStep.prefix_recursion_ancestry`. Original Total and literal
   PrefixValid derive exact recursionAncestry equality at each actual parked
   or narrowed Some cache. It follows the actual read, recursion check,
   prepared action, adapter and pure Right recording. The repeated check can
   clear a value bucket. The narrowing action can write a value. The whole
   prefix therefore does not claim a full Frame. Four private helpers invert
   the actual operations. Two are exact copies of inaccessible old helpers.
2. `SourcePruningEnumerationOpaqueAncestryExtension` exports
   `SelectedOpaqueDispatch.observed_cache_ancestry_extension`. Its only
   explicit premise is the actual run equation. It covers complete, rejected
   and stopped Some caches. Actual child dispatch retains ancestry. Actual
   finalization clears expansion for complete results. Rejected/stopped Some
   caches retain exact input expansion history. Every stopped candidate
   Option is split explicitly. No cache is invented for None.
3. `SourcePruningEnumerationPreparedReceiptAncestryExtension` exports
   `SelectedHistoryReceipt.ancestry_extension` and
   `SelectedHistoryReceipt.ancestry_extension_after_callback`. The receipt's
   actual preparation equation exposes actual Entry. Its own original Packet
   supplies Total. Entry gives exact per-slot history equality. The proof
   composes actual ordinary captured or opaque completion. The actual
   recordTypes callback derives its Frame from the completed receipt's own
   Packet. No future callback-retention supplier is used.
4. `SourcePruningEnumerationPreparedOutputAncestryExtension` exports
   `ResourceHistory.ancestry_extension` and
   `run_finite_complete_resources_with_ancestry`. The first theorem takes only
   the actual admitted history. Each constructor carries its own original
   admission. Parked Restart identifies its literal returned core. Selected
   history composes prefix, receipt, actual callback and its own tail IH.
   The second theorem keeps the old finite producer's exact bound/outcome,
   stability, resources and all-extra histories. It applies the first theorem
   to every actual hook output. No duplicate finite-depth proof family is added.

The new source commits are `676d6181e` and `bd75ee348c17f4946fadb5c5a676bf7252180725`. Audit adds four imports.
Its complete prior body remains an exact suffix.

## Verification and retained evidence

All four new modules and Audit pass strict Lean checks with warningAsError and
all linters enabled. All 11 compiler commands pass. There is no failed proof
candidate at this checkpoint. The aggregate Audit builds 4,599 jobs and checks
81,980 MicroCFTA theorem dependencies. The old dependency warning about the
unused `inputs` binder remains visible in Lake replay. No linter is disabled.

Every compiler job runs serially with measured memory.max=memory.high=4 GiB and
memory.swap.max=0. No compiler or native job is active at sealing. The exact
command, input copies, raw log, source hash and measured limits are retained.
Only propext, Classical.choice and Quot.sound are allowed. No custom axiom,
native_decide, placeholder or budget increase is introduced.

Public readback retains 833 complete theorem checks and axiom lists, plus 68
complete definition bodies. It has 3,473,780 bytes. SHA256:
`17202f2b56c9064978a289c1e8fb50c995468c2f3f222f815fb96ab75cbdd276`.
The prior 3,454,104 bytes are an exact prefix. All 19,676 appended bytes were
read without truncation. No old public surface is weakened.

All 4,594 prior non-Audit Lean sources and 443 stronger-source identities
retain their hashes. All 821 integrated Haskell/Cabal identities retain theirs.
All 23 earlier document bodies remain exact suffixes. This note is the 24th
current retained document. Every exact final source and document is copied.
Source-scope manifests retain whole identities separately from actual read
cuts. Author UNTESTED labels remain historical labels. Root's final compiler
records bind these exact candidate versions to passing checks.

The scope verifier first assumed the wrong delimiter after a copied private
helper. The current-state verifier first assumed every inherited identity has
a byte count. Both failed helpers and their raw logs are retained. The corrected
checks use exact byte ranges and require SHA256 for every identity. A byte
count is also checked when present. Neither failure was a Lean proof failure.

The immutable evidence area is
`/tmp/mcfta-recursive-ancestry-progress-20261029/`.
The restart archive is
`lean/restart-evidence/20261029-recursive-ancestry-progress/`.
Its manifest and verifier bind every sealed regular file. Reconstruct into a
fresh directory. Keep restored evidence immutable and continue in a new area.
The earlier prepared-ancestry source, packaging, restored areas and archive
remain unchanged. Historical missing native logs remain marked as missing.
They are not presented as recovered files.

## Haskell and upstream state

The initial upstream refresh completed with no new main commit. Main is
`63aae675c5c6b8312bc5872fff065a7de3629aef` and is an ancestor of this source.
No Haskell source changed. No Haskell build, test or format check ran. No new
Haskell defect or repair was established.

The previously verified graph text parser repair is
`c15021ce706ef560b6c0ab335ceed1a4b67ba4aa` on formalize. Main at the recorded head
lacks it. FINDINGS retains the lawful StateCodec id Right reproducer, four
strict-prefix exceptions, four controls, checked parser repair, existing-test
extension and post-repair checks for external pickup. Those successful checks
were not repeated without a source change. The serialization grammar and its
round-trip laws remain outside the Lean proof.

## Biggest gaps

The main global gap is a finite native generated boundary family, or another
well-founded rank derived from the original input. A fixed-handle shape budget
cannot bound the number of native handles. Queries can use generated operands.
The generated callback body's degree bound before optionalBinder is a missing
link. build_new_lower bounds a new Mu body by the generated body; current
Bounded alone does not give that body's strict original ceiling. A degree
ceiling still needs physical probe-key/guard closure or a different rank.

Nonterminal chosen-model recursive emission remains open. The actual terminal
callback emission theorem is retained. Source-derived sufficient recursive
depth must cover earlier allocating callbacks, rejected alternatives and exact
stopped diagnostics. Full solver/policy/origin/public API admission and concrete
optimized Haskell correspondence remain separate work.

Existing counterexamples remain unchanged. SourceColdUnfoldNewMuBoundary
refutes startup-only Mu inventories and decreasing cached depth. The actual
22-step OpenBodyBoundary witness refutes universal PreparedWithoutMu. Its
native_returned theorem observes returned=some(.mu26). It does not prove literal
cache/payload equality, divergence or failure of the needed original ceiling.

## Next bounded proof task

Extend the CLOSED original-input finite-depth producer with ancestry for actual
cached attachments in stopped diagnostics. ResourceHistory alone is not enough:
a zero-depth exhausted result has no output, yet its Failure holds before.

Retain every processed native receipt cache. Retain the actual current edge
receipt. A stopped continuation also retains its head receipt and a nested
Failure. Include rejected and stopped Some receipt caches. Do not restrict the
inventory to complete receipts. Callback/preparation raw Core rows are separate
from Cached attachments. A missing optional cache is not an invented endpoint.

The actual PreparedFiniteSiblingResources.StoppedAt can retain an arbitrary
nested prepared Failure. The older NativeHookResources.PreparedStoppedAt is a
different narrower certificate and cannot replace it. At the stopped head hook,
the finite sibling producer currently keeps OutcomeResources but loses the
nested reason's ancestry. Add the smaller-depth diagnostic IH there. Use the
actual callback Frame and the existing all-cache captured observer. Prepend
processed receipt caches in the stopped suffix case. Compose prefix and Entry
ancestry to compare those actual attachments with the original input.

The bounded diagnostic-next report in this evidence area gives exact source
cuts and proposed producer interfaces. It is planning only. No proposed
diagnostic theorem, predicate or strengthened depth family is installed here.
Do not add a future hook-retention oracle. Preserve the same original gates and
actual cache identities. Do not infer a representative change from Extends.

## Restart and publication

Read NEXT-PROMPT, HANDOFF and root FINDINGS, then this note. Refresh upstream.
Normal pushes to git@github.com:TharkunAB/cfta.git refs/heads/formalize remain
explicitly authorized. Use the established SSH port 443 route. Root remains
the sole compiler, evaluator, Git, board and repository writer. Bounded parallel
source-only work is authorized. Heavy checks remain serial at 4 GiB.

Board 720, post `5d3549a9-0c01-433f-8485-e505cec36ca3`, records the checked source
result. Author, full content and metadata have exact readback. The complete
goal stays ACTIVE. This checkpoint does not pause or complete it.
