"""Bind current sources, strict checks, public surface and restart documents."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/home/tritlo/Code/mcfta');AREA=Path('/tmp/mcfta-recursive-ancestry-progress-20261029')
def sha(data):return hashlib.sha256(data).hexdigest()
counts={}
for name in ['prior-lean-sources.json','prior-strong-sources.json','inherited-prior-haskell-sources.json']:
 records=json.loads((AREA/name).read_text());counts[name]=len(records)
 for record in records:
  data=(ROOT/record['path']).read_bytes();assert sha(data)==record['sha256'];assert len(data)==record['bytes']
modules=json.loads((AREA/'modules.json').read_text());old=(AREA/'prior-Audit.lean').read_bytes();current=(ROOT/'lean/MicroCFTA/Audit.lean').read_bytes();assert current==(''.join('import MicroCFTA.'+m+'\n' for m in modules)+'\n').encode()+old
sources=[];strict=[]
for module in modules+['Audit']:
 name='lean/MicroCFTA/'+module+'.lean';data=(ROOT/name).read_bytes();copy=AREA/'final-proof-sources'/name;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(data);record={'module':module,'path':name,'bytes':len(data),'sha256':sha(data),'snapshot':str(copy.relative_to(AREA))};sources.append(record)
 matches=[]
 for directory in AREA.iterdir():
  report=directory/'report.json';source=directory/'MicroCFTA'/(module+'.lean')
  if report.exists() and source.exists():
   v=json.loads(report.read_text())
   if v.get('exit_code')==0 and source.read_bytes()==data and '-DwarningAsError=true' in v['command'] and '-Dlinter.all=true' in v['command']:matches.append({'report':str(report.relative_to(AREA)),'source':str(source.relative_to(AREA)),'source_sha256':v['source_sha256']})
 assert len(matches)==1,(module,matches);strict.append({'module':module,**matches[0]})
(AREA/'final-proof-sources.json').write_text(json.dumps(sources,indent=2)+'\n');(AREA/'strict-source-mapping.json').write_text(json.dumps(strict,indent=2)+'\n')
for record in json.loads((AREA/'prior-documents.json').read_text()):
 original=(AREA/'prior-document-bodies'/record['path']).read_bytes();assert sha(original)==record['sha256'];assert (ROOT/record['path']).read_bytes().endswith(original)
for record in json.loads((AREA/'final-documents.json').read_text()):
 data=(ROOT/record['path']).read_bytes();assert data==(AREA/record['snapshot']).read_bytes();assert sha(data)==record['sha256']
commands=[];input_count=0
for directory in sorted(AREA.iterdir()):
 if not (directory/'report.json').exists():continue
 report=json.loads((directory/'report.json').read_text());assert report['exit_code']==0;assert report['cgroup_limits']=={'memory.max':'4294967296','memory.high':'4294967296','memory.swap.max':'0'};log=(directory/'raw.log').read_bytes();assert len(log)==report['bytes'] and sha(log)==report['sha256'];commands.append(directory.name)
 for record in json.loads((directory/'inputs.json').read_text()):
  data=(directory/'input-sources'/(record['module']+'.lean')).read_bytes();assert sha(data)==record['sha256'];input_count+=1
for directory in AREA.iterdir():
 if (directory/'report.json').exists() and (directory/'public.lean').exists():assert sha((directory/'public.lean').read_bytes())==json.loads((directory/'report.json').read_text())['source_sha256']
old=(AREA/'prior-public-readback.log').read_bytes();public=(AREA/'public-readback/raw.log').read_bytes();assert public.startswith(old);assert (AREA/'public-added-readback.log').read_bytes()==public[len(old):]
request=json.loads((AREA/'board-progress-request.json').read_text());readback=json.loads((AREA/'board-progress-readback.json').read_text());post_id=json.loads((AREA/'board-progress-reply.json').read_text())['structuredContent']['post_id'];post=next(p for p in readback['structuredContent']['items'] if p['id']==post_id);assert post['author']==request['username'];assert post['content']==request['content'];assert post['metadata']==request['metadata']
assert not subprocess.check_output(['git','diff','--name-only','f7827693fdde9957ece4776451feddc5af620312','--','lean/restart-evidence'],cwd=ROOT)
tracked=subprocess.check_output(['git','ls-files','-z','--','lean/restart-evidence'],cwd=ROOT).decode().split('\0');tracked=[p for p in tracked if p];counts['prior_evidence_files']=len(tracked);counts['prior_evidence_directories']=len({Path(p).parts[2] for p in tracked});(AREA/'prior-evidence-index.json').write_bytes(subprocess.check_output(['git','ls-files','-s','--','lean/restart-evidence'],cwd=ROOT))
summary={'counts':counts,'final_strict_sources':len(strict),'compiler_commands':len(commands),'compiler_failures':0,'input_snapshots':input_count,'documents':len(json.loads((AREA/'final-documents.json').read_text())),'old_document_suffixes':23,'public_theorems':len(json.loads((AREA/'public-declarations.json').read_text())),'public_definitions':len(json.loads((AREA/'public-definitions.json').read_text())),'public_bytes':len(public),'public_sha256':sha(public),'prior_public_prefix_bytes':len(old),'added_public_bytes':len(public)-len(old),'board_sequence':post['sequence'],'full_goal':'active','complete':False}
(AREA/'verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
