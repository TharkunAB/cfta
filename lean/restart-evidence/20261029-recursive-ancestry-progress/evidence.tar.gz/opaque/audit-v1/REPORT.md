# Opaque ancestry extension: bounded source-only report

Status: candidate-v1 is frozen and UNTESTED by its author.
The parent owns compilation, all repository changes and final evidence.
The parent reports refreshed unchanged main and base f7827693f.
No child Git call was made.

## Candidate

`SourcePruningEnumerationOpaqueAncestryExtension.lean` has 112 lines and 5,514 bytes.
SHA256: e831b8e66049a292f1c6248f03f954a13c46493961b5a757f1d4438a492a0d3b.
It exports only `SourcePruningEnumerationSelectedOpaqueDispatch.observed_cache_ancestry_extension`.
The complete statement and its original import/namespace/type/instance context are preserved in `public/`.

All indices are implicit: checkEmpty; r n p h k target; scs; value; caller; before; queries; result.
The ONLY explicit premise is the literal actual observation:

```
run checkEmpty r n p h k target scs value caller before queries = some result
```

The result is the same all-cache contract as the checked CapturedEdge observer:

- Actual complete cache: Extends before.core after.core AND after.core.expansionAncestry=[].
- Actual rejected cache or stopped receipt with Some cache: Extends AND exact original expansion equality.
- Unhandled or stopped receipt without a candidate: True.

No carrier, model, resource, future history, hook preservation, native-handle bound, completion or shape-budget supplier is added.

## Actual control flow

The proof first splits actual native value constructors.
Empty rejects at the same input cache.
An ordinary node with no terminal bucket member is deferred and cannot satisfy the supplied Some result observation.
Reference, Union, Mu and ordinary nodes with terminal members enter the ACTUAL child-dispatch branch.
No separate opaque model is substituted for that branch.

The child observation is retained as its full raw outcome, reached caller, queries, outer core, waiting state and optional cache.
The local childFields certificate is DERIVED from this actual childRun by the checked ChildDispatch.observed_cache_ancestry_extension observer.
It is not a new theorem input or an arbitrary future child-property supplier.

Error, no raw result, empty raw list, error row and multiple-row outcomes return the exact actual stopped receipt.
Each such branch explicitly splits candidate=None versus candidate=Some cache BEFORE applying its cache property.
This resolves the dependent stopped-Option match at the same concrete constructor that the public result contains.
The successful singleton with no candidate also returns the actual uncached stopped receipt and proves only True.

A successful singleton WITH an actual candidate inverts the exact Option.map finalization result.
The checked child observer supplies the original-to-child Extends relation and expansion equality.
The actual Finalize.run_ancestry_extension observation supplies child-to-final Extends and cleared expansion history.
The proof composes those two relations at the same literal final cache.

## Source review

The native constructor and terminal Bool reductions follow the already checked OpaqueKeyAncestry inversion.
The proof does not split an independently elaborated duplicate runtime matcher or add a duplicate semantic property matcher.
The stopped branches split the actual candidate Option explicitly, as required by the checked CapturedEdge observer repair.
The public inline result match remains the only public case contract.
The full raw child observation remains exact even in stopping/error cases.
Only actual attached caches receive an ancestry assertion.

The observer preserves per-slot keys at the SAME raw slots.
It does not infer key transfer to a different live representative, strict budget decrease, global recursive output lineage, Discharged, rendering correctness, whole-language completeness or termination.
An arbitrary stopped receipt is not claimed to have a cache.
No Haskell file or Haskell defect claim is added.

## Evidence scope

Five source modules were read whole.
Two additional literal cuts preserve the needed finalizer and base Extends contracts.
The source manifest retains complete input byte identities, exact cut hashes, the candidate hash, and the full public statement.
No compilation or evaluator/native execution was performed.
No Git, network, board or repository write was performed.
Only this newly owned TMP area was written.
The bounded candidate and report are frozen for the parent's checks.
