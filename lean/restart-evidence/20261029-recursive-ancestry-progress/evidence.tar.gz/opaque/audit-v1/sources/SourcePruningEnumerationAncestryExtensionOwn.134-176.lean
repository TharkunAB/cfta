          rcases row with ⟨fragment, reached⟩
          cases rest with
          | nil =>
              have same : reached = after := by simpa only [prepared, Option.some.injEq] using observed
              rw [← same]
              exact rows_ancestry_extension heap fuel scs value before [(fragment, reached)]
                prepared fragment reached (by simp)
          | cons row rest => simp only [prepared, reduceCtorEq] at observed

end MicroCFTA.SourcePruningEnumerationCachedPrepare

namespace MicroCFTA.SourcePruningEnumerationFinalize
open EnumerationState SourcePruningEnumerationAncestryExtension
local notation "Symbol" => SourcePruningTemplates.Symbol
variable {EnumGuard NativeGuard : Type}

/-- Actual finalization extends every slot's history and clears expansion ancestry. -/
theorem run_ancestry_extension
    (heap : InternedConstructorTemplates.State Symbol NativeGuard) (fuel target : Nat)
    (fragment : Fragments.Fragment Symbol) (before after : EnumerationExpandableIndex.Cached Symbol EnumGuard)
    (observed : run heap fuel target fragment before = some after) :
    Extends before.core after.core ∧ after.core.expansionAncestry = [] := by
  unfold run at observed
  obtain ⟨_old, _stored, written⟩ := Option.bind_eq_some_iff.mp observed
  have fields := SourcePruningEnumerationNativeIndex.write_ancestry_extension written
  exact ⟨fun slot key member => fields.1 slot key member, fields.2⟩

end MicroCFTA.SourcePruningEnumerationFinalize

namespace MicroCFTA.SourcePruningEnumerationSelectedEdge
open SourcePruningEnumerationAncestryExtension
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula

/-- Residual recording retains every slot key and the exact expansion history. -/
theorem finish_ancestry_extension
    (residual : Option Constraint) (fragment : Fragments.Fragment Symbol)
    (before : EnumerationExpandableIndex.Cached Symbol Constraint) :
    Extends before.core (finish residual fragment before).core ∧
      (finish residual fragment before).core.expansionAncestry = before.core.expansionAncestry :=
  ⟨fun _ _ member => member, rfl⟩

end MicroCFTA.SourcePruningEnumerationSelectedEdge
