import MicroCFTA.EnumerationCompressionFrame
import MicroCFTA.SourcePruningEnumerationKeyShapeBudget

/-!
# Retained recursion keys at every slot

The relation compares complete per-slot recursion histories.
It includes old keys at the next fresh counter.
It makes no claim about the current expansion history.
-/
namespace MicroCFTA.SourcePruningEnumerationAncestryExtension
open EnumerationState EnumerationCorrectness EnumerationCompressionFrame
open SourcePruningEnumerationKeyShapeBudget
variable {Symbol Guard : Type}

/-- Every slot retains every recursion key from the original state. -/
def Extends (before after : State Symbol Guard) : Prop :=
  ∀ slot key, key ∈ before.recursionAncestry slot → key ∈ after.recursionAncestry slot

/-- An unchanged state retains all per-slot keys. -/
theorem Extends.refl (state : State Symbol Guard) : Extends state state :=
  fun _ _ member => member

/-- Successive extensions retain the original per-slot keys. -/
theorem Extends.trans {before middle after : State Symbol Guard}
    (first : Extends before middle) (second : Extends middle after) : Extends before after :=
  fun slot key member => second slot key (first slot key member)

