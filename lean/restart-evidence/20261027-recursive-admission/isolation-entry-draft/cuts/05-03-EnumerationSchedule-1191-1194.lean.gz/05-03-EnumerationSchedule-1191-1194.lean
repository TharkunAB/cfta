/-- A rejecting action has no successful branch. -/
theorem reject_unsuccessful (before after : State Symbol Guard) (value : α) : ¬Success reject before value after := by
  simp [Success, reject, ExceptT.run]

