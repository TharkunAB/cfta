structure Cached (Symbol Guard : Type) where
  core : State Symbol Guard
  expandable : Nat → Bool
  waiting : EnumerationWaitingIndex.Waiting

