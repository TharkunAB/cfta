/- OPEN HEADER ONLY. No proof or theorem credit.
This is a source request-admission target at a literal checked node cut.
It does not assume a child result law or a future source invariant.
-/
import MicroCFTA.SourceCurrentAllocatedNativeGeneralCMHistory
import MicroCFTA.SourceCurrentNativeConsistentOptionalOwner
import MicroCFTA.SourceEqualityNativeDemandBodyYield
import MicroCFTA.SourceSynthesisCurrentUniverseBodyMatchedPairs

namespace MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation
open Cache InternedConstructorTemplates InternedProbeProvenance
open InternedBinderProtocol (NodeKey)
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace)
open SourceCurrentAllocatedNativePhysicalExecution (InputsThrough)
open SourceEqualityNativeDemandOperations (FieldsThrough)
open SourceCurrentAllocatedNativeGeneralCMHistory (AuthenticEntry Qualified)
open SourceSynthesisTypeSyntax (Library Query)
open SourceSynthesisFirstOrderConstruction (Expression)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSynthesisGeneralizeSyntax.Guard
local notation "Checked" => SourceEqualityNativeDemand.State
local notation "Profile" => SourceCurrentAllocatedNativeClosedResetProfile.Profile
local notation "ordinarySymbols" => SourceSynthesisUniverseCallerBoundary.ordinarySymbols
set_option autoImplicit false

/- Note [Actual source call admission]
Query results do not become operands of later compiled queries.
The compiler uses original operands, actual source reads and entered domains.
The carrier checks those calls and their literal continuations only.
Enter and read obligations use actual rooted prefixes within the fixed trace.
The carrier does not assume a result law or an optional body invariant.
-/
private def NodeAdmission
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
    (rootRequest : NodeRequest Symbol Guard) (machine : Machine Symbol Guard)
    (operations : SourceEqualityConstraintMemoAllocation.State) (wholeCount : Nat)
    (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard) (bodyId : Nat)
    (request : NodeRequest Symbol Guard) : Prop :=
  Qualified (width := width) rootRequest machine operations wholeCount entry body depth ordinary request ∨
    ∃ (fullPattern : Value Symbol Guard) (patternId : Nat)
      (originalDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey),
      AuthenticEntry (width := width) rootRequest machine operations wholeCount
        entry body depth ordinary fullPattern patternId originalDomain ∧
      let universeValue : Value Symbol Guard := .mu entry body depth ordinary
      let referenceValue : Value Symbol Guard := .reference (.interned entry.identity)
      let e := SourceRecursiveIntersectionControl.pair bodyId entry.identity
      let d := SourceRecursiveIntersectionControl.pair entry.identity entry.identity
      let bodyFirst := SourceRecursiveIntersectionDomain.extend originalDomain.key [entry.identity] e
      let diagonalFirst := SourceRecursiveIntersectionDomain.extend originalDomain.key [entry.identity] d
      let bodyTerminal := SourceRecursiveIntersectionDomain.extend bodyFirst [entry.identity] d
      let diagonalTerminal := SourceRecursiveIntersectionDomain.extend diagonalFirst [entry.identity] e
      (request.domain.key = bodyFirst ∧
        ((request.left = body ∧ request.right = body) ∨
         (request.left = referenceValue ∧ request.right = referenceValue) ∨
         (request.left = universeValue ∧ request.right = referenceValue))) ∨
      (request.domain.key = bodyTerminal ∧ request.left = body ∧ request.right = referenceValue) ∨
      (request.domain.key = diagonalFirst ∧
        ((request.left = body ∧ request.right = referenceValue) ∨
         (request.left = body ∧ request.right = universeValue))) ∨
      (request.domain.key = diagonalTerminal ∧
        ((request.left = body ∧ request.right = body) ∨
         (request.left = referenceValue ∧ request.right = referenceValue) ∨
         (request.left = universeValue ∧ request.right = referenceValue)))

private def EdgeAdmission
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
    (rootRequest : NodeRequest Symbol Guard) (machine : Machine Symbol Guard)
    (operations : SourceEqualityConstraintMemoAllocation.State) (wholeCount : Nat)
    (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard) (bodyId : Nat)
    (request : EdgeRequest Symbol Guard) : Prop :=
  request.left.children.length = request.right.children.length →
    ∀ children ∈ request.left.children.zip request.right.children,
      NodeAdmission (width := width) rootRequest machine operations wholeCount
        entry body depth ordinary bodyId ⟨request.domain, children.1, children.2⟩

private def CodeAdmission
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat} {A : Type}
    (rootRequest : NodeRequest Symbol Guard) (machine : Machine Symbol Guard)
    (operations : SourceEqualityConstraintMemoAllocation.State) (wholeCount : Nat)
    (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard) (bodyId : Nat) :
    Code Symbol Guard A → Prop
  | .pure _ | .fail _ => True
  | .work _ next | .optionalBinder _ _ next =>
      ∀ value, CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId (next value)
  | .node request next =>
      NodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId request ∧
      ∀ value, CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId (next value)
  | .edge request next =>
      EdgeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId request ∧
      ∀ value, CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId (next value)
  | .enter domain left right first second next =>
      ∀ (used : Nat) (before : Checked width)
        (actualNext : Interned IntersectionFlatMemoKeyDomain.DomainKey → Code Symbol Guard (Value Symbol Guard)),
        used + 1 ≤ wholeCount →
        Trace used (.code (.node rootRequest .pure))
          (⟨initial width machine, operations⟩ : Checked width)
          (.code (.enter domain left right first second actualNext)) before →
        let entered := SourceRecursiveIntersectionEnvironment.enter before.native.machine.domains
          domain.key left right first second
        let after : Checked width :=
          {before with native := advance before.native {before.native.machine with domains := entered.2}}
        Trace 1 (.code (.enter domain left right first second actualNext)) before
          (.code (actualNext entered.1)) after →
        CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId (next entered.1)
  | .read name next =>
      ∀ (used : Nat) (before : Checked width)
        (actualNext : Option (Value Symbol Guard) → Code Symbol Guard (Value Symbol Guard)),
        used + 1 ≤ wholeCount →
        Trace used (.code (.node rootRequest .pure))
          (⟨initial width machine, operations⟩ : Checked width)
          (.code (.read name actualNext)) before →
        CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId
          (next (SourcePreparedSharedRows.read before.native.machine.heap name))
  | .finishNode _ _ next | .finishEdge _ _ next =>
      CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId next

private def ControlAdmission
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
    (rootRequest : NodeRequest Symbol Guard) (machine : Machine Symbol Guard)
    (operations : SourceEqualityConstraintMemoAllocation.State) (wholeCount : Nat)
    (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard) (bodyId : Nat) :
    Control (Value Symbol Guard) → Prop
  | .code code => CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId code
  | .edgeBody request next =>
      EdgeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId request ∧
      ∀ value, CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId (next value)

section CarrierProofs
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
variable (rootRequest : NodeRequest Symbol Guard) (machine : Machine Symbol Guard)
  (operations : SourceEqualityConstraintMemoAllocation.State) (wholeCount : Nat)
  (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard) (bodyId : Nat)

private theorem code_admission_bind {A B : Type}
    (code : Code Symbol Guard A) (next : A → Code Symbol Guard B)
    (original : CodeAdmission (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary bodyId code)
    (continuation : ∀ value, CodeAdmission (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary bodyId (next value)) :
    CodeAdmission (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary bodyId (code.bind next) := by
  induction code with
  | pure value => exact continuation value
  | fail failure => trivial
  | work job resume ih | optionalBinder key value resume ih =>
      intro result
      exact ih result (original result)
  | node request resume ih | edge request resume ih =>
      refine ⟨original.1, ?_⟩
      intro result
      exact ih result (original.2 result)
  | enter domain left right first second resume ih =>
      intro used before actualNext within actual
      dsimp only
      intro one
      exact ih _ (original used before actualNext within actual one)
  | read name resume ih =>
      intro used before actualNext within actual
      exact ih _ (original used before actualNext within actual)
  | finishNode handle value rest ih | finishEdge handle value rest ih => exact ih original

private theorem code_admission_walk {A B : Type}
    (call : A → Code Symbol Guard B) (values : List A)
    (calls : ∀ value ∈ values, CodeAdmission (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary bodyId (call value)) :
    CodeAdmission (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary bodyId (walk call values) := by
  induction values with
  | nil => trivial
  | cons first rest ih =>
      apply code_admission_bind rootRequest machine operations wholeCount entry body depth ordinary bodyId
      · exact calls first List.mem_cons_self
      · intro value
        apply code_admission_bind rootRequest machine operations wholeCount entry body depth ordinary bodyId
        · exact ih (fun member included => calls member (List.mem_cons_of_mem first included))
        · intro values
          trivial

private theorem checked_children_admission
    (request : EdgeRequest Symbol Guard)
    (combined : SourceEqualityConjoinAllocation.Constraint FullSyntax.Formula)
    (admitted : EdgeAdmission (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary bodyId request)
    (arity : request.left.children.length = request.right.children.length) :
    CodeAdmission (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary bodyId
      (SourceEqualityNativeCheckedCode.children request.domain request.left request.right combined) := by
  unfold SourceEqualityNativeCheckedCode.children
  apply code_admission_bind rootRequest machine operations wholeCount entry body depth ordinary bodyId
  · apply code_admission_walk rootRequest machine operations wholeCount entry body depth ordinary bodyId
    intro children included
    exact ⟨admitted arity children included, fun _ => trivial⟩
  · intro values row
    trivial

private theorem checked_sentinel_admission (row : EdgeValue Symbol Guard) :
    CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId
      (SourceEqualityNativeCheckedCode.sentinel row) := by
  intro value
  trivial

private theorem checked_body_yield_admission {A : Type}
    (request : EdgeRequest Symbol Guard)
    (next : EdgeValue Symbol Guard → Code Symbol Guard A)
    (before after : Checked width) (control : Control A)
    (admitted : EdgeAdmission (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary bodyId request)
    (continuation : ∀ row, CodeAdmission (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary bodyId (next row))
    (one : SourceEqualityNativeDemand.body request next before = .yielded control after) :
    ∃ code, control = .code code ∧ CodeAdmission (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary bodyId code := by
  unfold SourceEqualityNativeDemand.body at one
  split at one
  · cases one
    refine ⟨_, rfl, ?_⟩
    exact code_admission_bind rootRequest machine operations wholeCount entry body depth ordinary bodyId
      _ next (checked_sentinel_admission rootRequest machine operations wholeCount
        entry body depth ordinary bodyId request.left) continuation
  · rename_i sameArity
    have arity : request.left.children.length = request.right.children.length := Classical.not_not.mp sameArity
    split at one
    · cases one
    · cases one
    · split at one
      · cases one
      · cases one
      · dsimp only at one
        split at one
        · cases one
        · cases one
          refine ⟨_, rfl, ?_⟩
          exact code_admission_bind rootRequest machine operations wholeCount entry body depth ordinary bodyId
            _ next (checked_sentinel_admission rootRequest machine operations wholeCount
              entry body depth ordinary bodyId request.left) continuation
        · cases one
          refine ⟨_, rfl, ?_⟩
          exact code_admission_bind rootRequest machine operations wholeCount entry body depth ordinary bodyId
            _ next (checked_sentinel_admission rootRequest machine operations wholeCount
              entry body depth ordinary bodyId request.left) continuation
        · cases one
          refine ⟨_, rfl, ?_⟩
          exact code_admission_bind rootRequest machine operations wholeCount entry body depth ordinary bodyId
            _ next (checked_children_admission rootRequest machine operations wholeCount
              entry body depth ordinary bodyId request _ admitted arity) continuation
end CarrierProofs

end MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation

namespace MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation
open Cache InternedConstructorTemplates InternedProbeProvenance
open InternedBinderProtocol (NodeKey)
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace)
open SourceCurrentAllocatedNativePhysicalExecution (InputsThrough)
open SourceEqualityNativeDemandOperations (FieldsThrough)
open SourceCurrentAllocatedNativeGeneralCMHistory (AuthenticEntry Qualified)
open SourceSynthesisTypeSyntax (Library Query)
open SourceSynthesisFirstOrderConstruction (Expression)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSynthesisGeneralizeSyntax.Guard
local notation "Checked" => SourceEqualityNativeDemand.State
local notation "Profile" => SourceCurrentAllocatedNativeClosedResetProfile.Profile
local notation "ordinarySymbols" => SourceSynthesisUniverseCallerBoundary.ordinarySymbols
open InternedNestedFacts InternedEdgeResidency
open SourceRecursiveIntersectionControl (identity tag pair decision payload)
open SourceCurrentAllocatedNativeGeneralCMHistory (ClosedQualified MixedQualified)
open SourceSynthesisUniversePrefixHeight (height)
local notation "Node" => Value Symbol Guard

section SourceCuts
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
variable (rootRequest : NodeRequest Symbol Guard) (machine : Machine Symbol Guard)
  (machineValid : SourceRecursiveIntersectionKernel.Valid machine)
  (operations : SourceEqualityConstraintMemoAllocation.State) (wholeCount : Nat)
  (entry : Interned NodeKey) (body depth ordinary : Node) (bodyId : Nat)

private theorem physical_at_root_prefix
    (sourceHeap : InternedConstructorTemplates.State Symbol Guard)
    (sourceGrowth : Grows sourceHeap machine.heap)
    (used : Nat) (control : Control Node) (before : Checked width)
    (actual : Trace used (.code (.node rootRequest .pure))
      (⟨initial width machine, operations⟩ : Checked width) control before) :
    SourceCurrentAllocatedNativePhysicalCache.Valid before.native ∧
      Grows sourceHeap before.native.machine.heap := by
  have initialPhysical := SourceCurrentAllocatedNativePhysicalCache.initial_valid (width := width) machine machineValid
  have reached := SourceCurrentNativeEnterCommonOperand.checked_trace_extension actual initialPhysical
  exact ⟨reached.1, grows_trans sourceGrowth reached.2.heap⟩

private theorem original_universe_read_at_prefix
    (sourceHeap : InternedConstructorTemplates.State Symbol Guard)
    (sourceGrowth : Grows sourceHeap machine.heap) (key : NodeKey)
    (stored : sourceHeap.nodeRecords key = some (.mu entry body depth ordinary))
    (used : Nat) (control : Control Node) (before : Checked width)
    (actual : Trace used (.code (.node rootRequest .pure))
      (⟨initial width machine, operations⟩ : Checked width) control before) :
    SourcePreparedSharedRows.read before.native.machine.heap entry.identity =
      some (.mu entry body depth ordinary) := by
  have reached := physical_at_root_prefix rootRequest machine machineValid operations sourceHeap sourceGrowth
    used control before actual
  have available : Available before.native.machine.heap (.mu entry body depth ordinary) :=
    reached.1.machine.1.cached.nodes key _ (reached.2.nodeRecords key _ stored)
  exact SourcePreparedSharedRows.read_identity before.native.machine.heap reached.1.machine.1
    (.mu entry body depth ordinary) available entry.identity rfl

private theorem authentic_domain_key
    (pattern : Node) (patternId : Nat)
    (domain : Interned IntersectionFlatMemoKeyDomain.DomainKey)
    (authentic : AuthenticEntry (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary pattern patternId domain) :
    domain.key = SourceRecursiveIntersectionDomain.extend IntersectionEmptyDomain.emptyKey
      [entry.identity] (pair entry.identity patternId) := by
  obtain ⟨_closed, _identity, kind, _side, used, before, _next, data⟩ := authentic
  dsimp only at data
  obtain ⟨_within, actual, _ordered, _one, sameDomain⟩ := data
  have physical := SourceCurrentNativeEnterCommonOperand.checked_trace_extension actual
    (SourceCurrentAllocatedNativePhysicalCache.initial_valid (width := width) machine machineValid)
  have binderPattern : SourceRecursiveIntersectionEnvironment.binder pattern = [] := by
    cases pattern <;> simp_all [tag, SourceRecursiveIntersectionEnvironment.binder]
  have enteredKey := SourceRecursiveIntersectionSchedule.entered_key before.native.machine.domains
    physical.1.machine.2 IntersectionEmptyDomain.emptyKey (.mu entry body depth ordinary) pattern
    entry.identity patternId
  rw [sameDomain]
  simpa only [SourceRecursiveIntersectionEnvironment.bindings,
    SourceRecursiveIntersectionEnvironment.binder, binderPattern, List.append_nil,
    List.map_cons, List.map_nil] using enteredKey

private theorem authentic_domain_nonempty
    (pattern : Node) (patternId : Nat)
    (domain : Interned IntersectionFlatMemoKeyDomain.DomainKey)
    (authentic : AuthenticEntry (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary pattern patternId domain) :
    domain.key.free.isEmpty = false := by
  have keyed := authentic_domain_key rootRequest machine machineValid operations wholeCount
    entry body depth ordinary pattern patternId domain authentic
  have named : entry.identity ∈ SourceRecursiveIntersectionDomain.names domain.key := by
    rw [keyed]
    exact (SourceRecursiveIntersectionDomain.extend_names _ _ _ _).mpr (Or.inl List.mem_cons_self)
  cases freeMap : domain.key.free with
  | nil =>
      simp only [SourceRecursiveIntersectionDomain.names, freeMap, List.map_nil, List.not_mem_nil] at named
  | cons first rest => rfl

private theorem original_entry_from_literal_enter
    (pattern : Node) (patternClosed : pattern.free = []) (patternId : Nat)
    (patternIdentity : identity pattern = some patternId)
    (patternKind : tag pattern = 1 ∨ tag pattern = 3) (universeFirst : Bool)
    (used : Nat) (before : Checked width)
    (next : Interned IntersectionFlatMemoKeyDomain.DomainKey → Code Symbol Guard Node)
    (within : used + 1 ≤ wholeCount)
    (actual : Trace used (.code (.node rootRequest .pure))
      (⟨initial width machine, operations⟩ : Checked width)
      (.code (.enter IntersectionEmptyDomain.emptyDomain
        (if universeFirst then .mu entry body depth ordinary else pattern)
        (if universeFirst then pattern else .mu entry body depth ordinary)
        (if universeFirst then entry.identity else patternId)
        (if universeFirst then patternId else entry.identity) next)) before) :
    let entered := SourceRecursiveIntersectionEnvironment.enter before.native.machine.domains
      IntersectionEmptyDomain.emptyKey
      (if universeFirst then .mu entry body depth ordinary else pattern)
      (if universeFirst then pattern else .mu entry body depth ordinary)
      (if universeFirst then entry.identity else patternId)
      (if universeFirst then patternId else entry.identity)
    let after : Checked width :=
      {before with native := advance before.native {before.native.machine with domains := entered.2}}
    Trace 1 (.code (.enter IntersectionEmptyDomain.emptyDomain
        (if universeFirst then .mu entry body depth ordinary else pattern)
        (if universeFirst then pattern else .mu entry body depth ordinary)
        (if universeFirst then entry.identity else patternId)
        (if universeFirst then patternId else entry.identity) next)) before
      (.code (next entered.1)) after →
    AuthenticEntry (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary pattern patternId entered.1 := by
  dsimp only
  intro one
  let universeValue : Node := .mu entry body depth ordinary
  let canonical := SourceRecursiveIntersectionEnvironment.enter before.native.machine.domains
    IntersectionEmptyDomain.emptyKey universeValue pattern entry.identity patternId
  have binderPattern : SourceRecursiveIntersectionEnvironment.binder pattern = [] := by
    cases pattern <;> simp_all [tag, SourceRecursiveIntersectionEnvironment.binder]
  have ordered : SourceRecursiveIntersectionEnvironment.enter before.native.machine.domains
      IntersectionEmptyDomain.emptyKey
      (if universeFirst then universeValue else pattern)
      (if universeFirst then pattern else universeValue)
      (if universeFirst then entry.identity else patternId)
      (if universeFirst then patternId else entry.identity) = canonical := by
    cases universeFirst with
    | true => rfl
    | false =>
      change IntersectionEmptyDomain.make before.native.machine.domains
        (SourceRecursiveIntersectionDomain.extend IntersectionEmptyDomain.emptyKey
          ((SourceRecursiveIntersectionEnvironment.binder pattern ++
            SourceRecursiveIntersectionEnvironment.binder universeValue).map Prod.fst)
          (pair patternId entry.identity)) = canonical
      simp only [canonical, SourceRecursiveIntersectionEnvironment.enter,
        SourceRecursiveIntersectionEnvironment.bindings, binderPattern, List.nil_append,
        List.append_nil, pair, Nat.min_comm, Nat.max_comm]
  refine ⟨patternClosed, patternIdentity, patternKind, universeFirst, used, before, next, ?_⟩
  dsimp only
  refine ⟨within, actual, ordered, ?_, congrArg Prod.fst ordered⟩
  simpa only [universeValue, ordered] using one

private theorem pattern_body_same (pattern : Node) (kind : tag pattern = 1 ∨ tag pattern = 3) :
    SourceRecursiveIntersectionKernel.body pattern = pattern := by
  cases pattern <;> simp_all [tag, SourceRecursiveIntersectionKernel.body]

private theorem closed_mu_enter_admission
    (bodyEntry : Interned NodeKey) (bodyRows : List (EdgeValue Symbol Guard))
    (bodyShape : body = .node bodyEntry bodyRows 0 [.interned entry.identity])
    (pattern : Node) (profile : Profile entry.identity pattern) (patternId : Nat)
    (patternIdentity : identity pattern = some patternId)
    (patternKind : tag pattern = 1 ∨ tag pattern = 3) (universeFirst : Bool) :
    CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId
      (compileMu IntersectionEmptyDomain.emptyDomain
        (if universeFirst then .mu entry body depth ordinary else pattern)
        (if universeFirst then pattern else .mu entry body depth ordinary)) := by
  have leftIdentity : identity (if universeFirst then .mu entry body depth ordinary else pattern) =
      some (if universeFirst then entry.identity else patternId) := by
    cases universeFirst <;> first | exact patternIdentity | rfl
  have rightIdentity : identity (if universeFirst then pattern else .mu entry body depth ordinary) =
      some (if universeFirst then patternId else entry.identity) := by
    cases universeFirst <;> first | exact patternIdentity | rfl
  simp only [compileMu, leftIdentity, rightIdentity, CodeAdmission]
  intro used before actualNext within actual one
  have authentic := original_entry_from_literal_enter rootRequest machine operations wholeCount
    entry body depth ordinary pattern profile.1 patternId patternIdentity patternKind universeFirst
    used before actualNext within actual one
  refine ⟨Or.inl (Or.inr ?_), ?_⟩
  · refine ⟨pattern, patternId, body, pattern, authentic, Or.inl rfl, profile, Nat.le_refl _, ?_, ?_⟩
    · intro impossible
      rw [bodyShape] at impossible
      cases impossible
    · have bodyPattern := pattern_body_same pattern patternKind
      cases universeFirst with
      | true => exact Or.inl ⟨rfl, bodyPattern⟩
      | false => exact Or.inr ⟨bodyPattern, rfl⟩
  · intro value result
    trivial
end SourceCuts
end MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation

namespace MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation
open Cache InternedConstructorTemplates InternedProbeProvenance
open InternedBinderProtocol (NodeKey)
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace)
open SourceCurrentAllocatedNativePhysicalExecution (InputsThrough)
open SourceEqualityNativeDemandOperations (FieldsThrough)
open SourceCurrentAllocatedNativeGeneralCMHistory (AuthenticEntry Qualified)
open SourceSynthesisTypeSyntax (Library Query)
open SourceSynthesisFirstOrderConstruction (Expression)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSynthesisGeneralizeSyntax.Guard
local notation "Checked" => SourceEqualityNativeDemand.State
local notation "Profile" => SourceCurrentAllocatedNativeClosedResetProfile.Profile
local notation "ordinarySymbols" => SourceSynthesisUniverseCallerBoundary.ordinarySymbols
open InternedNestedFacts InternedEdgeResidency
open SourceRecursiveIntersectionControl (identity tag pair decision payload)
open SourceCurrentAllocatedNativeGeneralCMHistory (ClosedQualified MixedQualified)
open SourceSynthesisUniversePrefixHeight (height)
local notation "Node" => Value Symbol Guard

section Descents
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
variable (rootRequest : NodeRequest Symbol Guard) (machine : Machine Symbol Guard)
  (operations : SourceEqualityConstraintMemoAllocation.State) (wholeCount : Nat)
  (entry : Interned NodeKey) (body depth ordinary : Node) (bodyId : Nat)

private theorem code_admission_rows
    (domain : Interned IntersectionFlatMemoKeyDomain.DomainKey)
    (left right : List (EdgeValue Symbol Guard))
    (each : ∀ rows ∈ SourceRecursiveIntersectionKernel.pairs left right,
      EdgeAdmission (width := width) rootRequest machine operations wholeCount
        entry body depth ordinary bodyId ⟨domain, rows.1, rows.2⟩) :
    CodeAdmission (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary bodyId (compileRows domain left right) := by
  unfold compileRows
  apply code_admission_bind rootRequest machine operations wholeCount entry body depth ordinary bodyId
  · apply code_admission_walk rootRequest machine operations wholeCount entry body depth ordinary bodyId
    intro rows included
    exact ⟨each rows included, fun _ => trivial⟩
  · intro values result
    trivial

private theorem closed_rows_admission
    (heap : InternedConstructorTemplates.State Symbol Guard) (facts : Facts heap)
    (domain : Interned IntersectionFlatMemoKeyDomain.DomainKey)
    (domainKind : domain = IntersectionEmptyDomain.emptyDomain ∨ domain.key.free.isEmpty = false)
    (leftEntry rightEntry : Interned NodeKey) (leftRows rightRows : List (EdgeValue Symbol Guard))
    (leftDepth rightDepth : Nat) (leftFree rightFree : List InternedBinderProtocol.Reference)
    (leftAvailable : Available heap (.node leftEntry leftRows leftDepth leftFree))
    (rightAvailable : Available heap (.node rightEntry rightRows rightDepth rightFree))
    (leftProfile : Profile entry.identity (.node leftEntry leftRows leftDepth leftFree))
    (rightProfile : Profile entry.identity (.node rightEntry rightRows rightDepth rightFree)) :
    CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId
      (compileRows domain leftRows rightRows) := by
  apply code_admission_rows rootRequest machine operations wholeCount entry body depth ordinary bodyId
  intro rows included _arity children zipped
  have rowMembers := (SourceRecursiveIntersectionKernel.pairs_member leftRows rightRows rows).mp included
  have childMembers := List.of_mem_zip zipped
  have first := SourceSynthesisCurrentUniverseAtomInductionSteps.node_child_closed_atoms
    heap facts entry.identity leftEntry leftRows leftDepth leftFree leftAvailable
    leftProfile.1 leftProfile.2 rows.1 rowMembers.1 children.1 childMembers.1
  have second := SourceSynthesisCurrentUniverseAtomInductionSteps.node_child_closed_atoms
    heap facts entry.identity rightEntry rightRows rightDepth rightFree rightAvailable
    rightProfile.1 rightProfile.2 rows.2 rowMembers.2.1 children.2 childMembers.2
  exact Or.inl (Or.inl ⟨⟨first.2.1, first.2.2⟩, ⟨second.2.1, second.2.2⟩, domainKind⟩)

private theorem closed_union_admission
    (heap : InternedConstructorTemplates.State Symbol Guard) (facts : Facts heap)
    (domain : Interned IntersectionFlatMemoKeyDomain.DomainKey)
    (domainKind : domain = IntersectionEmptyDomain.emptyDomain ∨ domain.key.free.isEmpty = false)
    (unionEntry : Interned NodeKey) (members : List Node) (level : Nat)
    (free : List InternedBinderProtocol.Reference) (other : Node) (unionFirst : Bool)
    (available : Available heap (.union unionEntry members level free))
    (profile : Profile entry.identity (.union unionEntry members level free))
    (otherProfile : Profile entry.identity other) :
    CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId
      ((walk (fun member => if unionFirst then requestNode domain member other
        else requestNode domain other member) members).bind fun values => .work (makeUnion values) .pure) := by
  apply code_admission_bind rootRequest machine operations wholeCount entry body depth ordinary bodyId
  · apply code_admission_walk rootRequest machine operations wholeCount entry body depth ordinary bodyId
    intro member included
    have inherited := SourceSynthesisCurrentUniverseAtomInductionSteps.union_member_closed_atoms
      heap facts entry.identity unionEntry members level free available profile.1 profile.2 member included
    have memberProfile : Profile entry.identity member := ⟨inherited.2.1, inherited.2.2⟩
    cases unionFirst with
    | false => exact ⟨Or.inl (Or.inl ⟨otherProfile, memberProfile, domainKind⟩), fun _ => trivial⟩
    | true => exact ⟨Or.inl (Or.inl ⟨memberProfile, otherProfile, domainKind⟩), fun _ => trivial⟩
  · intro values result
    trivial

private theorem mixed_union_admission
    (heap : InternedConstructorTemplates.State Symbol Guard) (facts : Facts heap)
    (pattern : Node) (patternId : Nat) (domain : Interned IntersectionFlatMemoKeyDomain.DomainKey)
    (authentic : AuthenticEntry (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary pattern patternId domain)
    (alias : Node) (aliasKind : alias = body ∨ alias = .reference (.interned entry.identity))
    (unionEntry : Interned NodeKey) (members : List Node) (level : Nat)
    (free : List InternedBinderProtocol.Reference) (aliasFirst : Bool)
    (available : Available heap (.union unionEntry members level free))
    (profile : Profile entry.identity (.union unionEntry members level free))
    (parentHeight : height (.union unionEntry members level free) ≤ height pattern) :
    CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId
      ((walk (fun member => if aliasFirst then requestNode domain alias member
        else requestNode domain member alias) members).bind fun values => .work (makeUnion values) .pure) := by
  apply code_admission_bind rootRequest machine operations wholeCount entry body depth ordinary bodyId
  · apply code_admission_walk rootRequest machine operations wholeCount entry body depth ordinary bodyId
    intro member included
    have inherited := SourceSynthesisCurrentUniverseAtomInductionSteps.union_member_closed_atoms
      heap facts entry.identity unionEntry members level free available profile.1 profile.2 member included
    have memberProfile : Profile entry.identity member := ⟨inherited.2.1, inherited.2.2⟩
    have smaller := SourceSynthesisUniversePrefixHeight.member_lt unionEntry members level free member included
    have strict : height member < height pattern := Nat.lt_of_lt_of_le smaller parentHeight
    have mixed : MixedQualified (width := width) rootRequest machine operations wholeCount
        entry body depth ordinary (if aliasFirst then ⟨domain, alias, member⟩ else ⟨domain, member, alias⟩) := by
      refine ⟨pattern, patternId, alias, member, authentic, aliasKind, memberProfile, Nat.le_of_lt strict,
        fun _ => strict, ?_⟩
      cases aliasFirst with
      | false => exact Or.inr ⟨rfl, rfl⟩
      | true => exact Or.inl ⟨rfl, rfl⟩
    cases aliasFirst <;> exact ⟨Or.inl (Or.inr mixed), fun _ => trivial⟩
  · intro values result
    trivial

private theorem mixed_rows_admission
    (machineValid : SourceRecursiveIntersectionKernel.Valid machine)
    (heap : InternedConstructorTemplates.State Symbol Guard) (facts : Facts heap)
    (bodyRows : List (EdgeValue Symbol Guard))
    (sourceChildren : ∀ row ∈ bodyRows, ∀ child ∈ row.children,
      child = .reference (.interned entry.identity) ∨ Profile entry.identity child)
    (pattern : Node) (patternId : Nat) (domain : Interned IntersectionFlatMemoKeyDomain.DomainKey)
    (authentic : AuthenticEntry (width := width) rootRequest machine operations wholeCount
      entry body depth ordinary pattern patternId domain)
    (operandEntry : Interned NodeKey) (operandRows : List (EdgeValue Symbol Guard)) (level : Nat)
    (free : List InternedBinderProtocol.Reference) (bodyFirst : Bool)
    (available : Available heap (.node operandEntry operandRows level free))
    (profile : Profile entry.identity (.node operandEntry operandRows level free))
    (parentHeight : height (.node operandEntry operandRows level free) ≤ height pattern) :
    CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId
      (compileRows domain (if bodyFirst then bodyRows else operandRows)
        (if bodyFirst then operandRows else bodyRows)) := by
  have nonempty := authentic_domain_nonempty rootRequest machine machineValid operations wholeCount
    entry body depth ordinary pattern patternId domain authentic
  apply code_admission_rows rootRequest machine operations wholeCount entry body depth ordinary bodyId
  intro rows included _arity children zipped
  have rowMembers := (SourceRecursiveIntersectionKernel.pairs_member
    (if bodyFirst then bodyRows else operandRows) (if bodyFirst then operandRows else bodyRows) rows).mp included
  have childMembers := List.of_mem_zip zipped
  cases bodyFirst with
  | true =>
    have inherited := SourceSynthesisCurrentUniverseAtomInductionSteps.node_child_closed_atoms
      heap facts entry.identity operandEntry operandRows level free available profile.1 profile.2
      rows.2 rowMembers.2.1 children.2 childMembers.2
    have childProfile : Profile entry.identity children.2 := ⟨inherited.2.1, inherited.2.2⟩
    rcases sourceChildren rows.1 rowMembers.1 children.1 childMembers.1 with reference | closed
    · have smaller := SourceSynthesisUniversePrefixHeight.child_lt operandEntry operandRows level free
        rows.2 rowMembers.2.1 children.2 childMembers.2
      have strict : height children.2 < height pattern := Nat.lt_of_lt_of_le smaller parentHeight
      exact Or.inl (Or.inr ⟨pattern, patternId, .reference (.interned entry.identity), children.2,
        authentic, Or.inr rfl, childProfile, Nat.le_of_lt strict, fun _ => strict, Or.inl ⟨reference, rfl⟩⟩)
    · exact Or.inl (Or.inl ⟨closed, childProfile, Or.inr nonempty⟩)
  | false =>
    have inherited := SourceSynthesisCurrentUniverseAtomInductionSteps.node_child_closed_atoms
      heap facts entry.identity operandEntry operandRows level free available profile.1 profile.2
      rows.1 rowMembers.1 children.1 childMembers.1
    have childProfile : Profile entry.identity children.1 := ⟨inherited.2.1, inherited.2.2⟩
    rcases sourceChildren rows.2 rowMembers.2.1 children.2 childMembers.2 with reference | closed
    · have smaller := SourceSynthesisUniversePrefixHeight.child_lt operandEntry operandRows level free
        rows.1 rowMembers.1 children.1 childMembers.1
      have strict : height children.1 < height pattern := Nat.lt_of_lt_of_le smaller parentHeight
      exact Or.inl (Or.inr ⟨pattern, patternId, .reference (.interned entry.identity), children.1,
        authentic, Or.inr rfl, childProfile, Nat.le_of_lt strict, fun _ => strict, Or.inr ⟨rfl, reference⟩⟩)
    · exact Or.inl (Or.inl ⟨childProfile, closed, Or.inr nonempty⟩)
end Descents
end MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation

namespace MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation
open Cache InternedConstructorTemplates InternedProbeProvenance
open InternedBinderProtocol (NodeKey)
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace)
open SourceCurrentAllocatedNativePhysicalExecution (InputsThrough)
open SourceEqualityNativeDemandOperations (FieldsThrough)
open SourceCurrentAllocatedNativeGeneralCMHistory (AuthenticEntry Qualified)
open SourceSynthesisTypeSyntax (Library Query)
open SourceSynthesisFirstOrderConstruction (Expression)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSynthesisGeneralizeSyntax.Guard
local notation "Checked" => SourceEqualityNativeDemand.State
local notation "Profile" => SourceCurrentAllocatedNativeClosedResetProfile.Profile
local notation "ordinarySymbols" => SourceSynthesisUniverseCallerBoundary.ordinarySymbols
open InternedNestedFacts InternedEdgeResidency
open SourceRecursiveIntersectionControl (identity tag pair decision payload)
open SourceCurrentAllocatedNativeGeneralCMHistory (ClosedQualified MixedQualified)
open SourceSynthesisUniversePrefixHeight (height)
local notation "Node" => Value Symbol Guard

section ClosedCompiler
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
variable (rootRequest : NodeRequest Symbol Guard) (machine : Machine Symbol Guard)
  (operations : SourceEqualityConstraintMemoAllocation.State) (wholeCount : Nat)
  (entry : Interned NodeKey) (body depth ordinary : Node) (bodyId : Nat)

private theorem closed_compile_admission
    (lib : Library) (query : Query) (signed : Int) (whole : Expression)
    (accepted : SourceSynthesisCurrentConstruction.firstOrderRaw lib query signed = .ok whole)
    (rootValue : Node) (sourceHeap : InternedConstructorTemplates.State Symbol Guard)
    (built : InternedFreshOrdinaryConstruction.build (ordinarySymbols whole) [] empty = .done rootValue sourceHeap)
    (key : NodeKey) (stored : sourceHeap.nodeRecords key = some (.mu entry body depth ordinary))
    (bodyEntry : Interned NodeKey) (bodyRows : List (EdgeValue Symbol Guard))
    (bodyShape : body = .node bodyEntry bodyRows 0 [.interned entry.identity])
    (universeProfile : Profile entry.identity (.mu entry body depth ordinary))
    (heap : InternedConstructorTemplates.State Symbol Guard) (facts : Facts heap)
    (growth : Grows sourceHeap heap)
    (request : NodeRequest Symbol Guard)
    (leftAvailable : Available heap request.left) (rightAvailable : Available heap request.right)
    (qualified : ClosedQualified entry.identity request) :
    CodeAdmission (width := width) rootRequest machine operations wholeCount entry body depth ordinary bodyId
      (compileNode request) := by
  rcases request with ⟨domain, left, right⟩
  rcases qualified with ⟨leftProfile, rightProfile, domainKind⟩
  have muOriginal (own : Interned NodeKey) (storedBody storedDepth storedOrdinary : Node)
      (available : Available heap (.mu own storedBody storedDepth storedOrdinary))
      (profile : Profile entry.identity (.mu own storedBody storedDepth storedOrdinary)) :
      (Value.mu own storedBody storedDepth storedOrdinary : Node) = .mu entry body depth ordinary :=
    SourceSynthesisCurrentUniverseClosedMuClassification.current_stored_universe_closed_mu_eq_after_growth
      lib query signed whole accepted rootValue sourceHeap built key entry body depth ordinary stored
      heap facts growth own storedBody storedDepth storedOrdinary available profile.1 profile.2
  cases emptyTest : SourceRecursiveIntersectionControl.hasEmpty left right with
  | true =>
    simpa only [compileNode, decision, emptyTest, ite_true, CodeAdmission] using True.intro
  | false =>
    cases resetTest : SourceRecursiveIntersectionControl.reset domain.key left right with
    | true =>
      simp only [compileNode, decision, emptyTest, resetTest, Bool.false_eq_true, ite_false, ite_true,
        requestNode, CodeAdmission]
      exact ⟨Or.inl (Or.inl ⟨leftProfile, rightProfile, Or.inl rfl⟩), fun _ => trivial⟩
    | false =>
      have emptyDomain : domain = IntersectionEmptyDomain.emptyDomain := by
        rcases domainKind with same | active
        · exact same
        · have resetTrue : SourceRecursiveIntersectionControl.reset domain.key left right = true := by
            simp only [SourceRecursiveIntersectionControl.reset, leftProfile.1, rightProfile.1,
              List.isEmpty_nil, active, Bool.not_false, Bool.and_self]
          rw [resetTrue] at resetTest
          cases resetTest
      subst domain
      cases selfTest : SourceRecursiveIntersectionControl.closedSelf left right with
      | true =>
        simpa only [compileNode, decision, emptyTest, resetTest, selfTest,
          Bool.false_eq_true, ite_false, ite_true, CodeAdmission] using True.intro
      | false =>
        cases swapTest : SourceRecursiveIntersectionControl.greater left right with
        | true =>
          simp only [compileNode, decision, emptyTest, resetTest, selfTest, swapTest,
            Bool.false_eq_true, ite_false, ite_true, requestNode, CodeAdmission]
          exact ⟨Or.inl (Or.inl ⟨rightProfile, leftProfile, Or.inl rfl⟩), fun _ => trivial⟩
        | false =>
          simp only [compileNode, decision, emptyTest, resetTest, selfTest, swapTest,
            Bool.false_eq_true, ite_false, IntersectionEmptyDomain.emptyDomain, IntersectionEmptyDomain.emptyKey]
          cases left with
          | empty => simp only [identity, unsupported, CodeAdmission]
          | reference name => cases leftProfile.1
          | node leftEntry leftRows leftDepth leftFree =>
            cases right with
            | empty => simp only [identity, unsupported, CodeAdmission]
            | reference name => cases rightProfile.1
            | node rightEntry rightRows rightDepth rightFree =>
              simp only [identity, List.not_mem_nil, ite_false, payload]
              exact closed_rows_admission rootRequest machine operations wholeCount entry body depth ordinary bodyId
                heap facts IntersectionEmptyDomain.emptyDomain (Or.inl rfl)
                leftEntry rightEntry leftRows rightRows leftDepth rightDepth leftFree rightFree
                leftAvailable rightAvailable leftProfile rightProfile
            | union rightEntry members level free =>
              simp only [identity, List.not_mem_nil, ite_false, payload]
              exact closed_union_admission rootRequest machine operations wholeCount entry body depth ordinary bodyId
                heap facts IntersectionEmptyDomain.emptyDomain (Or.inl rfl) rightEntry members level free
                (.node leftEntry leftRows leftDepth leftFree) false rightAvailable rightProfile leftProfile
            | mu own storedBody storedDepth storedOrdinary =>
              simp only [identity, List.not_mem_nil, ite_false, payload]
              have same := muOriginal own storedBody storedDepth storedOrdinary rightAvailable rightProfile
              rw [same]
              exact closed_mu_enter_admission rootRequest machine operations wholeCount entry body depth ordinary bodyId
                bodyEntry bodyRows bodyShape (.node leftEntry leftRows leftDepth leftFree) leftProfile
                leftEntry.identity rfl (Or.inl rfl) false
          | union leftEntry members level free =>
            cases right with
            | empty => simp only [identity, unsupported, CodeAdmission]
            | reference name => cases rightProfile.1
            | node rightEntry rightRows rightDepth rightFree =>
              simp only [identity, List.not_mem_nil, ite_false, payload]
              exact closed_union_admission rootRequest machine operations wholeCount entry body depth ordinary bodyId
                heap facts IntersectionEmptyDomain.emptyDomain (Or.inl rfl) leftEntry members level free
                (.node rightEntry rightRows rightDepth rightFree) true leftAvailable leftProfile rightProfile
            | union rightEntry otherMembers otherLevel otherFree =>
              simp only [identity, List.not_mem_nil, ite_false, payload]
              exact closed_union_admission rootRequest machine operations wholeCount entry body depth ordinary bodyId
                heap facts IntersectionEmptyDomain.emptyDomain (Or.inl rfl) leftEntry members level free
                (.union rightEntry otherMembers otherLevel otherFree) true leftAvailable leftProfile rightProfile
            | mu own storedBody storedDepth storedOrdinary =>
              simp only [identity, List.not_mem_nil, ite_false, payload]
              have same := muOriginal own storedBody storedDepth storedOrdinary rightAvailable rightProfile
              rw [same]
              exact closed_mu_enter_admission rootRequest machine operations wholeCount entry body depth ordinary bodyId
                bodyEntry bodyRows bodyShape (.union leftEntry members level free) leftProfile
                leftEntry.identity rfl (Or.inr rfl) false
          | mu own storedBody storedDepth storedOrdinary =>
            have sameLeft := muOriginal own storedBody storedDepth storedOrdinary leftAvailable leftProfile
            cases right with
            | empty => simp only [identity, unsupported, CodeAdmission]
            | reference name => cases rightProfile.1
            | node rightEntry rightRows rightDepth rightFree =>
              simp only [identity, List.not_mem_nil, ite_false, payload]
              rw [sameLeft]
              exact closed_mu_enter_admission rootRequest machine operations wholeCount entry body depth ordinary bodyId
                bodyEntry bodyRows bodyShape (.node rightEntry rightRows rightDepth rightFree) rightProfile
                rightEntry.identity rfl (Or.inl rfl) true
            | union rightEntry members level free =>
              simp only [identity, List.not_mem_nil, ite_false, payload]
              rw [sameLeft]
              exact closed_mu_enter_admission rootRequest machine operations wholeCount entry body depth ordinary bodyId
                bodyEntry bodyRows bodyShape (.union rightEntry members level free) rightProfile
                rightEntry.identity rfl (Or.inr rfl) true
            | mu rightOwn rightBody rightDepth rightOrdinary =>
              have sameRight := muOriginal rightOwn rightBody rightDepth rightOrdinary rightAvailable rightProfile
              rw [sameLeft, sameRight] at selfTest
              simp only [SourceRecursiveIntersectionControl.closedSelf, Value.referenceOf, beq_self_eq_true,
                universeProfile.1, List.isEmpty_nil, Bool.and_self, Bool.true_eq_false] at selfTest
end ClosedCompiler
end MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation
