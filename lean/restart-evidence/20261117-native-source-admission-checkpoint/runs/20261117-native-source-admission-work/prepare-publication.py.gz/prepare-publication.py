from pathlib import Path
import hashlib
import json
import re
import shlex
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
work = base / '20261117-native-source-admission-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this candidate into the active Work directory'
prior_run = base / '20261117-whole-worker-program-roles-publication'
prior_archive = base / '20261117-whole-worker-program-roles-checkpoint'
runtime = base / '20261117-native-source-admission-publication'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
reader_name = 'lean/MicroCFTA/SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.lean'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
native_name = 'lean/MicroCFTA/SourceSynthesisCurrentUniverseNativeAllocation.lean'
native_sha = '6ad6a65a49512b891fb043b8185c57650e280f4011f1c35ecf6235d994e7af9f'
reader_sha = 'b843352cf3cccc4a3a87eae50ab24f4703f96e4d1a123aa099a7ad823ff9b9ce'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
old_reader_sha = '568ea29287bef52f0743ebe52b327201b80608240d38f72876074cdf48107a71'
prior_commit = '69bd8299c9e5e604c991e8327d385cf64b0facd0'
expected_components = [
    {'module': 'SourceSynthesisCurrentUniverseNativeAllocation',
     'namespace': 'SourceSynthesisCurrentUniverseNativeAllocation',
     'source_path': native_name, 'raw_sha256': native_sha,
     'theorems': ['original_universe_mu_query_prefix_admission']},
    {'module': 'SourceCurrentAllocatedNativeSamePrefixKeyedChildResult',
     'namespace': 'SourceCurrentAllocatedNativeSamePrefixKeyedChildResult',
     'source_path': reader_name, 'raw_sha256': reader_sha,
     'theorems': ['keyed_child_law_at_actual_reader']}]
stage = json.loads((work / 'SOURCES-NORMAL-STAGING.json').read_text())
components = stage['components']
assert len(components) == 2
assert [{key: c[key] for key in expected} for c, expected in zip(components, expected_components)] == expected_components
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports']) == (6249, 5249, 658)
assert stage['new_normal_modules'] == 1 and stage['new_public_theorems'] == 2
assert stage['new_private_native_theorems'] == 36 and stage['new_private_native_predicates'] == 4
assert stage['native363_proved'] and stage['source_admission_cold_root_scope']
assert not stage['independent_query_inherited_warm_tables_proved']
assert not stage['optional441e_proved'] and not stage['joint_finite_completion_proved'] and not stage['haskell_changed']
prior = json.loads((prior_run / 'checked.json').read_text())
assert len(prior['checks']) == 5 and all(c['exit'] == 0 and not c['nonstandard_axioms']
    and not c['diagnostics'] and not c['sorryAx'] for c in prior['checks'])
assert (prior['source_files'], prior['independent_reports'], prior['resource_and_component_probes']) == (6248, 251, 405)
assert prior['whole_worker_program_slots_proved'] and prior['whole_worker_roles_proved']
assert prior['owner_resource_probes'] == 264
baseline = json.loads((work / 'baseline-source-pins.json').read_text())
assert len(baseline) == 6248 and native_name not in baseline
assert {str(p.relative_to(root)) for p in (root / 'lean/MicroCFTA').glob('*.lean')} == set(baseline) | {native_name}
old_reader = (work / 'KEYED-READER-OWNER-BEFORE.lean.txt').read_bytes()
old_audit = (work / 'AUDIT-BEFORE.lean.txt').read_bytes()
assert len(old_reader) == 14650 and sha(old_reader) == old_reader_sha
assert old_audit.count(b'#print axioms ') == 656
for name, digest in baseline.items():
    data = old_audit if name == audit_name else old_reader if name == reader_name else (root / name).read_bytes()
    assert sha(data) == digest, name
assert sha((root / owner_name).read_bytes()) == owner_sha
assert (root / reader_name).read_bytes().startswith(old_reader)
for component in components:
    assert sha((root / component['source_path']).read_bytes()) == component['raw_sha256']
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
qnames = ['MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation.original_universe_mu_query_prefix_admission',
          'MicroCFTA.SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.keyed_child_law_at_actual_reader']
assert public == ''.join('#check ' + q + '\n#print axioms ' + q + '\n' for q in qnames).encode()
new_import = b'import MicroCFTA.SourceSynthesisCurrentUniverseNativeAllocation\n'
audit = (root / audit_name).read_bytes()
assert audit == new_import + old_audit + b'\n' + public
assert sum(line.startswith(b'import ') for line in audit.splitlines()) == 5249
assert audit.count(b'#print axioms ') == 658
header_path = base / '20261117-source-native-admission-prologue-repair/PUBLIC-HEADER.lean.txt'
header = header_path.read_text()
native = (root / native_name).read_text()
declaration = 'theorem original_universe_mu_query_prefix_admission\n'
assert native[native.index(declaration):native.index(' := by', native.index(declaration))].rstrip() == header[header.index(declaration):].rstrip()
doc_record_path = base / '20261117-source-native-admission-prologue-repair/REPAIR.json'
doc_record = json.loads(doc_record_path.read_text())
assert doc_record['normal_raw_sha256'] == native_sha
assert doc_record['original_checked_raw_sha256'] == '486061fcce2c33a2d3bf53d444466df6d54308d3e87f9bbd669531681850ce91'
assert doc_record['only_historical_open_comment_replaced']
assert doc_record['all_original_imports_declarations_proof_bodies_and_limits_byte_exact']
normal_check = base / components[0]['actual_normal_check']
normal_checked = json.loads((normal_check / 'checked.json').read_text())
assert normal_checked['normal_module_checked'] and all(normal_checked['passed'])
assert normal_checked['checks'][1]['total_axiom_reports'] == 37
# Validation above is read-only. Only Root may create the publication run.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-native-admission-publication-'))
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
(runtime / 'PUBLIC-PROBES.lean.txt').write_bytes(public)
commands = []
strict_sources = []
fresh_count = 0
for component in components:
    normal = root / component['source_path']
    namespace = component.get('namespace', component['module'])
    predicates = []
    if component['source_path'] == native_name:
        helpers = re.findall(r'^private theorem ([A-Za-z0-9_]+)', normal.read_text(), re.M)
        predicates = re.findall(r'^private def ([A-Za-z0-9_]+)', normal.read_text(), re.M)
        assert len(helpers) == 36
        assert predicates == ['NodeAdmission', 'EdgeAdmission', 'CodeAdmission', 'ControlAdmission']
    else:
        assert component['private_theorem_reports_to_recompile'] == 0
        helpers = []
    names = helpers + component['theorems']
    probes = ''.join('#check @MicroCFTA.' + namespace + '.' + name + '\n#print axioms MicroCFTA.'
                     + namespace + '.' + name + '\n' for name in names)
    probes += ''.join('#check @MicroCFTA.' + namespace + '.' + name + '\n' for name in predicates)
    fresh_count += len(names)
    source = runtime / 'source/MicroCFTA' / normal.name
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_bytes(normal.read_bytes() + b'\n' + probes.encode())
    (runtime / (component['module'] + '-PROBES.lean.txt')).write_text(probes)
    strict_sources.append(source)
    commands.append(['lake', 'env', 'lean', '-j1', '-DwarningAsError=true', '-R',
        str(source.parent.parent), '-o', str(objects / (component['module'] + '.olean')), str(source)])
assert fresh_count == 38
independent = runtime / 'IndependentProbes.lean'
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert b'import MicroCFTA.SourceCurrentAllocatedNativeGeneralCMHistory\n' in prior_independent
assert b'import MicroCFTA.SourceCurrentAllocatedNativeGeneralCMHistoryDefinitions\n' in (root / 'lean/MicroCFTA/SourceCurrentAllocatedNativeGeneralCMHistory.lean').read_bytes()
assert b'import MicroCFTA.SourceCurrentAllocatedNativeSamePrefixKeyedChildResult\n' in (root / 'lean/MicroCFTA/SourceCurrentAllocatedNativeGeneralCMHistoryDefinitions.lean').read_bytes()
assert new_import not in prior_independent
independent.write_bytes(new_import + prior_independent + b'\n' + public)
assert independent.read_bytes().count(b'#print axioms ') == 253
selection = {'prior_checkpoint': prior_commit,
    'prior_archive_manifest_sha256': sha((prior_archive / 'manifest.json').read_bytes()),
    'prior_checked_sha256': sha((prior_run / 'checked.json').read_bytes()),
    'prior_pins_sha256': sha((prior_run / 'source-pins.json').read_bytes()),
    'baseline_sha256': sha((work / 'baseline-source-pins.json').read_bytes()),
    'stage_sha256': sha((work / 'SOURCES-NORMAL-STAGING.json').read_bytes()),
    'old_audit_sha256': sha(old_audit), 'old_reader_sha256': sha(old_reader),
    'unchanged_resource_owner_sha256': owner_sha,
    'prior_source_files': 6248, 'inherited_reports': 405, 'fresh_reports': 38, 'combined_reports': 443,
    'old_normal_sources_byte_exact_except_audit_and_reader': 6246,
    'old_reader_prefix_bytes': 14650, 'old_reader_prefix_exact': True,
    'old_audit_bytes_retained_after_one_import': True,
    'owner_preflight_reports_fresh_this_batch': 0, 'owner_reports_inherited': 264,
    'old_toolchain_and_proof_inputs_reverified': True, 'axiom_strings_replayed': False}
(runtime / 'INHERITANCE-SELECTION.json').write_text(json.dumps(selection, indent=2) + '\n')
STRICT_BINDING_TEMPLATE = '''from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/home/tritlo/Code/mcfta')
runtime = Path(__file__).parent
prior = root / 'lean/restart-evidence/20261117-whole-worker-program-roles-publication'
archive = root / 'lean/restart-evidence/20261117-whole-worker-program-roles-checkpoint'
work = root / 'lean/restart-evidence/20261117-native-source-admission-work'
sha = lambda data: hashlib.sha256(data).hexdigest()
selection = json.loads((runtime / 'INHERITANCE-SELECTION.json').read_text())
assert sha((archive / 'manifest.json').read_bytes()) == selection['prior_archive_manifest_sha256']
committed = subprocess.check_output(['git', 'show', selection['prior_checkpoint'] + ':'
    + str((archive / 'manifest.json').relative_to(root))], cwd=root)
assert committed == (archive / 'manifest.json').read_bytes()
subprocess.run(['python3', str(archive / 'verify.py')], check=True)
records = json.loads((archive / 'archived-inputs.json').read_text())
for name in ['checked.json', 'source-pins.json']:
    path = prior / name
    record = next(item for item in records if item['original'] == str(path))
    archived = (archive / record['archived']).read_bytes()
    if record['gzip']:
        archived = gzip.decompress(archived)
    assert archived == path.read_bytes()
assert sha((prior / 'checked.json').read_bytes()) == selection['prior_checked_sha256']
assert sha((prior / 'source-pins.json').read_bytes()) == selection['prior_pins_sha256']
assert sha((work / 'baseline-source-pins.json').read_bytes()) == selection['baseline_sha256']
assert sha((work / 'SOURCES-NORMAL-STAGING.json').read_bytes()) == selection['stage_sha256']
assert sha((work / 'AUDIT-BEFORE.lean.txt').read_bytes()) == selection['old_audit_sha256']
assert sha((work / 'KEYED-READER-OWNER-BEFORE.lean.txt').read_bytes()) == selection['old_reader_sha256']
for name, digest in json.loads((prior / 'source-pins.json').read_text()).items():
    if name == 'lean/MicroCFTA/Audit.lean':
        data = (work / 'AUDIT-BEFORE.lean.txt').read_bytes()
    elif name == 'lean/MicroCFTA/SourceCurrentAllocatedNativeSamePrefixKeyedChildResult.lean':
        data = (work / 'KEYED-READER-OWNER-BEFORE.lean.txt').read_bytes()
    else:
        data = (root / name).read_bytes()
    assert sha(data) == digest, name
assert sha((root / 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean').read_bytes()) == selection['unchanged_resource_owner_sha256']
print(json.dumps({'inherited_component_reports_verified': 405,
                  'fresh_component_reports_expected': 38,
                  'fresh_owner_preflight_reports': 0,
                  'unchanged_owner_reports_inherited': 264,
                  'old_sources_and_toolchain_byte_exact': True}), flush=True)
'''
strict = runtime / 'strict-new-and-bind.py'
strict.write_text(STRICT_BINDING_TEMPLATE + '\ncommands = ' + repr(commands)
    + '\nfor command in commands:\n    subprocess.run(command, check=True)\n')
template = (prior_run / 'check.py').read_text()
driver = template[:template.index('\njobs =')]
jobs = [('public-build', 'exec lake build', 0),
    ('strict-new-components-and-prior-bindings', 'exec python3 ' + shlex.quote(str(strict)), 38),
    ('independent-imports', 'exec lake env lean -j1 -DwarningAsError=true ' + shlex.quote(str(independent)), 253),
    ('audit-build', 'exec lake build MicroCFTA.Audit', 0),
    ('audit-strict', 'exec lake env lean -j1 -DwarningAsError=true MicroCFTA/Audit.lean', 658)]
driver += '\njobs = ' + repr(jobs) + '''
for name, command, count in jobs:
    run(name, command, count)
assert len(checks) == 5
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx']
           and (not job[2] or c['total_axiom_reports'] == job[2]) for c, job in zip(checks, jobs))
match = re.search(r'Checked axiom dependencies of (\\d+) MicroCFTA theorems\\.', (runtime / 'audit-strict.txt').read_text())
assert match
'''
report = dict(prior)
for name in ['checks', 'limits', 'at', 'audited_theorems', 'checked_code', 'owner_preflight_evidence',
             'legacy_new_private_reports', 'legacy_new_private_reports_caveat', 'new_owner_export_maxHeartbeats']:
    report.pop(name, None)
for name in list(report):
    if name.startswith('old_non_audit_'):
        report.pop(name)
report.update(source_files=6249, direct_audit_imports=5249, individual_reports=658,
    independent_reports=253, resource_and_component_probes=443,
    inherited_resource_component_reports=405, fresh_resource_component_reports=38,
    fresh_owner_preflight_reports=0, fresh_strict_normal_reports=38, actual_publication_strict_reports=38,
    resource_component_evidence='38 actual fresh strict reports (36 native private + native public + reader public alias) and 405 inherited reports bound to the committed prior archive; no repeated resource-owner compilation in the strict component gate and no replay of axiom strings',
    new_component_reports=38, new_theorem_reports=38, new_modules=1, new_public_theorems=2,
    new_private_component_reports=36, new_public_component_reports=2, new_private_predicates=4,
    new_relation_declaration_checks=4, new_relation_declaration_reports=0,
    owner_resource_probes=264, previous_owner_resource_probes=264,
    owner_recompiled_in_publication_strict_gate=False, fresh_owner_preflight_evidence=None,
    inherited_owner_preflight_evidence={'prior_run': str(prior_run), 'reports': 264,
        'normal_owner_sha256': owner_sha, 'fresh_this_batch': False, 'included_in_inherited_405': True},
    old_non_audit_non_reader_source_files_byte_exact=6246,
    old_non_audit_source_files_byte_exact=6246, entire_previous_resource_owner_byte_exact=True,
    old_resource_owner_sha256=owner_sha, old_reader_prefix_bytes=14650, old_reader_prefix_exact=True,
    old_audit_bytes_preserved_after_one_import=True, all_old_proof_bodies_and_limits_unchanged=True,
    native363_staged=True, reader_alias_staged=True, native_source_admission_proved=True,
    source_active_mu_admission_proved=True, source_admission_cold_root_scope=True,
    source_admission_scope={'source': 'accepted firstOrderRaw original build and its stored full U',
        'root': 'literal emptyDomain; both native memo families initially empty',
        'operands': 'both original root operands satisfy Profile(entry.identity)',
        'trace': 'same original checked whole trace and actual query prefix; all supplied fuels retained',
        'plans': 'original InputsThrough and FieldsThrough remain explicit physical premises',
        'result': 'Qualified or exact source auxiliary entry alternatives; no future result-law supplier'},
    reader_actual_control_api_export_proved=True, reader_alias_contract_unchanged=True,
    original363_public_declaration_exact=True, native_historical_open_comment_only_replaced=True,
    independent_query_inherited_warm_tables_proved=False, warm_across_independent_queries_proved=False,
    optional441e_proved=False, joint_finite_completion_proved=False,
    all_native_inhabitance_proved=False, source_terminal_marker_native_inhabitance_proved=False,
    source_type_marker_class_consistency_proved=False, compiled_haskell_correspondence_proved=False,
    haskell_changed=False, whole_worker_roles_proved=True, whole_worker_program_slots_proved=True,
    whole_worker_program_slots_fixed_marks_proved=True,
    proof_limits='unchanged defaults; unchanged owner proof settings inherited',
    prior_checkpoint=prior_commit, prior_immutable_archive=prior_archive.name, public_run=str(runtime))
driver += 'report = ' + repr(report) + '\n'
driver += '''report.update(checks=checks, limits=limits, at=datetime.datetime.now().astimezone().isoformat(),
              audited_theorems=int(match.group(1)))
(runtime / 'checked.json').write_text(json.dumps(report, indent=2) + '\\n')
print(json.dumps(report), flush=True)
'''
(runtime / 'check.py').write_text(driver)
files = list((root / 'lean/MicroCFTA').glob('*.lean'))
files += [root / name for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']]
files += [p for p in runtime.iterdir() if p.is_file()] + strict_sources
files += [Path(__file__), work / 'SOURCES-NORMAL-STAGING.json', work / 'baseline-source-pins.json',
    work / 'AUDIT-BEFORE.lean.txt', work / 'KEYED-READER-OWNER-BEFORE.lean.txt', header_path,
    work / 'FULL363-FIRST-VERIFIED.json', work / 'FULL363-NORMAL-VERIFIED.json', doc_record_path,
    normal_check / 'checked.json', normal_check / 'selection.json', normal_check / 'normal-module.txt']
(runtime / 'source-pins.json').write_text(json.dumps(
    {str(p.relative_to(root)): sha(p.read_bytes()) for p in files}, indent=2) + '\n')
print(json.dumps({'run': str(runtime), 'gates': 5, 'fresh_component_reports': 38,
    'inherited_component_reports': 405, 'combined_component_reports': 443,
    'fresh_owner_preflight_reports': 0, 'inherited_owner_reports': 264,
    'independent_reports': 253, 'audit_reports': 658, 'objects': str(objects)}))
