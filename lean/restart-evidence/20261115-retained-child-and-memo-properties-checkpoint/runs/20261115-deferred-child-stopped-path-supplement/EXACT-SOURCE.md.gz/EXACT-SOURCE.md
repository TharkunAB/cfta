[2026-11-15 06:33 CET]

Exact existing source definitions and theorem headers. No new theorem is claimed.

lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean:11836

```lean
private noncomputable def identity_actual_frame_callbacks
    (graph : Graph Symbol Constraint) (checkEmpty : Bool)
    (edgesOf : Node → List (EdgeValue Symbol Constraint)) (recursiveDepth workFuel : Nat)
    (metadata : Metadata Unit) (uv : Nat) : IdentityActualCallbackFrame bits → Done × Stopped
  | .captured edge residual caller queries =>
      let hook := SourcePruningEnumerationSharedPreparedRecursive.continueWith
        (resumeWithNarrow (Typing := Unit) (width := bits + 2)
          (SourcePruningEnumerationSharedEagerChildren.eagerChild checkEmpty
            workFuel workFuel workFuel workFuel workFuel edgesOf)
          (fun _ _ _ node state => .done node state) graph [] checkEmpty edgesOf
          none (fun _ _ => none) workFuel recursiveDepth)
        graph [] none (fun _ _ => none) workFuel metadata uv
      (fun fragments reached saved after =>
        let fragment := Fragments.Fragment.node edge.entry.key.symbol fragments
        let middle := SelectedEdge.finish residual fragment after
        match SourcePruningEnumerationFinalize.run reached.checked.native.machine.heap workFuel uv fragment middle with
        | some finished => SourcePruningEnumerationSharedReceiptContinuation.run hook caller queries
            (some (.complete fragment reached saved finished))
        | none => SourcePruningEnumerationSharedReceiptContinuation.run hook caller queries
            (some (.finalizeStopped fragment reached saved middle)),
       fun completed observation candidate => SourcePruningEnumerationSharedReceiptContinuation.run
         hook caller queries (some (.stopped completed observation candidate)))
  | .selected parent completedPrefix rest edge residual caller queries _parentHeight _remainingCount _parentBound =>
      let inherited := identity_actual_frame_callbacks graph checkEmpty edgesOf recursiveDepth workFuel metadata uv parent
      let tail := identity_actual_parent_tail checkEmpty edgesOf workFuel inherited completedPrefix rest
      (fun fragments reached saved after =>
        let fragment := Fragments.Fragment.node edge.entry.key.symbol fragments
        SourcePruningEnumerationSharedEagerChildren.consumeSelected tail caller queries
          (.complete fragment reached saved (SelectedEdge.finish residual fragment after)),
       fun completed observation candidate => SourcePruningEnumerationSharedEagerChildren.consumeSelected
         tail caller queries (.stopped completed observation candidate))
```

lean/MicroCFTA/SourcePruningEnumerationSharedEagerChildren.lean:42

```lean
def consumeSelected
    (done : Fragment → Caller width → Queries → Cached → Result Output Reason width)
    (caller : Caller width) (queries : Queries) (receipt : Receipt width) : Result Output Reason width :=
  match receipt with
  | .complete fragment reached saved after =>
      match done fragment reached saved after with
      | .complete processed outputs finalCaller finalQueries =>
          .complete (receipt :: processed) outputs finalCaller finalQueries
      | .stopped processed outputs current => .stopped (receipt :: processed) outputs current
  | other =>
      match advance other with
      | none => .stopped [] [] (.edge (some other) (endpoint other caller queries))
      | some (reached, saved) => .complete [other] [] reached saved
```

lean/MicroCFTA/SourcePruningEnumerationSharedChildVisitors.lean:34

```lean
noncomputable def visitChildren
    (visit : Visitor)
    (done : List Fragment → Caller width → Queries → Cached → Result Output Reason width)
    (stopped : List Fragment → Observation width → Option Cached → Result Output Reason width) :
    List (Node × List Suspended) → Caller width → Cached → Queries → Result Output Reason width
  | [], caller, before, queries => done [] caller queries before
  | (value, bucket) :: rest, caller, before, queries =>
      visit bucket value caller before queries
        (fun fragment reached saved after =>
          visitChildren visit
            (fun fragments => done (fragment :: fragments))
            (fun completed => stopped (fragment :: completed)) rest reached after saved)
        (fun observation candidate => stopped [] observation candidate)
```

lean/MicroCFTA/SourcePruningEnumerationSharedChildVisitors.lean:80

```lean
noncomputable def visitCapturedWith
    (visit : Visitor)
    (hook : Fragment → Caller width → Queries → Cached → HookResult Output Reason width)
    (k target : Nat) (scs : List Suspended) (edge : Edge)
    (caller : Caller width) (queries : Queries) (before : Cached) : Result Output Reason width :=
  visitSelected visit (fun receipt =>
    match receipt with
    | .complete fragment reached saved after =>
        match SourcePruningEnumerationFinalize.run reached.checked.native.machine.heap k target fragment after with
        | some finished => finishReceipt hook caller queries (.complete fragment reached saved finished)
        | none => finishReceipt hook caller queries (.finalizeStopped fragment reached saved after)
    | other => finishReceipt hook caller queries other) scs edge caller before queries
```

lean/MicroCFTA/SourcePruningEnumerationSharedChildVisitors.lean:96

```lean
noncomputable def shallowVisit
    (checkEmpty : Bool) (r n p h k : Nat)
    (scs : List Suspended) (incoming : Node) (caller : Caller width) (before : Cached) (queries : Queries)
    (done : Fragment → Caller width → Queries → Cached → Result Output Reason width)
    (stopped : Observation width → Option Cached → Result Output Reason width) : Result Output Reason width :=
  match ChildDispatch.run checkEmpty r n p h k scs incoming caller before queries with
  | ((.ok (some [.ok (fragment, _returned)]), reached, saved, _outer, _waiting), some after) =>
      done fragment reached saved after
  | (observation, candidate) => stopped observation candidate
```

lean/MicroCFTA/SourcePruningEnumerationSharedReceiptContinuation.lean:26

```lean
def run
    (hook : Fragment → Caller width → Queries → Cached → HookResult Output Reason width)
    (caller : Caller width) (queries : Queries) : Option (Receipt width) → Result Output Reason width
  | none => .stopped [] [] (.edge none (caller, queries))
  | some receipt =>
      match receipt with
      | .complete fragment reached saved after =>
          match hook fragment reached saved after with
          | .complete outputs actual returned => .complete [receipt] outputs actual returned
          | .stopped outputs reason actual => .stopped [] outputs (.continuation receipt reason actual)
      | other =>
          match advance other with
          | none => .stopped [] [] (.edge (some other) (endpoint other caller queries))
          | some (reached, saved) => .complete [other] [] reached saved
```

lean/MicroCFTA/SourcePruningEnumerationSharedReceiptContinuation.lean:58

```lean
theorem stopped_hook
    (hook : Fragment → Caller width → Queries → Cached → HookResult Output Reason width)
    (caller reached : Caller width) (queries saved : Queries) (fragment : Fragment) (after : Cached)
    (outputs : List Output) (reason : Reason) (actual : Option (Caller width × Queries))
    (stopped : hook fragment reached saved after = .stopped outputs reason actual) :
    run hook caller queries (some (.complete fragment reached saved after)) =
      .stopped [] outputs (.continuation (.complete fragment reached saved after) reason actual) := by
  simp only [run, stopped]
```

lean/MicroCFTA/SourcePruningEnumerationSharedReceiptContinuation.lean:68

```lean
theorem finalize_stopped
    (hook : Fragment → Caller width → Queries → Cached → HookResult Output Reason width)
    (caller reached : Caller width) (queries saved : Queries) (fragment : Fragment) (after : Cached) :
    run hook caller queries (some (.finalizeStopped fragment reached saved after)) =
      .stopped [] [] (.edge (some (.finalizeStopped fragment reached saved after)) (reached, saved)) := rfl
```

lean/MicroCFTA/SourcePruningEnumerationSharedSelectedContinuations.lean:599

```lean
def advance : Receipt width → Option (Caller width × Queries)
  | .complete _ caller queries _ => some (caller, queries)
  | .rejected caller queries _ => some (caller, queries)
  | .stopped _ (.ok (some []), caller, queries, _outer, _waiting) (some _) => some (caller, queries)
  | _ => none
```

lean/MicroCFTA/SourcePruningEnumerationSharedSelectedContinuations.lean:606

```lean
def endpoint (receipt : Receipt width) (caller : Caller width) (queries : Queries) : Caller width × Queries :=
  match receipt with
  | .complete _ reached saved _ => (reached, saved)
  | .rejected reached saved _ => (reached, saved)
  | .stopped _ (_, reached, saved, _, _) _ => (reached, saved)
  | .finalizeStopped _ reached saved _ => (reached, saved)
  | .unhandled => (caller, queries)
```

lean/MicroCFTA/SourcePruningEnumerationSharedBranching.lean:29

```lean
noncomputable def scan
    (visit : Edge → Caller width → Queries → Cached → Result Output Reason width)
    (before : Cached) : List Edge → Caller width → Queries → Result Output Reason width
  | [], caller, queries => .complete [] [] caller queries
  | edge :: rest, caller, queries =>
      match visit edge caller queries before with
      | .stopped processed outputs current => .stopped processed outputs current
      | .complete processed outputs reached saved =>
          match scan visit before rest reached saved with
          | .complete later remaining finalCaller finalQueries =>
              .complete (processed ++ later) (outputs ++ remaining) finalCaller finalQueries
          | .stopped later remaining current =>
              .stopped (processed ++ later) (outputs ++ remaining) current
```

lean/MicroCFTA/SourcePruningEnumerationSharedBranching.lean:59

```lean
theorem scan_complete
    (visit : Edge → Caller width → Queries → Cached → Result Output Reason width)
    (before : Cached) (edge : Edge) (rest : List Edge) (caller reached : Caller width) (queries saved : Queries)
    (processed : List (Receipt width)) (outputs : List Output)
    (observed : visit edge caller queries before = .complete processed outputs reached saved) :
    scan visit before (edge :: rest) caller queries =
      match scan visit before rest reached saved with
      | .complete later remaining finalCaller finalQueries =>
          .complete (processed ++ later) (outputs ++ remaining) finalCaller finalQueries
      | .stopped later remaining current => .stopped (processed ++ later) (outputs ++ remaining) current := by
  simp only [scan, observed]
```

lean/MicroCFTA/SourcePruningEnumerationSharedPreparedRecursive.lean:62

```lean
def finish (uv : Nat) : Fold (Output width Typing) (Failure width Typing) width → Result
  | .complete _processed outputs caller queries => .complete outputs caller queries
  | .stopped processed outputs current =>
      .stopped outputs (.alternatives uv processed current) (endpoint current)
```

lean/MicroCFTA/SourcePruningEnumerationSharedPreparedRecursive.lean:68

```lean
theorem finish_stopped (uv : Nat) (processed : List (Receipt width))
    (outputs : List (Output width Typing)) (current : FoldStop (Failure width Typing) width) :
    finish uv (.stopped processed outputs current) =
      .stopped outputs (.alternatives uv processed current) (endpoint current) := rfl
```

lean/MicroCFTA/SourcePruningEnumerationSharedPreparedRecursive.lean:74

```lean
noncomputable def continueWith
    (recur : Metadata Typing → Caller width → Queries → Cached → Option Next → Result)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat)
    (callbackFuel : Nat) (metadata : Metadata Typing) (uv : Nat)
    (fragment : Fragment) (caller : Caller width) (queries : Queries) (before : Cached) : Result :=
  let raw := ExceptT.run (SourcePruningRecordTypes.recordTypes
    graph templates callbackFuel metadata uv (.inl fragment) before.core)
  match raw with
  | [.ok ((true, _updated), _observed)] => .complete [] caller queries
  | [.ok ((false, updated), observed)] =>
      let after := EnumerationExpandableIndex.frame observed before
      recur updated caller queries after (SourcePruningEnumerationRestart.decision stop order updated after)
  | _ => .stopped [] (.callback uv raw) (some (caller, queries))
```

lean/MicroCFTA/SourcePruningEnumerationSharedPreparedRecursiveChildPolicy.lean:39

```lean
noncomputable def resumeWithNarrow
    (child : Visitor)
    (narrow : Metadata Typing → Nat → Nat → Node →
      InternedConstructorTemplates.State Symbol Constraint →
      MergedSourceComparison.Result Symbol Constraint Node)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (workFuel : Nat) :
    Nat → Metadata Typing → Caller width → Queries → Cached → Option Next → Result
  | _fuel, metadata, caller, queries, before, none => .complete [⟨some metadata, before, caller, queries⟩] caller queries
  | _fuel, _metadata, caller, queries, before, some .done => .complete [⟨none, before, caller, queries⟩] caller queries
  | _fuel, _metadata, caller, queries, _before, some .stuck => .complete [] caller queries
  | 0, metadata, caller, queries, before, some (.expand uv) =>
      .stopped [] (.exhausted uv metadata before) (some (caller, queries))
  | fuel + 1, metadata, caller, queries, before, some (.expand uv) =>
      let observed := SourcePruningEnumerationSelectedStep.runPrefixWithNarrow narrow graph templates
        stop order metadata workFuel workFuel workFuel workFuel workFuel workFuel uv caller before queries
      match observed with
      | .parked _ (some _parked) (some []) => .complete [] caller queries
      | .parked _ (some parked) (some [.ok ((updated, next), core)]) =>
          resumeWithNarrow child narrow graph templates checkEmpty edgesOf stop order workFuel fuel
            updated caller queries (EnumerationExpandableIndex.frame core parked) next
      | .narrowed _ _ reached saved (some []) _ _ _ => .complete [] reached saved
      | .narrowed _ _ reached saved _ _ (some [.ok ((true, _updated), _core)]) _ =>
          .complete [] reached saved
      | .narrowed _ _ reached saved _ (some after) (some [.ok ((false, updated), _core)]) none =>
          let prepared := SourcePruningEnumerationSharedPreparedChildPolicy.runWithChild child
            (continueWith (resumeWithNarrow child narrow graph templates checkEmpty edgesOf stop order workFuel fuel)
              graph templates stop order workFuel updated uv)
            checkEmpty workFuel workFuel workFuel workFuel workFuel workFuel workFuel uv edgesOf reached after saved
          match prepared.2 with
          | none => .stopped [] (.preparation uv prepared.1)
              (some (SourcePruningEnumerationSharedPreparedContinuations.preparation_endpoint reached saved prepared.1))
          | some folded => finish uv folded
      | .narrowed _ _ reached saved _ _ _ _ => .stopped [] (.selected uv observed) (some (reached, saved))
      | _ => .stopped [] (.selected uv observed) (some (caller, queries))
```

lean/MicroCFTA/SourcePruningEnumerationSharedScanOutputOrigins.lean:30

```lean
def outputs : Result Output Reason width → List Output
  | .complete _ values _ _ => values
  | .stopped _ values _ => values
```

lean/MicroCFTA/SourcePruningEnumerationSharedScanOutputOrigins.lean:35

```lean
theorem scan_output_origin
    (visit : Edge → Caller width → Queries → Cached → Result Output Reason width)
    (before : Cached) (edges : List Edge) (caller : Caller width) (queries : Queries)
    (index : Nat) (output : Output)
    (observed : (outputs (scan visit before edges caller queries))[index]? = some output) :
    ∃ (attempted : List Edge) (edge : Edge) (remaining : List Edge)
        (rowCaller : Caller width) (rowQueries : Queries)
        (processed : List (SelectedEdge.Result width)) (earlier : List Output)
        (rowResult : Result Output Reason width) (localIndex : Nat),
      edges = attempted ++ edge :: remaining ∧
      scan visit before attempted caller queries = .complete processed earlier rowCaller rowQueries ∧
      visit edge rowCaller rowQueries before = rowResult ∧
      (outputs rowResult)[localIndex]? = some output ∧
      index = earlier.length + localIndex := by
```

lean/MicroCFTA/SourcePruningEnumerationSharedScanOutputOrigins.lean:89

```lean
theorem identity_eager_scan_output_origin
    (graph : Graph Symbol Constraint) (checkEmpty : Bool)
    (edgesOf : Node → List Edge) (workFuel recursiveDepth uv : Nat)
    (metadata : SourcePruningRecordTypes.Metadata Unit) (scs : List Suspended)
    (before : Cached) (edges : List Edge) (caller : Caller width) (queries : Queries)
    (index : Nat) (output : SourcePruningEnumerationSharedPreparedRecursive.Output width Unit) :
    let child := SourcePruningEnumerationSharedEagerChildren.eagerChild checkEmpty
      workFuel workFuel workFuel workFuel workFuel edgesOf
    let recur := SourcePruningEnumerationSharedPreparedRecursiveChildPolicy.resumeWithNarrow child
      (fun _ _ _ node state => MergedSourceComparison.Result.done node state)
      graph [] checkEmpty edgesOf none (fun _ _ => none) workFuel recursiveDepth
    let hook := SourcePruningEnumerationSharedPreparedRecursive.continueWith recur
      graph [] none (fun _ _ => none) workFuel metadata uv
    let visit := fun edge current saved captured =>
      SourcePruningEnumerationSharedChildVisitors.visitCapturedWith child hook
        workFuel uv scs edge current saved captured
    (outputs (scan visit before edges caller queries))[index]? = some output →
    ∃ (attempted : List Edge) (edge : Edge) (remaining : List Edge)
        (rowCaller : Caller width) (rowQueries : Queries)
        (processed : List (SelectedEdge.Result width))
        (earlier : List (SourcePruningEnumerationSharedPreparedRecursive.Output width Unit))
        (rowResult : Result
          (SourcePruningEnumerationSharedPreparedRecursive.Output width Unit)
          (SourcePruningEnumerationSharedPreparedRecursive.Failure width Unit) width)
        (localIndex : Nat),
      edges = attempted ++ edge :: remaining ∧
      scan visit before attempted caller queries = .complete processed earlier rowCaller rowQueries ∧
      SourcePruningEnumerationSharedChildVisitors.visitCapturedWith child hook
        workFuel uv scs edge rowCaller rowQueries before = rowResult ∧
      (outputs rowResult)[localIndex]? = some output ∧
      index = earlier.length + localIndex := by
```
