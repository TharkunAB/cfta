[2026-11-15 06:17 CET]

Exact source excerpts. These are existing definitions and theorem headers.
No new theorem is claimed. SOURCE-PINS.json identifies each complete source file.

lean/MicroCFTA/SourcePruningEnumerationSharedChildVisitors.lean:34

```lean
noncomputable def visitChildren
    (visit : Visitor)
    (done : List Fragment → Caller width → Queries → Cached → Result Output Reason width)
    (stopped : List Fragment → Observation width → Option Cached → Result Output Reason width) :
    List (Node × List Suspended) → Caller width → Cached → Queries → Result Output Reason width
  | [], caller, before, queries => done [] caller queries before
  | (value, bucket) :: rest, caller, before, queries =>
      visit bucket value caller before queries
        (fun fragment reached saved after =>
          visitChildren visit
            (fun fragments => done (fragment :: fragments))
            (fun completed => stopped (fragment :: completed)) rest reached after saved)
        (fun observation candidate => stopped [] observation candidate)
```

lean/MicroCFTA/SourcePruningEnumerationSharedChildVisitors.lean:49

```lean
noncomputable def visitSelected
    (visit : Visitor) (consume : Receipt width → Result Output Reason width)
    (scs : List Suspended) (edge : Edge) (caller : Caller width) (before : Cached) (queries : Queries) :
    Result Output Reason width :=
  match SourcePruningEnumerationCachedOwn.prepare caller.checked.native.machine.heap scs edge before with
  | none => consume .unhandled
  | some [] => consume (.rejected caller queries before)
  | some [((symbol, staged, residual), middle)] =>
      visitChildren visit
        (fun fragments reached saved after =>
          let fragment := Fragments.Fragment.node symbol fragments
          consume (.complete fragment reached saved (SelectedEdge.finish residual fragment after)))
        (fun completed observation candidate => consume (.stopped completed observation candidate))
        (staged.map (fun input => (input.1, input.2.1))) caller middle queries
  | _ => consume .unhandled
```

lean/MicroCFTA/SourcePruningEnumerationSharedEagerChildren.lean:134

```lean
noncomputable def eagerChild
    (checkEmpty : Bool) (r n p h k : Nat) (edgesOf : Node → List Edge)
    (scs : List Suspended) (incoming : Node) (caller : Caller width) (before : Cached) (queries : Queries)
    (done : Fragment → Caller width → Queries → Cached → Result Output Reason width)
    (stopped : Observation width → Option Cached → Result Output Reason width) : Result Output Reason width :=
  if ordinaryNonterminal scs incoming then
    scan (fun edge reached saved captured =>
      visitSelected
        (fun bucket child current cache memos yes no =>
          if _lower : MergedOrdinaryHeight.height child < MergedOrdinaryHeight.height incoming then
            eagerChild checkEmpty r n p h k edgesOf bucket child current cache memos yes no
          else shallowVisit checkEmpty r n p h k bucket child current cache memos yes no)
        (consumeSelected done reached saved) scs edge reached captured saved)
      before (edgesOf incoming) caller queries
  else shallowVisit checkEmpty r n p h k scs incoming caller before queries done stopped
termination_by MergedOrdinaryHeight.height incoming
decreasing_by exact _lower
```

lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean:11823

```lean
private noncomputable def identity_actual_parent_tail
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint)) (workFuel : Nat)
    (callbacks : Done × Stopped) (completedPrefix : List Fragment)
    (rest : List (Node × List Suspended)) : ChildDone :=
  fun fragment reached saved after =>
    SourcePruningEnumerationSharedChildVisitors.visitChildren
      (SourcePruningEnumerationSharedEagerChildren.eagerChild checkEmpty
        workFuel workFuel workFuel workFuel workFuel edgesOf)
      (fun fragments => callbacks.1 (completedPrefix ++ fragment :: fragments))
      (fun completed => callbacks.2 (completedPrefix ++ fragment :: completed))
      rest reached after saved
```

lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean:11836

```lean
private noncomputable def identity_actual_frame_callbacks
    (graph : Graph Symbol Constraint) (checkEmpty : Bool)
    (edgesOf : Node → List (EdgeValue Symbol Constraint)) (recursiveDepth workFuel : Nat)
    (metadata : Metadata Unit) (uv : Nat) : IdentityActualCallbackFrame bits → Done × Stopped
  | .captured edge residual caller queries =>
      let hook := SourcePruningEnumerationSharedPreparedRecursive.continueWith
        (resumeWithNarrow (Typing := Unit) (width := bits + 2)
          (SourcePruningEnumerationSharedEagerChildren.eagerChild checkEmpty
            workFuel workFuel workFuel workFuel workFuel edgesOf)
          (fun _ _ _ node state => .done node state) graph [] checkEmpty edgesOf
          none (fun _ _ => none) workFuel recursiveDepth)
        graph [] none (fun _ _ => none) workFuel metadata uv
      (fun fragments reached saved after =>
        let fragment := Fragments.Fragment.node edge.entry.key.symbol fragments
        let middle := SelectedEdge.finish residual fragment after
        match SourcePruningEnumerationFinalize.run reached.checked.native.machine.heap workFuel uv fragment middle with
        | some finished => SourcePruningEnumerationSharedReceiptContinuation.run hook caller queries
            (some (.complete fragment reached saved finished))
        | none => SourcePruningEnumerationSharedReceiptContinuation.run hook caller queries
            (some (.finalizeStopped fragment reached saved middle)),
       fun completed observation candidate => SourcePruningEnumerationSharedReceiptContinuation.run
         hook caller queries (some (.stopped completed observation candidate)))
  | .selected parent completedPrefix rest edge residual caller queries _parentHeight _remainingCount _parentBound =>
      let inherited := identity_actual_frame_callbacks graph checkEmpty edgesOf recursiveDepth workFuel metadata uv parent
      let tail := identity_actual_parent_tail checkEmpty edgesOf workFuel inherited completedPrefix rest
      (fun fragments reached saved after =>
        let fragment := Fragments.Fragment.node edge.entry.key.symbol fragments
        SourcePruningEnumerationSharedEagerChildren.consumeSelected tail caller queries
          (.complete fragment reached saved (SelectedEdge.finish residual fragment after)),
       fun completed observation candidate => SourcePruningEnumerationSharedEagerChildren.consumeSelected
         tail caller queries (.stopped completed observation candidate))
```

lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean:11932

```lean
private theorem identity_selected_frame_callback
    (graph : Graph Symbol Constraint) (checkEmpty : Bool)
    (edgesOf : Node → List (EdgeValue Symbol Constraint)) (recursiveDepth workFuel : Nat)
    (metadata : Metadata Unit) (uv : Nat) (parent : IdentityActualCallbackFrame bits)
    (completedPrefix : List Fragment) (rest : List (Node × List Suspended))
    (edge : EdgeValue Symbol Constraint) (residual : Option Constraint)
    (caller : Caller (bits + 2)) (queries : Queries) (parentHeight remainingCount parentBound : Nat)
    (fragments : List Fragment) (reached : Caller (bits + 2)) (saved : Queries) (after : Cached) :
    let inherited := identity_actual_frame_callbacks graph checkEmpty edgesOf recursiveDepth workFuel metadata uv parent
    let tail := identity_actual_parent_tail checkEmpty edgesOf workFuel inherited completedPrefix rest
    let fragment := Fragments.Fragment.node edge.entry.key.symbol fragments
    let returned := SelectedEdge.finish residual fragment after
    (identity_actual_frame_callbacks graph checkEmpty edgesOf recursiveDepth workFuel metadata uv
      (.selected parent completedPrefix rest edge residual caller queries parentHeight remainingCount parentBound)).1
      fragments reached saved after =
      match tail fragment reached saved returned with
      | .complete processed outputs finalCaller finalQueries =>
          .complete (.complete fragment reached saved returned :: processed) outputs finalCaller finalQueries
      | .stopped processed outputs current =>
          .stopped (.complete fragment reached saved returned :: processed) outputs current := by
```

lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean:13633

```lean
private theorem identity_actual_source_return_tail_run
    (graph : Graph Symbol Constraint) (checkEmpty : Bool)
    (edgesOf : Node → List (EdgeValue Symbol Constraint)) (recursiveDepth workFuel : Nat)
    (metadata : Metadata Unit) (uv : Nat) (entry current : IdentityActualSourcePoint bits)
    (rest : List (Node × List Suspended)) (edge : EdgeValue Symbol Constraint) (residual : Option Constraint) :
    IdentityActualSourceTask.run graph checkEmpty edgesOf recursiveDepth workFuel metadata uv
      (.tuple (identity_actual_source_return_point entry current edge residual) rest) =
    identity_actual_parent_tail checkEmpty edgesOf workFuel
      (identity_actual_frame_callbacks graph checkEmpty edgesOf recursiveDepth workFuel metadata uv entry.frame)
      entry.completed rest (.node edge.entry.key.symbol current.completed) current.caller current.queries
      (SelectedEdge.finish residual (.node edge.entry.key.symbol current.completed) current.before) := by
```

lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean:13661

```lean
private theorem identity_actual_source_selected_return_run
    (graph : Graph Symbol Constraint) (checkEmpty : Bool)
    (edgesOf : Node → List (EdgeValue Symbol Constraint)) (recursiveDepth workFuel : Nat)
    (metadata : Metadata Unit) (uv : Nat) (entry current : IdentityActualSourcePoint bits)
    (rest : List (Node × List Suspended)) (edge : EdgeValue Symbol Constraint) (residual : Option Constraint) :
    let frame := IdentityActualCallbackFrame.selected entry.frame entry.completed rest edge residual entry.caller entry.queries
      entry.height entry.count entry.bound
    let returned := identity_actual_source_return_point entry current edge residual
    let receipt := SelectedEdge.Result.complete (.node edge.entry.key.symbol current.completed)
      current.caller current.queries returned.before
    IdentityActualSourceTask.run graph checkEmpty edgesOf recursiveDepth workFuel metadata uv
      (.tuple {current with frame := frame} []) =
      match IdentityActualSourceTask.run graph checkEmpty edgesOf recursiveDepth workFuel metadata uv (.tuple returned rest) with
      | .complete processed outputs finalCaller finalQueries => .complete (receipt :: processed) outputs finalCaller finalQueries
      | .stopped processed outputs stopped => .stopped (receipt :: processed) outputs stopped := by
```

lean/MicroCFTA/SourcePruningEnumerationSharedBranching.lean:29

```lean
noncomputable def scan
    (visit : Edge → Caller width → Queries → Cached → Result Output Reason width)
    (before : Cached) : List Edge → Caller width → Queries → Result Output Reason width
  | [], caller, queries => .complete [] [] caller queries
  | edge :: rest, caller, queries =>
      match visit edge caller queries before with
      | .stopped processed outputs current => .stopped processed outputs current
      | .complete processed outputs reached saved =>
          match scan visit before rest reached saved with
          | .complete later remaining finalCaller finalQueries =>
              .complete (processed ++ later) (outputs ++ remaining) finalCaller finalQueries
          | .stopped later remaining current =>
              .stopped (processed ++ later) (outputs ++ remaining) current
```

lean/MicroCFTA/SourcePruningEnumerationSharedPreparedRecursive.lean:74

```lean
noncomputable def continueWith
    (recur : Metadata Typing → Caller width → Queries → Cached → Option Next → Result)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat)
    (callbackFuel : Nat) (metadata : Metadata Typing) (uv : Nat)
    (fragment : Fragment) (caller : Caller width) (queries : Queries) (before : Cached) : Result :=
  let raw := ExceptT.run (SourcePruningRecordTypes.recordTypes
    graph templates callbackFuel metadata uv (.inl fragment) before.core)
  match raw with
  | [.ok ((true, _updated), _observed)] => .complete [] caller queries
  | [.ok ((false, updated), observed)] =>
      let after := EnumerationExpandableIndex.frame observed before
      recur updated caller queries after (SourcePruningEnumerationRestart.decision stop order updated after)
  | _ => .stopped [] (.callback uv raw) (some (caller, queries))
```

lean/MicroCFTA/SourcePruningEnumerationSharedPreparedRecursiveChildPolicy.lean:39

```lean
noncomputable def resumeWithNarrow
    (child : Visitor)
    (narrow : Metadata Typing → Nat → Nat → Node →
      InternedConstructorTemplates.State Symbol Constraint →
      MergedSourceComparison.Result Symbol Constraint Node)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (workFuel : Nat) :
    Nat → Metadata Typing → Caller width → Queries → Cached → Option Next → Result
  | _fuel, metadata, caller, queries, before, none => .complete [⟨some metadata, before, caller, queries⟩] caller queries
  | _fuel, _metadata, caller, queries, before, some .done => .complete [⟨none, before, caller, queries⟩] caller queries
  | _fuel, _metadata, caller, queries, _before, some .stuck => .complete [] caller queries
  | 0, metadata, caller, queries, before, some (.expand uv) =>
      .stopped [] (.exhausted uv metadata before) (some (caller, queries))
  | fuel + 1, metadata, caller, queries, before, some (.expand uv) =>
      let observed := SourcePruningEnumerationSelectedStep.runPrefixWithNarrow narrow graph templates
        stop order metadata workFuel workFuel workFuel workFuel workFuel workFuel uv caller before queries
      match observed with
      | .parked _ (some _parked) (some []) => .complete [] caller queries
      | .parked _ (some parked) (some [.ok ((updated, next), core)]) =>
          resumeWithNarrow child narrow graph templates checkEmpty edgesOf stop order workFuel fuel
            updated caller queries (EnumerationExpandableIndex.frame core parked) next
      | .narrowed _ _ reached saved (some []) _ _ _ => .complete [] reached saved
      | .narrowed _ _ reached saved _ _ (some [.ok ((true, _updated), _core)]) _ =>
          .complete [] reached saved
      | .narrowed _ _ reached saved _ (some after) (some [.ok ((false, updated), _core)]) none =>
          let prepared := SourcePruningEnumerationSharedPreparedChildPolicy.runWithChild child
            (continueWith (resumeWithNarrow child narrow graph templates checkEmpty edgesOf stop order workFuel fuel)
              graph templates stop order workFuel updated uv)
            checkEmpty workFuel workFuel workFuel workFuel workFuel workFuel workFuel uv edgesOf reached after saved
          match prepared.2 with
          | none => .stopped [] (.preparation uv prepared.1)
              (some (SourcePruningEnumerationSharedPreparedContinuations.preparation_endpoint reached saved prepared.1))
          | some folded => finish uv folded
      | .narrowed _ _ reached saved _ _ _ _ => .stopped [] (.selected uv observed) (some (reached, saved))
      | _ => .stopped [] (.selected uv observed) (some (caller, queries))
```

lean/MicroCFTA/SourcePruningEnumerationRestart.lean:52

```lean
theorem selected (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing)
    (caller : SourceCurrentAllocatedPartialState.State width)
    (before : EnumerationExpandableIndex.Cached Symbol Constraint) (uv : Nat)
    (valid : SourcePruningEnumerationNativeBranchCompletion.CacheValid caller before)
    (safe : Safe before.core) (chosen : decision stop order metadata before = some (.expand uv)) :
    EnumerationDriver.Ready uv before.core ∧ EnumerationReferences.IncomingAvoid uv before.core ∧
      ∃ (handle : Nat) (scs : List Suspended)
        (value : InternedConstructorTemplates.Value Symbol Constraint),
        before.core.values[uv]? = some (.unenumerated (some handle) scs) ∧
        lookupNode caller.checked.native.machine.heap handle = some value ∧
        InternedProbeProvenance.Available caller.checked.native.machine.heap value ∧ value.free = [] ∧
        (!(MergedOrdinaryHeight.recursiveBoundary value && scs.isEmpty)) = true := by
```
