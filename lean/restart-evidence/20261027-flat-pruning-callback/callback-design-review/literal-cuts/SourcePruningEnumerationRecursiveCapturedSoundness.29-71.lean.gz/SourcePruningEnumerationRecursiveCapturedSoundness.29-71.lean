theorem completed_head_canonical
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (caller : Caller width) (before : Cached) (checkEmpty : Bool)
    (metadata : Metadata Typing) (memos : Memos) (uv handle : Nat) (scs : List Suspended)
    (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
    (edges : List (EdgeValue Symbol Constraint)) (depth : Nat) (free : List InternedBinderProtocol.Reference)
    (edge : EdgeValue Symbol Constraint)
    (packet : Packet formulas solver inventory caller memos metadata before)
    (ready : EnumerationDriver.Ready uv before.core)
    (stored : before.core.values[uv]? = some (.unenumerated (some handle) scs))
    (decoded : lookupNode caller.checked.native.machine.heap handle = some (.node parentEntry edges depth free))
    (selected : edge ∈ edges)
    (canonical : Canonical before.core)
    {r n p h k : Nat} {fragment : Fragment} {afterCaller : Caller width}
    {after : Cached} {savedQueries : Queries}
    (observed : SourcePruningEnumerationCapturedEdge.run checkEmpty r n p h k uv scs edge
      caller before memos.query = some (.complete fragment afterCaller savedQueries after)) :
    Canonical after.core := by
  obtain ⟨roots, paths, _storage, realized, counts, flags⟩ := packet.valid
  have pending := EnumerationReferences.pending_inputs before.core packet.pending uv (some handle) scs stored
  have actual := observed
  by_cases allowed : arityAllows edge.children.length scs = true
  · cases projected : SourcePruningEnumerationConstraint.project edge.entry.key.constraint with
    | none =>
        rw [SourcePruningEnumerationCapturedEdge.run,
          SourcePruningEnumerationSelectedEdge.unsupported checkEmpty r n p h k scs edge
            caller before memos.query allowed projected] at actual
        cases actual
    | some pair =>
        obtain ⟨tries, residual⟩ := pair
        exact SourcePruningEnumerationCapturedEdge.complete_canonical formulas solver inventory caller
          before checkEmpty uv handle scs parentEntry edges depth free edge roots memos packet.context ready
          stored decoded realized selected paths counts flags pending allowed tries residual projected canonical observed
  · have rejected : arityAllows edge.children.length scs = false := by
      cases value : arityAllows edge.children.length scs with
      | false => rfl
      | true => exact (allowed value).elim
    rw [SourcePruningEnumerationCapturedEdge.run,
      SourcePruningEnumerationSelectedEdge.arity_rejected checkEmpty r n p h k scs edge
        caller before memos.query rejected] at actual
    cases actual

