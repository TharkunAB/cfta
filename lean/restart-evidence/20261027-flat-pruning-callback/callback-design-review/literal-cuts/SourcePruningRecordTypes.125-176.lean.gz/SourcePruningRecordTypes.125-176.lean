theorem recordTypes_agrees (graph : Graph Symbol Guard) (templates : List (Template.Pattern Symbol))
    (leftFuel rightFuel : Nat) (metadata : Metadata Typing) (uv : Nat)
    (input : Sum (Fragment Symbol) Nat) (left right leftAfter rightAfter : State Symbol Guard)
    (leftResult rightResult : Bool × Metadata Typing) (frame : Frame left right)
    (total : UnionFind.Total left.representatives)
    (leftRead : Success (recordTypes graph templates leftFuel metadata uv input) left leftResult leftAfter)
    (rightRead : Success (recordTypes graph templates rightFuel metadata uv input) right rightResult rightAfter) :
    leftResult = rightResult ∧ Frame leftAfter rightAfter := by
  cases templates with
  | nil =>
      rw [recordTypes_empty] at leftRead rightRead
      let value := (false, {metadata with types := updatedTypes metadata uv input})
      obtain ⟨leftEq, leftSame⟩ := (success_pure value leftResult left leftAfter).mp leftRead
      obtain ⟨rightEq, rightSame⟩ := (success_pure value rightResult right rightAfter).mp rightRead
      exact ⟨leftEq.trans rightEq.symm, by simpa only [leftSame, rightSame] using frame⟩
  | cons first rest =>
      change Success (SourcePruningOracle.oracle graph (first :: rest) leftFuel metadata.pending uv input >>= fun observed =>
        pure (observed.1, {metadata with pending := observed.2, types := updatedTypes metadata uv input}))
        left leftResult leftAfter at leftRead
      change Success (SourcePruningOracle.oracle graph (first :: rest) rightFuel metadata.pending uv input >>= fun observed =>
        pure (observed.1, {metadata with pending := observed.2, types := updatedTypes metadata uv input}))
        right rightResult rightAfter at rightRead
      obtain ⟨leftObserved, leftMiddle, leftFirst, leftLast⟩ := (success_bind _ _ _ _ _).mp leftRead
      obtain ⟨rightObserved, rightMiddle, rightFirst, rightLast⟩ := (success_bind _ _ _ _ _).mp rightRead
      obtain ⟨sameObserved, middleFrame⟩ := SourcePruningOracle.oracle_agrees graph (first :: rest)
        leftFuel rightFuel metadata.pending uv input left right leftMiddle rightMiddle leftObserved rightObserved
        frame total leftFirst rightFirst
      obtain ⟨leftEq, leftSame⟩ := (success_pure
        (leftObserved.1, {metadata with pending := leftObserved.2, types := updatedTypes metadata uv input})
        leftResult leftMiddle leftAfter).mp leftLast
      obtain ⟨rightEq, rightSame⟩ := (success_pure
        (rightObserved.1, {metadata with pending := rightObserved.2, types := updatedTypes metadata uv input})
        rightResult rightMiddle rightAfter).mp rightLast
      refine ⟨?_, by simpa only [leftSame, rightSame] using middleFrame⟩
      rw [leftEq, rightEq, sameObserved]

/-- Additional fuel retains the exact callback result and complete final state. -/
theorem recordTypes_moreFuel (graph : Graph Symbol Guard) (templates : List (Template.Pattern Symbol))
    (fuel extra : Nat) (metadata : Metadata Typing) (uv : Nat) (input : Sum (Fragment Symbol) Nat) :
    Retains (recordTypes graph templates fuel metadata uv input)
      (recordTypes graph templates (fuel + extra) metadata uv input) := by
  cases templates with
  | nil =>
      rw [recordTypes_empty, recordTypes_empty]
      exact retains_refl _
  | cons first rest =>
      change Retains (SourcePruningOracle.oracle graph (first :: rest) fuel metadata.pending uv input >>= _)
        (SourcePruningOracle.oracle graph (first :: rest) (fuel + extra) metadata.pending uv input >>= _)
      exact retains_bind _ _ _ _
        (SourcePruningOracle.oracle_moreFuel graph (first :: rest) fuel extra metadata.pending uv input)
        (fun _ => retains_refl _)

