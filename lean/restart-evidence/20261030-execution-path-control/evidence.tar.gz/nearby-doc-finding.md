# Existing module comment

SourcePruningEnumerationPathSelectedRaw still says that its source-only draft has not been compiled.
The protected production module has passed prior builds and strict checks.
This is a stale comment, not a new proof or Haskell defect.
Its source bytes stay protected in this phase.
