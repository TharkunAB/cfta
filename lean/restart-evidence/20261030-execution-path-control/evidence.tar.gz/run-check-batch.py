import json, os, subprocess, sys
from pathlib import Path
r = Path('/tmp/mcfta-execution-path-control-20261030')
spec = r / sys.argv[1]
commands = json.loads(spec.read_text())
for args in commands:
    command = ['/home/tritlo/Code/heavy-management/bin/capped', '--mem', '4G', '--time', '5m', 'python3', str(r / 'check-installed.py'), *args]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (r / (args[1] + '-outer.log')).write_bytes(result.stdout)
    print(result.stdout.decode(), end='', flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
