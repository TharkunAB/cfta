# Execution predicate review

Status: source-only semantic acceptance of the two exact approved bodies. No required case in the frozen operation specification is omitted. This assessment is not a Lean execution-invariant theorem, a compiler result, or an assertion of sufficient recursive depth.

## Exact sources and specification

The reviewed draft is `/tmp/mcfta-execution-path-control-20261030/execution-paths-v2.lean`, 276 lines, 19,032 bytes, SHA256 `9402280559c1a7f463c31bbc0cd7a9dcc13a683e6e3106818db703ae0326b94f`.

The reviewed installed data module is `lean/MicroCFTA/SourcePruningEnumerationExecutionPathData.lean`, 102 lines, 5,884 bytes, SHA256 `db39b16c885d60ecca4a600763acef2c64447778dd6fec51f13cc88d0cdc2a28`.

The exact frozen specification has SHA256 `d9a75e11661522dff3c3b28afd071d21883b13839306a47cecf3994c710c0bee`. Its provenance report has SHA256 `ed0c26bb7347279391fdcbe24c24442f9cd8dd7ecdcbffa3426c2057b20cc55b`. Both copies match the frozen bundle's pins, SHA256 `c7c275f0f2163c8f0402d7303620a39782271e20049fbc53a2a6531f3801e4a4`. Historical compiler/Audit/push counts in that report are prior reported context. This owner did not rerun or promote them to current validation.

The review covers sixteen definitions and four small theorem bodies. PUBLIC-CONTRACTS.json retains all twenty complete headers and original implicit-variable/typeclass contexts. CONTRACT-MAP.json records fifteen operation checks and exact source locations.

## Ordered recursive branches

Both Resume predicates require initial StatePaths and OutcomePaths of the literal current worker. They add selected-prefix paths only for a positive-depth expansion. The local match order agrees with both current worker copies: empty parked restart; singleton parked restart; empty narrowed action; singleton true Right callback; exact singleton false Right callback with retained candidate and ordinary=None; unsupported remainder. The fallback cases do not introduce recursive work. Their retained selected data remains covered by SelectedPrefixPaths and OutcomePaths.

The parked singleton uses its returned decision. It keeps the same caller and query state, updates metadata, and uses `frame core parked`. It reduces recursive capacity by one. It does not recompute a restart decision at an unrelated cache.

The false Right branch enters its stage at the retained `after` cache and reached native caller/saved queries. It does not use the ignored displayed Right Core as that stage input. SelectedPrefixPaths covers that displayed Core separately. The actual hook captures updated Right metadata and the outer selected uv.

The scan target and the outer selected uv remain distinct parameters. SiblingPaths runs the scan at the returned target and records through LeftPaths at recordUV. The stage supplies recordUV=outer uv. No target equality is assumed.

## Actual Left calls and sibling hooks

LeftPaths inspects the literal recordTypes call at the captured metadata/uv and head cache. RawPaths covers every successful raw row, including rows that cause a true empty-output return and malformed multirow observations. Its OutcomePaths covers the literal hook. Only the exact singleton-false equation produces a nested Resume obligation. That obligation uses updated Left metadata, the actual head caller and queries, the frame of the actual observed Core against the head cache, and the configured restart decision.

LeftPaths takes a generic nextPaths and hook so it can serve both workers. It does not by itself assert that an arbitrary supplied hook is a particular continueWith function. In the actual Resume definitions, the hook is the exact worker continueWith and nextPaths is the same worker's smaller-depth Resume predicate. Thus the relevant instantiation has the required literal-call alignment.

The frozen specification explicitly asks for StatePaths at the false callback's framed input. In the concrete worker instantiation, smaller-depth Resume starts with that StatePaths conjunct. RawPaths of the singleton successful observation also supplies paths at its observed Core. The generic helper's packaging is therefore not a missing operation case.

SiblingPaths covers the actual complete fold before finish and quantifies over every actual HookInvocation. It adds no output-membership or processed-membership condition. Empty-output hooks are included. A current stopped hook is included even when its receipt is outside the processed prefix. The supplied frozen specification establishes that Invocation is the actual call relation. This review reuses that relation; it does not independently reacquire its entire implementation.

Later siblings keep the captured metadata/cache and follow Invocation's actual native endpoints. The predicates do not replace the captured input with a previous output cache or require arbitrary unrelated continuation inputs.

## Native and prepared stage cases

NativeStage retains the entire actual entry raw list and every actual returned fold. It requests sibling details only for the same singleton ordinary-node, nonterminal case used by NativeOrdinaryContinuations.run. Terminal buckets and unsupported/malformed entry shapes cause no native ordinary scan. Their raw rows remain covered.

PreparedStage retains the exact preparation raw list from the actual SelectedContinuations result. It follows the actual done-value/singleton-entry branch. It advances the caller with that exact returned heap, frames entered against the captured before, and uses the returned prepared value. It does not replace the value with the decoded old native handle.

The terminal-bucket test precedes the node test. Thus a terminal bucket takes OpaquePaths even if the prepared value is a node. A nonterminal node takes SiblingPaths. Every other prepared value takes OpaquePaths. These are the two opaque source branches. Unsupported preparation results retain raw paths and do not invent a callback.

OpaquePaths inspects the exact SelectedOpaqueDispatch receipt and the actual ReceiptContinuation fold. It covers every optional receipt. For exactly a complete receipt, it requires LeftPaths at the actual receipt's fragment/caller/queries/cache. This clause is independent of the ordinary list Invocation relation and covers opaque callbacks that emit no outputs or stop.

## Retained results and failures

FullReceiptPaths adds stopped ObservationPaths to the existing ReceiptPaths. It covers the retained raw observation without asserting native heap validity at a stored fault heap. Both Failure predicates inspect every failure constructor and recursively inspect a nested continuation reason. Alternatives cover all processed receipts and their current optional receipt or continuation receipt.

FoldPaths retains every processed receipt, every output cache, and the current stop's receipt/reason. A complete fold with no outputs still retains its processed obligations. OutcomePaths alone would lose these fields because finish discards a complete processed list. The actual Sibling/Native/Prepared/Opaque predicates therefore retain FoldPaths before finish. The two finish laws only project the corresponding outcome statement; they do not recover erased fold data.

Zero recursive depth has the exact input/output/exhaustion cases. The two zero laws need only initial StatePaths. Native and Prepared aliases use the literal initial Restart.decision from their workers' run definitions.

## Remaining proof and scope

No positive-depth execution-invariant theorem appears in these two sources. The outstanding theorem must derive these predicates through the actual recursive and sibling calls from genuine current resource admission and the computed final forecast. It must transport the SAME P at the actual smaller-depth inputs and reached native endpoints. It must not request a future whole execution predicate, future trace, Complete, callback certificate, or output-membership hypothesis as an added public supplier. Existing smaller-depth finite_complete may be used internally as in the frozen specification.

This source acceptance concerns the specified retained Core/raw/receipt/hook operations. It does not recover a discarded observation history, assert Context at native fault heaps, prove guard-heap validity, or establish an unrestricted statement about every transient state inside imported helpers. Existing RawPaths, SelectedPrefixPaths, ObservationPaths, ReceiptPaths and Invocation retain their pinned specification meanings. Their proof bodies are outside the two new acquisitions.

Even a completed eventual theorem for these predicates would remain fixed-D and could retain exhaustion. It would not supply an original sufficient recursive capacity, bound native handle renewal, or prove public Haskell correspondence.

No Haskell source was read or changed. No Haskell repair or runtime defect was established. No FINDINGS entry is needed from this review.

## Provenance, source budget, and incidents

Only the two approved new whole bodies were acquired. Four exact frozen worker scopes were reused: complete Native Recursive 1–128/128; complete Prepared Recursive 1–120/120; SelectedContinuations 24–63/234; NativeOrdinaryContinuations 16–35/100. Every reused full source SHA and copied slice was checked against current source and the immutable frozen manifest before use. No third new whole or near-whole source was acquired by combined snippets.

initial-acquisitions.json records the two approved source bodies and two complete frozen documents. reuse-ledger.json records the four reused source scopes and their provenance. READ-DISPLAYS.json records complete recovery displays and the specification EOF clamp. source-unions.json records cumulative new/reused ranges. Final source-copy verification checks hashes and bytes; it is not a Lean proof check.

The first combined display was truncated, then hit a guessed uppercase PINS.json filename that does not exist. The four copied inputs were retained and verified. A later batched wrapper truncated metadata output. All complete source/specification/provenance displays needed for this review were recovered. INCIDENTS.md retains those events. There was no compiler failure, Lean proof search, execution experiment, or candidate mutation.

No compiler/evaluator/native/Git/network/board command ran. No production file or prior frozen bundle was changed. All writes remained in this owned directory. The final marker and manifest seal every payload.
