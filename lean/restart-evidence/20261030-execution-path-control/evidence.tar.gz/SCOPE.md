# Original forecast and whole-execution paths

The preceding turn made verified progress and published all work.
The full CFTA goal remains active.
Retain original public inputs, sufficient original resources for intended finite-prefix coverage, exact configured order and stops, the optimized interned core, both recursive workers, public Prefix/table/count/checkpoint adapters, and Haskell correspondence.
Retain older constructor, equality, node-count, size, rank, and unrank work.

First prove that both computed recursive forecasts stay inside one fixed original closed guard alphabet.
This discharges their projected-path premise from the original finite carrier.
It does not bound raw multiplicities, native handles, or original sufficient recursion depth.
Then implement concrete execution-path predicates for both actual workers.
They must include discarded processed receipts, actual raw/failure rows, empty-output hooks, direct prepared opaque callbacks, and exact smaller-depth calls.
The full eventual execution-path induction remains a separate proof task.
Keep the existing resource theorem and every old clause.
Do not add a future trace, model, Complete result, or callback supplier to the original input contract.

Root alone owns all production, compiler, evaluator, native, Git, network, and board work.
The callback review owns callback-path-review only.
It may acquire only two new whole or near-whole bodies: Native and Prepared finite callback resources.
The independent predicate review owns execution-predicate-review only.
Its two approved whole bodies are the new execution-predicate draft and installed path-data module.
Both reviews must verify frozen reuses and retain every acquisition, proposal, and incident before freezing.

Compiler checks remain serial under Lean 4.34.1, 4 GiB memory maximum/high, zero swap, and a five-minute cap.
The runner, compiler wrapper, and current-source verifier differ from the prior phase only in the evidence-area path.
The public builder also accepts noncomputable definitions. It would otherwise omit nine new definition readbacks.
The initial builder and exact parser change remain in public-builder-parser-fix.json.
The launch environment uses the existing verified uid-1000 runtime socket.
No queue, service, heartbeat, or cap setting changes.
No Haskell command or fix is planned; record any established finding in root FINDINGS.
All 530 prior protected, 4729 Lean, and 835 native sources match their initial bytes.
