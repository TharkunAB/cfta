from pathlib import Path
import json,hashlib
owner=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
acq=json.loads((owner/'acquisitions.json').read_text());loc=json.loads((owner/'locators.json').read_text());reuse=json.loads((owner/'reuse-ledger.json').read_text())
expected={'SourcePruningEnumerationFiniteCallbackResources.lean','SourcePruningEnumerationPreparedFiniteCallbackResources.lean'}
assert sum(r['whole'] for r in acq)==2 and {Path(r['source_path']).name for r in acq if r['whole']}==expected
scopes={}
for kind,records in [('new_cut',acq),('locator',loc),('reused',reuse)]:
 for r in records:
  src=Path(r['source_path']);full=src.read_bytes();b=(owner/r['copy']).read_bytes()
  assert len(full)==r['source_bytes'] and sha(full)==r['source_sha256']
  assert len(b)==r['copy_bytes'] and sha(b)==r['copy_sha256']
  if kind=='locator':
   indices=r['actual_lines'];text=full.decode().splitlines(keepends=True);assert b==''.join(f'{i}:{text[i-1]}' for i in indices).encode()
  else:
   indices=list(range(r['actual_start'],r['actual_end']+1));assert b==b''.join(full.splitlines(keepends=True)[r['actual_start']-1:r['actual_end']])
  if kind=='reused':
   base=Path(r['frozen_bundle']);assert sha((base/'pins.json').read_bytes())==r['frozen_manifest_sha256'];assert (base/r['frozen_copy']).read_bytes()==b
  q=scopes.setdefault(str(src),{'source_bytes':len(full),'source_lines':len(full.splitlines()),'source_sha256':sha(full),'new_cut':set(),'locator':set(),'reused':set()});q[kind].update(indices)
result=[]
for src,q in sorted(scopes.items()):
 new=q['new_cut']|q['locator'];alllines=new|q['reused']
 result.append({'source_path':src,**{k:v for k,v in q.items() if not isinstance(v,set)},'new_cut_lines':sorted(q['new_cut']),'locator_lines':sorted(q['locator']),'reused_lines':sorted(q['reused']),'new_union_lines':sorted(new),'all_union_lines':sorted(alllines),'new_fraction':len(new)/q['source_lines'],'all_fraction':len(alllines)/q['source_lines']})
(owner/'scope-unions.json').write_text(json.dumps(result,indent=2)+'\n')
for r in json.loads((owner/'prior-spec-reuse.json').read_text()):
 b=(owner/r['copy']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'] and Path(r['source']).read_bytes()==b
 assert sha((Path(r['source']).parent/'pins.json').read_bytes())==r['frozen_manifest_sha256']
source=(owner/'ExecutionCallbackBridge-v1-UNCOMPILED.lean').read_text();declarations=[]
for variant,fn in [('Native','001-SourcePruningEnumerationFiniteCallbackResources.lean'),('Prepared','002-SourcePruningEnumerationPreparedFiniteCallbackResources.lean')]:
 old=(owner/'cuts'/fn).read_text();a=old.index('theorem callback_finite_complete_resources\n');b=old.index(' := by\n',a);oldHeader=old[a:b]
 start=source.index('namespace MicroCFTA.SourcePruningEnumerationExecutionCallbackBridge.'+variant);a=source.index('theorem callback_finite_complete_resources_with_execution_ih\n',start);b=source.index(' := by\n',a);header=source[a:b]
 p=header.index('\n    (P : EqualityTrie.Path');ret=header.index('    ∃ (fuel : Nat)');tail=header.index(' ∧\n      StatePaths P (EnumerationExpandableIndex.frame after before).core ∧')
 recovered=(header[:p]+' :\n'+header[ret:tail]).replace('theorem callback_finite_complete_resources_with_execution_ih\n','theorem callback_finite_complete_resources\n',1)
 assert recovered==oldHeader
 declarations.append({'variant':variant,'old_header_sha256':sha(oldHeader.encode()),'new_header_sha256':sha(header.encode()),'recovered_header_sha256':sha(recovered.encode()),'exact_header_recovery':True,'old_typeclass_context':'variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]','status':'UNCOMPILED internal helper; Root must discharge IH/Complete in original-input theorem'})
(owner/'header-recovery.json').write_text(json.dumps(declarations,indent=2)+'\n')
versions=[]
for p in sorted(owner.glob('*.lean')):
 b=p.read_bytes();versions.append({'path':p.name,'bytes':len(b),'lines':len(b.splitlines()),'sha256':sha(b),'status':'UNCOMPILED; no owner compiler run'})
(owner/'versions.json').write_text(json.dumps(versions,indent=2)+'\n')
print('Validated cuts',len(acq),'locators',len(loc),'frozen sources',len(reuse),'source identities',len(scopes),'prior documents',3)
print('New whole body count',sum(r['whole'] for r in acq))
for r in result:
 if r['new_fraction']:print(Path(r['source_path']).name,len(r['new_union_lines']),r['source_lines'])
print('Both complete old callback headers recover exactly')
