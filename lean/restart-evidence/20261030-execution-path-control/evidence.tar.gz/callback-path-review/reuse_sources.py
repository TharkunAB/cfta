from pathlib import Path
import json,hashlib
owner=Path(__file__).parent;(owner/'reused').mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
repo=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA');records=[]
items=[('/tmp/mcfta-finite-prefix-control-20261030/native-path-review','sources/reused-SourcePruningEnumerationPathRecordingValues.lean','SourcePruningEnumerationPathRecordingValues',1,178),('/tmp/mcfta-traversal-path-control-20261030/whole-worker-path-review','cuts/001-SourcePruningEnumerationFiniteSiblingResources.lean','SourcePruningEnumerationFiniteSiblingResources',1,226),('/tmp/mcfta-traversal-path-control-20261030/whole-worker-path-review','cuts/002-SourcePruningEnumerationPreparedFiniteSiblingResources.lean','SourcePruningEnumerationPreparedFiniteSiblingResources',1,229)]
for bundle,fn,module,first,last in items:
 base=Path(bundle);b=(base/fn).read_bytes();pins=(base/'pins.json').read_bytes();r=next(x for x in json.loads(pins) if x['path']==fn);assert r['sha256']==sha(b) and r['bytes']==len(b)
 source=repo/(module+'.lean');full=source.read_bytes();assert b==b''.join(full.splitlines(keepends=True)[first-1:last])
 dest=owner/'reused'/(module+'.lean');dest.write_bytes(b)
 records.append({'source_path':str(source),'source_bytes':len(full),'source_lines':len(full.splitlines()),'source_sha256':sha(full),'actual_start':first,'actual_end':last,'requested_start':first,'requested_end':last,'copy':str(dest.relative_to(owner)),'copy_bytes':len(b),'copy_sha256':sha(b),'frozen_bundle':bundle,'frozen_copy':fn,'frozen_manifest_sha256':sha(pins),'whole':first==1 and last==len(full.splitlines()),'new_whole':False})
(owner/'reuse-ledger.json').write_text(json.dumps(records,indent=2)+'\n')
print('Verified',len(records),'frozen full source copies')
print(''.join((owner/'reused/SourcePruningEnumerationPathRecordingValues.lean').read_text().splitlines(keepends=True)[145:178]))
