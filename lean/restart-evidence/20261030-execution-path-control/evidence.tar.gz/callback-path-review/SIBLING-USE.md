# Exact sibling use of the callback bridge

Status: source-only plan. Both Lean drafts are UNCOMPILED. No whole-worker theorem is claimed.

Fix capacity n and one of the two reservation families R. Let the captured sibling schedule have original seed s, captured mass c, inherited bound h, and total count k. At index i<k, use the existing planned seed:

```text
s_i = R.stage n s c h i
childSeed = RecursiveReservation.afterHead s_i h
childCeiling = RecursiveReservation.massCeil s_i c h
R.final n childSeed childCeiling = R.step n s_i c h
```

The new projection helper proves inner projection coverage from the actual computed outer stage. It takes i<k and ProjectionPaths (R.stage n s c h k).1 P. It derives the inclusion through R.stage_succ_right and R.count_mono. No separate manual inclusion is an input.

For the original positive-depth final forecast, Native starts from ExpansionAdmission.narrowSeed s and Prepared starts from PreparedReservation.preparedSeed s. Both final recurrences set c=h=ceiling. The final projection helpers use precisely those definitions. They do not identify the two starting seeds.

## Head and callback inputs

Reuse the existing stable head producer at s_i. Retain its Post, full memos, head caller, complete head cache, FragmentBound, Fits, known guard Heap, and cache mass facts. HeadReserved.callback supplies the exact child reservation at childSeed/childCeiling.

Use the actual callback input Packet already constructed by the old head/callback proof. The public sibling return exposes admitted/pending/history/cache-bound certificates; it must not be treated as a Packet projection without the existing reconstruction. A new head path companion can replace the old internal callback-helper call with this bridge, or reuse the existing completed-head receipt adapter. Do not add a caller-supplied future Packet. This task did not acquire the complete head-resource bodies.

For a completed head receipt, the new paired callback helper takes:

- metadata: the captured callback metadata used by this sibling scan;
- uv: the selected callback variable used by the literal continueWith closure;
- fragment, caller, memos.query and before: the actual completed head receipt inputs;
- seed=childSeed and ceiling=childCeiling;
- before StatePaths, from the existing receipt/Invocation path producer;
- computed child-forecast projections, from the new stage/final projection helper;
- the existing smaller-depth Complete, internally from finite_complete;
- the smaller-depth eventual execution-path IH.

Instantiate the helper's generic Paths as the concrete Native or Prepared execution predicate at capacity n and the fixed original configuration/P. The outer suffix-closure fact is already captured when constructing that IH. The generic bridge itself needs no additional suffix-closure parameter.

## Exact returned state

The helper keeps the same recording witness `(result, after)` and derives:

```text
Packet ... result.2 (frame after before)
StatePaths P (frame after before).core
suspendedBound (frame after before).core <= ceiling
```

The first fact comes from the old callback resource result. The second uses the old result's ACTUAL recording Success with the checked recordTypes_paths theorem. The third uses the old Frame.values equality exactly as the original resource proof does. Recording leaves seed and ceiling unchanged.

The helper applies the IH at exactly that cache and result.2. It preserves the old full caller/memos and uses the same seed, ceiling, Fits, known Heap, selection clauses, and reservation.

It appends:

```text
forall extra, result.1=false ->
  Paths (newFuel+extra) result.2 caller memos.query (frame after before)
```

The old generic continueWith equation is also retained. Instantiate its recur with the literal resume at capacity n and work newFuel+extra. For result.1=false, its right side is the exact recursive call with this framed cache and updated metadata, with Restart.decision using the original configured stop/order. There is no detached future cache witness.

If another actual singleton-false equation names `(false, updated)` and `observed`, compare it with the retained singleton equation at the SAME work amount. Inject the list, Except.ok, and pair equalities. This yields result=(false,updated) and after=observed. Rewrite both the Packet and the path conclusion with those equalities. No output-membership assumption is needed.

If result.1=true, the path implication is vacuous. The helper does not request or assert an actual recursive call for that branch.

## Bound and endpoint alignment

Let oldFuel be the complete old callback resource witness and pathFuel be the smaller path IH witness. The new common fuel is oldFuel+pathFuel.

The recording Success, singleton equation, generic continueWith equation, and actual callback-to-outcome equation all come from the old witness at extra=pathFuel+extra. The smaller execution path comes from its IH at extra=oldFuel+extra. Addition aligns both amounts.

Keep the old outcome and its complete OutcomeResources. If an existing head producer has a different existential callback witness, move to a common larger work amount. Both stable equations describe the SAME literal callback. Equality of those actual results identifies their complete/stopped constructors and native endpoints before the suffix path induction runs.

The already frozen sibling proofs use the resulting hook Post/Packet/Fits/known facts for their tail. They keep the captured enumeration cache and metadata while threading the actual native endpoint. Add the new execution path fact at that same point. Do not feed a sibling output cache to the suffix.

For a stopped recursive callback, the current receipt is outside processed. Retain its complete head receipt paths and the nested execution/failure paths from the IH. For rejected or continuable stopped receipts, the callback is not invoked; keep the existing advance cases and their local observation paths.

This is an internal composition plan. The eventual original-input theorem must discharge Complete and the path IH. It must not expose either as a new original-input gate.
