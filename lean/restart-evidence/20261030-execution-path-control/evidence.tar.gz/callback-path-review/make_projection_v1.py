from pathlib import Path
import hashlib
owner=Path(__file__).parent
parts=['''import MicroCFTA.SourcePruningEnumerationFiniteReservation
import MicroCFTA.SourcePruningEnumerationPreparedReservation
import MicroCFTA.SourcePruningEnumerationPathTransport

/-!
# Computed callback forecast projections

UNCOMPILED source-only draft. The callback uses the exact smaller forecast.
The outer stage or final forecast supplies its projection paths.
-/
namespace MicroCFTA.SourcePruningEnumerationExecutionCallbackProjection
open SourcePruningEnumerationIncomingReservation (Seed)
open SourcePruningEnumerationPathTransport (ProjectionPaths)
local notation "afterHead" => SourcePruningEnumerationRecursiveReservation.afterHead
local notation "massCeil" => SourcePruningEnumerationRecursiveReservation.massCeil
''']
for variant,reservation,first in [('Native','SourcePruningEnumerationFiniteReservation','SourcePruningEnumerationExpansionAdmission.narrowSeed'),('Prepared','SourcePruningEnumerationPreparedReservation','SourcePruningEnumerationPreparedReservation.preparedSeed')]:
 parts.append('''
namespace VARIANT

/-- The original finite sibling forecast supplies the exact callback projection. -/
theorem callback_projection_of_stage
    {P : EqualityTrie.Path → Prop} (depth : Nat) (seed : Seed)
    (capturedMass inherited index count : Nat) (inside : index < count)
    (projected : ProjectionPaths (RESERVATION.stage depth seed capturedMass inherited count).1 P) :
    ProjectionPaths
      (RESERVATION.final depth
        (afterHead (RESERVATION.stage depth seed capturedMass inherited index) inherited)
        (massCeil (RESERVATION.stage depth seed capturedMass inherited index) capturedMass inherited)).1 P := by
  intro guard member
  have stepMember : guard ∈
      (RESERVATION.step depth
        (RESERVATION.stage depth seed capturedMass inherited index) capturedMass inherited).1 := by
    simpa only [RESERVATION.step] using member
  have stageMember : guard ∈
      (RESERVATION.stage depth seed capturedMass inherited (index + 1)).1 := by
    rw [RESERVATION.stage_succ_right]
    exact stepMember
  have counts : index + 1 ≤ count := by omega
  exact projected guard ((RESERVATION.count_mono depth seed capturedMass inherited counts).2 stageMember)

/-- The original positive-depth forecast supplies each actual callback projection. -/
theorem callback_projection_of_final
    {P : EqualityTrie.Path → Prop} (depth : Nat) (seed : Seed) (ceiling index : Nat)
    (inside : index < RESERVATION.rows seed)
    (projected : ProjectionPaths (RESERVATION.final (depth + 1) seed ceiling).1 P) :
    ProjectionPaths
      (RESERVATION.final depth
        (afterHead (RESERVATION.stage depth (FIRST seed) ceiling ceiling index) ceiling)
        (massCeil (RESERVATION.stage depth (FIRST seed) ceiling ceiling index) ceiling ceiling)).1 P := by
  have stageProjected : ProjectionPaths
      (RESERVATION.stage depth (FIRST seed) ceiling ceiling (RESERVATION.rows seed)).1 P := by
    simpa only [RESERVATION.final_succ] using projected
  exact callback_projection_of_stage depth (FIRST seed) ceiling ceiling index
    (RESERVATION.rows seed) inside stageProjected

end VARIANT
'''.replace('VARIANT',variant).replace('RESERVATION',reservation).replace('FIRST',first))
parts.append('\nend MicroCFTA.SourcePruningEnumerationExecutionCallbackProjection\n')
p=owner/'ExecutionCallbackProjection-v1-UNCOMPILED.lean';p.write_text(''.join(parts));p.chmod(0o444)
b=p.read_bytes();print(p,len(b),len(b.splitlines()),hashlib.sha256(b).hexdigest())
