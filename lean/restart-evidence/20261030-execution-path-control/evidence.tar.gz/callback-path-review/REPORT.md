# Actual callback resource and execution-path bridge

Status: completed bounded source-only task. Both supplied Lean drafts are UNCOMPILED. This owner ran no Lean compiler, evaluator, native program, Git, network, or board command. The owner changed no production or Haskell source. The full goal stays active.

Root supplied base `2c32ebc4bacbee067ab55a7470c14c6ab0831e52` and unchanged main `bd5a406a6`. This owner verified current source hashes, not Git state.

## Deliverables

1. ExecutionCallbackBridge-v1-UNCOMPILED.lean: 17857 bytes, 267 lines, SHA256 755fe961b16b0dd113b9b79331161f8a43e7532f7c1438c2d361fe34b8b02280.
2. ExecutionCallbackProjection-v1-UNCOMPILED.lean: 6572 bytes, 97 lines, SHA256 4715fd8a3e4989bd871b4c7541a6726af6054dc3667f245c0e1b6c05c908f2c0.
3. SIBLING-USE.md: exact current seed, callback, bound, and endpoint uses in both already frozen sibling proofs.

The first draft exposes two internal helpers:

```text
SourcePruningEnumerationExecutionCallbackBridge.Native.callback_finite_complete_resources_with_execution_ih
SourcePruningEnumerationExecutionCallbackBridge.Prepared.callback_finite_complete_resources_with_execution_ih
```

They wrap the existing actual callback resource producer. They retain every old input and witness clause, including Packet, RenderStable, Frame, updated metadata fields, every larger-work recording Success/singleton equation, the generic continueWith equation, the actual stable callback equation, and the entire OutcomeResources conjunct. They append actual framed StatePaths and the smaller eventual execution property in the singleton-false branch.

The second draft supplies Native and Prepared versions of callback_projection_of_stage and callback_projection_of_final. They derive the exact smaller callback forecast projections from the computed outer forecast. They add no manual future-inclusion premise.

## What is new

The old callback resource result already supplies the exact returned Core, updated metadata, and framed Packet. It also retains the original mass ceiling and seed. The checked recording path theorem already preserves stored paths. The missing local composition is to pass BOTH facts into the smaller-depth eventual execution IH at the same actual input.

The bridge obtains `(fuel,result,after,outcome)` from the existing producer. It uses `(callback 0).1` with PathRecordingValues.recordTypes_paths to derive StatePaths P after. Frame gives the exact cache core. The old Frame.values equality derives the same mass bound as the original resource proof.

For result.1=false, the internal IH receives:

```text
inventory caller memos (frame after before) result.2 seed ceiling
returnedPacket bounded known selectionMembers selectionLength
massAfter reserved framedPaths computedProjectionPaths
```

Nothing is inferred from an emitted output or a satisfying model. The new input is the actual singleton recording witness already retained by the old producer.

The new fuel is oldFuel+pathFuel. Every old recording and callback equation is shifted by pathFuel. The path IH is shifted by oldFuel. The old outcome and all its resources remain unchanged. For result.1=true the additional implication is vacuous; the source does not execute the recursive call.

The generic Paths argument is an INTERNAL induction abstraction. It prevents a dependency cycle with the concrete ExecutionPaths module Root is implementing. It is not an original-input theorem or a new original-input trace supplier. Root must instantiate it with the concrete Native/Prepared predicate and discharge the IH from the capacity induction. The old Complete premise also remains internal, with finite_complete supplying it. Do not advertise the helper alone as a closed original-input result.

## Exact projection derivation

Both current reservation definitions use:

```text
step depth seed capturedMass inherited =
  final depth (RecursiveReservation.afterHead seed inherited)
    (RecursiveReservation.massCeil seed capturedMass inherited)
```

At sibling index i<k, childSeed/childCeiling are computed from `stage depth seed capturedMass inherited i`. The helper rewrites that child's final forecast as step. stage_succ_right identifies it with stage(i+1). count_mono includes it in stage(k). ProjectionPaths then transports along the derived guard-list inclusion.

For the original final forecast, final_succ identifies the full stage. Native starts at ExpansionAdmission.narrowSeed seed. Prepared starts at PreparedReservation.preparedSeed seed. The two final helpers preserve this distinction. No public model, validity, future worker, future Packet, or forecast-inclusion supplier is added.

Root reported that its new closed-forecast upper-bound laws already discharge projections from the same original carrier, and that concrete ExecutionPaths passed its first strict probe. Those are Root-reported status facts. This owner did not inspect those new proof bodies or claim their production checks here.

## Scope and header preservation

The generator checked exact recovery of both old explicit callback headers: delete only the new P/path/projection/Paths/IH inputs and appended path conjuncts, restore the old theorem name, and the old header is literal. Both helpers keep all three original equality instances. They add no semantic-model or cache-validity premise. Their namespaces identify them as internal composition helpers.

There are no proof placeholders, custom axioms, native_decide calls, or new linter suppressions in either draft. Complete Lean proof bodies are supplied, but they have NOT been checked. Namespace elaboration, simplification, typeclass inference, and strict-linter acceptance remain for Root's probe. No compiler success is implied by this report.

## Acquisitions and reuse

Exactly TWO new whole production bodies were acquired, both explicitly named by Root before acquisition:

- SourcePruningEnumerationFiniteCallbackResources, 1-118/118, 7655 bytes, SHA256 a07a771a90fd54d15dfd900071cc25ebd52e7a6bfbafb140ba0962924e823746.
- SourcePruningEnumerationPreparedFiniteCallbackResources, 1-136/136, 8869 bytes, SHA256 04bb5fd54bdc7a7b1339ba486e634ee6a36e7103726ca1bb5c670c143a245405.

Both complete displays were read without truncation. All other new production reads were bounded definition/theorem cuts and sparse locators in the two reservation modules, plus the eight-line ProjectionPaths definition. Per-source unions are in scope-unions.json. No third whole or near-whole body was reconstructed through cuts.

Three exact full frozen sources were reused after manifest checks and equality with CURRENT source bytes: PathRecordingValues and the two sibling resource proofs. The prior frozen OPERATIONS, PUBLIC-TARGETS, and REPORT were copied by exact manifest pins. They remain immutable. Reuse records retain original bundle/copy paths, manifest SHA, current source bytes/lines/SHA, and exact copied bytes/SHA.

Validation retained 12 new cuts, three locator scopes, three full frozen source reuses, three exact prior-document reuses, and eight current production source identities. Outside the two approved whole bodies, new unions are Native reservation 140/342 lines, Prepared reservation 126/337 lines, and PathTransport 10/240 lines.

Every new acquisition records requested/actual endpoints and both full-source and copy identities. All source mutation operations stayed in this new owner directory. All old/restored/frozen trees stayed read-only. No source display was truncated. There was no acquisition race, failed compiler run, or overwritten version in this task. A bounded Native reservation cut initially ended at the stage_succ_right header; the later 99-104 cut retains its complete equation and proof. Both scopes remain explicit.

## Remaining boundary

Root must probe both immutable drafts and integrate any accepted proofs. These local helpers do not prove the whole fixed-D execution-path induction. They supply its exact singleton-false callback composition and computed forecast transport. The original-input result must still close every induction premise.

Even a completed fixed-D execution-path induction permits recursive exhaustion. Sufficient original capacity for the required policy-permitted finite ordered prefix, native handle renewal, neutral progress, raw multiplicity, public API adapters, and Haskell correspondence remain outside this local bridge.

No Haskell source was read or repaired. No new Haskell defect is established. Root keeps FINDINGS ownership.
