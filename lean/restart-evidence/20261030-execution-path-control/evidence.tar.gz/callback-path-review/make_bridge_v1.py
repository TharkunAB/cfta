from pathlib import Path
import hashlib
owner=Path(__file__).parent
parts=['''import MicroCFTA.SourcePruningEnumerationFiniteCallbackResources
import MicroCFTA.SourcePruningEnumerationPreparedFiniteCallbackResources
import MicroCFTA.SourcePruningEnumerationPathRecordingValues

/-!
# Actual callback resources and the smaller execution-path induction

UNCOMPILED source-only draft. This is an internal induction helper.
The original-input theorem must discharge both induction premises.
-/
''']
for variant,module,fn,reservation in [('Native','SourcePruningEnumerationRecursive','001-SourcePruningEnumerationFiniteCallbackResources.lean','SourcePruningEnumerationFiniteReservation'),('Prepared','SourcePruningEnumerationPreparedRecursive','002-SourcePruningEnumerationPreparedFiniteCallbackResources.lean','SourcePruningEnumerationPreparedReservation')]:
 s=(owner/'cuts'/fn).read_text();ns='MicroCFTA.SourcePruningEnumerationExecutionCallbackBridge.'+variant
 start=s.index('namespace ');context=s[start:s.index('/-- The original callback packet')]
 context=context.replace('namespace MicroCFTA.'+module,'namespace '+ns,1)
 context=context.replace('open EnumerationState','open '+module+'\nopen SourcePruningEnumerationPathTransport (StatePaths ProjectionPaths)\nopen EnumerationState',1)
 a=s.index('theorem callback_finite_complete_resources\n');b=s.index(' := by\n',a);old=s[a:b]
 inp=old[:old.index('    ∃ (fuel : Nat)')];pivot=inp.rfind(') :\n');assert pivot>=0
 added='''
    (P : EqualityTrie.Path → Prop)
    (paths : StatePaths P before.core)
    (projected : ProjectionPaths
      (RESERVATION.final recursiveFuel seed ceiling).1 P)
    (Paths : Nat → Metadata Typing → Caller (bits + 2) → Queries → Cached → Prop)
    (pathsIH : ∀ (nextInventory : Inventory) (nextCaller : Caller (bits + 2))
        (nextMemos : Memos) (nextCache : Cached) (nextMetadata : Metadata Typing)
        (nextSeed : Seed) (nextCeiling : Nat),
      Packet formulas solver nextInventory nextCaller nextMemos nextMetadata nextCache →
      Fits nextSeed.2 nextCaller.checked →
      Heap (fun guard => guard ∈ nextSeed.1) nextCaller.checked.native.machine.heap →
      (∀ entry rows depth free, ∀ edge ∈ edgesOf (.node entry rows depth free), edge ∈ rows) →
      (∀ entry rows depth free, (edgesOf (.node entry rows depth free)).length ≤ rows.length) →
      suspendedBound nextCache.core ≤ nextCeiling →
      RESERVATION.Reserved bits recursiveFuel nextSeed nextCeiling →
      StatePaths P nextCache.core →
      ProjectionPaths (RESERVATION.final recursiveFuel nextSeed nextCeiling).1 P →
      ∃ bound, ∀ extra,
        Paths (bound + extra) nextMetadata nextCaller nextMemos.query nextCache) :
'''.replace('RESERVATION',reservation)
 header=(inp[:pivot+1]+added+old[old.index('    ∃ (fuel : Nat)'):]).replace('theorem callback_finite_complete_resources\n','theorem callback_finite_complete_resources_with_execution_ih\n',1)
 header+=''' ∧
      StatePaths P (EnumerationExpandableIndex.frame after before).core ∧
      (∀ extra, result.1 = false → Paths (fuel + extra) result.2 caller memos.query
        (EnumerationExpandableIndex.frame after before))'''
 proof=''' := by
  obtain ⟨fuel, result, after, outcome, returned, stable, frame, types, holes, typing,
      callback, running, resources⟩ :=
    MODULE.callback_finite_complete_resources
      holeKey fits admits formulas solver inventory graph templates metadata uv fragment caller memos before
      checkEmpty edgesOf stop order recursiveFuel recursive seed ceiling packet allocated bounded known
      selectionMembers selectionLength mass reserved
  have afterPaths : StatePaths P after :=
    SourcePruningEnumerationPathRecordingValues.recordTypes_paths graph templates (fuel + 0)
      metadata uv (.inl fragment) before.core after result paths (callback 0).1
  have framedPaths : StatePaths P (EnumerationExpandableIndex.frame after before).core := afterPaths
  by_cases continued : result.1 = false
  · have massAfter : suspendedBound (EnumerationExpandableIndex.frame after before).core ≤ ceiling := by
      change suspendedBound after ≤ ceiling
      rw [SourcePruningEnumerationPrefixAdmission.suspendedBound_values before.core after frame.values]
      exact mass
    obtain ⟨pathFuel, pathRunning⟩ := pathsIH inventory caller memos
      (EnumerationExpandableIndex.frame after before) result.2 seed ceiling returned bounded known
      selectionMembers selectionLength massAfter reserved framedPaths projected
    refine ⟨fuel + pathFuel, result, after, outcome, returned, stable, frame, types, holes, typing,
      ?_, ?_, resources, framedPaths, ?_⟩
    · intro extra
      simpa only [Nat.add_assoc] using callback (pathFuel + extra)
    · intro extra
      simpa only [Nat.add_assoc] using running (pathFuel + extra)
    · intro extra _actualFalse
      have actual := pathRunning (fuel + extra)
      have same : pathFuel + (fuel + extra) = fuel + pathFuel + extra := by omega
      rw [same] at actual
      exact actual
  · refine ⟨fuel, result, after, outcome, returned, stable, frame, types, holes, typing,
      callback, running, resources, framedPaths, ?_⟩
    intro _extra impossible
    exact False.elim (continued impossible)

end NAMESPACE
'''.replace('MODULE',module).replace('NAMESPACE',ns)
 parts.append('\n'+context+'\n/-- Keep every callback resource clause and add the actual recursive input paths. -/\n'+header+proof)
 # The old explicit header is recovered after removing only additions/name and appended path clauses.
 recovered=inp[:pivot+1]+' :\n'+old[old.index('    ∃ (fuel : Nat)'):]
 assert recovered==old
out=owner/'ExecutionCallbackBridge-v1-UNCOMPILED.lean';out.write_text(''.join(parts));out.chmod(0o444)
b=out.read_bytes();print(out,len(b),len(b.splitlines()),hashlib.sha256(b).hexdigest())
