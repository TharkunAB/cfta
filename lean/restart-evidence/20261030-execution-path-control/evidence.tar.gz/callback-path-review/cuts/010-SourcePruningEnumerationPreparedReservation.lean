theorem stage_ge (depth : Nat) (seed : Seed) (capturedMass inherited count : Nat) :
    Le seed.2 (stage depth seed capturedMass inherited count).2 ∧
      seed.1 ⊆ (stage depth seed capturedMass inherited count).1 :=
  iterate_ge _ (fun current => step_ge depth current capturedMass inherited) seed count

/-- Later entries of the same schedule retain earlier numeric and guard bounds. -/
theorem count_mono (depth : Nat) (seed : Seed) (capturedMass inherited : Nat) {first last : Nat}
    (counts : first ≤ last) :
    Le (stage depth seed capturedMass inherited first).2 (stage depth seed capturedMass inherited last).2 ∧
      (stage depth seed capturedMass inherited first).1 ⊆ (stage depth seed capturedMass inherited last).1 := by
  obtain ⟨extra, same⟩ := Nat.exists_eq_add_of_le counts
  rw [same, stage_add]
  exact stage_ge depth (stage depth seed capturedMass inherited first) capturedMass inherited extra

/-- An original positive-depth envelope contains its first paired stage. -/
theorem rows_positive (seed : Seed) : 1 ≤ rows seed := by
  unfold rows
  omega

/-- A shorter original ordinary scan fits the positive-depth driver envelope. -/
theorem stage_le_final (depth : Nat) (seed : Seed) (ceiling count : Nat)
    (bounded : count ≤ rows seed) :
    Le (stage depth (preparedSeed seed) ceiling ceiling count).2 (final (depth + 1) seed ceiling).2 ∧
      (stage depth (preparedSeed seed) ceiling ceiling count).1 ⊆ (final (depth + 1) seed ceiling).1 := by
  rw [final_succ]
  exact count_mono depth (preparedSeed seed) ceiling ceiling bounded

/-- A parked route can use the first paired stage without an actual edge execution. -/
