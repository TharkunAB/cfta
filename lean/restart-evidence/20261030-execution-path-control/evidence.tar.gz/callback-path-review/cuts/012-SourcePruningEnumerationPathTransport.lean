def ProjectionPaths
    (guards : List (SourceSymbolicIndex.Constraint FullSyntax.Formula))
    (P : EqualityTrie.Path → Prop) : Prop :=
  ∀ guard ∈ guards, ∀ tries residual,
    SourcePruningEnumerationConstraint.project guard = some (tries, residual) →
    ∀ trie ∈ tries, ∀ path ∈ EqualityTrie.fromPathTrie trie, P path

/-- A represented child path comes from its indexed parent path. -/
