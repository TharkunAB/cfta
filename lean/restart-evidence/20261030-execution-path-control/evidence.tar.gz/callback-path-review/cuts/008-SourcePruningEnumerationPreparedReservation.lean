namespace MicroCFTA.SourcePruningEnumerationPreparedReservation
open SourceCurrentAllocatedNativeResourceForecast (Le Room)
open SourcePruningEnumerationIncomingReservation (Seed)
attribute [local irreducible] SourcePruningEnumerationRecursiveReservation.afterHead
attribute [local irreducible] SourceCurrentConstrainedCapEditForecast.headProfile
local notation "afterHead" => SourcePruningEnumerationRecursiveReservation.afterHead
local notation "edgeCount" => SourcePruningEnumerationRecursiveReservation.edgeCount
local notation "massCeil" => SourcePruningEnumerationRecursiveReservation.massCeil
local notation "scalar" => SourceCurrentConstrainedCapTargetForecast.scalar

export SourcePruningEnumerationFiniteReservation
  (iterate iterate_zero iterate_succ iterate_add iterate_ge)

/-- Native normalization retains the original numeric profile. -/
