namespace MicroCFTA.SourcePruningEnumerationFiniteReservation
open SourceCurrentAllocatedNativeResourceForecast (Le Room)
open SourcePruningEnumerationIncomingReservation (Seed)
attribute [local irreducible] SourcePruningEnumerationRecursiveReservation.afterHead
attribute [local irreducible] SourceCurrentConstrainedCapEditForecast.headProfile
local notation "afterHead" => SourcePruningEnumerationRecursiveReservation.afterHead
local notation "edgeCount" => SourcePruningEnumerationRecursiveReservation.edgeCount
local notation "massCeil" => SourcePruningEnumerationRecursiveReservation.massCeil
local notation "narrowSeed" => SourcePruningEnumerationExpansionAdmission.narrowSeed
local notation "scalar" => SourceCurrentConstrainedCapTargetForecast.scalar

/-- Iterate one fixed seed transition in its original order. -/
