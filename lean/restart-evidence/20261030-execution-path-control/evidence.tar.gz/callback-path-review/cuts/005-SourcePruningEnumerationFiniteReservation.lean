theorem HeadReserved.callback {bits depth capturedMass inherited : Nat} {seed : Seed}
    (reservation : HeadReserved bits depth seed capturedMass inherited) :
    Reserved bits depth (afterHead seed inherited) (massCeil seed capturedMass inherited) :=
  reservation.2

/-- Room at the complete original forecast supplies every nested reservation. -/
