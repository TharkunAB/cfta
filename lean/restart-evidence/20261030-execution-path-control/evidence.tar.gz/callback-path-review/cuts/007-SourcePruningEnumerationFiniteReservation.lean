theorem stage_succ_right (depth : Nat) (seed : Seed) (capturedMass inherited count : Nat) :
    stage depth seed capturedMass inherited (count + 1) =
      step depth (stage depth seed capturedMass inherited count) capturedMass inherited :=
  stage_add depth seed capturedMass inherited count 1

/-- The first narrowed seed retains all original numeric and guard bounds. -/
