from pathlib import Path
import hashlib,json,stat,sys
original=Path('/tmp/mcfta-execution-path-control-20261030')
r=Path(sys.argv[1]) if len(sys.argv)>1 else original
out=Path(sys.argv[2]) if len(sys.argv)>2 else r
out.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def check(p,row):
 b=p.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],p
 return b
def source(p):
 p=Path(p)
 return r/p.relative_to(original) if p.is_relative_to(original) else p
results={}
callback=r/'callback-path-review';pins=load(callback/'pins.json');marker=load(callback/'FROZEN')
assert sha((callback/'pins.json').read_bytes())=='37cb146f19af1f8703a997bb2f39e8dd48d45a14667aac7fe128910173f55659'
assert marker['pins_sha256']==sha((callback/'pins.json').read_bytes()) and marker['payload_files']==len(pins)==38
assert {p.relative_to(callback).as_posix() for p in callback.rglob('*') if p.is_file()}=={row['path'] for row in pins}|{'pins.json','FROZEN'}
for row in pins:check(callback/row['path'],row)
assert sha((callback/'REPORT.md').read_bytes())==marker['report_sha256']
acquired=load(callback/'acquisitions.json');assert len(acquired)==12
assert {Path(row['source_path']).stem for row in acquired if row['whole']}=={'SourcePruningEnumerationFiniteCallbackResources','SourcePruningEnumerationPreparedFiniteCallbackResources'}
for row in acquired+load(callback/'reuse-ledger.json'):
 b=source(row['source_path']).read_bytes();assert len(b)==row['source_bytes'] and sha(b)==row['source_sha256']
 expected=b''.join(b.splitlines(keepends=True)[row['actual_start']-1:row['actual_end']]);assert expected==(callback/row['copy']).read_bytes();assert sha(expected)==row['copy_sha256']
 if 'frozen_bundle' in row:
  manifest=load(r/'provenance-manifests'/f"{row['frozen_manifest_sha256']}.json")
  matches=[pin for pin in manifest if pin['path']==row['frozen_copy']];assert len(matches)==1;check(callback/row['copy'],matches[0])
for row in load(callback/'scope-unions.json'):
 b=source(row['source_path']).read_bytes();assert sha(b)==row['source_sha256'] and len(b.splitlines())==row['source_lines']
 if Path(row['source_path']).stem not in {'SourcePruningEnumerationFiniteCallbackResources','SourcePruningEnumerationPreparedFiniteCallbackResources'}:
  assert len(row['new_union_lines'])/row['source_lines']<0.75,row['source_path']
results['callback']={'payloads':len(pins),'new_whole_bodies':2,'acquisitions':len(acquired),'frozen_full_reuses':3,'pins_sha256':sha((callback/'pins.json').read_bytes())}
d=r/'execution-predicate-review';seal=load(d/'pins.json');manifest=load(d/'MANIFEST.json')
assert seal['manifest_sha256']==sha((d/'MANIFEST.json').read_bytes()) and seal['payload_files']==manifest['payload_files']==20
assert {p.relative_to(d).as_posix() for p in d.rglob('*') if p.is_file()}=={row['path'] for row in manifest['files']}|{'MANIFEST.json','pins.json'}
for row in manifest['files']:check(d/row['path'],row)
assert seal['marker_sha256']==sha((d/'FROZEN').read_bytes()) and seal['report_sha256']==sha((d/'REPORT.md').read_bytes())
assert seal['new_whole_bodies']==2 and seal['verified_frozen_worker_scopes']==4
oldpins=load(d/'frozen-worker-pins.json')
for row in load(d/'initial-acquisitions.json'):
 check(d/row['copy'],row)
 if 'whole-worker-path-review' in row['source']:
  prior=[pin for pin in oldpins if pin['path']==Path(row['source']).name];assert len(prior)==1;check(d/row['copy'],prior[0])
 else:check(source(row['source']),row)
for row in load(d/'reuse-ledger.json'):
 assert row['frozen_pins_sha256']==sha((d/'frozen-worker-pins.json').read_bytes());assert row['frozen_pin'] in oldpins
 check(d/row['copy'],row['frozen_pin']);prior=row['prior'];b=source(prior['source_path']).read_bytes();assert len(b)==prior['source_bytes'] and sha(b)==prior['source_sha256'];assert b''.join(b.splitlines(keepends=True)[prior['actual_start']-1:prior['actual_end']])==(d/row['copy']).read_bytes()
contracts=load(d/'PUBLIC-CONTRACTS.json');assert len(contracts)==20
for row in contracts:
 current=(r/'execution-paths-v3.lean').read_text() if 'execution-paths-v2' in row['source'] else source(row['source']).read_text()
 assert row['header'] in current,row['name']
reviewed=(d/'01-execution-paths-v2.lean').read_text();checked=(r/'execution-paths-v3.lean').read_text();base='/-- Zero recursive depth'
assert reviewed.split(base)[0]==checked.split(base)[0]
results['predicates']={'payloads':20,'new_whole_bodies':2,'frozen_worker_scopes':4,'complete_contracts':len(contracts),'all_nine_definition_bodies_equal_current':True,'two_base_proofs_repaired_and_compiler_checked_by_root':True,'pins_sha256':sha((d/'pins.json').read_bytes())}
for directory in [callback,d]:
 for p in directory.rglob('*'):
  if p.is_file():assert p.stat().st_mode & 0o222 == 0,p
for p in (r/'provenance-manifests').glob('*.json'):assert sha(p.read_bytes())==p.stem
(out/'owned-review-verification.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
