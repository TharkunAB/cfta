{-# LANGUAGE OverloadedStrings #-}

module Main (main) where

import Data.List (sort)
import Data.CFTA.Equality
import Data.CFTA.Symbol (Symbol)
import Data.CFTA.Term (Term)
import qualified Data.CFTA.Term as Term

-- Source-only controls. This file has not been compiled or executed.
-- These controls test truncation. They are not starvation counterexamples.
main :: IO ()
main = do
    let nat = createMu (\self -> Node [Edge "f" [self], Edge "a" []]) :: Node Symbol
        noBase = createMu (\self -> Node [Edge "f" [self]]) :: Node Symbol
        outer = Node [Edge "loop" [noBase], Edge "atom" []]
        marker = Term.Node "Mu" []
        weight edge = if edgeSymbol edge == "loop" then 1 else 0
        classes = mkEqConstraints [[path [0], path [1]], [path [0, 0], path [1, 0]]]
        repeating = Mu (\self -> Node [Edge "a" [], mkEdge "p" [self, self] (equalityConstraint classes)]) :: Node Symbol
        constrained = Node [mkEdge "p" [repeating, repeating] (equalityConstraint classes)]
        pair = Term.Node "p" [marker, marker]
    check "bare accepted recursive language returns marker" [marker] (terms nat)
    check "caller unfolds before enumeration"
        (sort [Term.Node "a" [], Term.Node "f" [Term.Node "a" []]])
        (sort (terms (unfoldBounded 2 nat)))
    check "first no-base Mu child does not starve later atom"
        [Term.Node "loop" [marker], Term.Node "atom" []]
        (map fst (runsBy weight "Mu" outer))
    check "existing constrained repeated-key control"
        [Term.Node "p" [pair, pair]] (terms constrained)

-- Print the observed list and whether it matches the source-derived expectation.
check :: String -> [Term Symbol] -> [Term Symbol] -> IO ()
check label expected actual = print (label, actual == expected, actual)
