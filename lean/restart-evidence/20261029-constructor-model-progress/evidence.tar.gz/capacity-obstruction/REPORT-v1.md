[2026-10-29 21:50 CET]

Source-only semantic-risk audit: earlier recursive branches and sufficient capacity

Result

No admitted all-capacity starvation counterexample was established. The actual worker does stop before later siblings when an earlier recursive hook stops. This is a necessary mechanism for the proposed obstruction. It does not supply an original admitted input whose earlier branch keeps stopping at every sufficient work fuel and every recursive capacity.

Two small proposed routes are excluded by actual code and existing checked point results. A fresh empty-bucket Mu/explicit-Union is not expandable. An exact repeated native handle plus suspended-trie key clears its bucket. A fresh UVar identity does not make that key new.

A different negative result already exists and must remain explicit: an admitted native startup Mu/Union can emit the same undischarged placeholder at every capacity. This refutes an unconditional claim that original Packet, ProperState, and an accepted original term force a whole-Discharged constructor output in this internal worker. This is deliberate recursion truncation. It is not an earlier-branch starvation example, and it does not establish a fault in the public size-counted generator.

This audit changes no repository file. It performs no compilation, evaluator, native execution, Git, network, or board call. BoundaryControls.hs is an untested source draft for Root to run. It contains controls, not a proposed divergence counterexample.

Exact stop and accumulation behavior

1. SourcePruningEnumerationNativeContinuations.run, reviewed whole, invokes a completed head's hook before its sibling suffix. If that hook is stopped outputs reason endpoint, the actual result is stopped [] outputs (continuation receipt reason endpoint). The suffix is absent from this expression. Existing stopped_hook proves this literal equation.

2. If that hook is complete outputs middleCaller middleQueries, the worker does scan the suffix at those actual endpoints. It appends outputs to later outputs in both complete and stopped suffix cases. A normal rejected receipt with an advance endpoint also reaches the suffix.

3. PreparedRecursive.continueWith distinguishes normal pruning from unsupported callback observations. A singleton successful recordTypes result with true completes with no outputs. It does not stop the sibling scan. A false result calls the recursive worker at the exact framed callback cache. An unsupported raw callback shape stops. These cases must not be combined into a generic claim that any rejected earlier branch blocks the later branch.

4. PreparedRecursive.resume at recursive depth zero stops with exhausted and no outputs only when its supplied next decision is expand uv. The none, done, and stuck cases complete. The stuck case has no outputs; it is ordinary branch rejection for the enclosing sibling scan, not the recursive-capacity exhausted case.

5. PreparedRecursive.finish preserves the fold's accumulated outputs in either outcome. HookInvocation.hookOutputs and foldOutputs also observe stopped outputs. Thus a late stop does not erase already emitted leaves.

6. Existing PreparedRecursive.run_outputs_moreDepth proves an ordered prefix of complete/stopped output lists when only recursive depth increases. Work fuel, caller, cache, queries, metadata, and policies remain fixed. Its conclusion does not assert new output existence. A permanently empty prefix would satisfy the theorem. The theorem alone therefore cannot establish eventual occurrence of a later accepted leaf. The report does not silently extend this fixed-work theorem across changing widths, physical states, or work bounds.

Existing prepared coverage is honest about the obstruction

PreparedFiniteSiblingCoverage.alternatives_finite_complete_resources_accepting has original Packet, Ready, stored native handle, separately available/closed prepared parent, actual selected-edge membership, original Fits/Known, inherited length/mass, and ScanReserved. Its accepted-edge observer additionally requires that all earlier arity-allowed entries have supported constraint projection.

The conclusion is the actual chosen accepting event with an extended assignment, OR an exact strictly earlier stopped hook with its resources. It does not conclude that the chosen edge is reached. This disjunction is neither a counterexample nor whole coverage.

The general finite Complete contract requires selectionMembers and selectionLength, not selector completeness. These two gates permit dropping edges. A proposed full coverage theorem must separately retain its actual chosen accepted edge or an original complete selection policy. A counterexample that simply selects no accepting edge would not establish the requested earlier-branch starvation phenomenon.

Admissions permit truncation; Discharged excludes it

The reviewed Recursive.Packet definition has exactly these fields: original Context, Safe enumeration storage, PendingReferences, CacheValid, finite dependency stratification, and allocated pending metadata. It contains no Discharged condition.

Recursive.initial_packet_models derives the original startup Packet and native model from an actual original accepted term. Its model observer takes native meaning holds ambient value term and concludes an assignment with assignment 0 = term and Satisfies at startup. Neither that observer nor EnumerationCorrectness.Satisfies requires that the root already has an explicit fragment or that the cache is Discharged. Satisfies means the stored native root and suspended restrictions admit that assignment.

The already checked Recursive.initial_boundary_done is the relevant exact negative witness. It assumes original Context, actual Available closed value, empty metadata.pending, and recursiveBoundary value = true. Its existential startup has:

- an actual encoded/decoded native handle;
- Packet, Canonical, ProperState, exact waiting/expandable flags and suspended bound zero;
- graph-carrier/reference conclusions;
- NOT Discharged;
- no selection candidates;
- successful marker rendering;
- a done decision for every order, with stop = none;
- the same one-output complete original-worker return at every workFuel and recursiveFuel.

This is an existing conditional theorem from original checked Context and available closed native value. It is not a fabricated raw cache. It is not a new fully instantiated concrete Lean native heap from this audit. The theorem is for the original recursive worker. The prepared worker has the identical done equation and same restart decision, so its corresponding observation follows directly from the actual prepared definition, without a source/prepared receipt cast. No redundant prepared wrapper was drafted.

The initial model theorem can attach an accepted term to the same startup through the encoded native handle. This shows why an original accepted finite term and a pending placeholder can coexist. It does not make marker rendering equal that accepted term.

SourcePruningEnumerationRendering.Discharged says that EVERY remaining unenumerated slot must have node = none and an empty bucket. The retained startup slot has node = some handle, so it violates Discharged even though its bucket is empty and it is not expandable. The current PreparedHistoryRenderingSoundness.ResourceHistory.render_sound takes whole output Discharged explicitly, together with actual render Success and checked PCS residuals. Its original native meaning is a derived conclusion. The truncation observation does not satisfy its Discharged antecedent.

Consequently, increasing only this internal recursive capacity is not a way to unfold an intentionally parked empty-bucket boundary. The current theorem boundary already accounts for that fact. Do not turn it into a public finite-value coverage claim or a new Haskell defect.

Why the simple nonproductive branch does not starve

Haskell expandable returns false for a recursiveBoundary with Sequence.Empty. initEnumerationState installs the root with that empty bucket. enumerateNode with no terminal equality demand allocates a Mu or explicit-Union child as an opaque UVar instead of expanding it. enumerateOutUVarWith unfolds a selected Mu once or turns a selected explicit-Union into an ordinary node, but an empty-bucket boundary is not offered for selection in the first place.

Thus a root Mu X.(X union Atom) is not a demonstrated infinite earlier choice: in the intended root configuration it stays a boundary. This audit does not claim that this unguarded expression has been instantiated through the native checked construction API. The guarded existing test Mu X.(f X | a) is enough to show the same root-truncation policy.

Similarly, an ordinary outer node with a first alternative loop(noBaseMu) and a later atom alternative finishes the first branch as loop(marker). It can then reach atom. This is the third untested control in BoundaryControls.hs. It is a source-derived expectation, not an executed result.

A constrained exact recurrence also does not supply the needed unseen input. Recursion.complete derives stable actual checkRepeated execution from Ready, stored pending slot, PendingRealized, exact lookup, roots, waiting counts and native flags. Its repeated=true branch returns the SAME handle with an empty bucket, disables that expandable flag, and preserves the other original invariants. ParkedRestart.selected_complete_with_parking_progress proves that actual successful selected parking fixes the allocation counter and strictly decreases candidates.length.

That count bounds consecutive parking steps only. A later allocating continuation can introduce new work. Neither result proves all constrained recursion terminates.

Both key definitions omit suspended UVar identities. Lean canonicalizes the suspended tries and pairs them with the native handle. Haskell pairs nodeIdentity with the set of path tries. Haskell addUVarValue inherits the current expansion ancestry; selected Mu/Union entry inserts the current key, and the post-expansion finalizer clears expansionAncestry. Merge inheritance unions existing histories. Therefore fresh UVar IDs alone do not evade repetition. This audit does not prove that all possible generated native handles or trie sets stay in one finite original carrier.

A potentially relevant variant must therefore justify a genuinely new handle or trie key at each selected boundary, or another real source of unbounded expandable work. Generated handles alone are not such a proof: one must establish their actual decoded values, admissions, closedness, successful checked operations, key insertion/inheritance, and persistence of nonempty ready obligations.

Actual Haskell consumers and public boundary

The eager EnumerateM is depth-first CPS, in the order of StateT state []. branches folds alternatives in order. allBranches produces the lazy result list. Therefore a genuinely nonterminating earlier branch could starve a later branch in that API. No admitted instance of that premise was established here. Haskell has no literal Lean recursiveFuel exhausted constructor; the bounded worker stop is a diagnostic approximation and is not itself an executed Haskell abort.

Equality.hs explicitly documents that enumeration stops at recursion and the CALLER must unfold first. Its example applies unfoldBounded 2 to a Mu before terms. EqualitySpec already contains the following expectations: bare Mu returns the recursion marker, a Mu under an edge returns the same nested marker, explicit bounded unfolding enumerates a and f(a), and the constrained repeated-key example terminates with markers. These tests were read as source; they were not executed by this audit.

There is no automatic placeholder-to-all-values consumer in the reviewed terms/runs path. runsFrom initializes the source, runs enumerateFully, and expands the resulting UVar with the recursion marker. A caller that wants a finite unfolding must transform the automaton BEFORE this enumeration. The marker itself is an ordinary output symbol for these APIs.

The public cfta-generator fromAutomaton entry is a DIFFERENT path. Gen.hs delegates to Flat.fromAutomaton. Flat.readAutomaton routes acyclic inputs to finiteAutomaton and cyclic inputs to automatonIndex, building a size-indexed Recursive generator. Automaton.automatonIndex uses Ordinary.tableIndex over original automaton rows. Its stated checks reject open support, equality-constrained edges, and ambiguous productive alternatives. This route does not expand a marker emitted by Enumeration.hs and cannot be declared incomplete from the internal truncation case. This audit does not prove that separate size-indexed implementation correct.

The optional ordered cursor is also a separate API. Its actual orderedPrepare keeps the same boundary/repetition checks, while orderedRawStep uses shallow ordinary-child expansion. Its documented policy gives no progress bound for an infinite lower-key search. Do not transfer the eager prepared sibling order or an alleged eager starvation example to the cursor without checking its scheduler and keys. No cursor starvation example was established.

Exact remaining risk / next meaningful obligation

For the proposed starvation counterexample, supply ONE original admitted source and a chosen later accepted edge. Derive the actual first head and actual nonpruned callback. For every recursive capacity that has enough original reservation and stable work fuel, derive that its earlier actual continuation prevents that chosen edge from being reached and that the chosen accepted term occurs in NONE of the accumulated earlier outputs. A proof that the whole result is stopped is insufficient, because stopped results can retain the desired output. A proof at one low work fuel is also insufficient.

Word reservations matter in this quantification. Existing finite contracts take Reserved bits D seed ceiling. An all-D statement cannot silently reuse one finite word width when its room condition eventually fails. It must quantify over admissible capacities/representations or supply an appropriate width-indexed version of the SAME mathematical source. This report does not claim that every D is admissible for a fixed physical caller.

For a positive sufficient-capacity proof, the missing obligation is termination/progress of ALL earlier actual continuations up to the chosen event, including their nonmodel branches and no-output effects. One chosen model's structural height need not bound those earlier branches. Current prefix/resource/model theorems do not discharge this obligation. The global source-derived key/rank or actual bounded producer route remains the appropriate next work. No supplied future terminating trace or future generated-body bound is introduced here.

Scope and readiness

Five existing Lean sources were reviewed whole: PreparedRecursive, PreparedReceiptHook, HookInvocation, NativeContinuations, and Recursion. Other reviewed inputs are literal cuts in manifest-v1.json. The whole-acquisition budget was exceeded conservatively by one: requested Equality.hs cuts1-96 and89-134 cover its134-line source. Five whole Lean sources plus that Haskell union yield6/5 whole identities. One early combined output was truncated, so this report does NOT claim whole Equality.hs review. The relevant public enumeration section89-134 was read separately. No further whole read followed.

Some broad searches printed a very long pre-existing single-line test fixture and were truncated. They establish no semantic claim and are not counted as reviewed proof bodies. The exact controlled cuts and whole snapshots supporting this report are retained with their source identities. Old FINDINGS and composition notes explicitly reject the same naive A=f(A)|a divergence proposal.

No Haskell defect or required fix was established. BoundaryControls.hs is source-only and untested. No new Lean proof candidate was needed: the useful admitted truncation witness already exists, and an all-capacity starvation claim remains unproved.
