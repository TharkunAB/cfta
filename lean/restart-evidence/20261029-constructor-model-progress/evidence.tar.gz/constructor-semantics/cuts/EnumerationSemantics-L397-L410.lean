      ResidualHolds meaning residual (fill assignment fragment) := by
  cases residual with
  | none =>
      obtain ⟨_, same⟩ := (success_pure () () before after).mp success
      subst after
      simp [ResidualHolds]
  | some guard =>
      obtain rfl := (modify_success _ before after).mp success
      simp only [Satisfies, Fragments.stateSatisfies, guardsHold, List.mem_cons, forall_eq_or_imp, ResidualHolds]
      exact ⟨fun ⟨state, guarded, old⟩ => ⟨⟨state, old⟩, guarded⟩, fun ⟨⟨state, old⟩, guarded⟩ => ⟨state, guarded, old⟩⟩

/-- A child traversal composes forward invariants and backward assignment implications. -/
theorem mapM_backward (action : α → EnumerateM Symbol Guard β) (invariant satisfies : State Symbol Guard → Prop)
    (relation : α → β → Prop) (inputs : List α)
