/-- Stored graph references denote their complete term languages. -/
abbrev NodeLanguage (Symbol : Type) := Nat → Term Symbol → Prop

/-- One source equality class requires a common existing subtree at every represented path. -/
def EqualityHolds (term : Term Symbol) (trie : EqualityTrie.Trie) : Prop :=
  ∃ common, ∀ path ∈ EqualityTrie.fromPathTrie trie, term.atPath path = some common

/-- An absent residual imposes no predicate; a present residual applies at this term. -/
def ResidualHolds (meaning : Guard → Term Symbol → Prop) (residual : Option Guard) (term : Term Symbol) : Prop :=
  match residual with
  | none => True
