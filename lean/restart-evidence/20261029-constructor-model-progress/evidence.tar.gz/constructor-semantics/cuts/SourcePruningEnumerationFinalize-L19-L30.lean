  let _old ← rawValue target
  setValue target (.enumerated fragment)
  pure fragment

/-- Use the current raw value to remove its waiting references after reset. -/
def run (heap : InternedConstructorTemplates.State Symbol NativeGuard)
    (fuel target : Nat) (fragment : Fragments.Fragment Symbol)
    (before : EnumerationExpandableIndex.Cached Symbol EnumGuard) :
    Option (EnumerationExpandableIndex.Cached Symbol EnumGuard) :=
  let reset : EnumerationExpandableIndex.Cached Symbol EnumGuard :=
    EnumerationExpandableIndex.frame {before.core with expansionAncestry := []} before
  (reset.core.values[target]?).bind fun old =>
