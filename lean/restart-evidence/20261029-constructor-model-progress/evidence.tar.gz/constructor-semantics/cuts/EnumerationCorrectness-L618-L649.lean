mutual
/-- Every hole of a fragment names an allocated slot. -/
def FragmentBound (limit : Nat) : Fragment Symbol → Prop
  | .hole uv => uv < limit
  | .node _ children => FragmentsBound limit children

/-- The finite child list contains only allocated holes. -/
def FragmentsBound (limit : Nat) : List (Fragment Symbol) → Prop
  | [] => True
  | child :: rest => FragmentBound limit child ∧ FragmentsBound limit rest
end

/-- Every stored equality reference and every stored fragment hole is allocated. -/
def SlotBound (limit : Nat) : UVarValue Symbol → Prop
  | .unenumerated _ scs => ∀ sc ∈ scs, sc.var < limit
  | .enumerated fragment => FragmentBound limit fragment
  | .eliminated => True

/-- Every stored union-find address and parent target stays inside the allocation domain. -/
def ForestBound (limit : Nat) (forest : UnionFind.Forest) : Prop :=
  ∀ uv entry, forest uv = some entry → uv < limit ∧
    match entry with
    | .root _ => True
    | .parent next => next < limit

/-- Storage safety needed to justify fresh-variable extension and representative lookup. -/
structure StorageValid (state : State Symbol Guard) : Prop where
  aligned : SupplyAligned state
  total : UnionFind.Total state.representatives
  forest : ForestBound state.counter state.representatives
  values : ∀ value ∈ state.values, SlotBound state.counter value
  guards : ∀ obligation ∈ state.obligations, FragmentBound state.counter obligation.2
