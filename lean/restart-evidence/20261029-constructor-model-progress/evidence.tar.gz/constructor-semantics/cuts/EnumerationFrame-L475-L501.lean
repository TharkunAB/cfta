/-- Removing one payload restriction preserves every complete assignment. -/
theorem neutralize_satisfies (language : NodeLanguage Symbol) (meaning : Guard → Term Symbol → Prop)
    (assignment : Nat → Term Symbol) (held : Nat) (state : State Symbol Guard)
    (satisfies : Satisfies language meaning assignment state) :
    Satisfies language meaning assignment (neutralize held state) := by
  refine ⟨⟨satisfies.1.1, ?_⟩, satisfies.2⟩
  intro uv
  by_cases same : uv = held
  · subst uv
    by_cases inside : held < state.values.length
    · simp [neutralize, heap, inside, slot, slotSatisfies, permits]
    · simp [neutralize, heap, inside, slot, slotSatisfies]
  · simpa [heap, neutralize_read held uv state same] using satisfies.1.2 uv

/-- Reestablishing the selected payload completes a neutral state's assignment. -/
theorem neutralize_restore (language : NodeLanguage Symbol) (meaning : Guard → Term Symbol → Prop)
    (assignment : Nat → Term Symbol) (held : Nat) (state : State Symbol Guard)
    (satisfies : Satisfies language meaning assignment (neutralize held state))
    (selected : slotSatisfies assignment held (heap language state.values held)) :
    Satisfies language meaning assignment state := by
  refine ⟨⟨satisfies.1.1, ?_⟩, satisfies.2⟩
  intro uv
  by_cases same : uv = held
  · simpa [same] using selected
  · have other := satisfies.1.2 uv
    simpa [heap, neutralize_read held uv state same] using other

