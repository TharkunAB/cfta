
/-- Successful sequential execution is exactly composition through one successful intermediate state. -/
theorem success_bind (action : EnumerateM Symbol Guard α) (next : α → EnumerateM Symbol Guard β)
    (before : State Symbol Guard) (value : β) (after : State Symbol Guard) :
    Success (action >>= next) before value after ↔
      ∃ middle intermediate, Success action before middle intermediate ∧ Success (next middle) intermediate value after := by
  simp only [Success, run_bind, List.mem_flatMap]
  constructor
  · rintro ⟨result, member, continued⟩
    cases result with
    | error error => simp at continued
    | ok pair => exact ⟨pair.1, pair.2, member, continued⟩
  · rintro ⟨middle, intermediate, member, continued⟩
    exact ⟨.ok (middle, intermediate), member, continued⟩

/-- A deterministic first step supplies exactly its returned state to the next step. -/
