/-- Residual recording adds exactly the retained guard predicate. -/
theorem recordResidual_assignment (language : NodeLanguage Symbol) (meaning : Guard → Term Symbol → Prop)
    (assignment : Nat → Term Symbol) (residual : Option Guard) (fragment : Fragment Symbol)
    (before after : State Symbol Guard) (success : Success (recordResidual residual fragment) before () after) :
    Satisfies language meaning assignment after ↔ Satisfies language meaning assignment before ∧
      ResidualHolds meaning residual (fill assignment fragment) := by
  cases residual with
  | none =>
      obtain ⟨_, same⟩ := (success_pure () () before after).mp success
      subst after
      simp [ResidualHolds]
  | some guard =>
      obtain rfl := (modify_success _ before after).mp success
      simp only [Satisfies, Fragments.stateSatisfies, guardsHold, List.mem_cons, forall_eq_or_imp, ResidualHolds]
      exact ⟨fun ⟨state, guarded, old⟩ => ⟨⟨state, old⟩, guarded⟩, fun ⟨⟨state, old⟩, guarded⟩ => ⟨state, guarded, old⟩⟩

