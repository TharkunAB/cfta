first, so shrinking moves toward leaves.

A cyclic automaton gives a recursive generator counted by size, the number of
term nodes, so 'upToSize' draws uniformly from the terms of at most a given
size. The count sums over accepting runs. An ambiguous automaton is therefore
rejected with 'AmbiguousAutomaton', and one with equality constraints with
'CannotCountConstrainedEdges'.

The values are the accepted terms. The form that 'upToSize' bounds
keeps the terms, the support, and the inspection graph, so 'support',
'inspect', 'termAt', and 'ranksOf' work on it.
-}
fromAutomaton ::
    (Ord symbol, Hashable symbol, Typeable symbol) =>
    Node symbol -> Gen symbol (Term symbol)
fromAutomaton = Flat.fromAutomaton id

{- | Read the terms an automaton accepts up to a constructor-depth bound.

A leaf has depth zero. The result is the finite generator 'fromAutomaton'
gives for an acyclic automaton: each distinct term has one rank, unranking
constructs only the selected term, and shrinks remain in the language.
-}
fromAutomatonUpToDepth ::
    (Ord symbol, Hashable symbol, Typeable symbol) =>
    Depth -> Node symbol -> Gen symbol (Term symbol)
fromAutomatonUpToDepth = Flat.fromAutomatonUpToDepth id
