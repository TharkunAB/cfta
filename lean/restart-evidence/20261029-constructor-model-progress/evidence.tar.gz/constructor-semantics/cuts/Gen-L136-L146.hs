import qualified Data.CFTA as FTA
import Data.CFTA.Constraint (Constraint)
import Data.CFTA.Gen.Error
import Data.CFTA.Gen.Internal.Automaton (datatypeDecoder, declarationOrder, undecodableConstructor)
import Data.CFTA.Gen.Internal.Flat hiding (fromAutomaton, fromAutomatonUpToDepth)
import qualified Data.CFTA.Gen.Internal.Flat as Flat
import Data.CFTA.Gen.Internal.Grouped
import Data.CFTA.Gen.Internal.Inspection (Inspection (..), InspectionSymbol (..), drawInspection)
import Data.CFTA.Gen.Internal.Query
import Data.CFTA.Gen.Internal.Recur
import Data.CFTA.Gen.Internal.Types
