/-- Interpret one concrete source slot as the previously verified fragment-domain slot. -/
def slot (language : NodeLanguage Symbol) : UVarValue Symbol → Slot Symbol
  | .unenumerated node scs =>
      .pending (node.map language) (scs.map fun sc => fun assignment term => Suspended.Holds assignment term sc)
  | .enumerated fragment => .expanded fragment
  | .eliminated => .eliminated

/-- Missing array positions impose no term restriction; operations still report invalid accesses. -/
def heap (language : NodeLanguage Symbol) (values : List (UVarValue Symbol)) : Heap Symbol :=
  fun uv => slot language (values[uv]?.getD .eliminated)

/-- Retained residual guards apply to their completed guarded fragments. -/
def guardsHold (meaning : Guard → Term Symbol → Prop) (assignment : Nat → Term Symbol)
    (obligations : List (Guard × Fragment Symbol)) : Prop :=
  ∀ obligation ∈ obligations, meaning obligation.1 (fill assignment obligation.2)

/-- A complete assignment satisfies all forest equalities, stored slots, and retained guards. -/
def Satisfies (language : NodeLanguage Symbol) (meaning : Guard → Term Symbol → Prop)
    (assignment : Nat → Term Symbol) (state : State Symbol Guard) : Prop :=
  Fragments.stateSatisfies state.representatives (heap language state.values) assignment ∧
    guardsHold meaning assignment state.obligations
