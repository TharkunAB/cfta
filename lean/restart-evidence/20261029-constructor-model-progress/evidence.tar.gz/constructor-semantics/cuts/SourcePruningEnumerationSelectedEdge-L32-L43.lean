/-- Record the residual in the actual completed cache. -/
def finish (residual : Option Constraint) (fragment : Fragment) (before : Cached) : Cached :=
  EnumerationExpandableIndex.frame {before.core with obligations :=
    match residual with
    | none => before.core.obligations
    | some guard => (guard, fragment) :: before.core.obligations} before

/-- Residual recording has exactly the source action's successful singleton result. -/
theorem finish_raw (residual : Option Constraint) (fragment : Fragment) (before : Cached) :
    ExceptT.run (recordResidual residual fragment before.core) = [.ok ((), (finish residual fragment before).core)] := by
  cases residual <;> rfl

