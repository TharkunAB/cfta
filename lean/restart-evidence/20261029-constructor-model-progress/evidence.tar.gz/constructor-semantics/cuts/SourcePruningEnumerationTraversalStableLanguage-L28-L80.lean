private theorem complete_tail
    (checkEmpty : Bool) {r n p h k : Nat}
    {incoming : Node} {bucket : List Suspended} {rest : List (Node × List Suspended)}
    {caller middleCaller afterCaller : Caller width} {before middle after : Cached}
    {queries middleQueries savedQueries : Queries} {fragment : Fragment} {fragments : List Fragment}
    {outer : EnumerationState.State Symbol Constraint} {waiting : EnumerationWaitingIndex.Waiting}
    (head : SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k
      bucket incoming caller before queries =
      ((.ok (some [.ok (fragment, middle.core)]), middleCaller, middleQueries, outer, waiting), some middle))
    (completed : SourcePruningEnumerationChildTraversal.run checkEmpty r n p h k
      ((incoming, bucket) :: rest) caller before queries =
      .complete fragments afterCaller savedQueries after) :
    ∃ tailFragments, fragments = fragment :: tailFragments ∧
      SourcePruningEnumerationChildTraversal.run checkEmpty r n p h k
        rest middleCaller middle middleQueries =
        .complete tailFragments afterCaller savedQueries after := by
  rw [SourcePruningEnumerationChildTraversal.run, head] at completed
  cases suffix : SourcePruningEnumerationChildTraversal.run checkEmpty r n p h k
      rest middleCaller middle middleQueries with
  | complete tailFragments finalCaller finalQueries final =>
      have fields : fragments = fragment :: tailFragments ∧ afterCaller = finalCaller ∧
          savedQueries = finalQueries ∧ after = final := by
        simpa only [suffix, SourcePruningEnumerationChildTraversal.Result.complete.injEq] using completed.symm
      obtain ⟨rfl, rfl, rfl, rfl⟩ := fields
      exact ⟨tailFragments, rfl, rfl⟩
  | stopped completedPrefix observation candidate =>
      simp only [suffix] at completed
      cases completed

/-- An actual stable complete traversal retains exactly its ordered effective child restrictions. -/
theorem stable_complete_semantics
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (beforeCaller : Caller width) (before : Cached)
    (checkEmpty : Bool) (inputs : List (Node × List Suspended))
    (roots : Nat → Nat) (memos : Memos)
    (initial : Context formulas solver inventory beforeCaller memos)
    (safe : Safe before.core) (paths : Roots before.core.representatives roots)
    (counts : EnumerationCanonicalWaiting.Correct roots before.core.values before.waiting)
    (flags : ∀ slot, SourcePruningEnumerationNativeIndex.candidate beforeCaller.checked.native.machine.heap
      ((before.core.values[slot]?).getD .eliminated) = some (before.expandable slot))
    (realized : PendingRealized beforeCaller.checked.native.machine.heap before.core)
    (genuine : ∀ incoming bucket, (incoming, bucket) ∈ inputs →
      Available beforeCaller.checked.native.machine.heap incoming ∧ incoming.free = [] ∧
      (∀ sc ∈ bucket, sc.var < before.core.counter) ∧ InputsPending before.core bucket)
    (ranges : Ranges checkEmpty inputs beforeCaller before memos.query)
    {r n p h k : Nat} {fragments : List Fragment} {afterCaller : Caller width}
    {after : Cached} {savedQueries : Queries}
    (observed : ∀ extraRepresentative extraNative P H extraIndex, p ≤ P → h ≤ H →
      SourcePruningEnumerationChildTraversal.run checkEmpty (r + extraRepresentative) (n + extraNative)
        P H (k + extraIndex) inputs beforeCaller before memos.query =
        .complete fragments afterCaller savedQueries after) :
    ∀ (ambient : InternedGuardedLanguage.Env Symbol)
