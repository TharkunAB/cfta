theorem fragmentsBound_member (limit : Nat) (children : List (Fragment Symbol))
    (bounded : FragmentsBound limit children) (child : Fragment Symbol) (member : child ∈ children) :
    FragmentBound limit child := by
  induction children with
  | nil => cases member
  | cons first rest ih =>
      rcases List.mem_cons.mp member with rfl | present
      · exact bounded.1
      · exact ih bounded.2 present

/-- Actual fragment rendering preserves every stored value and obligation. -/
