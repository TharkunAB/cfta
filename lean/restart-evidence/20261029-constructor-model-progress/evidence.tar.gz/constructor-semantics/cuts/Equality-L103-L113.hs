    -- * Enumeration

    {- |
    Enumeration stops at recursion. Unfold first to see past it:

    >>> let nat = createMu (\r -> Node [Edge "z" [], Edge "s" [r]]) :: Node Symbol
    >>> terms nat
    [Node "Mu" []]
    >>> terms (unfoldBounded 2 nat)
    [Node "z" [],Node "s" [Node "z" []]]
    -}
