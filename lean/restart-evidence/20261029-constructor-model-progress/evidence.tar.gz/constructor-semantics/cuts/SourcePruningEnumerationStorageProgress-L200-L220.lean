/-- An actual successful native finalizer removes the captured pending graph cost. -/
theorem finalize_pendingSize
    (heap : InternedConstructorTemplates.State Symbol NativeGuard) (fuel target handle : Nat)
    (fragment : Fragments.Fragment Symbol) (scs : List Suspended)
    (before after : EnumerationExpandableIndex.Cached Symbol EnumGuard)
    (assignment : Nat → Term Symbol)
    (stored : before.core.values[target]? = some (.unenumerated (some handle) scs))
    (observed : SourcePruningEnumerationFinalize.run heap fuel target fragment before = some after) :
    pendingSize after.core assignment + NumberedTerms.size (assignment target) =
      pendingSize before.core assignment := by
  simp only [SourcePruningEnumerationFinalize.run, Option.bind_eq_some_iff] at observed
  obtain ⟨_old, _stored, written⟩ := observed
  simp only [SourcePruningEnumerationNativeIndex.write, Option.bind_eq_some_iff, Option.some.injEq] at written
  obtain ⟨_flag, _classified, _removed, _removedCounts, _saved, _savedCounts, same⟩ := written
  subst after
  change EnumerationStorageProgress.scanCost assignment 0 (before.core.values.set target (.enumerated fragment)) +
    NumberedTerms.size (assignment target) = EnumerationStorageProgress.scanCost assignment 0 before.core.values
  simpa only [EnumerationStorageProgress.weight, Nat.zero_add, Nat.add_zero] using
    EnumerationStorageProgress.from_set assignment before.core.values 0 target
      (.unenumerated (some handle) scs) (.enumerated fragment) stored

