theorem trace_model_pendingSize
    {checkEmpty : Bool} {r n p h k : Nat} {inputs : List (Node × List Suspended)}
    {caller reached : Caller width} {before after : Cached} {queries saved : Queries}
    {fragments : List Fragment}
    (trace : SourcePruningEnumerationChildTraversal.Trace checkEmpty r n p h k inputs caller before queries
      fragments reached after saved)
    (holds : Constraint → Term Symbol → Bool) (ambient : InternedGuardedLanguage.Env Symbol)
    (meaning : Constraint → Term Symbol → Prop) (assignment : Nat → Term Symbol) (terms : List (Term Symbol))
    (coherent : InternedRecordCoherence.Coherent caller.checked.native.machine.heap)
    (storage : StorageValid before.core) (realized : PendingRealized caller.checked.native.machine.heap before.core)
    (satisfied : Satisfies (SourcePruningEnumerationNativeLanguage.handles holds ambient caller.checked.native.machine.heap)
      meaning assignment before.core)
    (genuine : ∀ incoming bucket, (incoming, bucket) ∈ inputs →
      Available caller.checked.native.machine.heap incoming ∧ incoming.free = [] ∧
      ∀ sc ∈ bucket, sc.var < before.core.counter)
    (nonterminal : ∀ incoming bucket, (incoming, bucket) ∈ inputs →
      bucket.any (fun sc => EqualityTrie.isTerminal sc.trie) = false)
    (accepted : All₂ (fun (input : Node × List Suspended) term =>
      InternedGuardedLanguage.meaning holds ambient input.1 term ∧
      ∀ sc ∈ input.2, Suspended.Holds assignment term sc) inputs terms) :
    ∃ extended,
      (extended = install assignment before.core.counter terms ∧
        (∀ uv < before.core.counter, extended uv = assignment uv) ∧
        after.core.counter = before.core.counter + terms.length ∧
        after.core.counter = after.core.values.length ∧
        (∀ uv < before.core.counter, after.core.values[uv]? = before.core.values[uv]?) ∧
        fragments.map (Fragments.fill extended) = terms ∧
        pendingSize after.core extended = pendingSize before.core assignment + NumberedTerms.forestSize terms) ∧
      Satisfies (SourcePruningEnumerationNativeLanguage.handles holds ambient caller.checked.native.machine.heap)
        meaning extended before.core ∧ reached = caller ∧ saved = queries ∧ StorageValid after.core ∧
      PendingRealized reached.checked.native.machine.heap after.core ∧
      Satisfies (SourcePruningEnumerationNativeLanguage.handles holds ambient reached.checked.native.machine.heap)
        meaning extended after.core ∧ ∀ fragment ∈ fragments, FragmentBound after.core.counter fragment := by