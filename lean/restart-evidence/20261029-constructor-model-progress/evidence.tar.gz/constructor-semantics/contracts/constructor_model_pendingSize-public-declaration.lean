theorem constructor_model_pendingSize
    (checkEmpty : Bool) (r n p h k : Nat) (inputs : List (Node × List Suspended))
    (caller reached : Caller width) (before traversed after : Cached) (queries saved : Queries)
    (fragments : List Fragment) (assignment : Nat → Term Symbol) (symbol : Symbol)
    (terms : List (Term Symbol)) (target handle : Nat) (scs : List Suspended) (residual : Option Constraint)
    (holds : Constraint → Term Symbol → Bool) (ambient : InternedGuardedLanguage.Env Symbol)
    (meaning : Constraint → Term Symbol → Prop)
    (coherent : InternedRecordCoherence.Coherent caller.checked.native.machine.heap)
    (storage : StorageValid before.core) (realized : PendingRealized caller.checked.native.machine.heap before.core)
    (satisfied : Satisfies (SourcePruningEnumerationNativeLanguage.handles holds ambient caller.checked.native.machine.heap)
      meaning assignment before.core)
    (genuine : ∀ incoming bucket, (incoming, bucket) ∈ inputs →
      Available caller.checked.native.machine.heap incoming ∧ incoming.free = [] ∧
      ∀ sc ∈ bucket, sc.var < before.core.counter)
    (nonterminal : ∀ incoming bucket, (incoming, bucket) ∈ inputs →
      bucket.any (fun sc => EqualityTrie.isTerminal sc.trie) = false)
    (accepted : All₂ (fun (input : Node × List Suspended) term =>
      InternedGuardedLanguage.meaning holds ambient input.1 term ∧
      ∀ sc ∈ input.2, Suspended.Holds assignment term sc) inputs terms)
    (stored : before.core.values[target]? = some (.unenumerated (some handle) scs))
    (parent : assignment target = .node symbol terms)
    (guarded : ResidualHolds meaning residual (assignment target))
    (completed : SourcePruningEnumerationChildTraversal.run checkEmpty r n p h k inputs caller before queries =
      .complete fragments reached saved traversed)
    (finalized : SourcePruningEnumerationFinalize.run reached.checked.native.machine.heap k target
      (.node symbol fragments) (SourcePruningEnumerationSelectedEdge.finish residual (.node symbol fragments) traversed) =
      some after) :
    ∃ extended,
      (extended = install assignment before.core.counter terms ∧
        (∀ uv < before.core.counter, extended uv = assignment uv) ∧
        Fragments.fill extended (.node symbol fragments) = assignment target ∧
        pendingSize after.core extended + 1 = pendingSize before.core assignment ∧
        pendingSize after.core extended < pendingSize before.core assignment) ∧
      Satisfies (SourcePruningEnumerationNativeLanguage.handles holds ambient caller.checked.native.machine.heap)
        meaning extended before.core ∧ reached = caller ∧ saved = queries ∧
      Satisfies (SourcePruningEnumerationNativeLanguage.handles holds ambient reached.checked.native.machine.heap)
        meaning extended after.core := by