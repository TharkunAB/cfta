    ∃ extended,
      extended = install assignment before.core.counter terms ∧
      (∀ uv < before.core.counter, extended uv = assignment uv) ∧
      after.core.counter = before.core.counter + terms.length ∧
      after.core.counter = after.core.values.length ∧
      (∀ uv < before.core.counter, after.core.values[uv]? = before.core.values[uv]?) ∧
      fragments.map (Fragments.fill extended) = terms ∧
      pendingSize after.core extended = pendingSize before.core assignment + NumberedTerms.forestSize terms