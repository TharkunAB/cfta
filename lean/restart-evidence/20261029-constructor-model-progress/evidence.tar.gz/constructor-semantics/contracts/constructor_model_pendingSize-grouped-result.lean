    ∃ extended,
      (extended = install assignment before.core.counter terms ∧
        (∀ uv < before.core.counter, extended uv = assignment uv) ∧
        Fragments.fill extended (.node symbol fragments) = assignment target ∧
        pendingSize after.core extended + 1 = pendingSize before.core assignment ∧
        pendingSize after.core extended < pendingSize before.core assignment