# Constructor models and terminal storage progress

The full formalization goal remains ACTIVE.
Read final-documents/lean/notes-current-constructor-model-progress.md first.
Actual nonterminal constructor cost and Satisfies use the SAME assignment.
Actual mixed assimilation and terminal stages derive their storage bounds.
Mixed child composition and public coverage remain open.
Worker capacity alone cannot remove intentional recursion placeholders.

Every regular file is archived without filtering. Keep this tree and all
reconstructions immutable. Continue in a fresh writable area. Historical
UNTESTED labels and failed attempts remain. Five exact final strict mappings
identify checked repairs. Verification executes no Lean or Haskell code.
