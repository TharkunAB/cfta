
/-- Suspending equality classes only allocates pending slots. -/
theorem suspension_origin (count : Nat) (state : State Symbol Guard) : EnumeratedOrigin state (suspendedState count state) := by
  induction count generalizing state with
  | zero => exact .refl state
  | succ count ih => exact (allocation_origin none state).trans (ih (allocated none state))

