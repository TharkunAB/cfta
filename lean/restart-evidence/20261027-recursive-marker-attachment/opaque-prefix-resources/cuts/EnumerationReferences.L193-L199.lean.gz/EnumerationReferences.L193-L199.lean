/-- Repeated class allocation creates no stored references. -/
theorem suspension_allowed (allowed : Nat → Prop) (count : Nat) (state : State Symbol Guard) (valid : ReferencesAllowed allowed state) :
    ReferencesAllowed allowed (suspendedState count state) := by
  induction count generalizing state with
  | zero => exact valid
  | succ count ih => exact ih (allocated none state) (allocation_allowed allowed none state valid)

