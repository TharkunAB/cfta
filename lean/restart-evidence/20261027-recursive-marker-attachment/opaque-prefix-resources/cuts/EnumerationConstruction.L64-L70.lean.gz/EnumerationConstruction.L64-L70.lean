/-- Suspending classes leaves the existing equality forest unchanged. -/
theorem suspended_forest (count : Nat) (state : State Symbol Guard) :
    (suspendedState count state).representatives = state.representatives := by
  induction count generalizing state with
  | zero => rfl
  | succ count ih => exact ih (allocated none state)

