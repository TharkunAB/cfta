/-- Actual class allocation preserves both local invariants. -/
theorem suspension_safe (count : Nat) (state : State Symbol Guard) (safe : Safe state) : Safe (suspendedState count state) := by
  induction count generalizing state with
  | zero => exact safe
  | succ count ih => exact ih (allocated none state) ⟨allocation_storage none state safe.1, allocation_live none state safe.1 safe.2⟩

