/-- The source recursive-boundary test stops at Mu and explicit union records. -/
def recursiveBoundary : Value Symbol Guard → Bool
  | .mu .. | .union .. => true
  | _ => false

