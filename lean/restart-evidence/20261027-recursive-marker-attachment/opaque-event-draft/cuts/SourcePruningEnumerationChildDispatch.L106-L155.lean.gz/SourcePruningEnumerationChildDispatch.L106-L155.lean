/-- Every successful singleton cache has the actual raw row core at fixed bounds. -/
theorem singleton_core
    (checkEmpty : Bool) (representativeFuel nativeFuel p h indexFuel : Nat)
    (scs : List Suspended) (incoming : Node)
    (beforeCaller reachedCaller : Caller width)
    (before after : EnumerationExpandableIndex.Cached Symbol Constraint)
    (queries savedQueries : Queries) (fragment : Fragments.Fragment Symbol)
    (returned outer : EnumerationState.State Symbol Constraint)
    (waiting : EnumerationWaitingIndex.Waiting)
    (observed : run checkEmpty representativeFuel nativeFuel p h indexFuel scs incoming
      beforeCaller before queries =
      ((.ok (some [.ok (fragment, returned)]), reachedCaller, savedQueries, outer, waiting), some after)) :
    after.core = returned := by
  by_cases empty : incoming = .empty
  · simp [run, empty] at observed
  · cases partitioned : scs.partition (fun sc => EqualityTrie.isTerminal sc.trie) with
    | mk here descendants =>
      cases here with
      | cons first rest =>
        apply SourcePruningEnumerationCachedTerminalAdapter.singleton_core checkEmpty
          representativeFuel nativeFuel p h indexFuel first rest beforeCaller reachedCaller
          before after incoming descendants queries savedQueries fragment returned outer waiting
        simpa only [run, ite_eq_right empty, partitioned] using observed
      | nil =>
        cases cached : SourcePruningEnumerationCachedPrepare.prepareChild
            beforeCaller.checked.native.machine.heap indexFuel scs incoming before with
        | none => simp only [run, ite_eq_right empty, partitioned, cached, Prod.mk.injEq,
            reduceCtorEq, and_false] at observed
        | some rows =>
          have erasure := SourcePruningEnumerationCachedPrepare.erase_some
            beforeCaller.checked.native.machine.heap indexFuel scs incoming before rows cached
          cases prepared : SourcePruningEnumerationShallowChild.prepareChild
              (EnumGuard := Constraint) scs incoming with
          | none => simp only [prepared, Option.map_none, reduceCtorEq] at erasure
          | some action =>
            have raw := congrArg (fun result => result.1.1) observed
            simp only [run, observe, ite_eq_right empty, partitioned, prepared] at raw
            simp only [prepared, Option.map_some, Option.some.injEq] at erasure
            have rowsSame : rows.map (fun row => Except.ok (row.1, row.2.core)) =
                [.ok (fragment, returned)] :=
              erasure.symm.trans (Option.some.inj (Except.ok.inj raw))
            obtain ⟨row, singleton, mapped⟩ := List.map_eq_singleton_iff.mp rowsSame
            rcases row with ⟨childFragment, childCache⟩
            subst rows
            have cacheSame : childCache = after := by
              simpa only [run, ite_eq_right empty, partitioned, cached, Option.some.injEq] using
                congrArg Prod.snd observed
            subst after
            exact (Prod.mk.inj (Except.ok.inj mapped)).2

