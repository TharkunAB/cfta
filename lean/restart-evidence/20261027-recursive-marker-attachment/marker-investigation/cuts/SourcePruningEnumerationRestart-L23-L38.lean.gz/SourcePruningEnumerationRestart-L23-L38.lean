/-- Reject blocked work and otherwise retain the exact metadata and enumeration state. -/
def run (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing)
    (before : EnumerationExpandableIndex.Cached Symbol Constraint) :
    EnumerateM Symbol Constraint (Metadata Typing × Option Next) :=
  let next := decision stop order metadata before
  fun state => if next = some .stuck then [] else [.ok ((metadata, next), state)]

/-- Restart rejects only stuck selection and otherwise returns its exact pure decision. -/
theorem run_exact (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing)
    (before : EnumerationExpandableIndex.Cached Symbol Constraint) :
    ExceptT.run ((run stop order metadata before) before.core) =
      if decision stop order metadata before = some .stuck then []
      else [.ok ((metadata, decision stop order metadata before), before.core)] := rfl

