  obtain ⟨_run, _post, _query, _counter, _paths, _storage, _realized, _counts, _flags,
    _origin, _expandedProtected, protects, references, _pending, _bounds, _shape, _fits, _known⟩ := full
  have inside : original.core.counter < prepared.core.counter := by
    rw [core]
    exact Nat.lt_succ_self _
  have protectedRoot := protects original.core.counter inside isolated.root avoids
  have incomingAfter : IncomingAvoid original.core.counter after.core := by
    have allowedAfter := references _ isolated.incoming avoids
    intro value member sc listed same
    exact allowedAfter value member sc listed ((protectedRoot.classes sc.var).mp same)
  have afterIsolated : IsolatedPending original.core.counter handle after.core :=
    ⟨protectedRoot.root, protectedRoot.value.trans isolated.stored, incomingAfter⟩
  refine ⟨handle, r, n, p, h, k, fragments, afterCaller, after, savedQueries, final, next,
    afterRoots, result, encoded, decoded, core, retained, afterIsolated, ?_⟩
  intro residual parentFragment fuel target finished different finalized
  exact afterIsolated.through_residual_finalize afterCaller.checked.native.machine.heap residual parentFragment
    fuel target original.core.counter handle after finished different finalized

