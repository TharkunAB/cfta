# OPEN restricted-constructor elaboration repair

The original combined actual check51921 failed. Whole-batch credit is zero.
This successor is uncompiled and unfrozen. It changes only BUILD, MANY and EDGES bodies.

The repair simplifies UnionFree at known node, union and binder constructors.
It simplifies UnionFreeMany and UnionFreeEdges before conjunction projections.
It qualifies all four verification calls with InternedFreshOrdinaryFacts.
The impossible union branch ends after simplification produces False.

All nine FIRSTs, four definitions, preamble and six primitive bodies are byte-exact.
There are no new declarations, premises, helpers, definitions or limit settings.
CHANGES.json has three literal count-one body replacements.
forward.patch and inverse.patch have zero context. Python replay and inverse were checked.
No GNU replay or compiler command was run. Root owns the separate encode repair.
