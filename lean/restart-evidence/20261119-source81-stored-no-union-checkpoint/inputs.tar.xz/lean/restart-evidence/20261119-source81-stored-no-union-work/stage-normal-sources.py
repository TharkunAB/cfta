from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/tritlo/Code/mcfta')
WORK = Path(__file__).resolve().parent
BASE = ROOT / 'lean/restart-evidence'
CONTROL = BASE / '20261119-fresh-stored-no-union-normal-publication-control-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
record = lambda path: {
    'path': str(path.relative_to(ROOT)),
    'bytes': path.stat().st_size,
    'sha256': sha(path.read_bytes()),
}
assert WORK.name == '20261119-source81-stored-no-union-work'
receipt = WORK / 'SOURCE-STAGE.json'
assert not receipt.exists()
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT).strip() == b'formalize'
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT)
selection = json.loads((CONTROL / 'SELECTION.json').read_text())
normal = json.loads((ROOT / selection['parent_source_baseline']['path']).read_text())
assert len(normal) == 6302
for path, digest in normal.items():
    assert sha((ROOT / path).read_bytes()) == digest, path
private = BASE / '20261119-fresh-and-stored-no-union-final-check'
result = json.loads((private / 'results.json').read_text())
assert result['proof_credit'] and result['driver_exit'] == 0
assert not result['diagnostics'] and not result['warnings'] and not result['sorryAx']
pins = json.loads((private / 'source-pins.json').read_text())
for path, digest in pins.items():
    assert sha((ROOT / path).read_bytes()) == digest, path
assert len(pins) == 6532
source = ROOT / selection['canonical_source']['path']
raw = source.read_bytes()
assert sha(raw) == '482c45675c286cec531c830097e469f5b00990f6c0e6cb743b7468c6c1658820'
target = ROOT / 'lean/MicroCFTA' / (selection['module'] + '.lean')
assert not target.exists()
assert not (ROOT / 'lean/.lake/build/lib/lean/MicroCFTA' / (selection['module'] + '.olean')).exists()
audit = ROOT / 'lean/MicroCFTA/Audit.lean'
before = (WORK / 'Audit-BEFORE.lean.txt').read_bytes()
assert audit.read_bytes() == before
desired = (CONTROL / 'IMPORTS.lean.txt').read_bytes() + before + b'\n' + (CONTROL / 'AUDIT-PROBES.lean.txt').read_bytes()
assert sha(before) == selection['Audit_before_sha256']
assert sha(desired) == selection['Audit_after_sha256']
assert len(desired) == selection['Audit_after_bytes']
assert len(re.findall(rb'^import ', desired, re.M)) == 5299
with target.open('xb') as stream:
    stream.write(raw)
assert audit.read_bytes() == before
audit.write_bytes(desired)
paths = sorted((ROOT / 'lean/MicroCFTA').glob('*.lean'))
assert len(paths) == 6299
after = {str(path.relative_to(ROOT)): sha(path.read_bytes()) for path in paths}
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    after[name] = sha((ROOT / name).read_bytes())
assert len(after) == 6303
for path, digest in normal.items():
    if path != 'lean/MicroCFTA/Audit.lean':
        assert after[path] == digest, path
assert audit.read_bytes() == desired and target.read_bytes() == raw
snapshot = WORK / 'NORMAL-SOURCE-PINS.json'
snapshot.write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
result = {
    'status': 'SOURCE_NORMAL_STAGING_COMPLETED',
    'at': datetime.datetime.now().astimezone().isoformat(),
    'normal_Source_changed': True,
    'new_module': record(target),
    'Audit_before': record(WORK / 'Audit-BEFORE.lean.txt'),
    'Audit_after': record(audit),
    'normal_source_pins': record(snapshot),
    'source_files': 6299,
    'source_toolchain_files': 6303,
    'direct_Audit_imports': 5299,
    'old_other_Lean_files_preserved': 6297,
    'toolchain_inputs_preserved': 4,
    'private_inputs_rehashed_before_mutation': 6532,
    'git_index_empty': True,
    'new_public_theorems': 4,
    'new_private_theorems': 9,
    'new_Prop_definitions': 4,
    'definition_checks': 0,
    'normal_publication_proof_credit': False,
    'Haskell_implementation_changed': False,
}
receipt.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result))
