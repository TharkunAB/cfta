import Lean
import MicroCFTA.Audit

open Lean Elab Command

/- Note [True module owner]
Namespace prefixes can omit declarations from the same module.
Use the environment module index for each theorem.
This command records metadata. It does not prove a theorem.
-/
run_cmd do
  let env ← getEnv
  let owners : List Name := [`MicroCFTA.InternedFreshOrdinaryStoredNoUnionRecords]
  let mut records : Array Json := #[]
  for (name, info) in env.constants.toList do
    if info.isTheorem then
      let owner? := do
        let index ← env.getModuleIdxFor? name
        env.header.moduleNames[index]?
      if let some owner := owner? then
        if owners.contains owner then
          records := records.push (Json.mkObj [
            ("name", Json.str name.toString),
            ("user_name", Json.str (privateToUserName name).toString),
            ("owning_module", Json.str owner.toString),
            ("audit_eligible", Json.bool ((`MicroCFTA).isPrefixOf (privateToUserName name)))])
  liftIO <| IO.println (Json.mkObj [
    ("scope", Json.str "STORED_NO_UNION_TRUE_MODULE_OWNER_THEOREMS_METADATA_ONLY"),
    ("owners", toJson (owners.map Name.toString)),
    ("loaded_owners", toJson ((owners.filter env.header.moduleNames.contains).map Name.toString)),
    ("theorem_count", toJson records.size),
    ("theorems", Json.arr records)]).compress
