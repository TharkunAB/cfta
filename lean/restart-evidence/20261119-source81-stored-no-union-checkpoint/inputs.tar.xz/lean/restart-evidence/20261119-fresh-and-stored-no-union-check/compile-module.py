from pathlib import Path
import json, os, subprocess, sys
ROOT=Path('/home/tritlo/Code/mcfta')
RUNTIME=ROOT/'lean/restart-evidence/20261119-fresh-and-stored-no-union-check'
s=json.loads((RUNTIME/'selection.json').read_text())
module=sys.argv[1];components={c['module']:c for c in s['components']};assert module in components
source_root=RUNTIME/'source';objects=RUNTIME/'objects'
assert {p.stem for p in source_root.rglob('*.lean')}==set(components)
assert not list(source_root.rglob('*.olean'))
assert not any(p.is_symlink() for p in objects.rglob('*'))
normal=ROOT/'lean/.lake/build/lib/lean/MicroCFTA'
for name in components:assert not (normal/(name+'.olean')).exists()
env=dict(os.environ);env['LEAN_NUM_THREADS']='1'
normal_path=env.get('LEAN_PATH','');assert normal_path
roots=[objects,source_root]+[Path(p) for p in normal_path.split(os.pathsep) if p]
for name in json.loads((RUNTIME/'import-order.json').read_text()):
    if name in components:continue
    resolved=next((p/'MicroCFTA'/(name+'.olean') for p in roots if (p/'MicroCFTA'/(name+'.olean')).is_file()),None)
    assert resolved is not None and resolved.resolve()==(normal/(name+'.olean')).resolve(),name
parent=s['components'][0]['module'];parent_object=objects/'MicroCFTA'/(parent+'.olean')
if module==parent:assert not list(objects.rglob('*.olean'))
else:assert {p for p in objects.rglob('*.olean')}=={parent_object} and parent_object.is_file()
env['LEAN_PATH']=str(objects)+os.pathsep+str(source_root)+os.pathsep+normal_path
command=['lean','-j1','-DwarningAsError=true','-R',str(source_root)]
if components[module]['emit_owned_object']:command+=['-o',str(parent_object)]
command+=[str(source_root/'MicroCFTA'/(module+'.lean'))]
raise SystemExit(subprocess.run(command,cwd=ROOT/'lean',env=env).returncode)
