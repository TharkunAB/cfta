from pathlib import Path
import datetime, hashlib, json, os, re, shlex, subprocess, time
ROOT=Path('/home/tritlo/Code/mcfta')
RUNTIME=ROOT/'lean/restart-evidence/20261119-fresh-and-stored-no-union-check'
SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canonical=lambda x:(json.dumps(x,indent=2,sort_keys=True)+'\n').encode()
s=json.loads((RUNTIME/'selection.json').read_text());pins=json.loads((RUNTIME/'source-pins.json').read_text())
def verify():
    for name,expected in pins.items():assert SHA(ROOT/name)==expected,name
def cache_state():
    directory=ROOT/'lean/.lake/build/lib/lean'
    def stat(p):
        x=p.stat();y=p.lstat()
        return [str(p.resolve()),x.st_dev,x.st_ino,x.st_size,x.st_mtime_ns,x.st_mode,x.st_nlink,x.st_uid,y.st_ino,y.st_mtime_ns]
    return {str(p.relative_to(directory)):stat(p) for p in sorted(directory.rglob('*.olean'))}
verify();before=cache_state()
assert not (RUNTIME/'results.json').exists() and not (RUNTIME/'checked.json').exists()
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
cgroup=Path('/sys/fs/cgroup')/group.lstrip('/')
limits={name:(cgroup/name).read_text().strip() for name in ['memory.max','memory.high','memory.swap.max']}
assert limits==s['limits']
source_root=RUNTIME/'source';objects=RUNTIME/'objects'
parent_object=objects/'MicroCFTA'/(s['components'][0]['module']+'.olean')
assert not list(objects.rglob('*.olean')) and not list(source_root.rglob('*.olean'))
env=dict(os.environ);env.pop('LEAN_SYSROOT',None);env.pop('LEAN_PATH',None);env['LEAN_NUM_THREADS']='1'
started=datetime.datetime.now().astimezone().isoformat();deadline=time.monotonic()+s['compiler_internal_timeout_seconds']
checks=[];parent_hash=None
for component in s['components']:
    module=component['module'];log=RUNTIME/(module+'.txt')
    if checks and not checks[-1]['passed']:
        checks.append({'module':module,'status':'UNRUN: PARENT FAILED','compiler_exit':None,'passed':False,'proof_credit':False});continue
    command=['nix-shell',str(ROOT/'shell.nix'),'--run','exec lake env python3 '+shlex.quote(str(RUNTIME/'compile-module.py'))+' '+shlex.quote(module)]
    with log.open('w') as stream:
        try:
            run=subprocess.run(command,cwd=ROOT/'lean',env=env,stdout=stream,stderr=subprocess.STDOUT,text=True,timeout=max(0.001,deadline-time.monotonic()))
            code,timed_out=run.returncode,False
        except subprocess.TimeoutExpired:code,timed_out=124,True
    verify();assert before==cache_state()
    assert not list(source_root.rglob('*.olean'))
    assert not (objects/'MicroCFTA'/(s['components'][1]['module']+'.olean')).exists()
    assert set(objects.rglob('*.olean')) <= {parent_object}
    text=log.read_text()
    reports=re.findall(r"'([^']+)' (?:depends on axioms:\s*\[([^]]*)\]|does not depend on any axioms)",text,re.S)
    names=[name for name,_ in reports]
    classification={name:sorted(x.strip() for x in axioms.split(',') if x.strip()) for name,axioms in reports}
    bad=sorted({a for values in classification.values() for a in values}-{'propext','Classical.choice','Quot.sound'})
    diagnostics=len(re.findall(r'(?m)^(?:error(?:\([^\n]*\))?:|[^\n]*:\d+:\d+: error(?:\([^\n]*\))?:)',text))
    warnings=len(re.findall(r'(?m)^(?:warning(?:\([^\n]*\))?:|[^\n]*:\d+:\d+: warning(?:\([^\n]*\))?:)',text))
    emitted_ok=parent_object.is_file() if component['emit_owned_object'] else parent_object.is_file() and SHA(parent_object)==parent_hash
    passed=code==0 and not timed_out and not diagnostics and not warnings and not bad and 'sorryAx' not in text and names==[d['resolved_qname'] for d in component['declarations']] and emitted_ok
    if component['emit_owned_object'] and parent_object.is_file():parent_hash=SHA(parent_object)
    check={'module':module,'status':'PASS' if passed else 'FAILURE','compiler_exit':code,'timed_out':timed_out,'passed':passed,'proof_credit':False,'observed_qnames':names,'classification_by_qname':classification,'total_axiom_reports':len(reports),'standard_axiom_reports':sum(bool(a) for _,a in reports),'axiom_free_reports':sum(not a for _,a in reports),'nonstandard_axioms':bad,'diagnostics':diagnostics,'warnings':warnings,'sorryAx':'sorryAx' in text,'source_sha256':SHA(source_root/'MicroCFTA'/(module+'.lean')),'log_sha256':SHA(log),'owned_parent_object_sha256':parent_hash,'owned_parent_object_bytes':parent_object.stat().st_size if parent_object.is_file() else 0}
    checks.append(check)
verify();assert before==cache_state()
passed=len(checks)==2 and all(c['passed'] for c in checks)
result={'status':'FINAL TWO MODULE BATCH PASS' if passed else 'FINAL TWO MODULE BATCH FAILURE','started_at':started,'completed_at':datetime.datetime.now().astimezone().isoformat(),'checks':checks,'driver_exit':0 if passed else 1,'all_selected_statements_checked':passed,'proof_credit':passed,'new_public_theorems':4,'new_private_theorems':9,'new_definitions':4,'definition_checks':0,'definition_axiom_credit':0,'private_helpers_overlap_authored_private':9,'additional_helper_credit':0,'limits':limits,'source_pins_unchanged':True,'pins_independently_reverified':len(pins),'source_pins_sha256':SHA(RUNTIME/'source-pins.json'),'driver_sha256':SHA(Path(__file__)),'normal_Source_changed':False,'normal_cache_unchanged':True,'normal_cache_objects':len(before),'normal_cache_stat_sha256':hashlib.sha256(canonical(before)).hexdigest(),'only_owned_parent_object_written':True,'child_no_o':True,'normal_publication_selected':False,'historical_joint_assignment_proved':False,'original_root_acceptance_proved':False}
(RUNTIME/'results.json').write_bytes(canonical(result))
if passed:(RUNTIME/'checked.json').write_bytes(canonical(result))
else:
    failure={'status':'FINAL FAILURE STAGE / ZERO BATCH CREDIT','failed_module':next(c['module'] for c in checks if c['status']=='FAILURE'),'child_unrun':checks[1]['compiler_exit'] is None,'proof_credit':False,'results_sha256':SHA(RUNTIME/'results.json'),'source_pins_sha256':SHA(RUNTIME/'source-pins.json'),'owned_parent_object_sha256':parent_hash,'logs':{c['module']:c.get('log_sha256') for c in checks}}
    (RUNTIME/'FAILURE-STAGE.json').write_bytes(canonical(failure))
print(json.dumps(result),flush=True)
raise SystemExit(0 if passed else 1)
