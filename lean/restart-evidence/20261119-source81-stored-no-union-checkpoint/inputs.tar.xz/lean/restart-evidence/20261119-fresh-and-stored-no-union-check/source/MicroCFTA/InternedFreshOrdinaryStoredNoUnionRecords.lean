import MicroCFTA.InternedFreshOrdinaryNoUnionRecords
import MicroCFTA.InternedFreshOrdinaryStoredSubstitution
import MicroCFTA.InternedStoredSubstitution

namespace MicroCFTA.InternedFreshOrdinaryStoredNoUnionRecords
open InternedConstructorTemplates InternedProbeProvenance InternedNestedFacts
open InternedNestedConstruction (Syntax EdgeSyntax Outcome)
open InternedNestedProvenance (Values)
open InternedStoredSubstitution (Environment encode encodeMany encodeEdges leaves input)
open InternedFreshOrdinaryNoUnionRecords
open InternedBinderProtocol (Reference)
set_option autoImplicit false
variable {Symbol Guard : Type}

mutual
private theorem encode_union_free
    (context : List (Value Symbol Guard)) (locals : List Reference)
    (value : Value Symbol Guard) (state : State Symbol Guard)
    (available : Available state value) (inventory : NoUnionRecords state) :
    UnionFree (encode context locals value)
 := by
  rw [encode.eq_def]
  split
  · trivial
  · cases value with
    | empty => trivial
    | reference name =>
        cases locals.findIdx? (fun candidate => candidate == name) <;> trivial
    | node entry edges depth free =>
        exact encodeEdges_union_free context locals edges state
          (fun child member => available.children child member) inventory
    | union entry members depth free =>
        exact False.elim (inventory entry.key entry members depth free
          (available.resident entry rfl))
    | mu entry body depth ordinary =>
        exact encode_union_free context (.interned entry.identity :: locals) body state
          (available.children body (by simp [InternedProbeProvenance.children])) inventory
termination_by sizeOf value

private theorem encodeMany_union_free
    (context : List (Value Symbol Guard)) (locals : List Reference)
    (values : List (Value Symbol Guard)) (state : State Symbol Guard)
    (available : Values state values) (inventory : NoUnionRecords state) :
    UnionFreeMany (encodeMany context locals values)
 := by
  cases values with
  | nil => trivial
  | cons first rest =>
      exact ⟨encode_union_free context locals first state
          (available first (by simp)) inventory,
        encodeMany_union_free context locals rest state
          (fun child member => available child (by simp [member])) inventory⟩
termination_by sizeOf values

private theorem encodeEdges_union_free
    (context : List (Value Symbol Guard)) (locals : List Reference)
    (edges : List (EdgeValue Symbol Guard)) (state : State Symbol Guard)
    (available : ∀ child ∈ edges.flatMap EdgeValue.children, Available state child)
    (inventory : NoUnionRecords state) :
    UnionFreeEdges (encodeEdges context locals edges)
 := by
  cases edges with
  | nil => trivial
  | cons first rest =>
      cases first with
      | mk entry children =>
          exact ⟨encodeMany_union_free context locals children state
              (fun child member => available child (by simp [EdgeValue.children, member]))
              inventory,
            encodeEdges_union_free context locals rest state
              (fun child member => available child (by simp [EdgeValue.children, member]))
              inventory⟩
termination_by sizeOf edges

end

theorem execute_no_union [DecidableEq (EdgeKey Symbol Guard)]
    (value : Value Symbol Guard) (environment : Environment Symbol Guard)
    (state : State Symbol Guard) (facts : Facts state)
    (available : Available state value)
    (replacements : InternedStoredSubstitution.Replacements state environment)
    (inventory : NoUnionRecords state) :
    NoUnionRecords (InternedFreshOrdinaryStoredSubstitution.execute
      value environment state).state
 := by
  exact build_no_union (encode (leaves value) [] value)
    ((leaves value).map (input environment)) state facts
    (InternedStoredSubstitution.inputs_available value environment state available replacements)
    (encode_union_free (leaves value) [] value state available inventory) inventory

end MicroCFTA.InternedFreshOrdinaryStoredNoUnionRecords

#print axioms MicroCFTA.InternedFreshOrdinaryStoredNoUnionRecords.encode_union_free
#print axioms MicroCFTA.InternedFreshOrdinaryStoredNoUnionRecords.encodeMany_union_free
#print axioms MicroCFTA.InternedFreshOrdinaryStoredNoUnionRecords.encodeEdges_union_free
#print axioms MicroCFTA.InternedFreshOrdinaryStoredNoUnionRecords.execute_no_union
