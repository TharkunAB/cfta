from pathlib import Path
import datetime, hashlib, json, os, re, shlex, subprocess
ROOT=Path('/home/tritlo/Code/mcfta')
RUNTIME=ROOT/'lean/restart-evidence/20261119-fresh-and-stored-no-union-combined-repair-check'
SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((RUNTIME/'selection.json').read_text());pins=json.loads((RUNTIME/'source-pins.json').read_text())
def verify():
    for name,expected in pins.items():assert SHA(ROOT/name)==expected,name
def cache_state():
    directory=ROOT/'lean/.lake/build/lib/lean'
    def stat(p):
        x=p.stat();y=p.lstat()
        return [str(p.resolve()),x.st_dev,x.st_ino,x.st_size,x.st_mtime_ns,x.st_mode,x.st_nlink,x.st_uid,y.st_ino,y.st_mtime_ns]
    return {str(p.relative_to(directory)):stat(p) for p in sorted(directory.rglob('*.olean'))}
verify();before=cache_state()
assert not (RUNTIME/'results.json').exists() and not (RUNTIME/'checked.json').exists()
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
cgroup=Path('/sys/fs/cgroup')/group.lstrip('/')
limits={name:(cgroup/name).read_text().strip() for name in ['memory.max','memory.high','memory.swap.max']}
assert limits==s['limits']
source=RUNTIME/'source/MicroCFTA'/(s['module']+'.lean')
assert not list((RUNTIME/'source').rglob('*.olean')) and not (RUNTIME/'objects').exists()
env=dict(os.environ);env.pop('LEAN_SYSROOT',None);env.pop('LEAN_PATH',None);env['LEAN_NUM_THREADS']='1'
started=datetime.datetime.now().astimezone().isoformat()
with (RUNTIME/'compiler.txt').open('w') as stream:
    try:
        command='exec lake env lean -j1 -DwarningAsError=true -R '+shlex.quote(str(RUNTIME/'source'))+' '+shlex.quote(str(source))
        run=subprocess.run(['nix-shell',str(ROOT/'shell.nix'),'--run',command],cwd=ROOT/'lean',env=env,stdout=stream,stderr=subprocess.STDOUT,text=True,timeout=s['compiler_internal_timeout_seconds'])
        code,timed_out=run.returncode,False
    except subprocess.TimeoutExpired:code,timed_out=124,True
verify();assert before==cache_state()
assert not list((RUNTIME/'source').rglob('*.olean'))
assert not (ROOT/'lean/.lake/build/lib/lean/MicroCFTA'/(s['module']+'.olean')).exists()
text=(RUNTIME/'compiler.txt').read_text()
reports=re.findall(r"'([^']+)' (?:depends on axioms:\s*\[([^]]*)\]|does not depend on any axioms)",text,re.S)
names=[name for name,_ in reports]
classification={name:sorted(x.strip() for x in axioms.split(',') if x.strip()) for name,axioms in reports}
bad=sorted({a for values in classification.values() for a in values}-{'propext','Classical.choice','Quot.sound'})
diagnostics=len(re.findall(r'(?m)^(?:error(?:\([^\n]*\))?:|[^\n]*:\d+:\d+: error(?:\([^\n]*\))?:)',text))
warnings=len(re.findall(r'(?m)^(?:warning(?:\([^\n]*\))?:|[^\n]*:\d+:\d+: warning(?:\([^\n]*\))?:)',text))
passed=code==0 and not timed_out and not diagnostics and not warnings and not bad and 'sorryAx' not in text and names==[d['resolved_qname'] for d in s['declarations']]
result={'status':'FINAL COMBINED LEAF PASS' if passed else 'FINAL COMBINED LEAF FAILURE','started_at':started,'completed_at':datetime.datetime.now().astimezone().isoformat(),'driver_exit':code,'timed_out':timed_out,'all_selected_statements_checked':passed,'proof_credit':passed,'observed_qnames':names,'classification_by_qname':classification,'total_axiom_reports':len(reports),'standard_axiom_reports':sum(bool(a) for _,a in reports),'axiom_free_reports':sum(not a for _,a in reports),'nonstandard_axioms':bad,'diagnostics':diagnostics,'warnings':warnings,'sorryAx':'sorryAx' in text,'new_public_theorems':4,'new_private_theorems':9,'new_definitions':4,'definition_checks':0,'definition_axiom_credit':0,'private_helpers_overlap_authored_private':9,'additional_helper_credit':0,'limits':limits,'source_pins_unchanged':True,'pins_independently_reverified':len(pins),'source_pins_sha256':SHA(RUNTIME/'source-pins.json'),'source_sha256':SHA(source),'driver_sha256':SHA(Path(__file__)),'log_sha256':SHA(RUNTIME/'compiler.txt'),'normal_Source_changed':False,'normal_cache_unchanged':True,'normal_cache_objects':len(before),'compiled_objects_written':False,'no_LEAN_PATH_overlay':True,'normal_publication_selected':False,'historical_joint_assignment_proved':False,'original_root_acceptance_proved':False}
(RUNTIME/'results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
if passed:(RUNTIME/'checked.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result),flush=True)
raise SystemExit(0 if passed else 1)
