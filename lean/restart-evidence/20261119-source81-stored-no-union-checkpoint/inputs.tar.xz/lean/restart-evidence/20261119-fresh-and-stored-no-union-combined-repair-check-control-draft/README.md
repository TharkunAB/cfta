OPEN same-leaf explicit-reduction repair checker.

Root must review and freeze this controller before execution. Use manifest status `FROZEN SMALL COMBINED LEAF CHECK CONTROLLER / NOT EXECUTED` and selection status `FROZEN COMBINED SAME-LEAF CHECK / NOT EXECUTED`. Copy the preparer and supervisor unchanged to the selected Work. Run the preparer, then the supervisor through the reviewed Nix, four-GiB, zero-swap, five-minute scope.

The combined source preserves all13 FIRSTs, all four definitions, and the first six primitive proof bodies. The preparer replays the exact13 FIRST/body replacements from the original combined source. One no-o command checks all13 ordered reports. Nine private reports use the physical child module owner. Four public QNames remain exact. Four Prop definitions have no axiom or declaration-check credit. Helpers overlap the nine private laws.

The driver and supervisor change only paths from the frozen combined predecessor. The34383 namespace failure and51921 proof failure remain exact zero-credit history. Their input maps remain references and are rehashed. There is no object output, private import overlay, cache farm, normal Source change, or normal publication selection. No commands have run from this controller.
