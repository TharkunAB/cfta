# Initial heap record invariant

This is a source audit and a proof plan. It has no theorem credit.

The actual current construction uses SourceSynthesisCurrentContext.context.
SourceSynthesisCurrentConstruction.firstOrderRaw then uses the existing
termsRows/relevantRows algorithms. Every successful row has node-root syntax.
The zero-size and insufficient-size cases have empty operand lists.
The source universe body unions an arrow node with constructor nodes.
Its recursive references occur inside node children. Generalization inserts
that universe and introduces no other union. Symbol mapping preserves syntax
constructor tags. No contrary union-member root was found in this audit.

Use this precise recursive restriction: node children and binder bodies satisfy
the restriction. Every union member satisfies the restriction and has node-root
syntax. Empty and variable syntax can occur outside union-member positions.
The existing OverUniverse grammar has unrestricted union closure and does not
establish this restriction.

The private terms_facts/relevant_facts laws in
SourceSynthesisCurrentCandidateAppOperands already derive node-root shapes.
Strengthen their recursive facts rather than adding separate proofs for each
catalog row. Preserve successful selection with resolveSelection_preserves.
The context proof must use the current context and generalized annotations.

Syntax alone does not prove an ordinary returned value for an arbitrary
malformed cache. Carry genuine builder Facts. The existing makeNode_ordinary
law in EqualityLeafProjectionUnion derives ordinary readback with coherent
and linked caches and resident input edges. The actual build_verified laws
provide these facts and the intermediate availability transports.

The checked ordinary makeUnion origin lemma then excludes new union records.
A source constructor induction can combine it with the actual makeNode,
makeEdge, self-filter, and request record laws. Include pending endpoints and
allocations for children later removed by a parent. The current UnionFree
predicate excludes all union instructions and is sufficient for stored encode;
it is too strong for accepted-source initialization. Extend or generalize the
constructor proof coherently if the source restriction is adopted.

After initialization, actual intersection and warm/native execution still need
preservation and memo-result attachments. Recursive Available excludes union
descendants once the heap inventory holds. No-union preservation alone does
not prove that all historical equality constraints have one finite model.
Repeated-key clearing and fresh equality-class origins still need causal
compatibility. Do not add a future-model or historical-discharge supplier.

No Haskell implementation change or defect follows from this audit.
