from pathlib import Path
import ast, hashlib, json, re, subprocess
ROOT=Path('/home/tritlo/Code/mcfta')
BASE=ROOT/'lean/restart-evidence'
CONTROL=BASE/'20261119-fresh-stored-no-union-normal-publication-control-draft'
WORK=BASE/'20261119-fresh-stored-no-union-normal-publication-work'
SHA=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:(json.dumps(x,indent=2,sort_keys=True)+'\n').encode()
assert Path(__file__).resolve().parent==WORK.resolve() and Path(__file__).read_bytes()==(CONTROL/'prepare-publication.py').read_bytes()
bound=set()
def verify(path,expected):
    data=path.read_bytes();assert SHA(data)==(expected['sha256'] if isinstance(expected,dict) else expected),str(path)
    if isinstance(expected,dict) and 'bytes' in expected:assert len(data)==expected['bytes'],str(path)
    bound.add(path);return data
def record(row):return verify(ROOT/row['path'],row)
manifest=json.loads((CONTROL/'MANIFEST.json').read_text())
assert manifest['status']=='FROZEN THIN NORMAL PUBLICATION CONTROLLER / NOT EXECUTED'
for name,expected in manifest['files'].items():verify(CONTROL/name,expected)
bound.add(CONTROL/'MANIFEST.json')
s=json.loads((CONTROL/'SELECTION.json').read_text())
assert s['status']=='FROZEN THIN NORMAL PUBLICATION CONTROLLER / NOT EXECUTED'
assert s['entrypoint']==Path(__file__).name and s['work']==WORK.name
assert s['expected_gate_reports']==[807,13,402,807,807] and s['expected_gate_definition_checks']==[0,0,0,0,0]
assert [s[k] for k in ['new_public_theorems','new_private_theorems','new_Prop_definitions','definition_checks','additional_helper_credit']]==[4,9,4,0,0]
assert s['Nix'] and s['Lean_threads']==1 and s['warnings_as_errors'] and s['default_proof_limits']
assert s['required_outer_time_cap_minutes']==5 and s['internal_timeout_seconds']==290
assert s['limits']=={'memory.max':'8589934592','memory.high':'8589934592','memory.swap.max':'0'}
assert s['no_private_import_overlay'] and s['no_cache_copies']
runtime=BASE/s['runtime'];assert not runtime.exists()
for key in ['stage','stage_actual','normal_source_pins','Audit_before_snapshot']:assert isinstance(s[key],dict),key
stage=json.loads(record(s['stage']));actual=json.loads(record(s['stage_actual']))
assert actual['actual_terminal'] and actual['actual_terminal_exit']==0
assert stage['normal_Source_changed'] and stage['status']=='SOURCE_NORMAL_STAGING_COMPLETED'
normal=json.loads(record(s['normal_source_pins']))
assert len(normal)==s['expected_source_toolchain_pins']==6303
assert len(list((ROOT/'lean/MicroCFTA').glob('*.lean')))==s['expected_sources']==6299
for name,expected in normal.items():verify(ROOT/name,expected)
assert set(normal)=={str(p.relative_to(ROOT)) for p in (ROOT/'lean/MicroCFTA').glob('*.lean')}|{'shell.nix','lean/lean-toolchain','lean/lakefile.toml','lean/lake-manifest.json'}
old_audit=record(s['Audit_before_snapshot']);assert SHA(old_audit)==s['Audit_before_sha256']
parent=json.loads(record(s['parent_source_baseline']));assert len(parent)==6302
for name,expected in parent.items():verify(ROOT/name if name!='lean/MicroCFTA/Audit.lean' else ROOT/s['Audit_before_snapshot']['path'],expected)
record(s['parent_PUSH']);record(s['private_control_manifest']);record(s['private_driver_exit'])
checked=json.loads(record(s['private_checked']));assert record(s['private_checked'])==record(s['private_results'])
assert checked['driver_exit']==0 and checked['proof_credit'] and not checked['diagnostics'] and not checked['warnings'] and not checked['sorryAx'] and not checked['nonstandard_axioms']
assert checked['total_axiom_reports']==13 and checked['standard_axiom_reports']==11 and checked['axiom_free_reports']==2
assert checked['observed_qnames']==s['fresh_qnames']
private_pins=json.loads(record(s['private_input_map']));assert len(private_pins)==6532
assert checked['source_pins_sha256']==s['private_input_map']['sha256']
for name,expected in private_pins.items():verify(ROOT/name if name!='lean/MicroCFTA/Audit.lean' else ROOT/s['Audit_before_snapshot']['path'],expected)
for failure in s['failed_private_attempts']:
    failed=json.loads(record(failure['results']));record(failure['log']);record(failure['input_map'])
    assert not failed['proof_credit'] and failed['driver_exit']!=0 and not failure['proof_credit']
raw=record(s['canonical_source']);candidate=json.loads(record(s['candidate_manifest']))
for name,expected in candidate['files'].items():verify((ROOT/s['candidate_manifest']['path']).parent/name,expected)
assert SHA(raw)=='482c45675c286cec531c830097e469f5b00990f6c0e6cb743b7468c6c1658820'
assert json.loads(record(s['declaration_records']))==s['declarations']
for declaration in s['declarations']:
    first=record(declaration['FIRST']);proof=record(declaration['proof']);assert raw.count(first+proof)==1
    prefix='_private.MicroCFTA.'+s['module']+'.0.' if declaration['visibility']=='private' else ''
    assert declaration['resolved_qname']==prefix+declaration['user_qname']
assert len(re.findall(rb'^def ',raw,re.M))==4 and not re.search(rb'set_option\s+(maxHeartbeats|maxRecDepth|warningAsError|linter\.)',raw)
imports=(CONTROL/'IMPORTS.lean.txt').read_bytes();probes=(CONTROL/'AUDIT-PROBES.lean.txt').read_bytes();same_leaf=(CONTROL/'SAME-LEAF-PROBES.lean.txt').read_bytes()
assert imports==('import MicroCFTA.'+s['module']+'\n').encode()
assert same_leaf==''.join('#print axioms '+d['user_qname']+'\n' for d in s['declarations']).encode()
expected_audit=imports+old_audit+b'\n'+probes
assert SHA(expected_audit)==s['Audit_after_sha256'] and len(expected_audit)==s['Audit_after_bytes']
assert (ROOT/'lean/MicroCFTA/Audit.lean').read_bytes()==expected_audit
assert (ROOT/'lean/MicroCFTA'/(s['module']+'.lean')).read_bytes()==raw
assert len(re.findall(rb'^import ',expected_audit,re.M))==s['direct_Audit_imports']==5299
assert expected_audit.count(b'#print axioms ')==807
prior=json.loads(record(s['prior_normal_checked']));record(s['prior_normal_input_map'])
assert prior['all_five_gates_passed'] and prior['proof_credit']
assert [c['total_axiom_reports'] for c in prior['checks']]==[794,1,389,794,794]
old_independent=record(s['prior_independent']);assert old_independent.count(b'#print axioms ')==389 and old_independent.count(b'#check ')==300
independent=imports+old_independent+b'\n'+probes
assert independent.count(b'#print axioms ')==402 and independent.count(b'#check ')==300
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT)
ast.parse((CONTROL/'publication-driver.py.txt').read_text())
runtime.mkdir();source=runtime/'source/MicroCFTA'/(s['module']+'.lean');source.parent.mkdir(parents=True);source.write_bytes(raw+b'\n'+same_leaf)
for name,data in [('IndependentProbes.lean',independent),('check.py',(CONTROL/'publication-driver.py.txt').read_bytes()),('selection.json',canonical(s))]:
    output=runtime/name;output.write_bytes(data);bound.add(output)
bound.update([source,Path(__file__)])
(runtime/'source-pins.json').write_bytes(canonical({str(p.relative_to(ROOT)):SHA(p.read_bytes()) for p in sorted(bound)}))
print(json.dumps({'runtime':str(runtime),'gates':5,'reports':[807,13,402,807,807],'new_public':4,'new_private':9,'definitions':4,'definition_checks':0,'no_private_import_overlay':True,'no_cache_copies':True}))
