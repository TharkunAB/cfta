OPEN combined same-leaf checker.

Root must review and freeze this controller before execution. Use manifest status `FROZEN SMALL COMBINED LEAF CHECK CONTROLLER / NOT EXECUTED` and selection status `FROZEN COMBINED SAME-LEAF CHECK / NOT EXECUTED`. Root may bind its exact mathematical review. Copy the preparer and supervisor unchanged to the selected Work. Run the preparer. Run the supervisor under the reviewed Nix, four-GiB, zero-swap, five-minute outer scope.

The canonical module contains both original namespaces. The three normal imports are at the top. Both non-import bodies and all13 FIRST/proof joins remain exact. All nine private reports use the physical child-module owner prefix. The four public user QNames remain exact. Four Prop predicate definitions have zero report credit. Helpers overlap the nine private laws.

One command checks the full source with no object output. The command uses the normal Lake import path. There is no object wrapper, import overlay, or cache symlink farm. Exact reports, standard axioms, zero diagnostics, zero warnings, and zero sorryAx are required. The old34383 namespace-shadow failure and its6378 inputs remain hash-bound evidence with zero proof credit. The child was unrun in that failed batch. Source80 source bytes remain the baseline; later documentation commits do not require a different baseline.
