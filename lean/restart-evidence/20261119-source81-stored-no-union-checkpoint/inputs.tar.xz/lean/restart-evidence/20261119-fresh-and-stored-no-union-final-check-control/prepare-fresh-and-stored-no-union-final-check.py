from pathlib import Path
import ast, hashlib, json, re
ROOT=Path('/home/tritlo/Code/mcfta')
BASE=ROOT/'lean/restart-evidence'
CONTROL=BASE/'20261119-fresh-and-stored-no-union-final-check-control'
WORK=BASE/'20261119-fresh-and-stored-no-union-final-work'
SHA=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:(json.dumps(x,indent=2,sort_keys=True)+'\n').encode()
assert Path(__file__).resolve().parent==WORK.resolve()
assert Path(__file__).read_bytes()==(CONTROL/Path(__file__).name).read_bytes()
bound=set()
def verify(path,expected):
    data=path.read_bytes();assert SHA(data)==(expected['sha256'] if isinstance(expected,dict) else expected),str(path)
    if isinstance(expected,dict) and 'bytes' in expected:assert len(data)==expected['bytes'],str(path)
    bound.add(path);return data
def record(row):return verify(ROOT/row['path'],row)
def rows(value):return {x['path']:x for x in value} if isinstance(value,list) else value
manifest=json.loads((CONTROL/'MANIFEST.json').read_text())
assert manifest['status']=='FROZEN SMALL COMBINED LEAF CHECK CONTROLLER / NOT EXECUTED'
for name,expected in manifest['files'].items():verify(CONTROL/name,expected)
bound.add(CONTROL/'MANIFEST.json')
s=json.loads((CONTROL/'SELECTION.json').read_text())
assert s['status']=='FROZEN COMBINED SAME-LEAF CHECK / NOT EXECUTED'
assert s['entrypoint']==Path(__file__).name and s['work']==WORK.name
assert s['module']=='InternedFreshOrdinaryStoredNoUnionRecords' and s['runtime']=='20261119-fresh-and-stored-no-union-final-check'
assert [s[k] for k in ['expected_private_reports','expected_public_reports','new_definitions','expected_definition_checks','additional_helper_credit']]==[9,4,4,0,0]
assert s['private_helpers_overlap_authored_private']==9
assert s['Nix'] and s['Lean_threads']==1 and s['warnings_as_errors'] and s['default_proof_limits'] and s['no_o']
assert s['required_outer_time_cap_minutes']==5 and s['compiler_internal_timeout_seconds']==290
assert s['limits']=={'memory.max':'4294967296','memory.high':'4294967296','memory.swap.max':'0'}
assert s['no_private_namespace'] and s['no_LEAN_PATH_overlay'] and not s['normal_publication_selected']
runtime=BASE/s['runtime'];assert not runtime.exists()
for name,expected in json.loads((CONTROL/'KNOWN-INPUT-PINS.json').read_text())['files'].items():verify(ROOT/name,expected)
old=json.loads(record(s['failed_two_module_results']));stage=json.loads(record(s['failed_two_module_stage']))
record(s['failed_two_module_control']);record(s['failed_two_module_log'])
assert old['driver_exit']==1 and not old['proof_credit'] and old['checks'][0]['compiler_exit']==1
assert old['checks'][1]['compiler_exit'] is None and not old['checks'][1]['passed']
assert stage['child_unrun'] and not stage['proof_credit'] and stage['owned_parent_object_sha256'] is None
assert stage['results_sha256']==s['failed_two_module_results']['sha256']
assert stage['logs'][old['checks'][0]['module']]==s['failed_two_module_log']['sha256']
oldpins=json.loads(record(s['failed_two_module_input_map']))
assert len(oldpins)==old['pins_independently_reverified']==6378
assert old['source_pins_sha256']==s['failed_two_module_input_map']['sha256']
for name,expected in oldpins.items():verify(ROOT/name,expected)
record(s['failed_combined_control'])
failed=json.loads(record(s['failed_combined_results']));record(s['failed_combined_log'])
assert failed['driver_exit']==1 and failed['diagnostics']==28 and failed['sorryAx'] and not failed['proof_credit']
assert failed['log_sha256']==s['failed_combined_log']['sha256']
failedpins=json.loads(record(s['failed_combined_input_map']))
assert len(failedpins)==failed['pins_independently_reverified']==6410
assert failed['source_pins_sha256']==s['failed_combined_input_map']['sha256']
for name,expected in failedpins.items():verify(ROOT/name,expected)
lastFailure=json.loads(record(s['failed_unused_simp_results']));record(s['failed_unused_simp_log'])
assert lastFailure['driver_exit']==1 and lastFailure['diagnostics']==1 and not lastFailure['sorryAx'] and not lastFailure['proof_credit']
assert lastFailure['total_axiom_reports']==13 and not lastFailure['nonstandard_axioms']
assert lastFailure['log_sha256']==s['failed_unused_simp_log']['sha256']
lastPins=json.loads(record(s['failed_unused_simp_input_map']))
assert len(lastPins)==lastFailure['pins_independently_reverified']==6487
for name,expected in lastPins.items():verify(ROOT/name,expected)
if s['Root_math_review'] is not None:
    review=json.loads(record(s['Root_math_review']));assert review['status'].startswith('FINAL') and not review.get('proof_credit',False)
packet=BASE/s['candidate_packet'];candidate=json.loads(record(s['candidate_manifest']))
for name,expected in rows(candidate['files']).items():verify(packet/name,expected)
for name,expected in rows(json.loads((packet/'SOURCE-PINS.json').read_text())['files']).items():verify(ROOT/name,expected)
raw=record(s['source']);preamble=record(s['preamble']);assembly=json.loads(record(s['assembly']))
assert json.loads(record(s['declaration_records']))==s['declarations']
previous_declarations=json.loads(record(s['previous_combined_declarations']))
expected=record(s['previous_combined_source']);record(s['previous_combined_candidate_manifest'])
assert len(previous_declarations)==len(s['declarations'])==13
for index,(old_declaration,new_declaration) in enumerate(zip(previous_declarations,s['declarations'])):
    for key in ['user_qname','resolved_qname','visibility']:assert old_declaration[key]==new_declaration[key]
    old_first=record(old_declaration['FIRST']);new_first=record(new_declaration['FIRST'])
    old_proof=record(old_declaration['proof']);new_proof=record(new_declaration['proof'])
    assert old_first==new_first
    if index<6:assert old_proof==new_proof
    assert expected.count(old_first+old_proof)==1
    expected=expected.replace(old_first+old_proof,new_first+new_proof,1)
assert expected==raw
for component in s['repaired_components']:
    repair_packet=BASE/component['packet'];repair_manifest=json.loads(record(component['manifest']))
    for name,expected_record in rows(repair_manifest['files']).items():verify(repair_packet/name,expected_record)
bodies=[]
for component in assembly['components']:
    original=record(component['source']);prefix=component['removed_import_prefix'].encode();assert original.startswith(prefix)
    body=original[len(prefix):];assert len(body)==component['retained_body_bytes'] and SHA(body)==component['retained_body_sha256']
    bodies.append(body)
assert raw==preamble+bodies[0]+b'\n'+bodies[1]+b'\n'
priorSource=record(s['previous_linter_source'])
assert priorSource.count(b'simp only [found, UnionFree]')==1
assert raw==priorSource.replace(b'simp only [found, UnionFree]',b'simp only [UnionFree]')
assert SHA(preamble)==assembly['imports_header_sha256'] and SHA(raw)==assembly['source_sha256']
assert preamble==b'import MicroCFTA.InternedFreshOrdinaryFacts\nimport MicroCFTA.InternedFreshOrdinaryStoredSubstitution\nimport MicroCFTA.InternedStoredSubstitution\n\n'
for declaration in s['declarations']:
    first=record(declaration['FIRST']);proof=record(declaration['proof']);assert raw.count(first+proof)==1
    short=re.search(rb'(?:private )?theorem\s+([A-Za-z0-9_]+)',first)[1].decode()
    assert declaration['user_qname'].rsplit('.',1)[1]==short
    prefix='_private.MicroCFTA.'+s['module']+'.0.' if declaration['visibility']=='private' else ''
    assert declaration['resolved_qname']==prefix+declaration['user_qname']
    assert not re.search(rb'\b(?:sorry|admit|axiom)\b',proof)
assert len(re.findall(rb'^private theorem ',raw,re.M))==9 and len(re.findall(rb'^theorem ',raw,re.M))==4
assert re.findall(rb'^def ([A-Za-z0-9_]+)',raw,re.M)==[n.rsplit('.',1)[1].encode() for n in s['definition_qnames']]
assert not re.search(rb'set_option\s+(?:maxHeartbeats|maxRecDepth|warningAsError|linter\.)',raw)
fixture=verify(CONTROL/'PROBES.lean.txt',manifest['files']['PROBES.lean.txt'])
assert fixture==''.join('#print axioms '+d['user_qname']+'\n' for d in s['declarations']).encode() and b'#check' not in fixture
push=json.loads(record(s['parent_PUSH_receipt']))
assert push['source_commit']==s['parent_source_commit'] and push['checkpoint_commit']==push['remote_commit']==s['parent_checkpoint_commit']
assert push['actual_push_terminal_exit']==push['actual_remote_check_terminal_exit']==push['postpush_current_tree_verifier_terminal_exit']==0
normal=json.loads(record(s['parent_normal_source_pins']));paths={p.stem:p for p in (ROOT/'lean/MicroCFTA').glob('*.lean')}
assert len(paths)==s['expected_source_files']==6298 and len(normal)==s['expected_source_toolchain_pins']==6302
assert set(normal)=={str(p.relative_to(ROOT)) for p in paths.values()}|{'shell.nix','lean/lean-toolchain','lean/lakefile.toml','lean/lake-manifest.json'}
for name,expected in normal.items():verify(ROOT/name,expected)
assert s['module'] not in paths
order,graph,active,seen=[],{},[],set()
def visit(module):
    assert module not in active
    if module in seen:return
    active.append(module);text=raw.decode() if module==s['module'] else paths[module].read_text()
    graph[module]=re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$',text,re.M)
    for dep in graph[module]:visit(dep)
    active.pop();seen.add(module);order.append(module)
visit(s['module']);dag=json.loads((CONTROL/'IMPORT-DAG.json').read_text())
assert len(order)==dag['full_modules']==172 and len(order)-1==dag['normal_dependencies']==171
assert SHA(canonical(order))==dag['full_order_sha256'] and SHA(canonical(graph))==dag['direct_import_graph_sha256']
assert json.loads((CONTROL/'TOPOLOGICAL-ORDER.json').read_text())==order
for name,expected in json.loads((CONTROL/'SOURCE-TOOLCHAIN-PINS.json').read_text()).items():verify(ROOT/name,expected)
objects=ROOT/'lean/.lake/build/lib/lean/MicroCFTA';assert not (objects/(s['module']+'.olean')).exists()
for module in seen-{s['module']}:assert (objects/(module+'.olean')).is_file(),module
for name in ['check-driver.py.txt','run-private-with-terminal-receipt.py.txt']:ast.parse((CONTROL/name).read_text())
runtime.mkdir();source=runtime/'source/MicroCFTA'/(s['module']+'.lean');source.parent.mkdir(parents=True)
source.write_bytes(raw+b'\n'+fixture)
(runtime/'check.py').write_bytes((CONTROL/'check-driver.py.txt').read_bytes());(runtime/'selection.json').write_bytes(canonical(s))
bound.update([source,runtime/'check.py',runtime/'selection.json',Path(__file__)])
(runtime/'source-pins.json').write_bytes(canonical({str(p.relative_to(ROOT)):SHA(p.read_bytes()) for p in sorted(bound)}))
print(json.dumps({'runtime':str(runtime),'commands':1,'private_reports':9,'public_reports':4,'definitions':4,'definition_checks':0,'no_o':True,'no_import_overlay':True,'normal_Source_changed':False,'memory_GiB':4,'minutes':5}))
