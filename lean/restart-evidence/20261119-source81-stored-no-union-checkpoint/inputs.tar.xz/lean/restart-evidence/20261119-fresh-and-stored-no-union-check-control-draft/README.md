OPEN two-module no-union batch checker.

Root must review and freeze this controller before execution. Set the manifest status to `FROZEN SMALL TWO MODULE CHECK CONTROLLER / NOT EXECUTED` and the selection status to `FROZEN TWO MODULE PRIVATE CHECK / NOT EXECUTED`. Root may bind its exact mathematical review record in `Root_math_review`. Copy the preparer and supervisor unchanged to the selected Work. Run the preparer first. Run the supervisor through Nix and the reviewed outer 4 GiB, zero-swap, five-minute scope. No commands have run from this controller.

The parent source draft is mapped to `MicroCFTA.InternedFreshOrdinaryNoUnionRecords`. The parent emits one owned object under the repository runtime. The child imports that exact object and emits no object. All other imports resolve to the normal cache. No normal Source or cache file is copied or changed.

The parent has six private and three public reports. The child has three private and one public report. The four parent predicate definitions are counted separately and have zero axiom credit. Private helpers overlap the nine authored private laws. The ordered report whitelist must match exactly. Both commands must pass before the batch receives proof credit. A failed parent leaves the child unrun and writes `FAILURE-STAGE.json`. All objects and logs remain in the owned runtime for Root review.

The Source80 PUSH receipt binds the source baseline. A later documentation-only commit does not change that baseline. The preparer checks all 6302 current source and toolchain bytes. It does not require the old checkpoint to be current Git HEAD.
