from pathlib import Path
import ast, hashlib, json, re
ROOT = Path('/home/tritlo/Code/mcfta')
BASE = ROOT/'lean/restart-evidence'
CONTROL = BASE/'20261119-fresh-and-stored-no-union-check-control-draft'
WORK = BASE/'20261119-fresh-and-stored-no-union-work'
SHA = lambda b: hashlib.sha256(b).hexdigest()
canonical = lambda x: (json.dumps(x,indent=2,sort_keys=True)+'\n').encode()
assert Path(__file__).resolve().parent == WORK.resolve()
assert Path(__file__).read_bytes() == (CONTROL/Path(__file__).name).read_bytes()
bound = set()
def verify(path, expected):
    data = path.read_bytes()
    assert SHA(data) == (expected['sha256'] if isinstance(expected,dict) else expected),str(path)
    if isinstance(expected,dict) and 'bytes' in expected: assert len(data) == expected['bytes'],str(path)
    bound.add(path)
    return data
def record(row): return verify(ROOT/row['path'],row)
def rows(value):
    return {x['path']:x for x in value} if isinstance(value,list) else value
manifest = json.loads((CONTROL/'MANIFEST.json').read_text())
assert manifest['status'] == 'FROZEN SMALL TWO MODULE CHECK CONTROLLER / NOT EXECUTED'
for name,expected in manifest['files'].items(): verify(CONTROL/name,expected)
bound.add(CONTROL/'MANIFEST.json')
s = json.loads((CONTROL/'SELECTION.json').read_text())
assert s['status'] == 'FROZEN TWO MODULE PRIVATE CHECK / NOT EXECUTED'
assert s['entrypoint'] == Path(__file__).name and s['work'] == WORK.name
assert s['runtime'] == '20261119-fresh-and-stored-no-union-check'
assert [s[k] for k in ['expected_private_reports','expected_public_reports','new_definitions','expected_definition_checks','additional_helper_credit']] == [9,4,4,0,0]
assert s['private_helpers_overlap_authored_private'] == 9
assert s['Nix'] and s['Lean_threads'] == 1 and s['warnings_as_errors'] and s['default_proof_limits']
assert s['required_outer_time_cap_minutes'] == 5 and s['compiler_internal_timeout_seconds'] == 290
assert s['limits'] == {'memory.max':'4294967296','memory.high':'4294967296','memory.swap.max':'0'}
assert s['owned_parent_object'] and s['child_no_o'] and s['no_private_all_cache_symlink_farm']
assert not s['normal_publication_selected'] and s['parent_receipt_is_source_baseline_not_live_HEAD']
runtime = BASE/s['runtime']; assert not runtime.exists()
for name,expected in json.loads((CONTROL/'KNOWN-INPUT-PINS.json').read_text())['files'].items(): verify(ROOT/name,expected)
if s['Root_math_review'] is not None:
    review = json.loads(record(s['Root_math_review']))
    assert review['status'].startswith('FINAL') and not review.get('proof_credit',False)
selected = {};fixtures = {}
for component in s['components']:
    module = component['module']; packet = BASE/component['packet']
    candidate = json.loads(record(component['manifest']))
    for name,expected in rows(candidate['files']).items(): verify(packet/name,expected)
    for name,expected in rows(json.loads((packet/'SOURCE-PINS.json').read_text())['files']).items(): verify(ROOT/name,expected)
    raw = record(component['source']);preamble = record(component['preamble'])
    assert raw.startswith(preamble)
    for declaration in component['declarations']:
        first = record(declaration['FIRST']);proof = record(declaration['proof'])
        assert raw.count(first+proof) == 1
        short = re.search(rb'(?:private )?theorem\s+([A-Za-z0-9_]+)',first)[1].decode()
        assert declaration['user_qname'] == 'MicroCFTA.'+module+'.'+short
        prefix = '_private.MicroCFTA.'+module+'.0.' if declaration['visibility']=='private' else ''
        assert declaration['resolved_qname'] == prefix+declaration['user_qname']
        assert not re.search(rb'\b(?:sorry|admit|axiom)\b',proof)
    assert len(re.findall(rb'^private theorem ',raw,re.M)) == component['private_reports']
    assert len(re.findall(rb'^theorem ',raw,re.M)) == component['public_reports']
    if component['definitions'] is not None:
        definitions = record(component['definitions']);assert raw.count(definitions)==1
        assert re.findall(rb'^def ([A-Za-z0-9_]+)',definitions,re.M)==[n.rsplit('.',1)[1].encode() for n in s['definition_qnames']]
    else: assert not re.search(rb'^(?:private )?(?:def|inductive|structure|opaque|axiom) ',raw,re.M)
    assert not re.search(rb'set_option\s+(?:maxHeartbeats|maxRecDepth|warningAsError|linter\.)',raw)
    fixture = verify(CONTROL/component['probe'],manifest['files'][component['probe']])
    assert fixture == ''.join('#print axioms '+d['user_qname']+'\n' for d in component['declarations']).encode()
    assert b'#check' not in fixture
    selected[module]=raw;fixtures[module]=fixture
assert list(selected)==['InternedFreshOrdinaryNoUnionRecords','InternedFreshOrdinaryStoredNoUnionRecords']
assert [(c['private_reports'],c['public_reports'],c['new_definitions'],c['emit_owned_object'],c['no_o']) for c in s['components']]==[(6,3,4,True,False),(3,1,0,False,True)]
push = json.loads(record(s['parent_PUSH_receipt']))
assert push['source_commit']==s['parent_source_commit']
assert push['checkpoint_commit']==push['remote_commit']==s['parent_checkpoint_commit']
assert push['actual_push_terminal_exit']==push['actual_remote_check_terminal_exit']==push['postpush_current_tree_verifier_terminal_exit']==0
normal = json.loads(record(s['parent_normal_source_pins']))
paths = {p.stem:p for p in (ROOT/'lean/MicroCFTA').glob('*.lean')}
assert len(paths)==s['expected_source_files']==6298 and len(normal)==s['expected_source_toolchain_pins']==6302
assert set(normal)=={str(p.relative_to(ROOT)) for p in paths.values()}|{'shell.nix','lean/lean-toolchain','lean/lakefile.toml','lean/lake-manifest.json'}
for name,expected in normal.items(): verify(ROOT/name,expected)
assert not (set(paths)&set(selected))
order,graph,active,seen = [],{},[],set()
def visit(module):
    assert module not in active,repr(active+[module])
    if module in seen:return
    active.append(module)
    text = selected[module].decode() if module in selected else paths[module].read_text()
    graph[module]=re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$',text,re.M)
    for dep in graph[module]:visit(dep)
    active.pop();seen.add(module);order.append(module)
visit(list(selected)[1])
dag=json.loads((CONTROL/'IMPORT-DAG.json').read_text())
assert len(order)==dag['full_modules']==173 and len(seen-set(selected))==dag['normal_dependencies']==171
assert SHA(canonical(order))==dag['full_order_sha256'] and SHA(canonical(graph))==dag['direct_import_graph_sha256']
assert json.loads((CONTROL/'TOPOLOGICAL-ORDER.json').read_text())==order
assert json.loads((CONTROL/'DIRECT-IMPORT-GRAPH.json').read_text())==graph
for name,expected in json.loads((CONTROL/'SOURCE-TOOLCHAIN-PINS.json').read_text()).items():verify(ROOT/name,expected)
objects=ROOT/'lean/.lake/build/lib/lean/MicroCFTA'
for module in selected:assert not (objects/(module+'.olean')).exists()
for module in seen-set(selected):assert (objects/(module+'.olean')).is_file(),module
for name in ['check-driver.py.txt','compile-module.py.txt','run-private-with-terminal-receipt.py.txt']:ast.parse((CONTROL/name).read_text())
runtime.mkdir()
(runtime/'source/MicroCFTA').mkdir(parents=True)
(runtime/'objects/MicroCFTA').mkdir(parents=True)
for module,raw in selected.items():
    source=runtime/'source/MicroCFTA'/(module+'.lean');source.write_bytes(raw+b'\n'+fixtures[module]);bound.add(source)
for template,target in [('check-driver.py.txt','check.py'),('compile-module.py.txt','compile-module.py')]:
    output=runtime/target;output.write_bytes((CONTROL/template).read_bytes());bound.add(output)
for name,value in [('selection.json',s),('import-order.json',order)]:
    output=runtime/name;output.write_bytes(canonical(value));bound.add(output)
bound.add(Path(__file__))
(runtime/'source-pins.json').write_bytes(canonical({str(p.relative_to(ROOT)):SHA(p.read_bytes()) for p in sorted(bound)}))
print(json.dumps({'runtime':str(runtime),'commands':2,'private_reports':9,'public_reports':4,'definitions':4,'definition_checks':0,'parent_owned_object':True,'child_no_o':True,'normal_Source_changed':False,'memory_GiB':4,'whole_job_minutes':5}))
