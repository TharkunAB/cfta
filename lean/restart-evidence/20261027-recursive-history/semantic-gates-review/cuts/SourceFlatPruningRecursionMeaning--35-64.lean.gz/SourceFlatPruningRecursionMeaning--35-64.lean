theorem checkRepeated_satisfies
    (heap : InternedConstructorTemplates.State Symbol NativeGuard)
    (language : NodeLanguage Symbol) (meaning : EnumGuard → Term Symbol → Prop)
    (assignment : Nat → Term Symbol) (uv handle : Nat) (scs : List Suspended)
    (before after : EnumerationFlatState.State Symbol EnumGuard)
    (earlier : EnumerationState.State Symbol EnumGuard)
    (related : EnumerationFlatState.Related before earlier)
    (ready : EnumerationDriver.Ready uv earlier)
    (stored : earlier.values[uv]? = some (.unenumerated (some handle) scs))
    (repeated : Bool)
    (observed : Except.ok (repeated, after) ∈ ExceptT.run (checkRepeated heap uv handle scs before)) :
    EnumerationFlatState.Satisfies language meaning assignment before ↔
      EnumerationFlatState.Satisfies language meaning assignment after ∧
        (repeated = true → ∀ sc ∈ scs, Suspended.Holds assignment (assignment uv) sc) := by
  obtain ⟨fuel, stable⟩ := checkRepeated_stable related heap uv handle scs
  have rows := stable 0
  simp only [Nat.add_zero] at rows
  obtain ⟨earlierAfter, earlierObserved, afterRelated⟩ := success_left rows observed
  have beforeMeaning := EnumerationFlatState.related_satisfies related language meaning assignment
  have afterMeaning := EnumerationFlatState.related_satisfies afterRelated language meaning assignment
  cases repeated with
  | false =>
      have preserved := SourcePruningEnumerationRecursion.checkRepeated_false_satisfies heap
        language meaning assignment fuel uv handle scs earlier earlierAfter ready.safe.1.total earlierObserved
      simpa using beforeMeaning.symm.trans (preserved.symm.trans afterMeaning)
  | true =>
      have cleared := SourcePruningEnumerationRecursion.checkRepeated_true_satisfies heap
        language meaning assignment fuel uv handle scs earlier earlierAfter ready stored earlierObserved
      simpa using beforeMeaning.symm.trans (cleared.trans (and_congr afterMeaning Iff.rfl))

