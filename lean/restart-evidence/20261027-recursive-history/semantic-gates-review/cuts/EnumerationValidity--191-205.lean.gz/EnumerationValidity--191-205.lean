theorem allocation_canonical (node : Option Nat) (state : State Symbol Guard) (valid : Canonical state) :
    Canonical (allocated node state) := by
  intro value member
  rcases List.mem_append.mp member with old | fresh
  · exact valid value old
  · have same : value = .unenumerated node [] := by simpa using fresh
    simp [same, references, ValidSuspended]

/-- Fresh equality-class allocation preserves canonical stored constraints. -/
theorem suspension_canonical (count : Nat) (state : State Symbol Guard) (valid : Canonical state) :
    Canonical (suspendedState count state) := by
  induction count generalizing state with
  | zero => exact valid
  | succ count ih => exact ih (allocated none state) (allocation_canonical none state valid)

