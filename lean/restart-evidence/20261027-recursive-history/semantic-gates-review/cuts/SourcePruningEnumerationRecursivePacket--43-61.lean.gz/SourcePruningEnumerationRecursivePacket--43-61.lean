theorem captured_post (packet : Packet formulas solver inventory caller memos metadata before)
    (post : Post formulas solver next caller nextCaller final) :
    Packet formulas solver next nextCaller final metadata before :=
  ⟨post.context, packet.safe, packet.pending,
    SourcePruningEnumerationNativeBranchCompletion.cacheValid_post caller nextCaller before packet.valid post,
    packet.ordered, packet.bounded⟩

/-- Safe callback reads transport the packet to their returned core and metadata. -/
theorem callback_frame (packet : Packet formulas solver inventory caller memos metadata before)
    (updated : Metadata Typing) (after : Core) (safe : EnumerationSchedule.Safe after)
    (frame : EnumerationCompressionFrame.Frame before.core after)
    (ordered : ∃ level frontier, EnumerationOrder.Stratified after level frontier)
    (bounded : ∀ group ∈ updated.pending, SourcePruningPartialMatch.PendingBound after.counter group) :
    Packet formulas solver inventory caller memos updated (EnumerationExpandableIndex.frame after before) := by
  refine ⟨packet.context, safe, ?_,
    SourcePruningEnumerationNativeBranchCompletion.cacheValid_frame caller before after frame safe packet.valid,
    ordered, bounded⟩
  exact EnumerationPendingReplacement.frame_pending before.core after frame packet.pending

