/-- No work, blocked work, or the next dependency-safe variable. -/
inductive Next where
  | done | stuck | expand (uv : Nat)
  deriving DecidableEq, Repr

/-- An invalid ordering hint falls back to the first available variable. -/
def pickNext (preference : List Nat → Option Nat) : Option (List Nat) → Next
  | none => .done
  | some [] => .stuck
  | some (first :: rest) =>
      match preference (first :: rest) with
      | some preferred => if preferred ∈ first :: rest then .expand preferred else .expand first
      | none => .expand first

