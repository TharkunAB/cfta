  match node with
  | 0 => some .empty
  | identity + 1 =>
      match heap.nodes.issued identity with
      | none => none
      | some key =>
          match heap.nodes.table key with
          | none => none
          | some entry => if entry.identity = identity then heap.nodeRecords key else none

