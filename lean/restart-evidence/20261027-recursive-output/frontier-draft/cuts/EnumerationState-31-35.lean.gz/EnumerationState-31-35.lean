inductive UVarValue (Symbol : Type) where
  | unenumerated : Option Nat → List Suspended → UVarValue Symbol
  | enumerated : Fragment Symbol → UVarValue Symbol
  | eliminated

