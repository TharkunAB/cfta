def Correct (values : List (UVarValue Symbol)) (waiting : Waiting) : Prop :=
  ∀ uv, waiting uv = encode (total uv values)

