/-- Classify an output at the cache and metadata recorded when it was emitted. -/
def OutputOrigin (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (output : Output width Typing) : Prop :=
  match output.metadata with
  | some metadata => SourceFlatPruningRestart.decision stop order metadata output.cache = none
  | none => SourceFlatPruningRestart.candidates output.cache = []

