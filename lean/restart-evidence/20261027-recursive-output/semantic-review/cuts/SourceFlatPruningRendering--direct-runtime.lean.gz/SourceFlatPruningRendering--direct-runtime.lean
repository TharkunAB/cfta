def expandFragment (heap : InternedConstructorTemplates.State Symbol NativeGuard) (marker : Symbol) :
    Nat → Fragment Symbol → Action Symbol EnumGuard (Term Symbol)
  | 0, _ => failure .fuelExhausted
  | fuel + 1, .node symbol children => do
      pure (.node symbol (← children.mapM (expandFragment heap marker fuel)))
  | fuel + 1, .hole uv => do
      match ← getValue uv with
      | .enumerated fragment => expandFragment heap marker fuel fragment
      | .unenumerated (some handle) _ =>
          match lookupNode heap handle with
          | none => failure .unresolvedReference
          | some value =>
              if MergedOrdinaryHeight.recursiveBoundary value then pure (.node marker [])
              else failure .unfinishedFragment
      | _ => failure .unfinishedFragment

/-- Render a stored root and retain the source rejection branches. -/
def expandUVar (heap : InternedConstructorTemplates.State Symbol NativeGuard) (marker : Symbol)
    (fuel uv : Nat) : Action Symbol EnumGuard (Term Symbol) := do
  match ← getValue uv with
  | .enumerated fragment => expandFragment heap marker fuel fragment
  | .unenumerated (some handle) _ =>
      match lookupNode heap handle with
      | none => failure .unresolvedReference
      | some value =>
          if MergedOrdinaryHeight.recursiveBoundary value then pure (.node marker []) else reject
  | _ => reject

/-- Render the root and all residuals at the same native heap. -/
def render (heap : InternedConstructorTemplates.State Symbol NativeGuard) (marker : Symbol)
    (fuel uv : Nat) : Action Symbol EnumGuard (Term Symbol × List (EnumGuard × Term Symbol)) := do
  let term ← expandUVar heap marker fuel uv
  let pending ← (← get).obligations.mapM fun obligation => do
    pure (obligation.1, ← expandFragment heap marker fuel obligation.2)
  pure (term, pending)

