UNTESTED: actual ordinary child bucket-write ancestry candidate

Created 2026-10-28 20:55:43 CET. No compiler, native execution, Git, network, board or repository write. Earlier frozen areas remain unchanged.

Candidate

../candidate-v1/MicroCFTA/SourcePruningEnumerationCachedOrdinaryAncestry.lean
Public export: MicroCFTA.SourcePruningEnumerationCachedChild.prepareOrdinary_ancestry.
Explicit argument order: aligned, observed. All heap, fuel, value, bucket, cache and fragment indices are implicit.

The only original structural premise is counter=values.length at before. The only point observation is the actual prepareOrdinary heap fuel scs value before=some(fragment,after). The theorem does not supply or assume a future completion of another operation.

Exact proposed result

- fragment is .hole at the original counter.
- The returned counter is original counter+1.
- Original expansionAncestry is unchanged.
- An actual encoded handle witnesses the FINAL raw pending value at the fresh slot, with bucket=scs.
- Each original key at slot<before.counter remains at that same slot after the actual write.
- Each original expansion key is in the returned fresh slot's recursionAncestry.

The final raw bucket is scs. It is not merely the allocation's initial empty bucket. Alignment is used to establish a real allocated raw slot and then the final List.set witness. No additional native Heap, Context, semantic model, language equivalence, finite key universe or termination supplier is used. Raw storage alone does not claim a live representative or scheduled candidate, and encodeNode alone does not claim native Available or decoding equality.

Actual proof path

1. Inspect the actual prepareOrdinary observation. A non-node input cannot return the observed pair. A terminal suspended trie also cannot return that pair.
2. Extract the actual encodeNode result, the actual CachedChild.allocate pair and the actual writeSlot result. The returned fragment/cache pair identifies the final after directly.
3. Apply the installed checked allocate_ancestry to the ORIGINAL alignment and actual allocation observation. Keep its exact returned fresh name, counter, expansion ancestry, raw allocation slot and bounded old-slot/fresh-key membership facts.
4. The private writeSlot_core lemma follows its actual old-slot read and the actual NativeIndex.write. It derives the exact returned core as the allocated core with the requested raw values.set. The writer also updates waiting counts and the candidate flag; its actual core update retains counter and both ancestry fields.
5. Transfer the allocation ancestry facts through THAT exact final core. The allocation raw witness supplies the in-range index required by List.getElem?_set_self. This yields the final inherited-bucket storage witness.

Thus the candidate covers the previously missing subsequent ordinary write. It is not another allocation-only wrapper. It does not infer any field from a forward semantic Post rule.

Scope limits

The premise is an actual Option.some pair from prepareOrdinary, rather than a generic outer success or a raw list. None results, structural Empty/reference/Mu/Union inputs and terminal-trie guards do not meet this local observed-pair premise. Rejection/missing cache/stopped raw rows at ChildDispatch remain separate; this theorem asserts no stability or resource property for them.

The original slot bound is explicit: old-key retention applies only for slot<before.counter. There is no assertion about arbitrary unallocated ancestry indices. The fresh conclusion is tied to the original counter and the exact output fragment.

No full shallow-child/ChildDispatch trace, whole head, global history, future finite-key bound or termination theorem is claimed. Existing checked allocation is imported unchanged. Root alone will compile and validate the new candidate.

Evidence

The 68-line candidate is immutable and UNTESTED here. It contains one public point theorem and one private actual-write core helper, with no runtime definition, sorry/admit, custom axiom, native_decide, budget change or linter suppression. source-manifest.json preserves the whole checked allocation/assimilation ancestry sources, exact runtime cuts and complete literal new declaration. It records source hashes and read scopes. No earlier frozen file was changed.
