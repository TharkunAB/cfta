# Completed-head projection attachment

Time: 2026-10-28 21:05 CET.
Status: UNTESTED. Root owns compilation and repository integration.

The candidate adds one theorem:
`MicroCFTA.SourcePruningEnumerationNativeHookResources.CompletedHeadReceipt.projection_heap`.
All data indices are implicit. The two explicit premises are the supplied actual
`CompletedHeadReceipt` and projection of its original caller heap. The conclusion
is projection of that receipt's exact reached caller heap.

The source is
`candidate-v1/MicroCFTA/SourcePruningEnumerationCompletedHeadProjectionHeap.lean`.
It has 62 lines and 3,890 bytes. Its SHA256 is
`ac9e8b9eef86a37161e745ffaa2450d8b37ca28890386e1bc76d1c510eaed0ea`.

## Exact meaning and scope

`ProjectionHeap` abbreviates `SourceEqualityAnnotationHeap.Heap` for the predicate
`fun constraint => SourcePruningEnumerationConstraint.project constraint ≠ none`.
The heap definition quantifies over physical `edgeRecords` keys. Each such key's
constraint must project. This property is stronger than a statement about one
chosen edge or one reachable child.

The theorem uses the actual receipt type in `HeadAdmission.lean`, in the
`NativeHookResources` namespace. It does not convert a prepared receipt into that
type. It requires the original caller projection explicitly. The bare original
`Packet` does not supply this predicate on physical edge keys.

The existing supplied receipt retains its full original admission and exact
completed execution. Its later `post`, `captured`, `completed`, `bounded` and
`known` fields are not used to infer projection. No reached heap, future child
support, model, source/prepared-parent equality or arbitrary forward `Post`
invariant is an added premise.

This is a property of an actual supplied completed head. The theorem does not
produce a head or a recursive output. It makes no whole-driver, coverage,
termination, semantic language or Haskell correspondence claim. It does not
extend the native-error endpoint scope of the captured observer.

## Proof route

1. Extract the original handle, decoded ordinary parent and selected edge from
   `head.admission.source`.
2. Extract original roots, realized pending handles, waiting counts and candidate
   flags from `head.admission.packet.valid`. Use the original packet context.
3. Apply `EnumerationReferences.pending_inputs` to the original packet's pending
   property and stored pending slot.
4. Extract the literal projection witness from `head.projected`.
5. Rewrite the original `edgeCost` reservation with `head.allowed` and that
   projection witness. This gives the exact `SelectedEdge.cost` reservation.
   This is the same reservation rewrite used by the existing checked
   `CompletedHeadReceipt.carriers` proof.
6. Apply `CapturedEdge.run_projection_heap` with those original inputs, original
   projection and the receipt's `bound` in each of the five fuel positions.
7. Specialize `head.running` at zero. Simplify `bound + 0` and rewrite the literal
   run in the captured observer. Its completed branch is the required reached
   heap predicate.

The proof uses no separate existential completion producer and no common-fuel
alignment. The existing receipt already supplies the literal run at its bound.

## Exact dependency and read scope

The captured observer was read whole from the installed source, then copied and
read whole from the copy. Its public argument order matches the original
`CapturedEdgeResources.complete_with_history_resources` through `known`, followed
by `originalProjection` and explicit `r n p h k`.
The copied observer has 87 lines and 5,359 bytes. Its SHA256 is
`851431e7aaad8f2c2cd0ae5e9b65e3c4cc7fbb3a318d73e75f3f9389df6b2e9f`.
It concludes projection for literal completed returns and stopped outer `.ok`
returns. The candidate uses its completed branch only.

Six source files were read whole. Their copies contain 837 lines and 55,667 bytes:

- `SourcePruningEnumerationHeadAdmission.lean`.
- `SourcePruningEnumerationCapturedEdgeResources.lean`.
- `SourcePruningEnumerationCapturedEdgeProjectionHeap.lean`.
- `SourcePruningEnumerationCompletedHeadArity.lean`.
- `SourcePruningEnumerationRecursivePacket.lean`.
- `SourcePruningEnumerationHeadReceiptCarriers.lean`.

Three exact source cuts were read and copied. They contain 112 lines and 6,422
bytes. The rest of those files was not read semantically for this task:

- `SourcePruningEnumerationNativeBranchResources.lean`, lines 1 through 53.
  This includes the complete `edgeCost` definition.
- `EnumerationReferences.lean`, lines 338 through 365.
  This includes the complete `pending_inputs` theorem.
- `SourceEqualityAnnotationHeap.lean`, lines 1 through 31.
  This includes the complete `Heap` definition.

`manifest-v1.json` records every copied input, source path, whole-source hash,
literal cut and copied-byte hash. It distinguishes whole reads from cuts.

## Validation and freeze

The candidate was read back whole. No compiler, build, native evaluator, Git,
network or board action was run. No repository file was written. No Haskell fix
was made or identified. Root must check the candidate and its dependency.

Candidate v1 and the source copies are immutable. Any compiler repair must use a
separate version. This report and its manifest close this bounded task.
