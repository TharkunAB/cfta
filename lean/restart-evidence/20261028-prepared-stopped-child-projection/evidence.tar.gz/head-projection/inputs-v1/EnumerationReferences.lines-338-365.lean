    (fresh_separate before safe held inside) graph fuel).1 scs node before after fragment safe (Nat.le_refl _) incoming inputs bounded success
  have frame := (enumeration_protected graph fuel).1 scs node held before after fragment safe inside root bounded inputs success
  intro value member sc listed same
  exact allowed value member sc listed ((frame.classes sc.var).mp same)

/-- Every stored suspended reference avoids all expanded slots. -/
def PendingReferences (state : State Symbol Guard) : Prop :=
  ∀ held fragment, state.values[held]? = some (.enumerated fragment) → IncomingAvoid held state

/-- A stored pending payload inherits the state's avoidance of every expanded slot. -/
theorem pending_inputs (state : State Symbol Guard) (pending : PendingReferences state)
    (uv : Nat) (node : Option Nat) (scs : List Suspended) (stored : state.values[uv]? = some (.unenumerated node scs)) :
    InputsPending state scs := by
  intro held fragment expanded
  exact pending held fragment expanded _ (List.mem_of_getElem? stored)

/-- The actual child traversal preserves pending-reference targets. -/
theorem enumerateNode_pending (graph : Graph Symbol Guard) (fuel node : Nat) (scs : List Suspended)
    (before after : State Symbol Guard) (fragment : Fragment Symbol) (safe : Safe before)
    (pending : PendingReferences before) (inputs : InputsPending before scs)
    (bounded : ∀ sc ∈ scs, sc.var < before.counter)
    (success : Success (enumerateNode graph fuel scs node) before fragment after) : PendingReferences after := by
  intro held storedFragment stored
  have original := (enumeration_origin graph fuel).1 scs node before after fragment success held storedFragment stored
  obtain ⟨inside, root⟩ := enumerated_root before safe held storedFragment original
  exact enumerateNode_incoming graph fuel node held scs before after fragment safe inside root (pending held storedFragment original)
    (inputs held storedFragment original) bounded success

