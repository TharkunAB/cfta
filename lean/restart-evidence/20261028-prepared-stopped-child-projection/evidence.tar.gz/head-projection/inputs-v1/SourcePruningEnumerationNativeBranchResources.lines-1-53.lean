import MicroCFTA.SourcePruningEnumerationNativeBranchCompletion
import MicroCFTA.SourcePruningEnumerationCapturedEdgeResources

/-!
# Original resources through ordered native alternatives

Each alternative uses the same captured enumeration cache.
Its actual returned caller and queries pass to the next alternative.
The original projected buckets determine every reserved mixed query step.
Each processed receipt retains bounds for its own exact selected-edge prefix.
-/
namespace MicroCFTA.SourcePruningEnumerationNativeBranchCompletion
open EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationDependencies
open InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes SourcePruningEnumerationObservation
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Context Post)
open SourcePruningEnumerationNativeBranches (advance)
open SourcePruningEnumerationIncomingReservation (Seed Reserved)
open SourceCurrentConstrainedCapGeneratedQueryResources (Fits)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Receipt" => SourcePruningEnumerationSelectedEdge.Result
local notation "Result" => SourcePruningEnumerationNativeBranches.Result
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
local notation "reservationAdvance" => SourcePruningEnumerationIncomingReservation.advance
variable {bits : Nat}

/-- Count the original projected child cost of one actual supported alternative. -/
noncomputable def edgeCost (scs : List Suspended) (start : Nat) (edge : EdgeValue Symbol Constraint) : Nat :=
  if arityAllows edge.children.length scs then
    match SourcePruningEnumerationConstraint.project edge.entry.key.constraint with
    | none => 0
    | some (tries, _) => SourcePruningEnumerationSelectedEdge.cost edge scs start tries
  else 0

/-- Count alternatives in their original order, including duplicate entries. -/
noncomputable def cost (scs : List Suspended) (start : Nat) : List (EdgeValue Symbol Constraint) → Nat
  | [] => 0
  | edge :: rest => edgeCost scs start edge + cost scs start rest

variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Original resources derive one actual native alternative and its complete receipt. -/
theorem head_complete_resources
    (seed : Seed)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
