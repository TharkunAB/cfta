"""Retain prior document bytes after the verified prepared-head update."""
from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path('/home/tritlo/Code/mcfta')
AREA = Path('/tmp/mcfta-prepared-stopped-child-projection-20261028')
now = datetime.datetime.now().astimezone().strftime('%Y-%m-%d %H:%M %Z')
source = json.loads((AREA / 'source-head.json').read_text())['head']
board = json.loads((AREA / 'board-verified.json').read_text())
assert board['status'] == 'pass' and board['sequence'] == 707
assert json.loads((AREA / 'source-push.json').read_text())['head'] == source
note_path = 'lean/notes-current-prepared-head-projection.md'
note = f'''# Current actual original and prepared head projection

Verified update: {now}.
Source: `{source}` on `formalize`, verified at the remote.
The full formalization goal remains active.

Actual stopped child traversal, selected edges, captured finalization and both
original and prepared completed-head receipts now derive projectability at
their exact returned native callers. Each theorem starts with the original
local input gates and the original local ProjectionHeap. It adds no future
heap, semantic Context or model supplier.

Projectability means that each resident native edge constraint has a supported
SourcePruningEnumerationConstraint.project result. It is a structural property.
It does not imply a satisfying model, a discharged result or an emitted output.
Bare Packet, Fits, Known, forecast alphabet membership and conditional arity
do not imply the original whole ProjectionHeap.

## Target and strongest semantic claim

The top-level target is agreement between intended CFTA language semantics and
the optimized interned implementation. Every emitted value must have the
original source meaning. Search must reach each permitted model at a finite
bound under the required policies. Public language operations and count, rank,
unrank and sample integration remain in scope. Preserve the older constructor
and equality work as secondary targets.

The strongest semantic results remain conditional. Checked rendered outputs
that satisfy the fixed-PCS and whole-Discharged conditions have the original
native root meaning and satisfy the original suspended constraints. At fixed
work fuel and other inputs, increased recursive depth retains every earlier
full output record in order. This includes outputs retained by stopped runs.

The original finite prepared worker retains its explicit resource, history,
canonical and arity certificates. Earlier child-prefix theorems derive each
actual next full Context/Memos, cache invariants and untouched suffix admission.
This update derives the same exact caller's projection through the final
stopping child, selected-edge completion, captured finalization and a supplied
actual completed head. Neither result proves output existence or completeness.

## Seven new modules

The new source has 556 lines and 34,845 bytes. It adds seven public proof
theorems, no runtime definitions and one private proof helper. Earlier producer
declarations and all prior non-Audit sources remain unchanged.

1. SourcePruningEnumerationTraversalStoppedProjectionHeap exports
   TraversalCompletion.stopped_projection_heap. An actual stopped traversal
   supplies its consumed Trace, untouched suffix and literal stopping child.
   The earlier prefix theorem derives that child's actual input Context,
   resources, cache admissions and ProjectionHeap. The child observer derives
   the same reached caller's projection. Raw Option and optional cache values
   remain unrestricted. This covers outer-success absent actions and caches.
   It does not claim preservation for an arbitrary outer native error.

2. SourcePruningEnumerationCachedOrdinaryAncestry exports
   CachedChild.prepareOrdinary_ancestry. Actual successful prepareOrdinary,
   with original counter/list alignment, returns the original fresh hole,
   increments the counter once and stores the actual encoded handle with the
   exact supplied suspended bucket. Actual writeSlot retains old allocated-slot
   key membership and gives the fresh slot the original expansion keys.
   Expansion ancestry stays unchanged. The one private writeSlot_core theorem
   proves that native slot writing changes only core.values. The theorem does
   not derive list equality of ancestry, native availability or a finite key set.

3. SourcePruningEnumerationSelectedEdgeProjectionHeap exports
   SelectedEdge.run_projection_heap. It retains the old selected-edge producer
   gates through Known and adds the original ProjectionHeap and five actual
   primitive bounds. It derives projection at actual complete and stopped
   outer-success callers. It derives the original child inputs once and keeps
   their actual staged order. Other result branches have proposition True.
   That proposition makes no claim about those branches.

4. SourcePruningEnumerationCapturedEdgeProjectionHeap exports
   CapturedEdge.run_projection_heap. The old original captured gates remain.
   The original stored handle and actual lookup identify the same available
   closed source parent. The selected-edge theorem supplies projection.
   Finalize returns a cache and reuses the exact native Caller and Queries.
   Actual complete and stopped outer-success returns retain projection.
   Absent finalization and other excluded branches have proposition True.

5. SourcePruningEnumerationCompletedHeadProjectionHeap exports
   NativeHookResources.CompletedHeadReceipt.projection_heap. The actual
   original receipt and its original input ProjectionHeap are the explicit
   premises. Original admission fields derive child input gates and the exact
   original edge reservation. The proof specializes the captured observer at
   the receipt's actual bound and rewrites its literal running observation.
   Projection is derived at that receipt's exact reached caller.

6. SourcePruningEnumerationCapturedPreparedProjectionHeap exports
   CapturedEdge.run_prepared_projection_heap. This separate theorem retains
   every old prepared captured gate. The source stored handle stays separate
   from the prepared parent. It uses that parent's own Available, Closed and
   selected facts. No decode equation identifies it with the stored source.
   Actual captured finalization preserves the same reached caller as above.
   It does not establish source/prepared language equivalence.

7. SourcePruningEnumerationPreparedHeadReceiptProjectionHeap exports
   PreparedNativeHookResources.CompletedHeadReceipt.projection_heap. This is
   the distinct prepared receipt type. It uses its original packet, stored
   source, separate parent admissions and literal running field. Its explicit
   premises are the actual prepared head and the original input projection.
   It derives projection at this same head's exact reached caller. No original
   receipt cast, Failure cast or future invariant premise is used.

## Callback and whole-producer boundary

Actual Recursive.continueWith and PreparedRecursive.continueWith run recordTypes
on enumeration data and metadata. Recording itself keeps the same native Caller
and Queries. The completed-head projection therefore has the exact callback-
entry type without a new wrapper. A false callback passes this same caller into
the actual recursive continuation. That later call can change the native heap.

Each new head theorem starts at the input of THIS supplied head. It does not
carry the whole driver's initial invariant through earlier selected-entry
preparation. The full finite producer must derive projection at each actual
head input, each returned recursive caller and each next ordered sibling.
Aggregate completion with no outputs must also retain projection. A property
of emitted output packets alone cannot cover that case.

The next source audit uses the existing finite arity/resource induction as a
structural guide. ArityOrigins.Fits is conditional on successful projection.
It cannot replace ProjectionHeap. SourceEqualityAnnotationExposure.nodeEdges_heap
can retain a general annotation across selected-prefix exposure from original
readiness, availability and closure. A source-only next candidate is being
prepared separately. It is not checked evidence for this checkpoint.

## Biggest remaining gaps

The principal semantic gap is actual model-preserving output emission and a
finite recursive depth derived from the original source. The depth must cover
all preceding ordered allocating callbacks and the chosen continuation.
Stable completed results and ordered output prefixes do not derive that depth.
A reservation indexed by a requested depth does not derive it either.

The immediate proof work is actual selected-entry preparation and finite
recursive-return projection. Use original gates and actual induction. Do not
add a top-level future-heap, future-step or model-preservation supplier as a
replacement for that proof. Then retain the chosen original model through
prepared heads, child calls, finalization, callbacks and actual emission.

The original finite key universe and inventory budget remain open. Local
assimilation, allocation and ordinary write ancestry do not supply the global
bound through all merges, fresh own tries and recursive callbacks. Complete
selector/policy coverage, semantic origin, public input/acceptance adapters and
physical optimized Haskell correspondence also remain open. Count, rank, unrank
and sampling have no new integration proof here.

DONE does not imply Discharged. Intended partial outputs remain in scope.
The earlier measure examples still lack a full admitted Context/Trace replay.
No new admitted all-depth runtime counterexample is established here.

## Validation and preserved failures

All seven final modules and Audit pass exact strict Lean 4.34.1 checks with
warningAsError and linter.all. Audit passes 4,532 jobs and checks axiom
dependencies of 81,692 theorems. The compiler matrix has 21 serial commands:
18 pass and three original Lean proof attempts fail. All final checks pass.
Each command measures memory.max/high at 4 GiB and swap.max at zero.

The stopped proof's first candidate used the reserved binder prefix. Its repair
renames that binder without changing the intended contract. The selected proof
adds cost unfolding to the same reservation simplification. The captured proof
repairs nested result case analysis and Option.map reduction. It keeps the same
exported declaration. All three original candidates, complete diagnostics and
separate repaired sources remain in evidence. No proof budget, custom axiom,
native proof evaluation axiom or linter suppression was added. An unchanged old
module retains its old replay warning.

Public readback contains 715 theorem signatures and axiom lists plus the same
60 definition bodies. It has 3,156,168 bytes. Its SHA-256 is
f9a0b9f2904ae49acb61ea00abcc0455a88213efa99b657be5550d627c11a2db.
The prior 3,128,821 bytes are an exact prefix. The complete new 27,347-byte
suffix was read. New axioms are subsets of propext, Classical.choice and
Quot.sound. No runtime definition is added.

All 4,524 earlier non-Audit Lean, 373 stronger-source and 817 Haskell/Cabal hashes
remain unchanged. Audit retains its exact old body after seven new imports.
Every one of the 16 earlier document bodies remains an exact suffix after the
verified current header. The new status note makes 17 final documents.
Complete reviews retain exact hashes and honest whole-file or literal-cut scope.
Historical UNTESTED labels remain as written; compiler-matrix.json and
final-proof-sources.json identify the final checked source and outcomes.

## Haskell and external repair record

No Haskell source changed. No Haskell build, test or benchmark ran. No new
Haskell defect or fix was established. The three repairs affect Lean proofs
only. They require no external Haskell change. Root FINDINGS.md retains every
earlier Haskell repair and external follow-up record after its current header.

## Restart

Complete evidence is in
lean/restart-evidence/20261028-prepared-stopped-child-projection/.
It includes every regular file in the sealed proof area without a filter.
Keep /tmp/mcfta-prepared-stopped-child-projection-20261028 and reconstructed
evidence immutable after sealing. Continue in the separate writable
/tmp/mcfta-prepared-finite-projectability-20261028 area. Its source-only finite
audit and any candidate are next work, not checked results in this checkpoint.

Board sequence {board['sequence']} has post ID {board['post_id']}.
Author, content and metadata have exact verified readback. Four focused source
commits are pushed. Documentation and complete evidence follow as separate
commits. Publication verification follows outside the frozen area.

Read NEXT-PROMPT.md, HANDOFF.md and FINDINGS.md. Refresh upstream. Preserve every
proof, counterexample, repair and marked draft. Keep the optimized interned core.
Normal pushes to the authorized formalize branch remain authorized. The full
goal is ACTIVE. Continue without asking whether to continue.
'''
target = ROOT / note_path
assert not target.exists()
target.write_text(note)
records = json.loads((AREA / 'prior-documents.json').read_text())
assert len(records) == 16
for record in records:
    path = ROOT / record['path']
    old = (AREA / 'prior-document-bodies' / record['path']).read_bytes()
    assert path.read_bytes() == old
    prefix = f'''# Verified original and prepared head projection: {now}

Source: `{source}` on formalize; pushed and verified.
Read lean/notes-current-prepared-head-projection.md from the repository root.
Every earlier document byte follows this update unchanged.

Actual stopped child traversal, selected edges, captured finalization and both
original and prepared completed-head receipts derive projectability at the exact
returned native caller from original local gates and original ProjectionHeap.
Prepared parents keep their own Available/Closed facts. Their source stored
handle stays separate. No future invariant or model supplier is added.
Actual ordinary allocation plus writeSlot retains original-slot key ancestry
and gives the fresh slot original expansion keys. No finite key bound follows.

Callback recording keeps the same caller. Whole-driver selected preparation,
recursive returns including no-output completion, and ordered next siblings
still require projection transport. Arity conditional on projection cannot
replace whole ProjectionHeap. The next separate source audit follows the
existing finite arity induction. It is not checked evidence for this update.

Strongest semantics remains conditional rendered soundness under fixed-PCS and
whole-Discharged, with ordered output-prefix retention at larger recursive depth.
Main gaps: actual model-preserving emission, source-derived finite depth across
preceding allocating callbacks and the continuation, global key/inventory budget,
full policy/origin/public APIs and optimized Haskell correspondence. DONE does
not imply Discharged. Intended partial outputs remain in scope.

Seven modules add seven public theorems, zero runtime definitions and one private
proof helper. Eight exact final strict sources pass. Audit: 4,532 jobs/81,692
dependencies. Public: 715 theorems/60 definitions, 3,156,168 bytes; the prior
3,128,821 bytes remain an exact prefix. The 21-command matrix has 18 passes and
three preserved proof failures. All final checks pass at measured 4 GiB and zero
swap. The repairs affect binder syntax, cost unfolding and nested Option/match
proof reduction. Original contracts remain. All 4,524 prior non-Audit Lean,
373 stronger-source and 817 Haskell/Cabal hashes remain unchanged.

No Haskell source changed, no Haskell check ran and no new Haskell defect/fix was
established. The three Lean proof repairs require no Haskell change. FINDINGS
retains every earlier external Haskell repair record. Board sequence 707 has
verified author, content and metadata readback. Complete evidence:
lean/restart-evidence/20261028-prepared-stopped-child-projection/.

Preserve all proof, counterexample, repair and marked draft bytes. Keep sealed
evidence immutable. Continue in a new writable area. The full goal remains ACTIVE.
Normal formalize pushes remain authorized. Continue without asking to continue.

'''
    path.write_bytes(prefix.encode() + old)
paths = [record['path'] for record in records] + [note_path]
final = []
for relative in paths:
    data = (ROOT / relative).read_bytes()
    final.append(dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    target = AREA / 'final-document-bodies' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
for record in records:
    assert (ROOT / record['path']).read_bytes().endswith(
        (AREA / 'prior-document-bodies' / record['path']).read_bytes())
(AREA / 'final-documents.json').write_text(json.dumps(final, indent=2) + '\n')
print(json.dumps(dict(prior_exact_suffixes=len(records), final_documents=len(final))))
