# Actual stopped traversal projection observer

Date: 2026-10-28T20:58:52+01:00.

The original 86-line draft was delivered as UNTESTED. No compiler or native evaluation ran in this child. Root found a reserved-identifier parser error and made an alpha-equivalent repair. The copied root default log now reports a successful build. This report preserves the original candidate, exact diagnostic, and separate root repair.

## Original gates and exact stopping observation

Module: `SourcePruningEnumerationTraversalStoppedProjectionHeap`.

Theorem: `TraversalCompletion.stopped_projection_heap`.

Every original argument of `TraversalCompletion.complete_with_fragments_resources` is retained. A literal signature comparison passes after restoring the old theorem name. The new inputs are the original caller's projection heap and an actual stopped observation at arbitrary supplied representative/native/Empty/index bounds.

The original gates include Context, Safe, representative roots, waiting counts, candidate flags, pending realization, every input's original availability/closure/variable bounds/pending admission, Fits, original mixed reservation, and Known. No original gate is dropped or replaced with a later heap or model.

The actual return is `.stopped completedPrefix (.ok result, afterCaller, savedQueries, outer, waiting) candidate`. Both `result : Option Raw` and `candidate : Option Cached` are unrestricted. The observer does not require a cache, an encoded action, a successful raw singleton, or any emitted output. The target is projection at that exact returned `afterCaller`.

## Actual receipt route

Existing `stopped_trace` extracts the actual consumed trace, exact stopping child call, and original decomposition `inputs = consumed ++ (stoppingInput :: remaining)`.

That original decomposition rewrites only the original genuine-input and reservation premises. The checked prefix theorem consumes the actual trace with the stopping input and remaining inputs untouched. It derives the actual current Inventory, full Memos, Post, exact query endpoint, Safe core, roots/counts/flags, pending realization, original stopping input admission, current Fits/Known, remaining reservation, and current projection heap.

The original stopping input admission derives its actual availability, closure, variable bounds, and pending references. The remaining reservation supplies its numeric head room. The derived `Post.context` supplies the actual current Context. The full final Memos query equality identifies the exact stopping call's query endpoint.

The checked child observer then derives the projection heap at the stopping call's returned native caller. The proof does not infer the reached heap from arbitrary native growth. It supplies no future Context, projected child support, heap, model, or generic preservation oracle.

## Stopping scope

The observer includes missing cache, missing raw action, empty raw rejection and inner enumeration errors under outer `.ok`. It retains the native effects of the actual stopping child. It does not merely return the heap before that child.

Outer native/terminal errors are excluded. This candidate does not assert heap preservation for their reached states or present a counterexample to that further property. It proves no completion, output-existence, complete coverage, uniform depth, termination, rendering, whole-driver closure, or public Haskell correspondence.

No runtime definition, new producer family, complete-producer tuple clone, source/prepared identity premise, custom axiom, proof budget, linter setting, or Haskell change is introduced.

## Preserved compiler evidence

Original candidate v1: 5,760 bytes, 86 lines, SHA256 `086341f5e5c898451c3ab21bdf70abc1e2ca2da09476bdc6b906d92bef302cb1`. It remains byte-identical to the delivered draft.

Root's first default build failed because `prefix` is a reserved Lean keyword in the new binder. The complete 1,891-byte raw log is retained with SHA256 `00002812e6860ceddadc23646089a945b59e2264774801850a6b67f280e10233`. The four parser messages are consequences of that binder declaration and its uses.

Root v2 renames only that binder and its two uses to `completedPrefix`. Exact byte comparison confirms the three replacements. The `Reserved.prefix` method is unchanged. The intended logical statement is alpha-equivalent. The root v2 whole source is copied separately: 5,787 bytes, 86 lines, SHA256 `c834ea9da020d6ba520d46c303f16801bdd14956d8db34ee239f2d613d8701f2`.

The complete second default raw log reports a successful 1,991-job build. Its 574-byte copy has SHA256 `6924adc74742fc3491f3a537a3026e25cc183719f1edbf0a3c8480095eced3a7`. The captured strict raw log is empty. This report does not infer a completed strict check only from an empty log. Root owns strict/Audit/public validation and any publication.

The raw logs include an unrelated replayed old-module warning. No linter suppression was added.

## Frozen read scope

Five existing sources were read whole and preserved: the prefix heap theorem, child heap observer, literal child traversal and stopped-trace extraction, original incoming reservation, and actual Post/Context definitions. The old traversal cost and admission declaration were read as the exact literal cut at lines 28 through 62. Hashing a cut's whole source does not assert a whole-file semantic read.

All whole sources, the literal cut, compiler logs and root v2 source are copied under `evidence-v1`. The original draft and report are now frozen. No earlier checkpoint directory was written. No further proof work is included.
