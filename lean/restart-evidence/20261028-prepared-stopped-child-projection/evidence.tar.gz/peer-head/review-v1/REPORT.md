PASS: original completed-head projection contract review

Created 2026-10-28 21:09:52 CET. CompletedHeadProjectionHeap was read whole: 62 lines, 3,890 bytes, SHA256 ac9e8b9eef86a37161e745ffaa2450d8b37ca28890386e1bc76d1c510eaed0ea. CapturedEdgeProjectionHeap was read whole: 91 lines, matching SHA256 4e5a4290a61132225fb726445e7e44604064481b6fea585650d9e913c005a815. No compiler, native execution, Git, network, board or repository write was used.

Exact exported statement

NativeHookResources.CompletedHeadReceipt.projection_heap has only two explicit proof arguments: the EXISTING actual completed-head receipt and ProjectionHeap at its ORIGINAL caller. All receipt/data indices are implicit. It concludes ProjectionHeap at that same receipt's reached caller. It adds no output projection, semantic model, completion supplier, global key universe or recursive-depth premise.

Original and prepared admissions remain distinct

This export is in SourcePruningEnumerationNativeHookResources. Its HeadAdmission.source contains an original stored handle and a decoded ordinary node at that SAME original caller, plus selection from that decoded parent's edges. The proof extracts exactly those witnesses.

PreparedNativeHookResources.HeadAdmission instead indexes its stored source handle separately from a prepared ordinary parent and retains parentAvailable/parentClosed. The reviewed theorem does NOT accept that nominal prepared receipt or equate its source handle with the prepared parent. This is a clear scope limit, not an implicit preparation correctness result.

Original packet and reservation

The proof obtains roots, native handle realization, canonical waiting counts and actual native candidate flags from head.admission.packet.valid. The original packet also retains its full Memos Context. Pending inputs are derived by EnumerationReferences.pending_inputs from the packet's original PendingReferences and the exact stored bucket.

head.allowed and head.projected are actual completion facts already present in the old receipt. NativeBranchCompletion.edgeCost uses precisely those arity/project cases. Rewriting them converts the SAME original head.admission.reserved to SelectedEdge.cost edge scs before.counter tries. That selected-edge cost is the mixed traversal cost of the actual EdgeInputs.children list. No later seed, future resource bound or replacement reservation is supplied.

Captured and selected actual runs

CapturedEdge.run_projection_heap consumes original Context, Ready, exact stored/decoded parent, native realization, selection, original indexes/pending bucket, supported arity/project observation, original Fits/reservation/known guards and original ProjectionHeap. It derives available/closed parent facts from the actual realized original handle and decoding equality. This equality identifies two descriptions of the SAME original native value; it is not an original-source/prepared-parent cast.

SelectedEdge.run_projection_heap derives its actual own-class prefix and child admissions from those original facts. It handles a complete child traversal and a stopped traversal with an outer-success stopping child at their exact reached native callers. The captured wrapper then follows actual finalization. Finalize writes only the enumeration cache and keeps the native caller unchanged. A successful captured completion therefore retains that selected run's reached heap.

The captured helper's match conclusion is scoped: it provides projection for some complete and some stopped/outer.ok results. It makes no projection claim for None, unhandled, rejected or stopped outer-error cases; those branches have conclusion True. The completed-head wrapper uses only the genuine some complete case.

Literal completed endpoint and full memos

The proof calls the captured helper at the receipt's own bound in all five primitive coordinates. head.running 0 then gives the EXACT same captured run, fragment, reached caller, saved queries and after cache. Removing Nat.add_zero and rewriting that literal observation specializes the match result to ProjectionHeap at the receipt's reached caller.

The original CompletedHeadReceipt remains unchanged. Its Post at returnedInventory/returnedMemos, returnedMemos.query=saved, captured and completed full packets, padded resource fields, supported arity/project facts and stable literal running field all remain available. The new proof does not replace full Memos by only the query field or infer projection by a forward semantic Post rule. It derives projection from original physical facts and the actual run.

Limits and review evidence

The theorem attaches a local heap property to an already supplied actual original completed-head receipt. It does not create a completed receipt, prove any recursive callback finishes, establish enough driver depth, infer final Satisfies/Discharged or prove global coverage/finite key bounds. The distinct prepared receipt needs its own justified application route; this export alone does not provide one.

Four whole sources, seven literal-cut sources and three complete declarations are preserved under this new review directory. source-manifest.json records exact bytes, hashes and read scopes. Root owns compiler/strict/Audit/public verification; this is an independent source-contract review. No concern was found within the stated original-receipt scope. Earlier frozen evidence remains unchanged.
