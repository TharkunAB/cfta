# Actual callback entry projection

Time: 2026-10-28 21:11 CET.
Status: source-only audit. No new Lean candidate was needed or compiled.
Root owns all proof checks and repository integration.

The existing completed-head projection fact already has the exact recursive
callback entry heap type. Recording has no returned native caller. The actual
`continueWith` call passes its supplied caller unchanged to the false branch's
recursive continuation. A new point theorem would only repeat this identity.

## Exact attachment

Let `head` be the supplied actual completed-head receipt. Its original native
caller is `caller`; its completed native caller is `reached`. Let
`originalProjection` apply to `caller`.

The existing fact is:

```lean
have entryProjection := head.projection_heap originalProjection
```

Its conclusion applies to `reached.checked.native.machine.heap`.

Suppose the actual callback observation is:

```lean
ExceptT.run (recordTypes graph templates fuel metadata uv (.inl fragment) after.core) =
  [.ok ((false, updated), recorded)]
```

The relevant concrete call is `continueWith recur graph templates stop order
fuel metadata uv fragment reached saved after`. Its false branch is literally:

```lean
recur updated reached saved (EnumerationExpandableIndex.frame recorded after)
  (SourcePruningEnumerationRestart.decision stop order updated
    (EnumerationExpandableIndex.frame recorded after))
```

Its native caller is `reached`. The native heap at this entry is therefore exactly
the heap in `entryProjection`. The record observation does not name or constrain
an unrelated caller. The attachment comes from this actual `continueWith`
invocation, with the head's returned caller as its caller argument.

The true recording branch returns `.complete [] reached saved`. Every malformed
raw recording branch returns `.stopped [] ... (some (reached, saved))`. Both
retain the same native heap. Only the false branch invokes the recursive body.

## Existing source interfaces

- `SourcePruningEnumerationRecursive.lean:62`, `continueWith`, contains the
  literal three-way match above. Recording receives `before.core`; no native
  caller is passed to `recordTypes` as state.
- `SourcePruningRecordTypes.lean:50`, `recordTypes`, updates metadata through the
  enumeration oracle. Its observation contains a Boolean, metadata and an
  enumeration core. It has no returned native caller or heap.
- `SourcePruningEnumerationRecursiveEquations.lean:20`, `continueWith_exact`,
  already converts an actual successful recording into the exact continuation
  equation. Its false branch retains the literal caller and query arguments.
- `SourcePruningEnumerationRecursiveCallback.lean:29`, `callback_complete`,
  returns the post-record packet at the same caller, inventory and full Memos.
  `callback_prefix_complete` at line 65 keeps these indices for its accepted
  selected-prefix admission.
- `SourcePruningEnumerationFiniteCallbackReceiptLanguage.lean:41`,
  `FalseCallbackReceipt`, stores the actual recording and restart. Its
  `returned` field at line 54 and `restarting` field at line 68 use the same
  caller and full Memos as its original packet. No caller equality lemma is
  missing from this interface.
- `SourcePruningEnumerationCallbackAdmission.lean:52`,
  `RecursiveCallbackAdmission.after_false`, retains caller, full Memos, seed,
  bounds, guard carrier and reservation. It changes metadata and the framed
  enumeration cache. The producer at line 113 attaches the callback admission
  to the same actual head receipt's completed caller and packet.
- `SourcePruningEnumerationReceiptHook.lean:26`, `receipt_zero_complete`,
  already identifies the zero-depth aggregate and output callers with the
  receipt's reached caller. Its exhausted endpoint is the same caller. Thus
  zero-depth native projection can use these existing equalities.

The installed head fact is
`SourcePruningEnumerationCompletedHeadProjectionHeap.lean:32`,
`NativeHookResources.CompletedHeadReceipt.projection_heap`.
Its copied bytes match candidate v1: 3,890 bytes, 62 lines, SHA256
`ac9e8b9eef86a37161e745ffaa2450d8b37ca28890386e1bc76d1c510eaed0ea`.
This audit does not report a compiler result for that module.

## Remaining genuine finite-producer obligation

The recursive body's return can have a different native caller. The completed
callback result supplies that returned caller to the next sibling, including
when the callback emits no outputs. This is explicit in
`RecursiveEquations.completed_head` at line 87: recursion starts at `reached`
but may complete at `middleCaller`.

`FiniteCallbackResources.callback_finite_complete_resources` uses the
smaller-depth `Complete` contract after the false record. That call needs the
post-record packet, original bounds and known guard carrier, selection policies,
mass bound and original reservation. Its caller is unchanged at this entry.
The old contract does not state projection at its returned aggregate caller.

`OutcomeResources` retains an aggregate `Post`, `Fits` and a known guard carrier,
plus each output's own packet and resources. It does not state the projection
predicate. A proof about emitted outputs alone would not cover a completed
callback with an empty output list. An endpoint property is needed there to
admit the next sibling. Actual stopped endpoints need the corresponding native
operation scope as well.

The needed progress is preservation through the actual smaller-depth recursive
body and its returned endpoints. The finite producer must derive that property
from its original input, through its actual native steps and depth induction.
It must not receive a future projection heap as an arbitrary supplier. This
audit establishes neither a counterexample to preservation nor a new recursive
preservation theorem. It identifies no missing native step in recording itself.

## Prepared scope and read evidence

The actual `PreparedRecursive.continueWith` body was inspected separately in the
literal cut of `SourcePruningEnumerationPreparedRecursive.lean`, lines 45 through
77. Its false branch also passes its caller unchanged. This independent source
fact does not convert a prepared head receipt or its `Failure` type into the
original receipt or `Failure` type. The original head theorem is used only at
its declared original receipt type.

Eleven source files were read whole. Their copies contain 1,466 lines and 97,203
bytes. The prepared cut contains 33 lines and 2,102 bytes. `manifest-v1.json`
lists each whole source, its byte count and SHA256. It records the full source
hash and exact copied-byte hash for the prepared cut. No whole semantic read of
the rest of the prepared source is claimed.

The copied files include the three requested entry interfaces, actual worker
definitions, existing exact callback equations, receipt and finite producer
interfaces, and the installed head projection fact. No compiler, native
evaluator, Git, network or board command was run. No repository file was written.
No Haskell fix was made or identified.

No new entry wrapper, producer family or large resource tuple was added. The
audit makes no whole-driver, coverage, termination or Haskell correspondence
claim. This report and its copied inputs close the bounded task and are frozen.
