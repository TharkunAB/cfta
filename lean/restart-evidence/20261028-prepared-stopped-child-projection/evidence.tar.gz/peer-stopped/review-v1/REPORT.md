PASS: stopped traversal projection source-contract review

Created 2026-10-28 21:01:33 CET. The installed primary source was read whole, 86 lines. Its SHA256 matches c834ea9da020d6ba520d46c303f16801bdd14956d8db34ee239f2d613d8701f2. The completedPrefix binder and its uses are consistent. No compiler, native execution, Git, network, board or repository edit was used.

Exact claim and gates

TraversalCompletion.stopped_projection_heap starts with original Context/full memos, Safe/cache indexes, PendingRealized, all original input values Available and closed, bounded/pending buckets, original Fits, the complete original mixed reservation, known native guards and original ProjectionHeap. It requires a literal actual traversal result

  stopped completedPrefix (.ok result, afterCaller, savedQueries, outer, waiting) candidate.

It concludes only ProjectionHeap at the SAME afterCaller.checked.native.machine.heap. The raw result is an unrestricted Option of the complete raw-row list type; candidate is an unrestricted Option Cached. There is no extra some-result, singleton, nonempty-row, successful-row or some-cache premise at the stopping call. Of course, the actual stopped observation still imposes the runtime's normal stop conditions; the theorem does not promise that every abstract pair of Option values is realizable.

Actual completed-prefix extraction

ChildTraversal.stopped_trace obtains consumed, the actual stopping incoming value and bucket, remaining, stoppedCaller, stoppedBefore and stoppedQueries. It keeps the exact input decomposition and an actual Trace for the consumed children. That Trace contains successful singleton rows with their actual returned caches. The final child equality is the exact stopping call, not the original first-child state or a hypothetical later call.

The input decomposition rewrites the ORIGINAL genuine-input admissions and total reservation. trace_prefix_resources_projection_heap consumes the actual prefix trace and untouched suffix. For each consumed singleton it invokes the original finite child producer and successful point uniqueness through observed_singleton_resources_projection_heap. This aligns the produced native caller/cache/query with the literal actual trace step. No supplied future Context or projection heap is needed.

The prefix result contains actual next inventory and final full Memos, a Post from the original caller to stoppedCaller, final.query=stoppedQueries, safe/cache/pending facts at stoppedBefore, suffix availability/closedness/bounds/pending, and Fits/known/projection heap at stoppedCaller. It also gives the remaining reservation at advance seed(cost consumed). These are derived outputs of the prefix proof, not new admission hypotheses.

Stopping call and reached heap

The stopping input's Available, closed, bounded and pending facts are taken from the derived suffix admissions. Its reservation is a prefix of the derived remaining reservation, using bucket.length+1<=bucket.length+1+cost remaining. Cost is the original sum of bucket lengths plus one per child.

The actual child call is rewritten only by final.query=stoppedQueries. The ChildDispatch observer receives post.context at the derived next inventory/full Memos, stoppedBefore's actual cache facts and its derived projection heap. Its actual observation retains the SAME .ok result, afterCaller, savedQueries, outer, waiting and candidate. That observer derives the projection heap at the reached afterCaller. Native work within the stopping call is therefore retained even when its raw Option or cache is missing.

The full memos returned by the PREFIX are the current starting memos for the stopping child. The theorem does not claim a new whole Post/full Memos output after the stopping child, and it does not assume such an output.

Return-shape scope

The stopped call can have outer .ok with none, an empty or otherwise stopped raw list, or no cache. The child observer takes exactly those unrestricted values and erases cache data without changing the reached caller. Its Empty/shallow cases retain the original child caller; its terminal case derives the actual native fold/incoming heap. Thus there is no hidden successful-singleton gate on the stopping child.

Outer child errors are excluded by the public explicit .ok observation. The theorem does not establish projection preservation for them, prove completion, produce a discharged/model assignment, prove enough recursive depth, preserve an arbitrary stopped result at larger bounds or establish global enumeration coverage. It introduces no original-source/prepared-parent equality or nominal worker cast.

Evidence and status

Four whole sources, two cut sources and five complete literal declarations are preserved with SHA256 identities in source-manifest.json. Root reports the installed source passed default+strict after a binder-only repair. This independent review checks the final source contract and does not run or replace compiler/Audit/public axiom checks. No concern was found in the bounded review. Earlier frozen evidence remains unchanged.
