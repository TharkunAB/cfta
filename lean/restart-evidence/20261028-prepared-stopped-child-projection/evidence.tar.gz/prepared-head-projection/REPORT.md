# Actual prepared completed-head projection

Time: 2026-10-28 21:16 CET.
Status: UNTESTED. Root owns compilation and repository integration.

The candidate adds the distinct prepared theorem
`MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources.CompletedHeadReceipt.projection_heap`.
All data indices are implicit. Its explicit premises are the actual prepared
head receipt and projection of that head's original input caller heap. It
concludes projection of the same receipt's exact reached caller heap.

Source:
`candidate-v1/MicroCFTA/SourcePruningEnumerationPreparedHeadReceiptProjectionHeap.lean`.
The candidate has 63 lines and 3,954 bytes. Its SHA256 is
`6f83d9f08a64025b80311e03a40eb42bf82a9d3d3b9d7f13bbbed855c2074c69`.

## Input and source boundaries

The theorem uses the actual `PreparedHeadAdmission.lean` receipt type. It retains
the extra indices `uv`, `handle`, `scs`, `parentEntry`, stored rows, depth and free
references. The stored source handle remains separate from the available closed
prepared parent.

The proof uses `admission.stored`, `admission.parentAvailable`,
`admission.parentClosed` and `admission.selected` directly. It requires no decode
equality between the original source handle and the prepared parent. It does not
convert an original receipt into a prepared receipt or convert either `Failure`
type.

`ProjectionHeap` is the physical-edge-key predicate
`SourceEqualityAnnotationHeap.Heap (fun constraint =>
SourcePruningEnumerationConstraint.project constraint ≠ none)`. The original
input caller projection remains an explicit premise. The bare packet and its
known guard carrier are not used as a substitute for that premise.

Here, original input caller means the input of this supplied head. A whole
producer still has to derive this input invariant at each actual head. This
local theorem does not assume it at a future endpoint of the whole producer.

## Exact proof route

1. Extract roots, pending-handle realization, waiting counts and native candidate
   flags from the original admission packet's `valid` field.
2. Extract this actual edge's successful constraint projection from
   `head.projected`.
3. Derive the original `InputsPending` property with `pending_inputs`, using the
   original packet pending property and `admission.stored`.
4. Rewrite the original `edgeCost` reservation with `head.allowed` and the actual
   projection witness. This yields the exact `SelectedEdge.cost` reservation.
5. Call `CapturedEdge.run_prepared_projection_heap`. Pass the original packet
   context, ready state, stored slot, separate prepared parent availability and
   closure, original resources and input projection. Use `bound` in all five
   fuel positions.
6. Specialize `head.running` at zero, simplify `bound + 0` and rewrite the actual
   captured run in the observer. Its completed branch is the required exact
   reached caller heap.

The endpoint `post`, `captured`, `completed`, `bounded` and `known` fields are not
used to infer projection. No future projection, child support or model is an
added premise. No separate completion producer or common-fuel alignment is
needed.

## Dependency and read scope

The new captured dependency is
`SourcePruningEnumerationCapturedPreparedProjectionHeap.lean`, with public
`CapturedEdge.run_prepared_projection_heap`. Its arguments match
`CapturedPreparedResources.complete_with_history_resources_prepared` through
`known`, followed by the original caller projection and explicit `r n p h k`.
The proof uses its literal completed branch only.

The captured dependency was read whole and copied. The copy was read back whole.
It has 89 lines and 5,475 bytes. Its SHA256 is
`943a99a645c89b4acf4f98efcea805bb971f36e816ae89643f551b622bc43ff5`.
This report does not claim a compiler result for the dependency or candidate.

Four source files were read whole. Their copies contain 642 lines and 42,048
bytes:

- `SourcePruningEnumerationPreparedHeadAdmission.lean`.
- `SourcePruningEnumerationPreparedHeadReceiptArity.lean`.
- `SourcePruningEnumerationCapturedPreparedResources.lean`.
- `SourcePruningEnumerationCapturedPreparedProjectionHeap.lean`.

Three exact source cuts were read and copied. They contain 112 lines and 6,422
bytes. No whole semantic read of the rest of these files is claimed:

- `SourcePruningEnumerationNativeBranchResources.lean`, lines 1 through 53.
- `EnumerationReferences.lean`, lines 338 through 365.
- `SourceEqualityAnnotationHeap.lean`, lines 1 through 31.

`manifest-v1.json` binds every source path, whole-source SHA256 and copied file.
For cuts, it records both the full source hash and the exact literal-cut hash.

## Validation and freeze

The candidate was read back whole. Its bytes and all copied-input hashes were
checked without a compiler. No repository file, earlier candidate or frozen
area was written. No compiler, native evaluator, Git, network or board command
was run. No Haskell fix was made or identified.

The theorem supplies no completed head or recursive output. It makes no global
depth, completion, coverage, language-equivalence or Haskell correspondence
claim. It adds no runtime definition, producer family, axiom or admitted proof.

Candidate v1 and all copied inputs are immutable. Root must preserve this
version and use a separate version for any compiler repair. This report and its
manifest close the bounded task.
