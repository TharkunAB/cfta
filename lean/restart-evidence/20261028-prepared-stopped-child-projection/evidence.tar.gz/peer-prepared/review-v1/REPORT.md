PASS: primary prepared captured/head projection contract review

Created 2026-10-28 21:18:14 CET. CapturedPreparedProjectionHeap was read whole: 89 lines, 5,475 bytes, SHA256 943a99a645c89b4acf4f98efcea805bb971f36e816ae89643f551b622bc43ff5. PreparedHeadReceiptProjectionHeap was read whole: 63 lines, 3,954 bytes, SHA256 6f83d9f08a64025b80311e03a40eb42bf82a9d3d3b9d7f13bbbed855c2074c69. Both expected identities match. No compiler, native execution, Git, network, board or repository write was used.

Prepared identity separation

This is the actual SourcePruningEnumerationPreparedNativeHookResources.CompletedHeadReceipt route. The original stored handle remains indexed by stored: before.values[uv]=unenumerated(some handle,scs). The prepared ordinary parent is indexed separately by parentEntry, edges, depth and free. Its own parentAvailable, parentClosed and selected fields are passed directly to the selected-edge projection helper.

Neither new file introduces a lookup equation that decodes the stored source handle as the prepared parent. Neither casts to the original NativeHookResources.CompletedHeadReceipt. The shared CapturedEdge.run receives the same original captured target/bucket and the selected prepared edge, exactly as the existing prepared producer does.

Old captured prepared gates

The input block from seed through known in run_prepared_projection_heap was compared mechanically with complete_with_history_resources_prepared. It matches after whitespace normalization. The same original Context/full memos, Ready, stored source, separate parent availability/closure, PendingRealized, selected membership, indexes, pending inputs, supported arity/project observation, Fits, mixed reservation and known native heap all remain explicit. The three decidable equality instances are the same, declared inline or by the original section context.

The new inputs after that old block are originalProjection at the SAME input caller and the five primitive runtime bounds. No future heap, model, source/prepared language-equivalence certificate or completion supplier is added. The old finite producer and its full result/resource packet are not redefined or shortened.

Actual captured return

The helper derives bucket bounds from original Ready.safe and the stored payload, then calls SelectedEdge.run_projection_heap with the prepared parent's own facts. It follows the actual SelectedEdge.run result and actual finalization. Finalize changes only the enumeration cache, so a successful finalized completion has the exact same reached native caller as the selected edge. Stopped outer-success calls retain that caller too.

The helper's conclusion is deliberately a match on the actual bounded run: some complete and some stopped/outer.ok yield projection at their actual returned callers. None, unhandled, rejected and stopped outer-error branches have conclusion True. It does not claim arbitrary error preservation or produce a successful result.

Prepared completed-head wrapper

PreparedNativeHookResources.CompletedHeadReceipt.projection_heap has only head and originalProjection as explicit proof arguments. It obtains original roots, realization and cache indexes from head.admission.packet.valid, derives the original bucket's pending facts from the packet, and uses the actual head.allowed/projected facts to rewrite the ORIGINAL edgeCost reservation to SelectedEdge.cost. No later reservation is supplied.

The wrapper calls run_prepared_projection_heap at head.bound in all primitive coordinates. head.running 0 is the literal actual captured complete run. Rewriting that exact observation specializes the match to ProjectionHeap at head.reached.checked.native.machine.heap. The complete fragment, reached caller, saved queries and returned cache are those already indexed by the receipt.

The receipt's full returned Post/Memos, query equality, captured and completed packets, admission/history/cache bounds and stable running field remain unchanged. Projection is not inferred from a forward semantic Post rule, and no desired final projection predicate is stored as a new receipt assumption.

Caller and callback scope

Original caller here means the input caller of THIS prepared head/captured invocation. The statement does not by itself transport a whole-driver initial heap through earlier selection/preparation.

PreparedRecursive.continueWith runs recordTypes on the enumeration core and metadata. Its completed or stopped recording branches keep the same native caller and queries. Its recursive branch passes those same caller/query arguments into recur with the framed returned enumeration core. Thus recording itself does not silently change the native caller referenced by this local head theorem.

A later recursive continuation can perform more native work. Neither reviewed theorem proves projection at every whole-recursive return, supplies enough recursive depth, proves completion exists, discharges suspended constraints or gives source/prepared model equivalence/global coverage. Any later recursive transport must be proved separately from its actual calls.

Evidence and status

Three whole sources, six literal-cut sources, three complete theorem declarations and the two complete prepared receipt/admission structures are preserved with byte/hash identities. The manifest includes the old-gate comparison. Root owns compilation, strict, Audit and public axiom checks; this independent result is source-contract PASS. No concern was found in the stated prepared scope. Earlier frozen evidence remains unchanged.
