from pathlib import Path
import hashlib
import json
import re
import shlex
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
work = base / '20261117-whole-worker-program-roles-work'
prior_run = base / '20261117-actual-eager-role-producer-publication'
prior_archive = base / '20261117-actual-eager-role-producer-checkpoint'
runtime = base / '20261117-whole-worker-program-roles-publication'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
audit_name = 'lean/MicroCFTA/Audit.lean'
fragment_name = 'lean/MicroCFTA/SourceSynthesisActualEagerProgramFragmentRoles.lean'
sha = lambda data: hashlib.sha256(data).hexdigest()
old_owner_hash = '305760b3b3ef558445f7a6af3a78cc994bf7fe0875319fc7a11a8c1682b45829'
new_owner_hash = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
old_fragment_hash = 'd0f62da80fcbf4db41c056ad98ecca1cd63b17a3bb4f1c0e1fe394d888706fd1'
new_fragment_hash = '3e6327527448256472cf1564746a537ecfbb98bae36cf7bc11b4e8b9fee446a9'
expected_components = [
    {'module': 'SourceSynthesisObservedChildProgramSlots',
     'namespace': 'SourceSynthesisProgramRolesObservedChild',
     'source_path': 'lean/MicroCFTA/SourceSynthesisObservedChildProgramSlots.lean',
     'raw_sha256': 'c4d32ba0d724ef610d8f9a3d4c80d5ee6753e8cbb2c10772f5d85d8318ded949',
     'theorems': ['observed_complete_program_slots']},
    {'module': 'SourceSynthesisActualEagerProgramFragmentRoles',
     'namespace': 'SourceSynthesisActualEagerProgramFragmentRoles',
     'source_path': fragment_name, 'raw_sha256': new_fragment_hash,
     'theorems': ['eager_program_fragment_roles', 'selected_eager_program_fragment_roles']}]
public_qnames = [
    'MicroCFTA.SourceSynthesisActualEagerProgramFragmentRoles.selected_eager_program_fragment_roles',
    'MicroCFTA.SourcePruningEnumerationSharedEagerReservation.runEager_real_program_slots_at_any_budget']
public = ''.join('#check ' + name + '\n#print axioms ' + name + '\n' for name in public_qnames).encode()
nonempty = lambda data: [line for line in data.splitlines() if line.strip()]
expected_new_owner_names = [
    'real_outer_program_slots_zero', 'real_program_render_stable_slots',
    'real_program_prepared_marked_fields', 'real_program_annotation_nonterminal',
    'real_outer_program_prepared_opaque', 'real_outer_program_prepared_captured',
    'real_outer_program_prepared_history', 'real_outer_program_parked_history',
    'real_outer_program_right_history', 'real_outer_program_slots_succ',
    'real_outer_program_slots_at_every_depth', 'runEager_real_program_slots_at_any_budget']
stage = json.loads((work / 'SOURCES-NORMAL-STAGING.json').read_text())
assert stage['owner_normal_installed'] is True
assert stage['owner_check'] == '20261117-whole-real-eager-program-slots-cache-equality-check'
assert stage['owner_base_sha256'] == old_owner_hash
assert stage['owner_raw_sha256'] == new_owner_hash
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports']) == (6248, 5248, 656)
assert stage['native363_staged'] is False
assert stage['reader_alias_staged'] is False
assert stage['whole_worker_program_slots_proved'] is True
components = stage['components']
assert len(components) == len(expected_components) == 2
assert [{key: c[key] for key in expected} for c, expected in zip(components, expected_components)] == expected_components
before_owner = (work / 'SourcePruningEnumerationSharedEagerReservation-BEFORE.lean.txt').read_bytes()
before_audit = (work / 'Audit-BEFORE.lean.txt').read_bytes()
before_fragment = (work / 'SourceSynthesisActualEagerProgramFragmentRoles-BEFORE.lean.txt').read_bytes()
preflight_audit = (work / 'AUDIT-PREFLIGHT.lean.txt').read_bytes()
assert sha(before_owner) == old_owner_hash and len(before_owner) == 2446450
assert sha(before_fragment) == old_fragment_hash and len(before_fragment) == 32048
assert before_audit.count(b'#print axioms ') == 654
assert preflight_audit.startswith(before_audit) and preflight_audit.count(b'#print axioms ') == 655
assert nonempty(preflight_audit[len(before_audit):]) == nonempty(public.split(b'#check ' + public_qnames[1].encode())[0])
owner_check_name = stage['owner_check']
owner_check = base / owner_check_name
owner_selection = json.loads((owner_check / 'selection.json').read_text())
owner_report = json.loads((owner_check / 'checked.json').read_text())
assert owner_report['owner_append_checked'] and all(owner_report['passed'])
assert len(owner_report['checks']) == 2
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx']
           for c in owner_report['checks'])
assert owner_report['checks'][1]['name'] == 'owner-and-appends'
assert owner_report['checks'][1]['total_axiom_reports'] == 264
assert owner_report['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
assert owner_report['old_owner_entire_exact_contiguous_block']
assert owner_report['old_owner_proof_bodies_and_limits_unchanged']
assert owner_report['new_proof_maxHeartbeats'] == 200000
assert owner_selection['owner'] == owner_name
assert owner_selection['reports'] == 264 and owner_selection['previous_owner_reports'] == 252
assert owner_selection['new_private_reports'] == 12  # Legacy key: eleven private theorems and one public theorem.
assert owner_selection['runtime_fuels_unchanged'] and owner_selection['old_owner_entire_exact_contiguous_block']
assert owner_selection['all_new_proofs_maxHeartbeats'] == 200000
owner = (root / owner_name).read_bytes()
assert sha(owner) == owner_selection['assembled_sha256'] == new_owner_hash
assert owner_selection['old_owner_sha256'] == old_owner_hash
assert owner_selection['old_owner_bytes'] == len(before_owner)
offset = owner_selection['old_owner_offset']
assert offset == 113 and owner[offset:offset + len(before_owner)] == before_owner
packet = base / '20261117-whole-real-eager-program-slots-cache-equality-repair'
import_prefix = (packet / 'IMPORTS.lean.txt').read_bytes()
append = (packet / 'APPEND.lean.txt').read_bytes()
assert sha(append) == '9e5cf9d48df8b56fa3bec7479e7b8474a83d9a7e14fc4131100bd35820495df8'
assert owner == import_prefix + before_owner + b'\n' + append
assert sha(import_prefix) == owner_selection['import_prefix_sha256']
assert sha(b'\n' + append) == owner_selection['append_sha256']
assert all(line.strip() == b'set_option maxHeartbeats 200000' for line in append.splitlines()
           if b'set_option maxHeartbeats' in line)
assert len(re.findall(rb'^private theorem ', append, re.M)) == 11
assert len(re.findall(rb'^private def ', append, re.M)) == 1
assert len(re.findall(rb'^theorem ', append, re.M)) == 1
assert re.findall(rb'^#print axioms (\w+)$', (packet / 'PROBES.lean.txt').read_bytes(), re.M) == [n.encode() for n in expected_new_owner_names]
fragment = (root / fragment_name).read_bytes()
assert sha(fragment) == new_fragment_hash and fragment.startswith(before_fragment)
audit = (root / audit_name).read_bytes()
assert audit.startswith(preflight_audit)
assert nonempty(audit[len(before_audit):]) == nonempty(public)
assert sum(line.startswith(b'import ') for line in audit.splitlines()) == 5248
assert audit.count(b'#print axioms ') == 656
old_probes = (work / 'PreviousOwnerProbes252.lean.txt').read_bytes()
new_probes = b'\n' + (packet / 'PROBES.lean.txt').read_bytes()
assert old_probes.count(b'#print axioms ') == 252
proof_source = owner_check / 'source/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
proof = proof_source.read_bytes()
assert proof == owner + b'\n' + old_probes + new_probes
assert proof.count(b'#print axioms ') == 264
owner_log = owner_check / 'owner-and-appends.txt'
owner_output = owner_log.read_text()
groups = [set(x.strip() for x in group.split(',') if x.strip())
          for group in re.findall(r'depends on axioms:\s*\[([^]]*)\]', owner_output, re.S)]
free = len(re.findall(r'does not depend on any axioms', owner_output))
assert len(groups) + free == 264
assert not (set().union(*groups) - {'propext', 'Classical.choice', 'Quot.sound'})
assert 'sorryAx' not in owner_output and not re.search(r': error(?:\(|:)', owner_output)
owner_pins = json.loads((owner_check / 'source-pins.json').read_text())
assert owner_pins[owner_name] == old_owner_hash and owner_pins[audit_name] == sha(preflight_audit)
assert owner_pins[fragment_name] == new_fragment_hash
for name, digest in owner_pins.items():
    data = before_owner if name == owner_name else preflight_audit if name == audit_name else (root / name).read_bytes()
    assert sha(data) == digest, name
prior = json.loads((prior_run / 'checked.json').read_text())
assert len(prior['checks']) == 5 and all(c['exit'] == 0 and not c['nonstandard_axioms']
    and not c['diagnostics'] and not c['sorryAx'] for c in prior['checks'])
assert (prior['source_files'], prior['owner_resource_probes'], prior['fresh_strict_normal_reports']) == (6248, 252, 13)
assert (prior['resource_and_component_probes'], prior['independent_reports'], prior['individual_reports']) == (392, 249, 654)
baseline = json.loads((work / 'baseline-source-pins.json').read_text())
assert len(baseline) == 6248
assert {str(p.relative_to(root)) for p in (root / 'lean/MicroCFTA').glob('*.lean')} == set(baseline)
old_snapshots = {owner_name: before_owner, audit_name: before_audit, fragment_name: before_fragment}
for name, digest in baseline.items():
    assert sha(old_snapshots[name] if name in old_snapshots else (root / name).read_bytes()) == digest, name
assert len(baseline) - len(old_snapshots) == 6245

runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-whole-role-publication-'))
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
(runtime / 'PUBLIC-PROBES.lean.txt').write_bytes(public)
commands, strict_sources = [], []
normal_count = 0
for component in components:
    normal = root / component['source_path']
    assert sha(normal.read_bytes()) == component['raw_sha256']
    helpers = re.findall(r'^private theorem ([A-Za-z0-9_]+)', normal.read_text(), re.M)
    public_names = re.findall(r'^theorem ([A-Za-z0-9_]+)', normal.read_text(), re.M)
    assert public_names == component['theorems']
    probes = ''.join('#check @MicroCFTA.' + component['namespace'] + '.' + name + '\n#print axioms MicroCFTA.'
                     + component['namespace'] + '.' + name + '\n' for name in helpers + public_names)
    normal_count += len(helpers) + len(public_names)
    source = runtime / 'source/MicroCFTA' / normal.name
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_bytes(normal.read_bytes() + b'\n' + probes.encode())
    (runtime / (component['module'] + '-PROBES.lean.txt')).write_text(probes)
    strict_sources.append(source)
    commands.append(['lake', 'env', 'lean', '-j1', '-DwarningAsError=true', '-R', str(source.parent.parent),
                     '-o', str(objects / (component['module'] + '.olean')), str(source)])
assert normal_count == 14
independent = runtime / 'IndependentProbes.lean'
independent.write_bytes((prior_run / 'IndependentProbes.lean').read_bytes() + b'\n' + public)
assert independent.read_bytes().count(b'#print axioms ') == 251
binding = {'prior_checkpoint': 'a0e968a176e23825baaeb4f2180d470d8c7c1c33',
    'prior_archive_manifest_sha256': sha((prior_archive / 'manifest.json').read_bytes()),
    'prior_checked_sha256': sha((prior_run / 'checked.json').read_bytes()),
    'prior_pins_sha256': sha((prior_run / 'source-pins.json').read_bytes()),
    'prior_source_files': 6248, 'prior_resource_reports': 392,
    'prior_owner_reports_replaced_by_fresh_preflight': 252,
    'prior_normal_reports_replaced_by_fresh_strict': 13,
    'inherited_reports': 127, 'fresh_owner_preflight_reports': 264,
    'fresh_strict_normal_reports': 14, 'fresh_reports_this_batch': 278,
    'combined_resource_and_component_reports': 405, 'strict_gate_actual_reports': 14,
    'old_non_audit_non_owner_non_fragment_sources_byte_exact': 6245,
    'old_owner_bytes_retained_contiguously': len(before_owner),
    'old_fragment_bytes_retained_as_prefix': len(before_fragment),
    'old_audit_retained_as_prefix': True, 'old_toolchain_and_proof_inputs_reverified': True,
    'legacy_new_private_reports_caveat': '12 means eleven private theorems and one public theorem; one additional private predicate is not a theorem report'}
assert binding['inherited_reports'] == prior['resource_and_component_probes'] - prior['owner_resource_probes'] - prior['fresh_strict_normal_reports']
assert binding['fresh_reports_this_batch'] == 264 + normal_count
assert binding['combined_resource_and_component_reports'] == 127 + 264 + normal_count
(runtime / 'INHERITANCE-SELECTION.json').write_text(json.dumps(binding, indent=2) + '\n')
preflight_files = [owner_check / name for name in [
    'checked.json', 'checks.json', 'selection.json', 'source-pins.json', 'check.py', 'owner-and-appends.txt']]
preflight_files += [proof_source, work / 'SourcePruningEnumerationSharedEagerReservation-BEFORE.lean.txt',
    work / 'Audit-BEFORE.lean.txt', work / 'AUDIT-PREFLIGHT.lean.txt',
    work / 'SourceSynthesisActualEagerProgramFragmentRoles-BEFORE.lean.txt', work / 'PreviousOwnerProbes252.lean.txt']
preflight_files += [packet / name for name in ['APPEND.lean.txt', 'IMPORTS.lean.txt', 'PROBES.lean.txt', 'MANIFEST.json']]
preflight = {'check': owner_check_name,
    'artifacts': {str(p.relative_to(root)): sha(p.read_bytes()) for p in preflight_files},
    'normal_owner_sha256': sha(owner), 'assembled_sha256': owner_selection['assembled_sha256'],
    'proof_source_sha256': sha(proof), 'old_owner_sha256': sha(before_owner),
    'preflight_audit_sha256': sha(preflight_audit), 'old_owner_offset': offset,
    'normal_fragment_sha256': sha(fragment), 'old_fragment_sha256': sha(before_fragment),
    'reports': 264, 'fresh_this_batch_before_publication': True,
    'recompiled_in_publication_strict_gate': False, 'axiom_strings_replayed': False}
(runtime / 'OWNER-FRESH-PREFLIGHT.json').write_text(json.dumps(preflight, indent=2) + '\n')
strict = runtime / 'strict-new-and-bind.py'
strict_head = '''from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

root = Path('/home/tritlo/Code/mcfta')
runtime = Path(__file__).parent
prior = root / 'lean/restart-evidence/20261117-actual-eager-role-producer-publication'
archive = root / 'lean/restart-evidence/20261117-actual-eager-role-producer-checkpoint'
work = root / 'lean/restart-evidence/20261117-whole-worker-program-roles-work'
sha = lambda data: hashlib.sha256(data).hexdigest()
selection = json.loads((runtime / 'INHERITANCE-SELECTION.json').read_text())
preflight = json.loads((runtime / 'OWNER-FRESH-PREFLIGHT.json').read_text())
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
audit_name = 'lean/MicroCFTA/Audit.lean'
fragment_name = 'lean/MicroCFTA/SourceSynthesisActualEagerProgramFragmentRoles.lean'
before_owner = (work / 'SourcePruningEnumerationSharedEagerReservation-BEFORE.lean.txt').read_bytes()
before_audit = (work / 'Audit-BEFORE.lean.txt').read_bytes()
before_fragment = (work / 'SourceSynthesisActualEagerProgramFragmentRoles-BEFORE.lean.txt').read_bytes()
preflight_audit = (work / 'AUDIT-PREFLIGHT.lean.txt').read_bytes()
assert sha((archive / 'manifest.json').read_bytes()) == selection['prior_archive_manifest_sha256']
committed = subprocess.check_output(['git', 'show', selection['prior_checkpoint'] + ':'
    + str((archive / 'manifest.json').relative_to(root))], cwd=root)
assert committed == (archive / 'manifest.json').read_bytes()
subprocess.run(['python3', str(archive / 'verify.py')], check=True)
records = json.loads((archive / 'archived-inputs.json').read_text())
for name in ['checked.json', 'source-pins.json']:
    path = prior / name
    record = next(item for item in records if item['original'] == str(path))
    archived = (archive / record['archived']).read_bytes()
    if record['gzip']:
        archived = gzip.decompress(archived)
    assert archived == path.read_bytes()
assert sha((prior / 'checked.json').read_bytes()) == selection['prior_checked_sha256']
assert sha((prior / 'source-pins.json').read_bytes()) == selection['prior_pins_sha256']
old = {owner_name: before_owner, audit_name: before_audit, fragment_name: before_fragment}
for name, digest in json.loads((prior / 'source-pins.json').read_text()).items():
    data = old[name] if name in old else (root / name).read_bytes()
    assert sha(data) == digest, name
for name, digest in preflight['artifacts'].items():
    assert sha((root / name).read_bytes()) == digest, name
check = root / 'lean/restart-evidence' / preflight['check']
result = json.loads((check / 'checked.json').read_text())
assert result['owner_append_checked'] and all(result['passed'])
assert len(result['checks']) == 2 and result['checks'][1]['total_axiom_reports'] == 264
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx']
           for c in result['checks'])
owner = (root / owner_name).read_bytes()
assert sha(owner) == preflight['normal_owner_sha256'] == preflight['assembled_sha256']
assert sha(before_owner) == preflight['old_owner_sha256']
offset = preflight['old_owner_offset']
assert owner[offset:offset + len(before_owner)] == before_owner
fragment = (root / fragment_name).read_bytes()
assert sha(fragment) == preflight['normal_fragment_sha256'] and fragment.startswith(before_fragment)
owner_selection = json.loads((check / 'selection.json').read_text())
assert owner_selection['assembled_sha256'] == sha(owner)
assert owner_selection['reports'] == 264 and owner_selection['previous_owner_reports'] == 252
assert owner_selection['new_private_reports'] == 12
assert owner_selection['old_owner_bytes'] == len(before_owner) == 2446450
old_probes = (work / 'PreviousOwnerProbes252.lean.txt').read_bytes()
proof = (check / 'source/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean').read_bytes()
assert sha(proof) == preflight['proof_source_sha256']
assert proof.startswith(owner + b'\\n' + old_probes)
assert old_probes.count(b'#print axioms ') == 252 and proof.count(b'#print axioms ') == 264
for name, digest in json.loads((check / 'source-pins.json').read_text()).items():
    data = before_owner if name == owner_name else preflight_audit if name == audit_name else (root / name).read_bytes()
    assert sha(data) == digest, name
assert sha(preflight_audit) == preflight['preflight_audit_sha256']
output = (check / 'owner-and-appends.txt').read_text()
groups = [set(x.strip() for x in group.split(',') if x.strip())
          for group in re.findall(r'depends on axioms:\\s*\\[([^]]*)\\]', output, re.S)]
free = len(re.findall(r'does not depend on any axioms', output))
assert len(groups) + free == 264
assert not (set().union(*groups) - {'propext', 'Classical.choice', 'Quot.sound'})
assert 'sorryAx' not in output and not re.search(r': error(?:\\(|:)', output)
assert selection['inherited_reports'] == 127
assert selection['fresh_owner_preflight_reports'] == 264
assert selection['fresh_strict_normal_reports'] == 14
print(json.dumps({'inherited_reports_verified': 127, 'fresh_owner_reports_verified_this_batch': 264,
    'actual_fresh_strict_reports_expected': 14, 'owner_recompiled_here': False}), flush=True)
'''
strict.write_text(strict_head + '\ncommands = ' + repr(commands)
                  + '\nfor command in commands:\n    subprocess.run(command, check=True)\n')
template = (prior_run / 'check.py').read_text()
driver = template[:template.index('\njobs =')]
jobs = [('public-build', 'exec lake build', 0),
    ('strict-new-components-and-prior-bindings', 'exec python3 ' + shlex.quote(str(strict)), 14),
    ('independent-imports', 'exec lake env lean -j1 -DwarningAsError=true ' + shlex.quote(str(independent)), 251),
    ('audit-build', 'exec lake build MicroCFTA.Audit', 0),
    ('audit-strict', 'exec lake env lean -j1 -DwarningAsError=true MicroCFTA/Audit.lean', 656)]
driver += '\njobs = ' + repr(jobs) + '''
for name, command, count in jobs:
    run(name, command, count)
assert len(checks) == 5
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx']
           and (not job[2] or c['total_axiom_reports'] == job[2]) for c, job in zip(checks, jobs))
match = re.search(r'Checked axiom dependencies of (\\d+) MicroCFTA theorems\\.', (runtime / 'audit-strict.txt').read_text())
assert match
'''
report = dict(prior)
for name in ['checks', 'limits', 'at', 'audited_theorems', 'checked_code', 'board_prefix']:
    report.pop(name, None)
report.update(prior_checkpoint=binding['prior_checkpoint'], public_run=str(runtime),
    prior_immutable_archive=prior_archive.name, source_files=6248, direct_audit_imports=5248, individual_reports=656,
    independent_reports=251, resource_and_component_probes=405,
    fresh_resource_component_reports=278, inherited_resource_component_reports=127,
    fresh_owner_preflight_reports=264, fresh_strict_normal_reports=14, actual_publication_strict_reports=14,
    resource_component_evidence='264 fresh owner reports before publication, 14 fresh normal-module strict reports, and 127 prior reports with archive/source/toolchain bindings; prior 252 owner plus 13 normal reports are replaced',
    owner_preflight_evidence=preflight, owner_recompiled_in_publication_strict_gate=False,
    new_component_reports=13, new_theorem_reports=13, new_modules=0, new_public_theorems=2,
    new_private_component_reports=11, new_public_component_reports=2,
    new_relation_declaration_checks=0, new_private_predicates=1,
    legacy_new_private_reports=12, legacy_new_private_reports_caveat=binding['legacy_new_private_reports_caveat'],
    owner_resource_probes=264, previous_owner_resource_probes=252,
    old_non_audit_non_owner_non_fragment_sources_byte_exact=6245,
    old_non_audit_non_owner_source_files_byte_exact=6245, old_non_audit_source_files_byte_exact=6245,
    entire_previous_resource_owner_byte_exact=False, old_owner_bytes_preserved_contiguously=len(before_owner),
    old_owner_offset=offset, old_fragment_prefix_bytes=len(before_fragment), old_fragment_prefix_exact=True,
    old_owner_proof_bodies_unchanged=True, old_owner_proof_limits_unchanged=True,
    selected_eager_program_fragment_roles_proved=True,
    whole_worker_roles_proved=True, whole_worker_program_slots_proved=True,
    whole_worker_program_slots_fixed_marks_proved=True,
    native363_staged=False, reader_alias_staged=False, native_source_admission_proved=False, source_active_mu_admission_proved=False,
    generic_packet_only_2c6_closed=False, source_to_arbitrary_current_row_fields_proved=False,
    source_type_marker_class_consistency_proved=False, joint_finite_completion_proved=False,
    haskell_refolded_root_outer_gate_correspondence_proved=False, haskell_changed=False,
    proof_limits='unchanged defaults; original owner proof settings retained; new owner declarations use 200000')
driver += 'report = ' + repr(report) + '\n'
driver += '''report.update(checks=checks, limits=limits, at=datetime.datetime.now().astimezone().isoformat(),
              audited_theorems=int(match.group(1)))
(runtime / 'checked.json').write_text(json.dumps(report, indent=2) + '\\n')
print(json.dumps(report), flush=True)
'''
(runtime / 'check.py').write_text(driver)
files = list((root / 'lean/MicroCFTA').glob('*.lean'))
files += [root / name for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']]
files += [p for p in runtime.iterdir() if p.is_file()] + strict_sources
files += [Path(__file__), work / 'SOURCES-NORMAL-STAGING.json', work / 'baseline-source-pins.json',
    prior_run / 'checked.json', prior_run / 'source-pins.json', prior_archive / 'manifest.json'] + preflight_files
(runtime / 'source-pins.json').write_text(json.dumps({str(p.relative_to(root)): sha(p.read_bytes())
    for p in files}, indent=2) + '\n')
print(json.dumps({'run': str(runtime), 'gates': 5, 'fresh_owner_preflight_reports': 264,
    'actual_strict_reports': 14, 'fresh_reports_this_batch': 278, 'inherited_reports': 127,
    'combined_resource_and_component_reports': 405, 'independent_reports': 251,
    'audit_reports': 656, 'owner_recompiled_in_strict_gate': False, 'objects': str(objects)}))
