Ancestry target stress test and bounded local candidate

Created 2026-10-28 19:50:03 CET. Repository read-only. No compiler, native execution, Git, network or board call. The previous output-prefix area remains unchanged.

Result

Plain raw storage of an unenumerated native value does not imply a live representative. The earlier proposed CompletedHeadReceipt.fresh_pending_ancestry interface also includes an actual completed receipt with its full completed Packet. That Packet contains Safe. Safe includes LiveRoots. Therefore the proposed interface's raw pending-slot witness DOES imply a live representative through an existing original receipt field. No new root premise is necessary.

This resolves only the raw-slot objection. The complete head-wide ancestry theorem remains unproved. Source inspection must not be described as a proof of that theorem.

Raw slot, representative and candidate

EnumerationSchedule.LiveRoots says that every allocated raw value differs from eliminated exactly when its slot is an IsRoot representative. The actual receipt.completed.safe.2 therefore yields, for the original proposed witness stored,

  (receipt.completed.safe.2 slot (.unenumerated (some nativeHandle) bucket) stored).mp
    (by simp)

with conclusion IsRoot after.core.representatives slot. Allocation bounds also follow from Safe storage and stored. The original proposed interface already supplies a fresh lower bound and an after-counter upper bound.

Without Safe, raw storage alone has no such implication. TerminalPrefix first unites representatives and retains the value array. A raw source may therefore still be unenumerated at that intermediate prefix while its representative has changed. The following successful fold eliminates the absorbed raw sources. The prefix's storage/canonical cache facts must not be mistaken for completed LiveRoots.

A live pending native slot also need not be a candidate. NativeIndex.candidate excludes an empty-bucket Mu or Union. The proposed pending-slot ancestry statement covers these boundary holders as well. A theorem about scheduled candidates must additionally use the actual candidate flag and its existing index correctness; it must not infer candidacy from the raw pending constructor.

Does assimilation leave an absorbed source pending and clear its ancestry?

The inspected successful nontrivial operations do not do that:

- SourcePruningEnumerationAssimilation.finish writes the target, writes source=eliminated, then updates target recursion ancestry with source++target followed by eraseDups. Other per-slot recursion ancestry is unchanged.
- CachedAssimilation.finish performs the two actual NativeIndex.write operations, then applies that same target ancestry union. It preserves the raw source's old per-slot ancestry. Its Empty branch returns the unchanged cache and no rows.
- EnumerationCorrectness.assimilated records both raw writes and exactly that ancestry update.
- Finalize.run clears expansionAncestry and replaces the captured raw slot. It leaves the per-slot recursionAncestry field unchanged. The captured target is an original allocated root, so it cannot be one of the proposed fresh slots.
- FoldLanguage.run_complete_semantics retains the exact fold completion fields: completed non-target recorded sources are eliminated, expansion ancestry is unchanged, and per-slot ancestry away from the target is unchanged.

Thus an absorbed raw source cannot retain an unenumerated value at an actual completed safe receipt. Its per-slot ancestry is not cleared by the inspected successful assimilation either. No Haskell defect or full operational counterexample is claimed.

Clarification of the unproved head-wide target

Keep the same original CompletedHeadReceipt and all its old fields. Keep the original stored handle separate from the prepared parent. The proposed conclusion may be written more explicitly as

  IsRoot after.core.representatives slot AND
  (forall key in before.core.expansionAncestry,
     key in after.core.recursionAncestry slot).

The first conjunct is already derived from receipt.completed.safe and stored. The second still needs the full allocation/child/assimilation/finalization composition. This is an explanatory strengthening of the conclusion, not a new admission gate. An alternative candidate-only formulation can add the actual after.expandable slot=true observation, but that narrows the target and is not needed to fix the raw-slot objection.

One local candidate

The immutable candidate is ../candidate-v1/MicroCFTA/SourcePruningEnumerationCachedAssimilationAncestry.lean. It imports the installed CachedAssimilation source. It has one public export:

  SourcePruningEnumerationCachedAssimilation.finish_ancestry observed

Every state, heap, slot, fuel, option and row index is implicit. The sole explicit hypothesis is the literal actual observation

  finish heap fuel source target merged sourceScs targetScs before = some (rows, after).

It concludes BOTH:

1. Every key in every original raw slot's recursion ancestry remains in that same raw slot's returned recursion ancestry.
2. If merged is not some0, every original source key belongs to the returned target ancestry.

The second clause has an explicit non-Empty gate because the Empty branch returns the original cache without transferring keys. The first clause also covers that branch. No live-root, source-distinctness, Packet, native model, resource bound, supplied later Heap or future completion premise is required for this local point statement.

The private helper derives per-slot ancestry equality directly from an actual NativeIndex.write observation. The public proof follows the two actual writes and the final ancestry union. It does not infer state fields from a semantic Post rule.

Exact runtime/completion scope

CachedFold.run executes CachedAdapter.run, which executes Dispatch.dispatch and the captured action. CachedAssimilation.finish is the installed companion cached assimilation computation used by CachedDispatch.complete. That completion retains its literal finish observations at every cache fuel and aligns its rows with the actual dispatch action; CachedAdapter.complete then keeps the same raw/core result. The new point lemma does not itself prove this alignment or a new dispatch coverage statement. Existing completion evidence supplies the alignment when composing it into that runtime.

No desired future key universe is assumed. The candidate is not a termination theorem and does not supply the head-wide fresh-pending theorem. Root must compile and review it. There are no new Lean runtime definitions, custom axioms, sorry/admit, native_decide, budget changes or linter suppressions.

Read scope and status

source-manifest.json preserves exact source bytes and SHA256 identities for the stated whole reads and literal cuts. Candidate-v1 is frozen, uncompiled and source-only. Previous frozen evidence and repository sources were not edited.
