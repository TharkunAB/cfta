# Actual incoming-node projection heap

Status: UNTESTED candidate. Root owns compilation. The imported incoming-query adapter has default and exact strict PASS as reported by root.

One additive module exports one theorem:
`SourcePruningEnumerationIncomingNode.observed_resources_projection_heap`.
It retains `observed_resources`' original input gates and original Fits/Known conclusions. It adds only the ORIGINAL caller projection heap as an input and appends the full physical projection heap at the SAME actual `afterCaller`.

## Actual branch coverage

The proof follows the actual `IncomingNode.run` cases and the checked arity observation proof.

- Representative-fuel failure, missing slot, and eliminated/enumerated slot keep the native caller. Their inner raw errors are included.
- `oldNode = none` keeps the native caller for both possible encoding observations. A raw Empty rejection is included.
- A missing native lookup keeps the native caller.
- For a present native handle, original PendingRealized supplies the actual old value's availability and closure. Its lookup equation identifies that value with the actual decoded operand.
- A successful native query and optional Empty check use `raw_done_resources_projection_heap` at the exact observed bounds. The returned caller equality from the actual run transports its Fits, Known and derived whole projection heap to the SAME caller in the supplied observation. Both failed encoding and successful finish branches are included. Empty rejection keeps its actual native effects.
- Native yielded/failed/constraintError/blocked and failed Empty-worker observations are incompatible with the supplied outer `.ok`. No projectability preservation for arbitrary failed native prefixes is claimed.

Original Context, pending realization, operand availability/closure, Fits, Room and Known remain explicit. No future heap, child support, replacement availability, model, emitted output or completion certificate is an input. The proof adds no source/prepared identity equation or raw-conjoin closure law.

## Replacement and lookup attachment

The compact public adapter retains the reached whole heap invariant. It does not add a general all-successful-lookups annotation field. That extension would need reached linked/cached Facts and would duplicate a larger resource-producer tuple solely to obtain them. Root explicitly selected the smaller adapter first.

The existing `run_complete_resources` already returns, in the SAME produced outcome, `Post` for the actual caller, `Available` for its actual replacement, replacement closure, encoding, and literal `lookupNode` readback. Its stable actual run at base fuels supplies the observation for the new theorem. The new result's `.2.2` is the reached ProjectionHeap. Combine that field with `post.context.ready.semantic.ready.semantic.1.normal.facts.linked` and the already returned replacement availability in `SourceEqualityAnnotationHeap.available`. This derives `Annotated projectable replacement` for that SAME replacement. Retain its existing literal lookup witness. It assumes no new future availability or model.

This is the direct next attachment inside the existing producer or its current consumer. It requires no second producer family or generic certificate type. The one module deliberately does not clone `run_complete_resources`' large tuple. Broader propagation through incoming folds, terminal children, ordered traversal and whole recursive callbacks remains outside this local adapter.

## Evidence and preservation

`manifest.json` binds six whole installed source reads and two exact literal cuts. Their copies remain under `evidence-v1`. The one candidate has a complete readback and hash. No compiler, native execution, Git, repository edit, network, board, admitted proof, custom axiom, proof-budget change, linter suppression, or sealed-area write was used. No Haskell source changed and no new Haskell defect or repair was established.

Candidate and report are frozen after this handoff.
