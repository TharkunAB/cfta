PASS: independent terminal projection source-contract review

Created 2026-10-28 20:01:02 CET. The installed primary file was read whole: 188 lines, 12,451 bytes, SHA256 fc91529c9f368894c76623afceda4b74837e872b54bcd449e74fcd4a54d48aa9. The expected identity matches. No compiler, native execution, Git, network, board or repository write was used.

Exact public claim

SourcePruningEnumerationTerminal.observed_resources_projection_heap retains the full old admission and the same actual outer-success observation of Terminal.run. It adds only originalProjection at beforeCaller.checked.native.machine.heap. Its conclusion retains the exact old Fits and known-alphabet Heap at afterCaller, in the same order, and appends ProjectionHeap at that SAME afterCaller heap.

ProjectionHeap means every physical native edge constraint passes SourcePruningEnumerationConstraint.project. It is a structural projection predicate. It does not assert a semantic model, successful enumeration or whole-driver coverage.

The complete old and new source declarations were compared mechanically. After removing only the new originalProjection premise and final ProjectionHeap conjunct, renaming the theorem and normalizing whitespace, they match exactly. No old resource witness, hypothesis or returned caller index is removed or replaced. The proof calls old observed_resources on the same observed run and retains resources.1 and resources.2 directly.

Actual prefix and fold

The actual singleton prefix observation supplies recorded, winner, moved and joined. TerminalAdmission.observed_prefix derives recorded=(first::rest).map roots, joined PendingRealized, winner PendingAt and every recorded source PendingAt from the original safe cache, roots, waiting counts, bounded bucket and pending references. These are not future-state admission hypotheses.

The exact recorded length derives the fold reservation from the original mixed reservation. Fold.observed_resources_projection_heap consumes originalProjection at the original caller. It derives the projection heap at the actual reached foldCaller for any outer .ok fold observation. Early return does not reset the native caller.

For a literal singleton fold, Fold.initial_ranges is derived from the original Context, pending facts, Fits, known heap and reservation. The existing finite Fold.run_complete produces Post, full final memos, query equality, PendingRealized and the precise raw shape. Fold.ok_unique compares that derived completion with the literal observed fold at the requested bounds. It identifies the result, native caller, saved queries and outer core. The singleton raw shape then identifies actualCore=folded. These equalities transport the already-derived facts; no supplied later Context or Heap is used.

Actual incoming merge

The incoming theorem receives the SAME foldCaller and folded core. Its Context is post.context at the produced next inventory and final full memos. PendingRealized is rewritten to the observed singleton core. Original incoming availability is transported through post.effects.keeps.available; original closedness remains explicit. The fold-derived Fits, known heap and projection heap are passed forward. Original reservation supplies Room for the one final incoming query.

The literal incoming observation uses final.query=saved foldQueries. IncomingNode.observed_resources_projection_heap derives the heap at reachedCaller. The terminal tuple equality then identifies reachedCaller with the theorem's afterCaller. The proof preserves the actual reached native heap for every incoming Option/raw result; it does not infer that heap from a semantic Post preservation rule.

Return-shape coverage

- Initially Empty incoming returns some[] at the unchanged original caller. The projection heap is originalProjection; the old resource pair is padded by its original theorem.
- A fold .ok none or .ok(some[]) retains its actual foldCaller and derived projection heap. Any native work before the missing/rejected result is retained.
- A singleton successful fold proceeds to the exact incoming run. Incoming none and some raw results retain that run's actual caller, including Empty rejection or raw read errors. Terminal maps raw incoming errors into its raw result without discarding the caller effects.
- Prefix faults or malformed prefix output, fold outer errors, non-singleton/error fold raw shapes and incoming outer errors produce a terminal outer error. They cannot satisfy the theorem's explicit outer .ok observation and are excluded by contradiction.

The theorem does not require a produced enum output, some cache, nonempty raw result or final Satisfies. It also does not claim resource preservation for terminal outer errors, prove existence of an outer successful observation, derive finite recursive depth, discharge suspended constraints or establish global coverage.

Source and prepared separation

This is a local theorem about the actual shared Terminal.run and native caller. It introduces no nominal worker cast, original-source/prepared-parent equality or preparation language equivalence. No future endpoint, future heap or model oracle is added to the admission.

Review scope

Seven whole sources and five literal source cuts are preserved with SHA256 identities. Eight complete source declaration blocks are copied under signatures/. The manifest distinguishes literal source declarations from elaborated public readback. Root owns compiler, strict, Audit and public verification; those running checks were not run or certified here. No concern was found in this bounded source-contract review.
