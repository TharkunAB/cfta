"""Strictly check the two new ordered-fold components in sequence."""
from pathlib import Path
import subprocess
import sys

area = Path('/tmp/mcfta-prepared-projectability-lineage-20261028')
for label, module in [
    ('strict-dispatch-projection-1', 'SourcePruningEnumerationDispatchProjectionHeap'),
    ('strict-fold-projection-1', 'SourcePruningEnumerationFoldProjectionHeap')]:
    subprocess.run([sys.executable, str(area / 'check-installed.py'),
        'strict', label, module], check=True)
