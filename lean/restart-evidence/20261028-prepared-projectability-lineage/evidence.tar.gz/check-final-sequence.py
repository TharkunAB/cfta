"""Check the terminal composition and final Audit/public interface in sequence."""
from pathlib import Path
import subprocess
import sys

area = Path('/tmp/mcfta-prepared-projectability-lineage-20261028')
for args in [
    ['lake', 'build-terminal-projection-1', 'MicroCFTA.SourcePruningEnumerationTerminalProjectionHeap'],
    ['strict', 'strict-terminal-projection-1', 'SourcePruningEnumerationTerminalProjectionHeap'],
    ['lake', 'build-audit-final', 'MicroCFTA.Audit'],
    ['strict', 'strict-audit-final', 'Audit'],
    ['public', 'public-final']]:
    subprocess.run([sys.executable, str(area / 'check-installed.py'), *args], check=True)
