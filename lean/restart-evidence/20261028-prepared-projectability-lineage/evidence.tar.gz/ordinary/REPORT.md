# Actual incoming allocation projectability lineage

Status: one small UNTESTED additive candidate. Root owns compilation.

The missing local adapter is
`SourcePruningEnumerationIncomingQuery.raw_done_resources_projection_heap`
in the candidate module `SourcePruningEnumerationIncomingQueryProjectionHeap`.
No native preservation primitive or model/origin wrapper is duplicated.

## Existing route

- `ProjectionHeap.constructed_projectable` derives the initial whole physical projection heap from original `SourceChecked` syntax and the actual closed construction.
- `SelectedPreparation.run_projectable_heap` and `complete_rows_projectable` already preserve actual normalization and derive every actual prepared ordinary row's projection support. The original source and prepared parent remain distinct.
- `TargetQuery.Receipt.projection_heap` already follows the actual completed rich native trace. `ConjunctionProjectionHeap.call_heap` already follows an actual optional emptiness call. These are the two local operations in the allocating incoming-query branch.
- `IncomingQuery.complete_resources` already produces one stable complete native receipt and the actual optional emptiness call, with exact checked states, memos, replacement availability and closure.
- `IncomingNode.observed_heap` for arity shows the exact attachment point: the outer successful incoming branch exposes native and phase observations before it encodes and writes its replacement. It uses the resource uniqueness adapter at that point. The existing arity adapter does not derive projectability.

## New exact interface

The candidate retains `raw_done_resources`' original Context, operand availability/closure, Fits, Room and Known premises. It adds the ORIGINAL caller's physical projection heap and retains the same two literal successful observations: native intersection `.done query queried`, then the optional check `.done answer checkedAfter saved` with its actual query memos.

It retains the old two resource conclusions in order. It appends:

1. The full physical projection heap at the supplied `checkedAfter`.
2. `Annotated projectable (if answer then .empty else query)` for the actual replacement. `Annotated` inspects the complete subtree, so this derives guard support for its ordinary rows and children. It is not a supplied child-support gate.

The proof calls the original resource producer once. Its actual target-query receipt preserves the original projection heap. A disabled or skipped Empty phase keeps that heap. A performed phase consumes its actual conjunction call and preserves the same whole heap. The original postcondition supplies linked records, and original producer availability derives the replacement's complete annotation property. Native completion uniqueness and optional-check uniqueness identify those produced states and values with the SAME supplied successful observations. No future model is used.

## Genuine original gate and remaining attachment

The original physical projection heap remains explicit. `Packet` contains Context, safe enumeration storage, pending references, native cache validity, stratification and bounded pending template variables. It does not contain this projection invariant. `Known` says only that resident guards belong to an alphabet. `NativeGuardAlphabet.step` contains every raw ordered conjunction, so alphabet membership cannot be silently replaced by projectability.

The initial gate has an existing checked-source producer. This candidate does not assume projectability at a future child or reached caller. Carrying the invariant from that original checked construction through every earlier caller-changing branch remains the whole-producer attachment. The candidate is a local step for that induction, not an initial-to-arbitrary-callback oracle.

For the next attachment, use the actual `IncomingNode.run` branch decomposition already shown by its arity observation theorem. Apply the new adapter to its literal native and phase observations. Propagate the resulting caller heap through actual incoming fold, terminal child, ordered traversal, and captured head receipts. Nonterminal shallow child allocation and callback metadata recording do not change the native caller. Include aggregate endpoints from callbacks with empty output lists. Keep the separately available prepared parent and original stored handle separate.

This does not construct an emitted recursive output, bound allocating recursion, remove an earlier stop, prove full accepted-output coverage, or establish Haskell correspondence. It uses no arbitrary raw-conjoin closure or projectability of the whole forecast alphabet.

## Prior obstruction scope

`CheckedProjection.raw_ready_counterexample` is a real raw makeEdge result with Ready, Cached annotations, a resident allowed-arity edge, and failed projection. It does not construct a full public Packet, accepted model, admitted recursive execution, or Haskell defect. This review does not strengthen that counterexample. No new Haskell defect or required fix is established.

## Evidence and preservation

`manifest.json` binds every complete listed source read and the two literal cuts. It states which broad discovery outputs were truncated and excludes them from whole-read claims. Source copies and candidate identities are preserved. A pre-install exact-name search found no existing incoming-query projection adapter. No compiler, native evaluation, Git, repository write, network, board, admitted proof, custom axiom, budget change, linter suppression, or sealed-area write was used.

Candidate and report are frozen after this handoff.
