# Root final contract review

PASS. All six final installed source bodies were read whole: 808 lines and
48,830 bytes. The ancestry variant is bound by the original whole candidate and
the exact five-line installed repair. All 20,718 new elaborated signature and
axiom bytes were read without truncation. public-new-blocks.log preserves them.
The prior 3,080,208 public bytes remain an exact prefix.

Five projectability adapters retain the exact old Fits/Known pair and every old
input. Only ORIGINAL operation-caller ProjectionHeap is added. It is not derived
from forecast alphabet membership. Native receipt/optional conjunction traces
preserve it; actual successful observations are aligned by completion uniqueness.
The query adapter also derives structural annotation support of its replacement.

Incoming-node and dispatcher observations preserve the actual returned caller,
including supported absent, rejected and inner-error returns. They do not assert
invariants for arbitrary outer native failures. Ordered fold singleton recursion
gets next Context, Post, full Memos and query equality from the original actual
singleton producer. Projection comes separately from the actual dispatcher.
Terminal recovers the same fold caller/core/queries from original run_complete
and ok_unique. Its Post derives the incoming Context and availability. The new
incoming adapter derives the final heap. Empty/no-output endpoints remain.

The ancestry point lemma takes only an actual successful CachedAssimilation.finish
observation. It retains every slot key. Transfer to the target has the necessary
merged != some0 gate. Both actual NativeIndex writes preserve ancestry; the final
eraseDups union preserves both source and target memberships. Existing cached
completion supplies runtime alignment; this lemma does not reprove it or infer
finite keys. The completed-head ancestry interface remains unproved.

No future output, child support, later Heap, semantic model, finite-key universe,
termination certificate, generic future-step supplier or source/prepared cast
appears. No whole-driver projectability or coverage claim is added. Earlier
original rendered soundness, finite canonical/history/arity and output-prefix
contracts remain unchanged. Intended partial outputs remain. DONE != Discharged.

Seven final strict checks pass. Matrix: fifteen commands, fourteen passes and
one preserved failed ancestry attempt. Root read the full 4,640-byte diagnostic.
The repair changes only current ite lemma names and explicit conditional reduction.
It changes no contract. No budget, axiom, placeholder, native proof evaluation or
linter suppression was added. New axioms are subsets of the standard three.

All inherited source identities were verified. Independent reviews pass in
peer-incoming/review-v1, peer-node-ancestry/review-v1,
peer-dispatch-fold/review-v1 and peer-terminal/review-v1. Their source-only read
scopes and compiler ownership remain explicit. Root read their complete reports.
No Haskell source changed, check ran, or new defect/fix was established.

The separate ChildDispatch candidate remains UNTESTED. Its frozen complete
candidate/report/evidence directory is copied under next-draft-child with a
complete copy manifest. It is not an installed module or part of the six checked
exports. Do not conflate that preserved draft with a verified result.
