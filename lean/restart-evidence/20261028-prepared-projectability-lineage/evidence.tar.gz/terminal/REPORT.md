# Terminal projection heap adapter

Date: 2026-10-28T19:58:39+01:00.

One additive candidate derives `ProjectionHeap` at the actual returned caller of every outer successful `Terminal.run` observation. The original current resource premises suffice. No additional trace or Context interface is missing for this local step. The child did not compile the candidate. Root owns installation and checks.

## Public interface

Module: `SourcePruningEnumerationTerminalProjectionHeap`.

Theorem: `SourcePruningEnumerationTerminal.observed_resources_projection_heap`.

Every original argument of `Terminal.observed_resources` is retained. The only new proof input is `originalProjection` at the original `beforeCaller`, placed last after `known`. A literal comparison of both argument signatures passes after removing only that input and restoring the old theorem name.

The observer is the actual outer `.ok result` at the supplied representative/native/Empty bounds. It retains the exact returned caller, query endpoint, outer core, and waiting table. There is no assumption that these supplied bounds exceed a separately chosen successful bound.

The conclusion retains the old `Fits` and `Known` pair at `advance seed ((first :: rest).length + 1)`. It appends `ProjectionHeap` at that same returned caller. The original pair is obtained directly from `Terminal.observed_resources`. The new proof then proves only the appended heap property.

## Actual state connections

1. Empty incoming returns the original caller. Its original projection heap remains valid.
2. The actual singleton prefix supplies the recorded sources and joined pending realization through existing `CachedTerminalAdapter.observed_prefix`. Its exact source count derives the original fold reservation.
3. The new `Fold.observed_resources_projection_heap` supplies the actual fold caller's Fits, Known, and projection heap. A missing fold action and an empty fold result retain that caller.
4. For an actual successful fold singleton, the original `Fold.run_complete` receipt supplies full endpoint memos, `Post`, and reached pending realization. `Fold.ok_unique` identifies its caller, query endpoint, and raw result with the actual observation. The produced raw shape identifies the actual returned singleton core.
5. That actual `Post.context` is the next native Context. Its `effects.keeps.available` retains the original incoming operand's availability at the fold caller. Existing closure is unchanged. The original mixed reservation supplies numeric room for the final incoming query.
6. `IncomingNode.observed_resources_projection_heap` consumes these derived current facts and the derived fold projection heap. It returns the actual final incoming caller's projection heap. The terminal observation identifies that caller exactly.

No forward heap property is inferred from `Post` growth. The physical heap invariant comes from the actual fold and incoming operation theorems. The original completion receipt is used only to recover its real Context, memo and operand attachment.

## Observation limits

The theorem covers `.ok none`, `.ok (some [])`, successful incoming raw rows, and inner enumeration errors retained under outer `.ok`. It does not require the result to contain an output. Invalid prefix shapes, outer native failures, optional Empty failures, and invalid fold raw shapes produce outer errors and contradict this observer.

The theorem does not claim heap preservation for those outer error observations. It does not derive a successful output, coverage, termination, rendering, or whole-driver semantics. It has no future heap, future child support, model, termination certificate, generic preservation supplier, or source/prepared identity premise. It introduces no producer family and changes no existing resource tuple. No Haskell code changed.

## Evidence and status

The immutable candidate has 12,451 bytes and 188 lines. SHA256: `fc91529c9f368894c76623afceda4b74837e872b54bcd449e74fcd4a54d48aa9`.

`manifest.json` records six whole source reads in this task and two prior whole reads rebound to the current source by exact byte equality. It also records the literal Terminal source cut at lines 1 through 82. That cut includes the complete actual `run` definition. A whole-source hash for a cut does not imply a whole-source read.

The candidate, copied inputs and report are frozen. Compilation and any integration remain with Root.
