import MicroCFTA.SourceCurrentAllocatedNativeInventoryState
import MicroCFTA.SourceCurrentAllocatedNativeGlobalMemos
import MicroCFTA.SourceCurrentConjunctionClassScan

/-!
# Exact checked intersections for current target operands

The raw step records the actual checked request with an empty domain.
Completion computes the next inventory at the literal entry heap. The
same returned state has physical readiness, exact intersection language,
and an operational trace with no global unfolding event. Existing global
tables remain coherent. Reached machine ranges and initial warm cache
admission remain explicit. Runtime forcing stays separate.
-/
namespace MicroCFTA.SourceCurrentAllocatedTargetQuery
open Cache Language InternedConstructorTemplates InternedProbeProvenance
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace)
open SourceCurrentAllocatedNativeInventoryState (Inventory At)
open SourceCurrentAllocatedNativeEffects (physical)
open SourceCurrentConjunctionClassScan (Ready)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Checked" => SourceEqualityNativeDemand.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Valid" => EndpointMemoGateTrace.Valid
local notation "WordRanges" => SourceCurrentAllocatedNativeRequestBounds.WordRanges
variable {width : Nat}

/-- One actual checked intersection retains its complete returned state. -/
inductive Step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (left right : Value Symbol Guard) (before : Checked width) :
    Value Symbol Guard → Checked width → Prop where
  | run {fuel : Nat}
      (trace : Trace fuel (.code (requestNode IntersectionEmptyDomain.emptyDomain left right)) before
        (.code (.pure value)) after) : Step left right before value after

/-- A raw completed step has a literal finite checked execution. -/
theorem Step.done [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    {left right value : Value Symbol Guard} {before after : Checked width}
    (actual : Step left right before value after) :
    ∃ fuel, execute fuel (.code (requestNode IntersectionEmptyDomain.emptyDomain left right)) before = .done value after := by
  cases actual with
  | run trace => exact ⟨_, trace_done _ _ before after value trace.steps⟩

/-- Completed steps from one entry return the same value and every state field. -/
theorem Step.unique [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    {left right first second : Value Symbol Guard} {before afterFirst afterSecond : Checked width}
    (leftStep : Step left right before first afterFirst) (rightStep : Step left right before second afterSecond) :
    first = second ∧ afterFirst = afterSecond := by
  obtain ⟨firstFuel, firstDone⟩ := leftStep.done
  obtain ⟨secondFuel, secondDone⟩ := rightStep.done
  exact SourceCurrentAllocatedNativeColdClosedExact.completed_unique firstFuel secondFuel _ before
    afterFirst afterSecond first second firstDone secondDone

/-- One literal return retains its computed inventory and the same global table bundle. -/
structure Receipt [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (formulas : SourceGuards.Formulas FullSyntax.Formula) (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (left right : Value Symbol Guard) (before : Checked width)
    (value : Value Symbol Guard) (after : Checked width) (memos : Memos) : Prop where
  actual : Step left right before value after
  ready : Ready after
  admitted : At formulas solver inventory after
  effects : SourceCurrentConjunctionRowsAllocation.Effects (physical before) (physical after)
  extension : Extension before.native.machine after.native.machine
  available : Available after.native.machine.heap value
  closed : value.free = []
  meaning : ∀ ambient term,
    InternedGuardedLanguage.meaning (SourceEqualityPCSGuard.holds formulas solver) ambient value term ↔
      InternedGuardedLanguage.meaning (SourceEqualityPCSGuard.holds formulas solver) ambient left term ∧
      InternedGuardedLanguage.meaning (SourceEqualityPCSGuard.holds formulas solver) ambient right term
  globals : Valid after.native.machine.heap memos
  events : ∃ events, SourceGlobalUnfold.Runs ⟨before.native.machine.heap, memos.unfolding⟩
    ⟨after.native.machine.heap, memos.unfolding⟩ events ∧ SourceGlobalUnfold.NoGlobal events

/-- Initial admission constructs the actual query, its next inventory, and every returned receipt. -/
theorem finite [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (formulas : SourceGuards.Formulas FullSyntax.Formula) (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (left right : Value Symbol Guard) (before : Checked width)
    (ready : Ready before) (admitted : At formulas solver inventory before)
    (leftAvailable : Available before.native.machine.heap left) (rightAvailable : Available before.native.machine.heap right)
    (leftClosed : left.free = []) (rightClosed : right.free = [])
    (ranges : WordRanges (.code (requestNode IntersectionEmptyDomain.emptyDomain left right)) before)
    (memos : Memos) (valid : Valid before.native.machine.heap memos) :
    ∃ next : Inventory, ∃ value after,
      next.source = before.native.machine.heap ∧ next.roots = inventory.roots ++ [left, right] ∧
      Receipt formulas solver next left right before value after memos := by
  obtain ⟨next, fuel, value, after, source, roots, query, current⟩ :=
    SourceCurrentAllocatedNativeInventoryState.query_complete inventory formulas solver before ready.good admitted
      ready.scopedCache ready.semantic ready.idle left right leftAvailable rightAvailable leftClosed rightClosed ranges
  have checked := SourceCurrentAllocatedNativeTraceEffects.effects query.trace ready.good ready.semantic ready.costs
    (fun _ => trivial)
  obtain ⟨events, runs, silent, finalValid⟩ := SourceCurrentAllocatedNativeGlobalMemos.trace_memos
    query.trace ready.good ready.semantic ready.costs (fun _ => trivial) memos valid
  exact ⟨next, value, after, source, roots, ⟨.run query.trace,
    ⟨checked.1, checked.2.1.ready.semantic, checked.2.1.ready.costs, query.scopedCache, query.idle⟩,
    current, checked.2.1, checked.2.2, query.result, query.closed, query.meaning,
    finalValid, events, runs, silent⟩⟩

/-- Any actual completed step has these receipts at its own literal returned state. -/
theorem Step.verified [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (formulas : SourceGuards.Formulas FullSyntax.Formula) (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) {left right value : Value Symbol Guard} {before after : Checked width}
    (actual : Step left right before value after)
    (ready : Ready before) (admitted : At formulas solver inventory before)
    (leftAvailable : Available before.native.machine.heap left) (rightAvailable : Available before.native.machine.heap right)
    (leftClosed : left.free = []) (rightClosed : right.free = [])
    (ranges : WordRanges (.code (requestNode IntersectionEmptyDomain.emptyDomain left right)) before)
    (memos : Memos) (valid : Valid before.native.machine.heap memos) :
    ∃ next : Inventory,
      next.source = before.native.machine.heap ∧ next.roots = inventory.roots ++ [left, right] ∧
      Receipt formulas solver next left right before value after memos := by
  obtain ⟨next, result, reached, source, roots, receipt⟩ := finite formulas solver inventory left right before
    ready admitted leftAvailable rightAvailable leftClosed rightClosed ranges memos valid
  obtain ⟨rfl, rfl⟩ := actual.unique receipt.actual
  exact ⟨next, source, roots, {receipt with actual := actual}⟩

end MicroCFTA.SourceCurrentAllocatedTargetQuery
