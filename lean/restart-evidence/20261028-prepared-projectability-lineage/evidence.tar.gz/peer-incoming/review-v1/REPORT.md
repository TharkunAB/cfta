# Incoming query projection-heap source review: PASS

Reviewed the WHOLE installed SourcePruningEnumerationIncomingQueryProjectionHeap module without truncation. It has 114 lines and 6623 bytes. SHA256: 7cc3016fc1af3587f86bbee24b02d928f99a5d489ae74e1555c3208f97478d38. The source snapshot preserves those bytes. The exact new and old source signatures are saved separately. Root's default build was running at assignment. This review did not compile and does not infer compiler success.

## Original premises and retained old result

raw_done_resources_projection_heap retains the old raw_done_resources arguments and literal execute/optional-check observations. It adds one explicit originalProjection premise at beforeCaller.checked.native.machine.heap. Its first two result conjuncts are exactly the old returned Fits forecast and annotation Heap for membership in the generated guard alphabet. Both are returned at the supplied checkedAfter state.

The original Context, operand availability, closedness, Fits, Room, and original alphabet-membership Heap remain explicit. The added projectability premise is also original. No returned Heap, returned projectable value, future support certificate, future model, or family of assumed successful executions is an input.

## Membership and projectability are separate

SourceEqualityAnnotationHeap.Heap valid quantifies over actual physical edge-record keys and applies valid to each key's constraint. The old Known invariant uses valid guard = membership in alphabet. ProjectionHeap instead uses valid constraint = Constraint.project constraint != none. Membership in an arbitrary alphabet does not imply projectability. The proof does not make that inference.

The new originalProjection premise supplies the physical projectability invariant. The generated-alphabet membership Heap and the returned ProjectionHeap remain separate result conjuncts. Annotated projectable on the actual replacement supplies the semantic node-edge and child annotation property. Its definition follows ordinary children, union members, and the semantic Mu body. It is not a claim about a semantic assignment or about every arbitrary constraint in the forecast alphabet.

## Actual query and optional Empty branches

The proof calls the existing complete_resources producer with the original inputs. The exact returned SourceCurrentAllocatedTargetQuery.Receipt retains the actual native query trace and its endpoint. Receipt.projection_heap transports the original physical ProjectionHeap through that actual trace, using the original good state. No later projectability premise is supplied.

For checkEmpty=false, the disabled tuple's .2.2.1 identifies the final checked state with the queried state. For an enabled but skipped check, the skipped tuple's .2.1 gives that same endpoint equality. Both branches reuse the actual query ProjectionHeap.

For an enabled performed check, the producer returns the actual physical conjunction endpoint, the exact checked-state advance equation, and an actual ConjunctionMemo.Call. Receipt.ready supplies good/semantic/cost facts for the queried state, and receipt.available supplies the actual query value in that heap. The conjunction call_heap lemma preserves physical projectability for both memo hits and misses. Its premises are supplied at that same actual endpoint. The advance equation then gives the final produced ProjectionHeap.

## Same returned state and replacement at arbitrary successful fuels

The supplied native observation is a literal successful execute at fuel. The producer also supplies a successful execute at its own computed n. completed_unique compares these two executions from the same original checked state. It identifies both query values and entire returned checked states. It imposes no fuel <= n or n <= fuel gate.

The supplied optional phase is a literal successful tuple at p/h. optional_done_unique compares it with the producer's phase at its own P/H. It identifies the Boolean answer, entire checked state, fourth memo, and query memo for all successful supplied bounds. The theorem uses the exact state and answer equalities; it does not assume primitive fuel errors remain stable at higher fuel.

The producer's Post supplies linked facts at the final physical heap. Its actual available replacement, together with the derived final ProjectionHeap, gives Annotated projectable through AnnotationHeap.available. The producer's replacement equation identifies that value with if producedAnswer then empty else producedQuery. Native and optional-phase uniqueness then rewrite it to the supplied answer and query. Thus the extra annotation result refers to the actual returned replacement, rather than a separate chosen witness.

## Verdict and limits

PASS: old Fits/Known pair retained exactly; original projectability explicit; actual trace and optional Empty branches used; supplied successful endpoints identified by uniqueness; no future Heap/support/model assumption; actual replacement annotation derived.

The theorem remains conditional on original projectability and on successful literal observations. It does not derive original projectability from alphabet membership, prove global enumeration completeness, or supply a semantic model of the final state. No source change is needed.

## Evidence

The manifest records exact whole or partial dependency read scopes. An early combined output was truncated in an unused proof-body section; the complete resource contract and required tuple fields were then read again without truncation. The primary 114-line source was read whole without truncation and its hash was checked again before the report was sealed.

No repository or old frozen area was edited. No compiler, native proof evaluation, Git, network, or board call was made. No Haskell file changed and no Haskell finding was established.
