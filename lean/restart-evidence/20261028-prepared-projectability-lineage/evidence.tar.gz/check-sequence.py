"""Run the two new source builds and strict checks sequentially."""
from pathlib import Path
import subprocess
import sys

area = Path('/tmp/mcfta-prepared-projectability-lineage-20261028')
for kind, label, module in [
    ('lake', 'build-incoming-node-projection-1', 'SourcePruningEnumerationIncomingNodeProjectionHeap'),
    ('lake', 'build-assimilation-ancestry-1', 'SourcePruningEnumerationCachedAssimilationAncestry'),
    ('strict', 'strict-incoming-node-projection-1', 'SourcePruningEnumerationIncomingNodeProjectionHeap'),
    ('strict', 'strict-assimilation-ancestry-1', 'SourcePruningEnumerationCachedAssimilationAncestry')]:
    args = ['MicroCFTA.' + module] if kind == 'lake' else [module]
    subprocess.run([sys.executable, str(area / 'check-installed.py'), kind, label, *args], check=True)
