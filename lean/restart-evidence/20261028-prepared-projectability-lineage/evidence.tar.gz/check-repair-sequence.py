"""Check the repaired ancestry proof and both remaining strict sources in order."""
from pathlib import Path
import subprocess
import sys

area = Path('/tmp/mcfta-prepared-projectability-lineage-20261028')
for kind, label, module in [
    ('lake', 'build-assimilation-ancestry-2', 'SourcePruningEnumerationCachedAssimilationAncestry'),
    ('strict', 'strict-incoming-node-projection-1', 'SourcePruningEnumerationIncomingNodeProjectionHeap'),
    ('strict', 'strict-assimilation-ancestry-1', 'SourcePruningEnumerationCachedAssimilationAncestry')]:
    args = ['MicroCFTA.' + module] if kind == 'lake' else [module]
    subprocess.run([sys.executable, str(area / 'check-installed.py'), kind, label, *args], check=True)
