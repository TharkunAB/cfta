"""Retain every prior document byte after the current verified proof update."""
from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path('/home/tritlo/Code/mcfta')
AREA = Path('/tmp/mcfta-prepared-projectability-lineage-20261028')
now = datetime.datetime.now().astimezone().strftime('%Y-%m-%d %H:%M %Z')
records = json.loads((AREA / 'prior-documents.json').read_text())
for record in records:
    path = ROOT / record['path']
    old = (AREA / 'prior-document-bodies' / record['path']).read_bytes()
    assert path.read_bytes() == old
    prefix = f'''# Verified native projectability update: {now}

Source: `dbc7c240c0ee313467681bab22586c50437459b0` on `formalize`.
Read `lean/notes-current-prepared-projectability-lineage.md` from the repo root.
Every earlier document byte follows this update unchanged.

Original physical projectability now survives actual incoming query/write,
dispatch, ordered fold and terminal outer-success returns. The exact old
Fits/Known pair remains. Empty and absent results keep actual native effects.
Only ORIGINAL caller ProjectionHeap is added. No future heap or step supplier
is assumed. Whole recursive transport remains open. Actual cached assimilation
retains slot ancestry and transfers source keys on non-Empty merges.

Earlier original rendered soundness, finite canonical/history/arity resources,
and exact output-prefix preservation at greater recursive depth remain intact.
Largest gap: actual model-preserving output emission and an original finite
depth for all earlier ordered allocating callbacks and the continuation.
Complete policies/origin lineage, public adapters and Haskell correspondence
remain open. DONE does not imply Discharged. Intended partial outputs remain.

Six modules add six public theorems, no definitions. Seven exact final strict
sources pass. Audit: 4,519 jobs/81,661 dependencies. Public: 701 theorems,
60 definitions, 3,100,926 bytes; prior 3,080,208 bytes an exact prefix.
Fifteen compiler commands: fourteen pass, one preserved failed ancestry proof
attempt. The repair changes five Lean simplifier lines; all final checks pass.
All 4,512 prior non-Audit Lean, 361 stronger and 817 Haskell/Cabal hashes remain.

No Haskell source changed, no Haskell check ran, and no new Haskell defect or
fix was established. FINDINGS.md retains earlier external repair records.
Complete evidence: lean/restart-evidence/20261028-prepared-projectability-lineage/.
Board sequence 705 has verified author, content and metadata readback.
The separate ChildDispatch draft remains UNTESTED and is preserved in that
archive. Continue in a new writable area. Keep frozen evidence immutable.
Full goal ACTIVE. Normal pushes to the authorized formalize branch remain
authorized. Keep every proof, counterexample, repair and marked draft.

'''
    path.write_bytes(prefix.encode() + old)
paths = [record['path'] for record in records] + ['lean/notes-current-prepared-projectability-lineage.md']
final = []
for relative in paths:
    data = (ROOT / relative).read_bytes()
    final.append(dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    target = AREA / 'final-document-bodies' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
for record in records:
    assert (ROOT / record['path']).read_bytes().endswith(
        (AREA / 'prior-document-bodies' / record['path']).read_bytes())
(AREA / 'final-documents.json').write_text(json.dumps(final, indent=2) + '\n')
print(json.dumps(dict(prior_exact_suffixes=len(records), final_documents=len(final))))
