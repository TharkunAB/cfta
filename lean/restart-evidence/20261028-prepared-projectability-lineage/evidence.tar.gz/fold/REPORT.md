# Actual dispatcher projection heap adapter

Date: 2026-10-28T19:54:21+01:00.

The candidate adds one theorem. It preserves the projection heap at the actual outer successful `Dispatch.dispatch` return. The candidate has not been compiled by this child. Root owns installation and checks.

## Interface

Module: `SourcePruningEnumerationDispatchProjectionHeap`.

Theorem: `SourcePruningEnumerationDispatch.observed_resources_projection_heap`.

The theorem retains every original argument of `Dispatch.observed_resources`. It adds `originalProjection` at `beforeCaller`, after `known`. It accepts the same literal outer `.ok result`, actual returned caller, and actual saved query endpoint. The result is the original forecast `Fits` and forecast `Known` pair, followed by `ProjectionHeap` at that exact returned caller.

`ProjectionHeap` states that every resident edge constraint projects. The input is a property of the original caller of this operation. It is not an assumed property of a later endpoint. Bare `Packet` and alphabet membership do not supply this input. The original checked source builder can supply the first heap; actual operation preservation must supply subsequent heaps.

## Actual branches

Branches without a native query retain the original caller. This includes equal slots, missing slots, eliminated sources, invalid source or target forms, missing optional handles, and failed lookups.

In the two-handle branch, actual pending realization derives both operands' availability and closure. Literal lookup equalities identify those operands. The proof invokes `IncomingQuery.raw_done_resources_projection_heap` on the actual native `.done` observation and actual optional Empty phase. That existing adapter uses the original complete native receipt, optional conjunction call, and completed-result uniqueness. The proof then identifies the returned caller from the actual dispatcher observation.

The theorem includes a missing encoded action and an action that later rejects with an empty raw result. It does not require a successful singleton. Outer native errors and outer optional Empty errors are excluded by the `.ok` observer. The theorem does not claim their reached heaps satisfy the conclusion.

## Fold and child route

`Terminal.run` first executes the representative prefix, then `Fold.run` on its recorded sources, then `IncomingNode.run` after a successful fold singleton. The fold calls `Dispatch.dispatch`; it does not call `IncomingNode.run` for each source.

`Fold.observed_singleton` already derives the actual next `Context`, full endpoint memos, pending realization, target and remaining source facts, and next `Fits`/`Known`. Its proof uses the actual original dispatcher completion receipt and `Dispatch.ok_unique`. It requires no future-step preservation supplier.

The direct fold induction can therefore use this candidate's reached projection heap together with those existing next-entry facts. Early fold returns retain the dispatcher heap. Exact singletons recurse at the actual returned caller and next seed. Root has whole-read `FoldArity`, `FoldResources`, and `FoldAdmission` and owns that next induction. This candidate does not duplicate it.

For the later terminal incoming phase, the existing original fold completion receipt and `Fold.ok_unique` identify the same completed caller, core, and query endpoint, as in `TerminalArity.observed_heap`. Its `Post` supplies the actual next `Context` and preserves the incoming operand's availability. The separately checked incoming-node adapter can then consume the fold's reached projection heap. This is a composition route, not a completed terminal or ChildDispatch preservation theorem in this candidate.

`ChildDispatch.erase` retains the actual raw caller observation under cache erasure. Empty and shallow child branches retain the original caller; the terminal branch uses the actual terminal call. These definitions do not establish the missing fold or terminal projection result by themselves.

## Scope

The candidate has no future heap, future child support, model, termination certificate, or generic step supplier premise. It assumes no identity between stored source syntax and a prepared parent. It makes no coverage, output existence, termination, public Haskell correspondence, or whole-driver claim. No Haskell code changed.

The candidate has 10,944 bytes and 178 lines. SHA256: `1ae70799db8e65f59372b4b5accdca0037de79d6c32c7e83f172134623669caa`.

`manifest.json` records nine complete source reads and three literal source cuts. All copied source bytes and cut boundaries are preserved. Whole-file identities for cut sources do not imply a whole-file read.

The candidate and this report are frozen. No further proof work is included.
