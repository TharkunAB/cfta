from pathlib import Path
import json,re
r=Path('/tmp/mcfta-whole-incoming-control-20261031');root=Path('/home/tritlo/Code/mcfta')
modules=json.loads((r/'modules.json').read_text());extensions=json.loads((r/'extension-modules.json').read_text());new=[];contracts=[]
def current_lines(name):
    data=(root/'lean/MicroCFTA'/f'{name}.lean').read_bytes()
    if name in extensions:
        assert name=='SourceSizedMinimumConvergence'
        original=(r/'prior-minimum-convergence.lean').read_bytes()
        assert data.startswith(original)
        data=data[len(original):]
    return data.decode().splitlines()

for name in modules+extensions:
    stack=[]
    for num,line in enumerate(current_lines(name),197 if name in extensions else 1):
        m=re.match(r'^(namespace|section|mutual)(?:\s+(\S+))?\s*$',line)
        if m:
            stack.append(m.group(2) if m.group(1)=='namespace' else None)
            continue
        if re.match(r'^end(?:\s|$)',line):
            assert stack,(name,num)
            stack.pop()
            continue
        m=re.match(r'^theorem\s+([A-Za-z_][\w.]*)',line)
        if m:
            fq='.'.join([scope for scope in stack if scope]+[m.group(1)])
            assert fq.startswith('MicroCFTA.'),(name,num,fq)
            fq=fq.removeprefix('MicroCFTA.');new.append(fq)
            contracts.append({'module':name,'line':num,'declaration':fq})
    assert not stack,(name,stack)
assert len(new)==len(set(new))
old=json.loads((r/'prior-public-declarations.json').read_text());assert not set(new)&set(old)
(r/'new-public-declarations.json').write_text(json.dumps(new,indent=2)+'\n')
(r/'public-declarations.json').write_text(json.dumps(old+new,indent=2)+'\n')
definitions=json.loads((r/'prior-public-definitions.json').read_text())
for name in modules+extensions:
    stack=[]
    for line in current_lines(name):
        scope=re.match(r'^(namespace|section|mutual)(?:\s+(\S+))?\s*$',line)
        if scope:
            stack.append(scope.group(2) if scope.group(1)=='namespace' else None);continue
        if re.match(r'^end(?:\s|$)',line):
            stack.pop();continue
        declaration=re.match(r'^(?:noncomputable\s+)?(?:def|abbrev|inductive|structure)\s+([A-Za-z_][\w.]*)',line)
        if declaration:
            fq='.'.join([v for v in stack if v]+[declaration.group(1)]).removeprefix('MicroCFTA.')
            assert fq not in definitions;definitions.append(fq)
(r/'public-definitions.json').write_text(json.dumps(definitions,indent=2)+'\n')
(r/'new-public-contract-locations.json').write_text(json.dumps(contracts,indent=2)+'\n')
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes()==(''.join('import MicroCFTA.'+name+'\n' for name in modules)).encode()+(r/'prior-Audit.lean').read_bytes()
print({'new_public':len(new),'total_public':len(old)+len(new),'by_module':{name:sum(c['module']==name for c in contracts) for name in modules},'audit_old_suffix':True})

previous_names=json.loads((r/'checkpoint-v2-public-declarations.json').read_text())
previous_definitions=json.loads((r/'checkpoint-v2-public-definitions.json').read_text())
new_names=[name for name in old+new if name not in previous_names]
new_definitions=[name for name in definitions if name not in previous_definitions]
assert old+new==previous_names+new_names
assert definitions==previous_definitions+new_definitions
previous_modules=json.loads((r/'checkpoint-v2-modules.json').read_text())
assert modules[:len(previous_modules)]==previous_modules
imports=''.join('import MicroCFTA.'+name+'\n' for name in modules if name not in previous_modules)
source=imports.encode()+(r/'public-v2.lean').read_bytes()+('\n'+''.join('#print MicroCFTA.'+name+'\n' for name in new_definitions)+''.join('#check MicroCFTA.'+name+'\n#print axioms MicroCFTA.'+name+'\n' for name in new_names)).encode()
public_source=r/'public-v3.lean'
if public_source.exists():assert public_source.read_bytes()==source
else:public_source.write_bytes(source)
print({'previous_checks':len(previous_names),'new_appended_checks':len(new_names),'new_appended_definitions':len(new_definitions),'source':'public-v3.lean'})
