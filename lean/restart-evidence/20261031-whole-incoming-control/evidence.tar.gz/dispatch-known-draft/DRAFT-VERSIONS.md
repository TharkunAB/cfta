V1: 159 lines. Initial source-only proof. Missing explicit operational decidable-equality instances in the theorem context.

V2: 161 lines. Same public contract and proof. Adds the three instances already required by the literal dispatcher. Final owner candidate. UNCOMPILED.

Both exact sources remain available. Root alone owns kernel checks, repairs, production installation, and publication.
