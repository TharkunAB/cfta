The only new public theorem is `MicroCFTA.SourceCurrentAllocatedNativeDispatchKnown.dispatch_known`.

It takes the current admitted caller, current cache, actual dispatch parameters, current resource gates, current whole KnownOrdinary, and current native Stored.
Its current `slots` argument is the exact existing dispatch-completion shape gate.
It computes the literal dispatch result inside its conclusion.
Every outer successful result retains the OLD cache at the returned heap.
Every successful raw Core produced by its actual selected action also has KnownOrdinary at that heap and the SAME bound.
An outer error has no returned-cache conclusion.

No future target, receipt, lookup, per-dispatch Known, callback, trace, history, or completion result is supplied.
The private replacement certificate is derived from current slot membership and the existing actual target-result producer.

The theorem is an UNCOMPILED source-only candidate.
It closes no global worker-progress or original-depth claim.
