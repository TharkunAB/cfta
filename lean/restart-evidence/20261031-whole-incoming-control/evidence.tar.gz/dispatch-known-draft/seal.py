from datetime import datetime
from pathlib import Path
import hashlib
import json
import os

owner = Path('/tmp/mcfta-native-dispatch-known-review-20261031')
provider = Path('/tmp/mcfta-native-incoming-known-review-20261031')
manifest_bytes = (provider / 'MANIFEST.json').read_bytes()
provider_manifest = json.loads(manifest_bytes)
verified = []
for row in provider_manifest['files']:
    original = provider / row['path']
    data = original.read_bytes()
    assert len(data) == row['bytes'], original
    assert hashlib.sha256(data).hexdigest() == row['sha256'], original
    verified.append(row['path'])

metadata_names = {
    'MANIFEST.json', 'MANIFEST.sha256', 'pins.json', 'FROZEN-PINS.json',
    'FROZEN-PINS.txt', 'FROZEN', 'FROZEN.json',
}
copied = []
for original in sorted(provider.rglob('*')):
    if original.is_file() and original.name in metadata_names:
        relative = original.relative_to(provider)
        target = owner / 'providers' / 'incoming-known' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(original.read_bytes())
        copied.append({
            'provider_path': str(original),
            'retained': str(target.relative_to(owner)),
            'sha256': hashlib.sha256(original.read_bytes()).hexdigest(),
        })

provider_check = {
    'provider': str(provider),
    'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
    'payload_files_verified': len(verified),
    'payload_paths': verified,
    'metadata_copies': copied,
    'body_reuse': 'Only ledger-listed numbered cuts; no third whole body copied.',
    'closure': 'The full frozen provider remains available at its original directory. Root retains its complete incoming-known-draft archive.',
}
(owner / 'provider-verification.json').write_text(json.dumps(provider_check, indent=2) + '\n')

now = datetime.now().astimezone().strftime('%Y-%m-%d %H:%M %Z')
excluded = {'MANIFEST.json', 'pins.json', 'FROZEN'}
rows = []
for path in sorted(owner.rglob('*')):
    if not path.is_file():
        continue
    relative = str(path.relative_to(owner))
    if relative in excluded:
        continue
    data = path.read_bytes()
    rows.append({
        'path': relative,
        'bytes': len(data),
        'lines': len(data.splitlines()),
        'sha256': hashlib.sha256(data).hexdigest(),
    })

manifest = {
    'status': 'FROZEN SOURCE-ONLY; both proof drafts UNCOMPILED',
    'frozen_at': now,
    'files': rows,
    'payload_files': len(rows),
    'payload_bytes': sum(row['bytes'] for row in rows),
    'old_wholes': [
        '/home/tritlo/Code/mcfta/lean/MicroCFTA/SourcePruningEnumerationDispatch.lean',
        '/home/tritlo/Code/mcfta/lean/MicroCFTA/SourceSizedPrefixKnownOrdinary.lean',
    ],
}
(owner / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
pins = {
    'frozen_at': now,
    'manifest_sha256': hashlib.sha256((owner / 'MANIFEST.json').read_bytes()).hexdigest(),
    'final_source': 'SourceCurrentAllocatedNativeDispatchKnown-v2-UNCOMPILED.lean',
    'final_source_lines': 161,
    'final_source_sha256': hashlib.sha256((owner / 'SourceCurrentAllocatedNativeDispatchKnown-v2-UNCOMPILED.lean').read_bytes()).hexdigest(),
    'report_sha256': hashlib.sha256((owner / 'REPORT.md').read_bytes()).hexdigest(),
    'provider_manifest_sha256': provider_check['manifest_sha256'],
    'payload_files': len(rows),
    'total_files': len(rows) + 3,
    'status': 'UNCOMPILED source-only; Root owns kernel checks.',
}
(owner / 'pins.json').write_text(json.dumps(pins, indent=2) + '\n')
(owner / 'FROZEN').write_text('Frozen source-only. Both proof drafts remain UNCOMPILED. ' + now + '\n')
for path in owner.rglob('*'):
    if path.is_file():
        os.chmod(path, 0o444)
for path in sorted(owner.rglob('*'), reverse=True):
    if path.is_dir():
        os.chmod(path, 0o555)
os.chmod(owner, 0o555)
print(json.dumps(pins, indent=2))
print('pins.json SHA256', hashlib.sha256((owner / 'pins.json').read_bytes()).hexdigest())
