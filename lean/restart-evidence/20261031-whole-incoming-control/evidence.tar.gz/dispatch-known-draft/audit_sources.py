from pathlib import Path
import hashlib
import json

owner = Path('/tmp/mcfta-native-dispatch-known-review-20261031')
ledger_text = (owner / 'acquisitions.json').read_text()
entries = json.loads(ledger_text)
by_source = {}
for entry in entries:
    original = Path(entry['original_path'])
    data = original.read_bytes()
    assert hashlib.sha256(data).hexdigest() == entry['source_sha256'], original
    lines = data.decode().splitlines(keepends=True)
    assert len(lines) == entry['source_lines'], original
    retained = owner / entry['copy']
    assert hashlib.sha256(retained.read_bytes()).hexdigest() == entry['copy_sha256'], retained
    chosen = entry.get('actual_lines', [])
    if not chosen:
        chosen = [i for first, last in entry.get('line_ranges', []) for i in range(first, last + 1)]
    if entry['kind'] == 'named whole original':
        assert retained.read_bytes() == data
    else:
        expected = ''.join(f'{i}:{lines[i-1]}' for i in chosen)
        assert retained.read_text() == expected, retained
    row = by_source.setdefault(str(original), {
        'source_sha256': entry['source_sha256'],
        'source_lines': len(lines),
        'line_union': set(),
        'copies': [],
        'whole': False,
    })
    row['line_union'].update(chosen)
    row['copies'].append(entry['copy'])
    row['whole'] |= entry['kind'] == 'named whole original'

for row in by_source.values():
    row['line_union'] = sorted(row['line_union'])
    row['union_count'] = len(row['line_union'])
    row['union_fraction'] = row['union_count'] / row['source_lines']

assert sum(row['whole'] for row in by_source.values()) == 2
result = {'acquisitions': len(entries), 'originals': by_source}
(owner / 'cumulative-original-unions.json').write_text(json.dumps(result, indent=2) + '\n')
summary = [(row['union_fraction'], path, row['union_count'], row['source_lines'])
           for path, row in by_source.items() if not row['whole']]
print('Exact source and retained-copy verification PASS.', len(entries), 'acquisitions;', len(by_source), 'original paths.')
for fraction, path, count, total in sorted(summary, reverse=True)[:8]:
    print(f'{count}/{total} {fraction:.3f} {path}')

provider = Path('/tmp/mcfta-native-incoming-known-review-20261031')
metadata = owner / 'providers' / 'incoming-known'
metadata.mkdir(parents=True, exist_ok=True)
for name in ['MANIFEST.json', 'FROZEN-PINS.txt', 'FROZEN']:
    source = provider / name
    if source.exists():
        (metadata / name).write_bytes(source.read_bytes())
print('Retained provider metadata; full provider remains available at', provider)

for path in sorted(owner.glob('*UNCOMPILED.lean')):
    print(path.name, len(path.read_text().splitlines()), hashlib.sha256(path.read_bytes()).hexdigest())
