from pathlib import Path
import hashlib
import json

owner = Path(__file__).resolve().parent
manifest_bytes = (owner / 'MANIFEST.json').read_bytes()
pins_text = (owner / 'pins.json').read_text()
pins = json.loads(pins_text)
assert hashlib.sha256(manifest_bytes).hexdigest() == pins['manifest_sha256']
manifest = json.loads(manifest_bytes)
for row in manifest['files']:
    path = owner / row['path']
    data = path.read_bytes()
    assert len(data) == row['bytes'], path
    assert hashlib.sha256(data).hexdigest() == row['sha256'], path
    assert path.stat().st_mode & 0o222 == 0, path
assert len(manifest['files']) == pins['payload_files']
source = owner / pins['final_source']
assert hashlib.sha256(source.read_bytes()).hexdigest() == pins['final_source_sha256']
assert len(source.read_text().splitlines()) == pins['final_source_lines']
assert owner.stat().st_mode & 0o222 == 0
print('Frozen source-only payload replay PASS:', len(manifest['files']), 'payloads;', pins['total_files'], 'total files.')
print('Final candidate remains UNCOMPILED:', pins['final_source_sha256'])
