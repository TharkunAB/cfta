# Actual admitted dispatch: source-only candidate

The final candidate is `SourceCurrentAllocatedNativeDispatchKnown-v2-UNCOMPILED.lean`.
It has 161 lines. SHA256 is `d01ef6b39e2f3e351a5f4fd2082877a4a781de06324766a55d86750efbd69357`.
It is UNCOMPILED. No compiler, evaluator, native worker, Haskell program, Git command, network request, board tool, or child process agent was used.

## Exact contract

`dispatch_known` evaluates the literal `SourcePruningEnumerationDispatch.dispatch` at arbitrary supplied native, prefix, and height fuels.
Its query memo is the actual current `memos.query` in the admitted caller Context.
For every actual outer `.ok possible` result, it derives both statements at the literal returned caller heap:

1. The entire old cache retains `KnownOrdinary bound`.
2. Every successful raw Core row of every selected action has `KnownOrdinary bound`.

The second statement retains all successful rows, rather than just the new target slot.
The first statement covers the old cache when a raw action rejects with `[]`.
An outer `.error` has no returned-cache claim in this candidate.
The actual caller and action are the same endpoints in the observed dispatch result.

The inputs are the current Context, PendingRealized, whole current KnownOrdinary, Fits, Room, and native finite-ordinary Stored.
The `slots` gate is exactly the existing CURRENT slot-shape admission from `dispatch_complete`:
source equals target; or the source is eliminated; or both actual slots are pending.
This gate is not an assumed future slot result, path, trace, callback result, or target certificate.
The candidate does not establish that gate for the complete terminal call chain.
The existing terminal/fold caller must still derive it from its actual current pending-slot admission.

Three existing operational decidable-equality instances remain explicit.
They are the same instances required by the literal dispatcher.
No extra domain, closedness, lookup, replacement-height, or future receipt is supplied as a public input.

## Proof route

`initial_ranges` derives the native request ranges from the current Ready, PendingRealized, Fits, and Room gates.
The existing `dispatch_complete` produces a finite successful result and its Post from those current inputs.
`ok_unique` aligns that internally produced result with the actual outer successful observation, even when the supplied fuels differ.
This use of the existing producer does not add a future completion supplier to the theorem.
The candidate does not assert that arbitrary insufficient fuels return a successful result.

The aligned Post retains every physical old lookup at the actual reached heap.
The private `assimilated_known` lemma handles the two literal list updates: target replacement, then source elimination.
Old entries use the old whole-cache property.
The new entry uses a replacement certificate derived inside the public proof.

For an optional unassigned operand, the actual complete result identifies the copied handle with the other current slot.
That handle is already covered by old KnownOrdinary at the reached heap.

For two known operands, the dispatcher reads its source and target values from the actual `before.core.values` slots.
`List.mem_of_getElem?` turns those literal reads into membership in the SAME current cache.
Current KnownOrdinary then supplies each decoded ordinary operand and its original common cap.
The receipt's physical lookup equations identify those current values with the actual native operands.
Thus the SCS-selected source operand needs no separate domain or cap witness in this local dispatch theorem.
The proof does not infer a slot property from a detached SCS node value.

The internally produced actual target Receipt feeds `receipt_result`.
It derives an ordinary query whose height is at most either operand height.
The original common cap follows by transitivity.
Disabled emptiness keeps that query.
Enabled emptiness either keeps it or replaces it with Empty, which is ordinary and has height zero.
The completed result supplies the physical lookup of that actual replacement at the actual reached heap.

## Versions and static review

V1 has 159 lines, SHA256 `eedc795f74dac353e1ee395a4accca322f7f190d29f4a26a0d46082c7ccdd7a0`.
V2 retains that proof and header body. It adds the three existing operational decidable-equality instances before the public theorem.
Both files remain available and read-only.
No elaboration or strict-linter claim is made.
Root may need proof-only repairs for generated result reduction, equation substitution, or tuple patterns.
No logical obstruction was found in the bounded source review.

## Remaining terminal and global obligations

The terminal source-map inventory remains in force.
The actual cached fold needs an internal induction over its literal dispatch recursion.
It must carry whole KnownOrdinary for each successful raw Core and old-cache Known at the changed caller heap.
It must preserve the distinction between an index-cache adapter returning `none` and a raw Core row that can continue through the fallback path.
It must derive each next current slot-shape gate from the actual pending/eliminated slot facts.
The final incoming stage requires the separate whole Incoming transport; that owner draft is not imported here.
Those are internal proof obligations, not public future fold or callback witnesses accepted by this theorem.

No bound on the number of dispatches, restores, incoming replacements, or recursive resumes follows.
No sufficient original global depth, ordered-prefix completion, accepted-term production, public API correspondence, signed constraint normalization, Set correspondence, or Haskell equivalence follows.
No Haskell defect or fix was established. No FINDINGS change is proposed.

## Acquisition and provider closure

Exactly two OLD whole originals were named before acquisition: Dispatch435 and KnownOrdinary110.
The ledger has 53 acquisitions across 39 original paths.
Every retained code cut has its exact full-source hash, line selection, and retained-copy hash.
`cumulative-original-unions.json` combines reused cuts at their ORIGINAL paths.
The largest other union is 37/96 lines for KnownOrdinaryHeap; no third whole or near-whole source was acquired.
`audit_sources.py` checked every source pin and every retained cut against the literal original bytes.

The private Incoming179 provider remains frozen at `/tmp/mcfta-native-incoming-known-review-20261031`.
Only lines 13–66 and the declaration locator at 69 were reused, with overlap counted once.
Its full 74-file manifest payload is verified by the owner seal script.
Its existing manifest and pins are retained as provider metadata.
The public theorem does not depend on that uncompiled Incoming module.
It reuses only the small list-set proof pattern and records the instance setup for review.

Metadata command failures and the truncated display are retained in `INCIDENTS.md`.
They did not execute Lean or Haskell and did not change production files.
