299:def keep (state : State Symbol Guard) (_ : Key) (edge : Language.Edge Key Other) : Bool :=
