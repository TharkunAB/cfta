1:import MicroCFTA.EnumerationAssignment
10:namespace MicroCFTA.EnumerationExecution
35:def Retains (first second : EnumerateM Symbol Guard α) : Prop :=
39:theorem retains_bind (first second : EnumerateM Symbol Guard α)
48:theorem retains_refl (action : EnumerateM Symbol Guard α) : Retains action action := fun _ _ _ success => success
51:theorem retains_mapM (left right : α → EnumerateM Symbol Guard β)
63:theorem retains_foldlM (left right : α → β → EnumerateM Symbol Guard α)
74:theorem retains_forM (left right : α → EnumerateM Symbol Guard PUnit)
84:theorem union_moreFuel (leftFuel rightFuel leftExtra rightExtra : Nat) (forest : UnionFind.Forest)
99:theorem representative_moreFuel (fuel extra uv : Nat) :
107:theorem getValue_moreFuel (fuel extra uv : Nat) :
113:theorem unionVariables_moreFuel (fuel extra left right : Nat) :
123:theorem mergeNode_moreFuel (graph : Graph Symbol Guard) (fuel extra uv node : Nat) (scs : List Suspended) :
129:theorem mergeTerminal_moreFuel (graph : Graph Symbol Guard) (fuel extra : Nat) (first : Suspended) (rest : List Suspended) :
141:theorem enumeration_moreFuel (graph : Graph Symbol Guard) (fuel extra : Nat) :
197:theorem resolve_moreFuel (fuel extra : Nat) (blocked : List Nat) (sc : Suspended) :
203:theorem collect_moreFuel (graph : Graph Symbol Guard) (fuel extra : Nat)
215:theorem findExpandable_moreFuel (graph : Graph Symbol Guard) (fuel extra : Nat) :
224:theorem enumerateOut_moreFuel (graph : Graph Symbol Guard) (fuel extra uv : Nat) :
244:theorem checkRepeated_moreFuel (graph : Graph Symbol Guard) (fuel extra uv node : Nat) (scs : List Suspended) :
252:theorem enumerateFully_moreFuel (graph : Graph Symbol Guard) (order : OracleState → List Nat → Option Nat)
290:theorem expandFragment_moreFuel (graph : Graph Symbol Guard) (marker : Symbol) (fuel extra : Nat)
313:theorem expandUVar_moreFuel (graph : Graph Symbol Guard) (marker : Symbol) (fuel extra uv : Nat) :
324:theorem runs_moreFuel (graph : Graph Symbol Guard) (marker : Symbol) (fuel extra root : Nat)
351:theorem foldlM_terminates (action : Nat → α → β → EnumerateM Symbol Guard α)
371:theorem mapM_terminates (action : Nat → α → EnumerateM Symbol Guard β)
393:theorem forM_terminates (action : Nat → α → EnumerateM Symbol Guard PUnit)
413:theorem representative_terminates (before : State Symbol Guard) (total : UnionFind.Total before.representatives) (uv : Nat) :
421:theorem unionVariables_terminates (before : State Symbol Guard) (total : UnionFind.Total before.representatives)
431:theorem resolve_terminates (before : State Symbol Guard) (total : UnionFind.Total before.representatives)
439:theorem collect_terminates (graph : Graph Symbol Guard) (before : State Symbol Guard)
454:theorem findExpandable_terminates (graph : Graph Symbol Guard) (before : State Symbol Guard)
468:theorem findExpandable_progress (graph : Graph Symbol Guard) (meaning : Guard → Term Symbol → Prop)
