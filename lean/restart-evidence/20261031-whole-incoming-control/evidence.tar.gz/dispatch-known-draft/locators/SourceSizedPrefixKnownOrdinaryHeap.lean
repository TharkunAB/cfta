1:import MicroCFTA.SourceSizedPrefixKnownOrdinary
2:import MicroCFTA.SourceCurrentAllocatedPartialInvariant
3:import MicroCFTA.SourceCurrentConstrainedCapGeneratedQueryResources
4:import MicroCFTA.SourceCurrentAllocatedRecursiveWarmInitialRanges
5:import MicroCFTA.SourceRecursiveIntersectionOriginalOutput
15:namespace MicroCFTA.SourceSizedPrefixKnownOrdinaryHeap
30:theorem keeps_known {before after : State Symbol Guard} {cached : Cached}
41:theorem post_lookupNode
51:theorem post_known
60:theorem query_known
70:theorem finite_query_known (bits : Nat) (profile : Profile)
