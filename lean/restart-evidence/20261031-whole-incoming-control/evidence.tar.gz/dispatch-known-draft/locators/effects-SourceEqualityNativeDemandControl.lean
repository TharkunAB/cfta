20:theorem edge_ready_hit [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
70:theorem body_ready (request : EdgeRequest Symbol Guard) (next : EdgeValue Symbol Guard → Code Symbol Guard Output)
