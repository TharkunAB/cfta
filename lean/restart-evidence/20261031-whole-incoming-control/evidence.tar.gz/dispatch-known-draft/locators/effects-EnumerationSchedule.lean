592:theorem assimilated_live (graph : Graph Symbol Guard) (before : State Symbol Guard) (target source : Nat)
616:theorem assimilate_effect (graph : Graph Symbol Guard) (before after : State Symbol Guard) (target source : Nat)
