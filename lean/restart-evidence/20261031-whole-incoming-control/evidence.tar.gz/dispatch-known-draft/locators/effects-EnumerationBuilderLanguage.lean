69:def keep (state : BuildState Symbol Guard) (_ : Key) (edge : Language.Edge Key Other) : Bool :=
