96:theorem ready_readback (request : EdgeRequest Symbol Guard) (state : SourceEqualityNativeDemand.State width)
