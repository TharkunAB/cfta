1:import MicroCFTA.SourcePruningEnumerationIncomingObservedResources
2:import MicroCFTA.SourcePruningEnumerationDispatch
11:namespace MicroCFTA.SourcePruningEnumerationDispatch
21:private theorem ok_tuple_unique {E : Type _} {A : Type _} {B : Type _} {C : Type _}
29:theorem ok_unique
