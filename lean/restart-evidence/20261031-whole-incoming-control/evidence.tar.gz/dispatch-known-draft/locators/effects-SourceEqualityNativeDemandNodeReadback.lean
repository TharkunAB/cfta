22:theorem ready_selection (request : NodeRequest Symbol Guard) (before chosen current : Native width Symbol Guard)
