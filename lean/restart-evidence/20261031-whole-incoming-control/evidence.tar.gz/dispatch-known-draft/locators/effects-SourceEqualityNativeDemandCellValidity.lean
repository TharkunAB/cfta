169:theorem node_ready_receipt [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
186:theorem edge_ready_receipt [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
