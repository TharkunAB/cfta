52:theorem Walk.effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
