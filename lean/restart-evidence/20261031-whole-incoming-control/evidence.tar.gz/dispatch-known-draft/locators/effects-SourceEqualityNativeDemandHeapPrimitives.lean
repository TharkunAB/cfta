51:theorem optionalBinder_keeps [DecidableEq (EdgeKey Symbol Guard)] (pair : Nat × Nat) (body : Value Symbol Guard)
74:theorem work_keeps [DecidableEq (EdgeKey Symbol Guard)] (job : Work Symbol Guard Result)
