1:import MicroCFTA.SourcePruningEnumerationDispatchResources
2:import MicroCFTA.SourcePruningEnumerationIncomingQueryProjectionHeap
38:theorem observed_resources_projection_heap (alphabet : List Constraint) (profile : Profile)
