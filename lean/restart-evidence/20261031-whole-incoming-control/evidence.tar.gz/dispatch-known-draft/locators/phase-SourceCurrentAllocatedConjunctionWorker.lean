1:import MicroCFTA.SourceCurrentConjunctionWorker
2:import MicroCFTA.SourceCurrentAllocatedConjunctionMemo
29:def Outcome.state : Outcome width → Checked width
32:def Outcome.memo : Outcome width → Memo
36:noncomputable def call [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
46:theorem call_hit (p h budget : Nat) (query original : Value Symbol Guard) (before : Checked width)
52:theorem call_lift {p h budget : Nat} {query : Value Symbol Guard} {before : Checked width}
59:theorem call_failed_lift {p h budget : Nat} {query : Value Symbol Guard} {before : Checked width}
66:theorem call_done {p h budget : Nat} {query : Value Symbol Guard} {before after : Checked width}
80:theorem call_failed {p h budget : Nat} {query : Value Symbol Guard} {before after : Checked width}
97:theorem call_tables {p h budget : Nat} {query : Value Symbol Guard} {before after : Checked width}
