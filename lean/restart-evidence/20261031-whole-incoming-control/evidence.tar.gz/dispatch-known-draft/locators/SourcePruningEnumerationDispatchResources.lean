1:import MicroCFTA.SourcePruningEnumerationCachedDispatch
2:import MicroCFTA.SourcePruningEnumerationIncomingObservedResources
11:namespace MicroCFTA.SourcePruningEnumerationDispatch
33:theorem initial_ranges (profile : Profile) (beforeCaller : Caller (bits + 2)) (before : Core)
97:theorem observed_resources (alphabet : List Constraint) (profile : Profile)
235:namespace MicroCFTA.SourcePruningEnumerationCachedDispatch
257:theorem complete_resources
