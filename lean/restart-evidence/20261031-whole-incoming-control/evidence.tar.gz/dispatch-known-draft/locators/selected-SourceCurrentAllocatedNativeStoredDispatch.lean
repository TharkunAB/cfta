1:import MicroCFTA.SourceCurrentAllocatedNativeStoredExecute
2:import MicroCFTA.SourceCurrentAllocatedNativeStoredEnabledEmpty
3:import MicroCFTA.SourceCurrentConstrainedCapGeneratedQueryResources
4:import MicroCFTA.SourcePruningEnumerationDispatch
28:private theorem after_query_stored (checkEmpty : Bool) (p h source target : Nat)
57:theorem dispatch_native_stored (profile : Profile) (checkEmpty : Bool) (nativeFuel p h : Nat)
