22:def assimilated (state : EnumerationFlatState.State Symbol EnumGuard) (target source : Nat)
31:theorem assimilated_related (related : EnumerationFlatState.Related flat earlier)
