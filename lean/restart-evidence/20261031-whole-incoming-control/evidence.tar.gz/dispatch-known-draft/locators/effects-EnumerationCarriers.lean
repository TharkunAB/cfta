96:theorem assimilated_carriers (graph : Graph Symbol Guard) (before : State Symbol Guard) (target source : Nat)
