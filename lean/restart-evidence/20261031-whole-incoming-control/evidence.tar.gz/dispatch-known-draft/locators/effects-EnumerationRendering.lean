42:theorem ready_read (graph : Graph Symbol Guard) (level : Nat → Nat) (frontier : Nat) (before after : State Symbol Guard)
