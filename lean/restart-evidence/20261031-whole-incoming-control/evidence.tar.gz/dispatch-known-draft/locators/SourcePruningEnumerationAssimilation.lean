1:import MicroCFTA.SourcePruningEnumerationIntersectionWrite
3:namespace MicroCFTA.SourcePruningEnumerationAssimilation
23:def finish (source target resultHandle : Nat)
38:theorem pending_assimilation_complete
