89:theorem ready_cached (request : EdgeRequest Symbol Guard) (state : CheckedState width)
