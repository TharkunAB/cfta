1:import MicroCFTA.SourceCurrentAllocatedConjunctionWorker
2:import MicroCFTA.SourceCurrentConjunctionWorkerCompletion
3:import MicroCFTA.SourceCurrentConjunctionWorkerStability
4:import MicroCFTA.SourceCurrentAllocatedConjunctionCaller
35:theorem call_done_stable {p h P H budget : Nat} {query : Value Symbol Guard} {before after : Checked width}
43:theorem call_done_unique {p h P H budget : Nat} {query : Value Symbol Guard} {before after later : Checked width}
53:theorem verified {inventory : Inventory} {p h budget : Nat} {before : Caller width} {after : Checked width}
72:theorem finite {inventory : Inventory} {before : Caller width} {query : Value Symbol Guard} {memos : Memos}
