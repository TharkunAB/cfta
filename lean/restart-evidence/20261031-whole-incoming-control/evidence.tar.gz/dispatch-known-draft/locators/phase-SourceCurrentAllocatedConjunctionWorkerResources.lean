1:import MicroCFTA.SourceCurrentAllocatedConjunctionWorkerActual
2:import MicroCFTA.SourceCurrentConjunctionCallerNumeric
39:theorem finite_resources {inventory : Inventory} {before : Caller width}
68:theorem raw_done_resources {inventory : Inventory} {p h budget : Nat}
