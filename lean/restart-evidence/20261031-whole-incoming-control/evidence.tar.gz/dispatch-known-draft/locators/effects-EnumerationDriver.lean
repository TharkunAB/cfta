405:theorem findExpandable_ready (graph : Graph Symbol Guard) (fuel uv : Nat) (before after : State Symbol Guard)
422:theorem getValue_ready (fuel uv : Nat) (before after : State Symbol Guard) (value : UVarValue Symbol)
444:theorem checkRepeated_ready (graph : Graph Symbol Guard) (fuel uv node : Nat) (scs : List Suspended)
