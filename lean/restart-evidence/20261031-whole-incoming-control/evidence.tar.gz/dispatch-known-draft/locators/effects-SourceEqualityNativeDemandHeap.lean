49:theorem body_keeps (request : EdgeRequest Symbol Guard) (next : EdgeValue Symbol Guard → Code Symbol Guard Output)
56:theorem step_keeps [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
96:theorem execute_keeps [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
