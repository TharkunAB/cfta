41:theorem assimilated_pending (state : State Symbol Guard) (target source : Nat) (node : Option Nat) (scs : List Suspended)
