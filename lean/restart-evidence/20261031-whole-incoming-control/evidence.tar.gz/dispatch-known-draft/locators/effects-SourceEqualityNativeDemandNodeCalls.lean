98:theorem ready_call [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
132:theorem ready_walk [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
