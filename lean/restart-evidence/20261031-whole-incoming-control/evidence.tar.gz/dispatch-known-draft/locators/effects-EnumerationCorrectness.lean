277:def assimilated (state : State Symbol Guard) (target source : Nat) (merged : UVarValue Symbol) : State Symbol Guard :=
