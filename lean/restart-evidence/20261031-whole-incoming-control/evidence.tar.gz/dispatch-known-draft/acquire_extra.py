from pathlib import Path
import hashlib
import json

owner = Path('/tmp/mcfta-native-dispatch-known-review-20261031')
provider = Path('/tmp/mcfta-native-incoming-known-review-20261031')
source = provider / 'SourceCurrentAllocatedNativeIncomingKnown-v3-UNCOMPILED.lean'
raw = source.read_bytes()
lines = raw.decode().splitlines(keepends=True)
selected = list(range(13, 29))
target = owner / 'cuts' / 'prior-incoming-instance-namespace'
target.write_text(''.join(f'{i}:{lines[i-1]}' for i in selected))
ledger_path = owner / 'acquisitions.json'
ledger = json.loads(ledger_path.read_text())
ledger.append({
    'kind': 'named bounded prior instance setup',
    'original_path': str(source),
    'source_sha256': hashlib.sha256(raw).hexdigest(),
    'source_bytes': len(raw),
    'source_lines': len(lines),
    'actual_lines': selected,
    'copy': str(target.relative_to(owner)),
    'copy_sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
})
ledger_path.write_text(json.dumps(ledger, indent=2) + '\n')
print(target.read_text())

old = owner / 'SourceCurrentAllocatedNativeDispatchKnown-v1-UNCOMPILED.lean'
new = owner / 'SourceCurrentAllocatedNativeDispatchKnown-v2-UNCOMPILED.lean'
marker = '/-- Every actual successful dispatch retains old handles and certifies each returned Core. -/'
variables = 'variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]\n\n'
assert old.read_text().count(marker) == 1
new.write_text(old.read_text().replace(marker, variables + marker))
print('V2 retains the V1 body and adds the three existing operational decidable-equality instances.')
