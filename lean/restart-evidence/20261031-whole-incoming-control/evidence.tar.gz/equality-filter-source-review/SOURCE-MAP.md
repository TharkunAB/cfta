# Original equality-view source map

| Stage | Actual Haskell source | Existing Lean source | Remaining connection |
|---|---|---|---|
| Stored fields | Constraint.hs105–113: constraintEqualities and constraintGuard | SourceSymbolicIndex.Constraint17–19: equalities and guard | The Lean equalities field is the stored field. The full accessor is sourceEqualities. |
| Positive syntax | Constraint.hs171–176: Top, distinct Same, fully successful And; otherwise Nothing | SourceCompactGuards.positiveNormalized and positiveNormalizedList | The Lean guard paths are List Nat. Haskell paths contain signed ChildIndex values. |
| Normalization | Equality/Constraint.hs367–368: normalize after Set.fromList | SourceCompactGuards.normalize, arrayNormalize_eq, arrayNormalize_finished | Relate the actual signed Set classes and their enumeration to the natural-path source representation. |
| Merge | Equality/Constraint.hs449–459: contradiction absorption, both-empty shortcut, then memoized normalize of both class lists | SourceCompactGuards.combineEqualities, combine_active, combine_value | The case structure is available. The signed representation and exact source readback remain separate. |
| Full accessor | Constraint.hs129–136: unsupported syntax or EmptyConstraints keeps stored; otherwise combine | SourceCompactGuards.sourceEqualities | This is already a total model accessor at the current path type. |
| Cached transport | Original stored equalities are normalized | SourceEqualityGuardReadback.source_cached; SourceCompactGuards.sourceEqualities_active | Reuse the existing stored Cached gate. Do not add a positive-only gate or equality-view witness. |
| Complete acceptance | Full constraint acceptance retains any residual guard | SourceEqualityGuardReadback.accepted_equalities | Acceptance implies the combined equality payload for every guard branch. |
| Numeric projection | Prefix.hs614–626: Set.toList/unPath, singleton child paths, signed checked lookup | SourceSizedPrefixEqualSizes.directChildren, sizeOf, readSizes, allSame, equalSizes | Render the actual produced class view. A supplied view is already supported. |
| Signed lookup | Path contains ChildIndex Int | SymbolicSignedPaths.lookup, decode, lookup_decode, encode_lookup | Decode requires nonnegative paths. The bounded encode preserves lookup but is not injective for Same syntax. |

The getPath projection APIs operate on term and heap projections.
The full equality accessor is SourceCompactGuards.sourceEqualities.

## Three different failure values

1. positiveNormalized has type Option (Option classes). Outer none means unsupported positive syntax. The accessor keeps the stored field.
2. Its inner none means normalized EqContradiction. The accessor retains contradiction through combineEqualities.
3. Numeric readSizes none means a selected child lookup failed. That class fails the numeric filter.

The numeric EqualityView.none case means EqContradiction and passes the numeric prefilter.
It does not certify satisfiability.
These failure values must not be identified with one another.

## Exact positive syntax

A reflexive Same is residual because its path still has to exist.
A guard that contains any unsupported constructor causes positive extraction of the whole And to fail.
The accessor then keeps stored equalities.
It does not collect a positive Same from the supported siblings of that failed And.
The full guard remains in the row constraint.

## Numeric behavior

Only singleton child paths enter directChildren.
Root paths and deeper paths do not enter this numeric projection.
An empty selected list passes.
A negative selected index fails before toNat conversion.
An out-of-range selected index fails.
A failed selected lookup returns numeric false.
An outer contradiction view returns numeric true.
The complete constraint evaluator decides the remaining semantic cases.
