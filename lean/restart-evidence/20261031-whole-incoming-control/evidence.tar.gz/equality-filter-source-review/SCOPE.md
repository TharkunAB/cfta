# Scope

Source-only full original equality-view producer for the computed startup filter.
Named OLD whole1: current SourceSizedPrefixEqualSizes.lean117.
OLD whole2 will be named before acquisition after bounded type/projection discovery.
All other old source bodies use named bounded cuts at original paths.
Root owns all compiler/evaluator/native/Haskell/Git/network/board/production work.
No spawning is permitted.
No reduced syntax or supplied public equality-view witness may replace the original producer.
Contradiction numeric success must not be called satisfiability.
