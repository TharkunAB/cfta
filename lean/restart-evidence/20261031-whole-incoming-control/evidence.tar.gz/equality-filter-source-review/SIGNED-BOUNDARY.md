# Signed-path boundary

Haskell ChildIndex is Int.
Haskell Path stores a list of ChildIndex values.
The numeric source checks child >= 0 before dropping child elements.
SourceGuards.Path is List Nat.
SourceSymbolicIndex.Constraint uses that natural path in both fields.

SymbolicSignedPaths already supplies signed lookup and decode.
Its decode rejects a negative segment.
Its bounded encode maps every negative segment to one impossible natural index.
encode_lookup proves lookup preservation under a term arity bound.
It does not prove injectivity of that encoding.

In particular, different negative segments have the same encoded index.
A negative segment and the nonnegative bound index also have the same encoding.
The source positive extractor first tests whether the two complete paths differ.
Those distinct paths can become equal after this encoding.
The positive Same branch can then become the residual reflexive Same branch.
Thus the existing lookup theorem alone does not commute with full guard extraction.
This is a type and representation obstruction.
It is not a Haskell runtime defect or an executed counterexample.

The existing blind_toNat_changes_lookup theorem records a second boundary.
A blind toNat path map can turn a missing negative child into child zero.
The positivity proof used for computed minimum values does not apply to arbitrary path indexes.

No original nonnegative-path property was established in these bounded reads.
Adding that as a public gate would restrict the full original signed input scope.
A faithful full signed producer or an internally derived original-input codec
is needed before claiming the all-signed source filter correspondence.
