# Original equality-view producer boundary

## Result

The existing full accessor is SourceCompactGuards.sourceEqualities.
It already combines the stored field with the normalized positive guard view.
SourceSymbolicIndex.Constraint.equalities is only the stored field.
A numeric filter that reads that field alone omits the successful guard contribution.

The task closes as a source map and exact next-contract report.
No new all-signed producer theorem or Lean module is supplied.
The conditional producer scope cannot be met from the current natural-path full
constraint type with the signed correspondence already available.
The current-model expressions in NEXT-CONTRACTS.md give the smallest useful
filter producer without a new public view gate.
Their original all-signed Haskell correspondence remains separate.

The owner ran no compiler, evaluator, native program or Haskell.
The owner made no production, Git, network or board change.
No new kernel-checked result is claimed.

## Actual source behavior

The Haskell Constraint stores normalized equality classes and a full Guard.
positiveEqualities accepts Top, distinct-path Same and wholly successful And.
A reflexive Same remains residual because the path must exist.
Any unsupported operand causes positive extraction of the entire And to fail.
The accessor then retains stored equalities.
It does not collect only the supported siblings of a failed conjunction.

Positive Same normalizes its pair.
And normalizes every right-fold combination.
An extracted contradiction remains a successful syntax result with a contradictory
payload, rather than becoming unsupported syntax.
Constraint.equalities preserves its empty-guard fast path.
The general combiner absorbs contradiction, keeps the both-empty shortcut and
otherwise normalizes the concatenated class sets.
The retained actual Haskell cuts pin these exact branches.

## Existing Lean producers and exports

SourceCompactGuards.positiveNormalized and positiveNormalizedList model that
staged normalization at every Same and And step.
sourceEqualities applies the complete accessor case split.
arrayNormalize_eq and arrayNormalize_finished supply the existing completed
normalizer readback.
The source API already derives its normalization work through its existing
termination result; no new future completion certificate is needed here.
The definitions are noncomputable because that existing API chooses a proved
sufficient work amount.

combineEqualities, combine_active and combine_value are the existing merge exports.
SourceEqualityGuardReadback.source_cached derives Cached for the full accessor
from the startup's existing stored Cached gate.
sourceEqualities_active gives the corresponding active payload fact.
accepted_equalities derives the full accessor payload from complete constraint
acceptance for arbitrary guards.
sourceEqualities_exact gives the stronger complete guard law on positive syntax.
No positive-only premise is needed merely to produce sourceEqualities or its cache fact.

SOURCE-MAP.md records the Haskell and Lean stages and exact bounded locators.

## Three failure layers

Outer none from positiveNormalized means unsupported syntax and keeps stored data.
Inner none means normalized EqContradiction.
Numeric readSizes none means a selected child lookup failed and rejects the class.
The numeric EqualityView.none contradiction case returns true.
That numeric result is not satisfiability.
These failure layers must remain separate.

The numeric code already keeps only singleton child paths.
It ignores root and deeper paths at this projection.
An empty selected list passes.
Negative and out-of-range selected indexes fail their lookup.
The existing generic cast/filtered-splits laws cover these branches at a supplied view.

## Precise signed-domain obstruction

Actual ChildIndex is Int and actual Path contains ChildIndex values.
SourceGuards.Path is List Nat.
Both fields of the current SourceSymbolicIndex.Constraint use that natural path.
Thus the original signed constraint is not itself an input value of this type.
A nested Int.ofNat map renders represented natural paths but cannot establish the
full original signed-domain accessor correspondence by itself.

SymbolicSignedPaths supplies signed lookup and decode.
Its bounded encode preserves lookup under an arity bound.
It maps all negative segments to one impossible natural index.
That encoding can identify two paths that were distinct before encoding.
The positive extractor tests distinctness before constructing its pair.
Consequently the lookup theorem does not by itself commute with full positive extraction.
SIGNED-BOUNDARY.md records this exact existing-code boundary.
The blind_toNat_changes_lookup source theorem also records the failed blind cast.
The positive Int-toNat minimum-table argument does not apply to signed path indexes.

No nonnegative-path guarantee was derived for the original source domain.
Adding one as a public gate would restrict the requested original signed scope.
No such gate is added here.
The missing signed full-constraint reification or faithful original-input codec,
normalization/readback and Set class enumeration correspondence remain explicit.

## Smallest next work

The represented current-model view can be computed from sourceEqualities and
nested Int.ofNat maps, then passed directly to the existing numeric equalSizes.
This uses the existing complete syntax and supplies no free equality view.
Its cast law is an instance of equalSizes_cast.
A useful next semantic contract is accepted_equal_sizes in NEXT-CONTRACTS.md.
It takes the existing Cached gate and actual complete-term acceptance.
It derives that the node-size allocation survives the numeric prefilter.
It does not accept a future view or normalization result.

A full original-source statement must additionally handle every signed path and
preserve distinct Same selection, normalization, class enumeration and numeric lookup.
The current signatures cannot state that all-signed input contract without the
missing type or adapter.
No invented reduced guard syntax is used to conceal that boundary.

## Larger goal and provenance

This does not prove literal Haskell equality-filter correspondence or satisfiability.
It does not close the sized-product/SCC/memo/fromRows/host correspondence.
Global original worker depth and ordered prefix progress remain open.
The original-input/both-worker/public/Haskell objective remains open.
No Haskell defect or fix was established.
There is no FINDINGS defect candidate from this source-only review.

Exactly two OLD wholes were named before acquisition: numeric EqualSizes117 and
SourceCompactGuards574.
All other bodies use named bounded cuts and retained declaration locators.
ACQUISITION-UNIONS.json records cumulative unions at original paths.
The full previous equal-size review and numeric owner providers remain frozen
with every payload hash reverified.
Their complete metadata and identities are retained.
The guessed missing Guard.hs read and timestamp estimate error are recorded.
All proposed document revisions are retained.
