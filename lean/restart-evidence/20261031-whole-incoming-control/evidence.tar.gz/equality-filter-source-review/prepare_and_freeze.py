from pathlib import Path
import hashlib,json,re
r=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
entries=json.loads((r/'acquisitions.json').read_text())
by={}
for e in entries:
 source=Path(e['original_path'])
 assert sha(source)==e['source_sha256']
 assert sha(r/e['copy'])==e['copy_sha256']
 key=(e['original_path'],e['source_sha256'])
 b=by.setdefault(key,{'original_path':e['original_path'],'source_sha256':e['source_sha256'],'source_lines':e['source_lines'],'lines':set()})
 if 'actual_lines' in e:
  lines=e['actual_lines']
 else:
  lines=[n for a,z in e['line_ranges']for n in range(a,z+1)]
 b['lines'].update(lines)
rows=[]
for b in by.values():
 lines=sorted(b.pop('lines'))
 ranges=[]
 for n in lines:
  if ranges and n==ranges[-1][1]+1:
   ranges[-1][1]=n
  else:
   ranges.append([n,n])
 b.update({'retained_unique_lines':len(lines),'cumulative_ranges':ranges,'fraction':len(lines)/b['source_lines'],'whole_or_near_whole':len(lines)/b['source_lines']>=0.75})
 rows.append(b)
assert sum(b['whole_or_near_whole']for b in rows)==2
(r/'ACQUISITION-UNIONS.json').write_text(json.dumps({'old_whole_limit':2,'old_wholes_used':2,'sources':rows},indent=2)+'\n')
repo=Path('/home/tritlo/Code/mcfta')
patterns=['*Projection*','*SymbolicIndex*','FullSyntax*','SourceSizedEqualities*','SourceSizedNormalizedConstraints*','*Signed*Path*','*Path*Signed*']
files=sorted({str(p.relative_to(repo))for pattern in patterns for p in (repo/'lean/MicroCFTA').glob(pattern)if p.is_file()})
(r/'FILENAME-INVENTORY.txt').write_text('\n'.join(files)+'\n')
providers=[]
review=Path('/tmp/mcfta-equal-sizes-source-review-20261031')
assert sha(review/'MANIFEST.json')=='8c0b06acf3315c648121ce9537d8f2ba4f542c533dea2650376c62655a66dc80'
assert sha(review/'FROZEN-PINS.json')=='0805d0886818d968fe1e0bcd0b242c1d54847855c7fb19dde3ad5840f3e4d51f'
for e in json.loads((review/'MANIFEST.json').read_text())['files']:
 assert sha(review/e['path'])==e['sha256']
for name in ['SCOPE.md','INCIDENTS.md','OWN-VERIFICATION.json','SOURCE-CONTRACT-REVIEW.json','NUMERIC-DEPENDENCY-REUSE.json','old-source-cut-ledger.json','read-ledger.json','provider-inventory-verification.json']:
 (r/'reused'/('prior-review-'+name)).write_bytes((review/name).read_bytes())
providers.append({'path':str(review),'manifest_file':'MANIFEST.json','manifest_sha256':sha(review/'MANIFEST.json'),'pin_file':'FROZEN-PINS.json','pin_sha256':sha(review/'FROZEN-PINS.json'),'full_closure_retained_in_place':True,'all_payload_hashes_match':True})
owner=Path('/tmp/mcfta-sized-minimum-equalsizes-next-review-20261031')
assert sha(owner/'MANIFEST.sha256')=='e71a3a0e886ea071b6b9e7a3af81c6333ab6a80dd686454cdafe46d148682f40'
assert sha(owner/'FROZEN-PINS.json')=='4af10393e289f2ba1fe2436290cc313ba3168f667127438c525a6d74164d5e87'
for line in (owner/'MANIFEST.sha256').read_text().splitlines():
 expected,leaf=line.split('  ',1)
 assert sha(owner/leaf)==expected
for name in ['MANIFEST.sha256','FROZEN-PINS.json','acquisitions.json']:
 file=owner/name
 if file.exists():
  (r/'reused'/('numeric-owner-'+name)).write_bytes(file.read_bytes())
providers.append({'path':str(owner),'manifest_file':'MANIFEST.sha256','manifest_sha256':sha(owner/'MANIFEST.sha256'),'pin_file':'FROZEN-PINS.json','pin_sha256':sha(owner/'FROZEN-PINS.json'),'full_closure_retained_in_place':True,'all_payload_hashes_match':True})
(r/'PROVIDER-CLOSURES.json').write_text(json.dumps(providers,indent=2)+'\n')
(r/'DOCUMENT-REUSE.json').write_text(json.dumps([{'source':str(review/name),'copy':'reused/prior-review-'+name,'sha256':sha(review/name),'role':'frozen prior metadata or historical report; not a current kernel-status claim'}for name in ['REPORT.md','FROZEN-PINS.json','MANIFEST.json','acquisitions.json','old-source-cut-ledger.json','CUMULATIVE-OLD-SOURCE-UNIONS.json']],indent=2)+'\n')
(r/'SOURCE-REVERIFY.json').write_text(json.dumps({'all_original_source_hashes_match':True,'all_retained_copy_hashes_match':True,'acquisition_records':len(entries),'distinct_original_path_hashes':len(rows)},indent=2)+'\n')
(r/'REPORT.md').write_text('''# Original equality-view producer boundary

## Result

The existing full accessor is SourceCompactGuards.sourceEqualities.
It already combines the stored field with the normalized positive guard view.
SourceSymbolicIndex.Constraint.equalities is only the stored field.
A numeric filter that reads that field alone omits the successful guard contribution.

The task closes as a source map and exact next-contract report.
No new all-signed producer theorem or Lean module is supplied.
The conditional producer scope cannot be met from the current natural-path full
constraint type with the signed correspondence already available.
The current-model expressions in NEXT-CONTRACTS.md give the smallest useful
filter producer without a new public view gate.
Their original all-signed Haskell correspondence remains separate.

The owner ran no compiler, evaluator, native program or Haskell.
The owner made no production, Git, network or board change.
No new kernel-checked result is claimed.

## Actual source behavior

The Haskell Constraint stores normalized equality classes and a full Guard.
positiveEqualities accepts Top, distinct-path Same and wholly successful And.
A reflexive Same remains residual because the path must exist.
Any unsupported operand causes positive extraction of the entire And to fail.
The accessor then retains stored equalities.
It does not collect only the supported siblings of a failed conjunction.

Positive Same normalizes its pair.
And normalizes every right-fold combination.
An extracted contradiction remains a successful syntax result with a contradictory
payload, rather than becoming unsupported syntax.
Constraint.equalities preserves its empty-guard fast path.
The general combiner absorbs contradiction, keeps the both-empty shortcut and
otherwise normalizes the concatenated class sets.
The retained actual Haskell cuts pin these exact branches.

## Existing Lean producers and exports

SourceCompactGuards.positiveNormalized and positiveNormalizedList model that
staged normalization at every Same and And step.
sourceEqualities applies the complete accessor case split.
arrayNormalize_eq and arrayNormalize_finished supply the existing completed
normalizer readback.
The source API already derives its normalization work through its existing
termination result; no new future completion certificate is needed here.
The definitions are noncomputable because that existing API chooses a proved
sufficient work amount.

combineEqualities, combine_active and combine_value are the existing merge exports.
SourceEqualityGuardReadback.source_cached derives Cached for the full accessor
from the startup's existing stored Cached gate.
sourceEqualities_active gives the corresponding active payload fact.
accepted_equalities derives the full accessor payload from complete constraint
acceptance for arbitrary guards.
sourceEqualities_exact gives the stronger complete guard law on positive syntax.
No positive-only premise is needed merely to produce sourceEqualities or its cache fact.

SOURCE-MAP.md records the Haskell and Lean stages and exact bounded locators.

## Three failure layers

Outer none from positiveNormalized means unsupported syntax and keeps stored data.
Inner none means normalized EqContradiction.
Numeric readSizes none means a selected child lookup failed and rejects the class.
The numeric EqualityView.none contradiction case returns true.
That numeric result is not satisfiability.
These failure layers must remain separate.

The numeric code already keeps only singleton child paths.
It ignores root and deeper paths at this projection.
An empty selected list passes.
Negative and out-of-range selected indexes fail their lookup.
The existing generic cast/filtered-splits laws cover these branches at a supplied view.

## Precise signed-domain obstruction

Actual ChildIndex is Int and actual Path contains ChildIndex values.
SourceGuards.Path is List Nat.
Both fields of the current SourceSymbolicIndex.Constraint use that natural path.
Thus the original signed constraint is not itself an input value of this type.
A nested Int.ofNat map renders represented natural paths but cannot establish the
full original signed-domain accessor correspondence by itself.

SymbolicSignedPaths supplies signed lookup and decode.
Its bounded encode preserves lookup under an arity bound.
It maps all negative segments to one impossible natural index.
That encoding can identify two paths that were distinct before encoding.
The positive extractor tests distinctness before constructing its pair.
Consequently the lookup theorem does not by itself commute with full positive extraction.
SIGNED-BOUNDARY.md records this exact existing-code boundary.
The blind_toNat_changes_lookup source theorem also records the failed blind cast.
The positive Int-toNat minimum-table argument does not apply to signed path indexes.

No nonnegative-path guarantee was derived for the original source domain.
Adding one as a public gate would restrict the requested original signed scope.
No such gate is added here.
The missing signed full-constraint reification or faithful original-input codec,
normalization/readback and Set class enumeration correspondence remain explicit.

## Smallest next work

The represented current-model view can be computed from sourceEqualities and
nested Int.ofNat maps, then passed directly to the existing numeric equalSizes.
This uses the existing complete syntax and supplies no free equality view.
Its cast law is an instance of equalSizes_cast.
A useful next semantic contract is accepted_equal_sizes in NEXT-CONTRACTS.md.
It takes the existing Cached gate and actual complete-term acceptance.
It derives that the node-size allocation survives the numeric prefilter.
It does not accept a future view or normalization result.

A full original-source statement must additionally handle every signed path and
preserve distinct Same selection, normalization, class enumeration and numeric lookup.
The current signatures cannot state that all-signed input contract without the
missing type or adapter.
No invented reduced guard syntax is used to conceal that boundary.

## Larger goal and provenance

This does not prove literal Haskell equality-filter correspondence or satisfiability.
It does not close the sized-product/SCC/memo/fromRows/host correspondence.
Global original worker depth and ordered prefix progress remain open.
The original-input/both-worker/public/Haskell objective remains open.
No Haskell defect or fix was established.
There is no FINDINGS defect candidate from this source-only review.

Exactly two OLD wholes were named before acquisition: numeric EqualSizes117 and
SourceCompactGuards574.
All other bodies use named bounded cuts and retained declaration locators.
ACQUISITION-UNIONS.json records cumulative unions at original paths.
The full previous equal-size review and numeric owner providers remain frozen
with every payload hash reverified.
Their complete metadata and identities are retained.
The guessed missing Guard.hs read and timestamp estimate error are recorded.
All proposed document revisions are retained.
''')
(r/'STATIC-AUDIT.json').write_text(json.dumps({'status':'SOURCE-ONLY inventory and exact next contracts','new_lean_module_or_proof':False,'old_wholes':2,'full_accessor_identified':'SourceCompactGuards.sourceEqualities','new_public_equality_view_witness_or_gate':False,'reduced_guard_syntax_added':False,'full_signed_correspondence_claimed':False,'contradiction_numeric_success_is_satisfiability':False,'source_path_gap':'SourceGuards.Path=List Nat versus ChildIndex Int','compiler_evaluator_native_haskell_invocations':0,'production_git_network_board_mutations':0},indent=2)+'\n')
manifest={'kind':'source-only original full equality-view producer boundary','status':'inventory; no new checked proof','files':[]}
for q in sorted(r.rglob('*')):
 if q.is_file() and q.name not in {'MANIFEST.json','pins.json','FROZEN'}:
  manifest['files'].append({'path':str(q.relative_to(r)),'bytes':q.stat().st_size,'sha256':sha(q)})
(r/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
pins={'scope':str(r),'manifest_sha256':sha(r/'MANIFEST.json'),'report_sha256':sha(r/'REPORT.md'),'source_map_sha256':sha(r/'SOURCE-MAP.md'),'next_contracts_sha256':sha(r/'NEXT-CONTRACTS.md'),'payload_files':len(manifest['files']),'status':'SOURCE-ONLY inventory; no new checked proof'}
(r/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(r/'FROZEN').write_text('Source-only original equality-filter producer review frozen.\nNo all-signed producer proof is claimed.\nMANIFEST.json SHA256 '+pins['manifest_sha256']+'\npins.json SHA256 '+sha(r/'pins.json')+'\n')
for e in manifest['files']:
 assert sha(r/e['path'])==e['sha256']
for q in r.rglob('*'):
 if q.is_file():
  q.chmod(0o444)
for q in sorted([q for q in r.rglob('*')if q.is_dir()],reverse=True):
 q.chmod(0o555)
r.chmod(0o555)
result={'files':sum(q.is_file()for q in r.rglob('*')),'manifest':sha(r/'MANIFEST.json'),'pins':sha(r/'pins.json'),'report':sha(r/'REPORT.md'),'source_map':sha(r/'SOURCE-MAP.md'),'next_contracts':sha(r/'NEXT-CONTRACTS.md'),'unions':[(Path(b['original_path']).name,b['retained_unique_lines'],b['source_lines'])for b in rows]}
print(json.dumps(result,indent=2))
