15:def NormalClasses (classes : Constraints) : Prop :=
20:def Cached (equalities : Option Constraints) : Prop :=
24:theorem normalized {fuel : Nat} {input output : Constraints}
30:theorem normalize_cached (classes : Constraints) : Cached (normalize classes) := by
48:theorem combine_cached (first second : Option Constraints) : Cached (combineEqualities first second) := by
57:theorem source_cached (constraint : Constraint Formula) (cached : Cached constraint.equalities) :
63:theorem active {equalities : Option Constraints} (cached : Cached equalities) : ActiveOption equalities :=
67:theorem accepted_equalities [DecidableEq Formula] (formulas : Formulas Formula) (solver : Entailment Formula)
85:def Sat (term : Term Symbol) : Option Constraints → Prop
90:theorem value_exact [DecidableEq Symbol] (term : Term Symbol) (equalities : Option Constraints)
