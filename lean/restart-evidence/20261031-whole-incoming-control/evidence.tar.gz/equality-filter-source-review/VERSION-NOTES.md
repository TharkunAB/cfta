# Versions

No new Lean module or proof draft is supplied.
NEXT-CONTRACTS-v1.md retains the first proposed current-model expressions.
NEXT-CONTRACTS.md makes the numeric size type generic for both Nat and Int.
The change matches the existing generic equalSizes API.
It permits its existing exact Int-cast transport to apply to the proposed wrapper.
All expressions and theorem headers remain uncompiled next-work targets.
The all-signed original source contract remains open.
