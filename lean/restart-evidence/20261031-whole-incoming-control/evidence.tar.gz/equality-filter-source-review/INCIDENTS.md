# Incidents

One named source locator included cfta/src/Data/CFTA/Guard.hs.
That guessed file does not exist.
The actual Guard declaration is in Constraint.hs.
The locator returned code 2 after producing its valid Constraint.hs matches.
The successful matches are retained at their original source lines.
The error text is retained separately.
No source was acquired at the missing path.

One parent progress message used the estimated time 05:20 CET.
A later date command returned 05:17 CET.
The estimate was ahead of the actual clock.
This timestamp error did not affect source, metadata or provenance.

The prior source review states that the minimum producer was still open at its time.
That statement is historical.
Root has since checked the computed minimum producer and its structural semantics.
The prior review is used for its equality-view source map, not as current minimum status.
