# Smallest next contracts

## Current natural-path representation

The current model can derive its numeric view from the existing full constraint.
It needs no new equality-view input or positive-guard gate.
The exact expression to implement next is:

```lean
noncomputable def representedEqualityView
    (constraint : SourceSymbolicIndex.Constraint Formula) :
    SourceSizedPrefixEqualSizes.EqualityView :=
  (SourceCompactGuards.sourceEqualities constraint).map
    (List.map (List.map (List.map Int.ofNat)))

noncomputable def representedEqualSizes {Size : Type} [DecidableEq Size]
    (constraint : SourceSymbolicIndex.Constraint Formula) (parts : List Size) : Bool :=
  SourceSizedPrefixEqualSizes.equalSizes (representedEqualityView constraint) parts
```

These are proposed expressions, not an elaborated or checked draft.
The accessor includes every existing SourceGuards.Guard constructor.
The expressions use the current natural-path representation.
Their noncomputable status comes from the existing source normalization API.
No future normalization or equality-view certificate is supplied.

The numeric cast law follows by instantiating equalSizes_cast at that produced view.
The existing source_cached law transports the startup's original Cached gate.
The next semantic law can require only that existing gate and actual constraint acceptance:

```lean
-- representedEqualSizes is the definition above, still to be installed.
theorem accepted_equal_sizes
    [DecidableEq Formula]
    (formulas : SourceGuards.Formulas Formula)
    (solver : SourceGuards.Entailment Formula)
    (constraint : SourceSymbolicIndex.Constraint Formula)
    (cached : SourceEqualityGuardReadback.Cached constraint.equalities)
    (symbol : SourceObservations.Label Formula)
    (children : List (Language.Term (SourceObservations.Label Formula)))
    (accepted : SourceSymbolicIndex.acceptsConstraint formulas solver constraint
      (.node symbol children) = true) :
    representedEqualSizes constraint (children.map RecursiveSize.nodeSize) = true
```

This header is a target only.
accepted_equalities already supplies the actual combined equality payload.
The remaining local proof derives equal node sizes from equal direct child terms.
It must preserve the empty projection and failed-lookup branches.

This current-model producer can specialize initial_packet_computed's filter.
It does not prove a literal all-signed Haskell correspondence.
That separate boundary must remain in its public description.

## Full original signed source

The original-domain contract must compute the view from the actual full signed
constraint, including stored classes and every full guard constructor.
It must prove that the resulting numeric Bool equals literal Prefix.equalSizes
for every parts list, including negative selected indexes and contradiction.
It must not take a supplied EqualityView, future merge result, positive-only
restriction or nonnegative-path admission as an input.

The current Constraint type cannot directly state this all-signed input contract.
Its guard and stored classes use SourceGuards.Path = List Nat.
The signed full-guard/constraint reification or a faithful original-input codec
is the missing definition or adapter.
A codec must preserve the distinct-path test before positive extraction and
preserve normalization plus numeric class projection.
Lookup preservation alone is insufficient.
Set class enumeration and path rendering also need an explicit correspondence.

No reduced guard syntax is proposed here.
No new public equality-view witness is proposed.
No missing source property is replaced with a future certificate.
