from pathlib import Path
import json,hashlib,shutil
r=Path('/tmp/mcfta-whole-incoming-control-20261031');owners=json.loads((r/'owners.json').read_text());items=[('terminal-known-source-review','/tmp/mcfta-native-terminal-known-review-20261031','ee320f50d51410c204e857e63f57d0c72627683797cd60765f66ab99b0d4e2ae','pins.json','faa296a6db588219c8fdac3093f91bb750a9a6759dffad464ea6364c40de9269'),('default-edge-source-review','/tmp/mcfta-default-edge-source-review-20261031','5b897cd5f743759088157793e120affba68408d4b07cc91a4e3f8568ecd54c1e','PINS.json','585947b5f41e4618b6cf538ab8133bf1420089ef5c484468d6fa32fbb10ebc13')]
for name,source,mhash,pins,phash in items:
 src=Path(source);assert hashlib.sha256((src/'MANIFEST.json').read_bytes()).hexdigest()==mhash and hashlib.sha256((src/pins).read_bytes()).hexdigest()==phash;manifest=json.loads((src/'MANIFEST.json').read_text());rows=manifest['files'];rows=[{'path':leaf,**manifest['pins'][leaf]} for leaf in rows] if rows and isinstance(rows[0],str) else rows;actual={str(x.relative_to(src)) for x in src.rglob('*') if x.is_file()};expected={x['path'] for x in rows};extras=actual-(expected|{'MANIFEST.json',pins});assert extras<={'FROZEN'}
 for row in rows:
  data=(src/row['path']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 for file in src.rglob('*'):
  if file.is_file():assert not file.is_symlink() and not file.stat().st_mode&0o222
 assert name not in [x['name'] for x in owners] and not(r/name).exists();shutil.copytree(src,r/name);owner={'name':name,'original':source,'manifest':'MANIFEST.json','manifest_sha256':mhash,'pins':pins,'pins_sha256':phash,'status':'Source-grounded next contract; no completed theorem claimed'}
 if extras:owner['extra_metadata']={leaf:{'bytes':(src/leaf).stat().st_size,'sha256':hashlib.sha256((src/leaf).read_bytes()).hexdigest()} for leaf in sorted(extras)}
 owners.append(owner)
(r/'owners.json').write_text(json.dumps(owners,indent=2)+'\n');(r/'add-source-reviews.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'complete_owners':len(owners),'new_source_reviews':[x[0] for x in items]}))
