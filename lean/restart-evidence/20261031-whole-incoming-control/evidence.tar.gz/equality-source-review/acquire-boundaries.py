from pathlib import Path
import json,hashlib,subprocess,shutil
r=Path(__file__).parent;p=Path('/tmp/mcfta-sized-minimum-equalsizes-next-review-20261031');sha=lambda b:hashlib.sha256(b).hexdigest();records=json.loads((p/'acquisitions.json').read_text());old=json.loads((r/'old-source-cut-ledger.json').read_text());read=json.loads((r/'read-ledger.json').read_text())
names=['cuts/SourceSizedPrefixProductInteger.lean-WHOLE-slot1.txt','cuts/SourceSizedPrefixProductRank.lean-WHOLE-slot2.txt','cuts/actual-bySize-equalSizes-L575-L628.txt','cuts/actual-Constraint-equalities-L105-L137.txt','cuts/actual-signed-child-index-L38-L49.txt','cuts/existing-concrete-constraint-L12-L26.txt','cuts/actual-equalityConstraint-L209-L216.txt']
for saved in names:
 x=next(x for x in records if x['copy']==saved);lo,hi=x['actual'];b=(p/saved).read_bytes();assert sha(b)==x['copy_sha256'];assert b==subprocess.check_output(['sed','-n',f'{lo},{hi}p',x['source']]);assert subprocess.check_output(['sha256sum',x['source']],text=True).split()[0]==x['source_sha256'];f='old-cuts/'+Path(saved).name;(r/f).write_bytes(b);old.append({'source_path':x['source'],'source_sha256':x['source_sha256'],'source_lines':x['source_lines'],'source_bytes':x['source_bytes'],'actual':[lo,hi],'copy':f,'copy_sha256':sha(b),'reuse_from':str(p/saved),'reuse_from_sha256':sha(b),'reuse_origin_range_start':lo,'classification':'named OLD WHOLE slot' if lo==1 and hi==x['source_lines'] else 'named bounded OLD source cut','read_complete':False})
 for pos in range(lo,hi+1,40):
  end=min(pos+39,hi);c=b''.join(b.splitlines(keepends=True)[pos-lo:end-lo+1]);copy=f'chunks/OLD-{Path(x["source"]).name}-L{pos}-L{end}.txt';(r/copy).write_bytes(c);read.append({'source':f,'source_sha256':sha(b),'actual':[pos-lo+1,end-lo+1],'original_lines':[pos,end],'copy':copy,'copy_sha256':sha(c),'read_complete':False})
for name in ['MANIFEST.json','FROZEN-PINS.json','REVIEW-STATUS.json','ROOT-REPORTED-CHECKS.json']:
 src=Path('/tmp/mcfta-sized-product-ordinary-public-review-20261031')/name;shutil.copyfile(src,r/'provider-metadata'/('PRIOR-R13-'+name))
(r/'old-source-cut-ledger.json').write_text(json.dumps(old,indent=2)+'\n');(r/'read-ledger.json').write_text(json.dumps(read,indent=2)+'\n')
print('Acquired',len(old),'OLD cuts including exactly two named wholes.')
