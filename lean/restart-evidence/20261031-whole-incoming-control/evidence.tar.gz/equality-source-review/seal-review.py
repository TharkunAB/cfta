from pathlib import Path
import hashlib,json,os
r=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest()
verification={'time':'2026-10-31 03:57 CET','status':'PASS bounded source/contract/provenance review; candidate remains UNCOMPILED','source_lines_fully_read':118,'old_source_lines_fully_read':483,'old_original_paths':6,'old_whole_original_paths':2,'read_chunks':19,'public_source_contracts':4,'provider_payloads':66,'provider_files':68,'compiler_evaluator_Haskell_native_Git_network_board_production_spawn_actions':0,'verification':'verify-review.py complete pre-seal PASS; sealed verifier must run after sealing','Haskell_defect_or_fix_established':False}
(r/'OWN-VERIFICATION.json').write_text(json.dumps(verification,indent=2)+'\n')
files=[]
for p in sorted(r.rglob('*')):
 if p.is_file() and str(p.relative_to(r)) not in {'MANIFEST.json','FROZEN-PINS.json'}:
  b=p.read_bytes();files.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':sha(b)})
m={'schema':'explicit files list; only root MANIFEST.json and FROZEN-PINS.json excluded','files':files};(r/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
names=['MANIFEST.json','REPORT.md','SCOPE.md','INCIDENTS.md','OWN-VERIFICATION.json','SOURCE-CONTRACT-REVIEW.json','CUMULATIVE-OLD-SOURCE-UNIONS.json','NUMERIC-DEPENDENCY-REUSE.json','acquisitions.json','old-source-cut-ledger.json','read-ledger.json','provider-inventory-verification.json','inputs/provider-SourceSizedPrefixEqualSizes-v3-UNCOMPILED.lean','old-cuts/SourceSizedPrefixProductInteger.lean-WHOLE-slot1.txt','old-cuts/SourceSizedPrefixProductRank.lean-WHOLE-slot2.txt','verify-review.py'];pins={name:sha((r/name).read_bytes()) for name in names};(r/'FROZEN-PINS.json').write_text(json.dumps({'pins':pins},indent=2)+'\n')
for p in r.rglob('*'):p.chmod(0o444 if p.is_file() else 0o555)
r.chmod(0o555)
print(json.dumps({'directory':str(r),'payload_files':len(files),'total_files':len(files)+2,'payload_bytes':sum(x['bytes'] for x in files),'MANIFEST_sha256':sha((r/'MANIFEST.json').read_bytes()),'FROZEN_PINS_sha256':sha((r/'FROZEN-PINS.json').read_bytes()),'REPORT_sha256':sha((r/'REPORT.md').read_bytes())},indent=2))
