from pathlib import Path
import hashlib,json,sys
r=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest()
a=json.loads((r/'acquisitions.json').read_text());old=json.loads((r/'old-source-cut-ledger.json').read_text());reads=json.loads((r/'read-ledger.json').read_text())
for x in a:
 b=(r/x['copy']).read_bytes();source=Path(x['source_path']).read_bytes();assert b==source;assert sha(b)==x['copy_sha256']==x['source_sha256'];assert x['read_complete']
for x in old:
 source=Path(x['source_path']).read_bytes();assert sha(source)==x['source_sha256'];ls=source.splitlines(keepends=True);assert len(ls)==x['source_lines'];lo,hi=x['actual'];b=(r/x['copy']).read_bytes();assert b==b''.join(ls[lo-1:hi]);assert sha(b)==x['copy_sha256'];assert x['read_complete']
 if x.get('reuse_from'):assert sha(Path(x['reuse_from']).read_bytes())==x['reuse_from_sha256']
for x in reads:
 b=(r/x['source']).read_bytes();lo,hi=x['actual'];cut=(r/x['copy']).read_bytes();assert sha(b)==x['source_sha256'];assert cut==b''.join(b.splitlines(keepends=True)[lo-1:hi]);assert sha(cut)==x['copy_sha256'];assert x['read_complete']
u=json.loads((r/'CUMULATIVE-OLD-SOURCE-UNIONS.json').read_text());assert len(u)==6;assert sum(x['whole'] for x in u.values())==2;assert sum(x['covered_lines'] for x in u.values())==483
p=Path('/tmp/mcfta-sized-minimum-equalsizes-next-review-20261031');inv=json.loads((r/'provider-inventory-verification.json').read_text());assert sha((p/'MANIFEST.sha256').read_bytes())==inv['manifest_sha256'];assert sha((p/'FROZEN-PINS.json').read_bytes())==inv['pins_sha256'];assert len(inv['files'])==66
for x in inv['files']:assert sha((p/x['path']).read_bytes())==x['sha256']
assert {str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()}=={x['path'] for x in inv['files']}|{'MANIFEST.sha256','FROZEN-PINS.json'}
contracts=json.loads((r/'SOURCE-CONTRACT-REVIEW.json').read_text());assert len(contracts['public_headers'])==4;doc=' '.join((r/'inputs/provider-EXACT-PUBLIC-HEADERS.txt').read_text().split())
for x in contracts['public_headers']:assert ' '.join(x['header_text'].split()) in doc
for x in json.loads((r/'NUMERIC-DEPENDENCY-REUSE.json').read_text()):assert (r/x['current_copy']).read_bytes()==Path(x['prior_frozen_copy']).read_bytes()
if '--sealed' in sys.argv:
 m=json.loads((r/'MANIFEST.json').read_text());files={x['path'] for x in m['files']};assert {str(f.relative_to(r)) for f in r.rglob('*') if f.is_file()}==files|{'MANIFEST.json','FROZEN-PINS.json'}
 for x in m['files']:
  b=(r/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
 pins=json.loads((r/'FROZEN-PINS.json').read_text())['pins'];assert sha((r/'MANIFEST.json').read_bytes())==pins['MANIFEST.json']
 for name,h in pins.items():assert sha((r/name).read_bytes())==h
 assert all(f.stat().st_mode&0o222==0 for f in r.rglob('*'))
print('PASS:10 NEW records/7 OLD records/19 complete read chunks/6 OLD paths/483 OLD lines/exact2 wholes/4 uncompiled source contracts/provider68 files;'+(' sealed complete manifest+pins+readonly PASS' if '--sealed' in sys.argv else ' ready to seal'))
