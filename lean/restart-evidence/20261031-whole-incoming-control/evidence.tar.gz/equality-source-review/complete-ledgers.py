from pathlib import Path
import json,hashlib,re
r=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();a=json.loads((r/'acquisitions.json').read_text());old=json.loads((r/'old-source-cut-ledger.json').read_text());reads=json.loads((r/'read-ledger.json').read_text())
for x in a:x.update(read_complete=True,review_mode='full V3/source-document read or exact complete base+version-diff coverage for retained V1/V2; SOURCE-ONLY/UNCOMPILED')
for x in old:x['read_complete']=True
for x in reads:x['read_complete']=True
(r/'acquisitions.json').write_text(json.dumps(a,indent=2)+'\n');(r/'old-source-cut-ledger.json').write_text(json.dumps(old,indent=2)+'\n');(r/'read-ledger.json').write_text(json.dumps(reads,indent=2)+'\n')
u={}
for x in old:
 y=u.setdefault(x['source_path'],{'source_sha256':x['source_sha256'],'source_lines':x['source_lines'],'line_set':set(),'copies':[]});assert x['source_sha256']==y['source_sha256'];lo,hi=x['actual'];y['line_set'].update(range(lo,hi+1));y['copies'].append(x['copy'])
for x in u.values():
 ls=sorted(x.pop('line_set'));rs=[]
 for n in ls:
  if rs and n==rs[-1][1]+1:rs[-1][1]=n
  else:rs.append([n,n])
 x.update(ranges=rs,covered_lines=len(ls),coverage_fraction=len(ls)/x['source_lines'],whole=len(ls)==x['source_lines']);assert x['whole'] or x['coverage_fraction']<0.5
assert len(u)==6 and sum(x['whole'] for x in u.values())==2 and sum(x['covered_lines'] for x in u.values())==483
(r/'CUMULATIVE-OLD-SOURCE-UNIONS.json').write_text(json.dumps(u,indent=2)+'\n')
prior=Path('/tmp/mcfta-sized-product-ordinary-public-review-20261031');reuses=[]
for basename,rel in [('SourceSizedPrefixProductInteger.lean','inputs/integer-installed-v5.lean'),('SourceSizedPrefixProductRank.lean','inputs/rank-installed-v4.lean')]:
 x=next(x for x in old if Path(x['source_path']).name==basename);assert (r/x['copy']).read_bytes()==(prior/rel).read_bytes();reuses.append({'original_path':x['source_path'],'source_sha256':x['source_sha256'],'current_copy':x['copy'],'prior_frozen_copy':str(prior/rel),'prior_frozen_manifest_sha256':sha((prior/'MANIFEST.json').read_bytes()),'classification':'explicit OLD WHOLE reuse; counted against this scope two-whole limit; all361 dependency lines were reread','Root_check_evidence':'copied prior R13 ROOT-REPORTED-CHECKS.json; no compiler execution by this reviewer'})
(r/'NUMERIC-DEPENDENCY-REUSE.json').write_text(json.dumps(reuses,indent=2)+'\n')
b=(r/'inputs/provider-SourceSizedPrefixEqualSizes-v3-UNCOMPILED.lean').read_bytes();headers=[{'name':m.group(1),'header_text':m.group(0).split(':=',1)[0].rstrip()} for m in re.finditer(r'(?ms)^theorem\s+(\w+)\b.*?:=',b.decode())];assert len(headers)==4
(r/'SOURCE-CONTRACT-REVIEW.json').write_text(json.dumps({'status':'PASS SOURCE-ONLY review; candidate UNCOMPILED and no axiom readback acquired','source_lines':118,'source_bytes':len(b),'source_sha256':sha(b),'public_headers':headers,'input_view':'raw signed current equality view; not complete Constraint projection','outer_none':'EqContradiction numeric filter returns True','lookup_none':'negative/out-of-range selected child rejects class','integer_total':'all Int totals; explicit negative empty branch; no negative-to-zero replacement','list_claim':'exact filtered allocation-part output; order/multiplicity preserved','open':['actual Constraint.equalities/positive-guard projection','Set.toList/class/path/signed-index adapter','actual minimumSizes producer','complete source row/native/worker/public correspondence'],'future_output_or_invariant_supplier':False,'new_source_checks_run':False},indent=2)+'\n')
print('Complete19 read chunks; OLD6 paths/483L/exact2 wholes;4 SOURCE-ONLY headers; prior R13 unchanged.')
