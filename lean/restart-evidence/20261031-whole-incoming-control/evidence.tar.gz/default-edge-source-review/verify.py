from pathlib import Path
import hashlib
import json
import sys

root = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = json.loads((root / 'MANIFEST.json').read_text())
for name in manifest['files']:
    data = (root / name).read_bytes()
    assert sha(data) == manifest['pins'][name]['sha256'], name
    assert len(data) == manifest['pins'][name]['bytes'], name
ledger = json.loads((root / 'acquisitions.json').read_text())
for record in ledger:
    copied = (root / record['copy']).read_bytes()
    assert sha(copied) == record['copy_sha256'], record['copy']
    assert all(1 <= i <= record['source_lines'] for i in record['actual_lines'])
    if '--live-source' in sys.argv:
        source = Path(record['source_path']).read_bytes()
        assert sha(source) == record['source_sha256'], record['source_path']
        lines = source.splitlines(keepends=True)
        replay = b''.join((str(i).encode() + b':' if record['copy_format'] == 'numbered-lines' else b'')
                          + lines[i - 1] for i in record['actual_lines'])
        assert replay == copied, record['copy']
summary = json.loads((root / 'OLD-SOURCE-UNIONS.json').read_text())
assert len(ledger) == summary['source_acquisitions'] == 40
assert summary['actual_unique_line_count'] == 924
assert summary['original_source_path_count'] == 14
assert summary['actual_whole_or_near_whole_count'] == 0
assert not list(root.glob('*.lean'))
assert len(manifest['files']) == len([p for p in root.rglob('*') if p.is_file() and p.name != 'MANIFEST.json'])
print(json.dumps({'status': 'PASS', 'manifest_pinned_files': len(manifest['files']),
                  'source_acquisitions': 40, 'unique_old_lines': 924, 'old_wholes': 0,
                  'new_Lean_source_lines': 0, 'live_source_replay': '--live-source' in sys.argv,
                  'compiler_or_evaluator_run': False}, sort_keys=True))
