from pathlib import Path
import json,hashlib,shutil
r=Path('/tmp/mcfta-whole-incoming-control-20261031');owners=json.loads((r/'owners.json').read_text());items=[('positive-worker-progress-review','/tmp/mcfta-positive-worker-progress-review-20261031','pins.json','985e8af39a5ba86dc909cb7e1ad7d209bd46d5b6b0bb8c055b90b5fdcd910414','FROZEN.json','41b716aa627bd71ce8e066ab36de01e9f170290a8aa675f746f2c4c6015aa9ee'),('dispatch-known-draft','/tmp/mcfta-native-dispatch-known-review-20261031','MANIFEST.json','d1545cb40d58502a628b1850601fbf250c4d4e88cdba8f51a0da69d0ec623f74','pins.json','0f4457092380678f513827ba6fc2c2e3f81a57afb02dfb65deb203bffb414eac')]
for name,source,mf,mhash,pins,phash in items:
 src=Path(source);assert hashlib.sha256((src/mf).read_bytes()).hexdigest()==mhash and hashlib.sha256((src/pins).read_bytes()).hexdigest()==phash;manifest=json.loads((src/mf).read_text());rows=manifest.get('files',manifest.get('payloads'));rows=[{'path':leaf,**manifest['pins'][leaf]} for leaf in rows] if rows and isinstance(rows[0],str) else rows;actual={str(x.relative_to(src)) for x in src.rglob('*') if x.is_file()};expected={x['path'] for x in rows};extras=actual-(expected|{mf,pins});assert extras<={'FROZEN'}
 for row in rows:
  data=(src/row['path']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 for file in src.rglob('*'):
  if file.is_file():assert not file.is_symlink() and not file.stat().st_mode&0o222
 assert name not in [x['name'] for x in owners] and not(r/name).exists();shutil.copytree(src,r/name);owner={'name':name,'original':source,'manifest':mf,'manifest_sha256':mhash,'pins':pins,'pins_sha256':phash,'status':'Source-only; full progress unproved; draft UNCOMPILED if present'}
 if extras:owner['extra_metadata']={leaf:{'bytes':(src/leaf).stat().st_size,'sha256':hashlib.sha256((src/leaf).read_bytes()).hexdigest()} for leaf in sorted(extras)}
 owners.append(owner)
(r/'owners.json').write_text(json.dumps(owners,indent=2)+'\n');(r/'add-progress-and-dispatch.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'complete_owners':len(owners),'new':[x[0] for x in items]}))
