from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,subprocess

r=Path('/tmp/mcfta-native-incoming-stored-control-20261030')
assert not (r/'FROZEN.json').exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='6045a170bbcc654056b8db085e30c2ab15ca88e6'
assert not subprocess.check_output(['git','status','--porcelain=v1'])
publication=json.loads((r/'checkpoint-publication.json').read_text())
assert publication['head']==head and publication['readback_exact'] and publication['tracking_exact']
assert publication['refs']['refs/heads/main']=='bd5a406a6a3f84b7e3ae0906082783911509df83'
summary=json.loads((r/'verification-summary.json').read_text())
assert summary['commands']==15 and summary['passed']==12 and summary['failed']==3
assert summary['input_snapshots']==31 and summary['public_checks']==1219 and summary['all_new_axioms_standard']
assert json.loads((r/'owned-verification.json').read_text())['status']=='pass'
assert json.loads((r/'document-verification.json').read_text())['all_current_pins']=='pass'
for p in r.iterdir():
    if p.is_dir() and not p.name.startswith('prior-') and (p/'started-command.json').exists():
        assert (p/'report.json').exists()
rows=[]
for p in sorted(r.rglob('*')):
    if p.is_file():
        assert not p.is_symlink();b=p.read_bytes()
        rows.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
seal={'created_at':datetime.now(ZoneInfo('Europe/Stockholm')).isoformat(),'write_halt':True,
      'goal_turn':'progress','full_goal_complete':False,'goal_controller_observed_status':'blocked',
      'work_continues_under_user_instruction':True,
      'incoming_source_head':'b7116e537a06197a4bb058d2d24b007d5cd9abc3',
      'source_head':'f4fbea6d453704d9a9d183356068f64929975911','docs_head':head,
      'main_head':'bd5a406a6a3f84b7e3ae0906082783911509df83','latest_prior_board_sequence':790,
      'compiler_commands':15,'passed_commands':12,'repaired_failed_commands':3,'input_snapshots':31,
      'new_laws':2,'public_checks':1219,'public_definitions':118,
      'root_source_lines':146,'root_public_lines':63,
      'future_contracts':'unproved Dispatch/Fold headers retained in full frozen cache-adapter-review',
      'next_source_tasks':'dispatch native Stored and slot-action transport; no Root check claimed',
      'payload_count_excluding_seal':len(rows),'payloads':rows}
(r/'FROZEN.json').write_text(json.dumps(seal,indent=2)+'\n')
for p in r.rglob('*'):
    if p.is_file():p.chmod(p.stat().st_mode&~0o222)
assert all(not(p.stat().st_mode&0o222) for p in r.rglob('*') if p.is_file())
print(json.dumps({'sealed':True,'payloads_excluding_seal':len(rows),
 'raw_bytes_excluding_seal':sum(a['bytes'] for a in rows),'source_head':seal['source_head'],'docs_head':head}))
