# Incoming native certificate public review

Source-only task assigned by Root on 2026-10-31. Write only in this
fresh directory. Preserve all earlier frozen bundles. Root owns compiler,
evaluator, native, Git, network, board, production and packaging work.
Do not spawn. Read all 105 installed lines and every actual branch.
Compare the complete public header with the frozen owner V2. Check the
representative lookup in original values, both checkEmpty settings, exact
current Fits.room bounds, arbitrary fuel including yielded state, and
Caller.advance frame. No Trace, Inputs, WordRanges or completion supplier
may be added. Entry Stored remains. No result semantics or whole-worker
claim follows. Wait for final public check and axiom report before freeze.
At most two named OLD whole or near-whole modules. Prefer named exact
cuts. Count reused cuts by original source path and record exact unions.
Retain versions, incidents and complete payload inventory with pins.
No Haskell defect or fix is established.

Root added one immediate cache-adapter companion before freeze. Its draft
has 42 lines. Its final installed source has 41 lines. Review all adapter
source and actual first-projection run/erase behavior. The same OLD quota
applies. The final checkpoint has 146 source lines and 63 public lines.
This is the only scope addition.
