# Actual incoming native certificate review

Result: PASS for both final source and public contracts. The reviewer found
no source or contract defect. The reviewer ran no compiler, evaluator,
native, Git, network, board, production or spawn command. Root owns that
validation and production work.

## Exact final payload and reads

| Installed source copy | Lines | Bytes | SHA-256 |
| --- | ---: | ---: | --- |
| inputs/installed-incoming.lean | 105 | 6670 | cd5b5db4b57e99d5f5cfe3a0c5c994464d814911b0c7cf73373d9f27fd0cae05 |
| inputs/installed-adapter.lean | 41 | 2638 | ce42bdc004cd5eeffaccbf276b64ef0720bbd95a18614019cffdf18af50c03d0 |

The final source total is 146 lines and 9308 bytes. The reviewer read all
105 incoming lines in three complete displays. The reviewer read all 42
adapter draft lines in one complete display. The installed adapter is
exactly that draft with its 48-byte status line removed. No proof body or
public header changed in that installation.

The final public tail is 63 lines and 4547 bytes. Its SHA-256 is
84cfcb7e32dd3e13084def352fddaf6c8706eb56277c557d2adbe086d3018c72.
It is exactly the concatenation of the complete 30-line incoming output
and 33-line adapter output. Both pieces were read in full without
truncation. The two complete expanded signatures and two axiom reports
are retained. There are no new definition prints.

read-ledger.json records ranges, retained copies, hashes and full-read
evidence. acquisitions.json records every source version and public
acquisition. Current source hashes and all retained cut ranges were checked
as metadata. No compiler was rerun by this reviewer.

## Exact public headers

The first theorem is
SourceCurrentAllocatedNativeStoredIncoming.incoming_run_stored.
Its complete source header is byte-exact with the frozen owner V2 at
incoming-review/NativeStoredIncoming-v2-UNCOMPILED.lean. That owner file has
SHA-256 3e79cc197a41f88a13438cba49e252bdc9665f48817c8c0e5082a58283761704.
The copied frozen manifest pins that exact hash. The source header is also
unchanged across the retained owner V1 and Root V2, V3, V4 and V5 versions.
This equality concerns the contract; failed proof candidates remain failed.

The second theorem is
SourceCurrentAllocatedNativeStoredIncomingCacheAdapter.incoming_cache_adapter_stored.
Its complete source header is byte-exact with its frozen 42-line owner V1.
Both source-header comparisons and their exact ranges are retained as JSON.
The incoming owner-to-installed proof diff is retained separately.

Both public signatures retain current native Ready, PendingRealized for
the current enumeration values, availability and closedness of the
incoming value, Fits profile, Room bits profile, and entry native Stored.
The adapter uses PendingRealized at before.core. Both signatures keep the
three equality instances. Neither signature adds Trace, Inputs,
WordRanges, Original, Receipt, future completion or result suppliers.

Ready here is SourceCurrentConjunctionClassScan.Ready. Its current fields
are Good, SemanticReady, CostHeap, Scoped and Idle. Fits includes node,
edge and domain counter bounds plus its separate heap-mass gate. Native
Stored is a different property. No public gate was removed or replaced.

## Actual incoming branches

The reviewer checked the complete literal run definition through line 93
of SourcePruningEnumerationIncomingNode. The proof matches every branch.

- If findRoot fails, the actual caller is unchanged. If it succeeds, the
  read state changes only its representative forest before slot lookup.
- The slot lookup uses before.values[found.representative] in the ORIGINAL
  values array. Missing, eliminated and enumerated slots retain the caller.
- A pending slot without an old handle retains the caller in both incoming
  encoding branches. A successful finish may write the enumeration state
  and reject Empty; it does not change the caller's native tables.
- An old handle that fails lookup retains the caller. For a successful
  lookup, PendingRealized is applied at found.representative with the actual
  old handle, old ancestry list and original slot equation. It gives the
  old value's actual lookup equation, availability and closedness. Option
  injectivity identifies that value with the actual decoded old value.
- Fits.room derives the three bounds for the CURRENT checked state. The
  proof passes those bounds, current Ready, both operand facts and entry
  Stored to the existing actual arbitrary-fuel execute theorem.
- All five native outcomes are covered: yielded, failed, constraintError,
  blocked and done. The first four advance the caller with the exact
  observed native state. Caller.advance gives that checked projection
  literally. This covers fuel zero and every other supplied native fuel.
- A done query supplies Stored for its actual queried state. With
  checkEmpty false, the phase retains queried. With checkEmpty true, the
  existing actual EnabledEmpty theorem retains Stored for the actual
  phase state. Both conjunction failure and success retain it. Both final
  replacement encoding branches use that same native state.

PendingRealized requires each current unenumerated handle-bearing slot to
resolve to an available closed value in the current heap. The proof uses
this CURRENT relation. It supplies no historical slot-realization or
future execution argument.

The current numeric bounds derived by Fits.room are exactly:

- nodes.next < 2^bits;
- edges.next <= 2^(bits+2);
- domains.next + 2^(nodes.next + nodes.next * nodes.next) < 2^(bits+1).

These use the current entry counters at width bits + 2. The proof does not
reset the counters or derive a Word64 deployment bound. Native fuel is an
execution budget. It is not enumeration worker depth.

## Actual cache-adapter boundary

The reviewer read the actual run and erase definitions in
SourcePruningEnumerationIncomingCacheAdapter, lines 63 through 93.
The first projection is literally the original IncomingNode.run result
for before.core. The adapter attaches an optional index candidate as a
SECOND component. That attachment leaves the complete observed caller in
the first component unchanged.

The new theorem changes its goal to that exact first projection and
applies incoming_run_stored with the same gates. It permits arbitrary
indexFuel and arbitrary cached index contents. It does not require index
validity. It concludes native Stored for the reached caller only. It does
not certify the optional index candidate or add result semantics.

The adapter specializes the incoming theorem's enumeration guard type to
the source constraint type. Its expanded public type records that exact
specialization. It does not introduce a new realization assumption.

## Meaning and limits of Stored

Stored concerns returned native node and edge memo cells. A request with
an empty seen list and recursively finite ordinary operands must have a
recursively finite ordinary result whose height is at most each operand's
height. The certificate is conditional on those antecedents.

The new laws preserve that property at the actual reached caller for
successful and unsuccessful observations. They do not assert an
unrestricted certificate for every returned root value, the meaning of an
emptiness answer, heap Ready after every outcome, full caller result-table
correctness, or whole-worker behavior. Caller nodeResults and edgeResults
are separate from the native tables named in the conclusions.

## Bounded OLD acquisition and explicit R7 reuse

The review acquired zero OLD whole or near-whole modules. Its exact union
is 271 lines over 11 OLD source paths, from 11 contiguous cuts and five
locator records. The largest fraction is 93 of 296 lines in the incoming
node module. All copied cuts count by their ORIGINAL repository path.

Four R7 reuses are explicit. They total 44 lines: the 13-line execute
header, the three-line EnabledEmpty header, the 13-line current Ready cut,
and the 15-line conditional Stored definition cut. The first two come
from source bodies that were NEW and fully read in R7. This review copies
and reads only the named header ranges. It does not reacquire those whole
OLD bodies. The other two reuse exact earlier bounded cuts. The prior
full-body R7 review remains frozen and separate.

R7-reuses.json records each origin, original source path, full-file hash,
current range and copy hash. The prior bundle MANIFEST SHA-256 is
51e9a76cea2842194c18fe32e275bef2db118c39b1555190a3f6aa086207d0c0.
old-source-cut-ledger.json, old-source-locator-ledger.json and
old-source-unions.json retain all exact ranges, hashes and unions.
Full-file hashes and sizes were streamed as metadata without acquiring
those OLD source bodies.

## Versions, incidents and validation authority

The bundle retains the frozen owner V1 and V2 incoming sources, Root
incoming V2 through V5 candidates, Root's installed V6 snapshot, both
current installed sources, and the adapter owner V1. It retains the
public pieces and their exact concatenation. Failed candidate proofs are
not described as compiled. Current installed incoming is exactly Root V5
minus its 48-byte draft status line.

The final incoming proof adds explicit reductions for nested matches,
phase observations and Caller.advance to the owner V2 proof. Its public
contract remains byte-exact. Root reports three repaired failed incoming
probes. Root owns their compiler logs and snapshots. The adapter passed
its first strict probe. This reviewer found no further proof repair.

No display truncation, helper failure or source/public-contract defect
occurred in this fresh review. Root added only the immediate adapter
companion before freeze. The completed first incoming review was retained.
All previous review bundles remain frozen and unchanged.

Both public axiom reports list only propext, Classical.choice and
Quot.sound. Root reports final installed default and strict checks passed,
a full Audit pass at 4755 jobs and 83045 dependency checks, and a public
pass at 1219 checks and 118 prints. Root reports 15 compiler commands:
12 passing and three repaired failed probes, with 31 snapshots. Root
reports all 554 old protected inputs and 835 native inputs exact, with
556 current protected files and 4755 Lean sources. These are Root reports.

Root reports the final public log has 4895021 bytes and SHA-256
a65433465f5c7d7d0d42d9ef2deda9405c80b3ddfe5496f9361e4d8d451ce946.
The prior 4890474-byte public log is an exact prefix. The first incoming
update had 4892669 bytes. This reviewer read the complete new 4547-byte
two-law tail and did not acquire the old multi-megabyte public log.
root-reported-validation.json keeps that authority boundary explicit.

Actual worker history transport, reset control, original depth, global
coverage, whole-worker proof and Haskell correspondence remain outside
these laws. No Haskell defect or fix is established by this review.
