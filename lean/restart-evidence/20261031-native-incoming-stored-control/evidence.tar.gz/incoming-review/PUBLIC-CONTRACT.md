# Incoming public contract

Complete source-only candidate. No new law is claimed checked.
The local notations and typeclass variables are in the complete V2 file.

```lean
theorem incoming_run_stored (profile : Profile) (checkEmpty : Bool)
    (representativeFuel nativeFuel p h : Nat)
    (beforeCaller : Caller (bits + 2)) (before : EnumerationState.State Symbol EnumGuard)
    (uv : Nat) (incoming : Node) (incomingScs : List EnumerationState.Suspended) (queries : Queries)
    (ready : SourceCurrentConjunctionClassScan.Ready beforeCaller.checked)
    (realized : PendingRealized beforeCaller.checked.native.machine.heap before)
    (available : Available beforeCaller.checked.native.machine.heap incoming) (closed : incoming.free = [])
    (fits : Fits profile beforeCaller.checked) (room : Room bits profile)
    (stored : Stored beforeCaller.checked.native) :
    Stored (SourcePruningEnumerationIncomingNode.run checkEmpty representativeFuel nativeFuel p h
      beforeCaller before uv incoming incomingScs queries).2.1.checked.native
```
