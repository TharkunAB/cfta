# Incidents

No command failed. No tool output was truncated. No proof probe ran here.
V1 remains retained. V2 uses dsimp only [run] instead of unfold run to expose
the literal definition and let bindings. No theorem header changed.
