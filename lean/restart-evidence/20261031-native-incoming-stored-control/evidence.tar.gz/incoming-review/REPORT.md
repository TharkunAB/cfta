# Native Stored through actual IncomingNode.run

Status: source-only complete proof candidate. This worker ran no compiler,
evaluator or native execution. The final candidate is V2. V1 remains in this
bundle. The public theorem has not been claimed checked here.

## Result

`NativeStoredIncoming-v2-UNCOMPILED.lean` has 95 lines. It has one public law,
`incoming_run_stored`. It concludes native Stored for the actual returned
Caller.checked.native of IncomingNode.run. It covers all representative/native
fuel, p and h values, both checkEmpty modes, and every returned run branch.

Its property premises are exactly the proposed current entry gates:

- Ready for beforeCaller.checked.
- PendingRealized for the original enumeration state before.
- Availability and closed syntax for incoming.
- Current Fits profile and Room bits profile.
- Native Stored at beforeCaller.checked.native.

There is no supplied future trace, WordRanges, per-step Room, per-step Stored,
result, success, slot-root semantic, StorageValid or coverage predicate. The
public header is retained in PUBLIC-CONTRACT.md.

The candidate's final target is the native state in this exact expression:

```lean
(SourcePruningEnumerationIncomingNode.run checkEmpty representativeFuel nativeFuel p h
  beforeCaller before uv incoming incomingScs queries).2.1.checked.native
```

V1 unfolds run. V2 uses dsimp only [run] to expose its definition and local let
bindings. The statement and the proof method are unchanged. No command failure
or proof-check failure led to that source-level adjustment.

## Actual old-operand producer

The literal run body first calls UnionFind.findRoot. Its readState changes only
the representatives field. It then reads ORIGINAL before.values at the actual
found.representative. It does not read a new values store.

On the actual unenumerated/some-old-handle branch, the proof applies:

```lean
realized found.representative oldHandle oldScs slot
```

Here slot is the actual before.values lookup equation. PendingRealized gives a
decoded value, its lookup equation, availability and closed syntax. Equality of
that lookup with the actual old-handle lookup identifies the decoded value with
old. The existing IncomingNodeResources.initial_ranges proof uses this same
producer at an arbitrary supplied index. No stronger representative, pending,
original-slot or storage semantics is used.

`fits.room room` supplies the three current counter inequalities required by
the checked execute_stored law. That law internally derives Original,
WordRanges and a physical trace from the current entry facts. This incoming
proof supplies none of those as additional gates.

## Complete branch account

- Failed representative lookup retains beforeCaller.
- Missing, eliminated or enumerated original slots retain beforeCaller.
- A pending slot with no old handle retains beforeCaller, whether incoming can
  be encoded or not. The returned finish action concerns enumeration state.
- A failed old-handle decode retains beforeCaller.
- A decoded old node uses execute_stored on the exact literal empty-domain raw
  request with incoming and old.
- Raw yielded, failed, constraintError and blocked outcomes advance the Caller
  with that outcome's own checked state. The raw Stored conclusion therefore
  applies directly, including the native state of a finite yielded observation.
- A raw done outcome gives native Stored at queried. The true checkEmpty branch
  uses the checked unconditional EnabledEmpty.check_stored law. The false branch
  retains queried. Neither branch needs a new closedness or numeric property of
  the returned query.
- The actual EnabledEmpty phase can finish or fail. Both retain native Stored at
  their own returned checked state.
- A successful phase can fail to encode the replacement or return a finish
  action. Both paths retain the corresponding phase checked state through the
  exact Caller.advance definition. Empty rejection inside finish cannot change
  that checked component.

The source proof cases the actual raw observation. It then generalizes the
literal optional-phase expression, proves its Stored fact by the Boolean split,
and cases the resulting actual phase observation and encode result. The
phase equation is a local equation for that observed expression. It is not a
caller-supplied successor, trace or result.

## Checked inputs and owner boundaries

Root authorized full exact reuse of these installed checked modules:

- SourceCurrentAllocatedNativeStoredExecute.lean, 89 lines, SHA-256
  ed2bc2575ca4f3571e60b9c2cf5be4d14ed30f9f29e2578e82f7f82318bd9611.
- SourceCurrentAllocatedNativeStoredEnabledEmpty.lean, 43 lines, SHA-256
  5835734077c7cea16ccee0330cdaf12cab65dc96bfac55a4066c9c2dc8521d10.

Both complete copied sources are in reused/. Their hashes were verified before
use. Root reported default/strict installed checks and final Audit passed for
their checkpoint. Root reported final Audit 4753 jobs / 83043 dependencies and
public review 1217 / 118. This worker did not acquire or run those raw checks.
Those results concern the preceding checkpoint, not this new incoming law.

Context.ready can supply this law's Ready premise. Context.stored remains the
separate merge-memo property. The new native Stored premise remains a separate
maintained invariant. This theorem does not derive native Stored from the merge
property. Existing literal initialization gives the native Stored starting fact.
The larger caller induction must also retain it across its other operations.

## Boundaries

Stored retains its existing conditional structural meaning. For returned
empty-seen native cells with finite ordinary inputs, it gives the finite
ordinary result property and height bounds. The incoming law does not extend
that certificate to every recursive input or result.

This candidate does not establish sufficient original depth or original-input
capacity, finite global enumeration coverage, source reset transport, unchanged
step transport, whole-worker induction, public API correspondence, whole-program
termination or Haskell correspondence. Its current Fits/Room and caller entry
facts must still be maintained by the larger execution proof.

No Haskell source changed. No admitted actual Haskell execution occurred. No
Haskell defect or fix was established. There is no new Haskell FINDINGS entry.

## Provenance

All writes stayed in /tmp/mcfta-native-incoming-stored-review-20261030. Prior
bundles remain frozen. This worker ran no compiler, evaluator, native execution,
Git, network, board, production write, packaging operation or spawned worker.

No OLD whole or near-whole module was acquired. The old source cuts are:
IncomingNode lines 1-93 of 296; IncomingNodeResources lines 1-73 of 239; and
PartialState lines 50-65 of 250. Both OLD whole-module slots remain unused.

acquisitions.json retains full source SHA-256, byte/line counts, exact selected
ranges, copy paths and copy hashes. CUMULATIVE-SOURCE-UNIONS.json retains each
source union. Both V1 and V2 are retained. Incidents and later owner reports
remain separate from source evidence and checking claims.
