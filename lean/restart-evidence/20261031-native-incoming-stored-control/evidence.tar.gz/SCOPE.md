# Actual IncomingNode native certificate preservation

Continue the complete original-input, both-worker, public/Haskell objective.
Root alone owns production/compiler/evaluator/native/Git/network/board/packaging.
Check exact immutable Incoming V2, all current Ready/PendingRealized/incoming
availability/closedness/Fits/Room/entrynativeStored gates retained.
No supplied trace, WordRanges, outputStored, future result or iteration producer.
All actual run branches and supplied fuel values remain in scope.
Preserve all prior inputs/output/documents/drafts/failures.
Use unchanged serial 4 GiB/zero-swap/five-minute command cap.
No Haskell defect/fix/candidate or native run established.
Global worker history transport, replacements/unchanged work, original depth,
ordered coverage, public APIs and Haskell correspondence remain open.
Backend marker remains blocked despite resumed verified work.

Scope extends through the actual IncomingCacheAdapter first projection.
It retains every existing incoming gate at before.core and arbitrary cache/indexFuel.
No cached-index validity or output certificate premise is added.
The incoming-only checks and metadata remain under their original names.
