# Actual caller transport around IncomingNode.run

Status: source-only complete cache-adapter candidate. No compiler, evaluator or
native execution ran here. No new law is claimed checked in this bundle.

## Completed candidate

The nearest concrete cached caller is
SourcePruningEnumerationIncomingCacheAdapter.run. It invokes the actual
IncomingNode.run, returns its COMPLETE tuple as the first projection, and
attaches an optional cached-index candidate as the second projection.

NativeStoredIncomingCacheAdapter-v1-UNCOMPILED.lean has 42 lines. Its public
incoming_cache_adapter_stored law concludes native Stored at the actual
adapter result's .1.2.1.checked.native. It accepts every indexFuel, both
checkEmpty modes, every representative/native bound, every p/h bound, all raw
outcomes, and either presence or absence of the optional cache candidate.

Its entry gates are unchanged from the checked incoming law, specialized to
before.core: current Ready, PendingRealized, available/closed incoming,
Fits/Room, and entry native Stored. It adds no index-cache validity, output
Stored, future trace, per-step future certificate, future Room or completion
supplier.

The source's existing erase theorem is rfl. The candidate therefore changes
its native target definitionally to the actual IncomingNode.run target and
applies the checked incoming_run_stored law. It does not need to inspect the
cached-index write result. That result does not replace any observed caller
state.

Candidate SHA-256:
4b5d4385a1363811dbb77df5a2e31ecd811e5712b77433f9d9443bf28a1af468.
The complete header is in PUBLIC-CONTRACT.md.

## Other actual enclosing handler

SourcePruningEnumerationTerminal.run is the larger direct caller. Its source
body has these stages:

1. Return the same caller for Empty incoming.
2. Execute TerminalPrefix.run and inspect its actual enumeration observation.
3. Run SourcePruningEnumerationFold.run on the recorded source list.
4. Only on the actual singleton-success fold branch, invoke IncomingNode.run
   with foldCaller, folded, winner and foldQueries.
5. Retain the incoming result's caller, including incoming errors and failed
   observations.

The returned Caller comes from the fold even when the fold stops before the
incoming call. Therefore a full Terminal native Stored law must cover the
actual Fold.run result in ALL outcome branches. A successful-only fold memo
receipt would not establish this property.

This task does not claim the full Terminal law. MISSING-LOCAL-CONTRACTS.md states
the precise next native transport targets without assuming their conclusions.

## Existing fold producers must be reused

Fold.Ranges contains a recursive quantifier over actually completed dispatch
actions. It must not be added as a new future supplier to a higher public law.
However, an existing concrete producer is already present:
FoldAdmission.initial_ranges derives Ranges from current Seed/Fits/Reserved,
Context, PendingRealized, pending target, selected source-slot facts and the
known alphabet heap. These are retained existing source premises, not a new
future execution certificate.

The initial_ranges proof calls observed_singleton only after an actual
successful dispatch and its actually returned action have completed. That
producer returns a fresh post Context, actual saved-query relation,
PendingRealized, pending target, remaining-source selection, Fits and known
alphabet heap for the actual reached state. It supports induction on the rest
of the finite recorded source list. No proposed native law should replace this
producer with an assumed per-step transport function.

FoldResources.observed_resources uses that source structure to derive the
advanced Fits and known alphabet heap for outer successful Fold.run
observations. The inspected FoldInvariants.run_preserves theorem preserves
StorageValid and canonical waiting counts. Neither inspected conclusion
contains native Stored.

## Exact native head gate

The inspected Dispatch.dispatch definition covers the fold head. Most branches
retain beforeCaller. The native branch occurs only after both actual source
and target slots have unenumerated/some-handle form and both handles decode.
PendingRealized can provide availability and closed syntax at both original
values lookups. Current fits.room supplies the numeric bounds. The raw query is
the same literal empty-domain request already handled by execute_stored.

Its done branch calls afterQuery. That exact helper uses the same optional
EnabledEmpty.check and Caller.advance frame as the checked incoming law. The
non-done raw branch copies that raw outcome's own checked state.

The missing small native law is therefore dispatch_native_stored under current
Ready/PendingRealized/Fits/Room/entry-native-Stored premises. Its exact proposed
header is in MISSING-LOCAL-CONTRACTS.md. This task has not proved it. It is a
sibling dispatcher bridge, not a new premise of the completed cache-adapter
law.

Once that law is checked, the existing observed_singleton producer can transport
the non-native entry invariants through the actual singleton-success head.
An induction on sources should then establish Fold.run native Stored in every
outcome. The precise current-reservation Fold target is also retained. The
larger Terminal lift must export or compose the actual successful fold's Ready,
PendingRealized, Fits/Room and availability of incoming before it invokes the
checked incoming law. This task does not assume those properties at a future
fold state.

## Checked source input

Root reported V5 strict proof success for the installed
SourceCurrentAllocatedNativeStoredIncoming.lean, 105 lines, SHA-256
cd5b5db4b57e99d5f5cfe3a0c5c994464d814911b0c7cf73373d9f27fd0cae05.
This exact new source was copied and pinned before use. The public incoming
header remains the one from the preceding source-only bundle. The inspected
old callers are unchanged.

This worker did not run Root's check or acquire its raw execution log. Any
subsequent checking of this cache-adapter candidate belongs to Root's next
execution phase.

## Boundaries

Native Stored remains the conditional structural property of returned native
cells. This law preserves it through one concrete cache adapter. It does not
establish bounds for every recursive result, original-input capacity,
sufficient original depth, source reset or unchanged-step transport, full Fold
or Terminal preservation, whole-worker induction, finite global enumeration,
a public API theorem or Haskell correspondence.

Context.stored remains the merge-memo property. Native Stored is a separate
entry invariant. This adapter law does not derive one from the other.

No Haskell source changed. No admitted actual Haskell execution occurred. No
Haskell defect or fix was established. There is no new Haskell FINDINGS entry.

## Scope and provenance

All writes stayed in /tmp/mcfta-native-incoming-caller-review-20261031. Prior
bundles remain frozen. No compiler, evaluator, native execution, Git, network,
board, production change, packaging operation or spawned worker occurred here.

No OLD whole or near-whole module was acquired. Both slots remain unused.
The initial locator searched the exact IncomingNode.run function name. It
retained its direct call/reference lines only, including proof references.
Later body reads were exact named bounded cuts. Every source hash, byte/line
count, selected source lines, retained copy path and copy hash is in
acquisitions.json. CUMULATIVE-SOURCE-UNIONS.json records repeated-read unions.
Raw locators and stderr are retained. No command failed or output was truncated.
