    match (SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
  generalize observedEq : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
  unfold SourcePruningEnumerationIncomingNode.run at observedEq
