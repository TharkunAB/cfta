  have fields := SourcePruningEnumerationIncomingNode.run_canonical
  generalize original : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
