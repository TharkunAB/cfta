            have incomingFacts := SourcePruningEnumerationIncomingNode.run_carriers checkEmpty r n p h
            rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
                have incomingFacts := (SourcePruningEnumerationIncomingNode.run_carriers checkEmpty r n p h
                rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
                  rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
