    (observed : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h caller before.core
  have fields := SourcePruningEnumerationIncomingNode.run_carriers checkEmpty r n p h caller before.core
  generalize original : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
