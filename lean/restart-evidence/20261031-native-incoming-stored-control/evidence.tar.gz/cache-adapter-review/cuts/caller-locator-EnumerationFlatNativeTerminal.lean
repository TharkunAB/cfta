                        (SourcePruningEnumerationIncomingNode.run checkEmpty
