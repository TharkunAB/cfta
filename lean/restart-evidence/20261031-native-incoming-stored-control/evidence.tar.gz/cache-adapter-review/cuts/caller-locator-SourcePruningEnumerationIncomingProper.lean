  have fields := SourcePruningEnumerationIncomingNode.run_proper
  generalize original : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
