            match SourcePruningEnumerationIncomingNode.run checkEmpty representativeFuel nativeFuel p h
            SourcePruningEnumerationIncomingNode.run checkEmpty (r + extraRepresentative) (n + extraNative) P H
      SourcePruningEnumerationIncomingNode.run_complete formulas solver foldInventory foldCaller folded
