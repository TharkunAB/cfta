    SourcePruningEnumerationIncomingNode.run checkEmpty representativeFuel nativeFuel p h
      SourcePruningEnumerationIncomingNode.run checkEmpty representativeFuel nativeFuel p h
  have original : SourcePruningEnumerationIncomingNode.run checkEmpty representativeFuel nativeFuel p h
        SourcePruningEnumerationIncomingNode.run checkEmpty (r + extra) (n + extraNative) P H
