import MicroCFTA.SourcePruningEnumerationEnabledEmpty
import MicroCFTA.SourcePruningEnumerationFinish
import MicroCFTA.SourceCurrentEmptinessMerge
namespace MicroCFTA.SourcePruningEnumerationDispatch
def finishOptional (source target : Nat) (node : Option Nat)
noncomputable def afterQuery
noncomputable def dispatch
theorem dispatch_complete
