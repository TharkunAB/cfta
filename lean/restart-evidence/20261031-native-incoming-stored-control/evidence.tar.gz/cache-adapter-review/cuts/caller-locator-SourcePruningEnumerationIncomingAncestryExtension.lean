  have fields := SourcePruningEnumerationIncomingNode.run_ancestry_extension
  generalize original : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
