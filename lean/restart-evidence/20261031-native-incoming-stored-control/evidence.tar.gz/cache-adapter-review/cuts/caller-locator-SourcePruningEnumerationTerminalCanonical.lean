            have incomingCanonical := SourcePruningEnumerationIncomingNode.run_canonical checkEmpty r n p h
            rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
