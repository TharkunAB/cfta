        SourcePruningEnumerationIncomingNode.run checkEmpty (r + extra) (n + extraNative) P H
    SourcePruningEnumerationIncomingNode.run_complete formulas solver inventory
