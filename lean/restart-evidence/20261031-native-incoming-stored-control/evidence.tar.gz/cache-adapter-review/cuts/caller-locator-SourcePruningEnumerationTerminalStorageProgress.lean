    (incomingActual : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h foldCaller folded
