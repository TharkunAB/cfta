  have oldStable : ∀ extra, SourcePruningEnumerationIncomingNode.run checkEmpty
      SourcePruningEnumerationIncomingNode.run checkEmpty r nativeFuel p h
    simp only [SourcePruningEnumerationIncomingNode.run, stable extra,
  generalize oldRun : SourcePruningEnumerationIncomingNode.run checkEmpty r nativeFuel p h
