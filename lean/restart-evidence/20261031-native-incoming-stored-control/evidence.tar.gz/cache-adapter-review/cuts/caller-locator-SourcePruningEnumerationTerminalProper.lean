            have incomingProperState := SourcePruningEnumerationIncomingNode.run_proper checkEmpty r n p h
            rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
                  rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
