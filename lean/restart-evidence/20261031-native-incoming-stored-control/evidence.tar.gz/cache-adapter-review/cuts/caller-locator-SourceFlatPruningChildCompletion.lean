            generalize SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
