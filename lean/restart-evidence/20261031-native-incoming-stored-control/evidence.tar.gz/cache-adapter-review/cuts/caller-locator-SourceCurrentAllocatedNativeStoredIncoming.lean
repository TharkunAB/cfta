    Stored (SourcePruningEnumerationIncomingNode.run checkEmpty representativeFuel nativeFuel p h
  dsimp only [SourcePruningEnumerationIncomingNode.run]
