      (SourcePruningEnumerationIncomingNode.run checkEmpty representativeFuel nativeFuel p h
  simp only [run, SourcePruningEnumerationIncomingNode.run, completed, ← rootSame, related.values]
        (SourcePruningEnumerationIncomingNode.run checkEmpty (representativeFuel + extra) nativeFuel p h
