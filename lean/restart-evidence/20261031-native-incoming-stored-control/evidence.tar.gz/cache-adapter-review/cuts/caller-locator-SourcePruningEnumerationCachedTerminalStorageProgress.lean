            SourcePruningEnumerationIncomingNode.run checkEmpty (r + extraRepresentative) (n + extraNative) P H
  have incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
