        SourcePruningEnumerationIncomingNode.run checkEmpty (r + extra) (n + extraNative) P H
