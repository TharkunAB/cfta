  have original : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h caller before.core
  have larger := SourcePruningEnumerationIncomingNode.run_ok_stable
