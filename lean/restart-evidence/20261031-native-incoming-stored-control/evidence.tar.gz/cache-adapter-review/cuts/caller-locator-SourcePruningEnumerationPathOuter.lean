                          have incomingPaths := (SourcePruningEnumerationIncomingNode.run_paths (P := P)
                          rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
            have incomingPaths := SourcePruningEnumerationIncomingNode.run_paths (P := P) checkEmpty r n p h
            rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
