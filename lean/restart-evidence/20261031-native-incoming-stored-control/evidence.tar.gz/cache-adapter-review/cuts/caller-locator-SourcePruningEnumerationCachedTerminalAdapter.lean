                  (SourcePruningEnumerationIncomingNode.run checkEmpty representativeFuel nativeFuel p h
                        cases fallbackIncomingResult : SourcePruningEnumerationIncomingNode.run
                        cases resultEq : SourcePruningEnumerationIncomingNode.run checkEmpty
            SourcePruningEnumerationIncomingNode.run checkEmpty (r + extraRepresentative) (n + extraNative) P H
