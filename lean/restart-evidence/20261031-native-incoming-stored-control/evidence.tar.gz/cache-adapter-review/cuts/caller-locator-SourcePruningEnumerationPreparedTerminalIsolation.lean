            have incomingFacts := SourcePruningEnumerationIncomingNode.run_isolated checkEmpty r n p h
            rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
