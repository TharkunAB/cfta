import MicroCFTA.EnumerationFlatNativeFold
import MicroCFTA.SourcePruningEnumerationIncomingNode
namespace MicroCFTA.EnumerationFlatNativeIncoming
def finish (target handle : Nat) (incomingScs oldScs : List EnumerationState.Suspended)
theorem finish_related (related : EnumerationFlatState.Related flat earlier)
noncomputable def run
theorem run_related
theorem run_stable
