  have fields := SourcePruningEnumerationIncomingNode.run_mass
  generalize original : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
