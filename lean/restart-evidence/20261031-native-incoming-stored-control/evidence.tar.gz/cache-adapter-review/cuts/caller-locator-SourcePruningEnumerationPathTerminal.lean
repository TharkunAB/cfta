  have fields := SourcePruningEnumerationIncomingNode.run_paths (P := P)
  generalize original : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
                  rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
