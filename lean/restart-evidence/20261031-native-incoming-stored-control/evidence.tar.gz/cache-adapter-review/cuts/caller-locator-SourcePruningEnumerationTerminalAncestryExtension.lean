                  rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
