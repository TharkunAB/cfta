                    rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
                        have incomingLater := SourcePruningEnumerationIncomingNode.run_ok_stable
