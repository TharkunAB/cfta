                      rcases incomingObserved : SourcePruningEnumerationIncomingNode.run
