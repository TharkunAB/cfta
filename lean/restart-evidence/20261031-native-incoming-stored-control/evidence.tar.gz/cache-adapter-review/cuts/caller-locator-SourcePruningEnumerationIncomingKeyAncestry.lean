  have fields := SourcePruningEnumerationIncomingNode.run_key_ancestry
  generalize original : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
