                                        cases incomingEq : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
