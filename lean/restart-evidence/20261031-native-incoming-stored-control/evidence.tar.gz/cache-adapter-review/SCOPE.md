# Scope

Root assigned this source-only task at 2026-10-31 00:05 CET.
Find the nearest actual enclosing caller or handler of IncomingNode.run. Prove the smallest useful native Stored law without output Stored, future per-step certificates, abstract traces or future completion suppliers. Genuine current Ready/PendingRealized/Available/closed/Fits/Room gates may remain. If transport is missing, retain an exact local target without assuming its result.

Root owns compiler, evaluator, native execution, Git, network, board, production and packaging. No spawned worker. All writes stay here; earlier bundles remain frozen. Max two newly named OLD whole or near-whole modules, named before acquisition. Other reads use exact declaration/call locators and bounded cuts with metadata and cumulative unions.
