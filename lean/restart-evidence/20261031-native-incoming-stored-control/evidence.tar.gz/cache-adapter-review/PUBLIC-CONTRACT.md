# Cache adapter public contract

Complete source-only candidate. No new law is claimed checked.
Local notations and typeclass variables are in the complete candidate.

```lean
theorem incoming_cache_adapter_stored (profile : Profile) (checkEmpty : Bool)
    (representativeFuel nativeFuel p h indexFuel : Nat)
    (beforeCaller : Caller (bits + 2)) (before : EnumerationExpandableIndex.Cached Symbol Constraint)
    (target : Nat) (incoming : Node) (incomingScs : List EnumerationState.Suspended) (queries : Queries)
    (ready : SourceCurrentConjunctionClassScan.Ready beforeCaller.checked)
    (realized : PendingRealized beforeCaller.checked.native.machine.heap before.core)
    (available : Available beforeCaller.checked.native.machine.heap incoming) (closed : incoming.free = [])
    (fits : Fits profile beforeCaller.checked) (room : Room bits profile)
    (stored : Stored beforeCaller.checked.native) :
    Stored (SourcePruningEnumerationIncomingCacheAdapter.run checkEmpty representativeFuel nativeFuel p h indexFuel
      beforeCaller before target incoming incomingScs queries).1.2.1.checked.native
```
