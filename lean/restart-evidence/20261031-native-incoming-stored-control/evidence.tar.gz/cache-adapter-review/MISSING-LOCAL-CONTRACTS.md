# Exact next local native transport contracts

These are unproved targets. They are not premises or results of the completed
cache-adapter candidate. The local Symbol/Constraint/Node/Caller/Queries
notations are those in the acquired actual caller definitions.

The first target uses exactly the actual Dispatch.dispatch signature. Current
Ready, PendingRealized and Fits/Room can supply both decoded operands and the
three numeric bounds. It needs no pending-at-source or pending-at-target
semantic premise because nonmatching branches retain the original caller.

```lean
theorem dispatch_native_stored
    {bits : Nat} {EnumGuard : Type}
    (profile : SourceCurrentAllocatedNativeResourceForecast.Profile)
    (checkEmpty : Bool) (nativeFuel p h : Nat)
    (beforeCaller : SourceCurrentAllocatedPartialState.State (bits + 2))
    (before : EnumerationState.State Symbol EnumGuard)
    (source target : Nat) (queries : SourceEndpointMemo.Memos)
    (ready : SourceCurrentConjunctionClassScan.Ready beforeCaller.checked)
    (realized : PendingRealized beforeCaller.checked.native.machine.heap before)
    (fits : SourceCurrentConstrainedCapGeneratedQueryResources.Fits profile beforeCaller.checked)
    (room : SourceCurrentAllocatedNativeResourceForecast.Room bits profile)
    (stored : SourceCurrentAllocatedFiniteOrdinaryStored.Stored beforeCaller.checked.native) :
    SourceCurrentAllocatedFiniteOrdinaryStored.Stored
      (SourcePruningEnumerationDispatch.dispatch checkEmpty nativeFuel p h
        beforeCaller before source target queries).2.1.checked.native
```

The next target uses the CURRENT reservation and semantic premises of the
existing FoldAdmission.initial_ranges/observed_singleton producer. Those extra
current slot premises are needed by that inspected producer. This review does
not claim that each is logically necessary for a smaller native-only fold
proof. No future Ranges or future postcondition is added.

```lean
theorem fold_native_stored
    {bits : Nat} {EnumGuard : Type}
    (seed : SourcePruningEnumerationIncomingReservation.Seed)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : SourceCurrentAllocatedNativeInventoryState.Inventory)
    (beforeCaller : SourceCurrentAllocatedPartialState.State (bits + 2))
    (before : EnumerationState.State Symbol EnumGuard) (sources : List Nat)
    (checkEmpty : Bool) (n p h target : Nat) (memos : EndpointMemoGateTrace.Memos)
    (initial : SourceCurrentAllocatedPartialInvariant.Context formulas solver inventory beforeCaller memos)
    (realized : PendingRealized beforeCaller.checked.native.machine.heap before)
    (targetPending : PendingAt before target)
    (selected : ∀ source ∈ sources, PendingOrEliminated before source)
    (fits : SourceCurrentConstrainedCapGeneratedQueryResources.Fits seed.2 beforeCaller.checked)
    (reserved : SourcePruningEnumerationIncomingReservation.Reserved bits seed sources.length)
    (known : SourceEqualityAnnotationHeap.Heap (fun guard => guard ∈ seed.1)
      beforeCaller.checked.native.machine.heap)
    (stored : SourceCurrentAllocatedFiniteOrdinaryStored.Stored beforeCaller.checked.native) :
    SourceCurrentAllocatedFiniteOrdinaryStored.Stored
      (SourcePruningEnumerationFold.run checkEmpty n p h sources beforeCaller before target memos.query).2.1.checked.native
```

The intended proof uses the dispatch law at the actual head. Nonrecursive
branches return that reached caller directly. The only recursive branch has an
ACTUAL singleton-success action observation, so existing observed_singleton
supplies the successor Context/Realized/Fits/selected facts and the current
reservation supplies its own tail. Native Stored at that successor comes from
the head law, not a supplied future invariant.

For the full Terminal.run lift, an actual successful fold must additionally
supply the incoming law's entry Ready, PendingRealized, availability of the
unchanged incoming value and advanced Fits/Room. These are postconditions to
prove or compose from existing actual-observation transports. They must not be
added as a per-step future supplier to Terminal's public theorem.
