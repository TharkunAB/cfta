from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
control = base / '20261118-source-worker-seeds-components-publication-control-draft'
stage_control = base / '20261118-source-worker-seeds-components-staging-control-draft'
work = base / '20261118-source-worker-seeds-components-work'
runtime = base / '20261118-source-worker-seeds-components-publication'
prior_work = base / '20261118-retained-source-gate-skip-work'
prior_run = base / '20261118-retained-source-gate-skip-publication'
prior_archive = base / '20261118-retained-source-gate-skip-checkpoint'
source_commit = 'fc345af6e51dd1e813fed83423f25c3228b78874'
assert Path(__file__).resolve().parent == work.resolve()
archive_control = base / '20261118-source-worker-seeds-components-checkpoint-control-draft'
assert Path(__file__).read_bytes() == (archive_control / 'prepare-checkpoint-controls.py').read_bytes()
assert runtime.is_dir(), 'The actual passed publication must exist.'
sha = lambda data: hashlib.sha256(data).hexdigest()
bound = set()

def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data

def records(value):
    if isinstance(value, list):
        return [(item['file'], item) for item in value]
    if 'files' in value:
        return records(value['files'])
    if 'pins' in value:
        return records(value['pins'])
    return value.items()

for name, record in json.loads((control / 'MANIFEST.json').read_text())['files'].items():
    verify(control / name, record)
bound.add(control / 'MANIFEST.json')
for name, record in json.loads((control / 'ACTUAL-INPUT-PINS.json').read_text()).items():
    verify(root / name, record)
for name, record in records(json.loads((stage_control / 'MANIFEST.json').read_text())['files']):
    verify(stage_control / name, record)
bound.add(stage_control / 'MANIFEST.json')
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage_bytes = stage_path.read_bytes()
assert stage_bytes == (control / 'EXPECTED-STAGE.json').read_bytes()
stage = json.loads(stage_bytes)
assert stage['status'] == 'ACTUALLY STAGED BY ROOT AFTER BOTH VERIFIED SUBSETS'
assert stage['source_baseline'] == source_commit and stage['normal_Source_changed'] and not stage['published']
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6283, 5283, 733, 328)
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (7, 520, 527)
assert stage['new_public_theorems'] == stage['new_private_helpers_transitive'] == 7
assert stage['new_Prop_definitions'] == stage['definition_checks'] == stage['explicit_private_reports'] == 0
assert stage['resource_owner_reports_inherited'] == 264 and stage['fresh_credit_for_old_owner_theorems'] == 0
bound.add(stage_path)
overrides = stage['baseline_overrides']
assert set(overrides) == {'lean/MicroCFTA/Audit.lean', 'lean/MicroCFTA/SourceCurrentNativeNumericalSeedClosure.lean'}

def historical(name, record):
    digest = record['sha256'] if isinstance(record, dict) else record
    for path in [root / name, root / overrides.get(name, name)]:
        if path.is_file() and sha(path.read_bytes()) == digest:
            return verify(path, record)
    raise AssertionError(name)

# The two passed subsets provide seven public reports. Neither old nor private
# reports are counted again. All five selected outputs will be rebuilt below.
subsets = stage['private_subsets']
assert len(subsets) == 2
chosen = {}
for position, (subset, expected_session, expected_reports, expected_pins) in enumerate(
        zip(subsets, [23742, 33636], [5, 2], [6477, 6360])):
    private_control = base / subset['control']
    verify(private_control / 'MANIFEST.json', subset['control_manifest_sha256'])
    selection_bytes = verify(private_control / 'SELECTION.json', subset['selection_sha256'])
    assert selection_bytes == (control / subset['selection_copy']).read_bytes()
    selection = json.loads(selection_bytes)
    for name, record in records(json.loads((private_control / 'MANIFEST.json').read_text())['files']):
        verify(private_control / name, record)
    private_run = base / subset['runtime']
    receipt_path = root / subset['verified_receipt']
    receipt = json.loads(receipt_path.read_text())
    assert receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
    assert receipt['actual_session'] == expected_session
    assert receipt['source_baseline'] == source_commit and receipt['runtime'] == private_run.name
    checked = json.loads(verify(private_run / 'checked.json', receipt['checked_sha256']))
    assert json.loads(verify(private_run / 'results.json', receipt['results_sha256'])) == checked
    assert checked['checks'] == receipt['checks'] and all(checked['passed']) and checked['proof_credit']
    assert sum(item['total_axiom_reports'] for item in checked['checks']) == expected_reports
    assert all(item['exit'] == 0 and not item['diagnostics'] and not item['sorryAx'] and not item['nonstandard_axioms']
        and item['declaration_checks'] == 0 and item['axiom_free_reports'] == 0 for item in checked['checks'])
    assert checked['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
    pins = json.loads(verify(private_run / 'source-pins.json', receipt['source_pins_sha256']))
    assert len(pins) == receipt['pins_independently_reverified'] == expected_pins
    for name, digest in pins.items():
        historical(name, digest)
    bound.add(receipt_path)
    bound.update(private_run / (item['name'] + '.txt') for item in checked['checks'])
    for item in selection['components']:
        assert item['module'] not in chosen
        chosen[item['module']] = item
    if position == 1:
        assert checked['original_narrowing_FIRST_preserved'] and not checked['original_narrowing_FIRST_byte_equal']
        assert not checked['original_narrowing_FIRST_alpha_equivalent'] and checked['current_source_narrowing_FIRST_checked']
assert len(chosen) == 5
baseline_path = work / 'baseline-source-pins.json'
baseline = json.loads(baseline_path.read_text())
assert len(baseline) == 6279
for name, digest in baseline.items():
    historical(name, digest)
components = stage['components']
new_sources = {item['source_path'] for item in components if item['kind'] == 'new_module'}
assert len(components) == 5 and len(new_sources) == 4
current = sorted((root / 'lean/MicroCFTA').glob('*.lean'))
assert {str(path.relative_to(root)) for path in current} == set(baseline) | new_sources
assert len(set(baseline) - set(overrides)) == 6277
push = json.loads((prior_work / 'PUSH-VERIFIED.json').read_text())
prior_source = json.loads((prior_work / 'SOURCE-COMMIT.json').read_text())
prior_publication = json.loads((prior_work / 'PUBLICATION-VERIFIED.json').read_text())
assert push['source_commit'] == prior_source['source_commit'] == source_commit
assert push['checkpoint_commit'] == push['remote_commit'] == stage['prior_checkpoint']
assert push['actual_push_terminal'] and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal'] and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
assert prior_source['publication_actual_session'] == prior_publication['actual_session'] == 73094
assert prior_publication['actual_terminal'] and prior_publication['actual_terminal_exit'] == 0
assert prior_publication['combined_reports'] == 520 and prior_publication['resource_reports_inherited'] == 264
verify(prior_archive / 'manifest.json', push['archive_manifest_sha256'])
subprocess.run(['git', 'merge-base', '--is-ancestor', push['checkpoint_commit'], 'HEAD'], cwd=root, check=True)
prior_checked = json.loads((prior_run / 'checked.json').read_text())
assert prior_checked['all_five_gates_passed'] and prior_checked['source_pins_unchanged']
assert (prior_checked['source_files'], prior_checked['independent_reports'], prior_checked['resource_and_component_probes']) == (6279, 321, 520)
for name, digest in json.loads((prior_run / 'source-pins.json').read_text()).items():
    historical(name, digest)
bound.update([prior_work / 'PUSH-VERIFIED.json', prior_work / 'SOURCE-COMMIT.json',
    prior_work / 'PUBLICATION-VERIFIED.json', prior_work / 'PUBLICATION-ACTUAL-RUN.json',
    prior_run / 'checked.json', prior_run / 'source-pins.json', prior_run / 'IndependentProbes.lean',
    prior_archive / 'manifest.json', prior_archive / 'verify.py', prior_archive / 'archived-inputs.json'])
# Preserve the actual failed run and every precompiler correction as rejected
# history. A generated sorryAx report never supplies inherited proof credit.
failed_receipt = json.loads((work / 'FIRST-CHECK-REJECTED.json').read_text())
assert failed_receipt['actual_session'] == 84470 and failed_receipt['actual_terminal_exit'] == 1
failed_run = base / failed_receipt['runtime']
failed = json.loads((failed_run / 'results.json').read_text())
assert not (failed_run / 'checked.json').exists() and not failed['proof_credit']
assert failed['checks'] == failed_receipt['checks']
for name, digest in json.loads((failed_run / 'source-pins.json').read_text()).items():
    historical(name, digest)
bound.update([work / 'FIRST-CHECK-REJECTED.json', failed_run / 'results.json', failed_run / 'source-pins.json'])
bound.update(failed_run / (item['name'] + '.txt') for item in failed['checks'])
raw_sources = {}
public = b''
private_count = 0
for item in components:
    original = chosen[item['module']]
    for key in ['module', 'kind', 'packet', 'manifest_sha256', 'source', 'raw_sha256', 'raw_bytes',
                'probe', 'probe_sha256', 'public_qnames', 'expected_axiom_reports', 'expected_declaration_checks']:
        assert item[key] == original[key], (item['module'], key)
    packet = base / item['packet']
    manifest = json.loads(verify(packet / 'MANIFEST.json', item['manifest_sha256']))
    for name, record in records(manifest['files']):
        verify(packet / name, record)
    for filename in ['SOURCE-PINS.json', 'ADDITIONAL-SOURCE-PINS.json', 'DEPENDENCY-PINS.json']:
        if (packet / filename).exists():
            for name, record in records(json.loads((packet / filename).read_text())):
                historical(name, record)
    raw = verify(root / item['source_path'], {'sha256': item['raw_sha256'], 'bytes': item['raw_bytes']})
    assert raw == (packet / item['source']).read_bytes()
    declarations = raw
    if item['kind'] == 'existing_owner_import_and_EOF':
        before = verify(root / item['old_snapshot'], {'sha256': item['owner_sha256'], 'bytes': item['owner_bytes']})
        prefix = verify(packet / item['imports'], item['imports_sha256'])
        declarations = verify(packet / item['append'], item['append_sha256'])
        assert len(before) == 23529 and len(prefix) == item['owner_offset'] == 61
        assert raw == prefix + before + declarations
    assert b'#print axioms ' not in raw and b'#check ' not in raw
    assert not re.search(rb'set_option\s+(maxHeartbeats|maxRecDepth|warningAsError|linter\.)', declarations)
    count = len(re.findall(rb'^private theorem ', declarations, re.M))
    assert count == item['new_private_helpers_transitive']
    private_count += count
    for header in item['headers']:
        data = verify(packet / header['file'], header['sha256'])
        start = raw.index(data.splitlines()[0])
        assert raw[start:raw.index(b':= by', start)].rstrip() == data.rstrip()
    probe = verify(packet / item['probe'], item['probe_sha256'])
    assert probe.count(b'#print axioms ') == item['expected_axiom_reports'] and b'#check ' not in probe
    private_run = base / next(subset['runtime'] for subset in subsets if item['module'] in subset['modules'])
    assert (private_run / 'source/MicroCFTA' / item['source']).read_bytes() == raw + b'\n' + probe
    bound.add(private_run / 'source/MicroCFTA' / item['source'])
    raw_sources[item['module']] = raw
    public += probe
assert private_count == 7 and public.count(b'#print axioms ') == 7
assert public == (work / 'PUBLIC-PROBES.lean.txt').read_bytes() == (control / 'EXPECTED-PUBLIC-PROBES.lean.txt').read_bytes()
imports = (work / 'IMPORTS.lean.txt').read_bytes()
assert imports == (control / 'EXPECTED-IMPORTS.lean.txt').read_bytes()
assert len(imports) == stage['audit_old_block_offset'] == 287 and imports.count(b'import ') == 4
old_audit = verify(root / overrides['lean/MicroCFTA/Audit.lean'], {'sha256': stage['old_audit_sha256'], 'bytes': stage['old_audit_bytes']})
assert len(old_audit) == 434278 and old_audit.count(b'#print axioms ') == 726
assert (root / 'lean/MicroCFTA/Audit.lean').read_bytes() == imports + old_audit + b'\n' + public
assert (root / 'lean/MicroCFTA/Audit.lean').read_bytes().count(b'#print axioms ') == 733
assert sum(line.startswith(b'import ') for line in (root / 'lean/MicroCFTA/Audit.lean').read_bytes().splitlines()) == 5283
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 321
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = sha((root / owner_name).read_bytes())
assert owner_sha == baseline[owner_name]
normal_objects = root / 'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()
# Recompute the combined transitive order at the actual staged bytes.
dag = json.loads((control / 'TOPOLOGICAL-ORDER.json').read_text())
edges = {}
visiting = set()
visited = set()
ordered = []

def walk(module):
    if module in visited:
        return
    assert module not in visiting, ('import cycle', module)
    visiting.add(module)
    data = (root / 'lean/MicroCFTA' / (module + '.lean')).read_text()
    edges[module] = re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$', data, re.M)
    if module not in chosen:
        assert (normal_objects / (module + '.olean')).is_file(), module
    for child in edges[module]:
        walk(child)
    visiting.remove(module)
    visited.add(module)
    ordered.append(module)

for module in stage['compile_order']:
    walk(module)
assert edges == dag['direct_imports']
assert [module for module in ordered if module in chosen] == stage['compile_order'] == dag['candidate_order']
for name in ['strict-bind.py.txt', 'publication-driver.py.txt', 'shadow-compile.py.txt']:
    ast.parse((control / name).read_text())

import gzip

archive = base / '20261118-source-worker-seeds-components-checkpoint'
board_prefix = 'current-board-source-worker-seeds-components-'
read = lambda path: json.loads(path.read_text())
git = lambda *args: subprocess.check_output(['git', *args], cwd=root)
for name, record in records(read(archive_control / 'MANIFEST.json')['files']):
    verify(archive_control / name, record)
for name, record in records(read(archive_control / 'SOURCE-PINS.json')):
    verify(root / name, record)
bindings = read(archive_control / 'prior-bindings.json')
assert bindings['prior_checkpoint'] == push['checkpoint_commit'] == '7dd87b6642d3114e1d02713af04a5ed494f72059'
source_receipt = read(work / 'SOURCE-COMMIT.json')
code = source_receipt['source_commit']
assert code == 'f8feb9f2dc42b8213c002281cdbce449404ab2f9'
assert source_receipt['parent'] == push['checkpoint_commit']
assert source_receipt['actual_terminal'] and source_receipt['actual_terminal_exit'] == 0
assert source_receipt['private_actual_sessions'] == [23742, 33636]
assert source_receipt['publication_actual_session'] == 83810
assert source_receipt['selected_public_FIRST_headers_checked']
assert source_receipt['original_narrowing_FIRST_preserved']
assert not source_receipt['original_narrowing_FIRST_byte_equal'] and not source_receipt['original_narrowing_FIRST_alpha_equivalent']
assert not source_receipt['joint_finite_completion_proved'] and not source_receipt['haskell_changed']
assert git('rev-parse', 'HEAD').decode().strip() == code
assert git('rev-parse', code + '^').decode().strip() == push['checkpoint_commit']
assert git('branch', '--show-current').decode().strip() == 'formalize'
assert not git('status', '--porcelain', '--untracked-files=no')
changed = {item['source_path'] for item in components} | {'lean/MicroCFTA/Audit.lean'}
assert len(changed) == 6 and set(source_receipt['files']) == changed
assert set(git('diff', '--name-only', push['checkpoint_commit'], code).decode().splitlines()) == changed
for name in changed:
    assert git('show', code + ':' + name) == (root / name).read_bytes(), name
for name in overrides:
    assert git('show', push['checkpoint_commit'] + ':' + name) == (root / overrides[name]).read_bytes(), name
# All three document preflights run before any archive or document write.
for name in ['NEXT-PROMPT.md', 'HANDOFF.md', 'FINDINGS.md']:
    assert (root / name).read_bytes() == git('show', code + ':' + name), name
report = read(runtime / 'checked.json')
publication = read(work / 'PUBLICATION-VERIFIED.json')
actual = read(work / 'PUBLICATION-ACTUAL-RUN.json')
assert publication['actual_session'] == actual['actual_session'] == 83810
assert publication['actual_terminal'] and publication['actual_terminal_exit'] == 0
assert actual['actual_terminal'] and actual['actual_terminal_exit'] == 0
assert publication['runtime'] == actual['runtime'] == runtime.name
assert publication['checks'] == report['checks']
assert [item['total_axiom_reports'] for item in report['checks']] == [733, 7, 328, 733, 733]
assert [(item['axiom_groups'], item['axiom_free_reports']) for item in report['checks']] == [(727, 6), (7, 0), (325, 3), (727, 6), (727, 6)]
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['sorryAx']
    and not item['nonstandard_axioms'] and item['declaration_checks'] == 0 for item in report['checks'])
assert report['all_five_gates_passed'] and report['source_pins_unchanged']
assert (report['source_files'], report['direct_audit_imports'], report['individual_reports'], report['independent_reports']) == (6283, 5283, 733, 328)
assert (report['fresh_reports'], report['inherited_reports'], report['combined_reports']) == (7, 520, 527)
assert (report['new_public_theorems'], report['new_private_theorems'], report['new_theorem_declarations']) == (7, 7, 14)
assert report['new_prop_definitions'] == report['new_definition_declaration_checks'] == 0
assert report['resource_owner_reports_inherited'] == 264 and report['owner_preflight_reports_fresh_this_batch'] == 0
assert report['audited_theorems'] == publication['audited_theorems'] == source_receipt['audited_theorems'] == 100214
for field in ['resource_admitted_request_Seeds_component_checked', 'selected_preparation_original_fuel_Seeds_component_checked',
        'actual_incoming_event_resource_component_checked', 'source_qualified_original_fuel_narrowing_checked',
        'same_actual_dispatch_event_resources_checked']:
    assert report[field], field
for field in ['all_original_eager_worker_query_admissions_proved', 'original_eager_worker_all_calls_Seeds_propagation_proved',
        'native_inhabitance_proved', 'actual_source_type_marker_role_preservation_proved', 'guard_truth_proved',
        'joint_finite_completion_proved', 'haskell_changed']:
    assert not report[field], field
public_pins = read(runtime / 'source-pins.json')
for name, digest in public_pins.items():
    verify(root / name, digest)
assert publication['pins_independently_reverified'] == len(public_pins) == 8194
assert sha((runtime / 'source-pins.json').read_bytes()) == publication['source_pins_sha256']
assert sha((runtime / 'checked.json').read_bytes()) == publication['checked_sha256']
assert read(runtime / 'results.json') == report
source_pins = {name: digest for name, digest in public_pins.items() if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
assert len(source_pins) == 6283
# The executed controller and the unused supplement have separate provenance.
provenance = read(work / 'SOURCE-COMMIT-ACTUAL-RUN.json')
assert provenance['source_commit'] == code and provenance['actual_session'] == 31393
assert provenance['actual_terminal'] and provenance['actual_terminal_exit'] == 0
executed_control = base / provenance['executed_control']
unused_control = base / provenance['later_unused_supplement']
assert executed_control.name == '20261118-source-worker-seeds-components-source-commit-control-draft'
assert unused_control.name == '20261118-source-worker-seeds-components-source-commit-final-receipts'
verify(executed_control / 'MANIFEST.json', '985b8ed117dbb7114f4db18d66379cc33409e9cc4edbefbfa3ae7646273faae0')
verify(unused_control / 'MANIFEST.json', '39f90484411a92f8b50fd5f6b8c1603ba19f450f77e7dd00be1c6a62a376dcd4')
for packet in [executed_control, unused_control]:
    for name, record in records(read(packet / 'MANIFEST.json')['files']):
        verify(packet / name, record)
    for name, record in records(read(packet / 'SOURCE-PINS.json')):
        verify(root / name, record)
assert (work / 'commit-source.py').read_bytes() == (executed_control / 'commit-source.py').read_bytes()
assert (unused_control / 'commit-source.py').read_bytes() == (executed_control / 'commit-source.py').read_bytes().replace(
    executed_control.name.encode(), unused_control.name.encode())
assert provenance['supplement_pins_independently_verified_after_commit'] == len(read(unused_control / 'SOURCE-PINS.json')) == 22
assert provenance['only_script_difference_is_CONTROL_location'] and provenance['final_receipts_required_and_checked_by_executed_script']
assert provenance['executed_control_manifest_sha256'] == sha((executed_control / 'MANIFEST.json').read_bytes())
assert provenance['later_supplement_manifest_sha256'] == sha((unused_control / 'MANIFEST.json').read_bytes())
assert provenance['source_payload_files'] == 6 and not provenance['root_documents_or_checkpoint_committed']
# Bind the committed prior archive. Do not select or recursively copy it.
for name, field in [('manifest.json', 'prior_manifest_sha256'), ('checkpoint.json', 'prior_checkpoint_json_sha256')]:
    data = (prior_archive / name).read_bytes()
    assert sha(data) == bindings[field]
    assert git('show', push['checkpoint_commit'] + ':' + str((prior_archive / name).relative_to(root))) == data
prior_checkpoint_data = read(prior_archive / 'checkpoint.json')
assert prior_checkpoint_data['checked_code'] == bindings['prior_source_commit'] == source_commit
assert prior_checkpoint_data['resource_and_component_probes'] == 520
old_pins = json.loads(gzip.decompress((prior_archive / 'source-pins.json.gz').read_bytes()))
assert baseline == {name: digest for name, digest in old_pins.items() if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
for name, digest in old_pins.items():
    historical(name, digest)
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    assert old_pins[name] == public_pins[name]
request = read(work / (board_prefix + 'request.json'))
canonical = read(work / (board_prefix + 'canonical.json'))
assert canonical['verified']
post = canonical.get('post', canonical)
assert post['id'] == request['request_id']
assert type(post['sequence']) is int and post['sequence'] > 0
for key, expected in [('author', request['username']), ('thread_id', request['thread_id']),
        ('post_type', request['post_type']), ('content', request['content']), ('metadata', request['metadata'])]:
    assert post[key] == expected, key
assert post['metadata']['source'] == code
# Root finalizes the terminal-only cleanup receipt before this controller runs.
cleanup = read(work / 'COMBINED-TMP-CLEANUP.json')
assert cleanup['all_owned_terminal_directories_removed'] and cleanup['unknown_tmp_entries_preserved']
assert cleanup['no_cache_data_copied']
actual_runs = [(84470, '20261118-source-worker-seeds-components-check'),
    (23742, '20261118-source-worker-seeds-components-repair-check'),
    (33636, '20261118-source-worker-dispatch-narrowing-check'), (83810, runtime.name)]
assert len(cleanup['runs']) == 4
paths = []
cumulative = 6566824277
for item, (session, name) in zip(cleanup['runs'], actual_runs):
    assert item['actual_session'] == session and item['runtime'] == name
    assert item['path'] == read(base / name / 'objects.json')['path']
    assert item['owned_terminal_only'] and item['normal_cache_preserved'] and item['unknown_tmp_entries_preserved']
    assert item['all_targets_removed'] and item['no_cache_data_copied']
    assert not item['live_process_references'] and not item['process_scan_errors']
    assert not Path(item['path']).exists() and not Path(item['path']).is_symlink()
    assert item['prior_cumulative_removed_bytes'] == cumulative
    cumulative += item['regular_bytes_removed']
    assert item['cumulative_removed_bytes'] == cumulative
    paths.append(item['path'])
assert len(set(paths)) == 4
assert cleanup['regular_bytes_removed'] == sum(item['regular_bytes_removed'] for item in cleanup['runs']) == 7909840
assert cleanup['symlinks_removed'] == sum(item['symlinks_removed'] for item in cleanup['runs']) == 25249
assert cumulative == cleanup['cumulative_removed_bytes'] == 6574734117
assert cleanup['normal_cache_targets_at_final_cleanup'] == 6317
assert cleanup['normal_target_stat_sha256_at_final_cleanup'] == cleanup['runs'][-1]['normal_target_stat_sha256'] == 'c090bccd76f37b15551823104242982fa395b12cc86096148dfc1f2a66a4abd1'
assert 'refused before deletion' in cleanup['runs'][-1]['initial_inline_scan'].lower()
start = read(work / 'START.json')
assert start['manual_work_explicitly_authorized'] and not start['joint_finite_completion_proved']
assert start['persistent_goal_control_status'] == 'paused'
assert start['expected_checks'] == 3 and start['expected_public_reports'] == 5
scope_update = read(work / 'BATCH-SCOPE-UPDATE.json')
assert scope_update['original_START_preserved'] and scope_update['initial_components'] == 3
assert scope_update['combined_future_public_reports_expected'] == scope_update['combined_future_private_helpers_transitive_expected'] == 7
combined_private = read(work / 'COMBINED-PRIVATE-VERIFIED.json')
assert [item['actual_session'] for item in combined_private['subsets']] == [23742,33636]
assert combined_private['public_reports'] == combined_private['private_helpers_transitive'] == 7
assert combined_private['all_selected_public_statements_checked'] and combined_private['no_subsets_recounted']
resume = read(work / 'RESUME-AUTHORIZATION.json')
assert resume['manual_work_explicitly_authorized'] and resume['earlier_usage_pause_lifted']
assert "Keep going. We'll use a reset if needed." in resume['authorizing_instructions']
assert resume['persistent_goal_control_status'] == 'paused'
assert not resume['goal_operation_performed'] and not resume['goal_completion_claimed']
usage = read(work / 'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int, float] and 0 <= percent <= 100
assert usage['current_usage_not_measured'] and usage['earlier_usage_pause_lifted_by_user_resume']
assert percent == 81 and '17:53:' in usage['checked_at']
handoff = (work / 'LIVE-HANDOFF.md').read_text()
assert code in handoff and 'open' in handoff.lower()
roots = read(archive_control / 'selection-roots.json')
assert len(roots) == len(set(roots)) == 22
additional = read(archive_control / 'archive-additional-roots.json')
assert len(additional) == 1
for item in additional:
    assert item['current_batch_theorem_credit'] == 0 and not item['private_runtime_selected']
    packet = base / item['root']
    verify(packet / item['manifest'], item['sha256'])
    for name, record in records(read(packet / item['manifest'])['files']):
        verify(packet / name, record)
    for filename in ['SOURCE-PINS.json', 'ADDITIONAL-SOURCE-PINS.json', 'DEPENDENCY-PINS.json']:
        if (packet / filename).exists():
            for name, record in records(read(packet / filename)):
                historical(name, record)
    roots.append(item['root'])
assert len(roots) == len(set(roots)) == 23 and prior_archive.name not in roots
assert all((base / name).is_dir() and not (base / name).is_symlink() for name in roots)
assert not any('work59' in name.lower() or 'ordered-fold-query-resources-check' in name for name in roots)
assert all(name in read(archive_control / 'selection-roots.json') or name in {item['root'] for item in additional} for name in roots)
for item in read(archive_control / 'original-header-files.json'):
    assert sha((root / item['path']).read_bytes()) == sha((root / item['original']).read_bytes()) == item['sha256']
selected_roots = sorted(str((base / name).relative_to(root)) for name in roots)
assert not archive.exists()
tree = hashlib.sha256()
for name, digest in sorted(source_pins.items()):
    tree.update(name.encode() + b'\0' + digest.encode() + b'\n')
config = dict(report)
config.update(checked_code=code, prior_checkpoint=push['checkpoint_commit'], public_run=str(runtime), public_gates=5,
    explicit_reports=733, board_prefix=board_prefix, board_post_id=post['id'], board_sequence=post['sequence'],
    source_tree_sha256=tree.hexdigest(), old_other_Source_files_byte_exact=6277,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],
    cleanup_receipt='COMBINED-TMP-CLEANUP.json', removed_regular_bytes=cleanup['regular_bytes_removed'],
    removed_symlinks=cleanup['symlinks_removed'], historical_primary_usage_percent=percent,
    historical_primary_usage_checked_at=usage['checked_at'], current_usage_not_measured=True,
    prior_immutable_archive=prior_archive.name, prior_manifest_sha256=bindings['prior_manifest_sha256'],
    actual_private_sessions=[23742,33636], actual_publication_session=83810,
    actual_source_commit_session=31393, executed_source_commit_control=executed_control.name,
    unused_source_commit_supplement=unused_control.name, unused_supplement_executed=False,
    unused_supplement_pins_independently_verified_after_commit=22,
    old_usage_pause_reintroduced=False, persistent_goal_control_status='paused',
    work_authorized_by_explicit_user_resume=True, goal_active=False, goal_completion_claimed=False,
    existing_resource_FieldsThrough_observers_exported=True,
    original_per_event_worker_resource_attachment_proved=False,
    original_worker_admissions_proved=False, native_inhabitance_proved=False,
    joint_finite_completion_proved=False, compiled_haskell_correspondence_proved=False, haskell_changed=False,
    additional_frozen_roots=additional, additional_frozen_roots_theorem_credit=0,
    original_incoming_filename_collision_rejected_before_compiler=True,
    incoming_filename_only_repair_preserves_entire_raw_and_FIRST=True,
    original_legacy_narrowing_FIRST_rejected_before_compiler=True,
    original_legacy_narrowing_FIRST_equivalent_to_current=False,
    future_worker_attachment_runtimes_selected=False)
skipped = sorted(str(path.relative_to(root)) for path in base.iterdir()
    if path.is_dir() and path.name.startswith(('20261117-', '20261118-')) and str(path.relative_to(root)) not in selected_roots)
review = {'selected_roots':23, 'base_roots':22, 'additional_frozen_roots':additional,
    'additional_frozen_roots_theorem_credit':0, 'fresh_public_reports':7,
    'inherited_reports':520, 'combined_reports':527, 'new_public_theorems':7,
    'new_private_theorems':7, 'new_theorem_declarations':14,
    'new_Prop_definitions':0, 'Prop_declaration_checks':0, 'Prop_axiom_credit':0,
    'resource_owner_reports_inherited':264, 'current_batch_failures_preserved':[84470],
    'successful_private_and_public_runs_preserved':[23742,33636,83810],
    'source_commit_executed_control':executed_control.name,
    'source_commit_unused_supplement':unused_control.name, 'unused_supplement_executed':False,
    'all_root_documents_preserved_as_suffix':True,
    'existing_resource_FieldsThrough_observers_exported':True,
    'future_worker_attachment_runtimes_selected':False, 'joint_finite_completion_proved':False}
note = (archive_control / 'checkpoint-note.md').read_text()
normalized_note = ' '.join(note.lower().split())
assert 'historical' in normalized_note and 'current usage was not measured' in normalized_note
assert '985' in note and '39' in note and 'not executed' in normalized_note
assert 'ONE' in note and 'SAME' in note
for key, value in {'THEOREMS':report['audited_theorems'], 'REMOVED':cleanup['regular_bytes_removed'],
        'SYMLINKS':cleanup['symlinks_removed'], 'CLEANUP':cleanup['cumulative_removed_bytes'],
        'USAGE':percent, 'BOARD':post['sequence']}.items():
    note = note.replace('{{' + key + '}}', str(value))
assert set(re.findall(r'\{\{(.*?)\}\}', note)) == {'TIME','TREE','CODE'}
outputs = {'checkpoint-config.json':config, 'archive-roots.json':selected_roots,
    'skipped-published-roots.json':skipped, 'selection-review.json':review}
assert all(not (work / name).exists() for name in outputs)
# No archive or Work write occurs before every preceding guard passes.
for name, value in outputs.items():
    (work / name).write_text(json.dumps(value, indent=2) + '\n')
(work / 'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code':code, 'archive':archive.name, 'roots':23,
    'board_sequence':post['sequence'], 'fresh_public_reports':7, 'inherited_reports':520,
    'combined_reports':527, 'current_usage_not_measured':True,
    'executed_source_commit_control':executed_control.name, 'unused_supplement_executed':False}))
