from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
control = base / '20261118-source-worker-seeds-components-publication-control-draft'
stage_control = base / '20261118-source-worker-seeds-components-staging-control-draft'
work = base / '20261118-source-worker-seeds-components-work'
runtime = base / '20261118-source-worker-seeds-components-publication'
prior_work = base / '20261118-retained-source-gate-skip-work'
prior_run = base / '20261118-retained-source-gate-skip-publication'
prior_archive = base / '20261118-retained-source-gate-skip-checkpoint'
source_commit = 'fc345af6e51dd1e813fed83423f25c3228b78874'
assert Path(__file__).resolve().parent == work.resolve()
assert Path(__file__).read_bytes() == (control / 'prepare-publication.py').read_bytes()
assert not runtime.exists(), 'Preserve all earlier publication runtimes.'
sha = lambda data: hashlib.sha256(data).hexdigest()
bound = set()

def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data

def records(value):
    if isinstance(value, list):
        return [(item['file'], item) for item in value]
    if 'files' in value:
        return records(value['files'])
    if 'pins' in value:
        return records(value['pins'])
    return value.items()

for name, record in json.loads((control / 'MANIFEST.json').read_text())['files'].items():
    verify(control / name, record)
bound.add(control / 'MANIFEST.json')
for name, record in json.loads((control / 'ACTUAL-INPUT-PINS.json').read_text()).items():
    verify(root / name, record)
for name, record in records(json.loads((stage_control / 'MANIFEST.json').read_text())['files']):
    verify(stage_control / name, record)
bound.add(stage_control / 'MANIFEST.json')
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage_bytes = stage_path.read_bytes()
assert stage_bytes == (control / 'EXPECTED-STAGE.json').read_bytes()
stage = json.loads(stage_bytes)
assert stage['status'] == 'ACTUALLY STAGED BY ROOT AFTER BOTH VERIFIED SUBSETS'
assert stage['source_baseline'] == source_commit and stage['normal_Source_changed'] and not stage['published']
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6283, 5283, 733, 328)
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (7, 520, 527)
assert stage['new_public_theorems'] == stage['new_private_helpers_transitive'] == 7
assert stage['new_Prop_definitions'] == stage['definition_checks'] == stage['explicit_private_reports'] == 0
assert stage['resource_owner_reports_inherited'] == 264 and stage['fresh_credit_for_old_owner_theorems'] == 0
bound.add(stage_path)
overrides = stage['baseline_overrides']
assert set(overrides) == {'lean/MicroCFTA/Audit.lean', 'lean/MicroCFTA/SourceCurrentNativeNumericalSeedClosure.lean'}

def historical(name, record):
    digest = record['sha256'] if isinstance(record, dict) else record
    for path in [root / name, root / overrides.get(name, name)]:
        if path.is_file() and sha(path.read_bytes()) == digest:
            return verify(path, record)
    raise AssertionError(name)

# The two passed subsets provide seven public reports. Neither old nor private
# reports are counted again. All five selected outputs will be rebuilt below.
subsets = stage['private_subsets']
assert len(subsets) == 2
chosen = {}
for position, (subset, expected_session, expected_reports, expected_pins) in enumerate(
        zip(subsets, [23742, 33636], [5, 2], [6477, 6360])):
    private_control = base / subset['control']
    verify(private_control / 'MANIFEST.json', subset['control_manifest_sha256'])
    selection_bytes = verify(private_control / 'SELECTION.json', subset['selection_sha256'])
    assert selection_bytes == (control / subset['selection_copy']).read_bytes()
    selection = json.loads(selection_bytes)
    for name, record in records(json.loads((private_control / 'MANIFEST.json').read_text())['files']):
        verify(private_control / name, record)
    private_run = base / subset['runtime']
    receipt_path = root / subset['verified_receipt']
    receipt = json.loads(receipt_path.read_text())
    assert receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
    assert receipt['actual_session'] == expected_session
    assert receipt['source_baseline'] == source_commit and receipt['runtime'] == private_run.name
    checked = json.loads(verify(private_run / 'checked.json', receipt['checked_sha256']))
    assert json.loads(verify(private_run / 'results.json', receipt['results_sha256'])) == checked
    assert checked['checks'] == receipt['checks'] and all(checked['passed']) and checked['proof_credit']
    assert sum(item['total_axiom_reports'] for item in checked['checks']) == expected_reports
    assert all(item['exit'] == 0 and not item['diagnostics'] and not item['sorryAx'] and not item['nonstandard_axioms']
        and item['declaration_checks'] == 0 and item['axiom_free_reports'] == 0 for item in checked['checks'])
    assert checked['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
    pins = json.loads(verify(private_run / 'source-pins.json', receipt['source_pins_sha256']))
    assert len(pins) == receipt['pins_independently_reverified'] == expected_pins
    for name, digest in pins.items():
        historical(name, digest)
    bound.add(receipt_path)
    bound.update(private_run / (item['name'] + '.txt') for item in checked['checks'])
    for item in selection['components']:
        assert item['module'] not in chosen
        chosen[item['module']] = item
    if position == 1:
        assert checked['original_narrowing_FIRST_preserved'] and not checked['original_narrowing_FIRST_byte_equal']
        assert not checked['original_narrowing_FIRST_alpha_equivalent'] and checked['current_source_narrowing_FIRST_checked']
assert len(chosen) == 5
baseline_path = work / 'baseline-source-pins.json'
baseline = json.loads(baseline_path.read_text())
assert len(baseline) == 6279
for name, digest in baseline.items():
    historical(name, digest)
components = stage['components']
new_sources = {item['source_path'] for item in components if item['kind'] == 'new_module'}
assert len(components) == 5 and len(new_sources) == 4
current = sorted((root / 'lean/MicroCFTA').glob('*.lean'))
assert {str(path.relative_to(root)) for path in current} == set(baseline) | new_sources
assert len(set(baseline) - set(overrides)) == 6277
push = json.loads((prior_work / 'PUSH-VERIFIED.json').read_text())
prior_source = json.loads((prior_work / 'SOURCE-COMMIT.json').read_text())
prior_publication = json.loads((prior_work / 'PUBLICATION-VERIFIED.json').read_text())
assert push['source_commit'] == prior_source['source_commit'] == source_commit
assert push['checkpoint_commit'] == push['remote_commit'] == stage['prior_checkpoint']
assert push['actual_push_terminal'] and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal'] and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
assert prior_source['publication_actual_session'] == prior_publication['actual_session'] == 73094
assert prior_publication['actual_terminal'] and prior_publication['actual_terminal_exit'] == 0
assert prior_publication['combined_reports'] == 520 and prior_publication['resource_reports_inherited'] == 264
verify(prior_archive / 'manifest.json', push['archive_manifest_sha256'])
subprocess.run(['git', 'merge-base', '--is-ancestor', push['checkpoint_commit'], 'HEAD'], cwd=root, check=True)
prior_checked = json.loads((prior_run / 'checked.json').read_text())
assert prior_checked['all_five_gates_passed'] and prior_checked['source_pins_unchanged']
assert (prior_checked['source_files'], prior_checked['independent_reports'], prior_checked['resource_and_component_probes']) == (6279, 321, 520)
for name, digest in json.loads((prior_run / 'source-pins.json').read_text()).items():
    historical(name, digest)
bound.update([prior_work / 'PUSH-VERIFIED.json', prior_work / 'SOURCE-COMMIT.json',
    prior_work / 'PUBLICATION-VERIFIED.json', prior_work / 'PUBLICATION-ACTUAL-RUN.json',
    prior_run / 'checked.json', prior_run / 'source-pins.json', prior_run / 'IndependentProbes.lean',
    prior_archive / 'manifest.json', prior_archive / 'verify.py', prior_archive / 'archived-inputs.json'])
# Preserve the actual failed run and every precompiler correction as rejected
# history. A generated sorryAx report never supplies inherited proof credit.
failed_receipt = json.loads((work / 'FIRST-CHECK-REJECTED.json').read_text())
assert failed_receipt['actual_session'] == 84470 and failed_receipt['actual_terminal_exit'] == 1
failed_run = base / failed_receipt['runtime']
failed = json.loads((failed_run / 'results.json').read_text())
assert not (failed_run / 'checked.json').exists() and not failed['proof_credit']
assert failed['checks'] == failed_receipt['checks']
for name, digest in json.loads((failed_run / 'source-pins.json').read_text()).items():
    historical(name, digest)
bound.update([work / 'FIRST-CHECK-REJECTED.json', failed_run / 'results.json', failed_run / 'source-pins.json'])
bound.update(failed_run / (item['name'] + '.txt') for item in failed['checks'])
raw_sources = {}
public = b''
private_count = 0
for item in components:
    original = chosen[item['module']]
    for key in ['module', 'kind', 'packet', 'manifest_sha256', 'source', 'raw_sha256', 'raw_bytes',
                'probe', 'probe_sha256', 'public_qnames', 'expected_axiom_reports', 'expected_declaration_checks']:
        assert item[key] == original[key], (item['module'], key)
    packet = base / item['packet']
    manifest = json.loads(verify(packet / 'MANIFEST.json', item['manifest_sha256']))
    for name, record in records(manifest['files']):
        verify(packet / name, record)
    for filename in ['SOURCE-PINS.json', 'ADDITIONAL-SOURCE-PINS.json', 'DEPENDENCY-PINS.json']:
        if (packet / filename).exists():
            for name, record in records(json.loads((packet / filename).read_text())):
                historical(name, record)
    raw = verify(root / item['source_path'], {'sha256': item['raw_sha256'], 'bytes': item['raw_bytes']})
    assert raw == (packet / item['source']).read_bytes()
    declarations = raw
    if item['kind'] == 'existing_owner_import_and_EOF':
        before = verify(root / item['old_snapshot'], {'sha256': item['owner_sha256'], 'bytes': item['owner_bytes']})
        prefix = verify(packet / item['imports'], item['imports_sha256'])
        declarations = verify(packet / item['append'], item['append_sha256'])
        assert len(before) == 23529 and len(prefix) == item['owner_offset'] == 61
        assert raw == prefix + before + declarations
    assert b'#print axioms ' not in raw and b'#check ' not in raw
    assert not re.search(rb'set_option\s+(maxHeartbeats|maxRecDepth|warningAsError|linter\.)', declarations)
    count = len(re.findall(rb'^private theorem ', declarations, re.M))
    assert count == item['new_private_helpers_transitive']
    private_count += count
    for header in item['headers']:
        data = verify(packet / header['file'], header['sha256'])
        start = raw.index(data.splitlines()[0])
        assert raw[start:raw.index(b':= by', start)].rstrip() == data.rstrip()
    probe = verify(packet / item['probe'], item['probe_sha256'])
    assert probe.count(b'#print axioms ') == item['expected_axiom_reports'] and b'#check ' not in probe
    private_run = base / next(subset['runtime'] for subset in subsets if item['module'] in subset['modules'])
    assert (private_run / 'source/MicroCFTA' / item['source']).read_bytes() == raw + b'\n' + probe
    bound.add(private_run / 'source/MicroCFTA' / item['source'])
    raw_sources[item['module']] = raw
    public += probe
assert private_count == 7 and public.count(b'#print axioms ') == 7
assert public == (work / 'PUBLIC-PROBES.lean.txt').read_bytes() == (control / 'EXPECTED-PUBLIC-PROBES.lean.txt').read_bytes()
imports = (work / 'IMPORTS.lean.txt').read_bytes()
assert imports == (control / 'EXPECTED-IMPORTS.lean.txt').read_bytes()
assert len(imports) == stage['audit_old_block_offset'] == 287 and imports.count(b'import ') == 4
old_audit = verify(root / overrides['lean/MicroCFTA/Audit.lean'], {'sha256': stage['old_audit_sha256'], 'bytes': stage['old_audit_bytes']})
assert len(old_audit) == 434278 and old_audit.count(b'#print axioms ') == 726
assert (root / 'lean/MicroCFTA/Audit.lean').read_bytes() == imports + old_audit + b'\n' + public
assert (root / 'lean/MicroCFTA/Audit.lean').read_bytes().count(b'#print axioms ') == 733
assert sum(line.startswith(b'import ') for line in (root / 'lean/MicroCFTA/Audit.lean').read_bytes().splitlines()) == 5283
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 321
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = sha((root / owner_name).read_bytes())
assert owner_sha == baseline[owner_name]
normal_objects = root / 'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()
# Recompute the combined transitive order at the actual staged bytes.
dag = json.loads((control / 'TOPOLOGICAL-ORDER.json').read_text())
edges = {}
visiting = set()
visited = set()
ordered = []

def walk(module):
    if module in visited:
        return
    assert module not in visiting, ('import cycle', module)
    visiting.add(module)
    data = (root / 'lean/MicroCFTA' / (module + '.lean')).read_text()
    edges[module] = re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$', data, re.M)
    if module not in chosen:
        assert (normal_objects / (module + '.olean')).is_file(), module
    for child in edges[module]:
        walk(child)
    visiting.remove(module)
    visited.add(module)
    ordered.append(module)

for module in stage['compile_order']:
    walk(module)
assert edges == dag['direct_imports']
assert [module for module in ordered if module in chosen] == stage['compile_order'] == dag['candidate_order']
for name in ['strict-bind.py.txt', 'publication-driver.py.txt', 'shadow-compile.py.txt']:
    ast.parse((control / name).read_text())
# Root executes the publication creation phase only after every preflight passes.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-source-worker-seeds-publication-'))
(objects / 'MicroCFTA').mkdir()
for dependency in normal_objects.glob('*.olean'):
    if dependency.stem not in chosen:
        (objects / 'MicroCFTA' / dependency.name).symlink_to(dependency)
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
for module, raw in raw_sources.items():
    path = runtime / 'source/MicroCFTA' / (module + '.lean')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    bound.add(path)
fresh_imports = ''.join('import MicroCFTA.' + module + '\n' for module in stage['compile_order']).encode()
(runtime / 'FreshPublicProbes.lean').write_bytes(fresh_imports + public)
(runtime / 'IndependentProbes.lean').write_bytes(imports + prior_independent + b'\n' + public)
for src, dst in [('strict-bind.py.txt', 'strict-new-and-bind.py'), ('publication-driver.py.txt', 'check.py'), ('shadow-compile.py.txt', 'shadow-compile.py')]:
    (runtime / dst).write_bytes((control / src).read_bytes())
(runtime / 'REPORT-BASE.json').write_bytes((control / 'REPORT-BASE.json').read_bytes())
inheritance = {'compile_order': stage['compile_order'], 'definition_names': [],
    'prior_checkpoint': push['checkpoint_commit'], 'prior_archive_manifest_sha256': push['archive_manifest_sha256'],
    'prior_checked_sha256': sha((prior_run / 'checked.json').read_bytes()),
    'prior_pins_sha256': sha((prior_run / 'source-pins.json').read_bytes()),
    'stage_sha256': sha(stage_bytes), 'baseline_sha256': sha(baseline_path.read_bytes()),
    'baseline_overrides': overrides,
    'override_digests': {name: sha((root / path).read_bytes()) for name, path in overrides.items()},
    'inherited_reports': 520, 'fresh_reports': 7, 'combined_reports': 527,
    'resource_owner_sha256': owner_sha, 'resource_owner_reports_inherited': 264,
    'owner_preflight_reports_fresh_this_batch': 0, 'new_private_helpers': 7,
    'Prop_declaration_checks': 0, 'Prop_axiom_credit': 0,
    'actual_private_sessions': [23742, 33636], 'fresh_owner_theorem_credit': 0, 'cache_data_copied': False}
(runtime / 'INHERITANCE-SELECTION.json').write_text(json.dumps(inheritance, indent=2) + '\n')
bound.update([Path(__file__), baseline_path, work / 'PUBLIC-PROBES.lean.txt', work / 'IMPORTS.lean.txt', control / 'TOPOLOGICAL-ORDER.json'])
bound.update(current)
bound.update(path for path in runtime.iterdir() if path.is_file())
(runtime / 'source-pins.json').write_text(json.dumps({str(path.relative_to(root)): sha(path.read_bytes()) for path in sorted(bound)}, indent=2, sort_keys=True) + '\n')
print(json.dumps({'runtime': str(runtime), 'gates': 5, 'strict_fresh_modules': 5,
    'fresh_public_reports': 7, 'definition_checks': 0, 'inherited_reports': 520,
    'combined_reports': 527, 'source_files': 6283, 'independent_reports': 328,
    'audit_reports': 733, 'objects': str(objects), 'normal_Source_changed': False}))
