# Source-only review

- The generator derives its sum and bounds from actual allocation membership.
- The strict decrease uses the actual parent total plus one.
- The original child-state order follows the allocation recursion.
- Each row retains the complete original label and Constraint value.
- The numeric filter tests the generated budget list and current source constraint.
- The synthetic root copies root rows. It does not add a constructor.
- Root sizes start at one. Nonpositive original bounds give no root rows.
- No future execution, completion, output, or native invariant is an input.
- The source Integer/minimum-table bridge remains explicit and unproved.
- The source rowOf-at-zero call-domain boundary remains explicit and unproved.
- The actual equalSizes, explore, mkFTA, trim, and native reifier are not modeled.
- All current draft claims require Root compilation and review before installation.
- No proof success or Haskell correspondence is claimed by this source-only task.
