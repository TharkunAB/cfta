# Original positive-size product rank proof scope

Started 2026-10-31 02:23 CET. SOURCE-ONLY. Root owns execution.
Draft the smallest source-aligned SourceSizedPrefixProductRank producer.
Derive child rank from generated original numeric allocations and rows.
Retain exact synthetic root, symbol, constraint, and child-state order.
No literal Haskell/fromFTA correspondence claim without those components.
No production edit, compiler, evaluator, Haskell/native run, Git, network,
board, or spawn. At most two named OLD whole/near-whole ORIGINAL paths.
No OLD whole is named yet. Other sources use exact named cuts/locators.
Coordinate numeric/source-product work with normal_lineage_review, who owns
fromRows/fromFTA/native structural transport. Preserve both workers, exact
configured policies, Unknown distinctions, and the full original-input goal.
