# Original size-product rank draft

The candidate derives strict child-budget decrease from generated numeric rows.
It does not accept a supplied sum equation or a supplied decrease predicate.
The candidate is SOURCE-ONLY and UNCOMPILED. Root must check it before use.
No compiler, evaluator, Haskell run, or native run was used for this task.

## Candidate

Use SourceSizedPrefixProductRank-v2-UNCOMPILED.lean.
It has 157 lines and 8633 bytes.
SHA256: 40326b095eddf260c6178537757b2b0cb9b8c8479654fa028f0ddf6620715d80.
V1 is retained. DRAFT-VERSIONS.md states the only V2 change.
Both versions have the same public headers.

The draft uses the existing SourceSizedDecided.Row. The Row retains the full
Constraint value. It does not replace Constraint by an evaluated predicate.
The draft also reuses SourceSizedCandidates.child_size_lt. Existing candidates
construct Term forests with reverse child traversal. That generator is not a
literal implementation of Prefix.bySize. The draft retains the public source
child order instead of reusing that different traversal.

## Generated facts

- allocations_spec reads membership in the actual local allocation generator.
  It derives original child-state order, exact consumed total, and child bounds.
- rowOf_origin reads membership in the generated and filtered row list.
  It derives source-row membership, original label and full constraint, original
  child-state order, and strict decrease from each child to the parent budget.
- rows_rank derives strict rank decrease for every generated edge child.
  It includes synthetic-root rows. The root copies source-root rows for sizes
  1 through the bound. It does not add a constructor to the generated tree.
- root_nonpositive gives an empty root row list for a nonpositive Integer bound.

The local allocation loop enumerates natural first budgets in ascending order.
It retains the actual minimum lookup and remaining-minimum-sum tests. Failed
lookups give no allocation. Recursion follows the original ordered child list.
The current equalSizes function filters actual allocations. The rank result
holds for every such filter, without a semantic assumption about that filter.

## Source alignment and exact limits

Prefix.hs lines 575 through 628 define the actual bySize construction.
The copied source SHA is 4acc51175aa2c84c1c54c188b2471d526dabb521db8208fbaf62522a9bca9a26.
Root previously compared this full source to current main
bd5a406a6a3f84b7e3ae0906082783911509df83 and to the live worktree.
ROOT-current-main-source-pins.json retains that exact scope. This task also
checked the current full source hash. Neither check executed Haskell.

The following bridges are NOT proved by the draft:

1. Ordinary.minimumSizes returns the natural minimum table used by the model.
   The Haskell code uses Integer. Its least-size algorithm is not modeled here.
2. The Haskell Integer interval [smallest .. total - sum others] equals the
   natural range/filter implementation under the original minimum-table facts.
   The draft does not claim literal interval or Haskell-expression equivalence.
3. The source direct-child equality-size filter implements the equalSizes
   parameter. The full original row constraint remains present in every row.
4. The Haskell explore function constructs the reachable finite table from these
   rows. The draft defines a row function. It does not model explore or mkFTA.
5. trim/fromFTA/fromRows produces ordinary native nodes with the derived rank.
   That source-to-native construction remains in the separate structural lane.

The source rowOf expression at size zero is not copied as an independent
Haskell equation. The source calls it at positive root sizes and at generated
child budgets from positive least sizes. The model defines rowOf at zero as [].
The minimum-table positivity and call-domain bridge remain part of item 1.
This boundary prevents a literal equivalence claim on arbitrary internal calls.

## Next construction step

First close the original minimum-table and Integer-allocation bridge. Then use
rows_rank to construct the reachable acyclic row graph and connect its retained
labels, constraints, and ordered children to actual fromRows native constructors.
Do not add a supplied native acyclicity fact as a replacement for this producer.
The separate structural lane owns that fromRows/fromFTA transport inventory.

This result does not select sufficient original recursive resources. It does
not prove completion of a requested public prefix, native semantic adequacy,
whole-worker execution, or Haskell correspondence. It does not replace configured
orders or stops, and it does not identify Unknown with an empty language.
The full original-input goal remains open for both workers and public adapters.
No Haskell defect or fix was established. FINDINGS needs no source-only defect entry.

## Acquisition scope

Seven acquisition records cover six original source paths. All are bounded
named cuts or declaration locators. Zero OLD whole or near-whole paths were used.
acquisitions.json retains exact source and copy metadata. cumulative-source-unions.json
retains every cumulative original-line union. ACQUISITION-VERIFICATION.json records
byte-exact cut checks and matching current full source hashes. All locator stderr
files and both draft versions are retained. No tool or acquisition failure occurred.
PRIOR-PRODUCTIVITY-* and metadata-reuses.json pin the frozen reuse provider.
