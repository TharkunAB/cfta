# Draft versions

V1 is retained unchanged. V2 changes only root_nonpositive's final simplifier
line. It uses the existing definition and zero equality without depending on
explicit library names for range-zero and flatMap-empty. All public headers
and mathematical statements are unchanged. No draft was compiled or evaluated.
