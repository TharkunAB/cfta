# Reviewer incidents

The first full-inventory helper verified all169 payload hashes, the complete171-file inventory, and payload byte count, then failed an overly strict permissions assertion. All provider files are read-only. Its root directory and cuts directory remain mode0775. The recovery checks file permissions and records writable directories separately. No provider file or mode was changed. This is metadata packaging scope, not a proof or source defect.

The provider separately retains its original locator truncations, import breadth, EOF-range correction, and basename-collision/hash recovery. Its original incidents and both earlier acquisition ledgers remain in the verified provider inventory. No incomplete reviewer source display has been counted as complete.

A metadata display of the provider union keys exceeded its output limit. It did not display source bodies. The complete JSON remains in provider-metadata. The final compact union table was read in full.

A combined source display of Enumeration.hs lines845–990 exceeded the available context. None of that combined display was used as full-read evidence. Recovery displayed each of the five retained chunks in a separate tool call:845–874,875–904,905–934,935–964,965–990. All five outputs were complete. The read ledger was marked complete only after this recovery.

The support helper recorded6534 bytes for the reused CapturedEdge source. The completion helper independently checked wc and confirmed the same6534 bytes. Both values remain in the ledger. No source metadata correction was needed.

The initial Root canonical note had167 lines. Root then corrected the carrier scope and the proposed construction height bound. Both source snapshots and their exact correction diff are retained. The corrected175-line note is the final reviewed version. The earlier note is a historical snapshot. It is not required to match the current production path.

The first permissions assertion failure and the two truncated displays were reported in tool output. No separate raw stderr or display-output file was saved. This bundle retains their incident descriptions and the repaired helper and complete recovery chunks. It does not claim to retain literal copies of those transient outputs.

The first sealing helper excluded files by basename. It also excluded provider-metadata/FROZEN-PINS.json from the payload list. The independent post-freeze exact-file-set assertion rejected that seal before handoff. The source and all acquisition checks had passed. The owner directory was reopened for this metadata repair. seal-v1-retained preserves both failed seal files and both exact helper versions. reproduced-check.log captures the same failing assertion. The repair excludes only the two ROOT metadata paths. The final seal includes all nested metadata and all retained failed-seal evidence. Source copies and source claims did not change.

The next seal attempt could not overwrite the read-only REVIEW-STATUS.json left by the first attempt. It stopped before it changed any seal metadata. The subsequent check still rejected the old invalid seal. seal-v2-retained preserves the exact helper and a reproduced PermissionError log. Recovery reopened only the three mutable ROOT seal metadata files, then generated the final inventory and checked it again. The provider and all source copies stayed unchanged.
