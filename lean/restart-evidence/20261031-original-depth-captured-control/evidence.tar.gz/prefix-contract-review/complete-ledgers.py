from pathlib import Path
import json,hashlib,subprocess,datetime
r=Path(__file__).parent;repo=Path('/home/tritlo/Code/mcfta');sha=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads((r/'old-source-cut-ledger.json').read_text());reads=json.loads((r/'read-ledger.json').read_text())
src=repo/'lean/MicroCFTA/SourcePruningEnumerationForecastPathDomain.lean';wc=subprocess.check_output(['wc','-lc',str(src)],text=True).split();h=subprocess.check_output(['sha256sum',str(src)],text=True).split()[0]
b=subprocess.check_output(['sed','-n','13,47p',str(src)]);rel='old-cuts/SourcePruningEnumerationForecastPathDomain.lean-L13-L47.txt';(r/rel).write_bytes(b)
old.append({'source_path':str(src),'source_lines':int(wc[0]),'source_bytes':int(wc[1]),'source_sha256':h,'actual':[13,47],'copy':rel,'copy_sha256':sha(b),'classification':'NEW named bounded OLD-source carrier definition cut','read_complete':True,'full_read_evidence':'Source body displayed in full as lines13-43 and44-47; no body display truncation.'})
for x in reads:x['read_complete']=True
for x in old:
 x['read_complete']=True
 if x['source_path'].endswith('/SourceCurrentAllocatedNativeStoredCapturedEdge.lean'):
  actual=int(subprocess.check_output(['wc','-c',x['source_path']],text=True).split()[0]);x['initial_helper_source_bytes']=x['source_bytes'];x['source_bytes']=actual
(r/'old-source-cut-ledger.json').write_text(json.dumps(old,indent=2)+'\n');(r/'read-ledger.json').write_text(json.dumps(reads,indent=2)+'\n')
locator={'source_path':str(src),'source_sha256':h,'source_lines':int(wc[0]),'line_vectors':[17,49,58,69],'kind':'retained exact four rg definition-locator lines; header-only acquisition counted by original source path'}
locb=b''.join(subprocess.check_output(['sed','-n',f'{n}p',str(src)]) for n in locator['line_vectors']);rel='old-cuts/ForecastPathDomain-definition-locators.txt';(r/rel).write_bytes(locb);locator.update(copy=rel,copy_sha256=sha(locb));
pref=repo/'cfta-generator/src/Data/CFTA/Sized/Prefix.hs';pb=subprocess.check_output(['sed','-n','153p',str(pref)]);rel='old-cuts/Prefix.hs-Ordinary-import-L153.txt';(r/rel).write_bytes(pb);locators=[locator,{'source_path':str(pref),'source_sha256':subprocess.check_output(['sha256sum',str(pref)],text=True).split()[0],'source_lines':1133,'line_vectors':[153],'kind':'previously read named alias locator: Ordinary is Gen.Internal.Table','copy':rel,'copy_sha256':sha(pb)}];(r/'locator-ledger.json').write_text(json.dumps(locators,indent=2)+'\n')
unions={}
for x in old:
 a=unions.setdefault(x['source_path'],{'source_sha256':x['source_sha256'],'source_lines':x['source_lines'],'ranges':[],'line_set':set(),'copies':[]});assert a['source_sha256']==x['source_sha256'];lo,hi=x['actual'];a['line_set'].update(range(lo,hi+1));a['copies'].append(x['copy'])
for x in locators:
 a=unions[x['source_path']];a['line_set'].update(x['line_vectors']);a['copies'].append(x['copy'])
for a in unions.values():
 lines=sorted(a.pop('line_set'));ranges=[]
 for n in lines:
  if ranges and n==ranges[-1][1]+1:ranges[-1][1]=n
  else:ranges.append([n,n])
 a['ranges']=ranges;a['covered_lines']=len(lines);a['coverage_fraction']=len(lines)/a['source_lines'];a['whole']=len(lines)==a['source_lines'];assert a['whole'] or a['coverage_fraction']<=0.5
assert sum(x['whole'] for x in unions.values())==2
(r/'CUMULATIVE-OLD-SOURCE-UNIONS.json').write_text(json.dumps(unions,indent=2)+'\n')
root=json.loads((r/'provider-metadata/Root-independent-main-source-pins.json').read_text());now=[]
for x in root:
 h=subprocess.check_output(['sha256sum',str(repo/x['path'])],text=True).split()[0];assert h==x['main_sha256']==x['current_sha256']==x['reviewer_sha256'];now.append({**x,'independent_review_current_sha256':h,'current_exact':True,'main_evidence':'Root supplied exact main blob comparison; no Git/network by reviewer'})
(r/'current-source-metadata-comparison.json').write_text(json.dumps(now,indent=2)+'\n')
current=repo/'lean/notes-current-original-depth-and-captured.md';assert subprocess.check_output(['sha256sum',str(current)],text=True).split()[0]=='af833b74a6ec7a235983fe12503646e490c153e2a94b8fead97a4580bac090b0'
print('OLD acquisitions',len(old),'source paths',len(unions),'covered original lines',sum(x['covered_lines'] for x in unions.values()),'wholes',sum(x['whole'] for x in unions.values()),'nonwhole max',max(x['coverage_fraction'] for x in unions.values() if not x['whole']))
print('Read-ledger complete chunks',len(reads),'lines',sum(x['actual'][1]-x['actual'][0]+1 for x in reads),'extra carrier lines',35)
for k,v in unions.items():print(Path(k).name,v['covered_lines'],v['source_lines'])
