from pathlib import Path
import json
import subprocess

r = Path('/tmp/mcfta-original-depth-and-captured-control-20261031')
repo = Path('/home/tritlo/Code/mcfta')
source = json.loads((r / 'source-commit.json').read_text())['head']
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M %Z'], text=True).strip()
canonical = 'lean/notes-current-original-depth-and-captured.md'
note = f'''# Current proof state: original size rank and captured edges

Updated {stamp}. Source commit {source}.
The full goal remains open.

## Full goal

Keep the original public inputs and the exact configured order and stops.
Prove sound output and the intended finite ordered prefix.
Derive sufficient resources from the ORIGINAL inputs.
Cover the optimized interned core and BOTH recursive workers.
Cover Prefix, table, count, checkpoint, and public adapters.
Prove the required Haskell correspondence.
Keep the constructor, equality, exact node-count, size-order, rank, and unrank work.
Do not replace this goal with a local cache law or a theorem count.

## Strongest closed worker statement

SourcePruningEnumerationExecutionOriginalPaths.Native.run_original_finite_complete_resources_paths
and the corresponding Prepared theorem apply at every supplied finite recursive depth.
Under their current original input and resource gates, they construct stable actual outcomes.
Actual paths and exact forecasts stay in one finite original carrier.
That carrier does not depend on the supplied recursive depth.
The original normalized-literal and seed-inclusion gates remain explicit.
The current Packet, Fits, Heap, edge-selection, mass, and reservation gates remain explicit.
The observed outcome can still exhaust or stop without the intended accepted prefix.

SourcePruningEnumerationConstructedResources.native_run and prepared_run already
construct the original packet, heap, cache, reservation, and mathematical width
for EACH supplied depth, under their stated gates.
Width existence at a chosen depth is therefore available.
These results do not choose a depth that produces the intended prefix.

PreparedFiniteOutputPrefix gives List.IsPrefix between actual hook-output lists
at two independently admitted depths.
It does not identify either list with an original declarative requested prefix.
Operational completion can retain metadata for an intentional stop.

## Existing bounded public reference target

SourceSizedQueries.through concatenates exact size classes through the original bound.
SourceSizedReferenceAPI.through_exact identifies membership with original
acceptance and nodeSize at most that bound.
through_complete gives eventual membership of each accepted finite term.
SourceSizedPublicContracts has the corresponding reference-API results.
Its finite_class result supplies finite ClassEvaluation by decreasing size.
Its preprocessing and ActiveOption gates remain explicit.
This reference API has no native root or fromFTA transport in its public signature.

Public Sized.Prefix requests completions of a preorder-token prefix within a node bound.
It retains size order and then language order.
Its table and strict-size reference routes differ from the guarded equality walk.
The guarded walk uses bySize, trim, fromFTA, and token restriction before enumeration.
Yes, No, and Unknown solver verdicts retain their distinct meanings.
Finite candidate sets alone do not prove termination of arbitrary solver callbacks.

## Concrete next construction proof

Current Prefix.bySize pairs an original state with an exact positive node budget.
Each generated row gives its children budgets that sum to the parent budget minus one.
Each child budget is therefore strictly below its parent budget.
The synthetic root covers original root sizes through the supplied bound.
This construction provides an original size rank.

Current Interned.fromFTA delegates to fromRows.
fromRows computes strongly connected components.
It emits Rec for a bound child in the same component.
It creates Mu only when the reference occurs.
It constructs ordinary bodies with mkNode.
A strict original row rank should exclude those Rec and Mu cases.
The literal bySize/fromRows model and its native construction proof remain open.
The next producer must derive available, closed native inputs in
SourceCurrentAllocatedFiniteOrdinaryDomain.Node, with height bounded by the original size.
It must preserve actual symbols, constraints, child order, and synthetic-root behavior.
Finite denotation alone does not establish this native structural predicate.
The generic nested Syntax interface can contain Mu, Union, and opaque field pools.
This size route does not silently restrict that generic interface.

After construction, prove progress through actual same-slot renewals and incoming writes.
Cover both the parked restart and the Left-callback recursive continuation.
Sibling continuations restore the captured enumeration cache and thread native endpoints.
Consecutive row-filter bounds do not count an entire history with those restorations.
Derive a sufficient original depth, then identify actual worker outputs with the
policy-permitted reference list through the real adapters.
Do not admit a future successful output, depth, Trace, Paths, or Complete supplier.

## Separate policy and cost questions

Worker order is a dependency-safe slot preference.
An absent or invalid hint falls back to an offered variable.
Restart.decision returns None only for its explicit stop condition.
A Root note that attributed that None case to the preference was corrected.
The exact source cut and correction remain in the evidence.

Custom cost-priority extraction is a separate API.
An accepted first prefix can exist despite infinitely many cheaper rejected raw jobs.
The archived lexicographic example is a current-source candidate for a queue proof.
It is an existing documented limit, not a new executed nontermination result.
An original finite-sublevel condition on partial row derivations addresses that limit.
It also requires terminating local work and the actual callback contracts.
It does not refute the bounded Prefix route or worker slot selection.

## New checked captured-edge law

SourceCurrentAllocatedNativeStoredCapturedEdge has one public theorem in 108 lines.
captured_edge_native_stored concerns the literal CapturedEdge.run observation.
It keeps the current captured-edge resource admission and entry Stored certificate.
It derives parent availability and closure from PendingRealized and the decoded slot.
It derives suspension bounds from Ready and the supported reservation from edgeCost.
It composes the actual SelectedEdge certificate.
Successful finalization retains the exact reached caller.

Rejected, stopped, and complete results preserve Stored at their exposed callers.
None and unhandled give True and establish no hidden-state fact.
Failed finalization can discard a caller that the selected edge reached.
Stored is conditional: empty-seen requests with two finite ordinary inputs return
a finite ordinary node or edge payload whose height is bounded by both inputs.
It does not assert result semantics, every active cell, or constructor normality.
It does not prove a whole-worker depth bound or public Haskell correspondence.

Two retained proof failures concerned finalizer reduction.
The repairs add dsimp before the finalizer split and Option.map_some afterward.
All public headers are exact across the repaired versions.
Installation removes only the 71-byte status line.
Root and an independent reviewer read all 108 source lines and all 63 public lines.
The reviewer also read all repairs and both failed logs.

## Verification

Eight serial capped compiler commands completed: six passed and two failed before repair.
All 13 source snapshots and all full raw logs remain in the evidence.
The effective memory.max and memory.high were 4294967296 bytes; swap.max was zero.
Focused default and strict checks passed after repair.
Full Audit default and strict checks passed: 4765 jobs and 83090 dependencies.
Public readback passed: 1231 checks and 118 definition prints.
The new axiom report uses only propext, Classical.choice, and Quot.sound.
The full public output has 4938741 bytes.
Its SHA-256 is 4e366af0b65657c931627b5976f97505172d5c8e82e6619d626cf4e4b35b660c.
The full prior 4934281-byte output is an exact prefix.
The new 4460-byte, 63-line tail has SHA-256
29637a921f8758e06f435634d885e4122fd882f91aa57e91edeabd58923167d8.
All 565 old protected files and all 835 native inputs are exact.
All 4764 old Lean files are exact except the one Audit import prefix.
The final source set has 566 protected files and 4765 Lean files.
The three prior root documents remain complete exact suffixes.

## Haskell findings and restart evidence

No Haskell file changed. No Haskell or native program ran in this phase.
No new executable defect or fix was established.
The custom-cost record remains a source-review candidate for an existing progress limit.
Keep all older conditional Haskell findings and fixes in the retained FINDINGS suffix.
Root compared the acquired Tree, EGraph, and Sized.Prefix bytes against exact main
bd5a406a6a3f84b7e3ae0906082783911509df83 and the current checkout; all three match.

The complete source-only inventories and independent reviews remain in the evidence.
They do not certify a closed original-depth producer.
The original capacity report is historical; its old Paths/Complete gap is superseded
by the closed paired whole-worker theorems stated above.
Private report providers are retained in full for exact portable reuse checks.
Metadata schema repairs, truncated diagnostics, locator repairs, and the policy
correction remain in the complete logs and incident records.

Control root: /tmp/mcfta-original-depth-and-captured-control-20261031.
Restart package: lean/restart-evidence/20261031-original-depth-captured-control.
Resume from the original size-product producer, then native construction and worker progress.
The complete goal remains open. No pause or completion is requested.
'''
prefix = f'''# Current checkpoint: original size rank and captured edges

Updated {stamp}. Source {source}.
Canonical current note: [{canonical}]({canonical}).
The complete earlier document remains below as an exact suffix.

The strongest closed BOTH-worker result stabilizes actual outcomes at each
supplied finite depth and keeps paths and forecasts in one finite original carrier.
Current original input and resource gates remain explicit. Exhaustion is possible.
ConstructedResources already computes mathematical width at each supplied depth.
The missing producer must derive sufficient original depth and intended prefix output.
Cross-depth List.IsPrefix alone is not that production theorem.

The bounded public reference target already has exactness, completeness, and finite
size evaluation. Public preorder-token Prefix also retains the token restriction.
The next construction route is concrete: bySize gives positive decreasing child
budgets; fromRows introduces Rec/Mu only for cyclic components.
Prove the actual original size rank, then transport it through native construction.
No literal bySize/fromRows-to-native proof is claimed yet.
The generic Mu/Union/opaque-field interface remains part of the full goal.

The new captured-edge law derives current parent admission from the actual stored
slot and preserves conditional native Stored at exposed rejected/stopped/complete callers.
None and unhandled establish no hidden-state fact.
This is one checked local law; it does not close whole-worker progress.

Audit passed at 4765 jobs and 83090 dependencies.
Public readback passed at 1231 checks and 118 definition prints.
Eight compiler commands: six passes, two retained repaired failures, 13 snapshots.
Root and peer fully read 108 installed source lines and 63 new public lines.
All 565 prior protected files and 835 native inputs are exact.
The old 4764 Lean files are exact except the new Audit import.
The full prior public output remains an exact prefix.
The complete current note records hashes, resource limits, gates, and repairs.

Haskell: no file changed and no Haskell/native program ran.
No new executable defect or fix was established.
The custom-cost candidate is an existing source-grounded progress limit.
It concerns cost extraction, not safe worker hints or bounded Prefix.
All older conditional FINDINGS and fixes remain below without omission.
The acquired current Tree/EGraph/Prefix bytes match exact main bd5a406a and this checkout.

Worker hints fall back to an offered variable when absent or invalid.
Only the explicit stop rule gives Restart.decision None.
A contrary Root note was corrected and retained with its source evidence.
Keep configured stops, ordering, pruning, and Yes/No/Unknown meanings in the target.
Do not replace original admission with a future successful history or output witness.

Control root: /tmp/mcfta-original-depth-and-captured-control-20261031.
Restart package: lean/restart-evidence/20261031-original-depth-captured-control.
The full original-input/BOTH-worker/public-adapter/Haskell goal remains open.

---

'''
(repo / canonical).write_text(note)
for name in ['NEXT-PROMPT.md', 'HANDOFF.md', 'FINDINGS.md']:
    (repo / name).write_bytes(prefix.encode() + (r / 'prior-documents' / name).read_bytes())
(r / 'canonical-note.md').write_text(note)
(r / 'root-document-prefix.md').write_text(prefix)
print(json.dumps({'canonical_lines': len(note.splitlines()), 'prefix_lines': len(prefix.splitlines())}))
