from pathlib import Path
import ast
import hashlib
import json
import re
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
control = base / '20261117-warm-full-admission-identity-publication-control-draft'
work = base / '20261117-warm-full-admission-identity-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this controller.'
archive_control = base / '20261117-warm-full-admission-identity-checkpoint-control-draft'
assert Path(__file__).read_bytes() == (archive_control / 'prepare-checkpoint-controls.py').read_bytes()
runtime = base / '20261117-warm-full-admission-identity-publication'
assert runtime.is_dir(), 'The checked publication must exist.'
prior_run = base / '20261117-warm-no-new-mu-publication'
prior_archive = base / '20261117-warm-no-new-mu-checkpoint'
prior_commit = 'c47d33f99209d27192a023bf2a9a0109f168333c'
prior_manifest = 'b87ed29f0b96f314296acb2feecef18c4fad53b5620859e391f4724582bf4462'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
bound = set()


def verify(path, record):
    data = path.read_bytes()
    digest = record['sha256'] if isinstance(record, dict) else record
    assert sha(data) == digest, str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data


def items(value):
    if isinstance(value, dict):
        return list(value.items())
    return [(item['path'], item) for item in value]


def manifest_records(manifest):
    if 'artifacts' in manifest:
        return [(item['path'], item) for item in manifest['artifacts']]
    return items(manifest['files'])


for name, record in json.loads((control / 'MANIFEST.json').read_text())['files'].items():
    verify(control / name, record)
bound.add(control / 'MANIFEST.json')
staging_control = base / '20261117-warm-full-admission-identity-staging-control-draft'
verify(staging_control / 'MANIFEST.json', '63d6044ec896042277a09d7366921936684063940cf4bad57b79664b65e7ea9d')
for name, record in json.loads((staging_control / 'MANIFEST.json').read_text())['files'].items():
    verify(staging_control / name, record)
for name, record in json.loads((staging_control / 'SOURCE-PINS.json').read_text()).items():
    verify(root / name, record)
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage = json.loads(stage_path.read_text())
assert stage == json.loads((control / 'EXPECTED-STAGE.json').read_text())
assert stage['prior_checkpoint'] == prior_commit
expected = stage['components']
overrides = {audit_name: str((work / 'Audit-BEFORE.lean.txt').relative_to(root))}
overrides.update({item['source_path']: item['old_snapshot'] for item in expected})
assert stage['baseline_overrides'] == overrides
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'],
        stage['independent_reports']) == (6267, 5267, 702, 297)
assert (stage['new_modules'], stage['new_public_theorems'], stage['new_private_helpers'],
        stage['new_theorem_declarations'], stage['new_prop_definitions']) == (0, 4, 1, 5, 0)
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (4, 492, 496)
baseline_path = work / 'baseline-source-pins.json'
baseline = json.loads(baseline_path.read_text())
assert len(baseline) == 6267 and len(expected) == 2
new_names = {item['source_path'] for item in expected}
assert len(new_names) == 2 and new_names.issubset(baseline)
current = sorted((root / 'lean/MicroCFTA').glob('*.lean'))
assert {str(path.relative_to(root)) for path in current} == set(baseline)


def prior_bytes(name):
    path = root / overrides.get(name, name)
    bound.add(path)
    return path.read_bytes()


def verify_prior_pins(path):
    bound.add(path)
    for name, record in items(json.loads(path.read_text())):
        data = prior_bytes(name)
        digest = record['sha256'] if isinstance(record, dict) else record
        assert sha(data) == digest, name
        if isinstance(record, dict) and 'bytes' in record:
            assert len(data) == record['bytes'], name


for name, digest in baseline.items():
    assert sha(prior_bytes(name)) == digest, name
assert len(set(baseline) - set(overrides)) == 6264
old_audit = prior_bytes(audit_name)
assert len(old_audit) == stage['old_audit_bytes'] == 430100
assert sha(old_audit) == stage['old_audit_sha256']
assert old_audit.count(b'#print axioms ') == 698
verify(root / owner_name, owner_sha)
prior = json.loads((prior_run / 'checked.json').read_text())
assert (prior['source_files'], prior['independent_reports'],
        prior['resource_and_component_probes']) == (6267, 293, 492)
assert len(prior['checks']) == 5 and all(item['exit'] == 0 and not item['diagnostics']
    and not item['sorryAx'] and not item['nonstandard_axioms'] for item in prior['checks'])
verify(prior_archive / 'manifest.json', prior_manifest)
verify_prior_pins(prior_run / 'source-pins.json')
bound.add(prior_run / 'checked.json')
def verify_candidate_pin(name, record):
    data = prior_bytes(name)
    digest = record['sha256'] if isinstance(record, dict) else record
    assert sha(data) == digest, name
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], name


review_packet = base / '20261117-warm-full-admission-identity-independent-review'
verify(review_packet / 'MANIFEST.json', '1012d1ff67fafdba799aa7c9e9a98db3b5baf203f97a477f96f67dd4a1402418')
for name, record in manifest_records(json.loads((review_packet / 'MANIFEST.json').read_text())):
    verify(review_packet / name, record)
for name, record in items(json.loads((review_packet / 'SOURCE-PINS.json').read_text())):
    verify_candidate_pin(name, record)


private_control = base / '20261117-warm-full-admission-identity-check-control-draft'
selected = json.loads((private_control / 'SELECTION.json').read_text())
private_run = base / selected['runtime']
assert stage['private_run'] == selected['runtime']
checked_path = private_run / 'checked.json'
checked = json.loads(checked_path.read_text())
receipt_path = work / 'PRIVATE-CHECK-VERIFIED.json'
receipt = json.loads(receipt_path.read_text())
assert receipt['actual_session'] == 72836 and receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
assert receipt['checks'] == checked['checks'] and checked['two_owners_checked']
assert len(checked['checks']) == 2 and all(checked['passed'])
assert checked['actual_public_axiom_reports'] == 4 and checked['actual_definition_declaration_checks'] == 0
assert checked['all_four_selected_first_headers_exact']
assert checked['new_private_helpers_compiled_transitively'] == 1
assert checked['fresh_credit_for_old_owner_theorems'] == 0
assert checked['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
verify_prior_pins(private_run / 'source-pins.json')
bound.update([checked_path, private_run / 'results.json', receipt_path])
for item in checked['checks']:
    bound.add(private_run / (item['name'] + '.txt'))
seen = set()
normal_sources = []
probes = []
public_names = []
definition_names = []
for item, chosen in zip(expected, selected['components']):
    for key, value in chosen.items():
        assert item[key] == value, (item['module'], key)
    packet = base / item['packet']
    manifest_path = packet / 'MANIFEST.json'
    verify(manifest_path, item['manifest_sha256'])
    if packet not in seen:
        seen.add(packet)
        for name, record in manifest_records(json.loads(manifest_path.read_text())):
            verify(packet / name, record)
        for pin_file in ['SOURCE-PINS.json', 'ADDITIONAL-SOURCE-PINS.json']:
            if (packet / pin_file).exists():
                for name, record in items(json.loads((packet / pin_file).read_text())):
                    verify_candidate_pin(name, record)
        if (packet / 'DEPENDENCY-PINS.json').exists():
            for name, record in items(json.loads((packet / 'DEPENDENCY-PINS.json').read_text())):
                verify(root / name, record)
                if isinstance(record, dict) and 'packet_manifest_sha256' in record:
                    verify((root / name).parent / 'MANIFEST.json', record['packet_manifest_sha256'])
        if (packet / 'FAILURE-PINS.json').exists():
            for record in json.loads((packet / 'FAILURE-PINS.json').read_text())['artifacts']:
                verify(root / record['path'], record)
    raw = verify(packet / item['source'], item['raw_sha256'])
    assert raw == (root / item['source_path']).read_bytes() and len(raw) == item['raw_bytes']
    before = (root / item['old_snapshot']).read_bytes()
    assert len(before) == item['old_bytes'] and sha(before) == item['old_sha256']
    assert item['old_snapshot'] == overrides[item['source_path']]
    appended = verify(packet / item['append'], item['append_sha256'])
    assert raw == before + appended and item['append_offset'] == len(before)
    for header in item['headers']:
        data = verify(packet / header['file'], header['sha256'])
        assert data.rstrip(b'\n') in appended
    probe = verify(packet / item['probe'], item['probe_sha256'])
    assert (private_run / 'source/MicroCFTA' / (item['module'] + '.lean')).read_bytes() == raw + b'\n' + probe
    assert re.findall(r'^private theorem (\w+)', appended.decode(), re.M) == item['new_private_helper_names']
    assert re.findall(r'^private def (\w+)', appended.decode(), re.M) == item['new_private_prop_names']
    assert re.findall(r'^#print axioms (\S+)', probe.decode(), re.M) == item['names']
    assert probe.count(b'#print axioms ') == item['expected_axiom_reports']
    assert probe.count(b'#check ') == item['expected_declaration_checks']
    normal_sources.append(raw)
    probes.append(probe)
    public_names.extend(item['names'])
assert len(public_names) == len(set(public_names)) == 4 and not definition_names
assert sum(len(item['new_private_helper_names']) for item in expected) == 1
assert sum(len(item['new_private_prop_names']) for item in expected) == 0
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
imports = (work / 'IMPORTS.lean.txt').read_bytes()
assert public == b''.join(probes)
assert imports == b'' and stage['old_audit_exact_offset'] == 0
assert (root / audit_name).read_bytes() == imports + old_audit + b'\n' + public
assert sum(line.startswith(b'import ') for line in (root / audit_name).read_bytes().splitlines()) == 5267
assert (root / audit_name).read_bytes().count(b'#print axioms ') == 702
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 293
for item in expected:
    assert ('import MicroCFTA.' + item['module'] + '\n').encode() in prior_independent
for name in ['strict-bind.py.txt', 'publication-driver.py.txt', 'shadow-compile.py.txt']:
    ast.parse((control / name).read_text())
normal_objects = root / 'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()

# Only Root executes the archive and Git checks below after review.
import gzip
import subprocess

ROOT = root
BASE = base
WORK = work
PUBLIC = runtime
ARCHIVE = '20261117-warm-full-admission-identity-checkpoint'
BOARD_PREFIX = 'current-board-warm-admission-identity-'
read = lambda path: json.loads(path.read_text())
GIT = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
for name, record in read(archive_control / 'MANIFEST.json')['files'].items():
    verify(archive_control / name, record)
for name, record in read(archive_control / 'SOURCE-PINS.json').items():
    verify(ROOT / name, record)
bindings = read(WORK / 'prior-bindings.json')
assert bindings['prior_checkpoint'] == prior_commit
commit = read(WORK / 'SOURCE-COMMIT.json')
code = commit['source_commit']
assert re.fullmatch('[0-9a-f]{40}', code)
assert commit['parent'] == prior_commit and commit['actual_terminal'] and commit['actual_terminal_exit'] == 0
assert not commit['joint_finite_completion_proved'] and not commit['haskell_changed']
assert commit['private_actual_session'] == 72836 and commit['publication_actual_session'] == 54013
assert commit['all_four_original_first_headers_exact'] and commit['old_owner_prefixes_byte_exact']
assert GIT('rev-parse', 'HEAD').decode().strip() == code
assert GIT('rev-parse', code + '^').decode().strip() == prior_commit
assert GIT('branch', '--show-current').decode().strip() == 'formalize'
assert not GIT('status', '--porcelain', '--untracked-files=no')
changed = new_names | {audit_name}
assert len(changed) == 3 and set(commit['files']) == changed
assert set(GIT('diff', '--name-only', prior_commit, code).decode().splitlines()) == changed
for name in changed:
    assert GIT('show', code + ':' + name) == (ROOT / name).read_bytes(), name
    assert GIT('show', prior_commit + ':' + name) == prior_bytes(name), name
# Check all three documents before any archive output. Finalize repeats this check.
for name in ['NEXT-PROMPT.md', 'HANDOFF.md', 'FINDINGS.md']:
    assert (ROOT / name).read_bytes() == GIT('show', code + ':' + name), name
source_control = BASE / '20261117-warm-full-admission-identity-source-commit-control-draft'
verify(source_control / 'MANIFEST.json', 'd18541c2d6cd8d4a0208ce078c5acaa28c66c24d49fb97aabc5077dd7cec32dc')
for name, record in read(source_control / 'MANIFEST.json')['files'].items():
    verify(source_control / name, record)
report = read(PUBLIC / 'checked.json')
verified = read(WORK / 'PUBLICATION-VERIFIED.json')
assert verified['actual_session'] == 54013 and verified['actual_terminal'] and verified['actual_terminal_exit'] == 0
assert verified['checks'] == report['checks']
assert [c['total_axiom_reports'] for c in report['checks']] == [702, 4, 297, 702, 702]
assert [(c['axiom_groups'], c['axiom_free_reports']) for c in report['checks']] == [
    (696, 6), (4, 0), (294, 3), (696, 6), (696, 6)]
assert all(c['declaration_checks'] == 0 for c in report['checks'])
assert all(c['exit'] == 0 and not c['diagnostics'] and not c['nonstandard_axioms'] and not c['sorryAx'] for c in report['checks'])
for name, value in {'source_files': 6267, 'direct_audit_imports': 5267,
        'individual_reports': 702, 'independent_reports': 297,
        'fresh_resource_component_reports': 4, 'inherited_resource_component_reports': 492,
        'resource_and_component_probes': 496, 'new_modules': 0, 'changed_existing_owners': 2,
        'new_public_theorems': 4, 'new_private_helpers': 1, 'new_private_theorems': 1,
        'new_private_predicates': 0, 'new_theorem_declarations': 5,
        'new_prop_definitions': 0, 'new_definition_declaration_checks': 0,
        'actual_publication_strict_reports': 4, 'new_private_component_reports': 0,
        'fresh_owner_preflight_reports': 0, 'replaced_old_reports': 0,
        'old_source_files_byte_exact': 6264, 'old_audit_exact_offset': 0,
        'audited_theorems': 100101, 'fresh_credit_for_old_owner_theorems': 0}.items():
    assert report[name] == value, name
for name in ['all_four_original_first_headers_exact', 'both_old_owner_prefixes_byte_exact',
        'all_new_formal_proof_checks_first_pass', 'first_check_passed_without_repair',
        'full_call_admission_exports_checked', 'interposed_entry_identity_exports_checked',
        'full_node_and_edge_call_admission_exports_proved', 'interposed_query_entry_identity_proved',
        'past_start_inventory_remains_explicit', 'existing_next_warm_NoNewMu_scope_unchanged',
        'historical_pins_use_exact_before_snapshots', 'current_public_pins_use_new_source_bytes',
        'prior_and_private_source_pins_use_both_owner_before_snapshots_and_Audit',
        'all_old_non_audit_non_appended_owner_source_byte_exact',
        'all_old_proof_bodies_and_limits_unchanged', 'new_append_bodies_unchanged_for_checks']:
    assert report[name], name
for name in ['private_helpers_counted_as_explicit_fresh_reports',
        'owner_recompiled_in_publication_strict_gate', 'all_six_cache_meanings_proved',
        'arbitrary_independent_warm_query_sequence_proved', 'every_warm_worker_call_qualification_proved',
        'all_native_inhabitance_proved', 'source_type_marker_class_consistency_proved',
        'joint_finite_completion_proved', 'compiled_haskell_correspondence_proved', 'haskell_changed']:
    assert not report[name], name
assert report['inherited_owner_preflight_evidence']['reports'] == 264
assert report['inherited_owner_preflight_evidence']['included_in_inherited_492']
assert report['baseline_overrides'] == overrides
assert report['owner_base_bytes'] == [133275, 51610]
assert report['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
pins = read(PUBLIC / 'source-pins.json')
for name, digest in pins.items():
    assert sha((ROOT / name).read_bytes()) == digest, name
assert verified['pins_independently_reverified'] == len(pins) == 6872
source_pins = {name: digest for name, digest in pins.items()
    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
assert len(source_pins) == 6267 and set(source_pins) == set(baseline)
prior_path = BASE / bindings['prior_archive']
for name, key in [('manifest.json', 'prior_manifest_sha256'), ('checkpoint.json', 'prior_checkpoint_json_sha256')]:
    data = (prior_path / name).read_bytes()
    assert sha(data) == bindings[key]
    assert GIT('show', prior_commit + ':' + str((prior_path / name).relative_to(ROOT))) == data
old_checkpoint = read(prior_path / 'checkpoint.json')
assert old_checkpoint['resource_and_component_probes'] == 492
assert old_checkpoint['checked_code'] == bindings['prior_source_commit']
assert old_checkpoint['checked_code'] == GIT('rev-parse', prior_commit + '^').decode().strip()
prior_files = {item['path']: item for item in read(prior_path / 'manifest.json')['files']}
for name in ['source-pins.json.gz', 'verification.json', 'archived-inputs.json']:
    data = (prior_path / name).read_bytes()
    assert len(data) == prior_files[name]['bytes'] and sha(data) == prior_files[name]['sha256']
    assert GIT('show', prior_commit + ':' + str((prior_path / name).relative_to(ROOT))) == data
old_pins = json.loads(gzip.decompress((prior_path / 'source-pins.json.gz').read_bytes()))
assert baseline == {name: digest for name, digest in old_pins.items()
    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
for name, digest in old_pins.items():
    assert sha(prior_bytes(name)) == digest, name
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    assert old_pins[name] == pins[name], name
request = read(WORK / (BOARD_PREFIX + 'request.json'))
canonical = read(WORK / (BOARD_PREFIX + 'canonical.json'))
assert canonical['verified']
post = canonical.get('post', canonical)
assert post['id'] == request['request_id'] == 'bc7f3c7e-bd7c-4c65-9ff1-b61df67b85ec'
assert post['sequence'] == 1511
for key, value in [('author', request['username']), ('thread_id', request['thread_id']),
        ('post_type', request['post_type']), ('content', request['content']), ('metadata', request['metadata'])]:
    assert post[key] == value, key
assert post['metadata']['source'] == code
cleanup = read(WORK / 'combined-terminal-cleanup-result.json')
preview = read(WORK / 'TMP-CLEANUP-PREVIEW.json')
assert cleanup['all_owned_terminal_only'] and cleanup['all_current_batch_actual_runs_terminal']
assert cleanup['unknown_tmp_entries_preserved'] and cleanup['normal_lake_symlink_targets_preserved']
assert not cleanup['symlink_target_bytes_counted'] and not cleanup['live_process_references']
paths = [item['path'] for item in cleanup['removed_targets']]
assert len(paths) == len(set(paths)) == 2
assert all(not Path(path).exists() and not Path(path).is_symlink() for path in paths)
actual_runs = [(72836, '20261117-warm-full-admission-identity-two-owner-check'),
    (54013, '20261117-warm-full-admission-identity-publication')]
for item, (session, run) in zip(cleanup['removed_targets'], actual_runs):
    assert item['actual_session'] == session and item['run'] == run
    assert item['path'] == read(BASE / run / 'objects.json')['path']
    assert not item['symlink_target_bytes_counted']
assert cleanup['removed_targets'] == preview['owned_terminal_targets']
assert preview['all_actual_runs_terminal'] and preview['terminal_sessions'] == [72836, 54013]
assert cleanup['removed_bytes'] == sum(item['bytes'] for item in cleanup['removed_targets']) == 14189984
assert cleanup['removed_symlinks'] == sum(item['symlinks'] for item in cleanup['removed_targets']) == 12598
assert cleanup['prior_cumulative_removed_bytes'] == 6463148813
assert cleanup['prior_cumulative_removed_bytes'] + cleanup['removed_bytes'] == cleanup['cumulative_removed_bytes'] == 6477338797
assert cleanup['tmp_readable_regular_file_bytes_after'] == 5847315235
assert len(cleanup['tmp_census_errors']) == 6
other_tmp = read(WORK / 'TMP-OTHER-DATA-AUDIT.json')
assert other_tmp['at'] > cleanup['at']
assert other_tmp['readable_regular_bytes'] == 5854147268 and len(other_tmp['errors']) == 7
assert other_tmp['unknown_or_other_build_data_preserved']
start = read(WORK / 'START.json')
resume = read(WORK / 'RESUME-AUTHORIZATION.json')
assert start['manual_work_explicitly_authorized'] and start['usage_pause_lifted']
assert start['persistent_goal_control_status'] == 'paused'
assert not start['joint_finite_completion_proved']
assert resume['user_instruction'] == "Keep going. We'll use a reset if needed."
assert resume['user_explicitly_resumed'] and resume['earlier_usage_pause_lifted'] and resume['work_authorized']
assert resume['persistent_goal_control_at_resume'] == 'paused' and resume['no_goal_resume_operation_available']
usage = read(WORK / 'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int, float] and 0 <= percent <= 100
assert usage['earlier_usage_pause_lifted_by_user_resume']
assert usage['current_usage_not_measured'] and usage['historical_snapshot_copied_at'] > usage['checked_at']
assert usage['snapshot_source'] == 'lean/restart-evidence/20261117-warm-no-new-mu-work/USAGE.json'
assert '17:53:' in usage['checked_at'] and percent == 81
roots = read(WORK / 'selection-roots.json')
assert len(roots) == len(set(roots)) == 11
assert source_control.name in roots
additional = read(WORK / 'archive-additional-roots.json')
assert len(additional) == 4
for item in additional:
    assert re.fullmatch(r'20261117-[a-z0-9-]+', item['root'])
    assert item['manifest'] == 'MANIFEST.json' and item['current_batch_theorem_credit'] == 0
    packet = BASE / item['root']
    manifest = read(packet / 'MANIFEST.json')
    verify(packet / 'MANIFEST.json', item['sha256'])
    for name, record in manifest_records(manifest):
        verify(packet / name, record)
    assert not item['private_runtime_selected']
    if item['kind'] == 'future_proof_candidate':
        assert 'UNCOMPILED' in manifest['status']
    else:
        assert item['kind'] == 'source_grounded_open_plan'
        assert not manifest['proofWritten'] and not manifest['compilerRun']
    roots.append(item['root'])
assert len(roots) == len(set(roots)) == 15
assert all((BASE / name).is_dir() and not (BASE / name).is_symlink() for name in roots)
# Work55 and all other future private checks are deliberately outside this selection.
assert not any('third-query-node-initial-work' in name or 'third-query' in name and name not in {
    '20261117-third-query-six-seed-bridge-plan', '20261117-third-query-node-seed-proof-draft'} for name in roots)
for name in roots:
    run = BASE / name
    if (run / 'check.py').exists():
        result = read(run / ('checked.json' if (run / 'checked.json').exists() else 'results.json'))
        assert result['checks'] and all(type(item['exit']) is int for item in result['checks']), name
for item in read(WORK / 'original-header-files.json'):
    assert sha((ROOT / item['path']).read_bytes()) == item['sha256']
    assert sha((ROOT / item['original']).read_bytes()) == item['sha256']
selected_roots = sorted(str((BASE / name).relative_to(ROOT)) for name in roots)
assert not (BASE / ARCHIVE).exists()
tree = hashlib.sha256()
for name, digest in sorted(source_pins.items()):
    tree.update(name.encode() + b'\0' + digest.encode() + b'\n')
config = dict(report)
config.update(checked_code=code, prior_checkpoint=prior_commit, public_run=str(PUBLIC), public_gates=5,
    explicit_reports=report['individual_reports'], board_prefix=BOARD_PREFIX,
    board_post_id=post['id'], board_sequence=post['sequence'], source_tree_sha256=tree.hexdigest(),
    old_non_audit_source_files_byte_exact=6264,
    old_audit_contiguous_bytes_preserved=430100, old_audit_exact_offset=0,
    ordinary_audit_import_bytes=0, new_audit_imports=0, old_audit_is_prefix=True,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],
    cleanup_receipt='combined-terminal-cleanup-result.json', removed_symlinks=cleanup['removed_symlinks'],
    symlink_target_bytes_counted=False, normal_lake_symlink_targets_preserved=True,
    tmp_readable_regular_file_bytes_after=cleanup['tmp_readable_regular_file_bytes_after'],
    tmp_census_errors=cleanup['tmp_census_errors'], unknown_tmp_entries_preserved=True,
    later_tmp_audit_readable_regular_bytes=other_tmp['readable_regular_bytes'],
    later_tmp_audit_at=other_tmp['at'], later_tmp_audit_errors=other_tmp['errors'],
    historical_primary_usage_percent=percent, historical_primary_usage_checked_at=usage['checked_at'],
    historical_usage_snapshot=True, current_usage_not_measured=True,
    prior_immutable_archive=bindings['prior_archive'], prior_manifest_sha256=bindings['prior_manifest_sha256'],
    fresh_strict_reports=4, inherited_component_reports=492,
    all_new_formal_proof_checks_first_pass=True, first_check_passed_without_repair=True,
    all_four_original_first_headers_exact=True, both_old_owner_prefixes_byte_exact=True,
    historical_failed_proofs_preserved_in_prior_immutable_chain=True,
    additional_frozen_roots=additional, additional_frozen_roots_theorem_credit=0,
    future_private_checks_and_Work55_excluded=True,
    arbitrary_independent_warm_query_sequence_proved=False,
    every_warm_worker_call_qualification_proved=False,
    user_explicitly_resumed=True, earlier_usage_pause_lifted=True,
    work_authorized_by_explicit_user_resume=True, persistent_goal_control_status='paused',
    goal_resume_operation_performed=False, goal_completion_claimed=False, goal_active=False,
    joint_finite_completion_proved=False, compiled_haskell_correspondence_proved=False, haskell_changed=False)
skipped = sorted(str(path.relative_to(ROOT)) for path in BASE.iterdir()
    if path.is_dir() and path.name.startswith('20261117-') and str(path.relative_to(ROOT)) not in selected_roots)
review = {'prior_checkpoint': prior_commit, 'selected_roots': len(selected_roots), 'base_roots': 11,
    'additional_frozen_roots': additional, 'additional_frozen_roots_theorem_credit': 0,
    'fresh_reports_this_batch': 4, 'inherited_reports': 492, 'combined_reports': 496,
    'new_public_theorems': 4, 'new_private_helpers': 1, 'new_theorem_declarations': 5,
    'new_prop_definitions': 0, 'definition_checks': 0, 'definition_axiom_reports': 0,
    'new_private_explicit_reports': 0, 'private_helpers_counted_as_explicit_reports': False,
    'all_current_component_first_checks_passed': True, 'inherited_owner_reports': 264,
    'all_four_original_first_headers_byte_exact': True, 'both_old_owner_prefixes_byte_exact': True,
    'full_call_admission_exports_checked': True, 'interposed_entry_identity_exports_checked': True,
    'future_private_checks_and_Work55_excluded': True,
    'all_six_cache_meanings_proved': False, 'every_warm_worker_call_qualification_proved': False,
    'arbitrary_independent_warm_query_sequence_proved': False,
    'warm_query_no_new_mu_proved': True, 'joint_finite_completion_proved': False,
    'haskell_changed': False, 'goal_completion_claimed': False}
note = (WORK / 'checkpoint-note.md').read_text()
for key, value in {'THEOREMS': report['audited_theorems'], 'REMOVED': cleanup['removed_bytes'],
                   'SYMLINKS': cleanup['removed_symlinks'],
                   'CLEANUP': cleanup['cumulative_removed_bytes'], 'USAGE': percent}.items():
    note = note.replace('{{' + key + '}}', str(value))
assert set(re.findall(r'\{\{(.*?)\}\}', note)) == {'TIME', 'TREE', 'CODE'}
assert 'historical' in note.lower() and 'current usage was not measured' in note.lower()
outputs = {'checkpoint-config.json': config, 'archive-roots.json': selected_roots,
           'skipped-published-roots.json': skipped, 'selection-review.json': review}
assert all(not (WORK / name).exists() for name in outputs)
# No mutation occurs before every proof, source, document, board and cleanup guard above passes.
for name, value in outputs.items():
    (WORK / name).write_text(json.dumps(value, indent=2) + '\n')
(WORK / 'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code': code, 'packet': ARCHIVE, 'roots': len(selected_roots),
    'board_sequence': post['sequence'], 'fresh_reports': 4, 'inherited_reports': 492,
    'combined_reports': 496, 'future_root_credit': 0, 'current_usage_not_measured': True}))
