# Actual fold, cache and physical projection review

The six current modules and their public contracts pass independent source review. All 991 current source lines, every private proof branch and all 440 new public lines were read. The public output has 13 complete laws, 13 standard-only axiom reports and two definition prints. This owner ran no compiler, evaluator or Haskell/native product. Root reports focused default/strict checks, Audit 4796/83564 and public 1315/159 PASS.

Given the current fold admissions, every successful raw Core row and every returned Some cache keeps the same common height cap for all pending Some handles at the actual reached heap. KnownOrdinary still describes only pending Some slots. It supplies no hidden node for a None slot.

## Actual contracts

| Module | Conclusion and exact boundary |
| --- | --- |
| FoldIncomingEntry163 | An actual successful singleton fold derives Post, final query identity, target Pending, PendingRealized, advanced Fits, remaining Room, annotation Heap, native Stored, Known and availability of the supplied original incoming value. The reservation covers sources.length+1. Other actual row shapes have conclusion True. The cached corollary uses literal erasure and covers raw endpoints with cache None. |
| ProjectionEffects225 | Every actual project and forest outcome preserves SemanticHeap, Covered, physical record growth and issued history. A done result is Available and closed. All Mu, Union, signed selection, absent child and worker/read-fuel branches follow the actual definitions. Completion or accepted-language semantics are not conclusions. |
| CachedFoldKnown139 | Every actual returned Some cache satisfies Known at the actual caller heap. Cache None has conclusion True. The source-list induction derives each next admission internally. |
| ProjectionPhysical149 | Actual readAll, union and head operations keep exact old physical handle payloads at every outcome and read fuel. The two public definitions retain each reached heap and map reader outcomes to exposure without the exhausted-limit tag. |
| IncomingOldKnown165 | Every actual bounded native-query endpoint keeps the SAME old cache, including non-done endpoints. Whole incoming execution keeps native Stored at every exposed caller and old-cache Known except the failed physical-check branch. |
| RawFoldKnown150 | Every successful actual raw Core row satisfies Known at the reached heap. The cached-fold corollary covers those rows independently of the optional returned cache, including cache None. Empty/error rows do not create a successful Core. |

The entry theorem preserves availability of a supplied original incoming value. It does not derive that arbitrary value's ordinary domain, closedness or common height cap. The conclusion therefore supplies part of the next incoming admission. It does not claim full terminal closure. The raw singleton row is explicit; a cache-None endpoint does not create an optional cache witness.

IncomingOld's exception is exactly Except.error (Sum.inr _). The literal IncomingNode.run uses that tag for the failed optional physical check. Native-query yielded, failed, constraintError and blocked endpoints keep old-cache Known. A completed enabled physical check also keeps it. Native Stored still holds at the omitted failed-check endpoint. This does not itself prove physical lookup retention there.

## Internal producers

No new public law takes a future Trace, Post, Receipt, per-step invariant or completion function as an input. Fold source-list induction and projection fuel induction remain internal. The private verified-bind and smaller-projection arguments are discharged by those internal proofs.

Both fold cap proofs derive dispatch admission from current target Pending and the selected source PendingOrEliminated facts. They obtain each successor Context, PendingRealized, target Pending, selected tail, Fits and annotation Heap through observed_singleton only after the actual singleton-success branch. Reserved.head and Reserved.tail provide the current and next finite schedule gates. Native Stored comes from the actual head dispatch. The raw fallback preserves successful Core bounds even when cache recovery returns None.

The entry proof derives finite completion from current initial_ranges, aligns the actual successful fold with ok_unique and obtains Post and target facts internally. Its extra reserved step gives Room at advance seed sources.length. Post.effects.keeps retains the original incoming availability. No future endpoint certificate is supplied.

The native prefix proof derives Original and actual warm ranges from current Ready, Fits/Room and Available/closed operands. It produces a completed physical trace internally, then derives the prefix reached by the actual supplied native fuel. The constant-True guard interpretation is used for physical trace effects. No semantic guard claim follows from that choice.

Projection follows literal readAll, rows, head, project and forest. It retains exact growth and issued history through reconstruction, list traversal and generic Mu/Union exposure. The private lookup proof uses both table/record growth and issued-history retention. Handle zero always decodes to Empty. Positive handles require the same issued key, table winner and record payload.

## Current admissions and full objective

Fold laws retain current Context, PendingRealized, target Pending, selected list membership, Fits, finite Reserved, annotation Heap, native Stored and input Known. Entry additionally takes current original incoming Available. Physical laws retain current SemanticHeap, Covered and Available/closed inputs, plus an old lookup for lookup conclusions. The native prefix law retains current Ready, Fits/Room, closed available operands and input Known. These gates are explicit in the public readback.

The full original-input proof remains open. Missing work includes failed-check old-cache lookup retention, complete terminal/alias/renewal and remaining writer composition, original positive-depth support and sufficient all-branch resources for BOTH workers, default/weighted source adapters, generic behavior and intended accepted public prefixes with exact configured order/stops/resources. Original Map/domain/order, signed/Set, rank/unrank, Prefix/table/count/checkpoint, Word64/host and Haskell correspondence remain within the full objective. A local common height cap and a finite supplied reservation do not supply those results.

No Haskell defect, edit or fix was established. This owner has no Haskell fix to add to FINDINGS. Root must retain any later Haskell fixes there for external work.

## Provenance and retained versions

The review reads the six normalized installed current modules. Original frozen provider drafts retain their UNCOMPILED/source-only labels. This review does not retroactively claim those original bytes were elaborated or that every original unelaborated header had a valid type. Root retains their complete versions, repairs, logs and providers.

Exactly the two named OLD whole originals were acquired and fully read: Fold353 and ProjectionWorker60. All other OLD semantic reads use named bounded cuts and locators. The ledger records 40 acquisitions at 17 ORIGINAL paths with 784 unique lines. CachedFold contributes only 19/120 lines for run/erase headers and its locator. No private reuse bypasses the ORIGINAL-path unions.

One header-cut helper initially stopped at the inner let actual := in a statement. The retained partial cut was supplemented with the entire theorem header. The exact lookup definition was also completed. Every final source/copy hash and exact original-line replay passes.

The final canonical178 and common-prefix58 were read in full and match the checked contracts. No documentation correction was required. Their complete origin records are retained. The common prefix is exact in all three root documents, and every full prior body remains an exact byte-hash suffix. Those old document bodies were hash-checked without semantic acquisition.

All15 immutable metadata snapshot files were copied, pinned and read in full. They record26 historical owners. That count was not compared against a later mutable owner index. The copied Root provider manifests and seals match all26 recorded pairs. Root retains complete readonly providers and transitive private helpers for the parent archive. Their source bodies were not acquired as a semantic shortcut here. Future require/terminal drafts stay UNCOMPILED and outside the six checked modules.

Root reports24 compiler commands:16 PASS and8 retained repaired failures, with130 input snapshots. Its metadata distinguishes full reads of five smaller diagnostics from bounded error/goal cuts in three large native-old diagnostics. Root retains every raw diagnostic and failed version. This peer claims no independent raw-diagnostic reading or compiler execution.

All current source/copy pins, public chunks, exact OLD line vectors, document prefixes/suffixes, immutable metadata pins and provider seal pins pass. No substantive source, public-contract or final-document issue remains. The full original objective and all stated boundaries remain open.
