#!/usr/bin/env python3
"""Verify retained metadata and source bytes. Use --live for original-path replay."""
from pathlib import Path
import argparse
import hashlib
import json
import re

ap = argparse.ArgumentParser()
ap.add_argument('--live', action='store_true')
args = ap.parse_args()
root = Path(__file__).resolve().parent

def js(name):
    return json.loads((root / name).read_text())

def sha(data):
    return hashlib.sha256(data).hexdigest()

def checked(path, pin, size=None):
    data = path.read_bytes()
    assert sha(data) == pin, str(path)
    if size is not None:
        assert len(data) == size, str(path)
    return data

mf = js('MANIFEST.json')
files = sorted(str(f.relative_to(root)) for f in root.rglob('*') if f.is_file() and f.name != 'MANIFEST.json')
assert files == sorted(mf['files']) and set(files) == set(mf['pins'])
for name in files:
    pin = mf['pins'][name]
    checked(root / name, pin['sha256'], pin['bytes'])

sources = js('new-sources.json')
assert len(sources) == 6 and sum(r['source_lines'] for r in sources) == 991
for row in sources:
    data = checked(root / row['copy'], row['copy_sha256'], row['source_bytes'])
    assert row['source_sha256'] == row['copy_sha256']
    assert len(data.splitlines()) == row['source_lines']
    assert row['actual_lines'] == list(range(1, row['source_lines'] + 1))
    if args.live:
        assert Path(row['source_path']).read_bytes() == data

old = js('old-acquisitions.json')
assert len(old) == 40
unions = {}
for row in old:
    data = checked(root / row['copy'], row['copy_sha256'])
    vector = row['actual_lines']
    assert len(vector) == len(set(vector)) and all(1 <= i <= row['source_lines'] for i in vector)
    unions.setdefault(row['source_path'], set()).update(vector)
    if row['copy_format'] == 'numbered-lines':
        assert [int(line.split(b':', 1)[0]) for line in data.splitlines()] == vector
    else:
        assert row['copy_format'] == 'plain-source-lines' and len(data.splitlines()) == len(vector)
    if args.live:
        original = checked(Path(row['source_path']), row['source_sha256'], row['source_bytes'])
        lines = original.splitlines(keepends=True)
        prefix = row['copy_format'] == 'numbered-lines'
        assert b''.join((str(i).encode() + b':' if prefix else b'') + lines[i-1] for i in vector) == data
assert len(unions) == 17 and sum(len(v) for v in unions.values()) == 784
u = js('OLD-SOURCE-UNIONS.json')
assert u['actual_wholes'] == u['old_whole_budget'] == 2
wholes = set()
for row in u['records']:
    assert set(row['actual_lines']) == unions[row['source_path']]
    if row['whole_or_near_whole']:
        wholes.add(Path(row['source_path']).name)
    else:
        assert len(row['actual_lines']) < 0.75 * row['source_lines']
    if Path(row['source_path']).name == 'SourcePruningEnumerationCachedFold.lean':
        assert len(row['actual_lines']) == 19
assert wholes == {'SourcePruningEnumerationFold.lean', 'SourceEqualityProjectionWorker.lean'}

public = checked(root / 'public/public-new-tail.log', '453d2adec7af3a10ec40e3c569b4e1683dc0363fe81d49d25b51c23e5409ab8b', 30883)
assert len(public.splitlines()) == 440
readback = js('public/readback-origin.json')
assert b''.join(checked(root / r['copy'], r['sha256'], r['bytes']) for r in readback['chunks']) == public
reports = js('public/axiom-reports.json')
actual = re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", public.decode(), re.S)
assert len(actual) == len(reports) == 13
for row, (name, axioms) in zip(reports, actual):
    assert row['name'] == name and row['axioms'] == re.split(r',\s*', axioms.strip())
    assert set(row['axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}
assert len(re.findall(r'^def ', public.decode(), re.M)) == 2

index = js('metadata/peer-inputs/INDEX.json')
assert index['owners_before_current_peer'] == 26 and len(index['files']) == 14
assert len(js('metadata/peer-inputs/owners.json')) == 26
for row in index['files']:
    checked(root / 'metadata/peer-inputs' / row['path'], row['sha256'], row['bytes'])
for row in js('metadata/consulted-metadata-origins.json')['records']:
    data = checked(root / row['copy'], row['sha256'], row['bytes'])
    assert row['actual_lines'] == list(range(1, len(data.splitlines()) + 1))
    if args.live:
        assert Path(row['origin_path']).read_bytes() == data

for row in js('docs/document-origins.json')['records']:
    data = checked(root / row['copy'], row['copy_sha256'], row['source_bytes'])
    assert row['actual_lines'] == list(range(1, row['source_lines'] + 1))
    if args.live:
        assert Path(row['source_path']).read_bytes() == data
prefix = (root / 'docs/current-document-prefix.md').read_bytes()
canonical = (root / 'docs/notes-current-fold-cache-and-physical-effects.md').read_bytes()
assert len(prefix.splitlines()) == 58 and len(canonical.splitlines()) == 178
assert sha(canonical) == '32c773d0b9d38b6eacffc6296a00cb1f7a6c1924164d5cd7f1f706944be20d84'
if args.live:
    for row in js('metadata/peer-inputs/document-plan.json')['files']:
        data = checked(Path('/home/tritlo/Code/mcfta') / row['path'], row['sha256'], row['bytes'])
        if 'prior_body_sha256' in row:
            assert data[:len(prefix)] == prefix
            assert len(data[len(prefix):]) == row['prior_body_bytes'] and sha(data[len(prefix):]) == row['prior_body_sha256']
    for row in js('metadata/provider-closure-resolution.json')['records']:
        for seal in row['checks']:
            checked(Path(seal['path']), seal['sha256'], seal['bytes'])
print('PASS: retained payloads; current991 source/440 public/13 standard reports/2 definitions; 40 OLD acquisitions/17 ORIGINAL paths/784 unique lines/2 named wholes; final178/58 docs; immutable15 metadata/26 historical provider seals' + ('; live replay' if args.live else ''))
