R19 independent SOURCE/PUBLIC-CONTRACT review. Root owns compiler/evaluator/native/Haskell/Git/network/board/production. No spawn. Review six NEW current modules991L, final public/docs and immutable metadata when supplied.

Named before OLD acquisition, the only permitted OLD whole ORIGINAL paths are:
/home/tritlo/Code/mcfta/lean/MicroCFTA/SourcePruningEnumerationFold.lean
/home/tritlo/Code/mcfta/lean/MicroCFTA/SourceEqualityProjectionWorker.lean

All other OLD source is named bounded cuts/locators, merged at ORIGINAL paths, including private reuse. CachedFold is limited to run/erase header cuts. No future Trace/Post/per-step supplier or global original-resource claim is permitted.

Final reviewed scope: six current sources991L, new public440L/13 laws/two definitions, canonical178L/commonprefix58L. All15 immutable snapshots copied/pinned/read, historical26-owner index kept separate from later live additions. Root retains complete providers/private closures. This peer executes only metadata/hash/line checks.
