import sys
sys.dont_write_bytecode = True
from acquire import acquire

for name, first, last, label in [
    ('SourcePruningEnumerationFoldAdmission.lean', 107, 130, 'current-derived-fold-ranges'),
    ('SourcePruningEnumerationFoldUnique.lean', 30, 48, 'actual-fold-result-uniqueness'),
    ('SourceCurrentAllocatedNativeStoredFold.lean', 28, 42, 'actual-fold-native-stored'),
    ('SourcePruningEnumerationFold.lean', 70, 105, 'original-finite-fold-output-contract'),
    ('SourcePruningEnumerationIncomingReservation.lean', 101, 120, 'original-reservation-remaining-incoming-step'),
]:
    acquire(name, 'cuts/' + label, 'named bounded actual fold-entry producer contract', first, last)
