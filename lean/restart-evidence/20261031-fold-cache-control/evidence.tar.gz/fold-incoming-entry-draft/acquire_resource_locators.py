import sys
sys.dont_write_bytecode = True
from acquire import acquire

pattern = r'^import |^namespace |^(private )?(theorem|lemma|def|noncomputable def|abbrev) '
for name in [
    'SourcePruningEnumerationFoldResources.lean',
    'SourcePruningEnumerationCachedFoldResources.lean',
    'SourcePruningEnumerationCachedTerminalResources.lean',
    'SourcePruningEnumerationCachedTerminalAdapterResources.lean',
    'SourcePruningEnumerationTerminalAdmission.lean',
    'SourcePruningEnumerationTerminalObservedResources.lean',
    'SourcePruningEnumerationFoldUnique.lean',
    'SourceCurrentAllocatedNativeStoredTerminal.lean',
]:
    acquire(name, 'locators/' + name, 'named current terminal/fold resource declaration locators', pattern=pattern)
