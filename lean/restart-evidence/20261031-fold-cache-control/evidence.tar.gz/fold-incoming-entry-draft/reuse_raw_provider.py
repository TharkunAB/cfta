from pathlib import Path
import hashlib
import json

owner = Path('/tmp/mcfta-native-terminal-compose-known-review-20261031')
provider = Path('/tmp/mcfta-native-fold-fallback-known-review-20261031')
source = provider / 'SourceCurrentAllocatedNativeRawFoldKnown-v1-UNCOMPILED.lean'
raw = source.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '911d5202a6ef9bc9cc19f4d71fa02791382afebd1c1508995c820946e7174ab2'
lines = raw.decode().splitlines(keepends=True)
selected = list(range(35, 55))
target = owner / 'cuts' / 'raw150-public-cap-contract'
target.write_text(''.join(f'{i}:{lines[i-1]}' for i in selected))
ledger_path = owner / 'acquisitions.json'
ledger = json.loads(ledger_path.read_text())
ledger.append({'kind': 'named bounded private pending public header reuse',
               'original_path': str(source), 'source_sha256': hashlib.sha256(raw).hexdigest(),
               'source_bytes': len(raw), 'source_lines': len(lines), 'actual_lines': selected,
               'copy': str(target.relative_to(owner)), 'copy_sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
ledger_path.write_text(json.dumps(ledger, indent=2) + '\n')
print(target.read_text())

manifest_raw = (provider / 'MANIFEST.json').read_bytes()
assert hashlib.sha256(manifest_raw).hexdigest() == '1de1a86683a28b1422475d5607ff61208569c14166cadb78108a2908570f01a8'
manifest = json.loads(manifest_raw)
for row in manifest['files']:
    data = (provider / row['path']).read_bytes()
    assert len(data) == row['bytes']
    assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
metadata = owner / 'providers' / 'raw150'
metadata_names = {'MANIFEST.json', 'pins.json', 'FROZEN', 'cumulative-original-unions.json', 'provider-verification.json'}
copied = []
for original in provider.rglob('*'):
    if original.is_file() and original.name in metadata_names:
        relative = original.relative_to(provider)
        destination = metadata / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(original.read_bytes())
        copied.append(str(relative))
record = {'provider': str(provider), 'manifest_sha256': hashlib.sha256(manifest_raw).hexdigest(),
          'verified_payloads': len(manifest['files']), 'full_provider_files': 38,
          'source_status': 'Owner150 remains UNCOMPILED; Root is checking a derived production version in R19.',
          'body_reuse': 'Only public header lines35-54; no old proof body copied.',
          'metadata_copies': copied,
          'closure': 'Full original38-file provider and its referenced42-file cached-fold provider remain available and frozen. Root owns their complete restart evidence.'}
(owner / 'provider-verification.json').write_text(json.dumps(record, indent=2) + '\n')
print('Full private provider payload verified:', len(manifest['files']))
