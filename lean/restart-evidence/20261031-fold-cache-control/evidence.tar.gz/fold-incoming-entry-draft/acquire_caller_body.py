import sys
sys.dont_write_bytecode = True
from acquire import acquire

acquire('SourcePruningEnumerationChildDispatch.lean', 'cuts/literal-child-observe-and-terminal-input',
        'named bounded actual incoming-source caller body', 28, 67)
