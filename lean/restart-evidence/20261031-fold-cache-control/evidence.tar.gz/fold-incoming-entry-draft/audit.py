from pathlib import Path
import hashlib
import json

owner = Path('/tmp/mcfta-native-terminal-compose-known-review-20261031')
rows = json.loads((owner / 'acquisitions.json').read_text())
unions = {}
for row in rows:
    source = Path(row['original_path'])
    data = source.read_bytes()
    assert hashlib.sha256(data).hexdigest() == row['source_sha256'], source
    lines = data.decode().splitlines(keepends=True)
    assert len(lines) == row['source_lines'], source
    retained = owner / row['copy']
    kept = retained.read_bytes()
    assert hashlib.sha256(kept).hexdigest() == row['copy_sha256'], retained
    whole = row['kind'] == 'named whole original'
    expected = data if whole else ''.join(f'{i}:{lines[i-1]}' for i in row['actual_lines']).encode()
    assert kept == expected, retained
    item = unions.setdefault(str(source), {
        'source_sha256': row['source_sha256'], 'source_lines': len(lines),
        'source_bytes': len(data), 'whole': False, 'actual_lines': set(), 'retained_copies': [],
    })
    assert item['source_sha256'] == row['source_sha256']
    item['actual_lines'].update(row['actual_lines'])
    item['whole'] |= whole
    item['retained_copies'].append(row['copy'])
for item in unions.values():
    item['actual_lines'] = sorted(item['actual_lines'])
    item['union_count'] = len(item['actual_lines'])
    item['union_fraction'] = item['union_count'] / item['source_lines']
assert sum(item['whole'] for item in unions.values()) == 2
record = {'acquisitions': len(rows), 'original_paths': len(unions), 'sources': unions}
(owner / 'cumulative-original-unions.json').write_text(json.dumps(record, indent=2) + '\n')
print('Source/cut/hash audit PASS:', len(rows), 'acquisitions;', len(unions), 'original paths; exactly two OLD wholes.')
others = [(item['union_fraction'], path, item['union_count'], item['source_lines'])
          for path, item in unions.items() if not item['whole']]
for fraction, path, count, total in sorted(others, reverse=True)[:5]:
    print(count, '/', total, f'{fraction:.3f}', path)

provider_results = []
for provider in [Path('/tmp/mcfta-native-fold-fallback-known-review-20261031'),
                 Path('/tmp/mcfta-native-fold-known-review-20261031')]:
    manifest_raw = (provider / 'MANIFEST.json').read_bytes()
    manifest = json.loads(manifest_raw)
    for item in manifest['files']:
        data = (provider / item['path']).read_bytes()
        assert len(data) == item['bytes']
        assert hashlib.sha256(data).hexdigest() == item['sha256'], item['path']
    provider_results.append({'provider': str(provider),
                             'manifest_sha256': hashlib.sha256(manifest_raw).hexdigest(),
                             'payloads_verified': len(manifest['files'])})
(owner / 'provider-closure-audit.json').write_text(json.dumps(provider_results, indent=2) + '\n')
print('Complete private provider payloads verified:', [item['payloads_verified'] for item in provider_results])
