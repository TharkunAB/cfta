# Actual fold endpoint for terminal incoming

The final candidate is `SourceCurrentAllocatedNativeFoldIncomingEntry-v1-UNCOMPILED.lean`.
It has 163 lines. SHA256 is `15fe078589900d5cc25e40d939f718fd01bc9b9371dc595f4001472aab64b8c2`.
Both theorem bodies are UNCOMPILED. Root owns checks and production work.

This task implements the first missing current-entry producer. It does not claim full terminal closure.
The requested older directory was already sealed. Root approved this fresh `terminal-compose` directory at08:28. The older inventory remains unchanged.

## Actual closed result

`fold_incoming_entry` computes the literal raw Fold at arbitrary supplied fuels.
In its actual successful singleton branch, it derives all of these facts at the SAME literal reached caller:

- A Post and its next Context, with the actual saved query memo.
- PendingRealized for the returned Core and a pending target.
- Fits and annotation Heap at the original finite schedule's advanced profile.
- Native Stored and whole KnownOrdinary at the SAME input height bound.
- Room for the next incoming call.
- Physical availability of the SAME original incoming value.

`cached_fold_incoming_entry` transfers that complete endpoint package through the existing erasure identity.
It computes the actual cached Fold and covers its singleton branch independently of cache `some` or `none`.
It does not invent a recovered cache or assert valid old flags.

The public inputs are the existing CURRENT fold admission, current whole KnownOrdinary, and availability of the original incoming value.
The reservation is `Reserved bits seed (sources.length + 1)`.
This is the EXISTING terminal allowance for recorded source steps plus one incoming step.
It is explicit in the header. It is not a new reservation silently imposed on a plain fold theorem.
There is no future Post, endpoint Context, Room, range, receipt, trace, result, or per-step supplier.

## Derivation from original current gates

The original reservation supplies the fold reservation by prefix restriction.
`reserved_iff_last` derives Room at `advance seed sources.length` directly from that original reservation.
The proof does not ask for Room at a future observed state.

`initial_ranges` constructs the complete fold range predicate from current admission.
That checked producer derives each current dispatch slot/range admission inside its actual source-list induction.
The candidate does not accept that predicate as a public input.

The existing `run_complete` produces its finite successful fold and Post from those current inputs.
`ok_unique` aligns the internally produced fold with the SAME actual successful singleton observation.
The returned row shape identifies its Core with the produced endpoint Core.
This is a derived result, rather than a supplied future completion witness.

`observed_resources` supplies Fits and the annotation Heap at the actual caller.
`fold_native_stored` supplies native Stored there.
The newly checked raw-fold cap law supplies whole KnownOrdinary for that actual row.
The aligned Post retains the original incoming value's physical availability through its actual heap effect.
The existential Post contains the next Context through `post.context`.

## Exact terminal and source-builder boundaries

The actual terminal adapter calls the cached fold on the actual prefix result.
Its successful singleton branch then calls IncomingNode directly when cache recovery returns `none`, or calls the incoming cache adapter when a cache is returned.
The new endpoint package supplies the missing current resource/heap connection for that incoming call.

It does not derive whole Known for the literal prefix result from the original terminal cache in this module.
That current prefix connection must use its actual unchanged values and existing prefix admission facts.
It does not compose the final incoming raw rows or returned cache.

The terminal's `incoming` argument is an arbitrary Value in its current interface.
Its existing admission supplies Available and closedness. Neither is an ordinary-domain or common-height producer.
Current Known for cache slots does not link an arbitrary separate incoming value to those slot bounds.
Root explicitly confirmed that limitation. This candidate does not add a new incoming-domain or height premise to hide it.

The nearest supplied native routes are pinned in NativeOrdinary24–32 and NativeOrdinaryContinuations20–32.
Both read the actual parent, then pass the free `edgesOf parent` list to branch or continuation execution.
The row-source membership/cap connection for values produced downstream from that list remains separate.
This review does not assume that an arbitrary `edgesOf` function returns only fields from the actual parent.
ChildDispatch46–66 then passes its incoming argument unchanged to the terminal adapter in the terminal-SCS branch.

The constrained-cap callback header38–46 takes an existing generic `Cap` and `MuStored`, then preserves them.
That header does not produce finite ordinary Node or MergedOrdinaryHeight for the terminal's arbitrary incoming argument.
The separate physical lookup producer uses current SemanticHeap/Covered gates. Root confirmed that it does not provide the missing ordinary/common-cap implication.

`NEXT-BOUNDARY.md` records the exact next source certification and cache branch.

## Honest scope

This is a current fold-to-incoming endpoint producer, not the requested complete terminal theorem.
It closes a real prerequisite without a future endpoint supplier.
It derives availability at the endpoint. It does not derive ordinary domain or height for the arbitrary incoming value.
Closedness remains a property of the unchanged original value in its caller; this endpoint law does not need a separate closedness premise.

The earlier raw/cache fold laws and this candidate leave full terminal composition, source-builder certification, Mu/Union/opaque routes, both-worker coverage, captured-sibling restoration, sufficient original depth/resources, ordered public prefixes, and Haskell correspondence open.
No Haskell defect or fix was established. No FINDINGS change is proposed.

## Upstream status and provenance

Root reported installed raw150 and cached139 default+strict PASS at08:40, without proof or admission repairs.
Only the historical source-only sentence changed. The literal line counts remain150 and139.
The current raw production SHA is `4b03bd8bbfd4b40eae0bfb1805ed3fac7bcb7eafb09706fcae07052eb5507a23`.
The current cached production SHA is `ff228394fa5c0d35b18e0482fc9d1a5f332ef920e6ef07e8a282de70a986da50`.
This owner did not run those checks. Its own new163 remains UNCOMPILED.

Only two OLD wholes were acquired: CachedTerminal353 and CachedTerminalAdapter635, named before acquisition.
All other source is named bounded cuts or declaration locators.
The protected NativeOrdinaryContinuations100 module was read only through a small named cut and declaration lines.
The prior raw150 owner contributes public header lines35–54 only, and no proof body.
Its full35-file manifest payload is verified. Its complete38-file owner remains frozen, with referenced cached139 provider metadata retained.
Both source versions have exact vectors: historical private150 and current checked production150.

`acquisitions.json` records original paths, full-source hashes, retained ranges and copy hashes.
`cumulative-original-unions.json` combines all repeated source reads at their ORIGINAL paths.
No compiler, formal evaluator, native/Haskell program, Git, network, board, production mutation, or child agent was used.
All previous sealed bundles remain unchanged.
