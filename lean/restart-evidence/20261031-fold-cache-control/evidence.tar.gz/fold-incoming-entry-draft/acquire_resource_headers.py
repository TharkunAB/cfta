import sys
sys.dont_write_bytecode = True
from acquire import acquire

for name, first, last, label in [
    ('SourcePruningEnumerationFoldResources.lean', 29, 54, 'actual-fold-observed-resources'),
    ('SourcePruningEnumerationTerminalAdmission.lean', 32, 57, 'actual-prefix-entry-facts'),
    ('SourceCurrentAllocatedNativeStoredTerminal.lean', 29, 53, 'current-terminal-native-stored-admission'),
    ('SourcePruningEnumerationTerminalObservedResources.lean', 30, 59, 'actual-terminal-observed-resources'),
    ('SourcePruningEnumerationCachedTerminalAdapterResources.lean', 34, 61, 'current-terminal-adapter-original-resources'),
    ('SourcePruningEnumerationCachedTerminalResources.lean', 34, 60, 'current-cached-terminal-original-resources'),
]:
    acquire(name, 'cuts/' + label, 'named bounded current original-admission header', first, last)
