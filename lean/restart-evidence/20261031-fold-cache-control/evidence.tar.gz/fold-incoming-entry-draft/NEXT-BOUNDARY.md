# Remaining actual terminal composition

The new closed endpoint producer covers the literal raw/cache Fold singleton branch.
It derives current Post/Context, realized/pending, Fits/Room, annotation Heap, native Stored, whole Known and original incoming availability.
It uses the existing original source-count-plus-incoming reservation.

The next composition has three concrete obligations.

First, transport initial cache Known through the actual terminal prefix.
The prefix changes representative and waiting data. Its actual value preservation must supply the joined cache property and current pending/selected admission.
The existing observed-prefix law already exports current PendingRealized and pending recorded slots, but its retained header does not export KnownOrdinary.

Second, certify the actual incoming source value before the terminal call.
NativeOrdinary and NativeOrdinaryContinuations pass `edgesOf parent` to their branch machinery.
The actual selected-row/field builder must prove its literal produced incoming value is finite ordinary and has height at most the original common bound.
This must come from the actual controlled row source and builder, rather than a free future incoming certificate or an assumed restriction on arbitrary `edgesOf`.
ChildDispatch then passes that same value to the terminal adapter.
The current local terminal admission's arbitrary Available/closed incoming argument is insufficient to derive those two properties.
This is a model/adapter obligation, not a Haskell defect or executable counterexample.

Third, compose the actual incoming result and cache adapter.
IncomingKnown supplies successful raw Core bounds when its CURRENT incoming domain/cap gates are met.
The actual incoming cache adapter's empty-row branch is important:
lines29–41 write a new pending Empty handle0 into the read Core, then run the index write and frame that new Core.
It does not simply return the old cache.
Known for the other read slots at the reached heap and the Empty handle's actual readback must be derived internally.
The successful singleton branch frames the returned Core at lines43–46.

The task does not establish a global bound on terminal calls or resumes.
Mu, Union, opaque reconstruction, Prepared-worker coverage, original resource sufficiency, ordered accepted prefixes, public adapters, and Haskell correspondence remain separate.
