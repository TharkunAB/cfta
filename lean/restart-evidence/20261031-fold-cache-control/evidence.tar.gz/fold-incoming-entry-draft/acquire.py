from pathlib import Path
import hashlib
import json
import re

OWNER = Path('/tmp/mcfta-native-terminal-compose-known-review-20261031')
ROOT = Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')


def acquire(name, label, kind, first=None, last=None, pattern=None):
    source = ROOT / name
    raw = source.read_bytes()
    lines = raw.decode().splitlines(keepends=True)
    if kind == 'named whole original':
        selected = list(range(1, len(lines) + 1))
        kept = raw
    elif pattern is not None:
        selected = [i for i, line in enumerate(lines, 1) if re.search(pattern, line)]
        kept = ''.join(f'{i}:{lines[i-1]}' for i in selected).encode()
    else:
        selected = list(range(first, last + 1))
        kept = ''.join(f'{i}:{lines[i-1]}' for i in selected).encode()
    target = OWNER / label
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(kept)
    ledger_path = OWNER / 'acquisitions.json'
    rows = json.loads(ledger_path.read_text()) if ledger_path.exists() else []
    row = {'kind': kind, 'original_path': str(source),
           'source_sha256': hashlib.sha256(raw).hexdigest(),
           'source_bytes': len(raw), 'source_lines': len(lines),
           'actual_lines': selected, 'copy': label,
           'copy_sha256': hashlib.sha256(kept).hexdigest()}
    if pattern is not None:
        row['pattern'] = pattern
    rows.append(row)
    ledger_path.write_text(json.dumps(rows, indent=2) + '\n')
    print(name, len(lines), 'lines', row['source_sha256'])
    if kind != 'named whole original':
        print(target.read_text())


if __name__ == '__main__':
    acquire('SourcePruningEnumerationCachedTerminal.lean', 'reused/SourcePruningEnumerationCachedTerminal.lean', 'named whole original')
    acquire('SourcePruningEnumerationCachedTerminalAdapter.lean', 'reused/SourcePruningEnumerationCachedTerminalAdapter.lean', 'named whole original')
