import sys
sys.dont_write_bytecode = True
from acquire import acquire

pattern = r'^import |^namespace |^(private )?(theorem|def|noncomputable def|abbrev) |ChildDispatch\.run|ChildTraversal\.run|CachedTerminalAdapter\.run'
for name in [
    'SourcePruningEnumerationNativeOrdinary.lean',
    'SourcePruningEnumerationNativeOrdinaryContinuations.lean',
    'SourceCurrentConstrainedCapNativeCallbacks.lean',
]:
    acquire(name, 'locators/' + name, 'Root-named actual incoming-source caller locator', pattern=pattern)
acquire('SourceCurrentAllocatedNativeRawFoldKnown.lean', 'cuts/checked-raw-fold-cap-header',
        'named bounded checked current production dependency header', 34, 53)
