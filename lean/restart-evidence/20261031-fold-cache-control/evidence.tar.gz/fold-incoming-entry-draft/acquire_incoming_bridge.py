import sys
sys.dont_write_bytecode = True
from acquire import acquire

pattern = r'^import |^namespace |^(private )?(theorem|lemma|def|noncomputable def|abbrev) '
for name in [
    'SourcePruningEnumerationIncomingCacheAdapter.lean',
    'SourcePruningEnumerationIncomingNodeProjectionHeap.lean',
    'SourcePruningEnumerationIncomingObservedResources.lean',
    'SourcePruningEnumerationIncomingCacheLanguage.lean',
    'SourcePruningEnumerationFoldObservedLanguage.lean',
]:
    acquire(name, 'locators/' + name, 'named incoming/endpoint producer locators', pattern=pattern)
acquire('SourcePruningEnumerationTerminalObservedResources.lean',
        'cuts/actual-prefix-fold-incoming-resource-connection',
        'named bounded actual endpoint resource proof', 78, 112)
