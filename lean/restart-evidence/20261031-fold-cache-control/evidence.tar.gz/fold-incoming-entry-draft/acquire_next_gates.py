import sys
sys.dont_write_bytecode = True
from acquire import acquire

acquire('SourcePruningEnumerationIncomingCacheAdapter.lean', 'cuts/literal-incoming-adapt',
        'named bounded current returned-cache branches', 22, 48)
acquire('SourcePruningEnumerationFoldObservedLanguage.lean', 'cuts/actual-fold-post-producer-header',
        'named bounded observed fold Post producer header', 25, 53)
acquire('SourcePruningEnumerationTerminalObservedResources.lean', 'locators/actual-terminal-context-flow',
        'named bounded actual Post/context call locators',
        pattern=r'(initial_ranges|run_complete|ok_unique|post|context|foldContext|available_keeps|after_prefix|\.head)')
