from datetime import datetime
from pathlib import Path
import hashlib
import json
import os

owner = Path('/tmp/mcfta-native-terminal-compose-known-review-20261031')
vectors = json.loads((owner / 'cumulative-original-unions.json').read_text())
now = datetime.now().astimezone().strftime('%Y-%m-%d %H:%M %Z')
excluded = {'MANIFEST.json', 'pins.json', 'FROZEN'}
files = []
for path in sorted(owner.rglob('*')):
    if not path.is_file():
        continue
    relative = str(path.relative_to(owner))
    if relative in excluded:
        continue
    data = path.read_bytes()
    files.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
manifest = {
    'status': 'FROZEN SOURCE-ONLY; new163 and both endpoint laws UNCOMPILED',
    'frozen_at': now, 'payload_files': len(files),
    'payload_bytes': sum(row['bytes'] for row in files),
    'acquisitions': vectors['acquisitions'], 'original_paths': vectors['original_paths'],
    'old_whole_originals': [path for path, row in vectors['sources'].items() if row['whole']],
    'files': files,
}
(owner / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
source = owner / 'SourceCurrentAllocatedNativeFoldIncomingEntry-v1-UNCOMPILED.lean'
assert len(source.read_text().splitlines()) == 163
pins = {
    'frozen_at': now, 'status': 'UNCOMPILED actual fold endpoint producer; full terminal remains open',
    'manifest_sha256': hashlib.sha256((owner / 'MANIFEST.json').read_bytes()).hexdigest(),
    'candidate': source.name, 'candidate_lines': 163,
    'candidate_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'report_sha256': hashlib.sha256((owner / 'REPORT.md').read_bytes()).hexdigest(),
    'next_boundary_sha256': hashlib.sha256((owner / 'NEXT-BOUNDARY.md').read_bytes()).hexdigest(),
    'source_vectors_sha256': hashlib.sha256((owner / 'cumulative-original-unions.json').read_bytes()).hexdigest(),
    'payload_files': len(files), 'total_files': len(files) + 3,
}
(owner / 'pins.json').write_text(json.dumps(pins, indent=2) + '\n')
(owner / 'FROZEN').write_text('Frozen source-only. New163 remains UNCOMPILED. Full terminal is open. ' + now + '\n')
for path in owner.rglob('*'):
    if path.is_file():
        os.chmod(path, 0o444)
for path in sorted(owner.rglob('*'), reverse=True):
    if path.is_dir():
        os.chmod(path, 0o555)
os.chmod(owner, 0o555)
print(json.dumps(pins, indent=2))
print('pins.json SHA256', hashlib.sha256((owner / 'pins.json').read_bytes()).hexdigest())
