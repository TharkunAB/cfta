1:import MicroCFTA.SourceCurrentConstrainedCapStoredSubstitution
2:import MicroCFTA.SourceCurrentConstrainedCapMarkerTransport
3:import MicroCFTA.SourceCurrentConstrainedCapWarmOccurrences
13:namespace MicroCFTA.SourceCurrentConstrainedCapNativeCallbacks
26:theorem filter_keeps [DecidableEq (EdgeKey Symbol Guard)] (name : Reference) (value : Value Symbol Guard)
38:theorem complete [DecidableEq (EdgeKey Symbol Guard)] (annotation : Guard → Prop) (depth : Nat)
83:theorem finish_local (annotation : Guard → Prop) (depth : Nat) (weight : Reference → Nat) (bound : Nat)
114:theorem candidate_complete [DecidableEq (EdgeKey Symbol Guard)] (annotation : Guard → Prop) (depth : Nat)
