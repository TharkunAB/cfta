1:import MicroCFTA.SourcePruningEnumerationCachedIncoming
3:namespace MicroCFTA.SourcePruningEnumerationIncomingCacheAdapter
22:def adapt
50:theorem adapt_singleton_core
63:noncomputable def run
83:theorem erase
95:theorem singleton_core
116:theorem complete
