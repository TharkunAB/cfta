1:import MicroCFTA.SourcePruningEnumerationCachedPrepare
2:import MicroCFTA.SourcePruningEnumerationCachedTerminalAdapter
28:noncomputable def observe
46:noncomputable def run
64:        SourcePruningEnumerationCachedTerminalAdapter.run
69:theorem erase
91:theorem terminal
99:      SourcePruningEnumerationCachedTerminalAdapter.run
103:  · simp only [run, SourcePruningEnumerationCachedTerminalAdapter.run, ite_eq_left empty]
107:theorem singleton_core
157:theorem empty
167:theorem nonterminal_complete
