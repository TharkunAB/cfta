1:import MicroCFTA.SourcePruningEnumerationSelectedEntry
2:import MicroCFTA.SourcePruningEnumerationNativeBranchCompletion
4:namespace MicroCFTA.SourcePruningEnumerationNativeOrdinary
24:noncomputable def run (checkEmpty : Bool) (r n p h k uv : Nat)
36:theorem entry_readback (checkEmpty : Bool) (r n p h k uv : Nat)
43:theorem terminal (checkEmpty : Bool) (r n p h k uv target handle : Nat) (scs : List Suspended)
56:def Ranges (checkEmpty : Bool) (uv : Nat) (edgesOf : Node → List (EdgeValue Symbol Constraint))
66:theorem complete_with_history
155:theorem complete_with_posts
205:theorem complete
250:theorem selected_complete
