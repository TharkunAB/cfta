1:import MicroCFTA.SourcePruningEnumerationFoldAdmission
10:namespace MicroCFTA.SourcePruningEnumerationFold
29:theorem observed_resources (seed : Seed)
