1:import MicroCFTA.EnumerationFlatTerminalPrefix
2:import MicroCFTA.EnumerationFlatNativeIncomingCache
3:import MicroCFTA.SourcePruningEnumerationCachedTerminalAdapter
32:def wrapIncoming (winner : Nat) (moved : EnumerationWaitingIndex.Waiting)
52:noncomputable def run
103:def ResultRelated
125:private def earlierIncoming (winner : Nat) (moved : EnumerationWaitingIndex.Waiting)
145:theorem wrapIncoming_related
195:theorem run_stable
207:        (SourcePruningEnumerationCachedTerminalAdapter.run checkEmpty
212:    simp only [run, SourcePruningEnumerationCachedTerminalAdapter.run, ite_eq_left empty]
245:  simp only [run, SourcePruningEnumerationCachedTerminalAdapter.run, ite_eq_right empty,
