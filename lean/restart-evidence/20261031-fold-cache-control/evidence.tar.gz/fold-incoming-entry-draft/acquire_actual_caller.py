import sys
sys.dont_write_bytecode = True
from acquire import acquire

for name in ['SourcePruningEnumerationChildDispatch.lean', 'EnumerationFlatNativeTerminal.lean']:
    acquire(name, 'locators/' + name, 'named actual terminal caller/builder locator',
            pattern=r'^import |^(private )?(theorem|def|noncomputable def) |CachedTerminalAdapter\.run')
