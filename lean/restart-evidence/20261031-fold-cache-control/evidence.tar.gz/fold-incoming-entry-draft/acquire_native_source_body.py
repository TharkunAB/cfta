import sys
sys.dont_write_bytecode = True
from acquire import acquire

for name, first, last, label in [
    ('SourcePruningEnumerationNativeOrdinary.lean', 24, 55, 'actual-ordinary-entry-and-terminal-route'),
    ('SourcePruningEnumerationNativeOrdinaryContinuations.lean', 20, 34, 'actual-ordinary-continuations-entry'),
    ('SourceCurrentConstrainedCapNativeCallbacks.lean', 38, 57, 'current-constrained-cap-factory-header'),
]:
    acquire(name, 'cuts/' + label, 'Root-named bounded actual source-builder contract', first, last)
