import sys
sys.dont_write_bytecode = True
from acquire import acquire

for name, first, last, label in [
    ('SourceCurrentAllocatedNativeIncomingOldKnown.lean', 69, 97, 'actual-incoming-old-known-contract'),
    ('SourceCurrentAllocatedNativeIncomingKnown.lean', 69, 87, 'actual-incoming-raw-known-contract'),
    ('SourcePruningEnumerationIncomingNode.lean', 39, 87, 'literal-incoming-read-and-query-branches'),
]:
    acquire(name, 'cuts/' + label, 'named bounded checked current incoming contract/runtime', first, last)
