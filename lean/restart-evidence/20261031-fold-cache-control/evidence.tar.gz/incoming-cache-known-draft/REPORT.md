# Current incoming cache producer

The 150-line candidate is UNCOMPILED. Root alone checks Lean sources. This bundle does not claim full terminal closure.

The candidate closes a concrete incoming-cache gate. The existing singleton-core law does not cover an empty raw result. The literal adapter can return a cache after it writes handle 0 to its target slot. The proof treats this write as a new value. It does not assume that the returned cache retains the original Core.

## Candidate laws

`read_values` derives an unconditional equality from the literal IncomingNode.run body. Its fourth result component has the original values list. A representative lookup can update the representatives field. Each subsequent branch retains that read state. The statement takes current arguments only. It does not take a run observation, successful tag, future Core, or cache certificate.

`run_known` executes the actual IncomingCacheAdapter.run expression at its supplied bounds. It derives both properties at the heap of that expression's exact returned Caller:

- Each successful raw Core row satisfies whole KnownOrdinary at the original common bound. This includes raw success when the optional cache is None.
- Every returned Some cache satisfies whole KnownOrdinary at that same bound and heap. This includes the empty-raw adapter branch and its actual Empty target write.

The public law keeps the existing current Context, PendingRealized, Available, closed, KnownOrdinary, Fits, Room, and native Stored gates. It also keeps the explicit CURRENT incoming ordinary domain and height bound used by IncomingKnown180. It has no free endpoint, Post, row bound, transition, receipt, or future cache/Core witness.

The proof derives successful raw row bounds from checked IncomingKnown180. It derives the original cache bound at the actual reached heap from checked incomingOld165. That latter result omits a bound only on the failed-check error branch. The literal cache adapter returns None on that error branch. It cannot create a missing successful-cache obligation there.

The private `adapt_known` lemma describes the literal pure adapter. Its internal row-bound premise is discharged by IncomingKnown180 in the closed public proof. It is not a public entry gate. In the empty branch, the proof obtains old members from the derived read-values equality. It obtains the replacement member from List.mem_or_eq_of_mem_set. Handle 0 has literal lookup `some .empty`; its recursive ordinary domain and height bound follow directly. In the singleton branch, adapt_singleton_core transports the internally derived raw Core property.

## Exact boundary

The full CachedTerminalAdapter.run theorem remains open in this bundle. Its consumer must split the actual prefix and fold results. It must use the checked fold incoming-entry producer for the actual singleton fold branch. It must use checked cached139 for an actual returned cache in the empty-fold-row branch. It can now use this candidate for the actual incoming cache branch and IncomingKnown180 for the cache-None incoming branch. It must transport the incoming row map to the terminal hole-fragment rows.

The consumer must also derive the joined prefix values equality and its current fold admission from the actual prefix result. It must retain the original source-count reservation with its incoming-step allowance. The checked endpoint163 already supplies the actual singleton fold's Context, Fits, Room, heap guard, native Stored, current whole Known, and incoming physical availability internally. This candidate does not replace that producer with a supplied future endpoint.

The full terminal composition was not written in this bounded task. The necessary literal read/cache coherence producer and its closed incoming-cache consumer are the useful partial result permitted by the task. The exact next target is in NEXT-CONSUMER.md.

The arbitrary terminal input does not derive its ordinary domain or height bound. Certification from the actual worker source builder remains open. The existing physical lookup transport is insufficient for that property. No successful-run depth, original-D producer, original ordered-prefix production, public API or Haskell correspondence follows. Generic Mu, Union, opaque values, and both complete workers remain outside this local result.

## Validation and provenance

No compiler, evaluator, native program, Haskell program, Git command, network operation, board operation, production edit, or child agent ran in this task. No Haskell defect or fix was established. There is no FINDINGS candidate.

The two OLD whole originals were named before acquisition. They are CachedTerminalAdapter635 and IncomingCacheAdapter245. Every other acquired source body is a named bounded cut. Acquisitions, exact original hashes, retained copies, declaration locators, cumulative original-path vectors, and incidents are retained. This task uses current production header cuts rather than a private provider body. Root's check status for the installed producers is reported as upstream evidence only.

The candidate's main elaboration uncertainty is its direct exhaustive `repeat (first | rfl | split)` proof of read_values. No compiler result is claimed. The remaining proof uses explicit current observations and standard constructor/case lemmas. Root may need proof-only tactic repairs. The intended public gates and conclusion are unchanged by that possibility.
