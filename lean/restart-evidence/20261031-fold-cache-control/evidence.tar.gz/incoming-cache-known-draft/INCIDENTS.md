An acquisition script named a nonexistent SourcePruningEnumerationIncomingFrame.lean metadata path. Its error branch mistakenly attempted an unrelated nonexistent path rather than recording the missing name. That attempt raised FileNotFoundError and acquired no source. The five preceding named locator acquisitions were already retained in the ledger. The original failed script remains available. No production file or sealed bundle changed.

A filename/date tool response exceeded the output budget and was truncated. It did not acquire a source body. The bounded date and filename checks were repeated.

A later read used three incorrect owner cut filenames. The three cat operations reported missing files and acquired no source. A bounded owner filename listing identified the retained cuts, which were then read by their actual names.
