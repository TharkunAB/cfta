# Actual terminal consumer still required

The next public law should compute the literal CachedTerminalAdapter.run result from its original terminal inputs. It should prove both the successful raw Core property and the returned-Some whole cache property at that result's exact Caller heap.

Retain these current entry predicates from the actual terminal admission: Context, Safe, Roots, canonical waiting correctness, original suspended-input bounds, InputsPending, PendingRealized, Available, incoming closedness, current KnownOrdinary, Fits, native Stored, the original heap guard, and Reserved for the original source count plus one incoming step. Keep all cache validity gates required by the actual consumer. The current incoming Node domain and height bound may remain explicit local value facts. Do not replace them with a claimed arbitrary source-builder producer.

For the actual terminal expression:

```lean
let actual := SourcePruningEnumerationCachedTerminalAdapter.run
  checkEmpty r n p h indexFuel first rest beforeCaller before
  incoming incomingScs memos.query
(match actual.1.1 with
 | .ok (some rows) =>
     ∀ fragment returned,
       Except.ok (fragment, returned) ∈ rows →
       KnownOrdinary bound actual.1.2.1.checked.native.machine.heap
         {before with core := returned}
 | _ => True) ∧
(match actual.2 with
 | some after =>
     KnownOrdinary bound actual.1.2.1.checked.native.machine.heap after
 | none => True)
```

These are conclusions of the original-input theorem. They must not become entry hypotheses.

The implementation must retain all literal branches:

1. Incoming Empty returns the original cache and no raw rows. Use the current bound directly.
2. Prefix error or unsupported shape returns an error and no cache. The successful-row/cache obligations are vacuous.
3. The successful actual prefix supplies joined values equal to original values. Derive that fact from the actual prefix body or its checked completion and uniqueness laws. Derive recorded-source pending and the reservation relation from this same observation.
4. The actual CachedFold empty-row branch may return Some cache. Use checked cached139 at its reached Caller heap. Its raw success has no Core rows.
5. The actual singleton fold branch uses checked endpoint163 to derive its current incoming admission. Derive that endpoint from the actual fold observation. Do not take it as an argument.
6. The incoming cache-None branch executes IncomingNode.run directly on the folded Core. Use checked IncomingKnown180 for raw Core rows. The returned cache is None.
7. The incoming Some-cache branch first frames the actual folded Core over the recovered cache. Its whole Known follows from the actual folded Core bound. Apply this bundle's closed run_known to the actual IncomingCacheAdapter.run. This includes its empty-raw Empty write.
8. Map each successful incoming Unit/Core row to the terminal hole-fragment/Core row using the actual map membership. Retain the exact returned Caller.

The source-builder domain/cap implication, full raw terminal closure, recursive worker preservation, successful-depth/original-resource producer, semantic accepted-output meaning, public ordered-prefix bridge, and signed/Haskell adapters remain separate obligations. This target does not supply any of them as a future invariant.
