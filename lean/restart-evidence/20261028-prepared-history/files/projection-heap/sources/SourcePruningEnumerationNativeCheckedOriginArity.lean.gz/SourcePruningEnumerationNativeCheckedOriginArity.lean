import MicroCFTA.SourcePruningEnumerationArityOrigins
import MicroCFTA.SourceEqualityNativeDemandAcceptedReceipt
import MicroCFTA.SourceEqualityNativeDemandMismatchProvenance
import MicroCFTA.SourceEqualityNativeDemandAcceptedReadback
import MicroCFTA.SourceCurrentAllocatedNativePhysicalTraceCompletion

/-!
# Projected arity of actual checked native edge returns

The ready prefix derives its own guard check.
The accepted worker retains its actual ordered child walk and returned state.
These results do not infer origins for every edge in a current Packet.
-/
namespace MicroCFTA.SourcePruningEnumerationNativeCheckedOriginArity
open Language Cache InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
open EnumerationState EnumerationCorrectness
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand SourceEqualityNativeDemandProvenance
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Allocated" => SourceEqualityConjoinAllocation.Constraint FullSyntax.Formula
local notation "top" => SourceEqualityConstraintConstructors.top (Formula := FullSyntax.Formula)
local instance : DecidableEq (SourceGuards.Guard FullSyntax.Formula) := SourceEqualityPCSNativeEdge.guardDecidableEq

/-- The actual ready result derives projected arity at its checked incoming child count. -/
theorem ready_fits
    (le : SourceGuards.Guard FullSyntax.Formula → SourceGuards.Guard FullSyntax.Formula → Bool)
    (first second combined : Allocated) (leftArity rightArity : Nat)
    (operations : SourceEqualityConstraintMemoAllocation.State)
    (valid : SourceEqualityConstraintMemoAllocation.Valid operations)
    (firstReady : SourceEqualityConstraintAllocation.Ready operations.constraints first.stored)
    (secondReady : SourceEqualityConstraintAllocation.Ready operations.constraints second.stored)
    (observed : (SourceEqualityIntersectionEdgeAllocation.run le first second
      leftArity rightArity operations).1 = .ok (.ready combined)) :
    SourcePruningEnumerationArityOrigins.Fits (SourceEqualityConjoinAllocation.readback combined) leftArity := by
  obtain ⟨branch, literal, sourceSame, _prefixValid, _growth, ready⟩ :=
    SourceEqualityIntersectionEdgeAllocation.run_correct le first second leftArity rightArity
      operations valid firstReady secondReady
  have branchSame : branch = .ready combined := Except.ok.inj (literal.symm.trans observed)
  subst branch
  obtain ⟨_combinedReady, cached, _physical⟩ := ready combined rfl
  have accepted : SourceEqualityMkEdgeAllocation.accepted
      (SourceEqualityConjoinAllocation.readback combined) leftArity = true := by
    change SourceEqualityIntersectionEdgeAllocation.Branch.ready
      (SourceEqualityConjoinAllocation.readback combined) = _ at sourceSame
    unfold SourceEqualityIntersectionEdgeAllocation.source at sourceSame
    split at sourceSame
    next _mismatch => cases sourceSame
    next _matched =>
      dsimp only at sourceSame
      split at sourceSame
      next kept =>
        have readbackSame := SourceEqualityIntersectionEdgeAllocation.Branch.ready.inj sourceSame
        rw [readbackSame]
        exact kept
      next _rejected => cases sourceSame
  have fits : SourceEqualityMkEdgeAllocation.fits leftArity
      (SourceCompactGuards.sourceEqualities (SourceEqualityConjoinAllocation.readback combined)) = true := by
    by_cases rejected : SourceEqualityMkEdgeAllocation.contradictory
        (SourceEqualityConjoinAllocation.readback combined) = true
    · simp only [SourceEqualityMkEdgeAllocation.accepted, rejected, ↓reduceIte,
        Bool.false_eq_true] at accepted
    · simpa only [SourceEqualityMkEdgeAllocation.accepted, rejected, Bool.false_eq_true,
        ↓reduceIte] using accepted
  obtain ⟨classes, source, rootBounds⟩ := (SourceEqualityMkEdgeArity.fits_exact leftArity
    (SourceCompactGuards.sourceEqualities (SourceEqualityConjoinAllocation.readback combined))).mp fits
  obtain ⟨canonicalProjection, _validTries, pathReadback, _meaning⟩ :=
    (source ▸ SourcePruningEnumerationConstraint.project_complete
      (SourceEqualityConjoinAllocation.readback combined) cached)
  intro tries residual projected start
  have triesSame : EnumerationEquality.readClasses classes = tries :=
    congrArg Prod.fst (Option.some.inj (canonicalProjection.symm.trans projected))
  rw [← triesSame]
  apply (fresh_arity_iff leftArity start (EnumerationEquality.readClasses classes)).mpr
  intro trie member index suffix path
  obtain ⟨paths, pathsMember, same⟩ := List.mem_map.mp member
  subst trie
  exact rootBounds paths pathsMember (index :: suffix)
    ((pathReadback paths pathsMember (index :: suffix)).mp path)

/-- Actual child receipts retain the full original accepted result and derive its fresh own arity. -/
theorem accepted_body_produced [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (formulas : SourceGuards.Formulas FullSyntax.Formula) (solver : SourceGuards.Entailment FullSyntax.Formula)
    (request : EdgeRequest Symbol Guard) (state after : SourceEqualityNativeDemand.State width)
    (first second combined : Allocated) (values : List (Value Symbol Guard)) (fuel : Nat)
    (valid : SourceEqualityConstraintMemoAllocation.Valid state.operations)
    (heapReady : SourceEqualityRequiredCache.Ready state.native.machine.heap)
    (inputs : EdgeReady state.native.machine request)
    (leftCached : SourceEqualityGuardReadback.Cached request.left.entry.key.constraint.equalities)
    (rightCached : SourceEqualityGuardReadback.Cached request.right.entry.key.constraint.equalities)
    (arity : request.left.children.length = request.right.children.length)
    (symbols : request.left.entry.key.symbol = request.right.entry.key.symbol)
    (left : SourceEqualityConstraintFieldLookup.load request.left.entry.key.constraint state.operations.constraints = .ok (some first))
    (right : SourceEqualityConstraintFieldLookup.load request.right.entry.key.constraint state.operations.constraints = .ok (some second))
    (accepted : (SourceEqualityIntersectionEdgeAllocation.run GuardStructuralOrder.le first second
      request.left.children.length request.right.children.length state.operations).1 = .ok (.ready combined))
    (walk : SourceEqualityNativeDemandChildWalk.Walk (SourceEqualityPCSGuard.holds formulas solver) request.domain
      (request.left.children.zip request.right.children)
      {state with operations := (SourceEqualityIntersectionEdgeAllocation.run GuardStructuralOrder.le first second
        request.left.children.length request.right.children.length state.operations).2} values after fuel) :
    let built := run (makeEdge request.left.entry.key.symbol (SourceEqualityConjoinAllocation.readback combined) values) after.native.machine.heap
    let final : SourceEqualityNativeDemand.State width := {after with native := advance after.native {after.native.machine with heap := built.2}}
    execute (fuel + 3) (.edgeBody request .pure) state = .done built.1 final ∧
      EdgeProduced (width := width) (SourceEqualityPCSGuard.holds formulas solver) final.native.machine request built.1 ∧
      SourceEqualityRequiredCache.Keeps state.native.machine.heap final.native.machine.heap ∧
      EdgeResident final.native.machine.heap built.1 ∧ built.1.children = values ∧ built.1.children.length = request.left.children.length ∧
      SourcePruningEnumerationArityOrigins.Fits built.1.entry.key.constraint built.1.children.length := by
  have original := SourceEqualityNativeDemandAcceptedReceipt.body_produced formulas solver request state after
    first second combined values fuel valid heapReady inputs leftCached rightCached arity symbols left right accepted walk
  have childEffects := walk.effects heapReady
  have fields := MergedPhysicalGroupEdges.makeEdge_fields after.native.machine.heap
    childEffects.1.ready.semantic.1.normal.facts request.left.entry.key.symbol
    (SourceEqualityConjoinAllocation.readback combined) values childEffects.2.2.1
  obtain ⟨firstReady, _firstFields⟩ := SourceEqualityConstraintFieldLookup.load_ready _ _
    valid.constraints leftCached first left
  obtain ⟨secondReady, _secondFields⟩ := SourceEqualityConstraintFieldLookup.load_ready _ _
    valid.constraints rightCached second right
  have checked := ready_fits GuardStructuralOrder.le first second combined
    request.left.children.length request.right.children.length state.operations valid firstReady secondReady accepted
  refine ⟨original.1, original.2.1, original.2.2.1, original.2.2.2.1,
    original.2.2.2.2.1, original.2.2.2.2.2, ?_⟩
  rw [fields.2.1, original.2.2.2.2.2]
  exact checked

/-- Final record coherence identifies the requested constraint and actual child count. -/
private theorem constructed_fields [DecidableEq (EdgeKey Symbol Guard)]
    (symbol : Symbol) (constraint : Guard) (values : List (Value Symbol Guard))
    (heap : InternedConstructorTemplates.State Symbol Guard)
    (coherent : InternedRecordCoherence.Coherent (run (makeEdge symbol constraint values) heap).2) :
    let result := (run (makeEdge symbol constraint values) heap).1
    result.entry.key.constraint = constraint ∧ result.children.length = values.length := by
  let key : EdgeKey Symbol Guard := ⟨symbol, values.map Value.referenceOf, constraint⟩
  let candidate := EdgeValue.mk (Cache.intern heap.edges key).1 values
  obtain ⟨stored, present⟩ := Cache.keepFirst_present heap.edgeRecords key candidate
  have recorded : (run (makeEdge symbol constraint values) heap).2.edgeRecords key =
      some (run (makeEdge symbol constraint values) heap).1 := by
    simp only [makeEdge, run, edgeStep, key, candidate, present, Option.getD_some]
  have fields := (coherent.edges key _ recorded).2
  refine ⟨congrArg EdgeKey.constraint fields.1, ?_⟩
  simpa only [key, List.length_map] using congrArg List.length fields.2

/-- A returned physical body derives arity from its own raw child walk and checked prefix. -/
theorem accepted_receipt_fits [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (request : EdgeRequest Symbol Guard) (state : SourceEqualityNativeDemand.State width)
    (first second combined : Allocated)
    (initial : SourceCurrentAllocatedNativePhysicalCompletion.Good state)
    (inputs : EdgeReady state.native.machine request)
    (left : SourceEqualityConstraintFieldLookup.load request.left.entry.key.constraint state.operations.constraints = .ok (some first))
    (right : SourceEqualityConstraintFieldLookup.load request.right.entry.key.constraint state.operations.constraints = .ok (some second))
    (accepted : (SourceEqualityIntersectionEdgeAllocation.run GuardStructuralOrder.le first second
      request.left.children.length request.right.children.length state.operations).1 = .ok (.ready combined))
    {count : Nat} {result : EdgeValue Symbol Guard} {after : SourceEqualityNativeDemand.State width}
    {post : Machine Symbol Guard → EdgeValue Symbol Guard → Prop}
    (receipt : SourceCurrentAllocatedNativePhysicalTraceCompletion.Receipt count
      (.edgeBody request .pure) state result after post) :
    ∃ values middle childCount, childCount + 1 < count + 1 ∧
      SourceEqualityNativeDemandWalkExecution.Walk (fun pair => requestNode request.domain pair.1 pair.2)
        (request.left.children.zip request.right.children)
        {state with operations := (SourceEqualityIntersectionEdgeAllocation.run GuardStructuralOrder.le first second
          request.left.children.length request.right.children.length state.operations).2} values middle childCount ∧
      result = (run (makeEdge request.left.entry.key.symbol (SourceEqualityConjoinAllocation.readback combined) values)
        middle.native.machine.heap).1 ∧
      after = {middle with native := advance middle.native {middle.native.machine with heap :=
        (run (makeEdge request.left.entry.key.symbol (SourceEqualityConjoinAllocation.readback combined) values)
          middle.native.machine.heap).2}} ∧
      result.children.length = request.left.children.length ∧
      SourcePruningEnumerationArityOrigins.Fits result.entry.key.constraint result.children.length := by
  have arity : request.left.children.length = request.right.children.length := by
    by_cases same : request.left.children.length = request.right.children.length
    · exact same
    · have impossible := congrArg Prod.fst
        (SourceEqualityIntersectionEdgeAllocation.run_mismatch GuardStructuralOrder.le first second
          request.left.children.length request.right.children.length state.operations same)
      rw [accepted] at impossible
      cases impossible
  obtain ⟨values, middle, childCount, bounded, walk, resultSame, afterSame⟩ :=
    SourceEqualityNativeDemandAcceptedReadback.body_observation request state after first second combined
      (count + 1) result arity left right accepted receipt.done
  have coherent : InternedRecordCoherence.Coherent
      (run (makeEdge request.left.entry.key.symbol (SourceEqualityConjoinAllocation.readback combined) values)
        middle.native.machine.heap).2 := by
    simpa only [afterSame, advance] using receipt.good.heap.semantic.1.normal.facts.coherent
  have fields := constructed_fields request.left.entry.key.symbol
    (SourceEqualityConjoinAllocation.readback combined) values middle.native.machine.heap coherent
  have lengthSame : result.children.length = request.left.children.length := by
    rw [resultSame, fields.2, walk.length, List.length_zip, arity, Nat.min_self]
  obtain ⟨firstReady, _firstFields⟩ := SourceEqualityConstraintFieldLookup.load_ready _ _
    initial.operations.constraints (initial.fields _ _ inputs.2.1).1 first left
  obtain ⟨secondReady, _secondFields⟩ := SourceEqualityConstraintFieldLookup.load_ready _ _
    initial.operations.constraints (initial.fields _ _ inputs.2.2).1 second right
  have checked := ready_fits GuardStructuralOrder.le first second combined
    request.left.children.length request.right.children.length state.operations initial.operations firstReady secondReady accepted
  refine ⟨values, middle, childCount, bounded, walk, resultSame, afterSame, lengthSame, ?_⟩
  rw [lengthSame, resultSame, fields.1]
  exact checked

end MicroCFTA.SourcePruningEnumerationNativeCheckedOriginArity
