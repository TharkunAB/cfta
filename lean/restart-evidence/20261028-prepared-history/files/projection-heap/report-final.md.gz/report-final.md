# Final projection-heap review

CLEAR for the bounded original-construction, checked-emission and completed rich-query proof scope. The whole Parent worker and recursive-history attachment remain open. No new required Haskell fix was established. No whole-driver soundness or accepted-output coverage upgrade is claimed.

The source checkpoint is c2447659a54c163c679fc5e17917c414b6aa7906, as recorded by Root. This reviewer made no repository, compiler, build, native, Git, network or board operation. All writes are confined to this fresh projection-heap subtree.

## Original property and exact construction packet

SourceChecked is the existing original source syntax admission. Each literal edge retains its cached payload check and accepted constructor test at its original child count. source_allowed, source_many_allowed and source_edges_allowed derive the existing Allowed predicates for project!=none by mutual syntax induction. They do not assume a global heap or future selector support.

The existing AnnotationConstruction.build then preserves that derived property through all nested children, discarded alternatives, binder probes, fresh binder construction, canonical hits and actual pending outcomes. constructed_projectable derives the whole physical edge-key property at the SAME empty-cache build result. closed_projectable retains the full old annotation producer result: the actual build equation, whole Heap and semantic Annotated fields. Its result specialization is checked in contracts/closed-contract-comparison-v2.json. SourceChecked remains an explicit original admission; it is not derived from arbitrary Context, Ready or Packet.

## Actual checked construction and native queries

CheckedProjectionHeap uses the actual accepted boolean. The accepted branch emits the checked original guard; rejection emits the actual Top sentinel. build_heap derives the actual work from original valid equality operations and original stored-field Ready. Receipt.preserves_projection_heap identifies the SAME actual returned native heap. These original readiness inputs remain explicit. No final heap, desired result, arbitrary extension law or unconditional conjunction property is supplied.

The native node/query proofs use actual SourceEqualityNativeDemand functions and the existing rich physical Trace. The eight transferred operational headers retain their original Good, equality-instance, fuel, physical-input and completed-trace admissions. The intentional property change is from numeric key/count arity to guard projectability. Exact source-surface comparisons and old headers are retained in contracts/native-query. They do not claim that the old numeric predicate is unchanged.

The rich body observer exposes the actual Top sentinel or actual accepted construction. In the accepted branch, run_correct derives accepted=true for the precise combined guard. accepted_projectable then proves projection succeeds for the guard actually emitted. The actual ordered child Walk threads every reached intermediate heap. Node and union work emits no fresh guard. Optional binders use existing stored-syntax annotation preservation with Available from the current rich-trace input and Facts from the same Good state. Actual lookup, hits, demand and finish frames preserve the native heap.

Local Walk, compiler and request-frame lemmas retain explicit smaller-call hypotheses. Final node_query_heap and edge_query_heap discharge both call families by strong induction on actual trace length. Their full printed inputs are the original request/states/value/fuel, Good before, original whole projectability Heap and the SAME completed rich Trace. They have no child heap oracle, endpoint heap premise, future continuation law, semantic model or universal raw-conjoin closure. The memo corollary uses the actual returned resident edge at this SAME query endpoint.

This proves whole returned-heap projectability for completed checked rich node and edge queries. It does not cover every failed, pending, blocked or exhausted prefix. A bare raw .done is not promoted to a rich trace. SelectedValue.run_heaps already preserves a genuinely established original annotation property through every normalization outcome, with its original SemanticReady, Available, CostHeap and ProbeHeap inputs. Those inputs and a full allocated Caller context are not inferred from the new closed-source theorem alone.

## Remaining integration and rejected route

The complete Parent receipt identifies its final checked constructor. It does not by itself establish the whole property at the local-reduction middle heap. All actual smaller workers and then every relevant history transition still need attachment. Generic Keeps or Post cannot establish an arbitrary property for newly created keys. Initial constructor provenance and completed-query preservation are complementary results, not a proof that every current Parent or output history already carries the invariant.

The old generic annotation theorem requires forall first second, annotation(conjoin first second). For project!=none, that unconditional premise is false. A raw first constraint with equalities=none conjoined with Top retains none; sourceEqualities and project remain none. The old raw compileEdge annotation proof asks for precisely that conjunction fact. Cached representation admits none and does not repair this gap. The new proofs follow the genuine checked accepted/sentinel branches instead. This is a proof-interface boundary, not a checked-runtime counterexample or Haskell defect. Earlier frozen counterexamples and Haskell repair scopes remain unchanged.

## Exact final sources and failed lineage

All four assigned installed sources equal the immutable owner draft and actual passing strict snapshot:

- ProjectionHeap v2: 89 lines, 4677 bytes, SHA256 928cfc4b237c754a15403bf332d9d8f059d38da68480a88bf316cf58e4acb9f4.
- CheckedProjectionHeap v1: 111 lines, 7060 bytes, SHA256 8752193a29f8423aff286ac6c975144800912b3ad54b3d231d1b3ef645e103e1.
- NativeNodeProjectionHeap v2: 277 lines, 17224 bytes, SHA256 da7e9fade9bd88a64cbbcdddcd94308f94a19d5fad6369e92987a6ccbd710d75.
- NativeQueryProjectionHeap v2: 336 lines, 21887 bytes, SHA256 d09aa479ef4b8a3b8e5216576c2a88d83e0d13a5433393e2387446d0774ba87d.

Each final strict check exits zero with empty raw output. ProjectionHeap v1 failed because its well-founded Allowed definitions needed their actual equations before constructor proofs. V2 changes only unfolding. NativeNode v1 failed on unused EdgeKey equality scopes in six private helpers. V2 moves the instance declaration to actual runtime/trace methods; proof bodies and public headers remain unchanged. Both complete failed logs were read and retained. No omit, linter suppression, raised proof limit, placeholder or custom axiom was added.

NativeQuery v1 had a missing local Allocated alias found during source review. V2 adds that original type alias and corrects a stale comment. No Root compiler failure is claimed for that untested predecessor. Historical initial reports and status files keep their original pending wording. This report and the checked snapshots record the final PASS results. All immutable variants and patches remain.

## Public, check and document evidence

All 21 assigned complete public blocks were read: 40305 bytes, including every axiom list. They contain only propext, Classical.choice and Quot.sound. Each matches its literal indexed appendix slice and occurs once in the final actual public output. The other eight new declarations and four new definitions are assigned to other bounded reviews; this reviewer does not claim whole reading of those sources or the full appendix.

Full public output is 2256710 bytes, SHA256 da3b4f685a03e45a27e8a657a7be80e0bdb20db45c47efe3b35f5b05b311af2f. The complete prior 2141917-byte output is an exact prefix. Public validation reports 511 theorem blocks, 48 printed definitions, 29 new theorems, four new definitions, standard axioms only and no elision. Full output and prior output are captured for replay.

Root's records show eight modules and nine final strict checks including Audit pass. Audit reports 4409 jobs and 81113 theorem dependencies. Existing raw/report bytes, hashes, exits and measured memory.max=memory.high=4294967296 and memory.swap.max=0 were checked for 17 current compiler/build/public commands and one inherited public receipt. Four current failed attempts remain. Only the two owned failed logs are claimed read in full here; the other two belong to Root's SelectedInvocation review. The source validator reports 4400 prior non-Audit Lean, 249 strong and 810 Haskell source/evidence identities unchanged. These are supplied validation results, not a claim that every prior source was read independently.

The WHOLE final 10627-byte notes-current-prepared-history.md was read. SHA256 is 0976742cca6f02545de23991ef75323abcef2f0c8f2e74b9eb241c9992d988ca. The WHOLE current common insertion, 2592 bytes, and FINDINGS insertion, 5752 bytes, were read. All nine actual regions were checked against current repository files. Removing each exact insertion at its recorded offset recovers the complete prior document bytes. The large old bodies were checked by byte inverse and were not read in full.

The only final insertion correction replaces the broad phrase about no required Haskell fix with the precise statement that no new required Haskell fix was established. Both earlier insertion versions and the exact one-change comparison remain. The note is unchanged. The new text keeps SourceChecked provenance, checked emission, completed rich-query scope, unresolved whole-parent/history attachment, original policy gates, original/prepared value distinction, finite-depth limitation and physical Haskell boundary explicit. No material concern was found within this assigned scope. Broader output-history/depth claims are not independently re-proved by this owner.

The source index has 35 whole/cuts records and 59 literal cuts with explicit reading scopes. Copied whole sources do not imply whole reading. Final source/copy/cut, strict-snapshot, public-prefix, assigned-block, contract and document-inverse checks pass. The manifest covers every payload in this subtree. The final seal records WRITE HALT. No later writes are authorized here.
