from pathlib import Path
import hashlib
import json

r = Path('/home/tritlo/Code/mcfta')
a = Path('/tmp/mcfta-prepared-history-20261028')
head = (a / 'source-head.txt').read_text().strip()
public = json.loads((a / 'public-validation.json').read_text())
source = json.loads((a / 'source-validation.json').read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


common = f'''
## Prepared output histories and native projection support

Source checkpoint: {head}.
Conditional finite-pruning language preservation and prepared finite-depth
resource closure remain. Every output of the actual prepared driver now has
an operational recursive history. This includes outputs before a later stop.
The history records actual preparation, ordinary or opaque dispatch, false
fragment recording and the same smaller-depth restart. The history theorem
needs no semantic model, resource packet or future completion premise.

Original checked source construction now derives a projectable native heap.
Checked edge construction and completed native node and edge queries preserve
that whole-heap property. The query induction derives the smaller-query facts.
It does not assume arbitrary conjunctions support projection. Application to
the whole parent worker and every recursive history remains open.

A new backward soundness helper keeps the original stored value separate
from its prepared ordinary parent. It retains the old ordinary-branch gates
and final satisfying-assignment premise. Actual preparation supplies the
required language equivalence, but no installed history composition passes
that receipt to the helper yet. A separate completed-head resource receipt
retains the actual caller, full Memos, both cache packets and prepared-parent
indexes. It preserves the old head producer and its smaller-depth Complete
premise. These results do not prove whole-driver output soundness or coverage.

The largest gaps are semantic composition through all actual histories and
an original sufficient depth bound for ALL earlier reachable callbacks.
Fresh variable IDs do not change recursion keys. A narrowed Union need not
insert its original key. Equality normalization can increase path length.
Use the existing finite saturation domain as a starting point for a global
carrier proof. No complete admitted divergence example has been established.
Public APIs, ranking, sampling and physical Haskell correspondence remain open.
Whole-CFTA goal ACTIVE; checkpoint PROGRESS. No new required Haskell fix
was established.

Eight modules add 29 public theorems and four definitions. Nine final strict
checks pass. Full Audit passes 4409 jobs and checks 81113 theorem dependencies.
Public readback has 511 theorem blocks and 48 definitions. Its complete prior
2141917-byte output is an exact prefix. All 4400 prior non-Audit Lean, 249 strong
and 810 Haskell source/evidence files retain bytes.
Details: lean/notes-current-prepared-history.md.

'''
findings = common + '''### Haskell comparison and external integration handoff

No Haskell or Cabal file changed. No Haskell test or benchmark ran.
No new Haskell defect or required repair was established. Keep the integrated
LPO and KBO Natural-weight fixes and all earlier counterexamples below.
The refreshed main tip d1ca06a1dd0c7488205feda613b529df21a08669 is an ancestor
of this source checkpoint. This checkpoint requests no Haskell patch.

The native projection result uses original checked constructor provenance.
Completed rich node and edge query traces preserve the whole projectable
heap. Actual accepted checked construction provides a successful accessor;
the rejected empty-edge sentinel also supports projection. No unconditional
closure law for raw conjoin is assumed. The earlier raw interner example
remains valid. Native Ready and Cached annotations alone remain insufficient.
Whole parent preparation and recursive-history attachment still need proofs.

The depth audit compares the actual Haskell CPS order and formal worker.
An earlier stopped callback omits later siblings. More work fuel cannot fix
the literal exhausted expand case at zero recursive depth. The existing
finite-depth resource result permits that stop. It supplies no sufficient
original recursive depth for the whole earlier search tree.

EnumerationState.recursionKey and Haskell recursionKey omit suspended UVar IDs.
Fresh IDs alone cannot evade repeated-key parking. The earlier A=f(A)|a
proposal also fails as a divergence example: an unconstrained Mu child is
not expandable. Repeated keys clear the bucket or park the work.

Do not count every original Union visit as an inserted ancestry key.
Both implementations check repetition before narrowing. Narrowing can replace
the Union with an ordinary node. Entry then reads that current ordinary value
and inserts no original Union key. Mu remains exempt from that narrowing.
This is an obstruction to a proposed proof measure, not a proven runtime fault.

Do not bound future paths by the longest original path alone. Congruence
combination of classes {[0],[1,0]} and {[0,0],[2]} can add [1,0,0]. This is a
source-definition calculation, not an executed full admitted counterexample.
EqualityTermination.bounded_state and saturationDomain already give a finite
gap/anchor/alphabet domain for one normalization. Derive one ORIGINAL domain
through allocation, descent, constraint combination and native reconstruction.
Also derive a finite carrier for future recursive native identities and a
progress measure for Union and ordinary phases. None is established here.

The prepared captured soundness helper still assumes Canonical, nonterminal
inherited constraints, fresh projected arity and retained-child conditions.
It observes a stable actual completed family and a satisfying final cache.
The source/prepared equivalence is explicit in that local helper. Use the
same actual SelectedPreparation receipt to supply it during composition.
Transport the stored lookup and parent availability through actual Keeps.
Do not infer that equivalence from HeadAdmission alone or identify the
original source handle with the prepared parent.

'''
(a / 'document-insertions').mkdir(exist_ok=True)
(a / 'document-insertions/common.md').write_text(common)
(a / 'document-insertions/findings.md').write_text(findings)
records = {}
for p in sorted((a / 'prior-documents').rglob('*.md')):
    rel = p.relative_to(a / 'prior-documents')
    old = p.read_bytes()
    insertion = (findings if str(rel) == 'FINDINGS.md' else common).encode()
    first, rest = old.split(b'\n', 1)
    new = first + b'\n' + insertion + rest
    assert new.replace(insertion, b'', 1) == old
    (r / rel).write_bytes(new)
    records[str(rel)] = dict(before_sha256=sha(old), after_sha256=sha(new), inserted_bytes=len(insertion))
(a / 'document-inverse.json').write_text(json.dumps(records, indent=2) + '\n')

modules = json.loads((a / 'modules.json').read_text())
note = f'''# Prepared output histories and native projection support

Source checkpoint: {head}. Whole-CFTA goal ACTIVE. Checkpoint PROGRESS.
The four proof commits are published on formalize. The evidence commit follows.

## Strongest current statement

Under the recorded admission, resource, selector and policy conditions,
finite pruning preserves the represented language. At every finite recursive
depth, prepared enumeration has one stable resource-certified actual outcome
at all sufficiently large work fuels. Stops and exhaustion remain permitted.
Constructive model and original-subtree proofs cover the recorded startup,
preparation, branch, sibling-event and recording stages. Every actual prepared
driver output now has an operational recursive history, including outputs
retained before a later stop. These are component results. Whole-driver
output soundness and original accepted-output coverage remain open.

## Operational history

SelectedContinuations.Invocation records the actual preparation pair. It keeps
the original decoded value separate from the prepared result. Dispatch tests
terminal constraints first. It then uses the actual prepared ordinary rows or
the actual opaque dispatch. Every output of an actual complete or stopped fold
comes from one of these real hook invocations.

PreparedRecursive.OutputHistory records supplied stop and done outputs, actual
parked restarts and actual selected invocations. Selected history records the
literal false recordTypes result and the same smaller-depth resume frame.
The resume_output_history and run_output_history theorems cover every work
fuel, recursive depth and actual output. No resource, model, admission,
Complete or future success predicate is an input to this extraction.
Resource and semantic decoration of the entire history remains separate work.

## Original projection support

ProjectionHeap derives Allowed, ManyAllowed and EdgesAllowed from the original
SourceChecked predicates. It retains each accepted original child-count check.
Actual construction from the empty heap derives successful projection for
every resident edge. The closed theorem retains the complete old actual-build,
Heap and Annotated result.

CheckedProjectionHeap preserves the whole native heap through accepted checked
edge construction and the actual rejected sentinel. Its Receipt law uses the
same returned native heap. NativeNodeProjectionHeap and NativeQueryProjectionHeap
then prove the whole-heap property through completed rich node and edge queries.
Strong induction on actual query fuel derives all shorter query obligations.
Actual ready construction supplies accepted=true for the combined constraint.
No arbitrary raw-conjoin projection law or future endpoint heap is assumed.
The final query theorems retain the original Good, actual completed rich Trace,
fuel and equality-instance arguments. They make no claim about incomplete
native query prefixes. Whole parent-worker and history attachment remain open.

## Prepared backward meaning and resource receipts

CapturedEdge.stable_complete_sound_prepared generalizes the old ordinary
helper to a separately available closed prepared parent. The original stored
handle still decodes to its own source value. A universal language equivalence
connects that source value with the actual prepared parent. The proof restores
the original slot and the entire old semantic conclusion. It also returns
acceptance by the original source value.

This is a local backward theorem. It still requires a satisfying completed
cache and a stable actual completed run family. The old Canonical, nonterminal,
fresh projected arity and retained-child gates remain. Its language equivalence
is an explicit local argument. SelectedPreparation.complete supplies that fact
from the same actual preparation. No installed history composition passes it
to this helper yet. Lift the old handle lookup and parent availability through
the actual Post effects; do not infer equivalence from resource admission.

PreparedNativeHookResources.HeadAdmission indexes the original slot, handle and
suspended bucket separately from the actual prepared parent and selected edge.
CompletedHeadReceipt retains its full actual Post, full Memos/query equality,
captured and completed cache Packets, admission, pending references, fragment
history, allocation bounds, Fits, known guards, projection and stable run.
The new producer calls the old head producer once. It retains its complete
old result before the appended completion observer. Its original smaller-depth
Complete induction hypothesis remains. It supplies no output semantic model.

## Missing global depth argument

The ordered worker evaluates earlier callbacks before later sibling rows.
An earlier stopped callback omits the suffix. Increasing work fuel does not
remove an exhausted expansion at recursive depth zero. The chosen accepted
term's height cannot bound every earlier callback. The existing histogram
theorem assumes CompleteGraph and excludes recursive graph nodes. It proves
a model path, not termination of every earlier search branch.

Fresh suspended variable IDs do not affect the actual recursion key. Empty
recursive buckets disable expansion, and repeated keys clear or park work.
These facts invalidate the simple fresh-ID and A=f(A)|a divergence proposals.
No complete admitted all-depth divergence example was constructed.

A global measure must account for Union narrowing. The original Union is
checked before narrowing; entry can later see an ordinary rebuilt node and
insert no original Union key. Thus a key-count decrease for every pre-prefix
boundary is unavailable. Mu is exempt from this narrowing. Ordinary and Union
stretches need a separate progress argument.

Equality normalization can create paths longer than every original path.
The classes {{[0],[1,0]}} and {{[0,0],[2]}} can generate [1,0,0]. This is a
source-definition calculation, not an executed admitted counterexample.
EqualityTermination already proves a finite gap/anchor/alphabet saturation
domain for one normalization. Derive a single original domain through all
actual allocation, child descent, constraint combination and reconstruction.
Also derive a finite original carrier of reachable recursive native identities.
Neither whole-driver carrier theorem is present. The audit retains exact
source cuts, rejected approaches and scope limits in depth-audit/report.txt.

## Validation and preservation

Eight modules add 29 public theorems and four definitions:

'''+''.join('- MicroCFTA.' + module + '\n' for module in modules)+f'''
All nine final strict checks pass with warningAsError=true and linter.all=true.
Full Audit passes 4409 jobs and checks 81113 theorem dependencies. Seventeen
current compiler/build/public commands and one inherited public receipt are
retained. Four failed strict attempts remain with complete logs and drafts.
All actual commands run serially with measured memory.max=memory.high=
4294967296 and memory.swap.max=0. No proof limit was raised. No linter was
disabled. New proof code has no sorry, admit, custom axiom or native_decide.
The build replays one unchanged old unused-variable warning. Final new-module
strict outputs are empty. Strict Audit reports only its checked count.

Public readback contains 511 complete signatures and axiom lists, plus 48
printed definitions. Only propext, Classical.choice and Quot.sound occur.
The complete prior 2141917-byte output is an exact prefix. No elision occurs.
Full readback: {public['bytes']} bytes, SHA256 {public['sha256']}.
New appendix: {public['new_bytes']} bytes, SHA256 {public['new_sha256']}.
Named owners read the complete assigned public blocks. Root read each new
source, final corrective diff and failed compiler log. Source/public review
records state their exact scope; a copied whole source is not a whole read.

All 4400 prior non-Audit Lean, 249 strong and 810 Haskell source/evidence files
retain exact bytes. Audit adds imports before its complete previous body.
Nine documents retain their old bodies after the recorded insertion is removed.
No Haskell/Cabal file changed. No Haskell test or benchmark ran. No new Haskell
defect or required repair was established. FINDINGS retains the integrated LPO
and KBO Natural repairs. The refreshed main tip is already an ancestor.

Failed attempts are preserved. SelectedInvocation v2 exposed an ambiguous
State and an unused equality instance. v3 exposed an invalid doc-comment/omit
placement and the strict omit linter. v4 uses short instance sections.
ProjectionHeap v1 needed the actual Allowed equations before induction steps.
NativeNodeProjectionHeap v1 exposed an unused EdgeKey equality instance in six
private proof helpers. v2 narrows the instance scope. No contract was weakened.
Untested predecessor drafts remain separate from actual failed compiler runs.

## Restart and evidence

Raw evidence: /tmp/mcfta-prepared-history-20261028.
Archive: lean/restart-evidence/20261028-prepared-history.
Each actual command retains tested sources, raw output, exit code, hashes and
measured limits. Review bundles retain source identities, literal cuts and
contract comparisons. The manifest includes every frozen payload. It records
stored and raw hashes. Large or whitespace-sensitive files use deterministic
gzip. The verifier checks exact sets, prior source/public preservation,
document inverses, command limits, reconstruction and committed archive bytes.
All earlier areas remain frozen. Use a fresh area for the next checkpoint.

Next: attach resource and semantic facts to the actual prepared history. Use
the same preparation receipt to connect the original value and prepared parent.
Preserve opaque and terminal outputs. Derive ordinary branch gates from real
receipts where possible. Separately derive original path and recursive identity
carriers before removing earlier callback stops. Keep original selector,
annotation-admission and subtree-policy conditions explicit. Public APIs,
ranking, sampling and physical Haskell correspondence remain open.
The whole formalization is not complete. The whole-CFTA goal remains ACTIVE.
'''
(a / 'root-review').mkdir(exist_ok=True)
(r / 'lean/notes-current-prepared-history.md').write_text(note)
(a / 'root-review/notes-current-prepared-history.md').write_text(note)
print(json.dumps(dict(documents=len(records), note_bytes=len(note.encode()), common_bytes=len(common.encode()), findings_bytes=len(findings.encode()))))
