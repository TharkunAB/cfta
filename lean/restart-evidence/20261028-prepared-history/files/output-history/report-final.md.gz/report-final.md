# Prepared actual output history and rich head receipt

Status: CLEAR within the assigned scope. Whole-CFTA goal ACTIVE. This report does not claim whole-driver soundness, accepted-output coverage, or an original sufficient recursive depth. Review completed on 2026-10-28 CET against source checkpoint c2447659a54c163c679fc5e17917c414b6aa7906. Root owns compiler, build, repository and publication operations. This owner made no compiler call or repository mutation. The archive and evidence publication remain Root's work after this review.

## Source and proof scope

The owner read the whole final SelectedInvocation, PreparedOutputHistory and PreparedHeadAdmission sources. The canonical source-index.json records 27 whole provenance copies and 39 exact literal line cuts, including the whole final checkpoint note. Every whole copy matches the current source. Every cut has valid inclusive line bounds and exact bytes. Each entry states its semantic review scope. Partial reads of other whole copied sources remain explicitly partial; a copy is not a whole-source review.

SelectedContinuations.Invocation retains the exact actual SelectedPreparation.run pair. Its original target, stored handle, suspended constraints and decoded source remain separate from the actual prepared value and native heap. It uses the actual advanced Caller and framed entered cache. Terminal dispatch precedes ordinary shape. Ordinary dispatch uses the current prepared parent's actual rows and the existing ordered hook Invocation. Opaque and terminal paths retain their actual complete receipt. The generic extraction proves that each actual folded output came from a real hook invocation. Both complete and stopped hook outcomes retain their emitted outputs. It assumes no supplied future invocation or successful aggregate fold.

PreparedRecursive.OutputHistory is a genuine relation for the new worker. Its stop and done cases retain literal output singletons. Its parked case retains actual prefix execution and the actual framed smaller-depth restart. Its selected case retains actual narrowed prefix execution, actual selected Invocation, literal false recordTypes execution and the exact smaller-depth new resume frame. The callback and finish proofs use the new Failure, continueWith and finish, rather than identifying them with the old worker. The resume_output_history and run_output_history theorems cover each actual output at every work fuel and recursive depth. Outputs before a later stop remain covered. These theorems take no Packet, model, resource Complete, admission, final discharge or future success premise.

This is an operational history. It does not itself retain full Memos, intermediate resource Packets, or backward semantic laws. The old ResourceHistory, WithArity, carrier and rendering results do not transfer to it by identity. The earlier design reports that marked these needs open remain historical records.

The rich prepared HeadAdmission indexes original uv/handle/scs separately from prepared parentEntry/storedEdges/depth/free/edge. It retains the actual source Packet, Ready, IncomingAvoid, Fits, guard Heap and original stored-slot equation. Prepared parent availability, closedness and selected membership are separate fields. The exact edge-cost reservation comes from the existing packet and HeadReserved facts.

CompletedHeadReceipt retains that same admission, actual Post to the reached Caller, FULL returned Memos and saved-query equality, both the captured and completed cache Packets, admission, pending references, fragment history, allocation bounds, Fits, known guards, allowed/projected facts and the stable actual CapturedEdge run at the same diagonal bound. The wrapper calls the original prepared head producer once. It fixes all original existential operational/resource witnesses before appending the actual-completion observer. Unsupported and callback alternatives remain in the original packet. No output semantic model is an input.

The entire original prepared finite head declaration recovers literally after undoing the new theorem name and removing only the appended observer: 4615 bytes, SHA256 d1d0b4332770bbc4818c182a7dbe54e5d127651857f72f01cf383cd410598127. The comparison includes every original input binder, existential witness and result field. In particular, its existing smaller-depth PreparedRecursive.Complete induction hypothesis REMAINS. This helper is not advertised as an unconditional global finite-history producer.

Resource admission does not equate the original source with the prepared parent. A separately available prepared parent could be unrelated to the stored source. Actual SelectedPreparation provides the language equivalence. Root has now proved the separate local prepared backward helper, but no installed full-history composition supplies this same preparation equivalence to that helper yet. This owner did not claim whole-source review of Root's separate backward theorem or the projection family.

## Exact final source identities

- SelectedInvocation: 160 lines, 9454 bytes, SHA256 4ec94612025fd51b4873b9d117d1e6625c6f75e59a45c796277091c1d8d61ff5.
- PreparedOutputHistory: 222 lines, 14639 bytes, SHA256 3148bb137069d3cba43593f438cec240cc80140c49713e17348be740ec0c2eac.
- PreparedHeadAdmission: 277 lines, 18903 bytes, SHA256 3ae193af46602e83dea29096acd3687ad0daee8e09acc414f5b0a77ebf4ccc7f.

The history's immutable v1 is untested historical material. V2 adds the explicit Output namespace import and passes its first actual strict check with empty output. The receipt's immutable v1 passes its first strict check with empty output. Both candidates match tested snapshots and installed sources exactly. Historical UNTESTED and OPEN status files remain unchanged; the final checked records and this report supersede their status.

SelectedInvocation's initial candidate is retained as untested. Actual v2 and v3 failed strict checks with 1085-byte and 1236-byte logs. V4 fixes State/instance scope and doc-comment/omit placement, then passes with empty output. The initial source, corrective diff, tested snapshots, reports and raw logs remain. The two unrelated projection-family failed attempts also remain in the final command evidence. Root read every failed log. This owner does not claim whole semantic review of those unrelated failures.

## Whole assigned public review

All 11 assigned blocks were read in full: four printed definitions and seven complete theorem signatures with axiom lists, totalling 66605 bytes and 932 lines. public-read-scopes-v1.json records each exact hash, appendix offset and full raw-log byte/line interval. Every interval and copied block verifies against the authoritative public output.

These are Invocation, OutputHistory, HeadAdmission and CompletedHeadReceipt; receipt_output_invocation, output_invocation, continueWith_output_restart, finish_hook_outputs, resume_output_history, run_output_history and head_finite_complete_resources_with_receipt. The printed definitions retain complete constructor and field bodies. The prints preserve actual outcomes before later stops, separate original/prepared indexes, same receipt/Caller/cache witnesses and the unchanged Complete IH.

Each theorem uses only a subset of propext, Classical.choice and Quot.sound. receipt_output_invocation and finish_hook_outputs list propext only. The other five assigned theorem lists use the standard three axioms. No custom axiom or elided statement occurs. No other new public block is claimed semantically read here.

The full public receipt passes with 2256710 bytes, SHA256 da3b4f685a03e45a27e8a657a7be80e0bdb20db45c47efe3b35f5b05b311af2f. Its complete inherited 2141917-byte output is an exact prefix. The new 114793-byte appendix has SHA256 4e21c05377c3dbcdc0e8e6eb65c1fc071c4bbc101e8a316ae9c46bb1fbe5c9e4. The validator reports 511 theorem blocks, 48 printed definitions, 29 new theorems and four new definitions. Full raw output is preserved as provenance; only the assigned 11 new blocks are claimed semantically read.

## Checks and preservation

The final record contains 17 current compiler/build/public commands and one inherited public receipt. Four actual strict failures remain with their full logs and tested sources. All nine final strict checks pass, including strict Audit. Full Audit passes 4409 jobs and checks 81113 theorem dependencies. The build replays one unchanged old unused-variable warning. Standalone strict checks use fatal warnings and all linters; their final new-module outputs are empty. Strict Audit emits only its 56-byte count.

Every command report and raw log was copied and hash-checked. Source hashes match retained tested snapshots. Measured memory.max and memory.high are 4294967296, with memory.swap.max=0, for all 18 receipts. Root ran the actual commands serially. command-verification-final.json records the exact command identities and distinguishes the inherited receipt from current commands. integration/v1 preserves the earlier validator revision; integration/final preserves the authoritative 17-plus-1 denominator.

The final source validator passes for eight new modules and preserves 4400 prior non-Audit Lean files, 249 strong source/evidence files and 810 Haskell files. Its source hash record matches the checked final modules. The owner verified its relevant exact source/check copies. This report does not substitute those counts for whole-driver correctness. No Haskell or Cabal file changed, no Haskell test or benchmark ran, and no new required Haskell fix was established.

## Documentation review and inverses

The WHOLE final notes-current-prepared-history.md was read: 10627 bytes, SHA256 0976742cca6f02545de23991ef75323abcef2f0c8f2e74b9eb241c9992d988ca. It matches the repository note exactly. Both final insertion texts were read in full: common 2592 bytes, SHA256 da7260f8fe2fb2e5f678e1f63cbd7c91cadf8c5b5a99a784877435e03d737030; FINDINGS 5752 bytes, SHA256 1ac2bf99e87d9affe560d4e962944829616c34a349d28809d329f4d82c27ad00. They include the final scoped wording “No new required Haskell fix was established.” Earlier insertion wording is retained only as historical evidence.

All nine current insertion regions reconstruct their actual documents from the preserved prior bodies at the recorded byte offset. Removing the inserted bytes recovers every exact prior body and hash. document-inverses-final.json records the insert, prior and current identities. The giant historical document bodies are preserved and compared mechanically; this owner reviewed the new insertion regions, not all historical prose.

The note correctly separates unconditional actual output-history extraction from pending whole-history resource and semantic decoration. It keeps prepared parent/source identities separate and retains the helper Complete IH. It describes completed native projection query closure without claiming prefix closure or whole-parent attachment. It preserves the local backward helper's Canonical, nonterminal, arity, retained-child, stable-family and final-model gates. Its deeper depth/path discussion is a scoped audit, not an executed admitted divergence counterexample. The equality path-growth example remains a source-definition calculation. No new Haskell defect or whole-CFTA completion claim is made.

## Remaining proof boundary

The next proof must decorate each actual prepared output path with its own preparation, full Memos/Post and rich resource receipts. It must pass the SAME source/prepared equivalence to the local backward theorem and handle terminal and opaque paths. It must derive the remaining ordinary semantic gates from actual receipts where possible. The pure history and the rich head receipt are necessary components, but no theorem in this bundle composes them through the entire driver.

A separate original depth/progress argument must cover all earlier reachable callbacks. An earlier stopped callback can omit later rows. Increasing work fuel does not remove recursive-depth exhaustion. Fresh IDs alone do not change recursion keys. Current selector, annotation admission and subtree-policy conditions remain explicit. Whole-driver output soundness, original accepted-output coverage, public APIs, ranking, sampling and physical Haskell correspondence remain open.

The exact-set seal covers only this output-history subtree. All earlier frozen areas remain untouched. No payload may change after FROZEN.json is written.
