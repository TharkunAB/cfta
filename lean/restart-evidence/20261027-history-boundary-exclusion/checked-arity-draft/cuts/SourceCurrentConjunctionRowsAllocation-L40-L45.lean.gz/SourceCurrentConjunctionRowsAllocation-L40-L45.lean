/-- A completed row graph retains both actual state components. -/
structure Effects (before after : State Symbol Formula) : Prop where
  keeps : Keeps before.heap after.heap
  ready : Ready after
  grows : SourceEqualityConstraintMemoAllocation.Grows before.equality after.equality

