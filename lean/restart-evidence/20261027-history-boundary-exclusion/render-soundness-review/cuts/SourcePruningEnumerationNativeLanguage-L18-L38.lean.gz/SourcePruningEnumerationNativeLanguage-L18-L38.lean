/-- A native handle denotes the independent guarded meaning of its actual readback. -/
def handles (holds : NativeGuard → Term Symbol → Bool)
    (ambient : InternedGuardedLanguage.Env Symbol)
    (heap : InternedConstructorTemplates.State Symbol NativeGuard) : NodeLanguage Symbol :=
  fun handle term => ∃ value, lookupNode heap handle = some value ∧
    InternedGuardedLanguage.meaning holds ambient value term

/-- An actual handle readback determines its complete native language. -/
theorem handles_lookup
    (holds : NativeGuard → Term Symbol → Bool) (ambient : InternedGuardedLanguage.Env Symbol)
    (heap : InternedConstructorTemplates.State Symbol NativeGuard)
    (handle : Nat) (value : InternedConstructorTemplates.Value Symbol NativeGuard) (term : Term Symbol)
    (decoded : lookupNode heap handle = some value) :
    handles holds ambient heap handle term ↔ InternedGuardedLanguage.meaning holds ambient value term := by
  constructor
  · rintro ⟨actual, found, accepted⟩
    have same : actual = value := Option.some.inj (found.symm.trans decoded)
    simpa only [same] using accepted
  · intro accepted
    exact ⟨value, decoded, accepted⟩

