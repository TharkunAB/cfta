from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import tempfile

ROOT = Path('/home/tritlo/Code/mcfta')
BASE = ROOT / 'lean/restart-evidence'
CONTROL = BASE / '20261118-worker-endpoint-seeds-zero-repair-check-control-draft'
WORK = BASE / '20261118-worker-endpoint-seeds-zero-work'
assert Path(__file__).resolve().parent == WORK.resolve(), 'Root reviews and copies this preparer into NEW Work65.'
assert Path(__file__).read_bytes() == (CONTROL / 'prepare-worker-endpoint-seeds-zero-repair-check.py').read_bytes()
SHA = lambda data: hashlib.sha256(data).hexdigest()
bound = set()


def verify(path, record):
    data = path.read_bytes()
    assert SHA(data) == (record['sha256'] if isinstance(record, dict) else record), str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data


def records(manifest):
    files = manifest['files']
    return files.items() if isinstance(files, dict) else [(item.get('file', item.get('path')), item) for item in files]


def bind_packet(packet, expected_manifest):
    manifest = json.loads(verify(packet / 'MANIFEST.json', expected_manifest))
    for name, record in records(manifest):
        verify(packet / name, record)
    return manifest


manifest = json.loads((CONTROL / 'MANIFEST.json').read_text())
assert manifest['status'] == 'FROZEN PRIVATE CHECK CONTROLLER / NOT EXECUTED'
for name, record in records(manifest):
    verify(CONTROL / name, record)
bound.add(CONTROL / 'MANIFEST.json')
selection = json.loads((CONTROL / 'SELECTION.json').read_text())
assert selection['status'] == 'FROZEN PRIVATE CHECK CANDIDATE / NOT EXECUTED'
assert selection['work'] == WORK.name
assert selection['runtime'] == '20261118-worker-endpoint-seeds-zero-repair-check'
runtime = BASE / selection['runtime']
assert not runtime.exists(), 'Use a new runtime. Preserve every earlier proof attempt.'
assert selection['source_files'] == 6286
assert re.fullmatch(r'[0-9a-f]{40}', selection['source_commit'])
assert re.fullmatch(r'[0-9a-f]{40}', selection['verified_prior_checkpoint_commit'])
assert selection['expected_checks'] == len(selection['components']) == 1
assert selection['expected_public_axiom_reports'] == 0
assert selection['expected_explicit_private_axiom_reports'] == 1
assert selection['expected_declaration_checks'] == 3
assert selection['new_private_helpers_transitive'] == 0
assert selection['new_definitions'] == 3 and selection['definition_axiom_credit'] == 0
assert selection['new_private_theorems'] == 1
assert selection['new_private_Prop_definitions'] == 3
assert not selection['Source64_PUSH_required']
assert selection['root_math_review_confirmed']
assert selection['prior_checkpoint_push_required_for_private_check']
assert selection['prior_checkpoint_push_required_before_normal_Source_staging']
for name, record in json.loads((CONTROL / 'RECEIPT-PINS.json').read_text()).items():
    verify(ROOT / name, record)
review = json.loads((ROOT / selection['root_math_review_receipt']).read_text())
assert review['Root_entire_append_motives_FIRST_and_proof_read'] and not review['semantic_concerns_found']
assert review['candidate_manifest'] == selection['components'][0]['manifest_sha256']
assert review['FIRST_sha256'] == selection['components'][0]['headers']['FIRST-HEADER.lean.txt']
assert review['source_baseline'] == selection['source_commit']
assert review['prior_checkpoint'] == selection['verified_prior_checkpoint_commit']
assert review['expected_public_reports'] == 0 and review['expected_explicit_private_reports'] == 1
assert review['new_private_Prop_definitions'] == review['expected_definition_checks'] == 3
assert review['all_three_motives_byte_exact_to_frozen_design']
assert review['prior_private_actual_session'] == selection['prior_private_actual_session']
assert review['assembly_is_prefix_plus_append_no_extra_separator']
assert review['Root_exact_width_repair_reviewed'] and review['FIRST_bytes_changed']
assert not review['original_FIRST_successfully_elaborated']
assert review['proof_and_three_motives_byte_exact'] and review['no_new_premise_fuel_or_budget']
original_control = BASE / selection['first_failed_control']
bind_packet(original_control, selection['first_failed_control_manifest_sha256'])
original_packet = BASE / selection['original_candidate_packet']
bind_packet(original_packet, selection['original_candidate_manifest_sha256'])
rejected = json.loads((ROOT / selection['first_rejected_receipt']).read_text())
first_actual = json.loads((WORK / 'PRIVATE-CHECK-ACTUAL-RUN.json').read_text())
first_runtime = BASE / selection['first_failed_runtime']
assert rejected['actual_terminal'] and first_actual['actual_terminal']
assert rejected['actual_terminal_exit'] == first_actual['actual_terminal_exit'] == 1
assert rejected['actual_session'] == first_actual['actual_session'] == selection['first_failed_actual_session'] == 78387
assert rejected['runtime'] == first_actual['runtime'] == selection['first_failed_runtime']
assert rejected['selected_control_manifest_sha256'] == selection['first_failed_control_manifest_sha256']
assert rejected['all_printed_reports_credit'] == rejected['credited_private_reports'] == rejected['credited_public_reports'] == 0
assert rejected['FIRST_not_successfully_elaborated']
assert rejected['checks'][0]['diagnostics'] == 6 and not rejected['checks'][0]['sorryAx']
assert rejected['checks'][0]['total_axiom_reports'] == 0 and rejected['checks'][0]['declaration_checks'] == 3
assert not (first_runtime / 'checked.json').exists()
first_results = json.loads((first_runtime / 'results.json').read_text())
assert first_results['checks'] == rejected['checks'] and not first_results['proof_credit']
assert SHA((first_runtime / 'results.json').read_bytes()) == rejected['results_sha256']
assert SHA((first_runtime / 'source-pins.json').read_bytes()) == rejected['source_pins_sha256']
first_pins = json.loads((first_runtime / 'source-pins.json').read_text())
assert len(first_pins) == rejected['pins_independently_reverified'] == selection['first_failed_input_pins'] == 9428
for name, digest in first_pins.items():
    verify(ROOT / name, digest)
# Preserved repository logs and pins bind the failure. Removed temporary objects are not required.
private_receipt = json.loads((ROOT / selection['prior_private_receipt']).read_text())
private_runtime = BASE / selection['prior_private_runtime']
private_actual = json.loads((BASE / selection['prior_private_work'] / 'REPAIR-CHECK-ACTUAL-RUN.json').read_text())
assert private_receipt['actual_terminal'] and private_actual['actual_terminal']
assert private_receipt['actual_terminal_exit'] == private_actual['actual_terminal_exit'] == 0
assert private_receipt['actual_session'] == private_actual['actual_session'] == selection['prior_private_actual_session'] == 79066
assert private_receipt['runtime'] == private_actual['runtime'] == selection['prior_private_runtime']
assert private_receipt['credited_public_reports'] == 0 and private_receipt['credited_private_reports'] == 1
assert private_receipt['source_pins_unchanged'] and private_receipt['proof_credit']
assert private_receipt['source_baseline'] == selection['source_commit']
assert private_actual['source_baseline'] == selection['source_commit']
assert private_receipt['selected_packet_manifest_sha256'] == selection['components'][0]['prefix_manifest_sha256']
private_checked = json.loads((private_runtime / 'checked.json').read_text())
assert private_checked == json.loads((private_runtime / 'results.json').read_text())
assert private_checked['checks'] == private_receipt['checks']
assert len(private_checked['checks']) == 1
assert private_checked['checks'][0]['exit'] == 0 and private_checked['checks'][0]['total_axiom_reports'] == 1
assert not private_checked['checks'][0]['diagnostics'] and not private_checked['checks'][0]['sorryAx']
assert not private_checked['checks'][0]['nonstandard_axioms']
assert SHA((private_runtime / 'checked.json').read_bytes()) == private_receipt['checked_sha256']
assert SHA((private_runtime / 'source-pins.json').read_bytes()) == private_receipt['source_pins_sha256']
private_pins = json.loads((private_runtime / 'source-pins.json').read_text())
assert len(private_pins) == private_receipt['pins_independently_reverified'] == selection['prior_private_input_pins'] == 9380
for name, digest in private_pins.items():
    verify(ROOT / name, digest)
# Source64 is a verified private pass. It has no required Source64 PUSH receipt.
prior = BASE / selection['prior_work']
publication = BASE / selection['prior_publication_runtime']
commit = json.loads((prior / 'SOURCE-COMMIT.json').read_text())
receipt = json.loads((prior / 'PUBLICATION-VERIFIED.json').read_text())
actual = json.loads((prior / 'PUBLICATION-ACTUAL-RUN.json').read_text())
checked = json.loads((publication / 'checked.json').read_text())
assert commit['source_commit'] == selection['source_commit']
assert commit['actual_terminal'] and commit['actual_terminal_exit'] == 0
assert commit['publication_actual_session'] == receipt['actual_session'] == actual['actual_session'] == selection['prior_publication_actual_session']
assert receipt['actual_terminal'] and actual['actual_terminal']
assert receipt['actual_terminal_exit'] == actual['actual_terminal_exit'] == 0
assert receipt['runtime'] == actual['runtime'] == selection['prior_publication_runtime']
assert checked == json.loads((publication / 'results.json').read_text())
assert checked['checks'] == receipt['checks']
assert SHA((publication / 'checked.json').read_bytes()) == receipt['checked_sha256']
assert SHA((publication / 'source-pins.json').read_bytes()) == receipt['source_pins_sha256']
assert [item['total_axiom_reports'] for item in checked['checks']] == [744, 1, 339, 744, 744]
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['sorryAx'] and not item['nonstandard_axioms'] for item in checked['checks'])
assert [item['declaration_checks'] for item in checked['checks']] == [0, 1, 0, 0, 0]
assert checked['all_five_gates_passed'] and checked['source_pins_unchanged']
assert receipt['source_files'] == 6286 and receipt['direct_audit_imports'] == 5286
assert receipt['audited_theorems'] == commit['audited_theorems'] == selection['prior_publication_audited_theorems']
assert receipt['pins_independently_reverified'] == selection['prior_publication_pins_reverified']
assert receipt['indexed_query_origin_from_one_operation_list']
assert receipt['all_operation_fields_and_native_run_result_retained']
assert receipt['definition_checks'] == 1 and receipt['definition_axiom_credit'] == 0
assert not receipt['joint_finite_completion_proved']
publication_pins = json.loads((publication / 'source-pins.json').read_text())
assert len(publication_pins) == receipt['pins_independently_reverified']
for name, digest in publication_pins.items():
    verify(ROOT / name, digest)
push = json.loads((ROOT / selection['prior_push_verified_receipt']).read_text())
assert push['source_commit'] == selection['source_commit']
assert push['checkpoint_commit'] == push['remote_commit'] == selection['verified_prior_checkpoint_commit']
assert push['actual_push_terminal'] and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal'] and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
assert push['normal_Source_files'] == 6286

# Root may commit documentation after Source63. Source and toolchain must stay exact.
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT).decode().strip() == 'formalize'
subprocess.run(['git', 'merge-base', '--is-ancestor', selection['source_commit'], 'HEAD'], cwd=ROOT, check=True)
changes = subprocess.check_output(['git', 'diff', '--name-only', selection['source_commit'], 'HEAD'], cwd=ROOT).decode().splitlines()
assert all(name in ['NEXT-PROMPT.md', 'HANDOFF.md', 'FINDINGS.md'] or name.startswith('lean/restart-evidence/') for name in changes), changes
subprocess.run(['git', 'diff', '--quiet', selection['source_commit'], '--', 'lean/MicroCFTA',
    'lean/lake-manifest.json', 'lean/lakefile.toml', 'lean/lean-toolchain', 'shell.nix'], cwd=ROOT, check=True)
baseline = json.loads((CONTROL / selection['source_baseline']).read_text())
assert baseline['source_commit'] == selection['source_commit'] and baseline['source_files'] == 6286
sources = sorted((ROOT / 'lean/MicroCFTA').glob('*.lean'))
assert len(sources) == 6286 and {str(path.relative_to(ROOT)) for path in sources} == set(baseline['sources'])
for name, record in {**baseline['sources'], **baseline['toolchain']}.items():
    verify(ROOT / name, record)
    assert publication_pins[name] == record['sha256'], name
item = selection['components'][0]
assert item['module'] == 'SourcePruningEnumerationSharedEagerReservation'
assert selection['compile_order'] == [item['module']]
packet = BASE / item['packet']
bind_packet(packet, item['manifest_sha256'])
for name, record in json.loads((packet / 'SOURCE-PINS.json').read_text())['files'].items():
    verify(ROOT / name, record)
raw = verify(packet / item['source'], {'bytes': item['raw_bytes'], 'sha256': item['raw_sha256']})
prefix_packet = BASE / item['prefix_packet']
bind_packet(prefix_packet, item['prefix_manifest_sha256'])
prefix = verify(prefix_packet / item['source'], {'bytes': item['prefix_bytes'], 'sha256': item['prefix_sha256']})
old_owner = verify(ROOT / item['old_owner_source'], {'bytes': item['old_owner_bytes'], 'sha256': item['old_owner_sha256']})
assert prefix[item['old_owner_offset']:item['old_owner_offset'] + len(old_owner)] == old_owner
append = verify(packet / 'APPEND.lean.txt', item['append_sha256'])
assert raw == prefix + append
assert len(prefix) == 2540349 and len(raw) == 2549042
for name, digest in item['headers'].items():
    header = verify(packet / name, digest)
    assert append.count(header.rstrip()) == raw.count(header.rstrip()) == 1
assert re.findall(r'^private theorem (\w+)', append.decode(), re.M) == ['real_eager_endpoint_seeds_zero']
assert re.findall(r'^private def (\w+)', append.decode(), re.M) == [name.rsplit('.', 1)[-1] for name in item['definition_qnames']]
assert not re.findall(r'^(?:theorem |(?:private )?(?:inductive|structure) )', append.decode(), re.M)
assert not re.search(rb'set_option\s+(?:maxHeartbeats|maxRecDepth|warningAsError|linter\.)', append)
assert not re.search(rb'\b(?:sorry|axiom)\b', append)
probe = verify(packet / item['probe'], item['probe_sha256'])
assert re.findall(r'^#print axioms (\S+)', probe.decode(), re.M) == item['private_qnames']
assert re.findall(r'^#check (\S+)', probe.decode(), re.M) == item['definition_qnames']
assert len(set(item['definition_qnames'])) == 3
assert probe.count(b'#print axioms ') == item['expected_axiom_reports'] == 1
assert probe.count(b'#check ') == item['expected_declaration_checks'] == 3
assert b'#print axioms ' not in raw and b'#check ' not in raw
for module, digest in item['normal_dependencies'].items():
    verify(ROOT / 'lean/MicroCFTA' / (module + '.lean'), digest)

original_raw = (original_packet / item['source']).read_bytes()
original_first = verify(original_packet / 'FIRST-HEADER.lean.txt', selection['original_FIRST_sha256'])
selected_first = (packet / 'FIRST-HEADER.lean.txt').read_bytes()
old_call = b'RealEagerEndpointSeedsAtDepth sourceHeap entry body depth ordinary bodyId'
new_call = b'RealEagerEndpointSeedsAtDepth (bits := bits) sourceHeap entry body depth ordinary bodyId'
assert original_raw.count(old_call) == original_first.count(old_call) == 1
assert raw == original_raw.replace(old_call, new_call, 1)
assert selected_first == original_first.replace(old_call, new_call, 1)
assert len(raw) - len(original_raw) == len(selected_first) - len(original_first) == 15
assert not selection['original_FIRST_successfully_elaborated'] and selection['FIRST_bytes_changed']
for name in ['PROOF.lean.txt', 'MOTIVE-DEFINITIONS.lean.txt', 'OWNER-LOCAL-CONTEXT.lean.txt',
             'COMBINED-PROBES.lean.txt', 'DEFINITION-CHECKS.lean.txt', 'PRIVATE-OWNER-PROBES.lean.txt', 'SOURCE-PINS.json']:
    assert (packet / name).read_bytes() == (original_packet / name).read_bytes(), name

normal_objects = ROOT / 'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()
paths = {path.stem: path for path in sources}
active, seen, order, graph = [], set(), [], {}


def visit(name):
    assert name not in active, 'Import cycle: ' + repr(active + [name])
    if name in seen:
        return
    active.append(name)
    data = raw.decode() if name == item['module'] else paths[name].read_text()
    graph[name] = re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$', data, re.M)
    for dependency in graph[name]:
        assert dependency in paths, dependency
        visit(dependency)
    active.pop()
    seen.add(name)
    order.append(name)


visit(item['module'])
topological = json.loads((CONTROL / 'TOPOLOGICAL-ORDER.json').read_text())
assert graph == topological['direct_imports'] and order == topological['full_transitive_order']
assert len(order) == 2864 and len(seen - {item['module']}) == 2863
for name in seen - {item['module']}:
    assert (normal_objects / (name + '.olean')).is_file(), name
assert set(item['normal_dependencies']).issubset(seen)
for name in ['shadow-compile.py.txt', 'check-driver.py.txt']:
    ast.parse((CONTROL / name).read_text())
# Root creates the fresh runtime only after every read-only gate passes.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-worker-endpoint-seeds-zero-repair-'))
(objects / 'MicroCFTA').mkdir()
linked = []
for obj in sorted(normal_objects.glob('*.olean')):
    if obj.stem != item['module']:
        (objects / 'MicroCFTA' / obj.name).symlink_to(obj)
        linked.append(obj.name)
assert item['module'] + '.olean' not in linked
assert all(name + '.olean' in linked for name in item['normal_dependencies'])
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
(runtime / 'shadow-imports.json').write_text(json.dumps({'linked_unchanged_modules': linked,
    'excluded_candidate_modules': [item['module']], 'candidate_output_links_created': False,
    'normal_dependency_modules': 2863, 'cache_data_copied': False}, indent=2) + '\n')
fixture = runtime / 'source/MicroCFTA' / item['source']
fixture.parent.mkdir(parents=True)
fixture.write_bytes(raw + b'\n' + probe)
bound.add(fixture)
(runtime / 'selection.json').write_text(json.dumps(selection, indent=2, sort_keys=True) + '\n')
(runtime / 'shadow-compile.py').write_bytes((CONTROL / 'shadow-compile.py.txt').read_bytes())
(runtime / 'check.py').write_bytes((CONTROL / 'check-driver.py.txt').read_bytes())
(runtime / 'NORMAL-STAGING-GATE.json').write_text(json.dumps({
    'source_commit': selection['source_commit'], 'prior_Work63_push_receipt': selection['prior_push_verified_receipt'],
    'checkpoint_commit': push['checkpoint_commit'], 'private_check_requires_checkpoint_push': True,
    'normal_Source_staging_requires_checkpoint_push': True, 'normal_Source_staging_executed_by_this_controller': False}, indent=2) + '\n')
bound.add(Path(__file__))
bound.update(path for path in runtime.iterdir() if path.is_file())
(runtime / 'source-pins.json').write_text(json.dumps({str(path.relative_to(ROOT)): SHA(path.read_bytes())
    for path in sorted(bound)}, indent=2, sort_keys=True) + '\n')
print(json.dumps({'runtime': str(runtime), 'objects': str(objects), 'checks': 1,
    'expected_public_reports': 0, 'explicit_private_reports': 1, 'new_private_helpers': 1, 'definition_checks': 3, 'definition_axiom_credit': 0,
    'new_definitions': 3,
    'normal_Source_changed': False, 'prior_checkpoint_push_required_before_private_check': True}))
