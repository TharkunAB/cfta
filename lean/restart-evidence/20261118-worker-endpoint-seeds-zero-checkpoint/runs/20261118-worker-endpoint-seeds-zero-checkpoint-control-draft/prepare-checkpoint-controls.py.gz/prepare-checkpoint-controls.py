from pathlib import Path
import ast
import gzip
import hashlib
import json
import re
import subprocess

root = Path('/home/tritlo/Code/mcfta')
base = root/'lean/restart-evidence'
archive_control = base/'20261118-worker-endpoint-seeds-zero-checkpoint-control-draft'
work = base/'20261118-worker-endpoint-seeds-zero-work'
runtime = base/'20261118-worker-endpoint-seeds-zero-fixture-repair-publication'
archive = base/'20261118-worker-endpoint-seeds-zero-checkpoint'
prior_archive = base/'20261118-invocation-native-query-projection-checkpoint'
board_prefix = 'current-board-worker-endpoint-seeds-zero-'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
git = lambda *args: subprocess.check_output(['git', *args], cwd=root)
assert (archive_control/'STATUS.txt').read_text().startswith('FROZEN'), 'OPEN control; do not execute.'
assert Path(__file__).resolve().parent == work.resolve()
assert Path(__file__).read_bytes() == (archive_control/'prepare-checkpoint-controls.py').read_bytes()


def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    return data


def records(value):
    if isinstance(value, list):
        return [(item.get('file', item.get('path')), item) for item in value]
    return records(value['files']) if 'files' in value else value.items()


def packet(path, digest=None):
    if digest is not None:
        verify(path/'MANIFEST.json', digest)
    for name, record in records(read(path/'MANIFEST.json')):
        verify(path/name, record)


assert read(archive_control/'MANIFEST.json')['status'] == 'FROZEN CANDIDATE / NOT EXECUTED'
packet(archive_control)
for name, record in records(read(archive_control/'SOURCE-PINS.json')):
    verify(root/name, record)
stage = read(work/'SOURCES-NORMAL-STAGING.json')
overrides = stage['baseline_overrides']
assert stage['status'] == 'SOURCE_NORMAL_STAGING_COMPLETED' and stage['normal_Source_changed']
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6286, 5286, 744, 339)
assert (stage['fresh_private_reports'], stage['inherited_reports'], stage['combined_reports']) == (2, 538, 540)
assert stage['new_public_theorems'] == 0 and stage['new_private_theorems'] == 2 and stage['new_private_helpers_transitive'] == 0 and stage['new_private_Prop_definitions'] == stage['new_definitions'] == 3
assert stage['new_modules'] == 0 and stage['changed_existing_owners'] == 1 and set(overrides) == {'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'}
assert stage['Audit_changed'] is False


def historical(name, record):
    digest = record['sha256'] if isinstance(record, dict) else record
    for path in [root/name, root/overrides.get(name, name)]:
        if path.is_file() and sha(path.read_bytes()) == digest:
            return verify(path, record)
    raise AssertionError(name)


source_receipt = read(work/'SOURCE-COMMIT.json')
provenance = read(work/'SOURCE-COMMIT-ACTUAL-RUN.json')
code = source_receipt['source_commit']
assert code == provenance['source_commit'] and re.fullmatch(r'[0-9a-f]{40}',code)
assert source_receipt['parent'] == stage['prior_checkpoint'] == '51ff371093cf387f351c1f30428b48d9f9cf25be'
assert type(provenance['actual_session']) is int and provenance['actual_session'] > 0 and provenance['actual_terminal'] and provenance['actual_terminal_exit'] == 0
commit_control = base/provenance.get('controller',provenance.get('control'))
assert commit_control.name == '20261118-worker-endpoint-seeds-zero-source-commit-control-draft'
packet(commit_control,provenance['control_manifest_sha256'])
assert (work/'commit-source.py').read_bytes() == verify(commit_control/'commit-source.py',provenance['script_sha256'])
assert read(commit_control/'MANIFEST.json')['all_final_receipts_bound_before_freeze']
assert source_receipt['private_actual_sessions'] == [entry['actual_session'] for entry in stage['private_subsets']]
assert source_receipt['rejected_private_credit'] == 0
assert (source_receipt['new_public_theorems'],source_receipt['new_private_theorems'],source_receipt['new_definitions']) == (0,2,3)
assert source_receipt['explicit_definition_checks'] == 3 and source_receipt['definition_axiom_credit'] == 0
assert git('branch','--show-current').decode().strip() == 'formalize'
assert git('rev-parse','HEAD').decode().strip() == code
assert git('rev-parse',code+'^').decode().strip() == stage['prior_checkpoint']
assert not git('status','--porcelain','--untracked-files=no')
assert set(git('diff','--name-only',stage['prior_checkpoint'],code).decode().splitlines()) == set(stage['exact_Source_write_paths'])
for name in stage['exact_Source_write_paths']:
    assert git('show',code+':'+name) == (root/name).read_bytes()
    if name in overrides:
        assert git('show',stage['prior_checkpoint']+':'+name) == (root/overrides[name]).read_bytes()
    else:
        assert not git('ls-tree','--name-only',stage['prior_checkpoint'],'--',name)
for name in ['NEXT-PROMPT.md','HANDOFF.md','FINDINGS.md']:
    assert (root/name).read_bytes() == git('show',code+':'+name),name
report = read(runtime/'checked.json')
publication = read(work/'PUBLICATION-VERIFIED.json')
actual = read(work/'PUBLICATION-ACTUAL-RUN.json')
assert publication['actual_session'] == actual['actual_session'] == source_receipt['publication_actual_session']
assert type(actual['actual_session']) is int and actual['actual_session'] > 0
assert publication['actual_terminal'] and actual['actual_terminal'] and publication['actual_terminal_exit'] == actual['actual_terminal_exit'] == 0
assert type(actual['preparer_actual_session']) is int and actual['preparer_terminal_exit'] == 0
assert report == read(runtime/'results.json') and report['checks'] == publication['checks']
assert [item['total_axiom_reports'] for item in report['checks']] == [744,2,339,744,744]
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['sorryAx'] and not item['nonstandard_axioms'] for item in report['checks'])
assert report['all_five_gates_passed'] and report['source_pins_unchanged']
assert [item['declaration_checks'] for item in report['checks']] == [0,3,0,0,0]
assert report['definition_checks'] == 3 and report['definition_axiom_credit'] == 0
assert report['audited_theorems'] == publication['audited_theorems'] == source_receipt['audited_theorems']
assert type(report['audited_theorems']) is int and report['audited_theorems'] > 0
assert (report['new_public_theorems'],report['new_private_theorems'],report['new_theorem_declarations'],report['new_prop_definitions']) == (0,2,2,3)
for field in ['all_original_eager_worker_query_admissions_proved','original_eager_worker_all_calls_Seeds_propagation_proved','joint_finite_completion_proved','haskell_changed']:
    assert not report[field],field
public_pins = json.loads(verify(runtime/'source-pins.json',publication['source_pins_sha256']))
verify(runtime/'checked.json',publication['checked_sha256'])
verify(runtime/'results.json',publication['results_sha256'])
assert len(public_pins) == publication['pins_independently_reverified']
for name,record in public_pins.items():
    verify(root/name,record)
for entry in stage['private_subsets']+stage.get('rejected_checks',[]):
    receipt_path = entry.get('verified_receipt',entry.get('receipt'))
    receipt = read(root/receipt_path)
    private_actual = read(root/entry['actual_receipt'])
    private_run = base/entry['runtime']
    assert receipt['actual_session'] == private_actual['actual_session'] == entry['actual_session']
    result = json.loads(verify(private_run/'results.json',receipt['results_sha256']))
    assert result['checks'] == receipt['checks']
    if entry in stage['private_subsets']:
        assert receipt['actual_terminal_exit'] == private_actual['actual_terminal_exit'] == 0
        assert receipt['proof_credit'] and result == read(private_run/'checked.json')
        assert result['checks'][0]['total_axiom_reports'] == 1 and result['checks'][0]['declaration_checks'] == entry['explicit_definition_checks']
    else:
        assert receipt['actual_terminal_exit'] == private_actual['actual_terminal_exit'] == 1
        assert not receipt['proof_credit'] and receipt['credited_public_reports'] == 0
        assert not (private_run/'checked.json').exists()
    private_pins = json.loads(verify(private_run/'source-pins.json',receipt['source_pins_sha256']))
    assert len(private_pins) == receipt['pins_independently_reverified'] == entry['pins']
    for name,record in private_pins.items():
        historical(name,record)
baseline = read(root/stage['source_baseline_path'])
assert len(baseline['sources']) == 6286 and len(baseline['toolchain']) == 4
assert len(set(baseline['sources'])-set(overrides)) == stage['old_other_Source_files_byte_exact'] == 6285
for name,record in {**baseline['sources'],**baseline['toolchain']}.items():
    historical(name,record)
components = stage['components']
for item in components:
    packet(base/item['packet'],item['manifest_sha256'])
    current = verify(root/item['source_path'],{'sha256':item['raw_sha256'],'bytes':item['raw_bytes']})
    assert current == (base/item['packet']/item['source']).read_bytes()
    for filename,digest in item['headers'].items():
        data = verify(base/item['packet']/filename,digest).rstrip()
        assert current.count(data) == 1
        if filename == 'FIRST-HEADER.lean.txt':
            assert re.match(rb'\s*:= by',current[current.index(data)+len(data):])
assert len(components) == 1
owner = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
old_owner = historical(owner,baseline['sources'][owner])
assert len(old_owner) == 2533565 and (root/owner).read_bytes()[72:72+2533565] == old_owner
assert len((root/'lean/MicroCFTA/Audit.lean').read_bytes()) == 436723
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes() == git('show',stage['prior_checkpoint']+':lean/MicroCFTA/Audit.lean')
bindings = read(archive_control/'prior-bindings.json')
for filename,key in [('manifest.json','prior_manifest_sha256'),('checkpoint.json','prior_checkpoint_json_sha256')]:
    data = verify(prior_archive/filename,bindings[key])
    assert git('show',stage['prior_checkpoint']+':'+str((prior_archive/filename).relative_to(root))) == data
old_pins = json.loads(gzip.decompress((prior_archive/'source-pins.json.gz').read_bytes()))
assert {n:v['sha256'] for n,v in baseline['sources'].items()} == {n:v for n,v in old_pins.items() if n.startswith('lean/MicroCFTA/') and n.endswith('.lean')}
for name,record in old_pins.items():
    historical(name,record)
request = read(work/(board_prefix+'request.json'))
canonical = read(work/(board_prefix+'canonical.json'))
assert canonical['verified']
post = canonical.get('post',canonical)
assert post['id'] == request['request_id'] and type(post['sequence']) is int and post['sequence'] > 0
for key,expected in [('author',request['username']),('thread_id',request['thread_id']),('post_type',request['post_type']),('content',request['content']),('metadata',request['metadata'])]:
    assert post[key] == expected,key
assert post['metadata']['source'] == code and not post['metadata']['joint_finite_completion_proved']
cleanup = read(work/'COMBINED-TMP-CLEANUP.json')
assert cleanup['all_targets_removed'] and cleanup['normal_cache_preserved'] and cleanup['unknown_tmp_entries_preserved'] and cleanup['no_cache_data_copied']
expected_runs = {entry['actual_session']:entry['runtime'] for entry in stage.get('rejected_checks',[])+stage['private_subsets']}
expected_runs[actual['actual_session']] = runtime.name
assert len(cleanup['runs']) == cleanup['owned_terminal_directories'] == len(expected_runs) == 5
assert {entry['actual_session']:entry['runtime'] for entry in cleanup['runs']} == expected_runs
cumulative = 6620105861
for entry in cleanup['runs']:
    assert entry['path'] == read(base/entry['runtime']/'objects.json')['path']
    assert entry['owned_terminal_only'] and entry['normal_cache_preserved'] and entry['all_targets_removed'] and entry['no_cache_data_copied']
    assert not entry['live_process_references']
    # Protected process visibility errors remain explicit. Safe removal needs concrete scope evidence.
    if entry['regular_bytes_removed'] == 0:
        assert entry['symlink_only_terminal_namespace'] and entry['no_regular_data_unlinked']
    else:
        assert entry['scope_ActiveState'] == 'inactive' and entry['generated_terminal_outputs_only']
        assert entry['no_source_or_normal_cache_data_unlinked']
    assert not Path(entry['path']).exists() and not Path(entry['path']).is_symlink()
    assert entry['prior_cumulative_removed_bytes'] == cumulative
    cumulative += entry['regular_bytes_removed']
    assert entry['cumulative_removed_bytes'] == cumulative
assert cumulative == cleanup['cumulative_removed_bytes']
assert cleanup['regular_bytes_removed_this_batch'] == sum(entry['regular_bytes_removed'] for entry in cleanup['runs'])
assert cleanup['symlinks_removed_this_batch'] == sum(entry['symlinks_removed'] for entry in cleanup['runs'])
assert type(cleanup['normal_cache_targets']) is int and cleanup['normal_cache_targets'] > 0
start = read(work/'START.json')
assert start['expected_public_reports'] == 0 and start['expected_explicit_private_reports'] == 1
assert start['expected_definition_checks'] == 3 and start['definition_axiom_credit'] == 0
assert start['new_private_helpers'] == 1 and start['new_private_Prop_definitions'] == 3 and start['full_goal_remains_open']
preparer_rejected = read(work/'PUBLICATION-PREPARER-REJECTED.json')
assert preparer_rejected['actual_session'] == 84654 and preparer_rejected['actual_terminal_exit'] == 1
assert not preparer_rejected['runtime_created'] and not preparer_rejected['compiler_run'] and preparer_rejected['proof_credit'] == 0
resume = read(work/'RESUME-AUTHORIZATION.json')
assert resume['manual_work_explicitly_authorized'] and resume['earlier_usage_pause_lifted'] and not resume['goal_operation_performed'] and not resume['goal_completion_claimed']
usage = read(work/'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int,float] and 0 <= percent <= 100 and usage['current_usage_not_measured']
current_usage_path = root/read(archive_control/'current-usage-selection.json')['path']
current_usage = read(current_usage_path)
current_percent = current_usage['used_percent']
assert type(current_percent) in [int,float] and 0 <= current_percent <= 100
assert not current_usage['pause_required'] and current_usage['pause_threshold_percent'] == 80
assert code in (work/'LIVE-HANDOFF.md').read_text()
roots = read(archive_control/'selection-roots.json')
additional = read(archive_control/'archive-additional-roots.json')
assert len(roots) == len(set(roots)) and all(extra['current_batch_theorem_credit'] == 0 for extra in additional)
for extra in additional:
    assert extra['current_batch_theorem_credit'] == 0 and not extra['private_runtime_selected']
    packet(base/extra['root'],extra['sha256'])
    roots.append(extra['root'])
assert len(roots) == len(set(roots)) and prior_archive.name not in roots
assert all((base/name).is_dir() and not (base/name).is_symlink() for name in roots)
for header in read(archive_control/'original-header-files.json'):
    assert sha((root/header['path']).read_bytes()) == sha((root/header['original']).read_bytes()) == header['sha256']
for name in ['assemble.py','finalize.py','verify.py','commit-checkpoint.py']:
    ast.parse((archive_control/name).read_text())
source_pins = {n:v for n,v in public_pins.items() if n.startswith('lean/MicroCFTA/') and n.endswith('.lean')}
assert len(source_pins) == 6286
selected = sorted(str((base/name).relative_to(root)) for name in roots)
tree = hashlib.sha256()
for name,digest in sorted(source_pins.items()):
    tree.update(name.encode()+b'\0'+digest.encode()+b'\n')
config = dict(report)
config.update(checked_code=code,prior_checkpoint=stage['prior_checkpoint'],public_run=str(runtime),public_gates=5,
    explicit_reports=744,board_prefix=board_prefix,board_post_id=post['id'],board_sequence=post['sequence'],
    source_tree_sha256=tree.hexdigest(),old_other_Source_files_byte_exact=6285,
    known_cumulative_tmp_removed_bytes=cumulative,cleanup_receipt='COMBINED-TMP-CLEANUP.json',removed_regular_bytes=cleanup['regular_bytes_removed_this_batch'],removed_symlinks=cleanup['symlinks_removed_this_batch'],
    historical_primary_usage_percent=percent,historical_primary_usage_checked_at=usage['checked_at'],current_usage_not_measured=False,
    current_primary_usage_percent=current_percent,current_primary_usage_checked_at=current_usage['sample_at'],
    current_usage_receipt=str(current_usage_path.relative_to(root)),
    prior_immutable_archive=prior_archive.name,prior_manifest_sha256=bindings['prior_manifest_sha256'],
    actual_selected_private_sessions=[entry['actual_session'] for entry in stage['private_subsets']],actual_publication_session=actual['actual_session'],actual_source_commit_session=provenance['actual_session'],
    executed_source_commit_control=commit_control.name,source_commit_control_bound_after_final_publication=True,
    old_usage_pause_reintroduced=False,persistent_goal_control_status=resume['persistent_goal_control_status'],work_authorized_by_explicit_user_resume=True,
    goal_active=False,goal_completion_claimed=False,additional_frozen_roots=additional,additional_frozen_roots_theorem_credit=0,future_worker_runtime_selected=False)
skipped = sorted(str(p.relative_to(root)) for p in base.iterdir() if p.is_dir() and p.name.startswith(('20261117-','20261118-')) and str(p.relative_to(root)) not in selected)
review = dict(selected_roots=len(roots),base_roots=len(roots)-len(additional),additional_frozen_roots=additional,fresh_public_reports=0,fresh_private_reports=2,inherited_reports=538,combined_reports=540,
    new_public_theorems=0,new_private_theorems=2,new_definitions=3,resource_owner_reports_inherited=264,current_batch_compiler_failures=[entry['actual_session'] for entry in stage.get('rejected_checks',[])],
    failed_compiler_credit=0,successful_private_and_public_runs_preserved=[entry['actual_session'] for entry in stage['private_subsets']]+[actual['actual_session']],
    all_root_documents_preserved_as_suffix=True,future_extra_theorem_credit=0,future_worker_runtime_selected=False,joint_finite_completion_proved=False)
note = (archive_control/'checkpoint-note.md').read_text()
for key,value in {'THEOREMS':report['audited_theorems'],'PINS':publication['pins_independently_reverified'],'REMOVED':cleanup['regular_bytes_removed_this_batch'],'SYMLINKS':cleanup['symlinks_removed_this_batch'],'CLEANUP':cumulative,'USAGE':percent,'CURRENT_USAGE':current_percent,'CURRENT_USAGE_TIME':current_usage['sample_at'],'BOARD':post['sequence']}.items():
    note = note.replace('{{'+key+'}}',str(value))
assert set(re.findall(r'\{\{(.*?)\}\}',note)) == {'TIME','TREE','CODE'}
outputs = {'checkpoint-config.json':config,'archive-roots.json':selected,'skipped-published-roots.json':skipped,'selection-review.json':review}
assert not archive.exists() and all(not (work/name).exists() for name in outputs)
# Root writes Work outputs only after every read-only gate passes.
for name,value in outputs.items():
    (work/name).write_text(json.dumps(value,indent=2)+'\n')
(work/'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code':code,'archive':archive.name,'roots':len(roots),'board_sequence':post['sequence'],'fresh_public_reports':0,'fresh_private_reports':2,'inherited_reports':538,'combined_reports':540,'current_usage_not_measured':False,'current_primary_usage_percent':current_percent}))
