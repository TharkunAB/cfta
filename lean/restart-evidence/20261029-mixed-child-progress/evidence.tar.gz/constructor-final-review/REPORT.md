# Accepted constructor contract review

Measured review: 2026-10-29 22:31 CET.
Verdict: CLEAR for the stated local accepted selected-edge step.
No material source fix is required by this review.
This owner ran no compiler, evaluator, native program, Git, network or board
command and changed no repository file. Root owns all such checks and writes.

## Exact reviewed sources

Three current Lean sources were reviewed within the three-source limit:

- AcceptedConstructorProgress: 263 lines, 18464 bytes, SHA256
  8f9551888a0a5811c41855ee61041e82840de4f21e2ffa5f36d08c9c5a478bde.
- TraversalModelStorageProgress: 432 lines, 32363 bytes, SHA256
  84e8086d72429eb4b388f4873eef372b47a0d486d15db4c937f1b106648ee77a.
- OwnChildModelProgress: 231 lines, 14534 bytes, SHA256
  ab25dc165d91380062dab69f752ac2df0a43b12c6b297c45ecc77cb038ec62c0.

All copies and literal dependency cuts are retained. acquisitions.json records
the exact paths, endpoints, byte counts and hashes. A combined display of the
traversal and own source was truncated. The missing traversal region was read
again through overlapping cuts220-265 and260-432. The own source display was
complete. No whole-review claim relies on omitted text. Broad source searches
were only locators; some locator output was truncated.

## Original parent and accepted edge

accepted_constructor_decreases takes a stored pending graph slot at the
original target. parentLookup explicitly ties THAT stored handle to the exact
.node parentEntry edges depth free whose edge is selected. PendingRealized
then supplies Available and closed facts for that same parent. The proof
compares the two lookup results. It does not assume that an arbitrary available
node is the parent of the stored target.

The selected edge membership, original edgeMeaning, parent-assigned term,
original Satisfies, original root and current cache invariants are explicit.
The syntactic projected constraint equation is original edge data used to
state the planned resource cost. It is not a future execution observation.
Fits, Reserved and the heap alphabet are original resource admissions.
The theorem does not claim to derive these global reservations itself.

The original stored slot model supplies every inherited suspended Holds.
accepted_own_children derives actual constraint projection, ordered accepted
native child terms, residual truth and the real own-class allocation packet.
It constructs a compatible fresh assignment. The pure own-class allocation
preserves pending graph cost. Actual child inputs and every bucket obligation
use that same assignment.

## Parent protection through mixed children

The original Canonical hypothesis supplies ValidSuspended for the stored scs.
The accepted constraint projection supplies validity for fresh own tries.
ParentChildSeparation.edge_children_avoid_parent uses those valid sources and
the actual descend operation to derive ProperInputs for every child bucket.
ProperInputs contains valid, nonempty tries. Nonemptiness is needed to extract
an actual path; a vacuous empty trie would not establish parent avoidance.

The accepted child term is a proper child of the parent constructor. If a
child bucket referred to the parent's equality class, original Satisfies and
Holds would make the whole parent occur below that proper child. Finite term
height rules this out. This proves Avoids. The mixed traversal's real
protected-root receipt then retains the original target slot and root.
No parent protection, post-slot shape or desired cost frame is assumed.
The old all-nonterminal frame is not reused for mixed children.

## Actual execution at a common index bound

The mixed traversal producer supplies real complete runs for all sufficiently
large representative/native/index bounds and P/H. Its accepting observer
constructs one extension with ordered fragment fills and final Satisfies.
The selected-edge equation follows from the actual own packet, actual child
traversal and literal residual finish. Completion is a conclusion, not a
premise.

Finalize.complete is called at the reached native heap and actual recorded
cache. The protected stored target, recorded safety, fragment bounds, waiting
counts, flags and realization derive its actual result. Finalization is also
a conclusion. The proof does not receive a captured finalizer result oracle.

The returned shared index base is k+finalFuel. SelectedEdge.run uses the
original stable traversal with extra index finalFuel+ek. Finalize.run uses
its own stable result with extra index k+ek. Associativity and commutativity
make both equations use exactly (k+finalFuel)+ek. The finalizer heap is the
same afterCaller heap used by the actual selected-edge result.

## One assignment and strict cost decrease

The final extended assignment agrees at every original allocated ID. It
satisfies the original cache, the actual residual-recorded cache and the
actual finalized cache. Its fragment fills to the original chosen term.
The final write model comes from the real finalizer write and the derived
parent equation. No final Satisfies predicate is a public input.

The mixed traversal's cost law relates its final extended assignment to the
own assignment at the preceding state. The own-class cost law relates that
to the original assignment. Thus the proof can telescope the two laws without
assuming a desired cost statement under a later assignment at an earlier
state. Earlier fragment fills are retained by bounded old-ID agreement.

Actual finalization removes the preserved parent's assigned constructor
count. The term has one parent constructor plus its ordered child forest.
The result is:

    pendingSize finalized.core extended + 1 <= pendingSize before.core assignment

This is a strict decrease of the chosen-term pending constructor measure.
It is not a time bound, total native heap bound or FEAT pay-size statement.
A reduction larger than one is allowed. No exact-one decrease is claimed.

The public inputs contain no future model, endpoint cost bound, future trace
family, chosen assignment extension, child operation observation, desired
preservation implication or finalizer result. All those local outputs are
derived from the original model, accepted edge and original admissions.

## Returned invariants and iteration boundary

The result exports actual selected-edge and finalizer executions, Native Post,
query equality, old-ID agreement, the three Satisfies facts and exact fill.
It also returns final Safe, Canonical, Roots, StorageValid, PendingRealized,
canonical waiting counts, exact native expandable flags and the advanced
Fits/heap alphabet. These are substantial local iteration data.

This is not a complete recursive scheduler packet. In particular it does not
export ProperState, global PendingReferences, recursion-key ancestry or the
whole recursive history/packet. It does not require or derive the outer
scheduler's choice of this target or a waiting-count-zero selection equation.
Next-call InputsPending for another selected slot remains a separate admission.
Safe means StorageValid plus LiveRoots. Canonical means valid stored tries;
neither definition alone is the full strict-path or pending-reference invariant.
The retained traversal receipt contains conditional reference/protection facts,
but those facts are not all exported by this constructor theorem.

The public result also does not separately state final counter growth or the
literal final target value. These can be recovered from its actual operations
and existing operation lemmas when a later iteration theorem needs them.
Their absence is not an error in the present local statement.

An outer ordinary/recursive worker theorem must attach this actual selected-edge
step after its real earlier branches and callbacks. It must carry the required
scheduler/ancestry/reference invariants, updated resources and model witnesses.
The local strict decrease does not control neutral opaque transfers, restarts,
all earlier callbacks, stops or all events of a complete public invocation.

## Exact remaining global and public boundary

The checked local statement now derives an accepted ordinary constructor step,
including mixed children, residual recording and finalization. It does not
prove complete enumeration of all accepted finite values, sufficient global
recursive capacity, exact public order/stops or Haskell execution correspondence.
Its accepted selected edge is supplied as an original semantic witness; it
does not show that the full outer schedule reaches that edge after earlier work.

The existing initial_boundary_done theorem is unchanged. The reviewed literal
cut proves an admitted recursive-boundary startup with no candidates, no
Discharged predicate and a complete placeholder result for every worker and
recursive fuel. A worker-capacity-only coverage claim would therefore exceed
the formal contract. Graph unfolding or the relevant public generator bridge
remains necessary for intended finite-value coverage.

ResourceHistory.render_sound still explicitly takes discharged output, actual
rendering, checked pending PCS obligations and its existing history/admission
gates. The new local constructor result does not remove those conditions.
No public generator implementation or Haskell correspondence theorem is proved
by these three reviewed sources. No Haskell defect or fix was established by
this review.

## Independent-check scope

Root reported strict checks for these sources and is running aggregate/public
checks. This review verifies source contracts and copied-byte identities only.
It does not independently claim compiler, aggregate or axiom-check execution.
The previous mixed-assignment bundle remains frozen and was not changed.
