# Constructive mixed constructor progress

The full formalization goal remains ACTIVE.
Read final-documents/lean/notes-current-mixed-constructor-progress.md first.
Original accepted stored parents derive actual mixed selected-edge execution
and actual finalization at one common index bound. The same extended model
supplies original/recorded/final Satisfies, actual fill and strict pending cost.
Iteration admissions, neutral-step control, global resources, unfolding/public
coverage, exact order/stops and Haskell correspondence remain open.

Every regular file is archived without filtering. Keep this tree and every
reconstruction immutable. Continue in a fresh writable area. Historical failed
attempts and source-only UNTESTED labels remain. Eight strict mappings identify
the exact final sources. Verification executes no Lean or Haskell code.
