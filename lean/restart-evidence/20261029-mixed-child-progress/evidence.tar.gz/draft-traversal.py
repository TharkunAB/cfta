from pathlib import Path
p=Path('/tmp/mcfta-mixed-child-progress-20261029');base=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA/SourcePruningEnumerationTraversalCoverage.lean').read_text();(p/'prior-sources/SourcePruningEnumerationTraversalCoverage.lean').write_text(base)
start=base.index('theorem complete_with_fragments_resources_accepting\n');end=base.index(' := by',start);header=base[start:end];body=base[end+len(' := by'):base.index('\nend MicroCFTA.SourcePruningEnumerationTraversalCompletion')]
outer=header.index('    ∃ (r n p h k');obs=header.index('      ∀ (ambient :');resultStart=header.index('      (∀ extraRepresentative');oldObserver=header[obs:];strong=oldObserver+' ∧\n          EnumerationStorageProgress.pendingSize after.core extended ≤\n            EnumerationStorageProgress.pendingSize before.core assignment + NumberedTerms.forestSize terms'
privateHeader=header[:obs]+strong;privateHeader=privateHeader.replace('theorem complete_with_fragments_resources_accepting\n','private theorem complete_with_pendingSize\n',1)
replacements=[
('SourcePruningEnumerationChildCompletion.complete_with_fragments_resources_accepting seed','SourcePruningEnumerationChildCompletion.complete_with_fragments_resources_accepting_pendingSize seed'),
('middleRoots, outer, waiting, ⟨headRun,','middleRoots, outer, waiting, ⟨⟨headRun,'),
('middleKnown, _headTerminal⟩, headAccepting⟩ :=','middleKnown, _headTerminal⟩, _oldHeadAccepting⟩, headAccepting⟩ :='),
('exact ⟨assignment, fun _ _ => rfl, satisfied, rfl, rfl, satisfied⟩','exact ⟨assignment, fun _ _ => rfl, satisfied, rfl, rfl, satisfied, by simp [NumberedTerms.forestSize]⟩'),
('_extended, _fragment, _agree, _original, singleton, _filled, _satisfied⟩','_extended, _fragment, _agree, _original, singleton, _filled, _satisfied, _cost⟩'),
('headFill, middleSatisfied⟩ :=','headFill, middleSatisfied, headCost⟩ :='),
('tailComplete, tailFilled, afterSatisfied⟩ :=','tailComplete, tailFilled, afterSatisfied, tailCost⟩ :='),
('refine ⟨extended, agree, originalExtended, ?_, ?_, afterSatisfied⟩','refine ⟨extended, agree, originalExtended, ?_, ?_, afterSatisfied, ?_⟩')]
for a,b in replacements:
 assert a in body,a;body=body.replace(a,b,1)
body+='\n              · simpa only [NumberedTerms.forestSize, Nat.add_assoc] using\n                  Nat.le_trans tailCost (Nat.add_le_add_right headCost (NumberedTerms.forestSize terms))\n'
publicHeader=header[:resultStart]+'      ('+header[resultStart:].lstrip()+') ∧\n'+strong
publicHeader=publicHeader.replace('theorem complete_with_fragments_resources_accepting\n','theorem complete_with_fragments_resources_accepting_pendingSize\n',1)
wrapper='''
  obtain ⟨r, n, p, h, k, fragments, afterCaller, after, savedQueries, final, next,
    afterRoots, result, receipt⟩ :=
    complete_with_pendingSize seed formulas solver inventory beforeCaller before checkEmpty inputs
      roots memos initial safe paths counts flags realized genuine fits reserved known
  rcases receipt with ⟨running, post, querySame, growth, afterPaths, storage, afterRealized,
    afterCounts, afterFlags, origin, protectedEnumerated, protectedRoots, references,
    pendingReferences, bounds, shape, afterFits, afterKnown, accepting⟩
  refine ⟨r, n, p, h, k, fragments, afterCaller, after, savedQueries, final, next,
    afterRoots, result, ⟨running, post, querySame, growth, afterPaths, storage, afterRealized,
      afterCounts, afterFlags, origin, protectedEnumerated, protectedRoots, references,
      pendingReferences, bounds, shape, afterFits, afterKnown, ?_⟩, accepting⟩
  intro ambient residualMeaning assignment terms satisfied related
  obtain ⟨extended, agree, original, completed, filled, model, _cost⟩ :=
    accepting ambient residualMeaning assignment terms satisfied related
  exact ⟨extended, agree, original, completed, filled, model⟩
'''
pre=base[:start];pre=pre.replace('import MicroCFTA.SourcePruningEnumerationChildCoverage','import MicroCFTA.SourcePruningEnumerationChildModelStorageProgress')
pre=pre.replace('# Constructive coverage of resource-admitted child traversal','# One accepted assignment and cost through mixed child traversal').replace('Every accepted ordered input constructs a successful child singleton.','Every accepted ordered input constructs a successful child singleton.\nThe same assignment supplies its semantic model and pending graph cost.')
s=pre+privateHeader+' := by'+body+'\n/-- Retain every original traversal receipt and derive meaning and cost with one assignment. -/\n'+publicHeader+' := by'+wrapper+'\nend MicroCFTA.SourcePruningEnumerationTraversalCompletion\n'
d=p/'root-candidate-v1/MicroCFTA/SourcePruningEnumerationTraversalModelStorageProgress.lean';d.parent.mkdir(parents=True);d.write_text(s);print(dict(lines=len(s.splitlines()),bytes=len(s.encode())))
