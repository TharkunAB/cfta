"""Preserve pre-merge identities and initialize the next proof evidence area."""
from pathlib import Path
import hashlib,json,shutil,subprocess
ROOT=Path('/home/tritlo/Code/mcfta');OLD=Path('/tmp/mcfta-boundary-entry-progress-20261029');AREA=Path('/tmp/mcfta-prepared-ancestry-progress-20261029')
def record(path):
 raw=(ROOT/path).read_bytes();return dict(path=path,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
paths=subprocess.check_output(['rg','--files','lean/MicroCFTA','-g','*.lean'],cwd=ROOT,text=True).splitlines();lean=[record(x)for x in sorted(paths)if x!='lean/MicroCFTA/Audit.lean'];(AREA/'prior-lean-sources.json').write_text(json.dumps(lean,indent=2)+'\n');shutil.copyfile(ROOT/'lean/MicroCFTA/Audit.lean',AREA/'prior-Audit.lean')
for a,b in [('strong-sources.json','prior-strong-sources.json'),('public-declarations.json','public-declarations.json'),('public-definitions.json','public-definitions.json'),('public-definitions.json','prior-public-definitions.json')]:shutil.copyfile(OLD/a,AREA/b)
prior_hs=json.loads((OLD/'inherited-prior-haskell-sources.json').read_text());changed=[]
for row in prior_hs:
 current=record(row['path'])
 if current['sha256']!=row['sha256']:changed.append(dict(before=row,after=current))
assert all(x['before']['path']=='cabal.project'for x in changed),changed
shutil.copyfile(OLD/'inherited-prior-haskell-sources.json',AREA/'pre-merge-haskell-sources.json');tracked=subprocess.check_output(['git','ls-files','*.hs','*.cabal','cabal.project'],cwd=ROOT,text=True).splitlines();haskell=[record(x)for x in sorted(set(tracked)|{r['path']for r in prior_hs})];(AREA/'inherited-prior-haskell-sources.json').write_text(json.dumps(haskell,indent=2)+'\n');(AREA/'upstream-haskell-identity-delta.json').write_text(json.dumps(dict(old_count=len(prior_hs),new_count=len(haskell),changed_old=changed,new_files=sorted(set(tracked)-{r['path']for r in prior_hs})),indent=2)+'\n')
for f in ['public-final/raw.log','public-final/public.lean']:
 target=AREA/('prior-public-readback.log'if f.endswith('raw.log')else 'prior-public-readback/public.lean');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(OLD/f,target)
docs=json.loads((OLD/'final-documents.json').read_text());(AREA/'prior-documents.json').write_text(json.dumps(docs,indent=2)+'\n')
for row in docs:
 current=record(row['path']);assert current['sha256']==row['sha256'];target=AREA/'prior-document-bodies'/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/row['path'],target)
for f in ['modules.json','new-public-declarations.json','new-public-definitions.json']:(AREA/f).write_text('[]\n')
(AREA/'check-installed.py').write_text((OLD/'check-installed.py').read_text().replace(str(OLD),str(AREA)));(AREA/'peaks').mkdir();print(json.dumps(dict(prior_lean=len(lean),prior_strong=len(json.loads((AREA/'prior-strong-sources.json').read_text())),haskell=len(haskell),changed_old_haskell=len(changed),prior_docs=len(docs))))
