# Serialization source review after PR188 integration

Status: bounded SOURCE-ONLY review. No compiler, evaluator, native check,
Nix job or Haskell test ran in this child task. Root owns all checks and
repository/Git/board changes. All proposed code remains in this TMP tree.
Parent reports PR188/main63aae675c merged at
e216346905cfeb0b243799138b4c254a739de0aa; this child did not query Git.

## Concrete finding: parsed equality classes can throw an exception

The public parser returns Either TextError graph, but some finite malformed
inputs reach a partial core constructor instead of producing Left.

Minimal input with the lawful Text codec StateCodec id Right:

    graph 1; start S; state S { a where equal([], [0]); }

The explicit stored-class spelling reaches the same constructor:

    graph 1; start S; state S { a where constraint([[[], [0]]], true); }

Non-root strict prefixes also fail, for example equal([0], [0, 1]).
This is a source-justified exception prediction, not an executed result.

The exact route is:

- Text.hs531: equal(...) constructs PathEClass(Set.fromList paths) directly.
- Text.hs542: classesParser constructs each PathEClass the same way.
- Equality/Constraint.hs176-182: PathEClass' has a STRICT getPathTrie field.
- Equality/Constraint.hs195-199: the public PathEClass pattern calls toPathTrie.
- Equality/Constraint.hs118-144: toPathTrie explicitly errors when a distinct
  path is a prefix of another. [] plus [0] reaches headOf EmptyPath/error.
- readGraph and mkFTA validate state closure and symbol arities. They do not
  validate this annotation representation before the strict trie is forced.

The core constructor documents its precondition. The serialization reader
accepts unchecked external text, so it must enforce that precondition before
calling the constructor. This finding concerns malformed-input totality and
error reporting. It does not establish corruption of a fully defined lawful
stored graph on a print/parse round trip.

## Source-only reproducer and surgical proposed repair

repro-v1/PrefixClassException.hs supplies four failing shapes and four controls.
It catches SomeException and forces the complete shown parse result within
the handler. It requires no solver. It remains UNCOMPILED and UNEXECUTED.
Predicted original results: EXCEPTION for all four prefix cases, RIGHT for
empty class, singleton empty path, nonprefix class and repeated same path.
The repeated path becomes one set member, as the stored representation requires.

proposed-fix-v1/reject-prefix-classes.patch is a proposal, not an applied edit.
It adds one small checkedPathClass helper. It removes duplicate paths through
Set, then checks adjacent paths in ascending lexicographic order with the
existing isStrictSubpath. A strict prefix is immediately followed by an
extension in that order whenever any extension exists. It rejects the input
through parser fail before constructing PathEClass. Both equal(...) and
explicit class lists use this helper. It adds four cases to the EXISTING
malformed-input list and explains the representation restriction in README.

Expected fixed results: LEFT for all four bad cases, RIGHT for all controls.
Do not replace the class with EqContradiction using mkEqConstraints: that
would normalize stored constructors and contradict the exact-storage contract.
Empty and singleton classes must remain accepted. Negative indexes remain
representable and retained. Inter-class prefix relationships remain allowed;
only strict prefix pairs WITHIN one class violate this trie representation.
Printing valid values remains byte-for-byte unchanged by the proposal.

Root must run the focused reproducer before/after and the existing package
suite in the requested serial4GiB Nix environment. Root can format/apply the
proposal and record the verified Haskell fix in FINDINGS. This child neither
applied the proposal nor changed Haskell source in the repository.

## Claims checked against source; no further defect established

State labels: the printer escapes the TEXT produced by the codec, and the
parser unescapes it before decodeState. Empty labels, _, spaces, quotes,
backslashes, controls, Unicode and keyword-like labels use the same route.
showCodec correctness is explicitly conditional on lawful Show/Read; custom
codecs must decode an encoding to the SAME state and preserve equality/order.
An intentionally lossy codec is outside the documented law and is not a defect.

Notes: comments and sort labels are separate from the graph value. The printer
prints file notes and notes for every actual row, including unreachable/dead
rows. It deliberately drops notes for absent states, as documented and tested.
One inserted space after /// is removed by commentParser. Text.splitOn and
Text.intercalate retain empty/trailing lines. The code keeps CR inside note
text rather than treating it as a quoted-name escape. Existing fixtures include
empty notes, leading/trailing spaces, slashes, Unicode, newlines and CRLF text.
No present-item note or state-sort loss was established by this review.

Constraints: printing and parsing use the actual constructors. Neither invokes
a logical simplifier. Equality class LIST order is retained; paths within each
class are a Set. Empty/singleton classes, EqContradiction versus a bottom guard,
empty And/Or, ordered substitutions, all guard cases and invalid-but-representable
Int paths have explicit spellings. The prefix finding above concerns a class
that cannot be represented by the existing trie, not an omitted normalization.

Refinements: symbolRefinement is printed in full; only exact F.Top is omitted.
Symbol interning uses the text and STRUCTURAL Formula key. Formula/Guard Eq
is structural. Arithmetic/Neg/Lit, quantifiers with ordered duplicate bindings,
function sorts and every current term/formula constructor have matching cases.
The distinguished name is __cfta_value. The concise v term decodes to that name;
var(v) decodes to the ordinary name v. These remain distinct.

Lexical boundaries: keyword rejects name-character suffixes. integerParser
uses Integer; pathParser explicitly checks the machine Int range. Quoted
strings reject unescaped characters below U+0020 and decode the documented
simple escapes and valid surrogate pairs. Four-or-more-slash comments are
presentation; exactly-three-slash comments attach to a header or state.
Malformed forms are not silently ended by generic many: explicit lookahead
selects declarations and explicit delimiters select list/block completion.
No additional accepted-input mismatch was established in these paths.

Graph validation: readGraph checks duplicate DECODED states before mkFTA,
then reports MissingInitialState, DanglingState and InconsistentArity through
InvalidGraph. Graph rows and transition lists are not pruned or deduplicated.
Repeated transitions and child order remain represented. The validator keys
arity by the complete Symbol, as the existing core type requires.

## Existing test scope and limits

The complete395-line Spec.hs covers graph round trips, unusual names and
stored constraints, structured states and explicit codecs, notes and sorts,
malformed input, escapes and bounded reopened ranks. The all-forms fixture
covers formula/term/guard constructors and class representations. Rank checks
are bounded to size7 and omit all-forms; they require Z3. These tests are not a
formal universal round-trip proof. No new test result is claimed here.

The existing malformed list does not include a class with comparable distinct
paths. The proposed four entries cover both compact/explicit spellings and
root/non-root prefixes. Existing positive fixtures already cover empty and
singleton classes; the standalone controls also protect duplicates and two
nonprefix paths.

## Evidence and FINDINGS handoff

All full inputs and exact literal cuts have byte/line counts and SHA256 in
manifest-v1.json. Text.hs718L was read WHOLE across1-240,241-480,481-718.
Spec.hs395L was read WHOLE across1-205 and206-395. The one truncated discovery
batch was followed by full untruncated reads of its affected material.
Large core files are identified only by their exact read cuts.

Reviewed original Text.hs SHA256:
ede0ff898f5e422102b54dd81e2cea0d67806219f38b4c705a4538ee313c79ec.
Reviewed original Spec.hs SHA256:
28f3fe1b0eebcef24a9764960034bcf6b5efeda9db3d0ebb2d581a0e46d0afd2.

FINDINGS item for root: the new serialization reader reaches partial
PathEClass/toPathTrie from unchecked prefix-related paths. Record the exact
before/after execution evidence when available. The proposed fix validates
the representability precondition in BOTH parsing paths without normalizing
stored values. This is the only new Haskell defect identified in this bounded
review. Repository files and all older evidence remain unchanged by this child.

Freeze after final retained-input/candidate identity checks. No more work is
needed from this child unless root requests a source-specific follow-up.
