{-# LANGUAGE OverloadedStrings #-}

-- Source-only reproducer. Root owns compilation and execution.
module Main (main) where

import Control.Exception (SomeException, evaluate, try)
import Control.Monad (forM_)
import Data.Text (Text)
import qualified Data.CFTA.Serialization.Text as T

main :: IO ()
main = forM_ cases $ \(label, constraint) -> do
    let input = "graph 1; start S; state S { a where " <> constraint <> "; }"
        parsed = T.parseGraphWith (T.StateCodec id Right :: T.StateCodec Text) input
    -- Force the complete printed result inside the exception handler.
    observed <- try (evaluate (case parsed of Left _ -> 0; Right graph -> 1 + length (show graph))) :: IO (Either SomeException Int)
    putStrLn (label <> ": " <> either (\failure -> "EXCEPTION " <> show failure) (\size -> if size == 0 then "LEFT" else "RIGHT") observed)

cases :: [(String, Text)]
cases =
    [ ("prefix-root-equal", "equal([], [0])")
    , ("prefix-nested-equal", "equal([0], [0, 1])")
    , ("prefix-root-explicit", "constraint([[[], [0]]], true)")
    , ("prefix-nested-explicit", "constraint([[[0], [0, 1]]], true)")
    , ("valid-empty-class", "equal()")
    , ("valid-root-class", "equal([])")
    , ("valid-nonprefix-class", "equal([0], [1])")
    , ("valid-duplicate-path-set", "equal([0], [0])")
    ]
