# Actual terminal-pipeline ancestry extension

Status: four immutable source-only candidate modules. UNTESTED by this child.
Root owns compilation, runtime/native evaluation, repository edits, Git,
network and board actions. No earlier evidence directory was changed.

## Delivered interfaces

All modules use the full SourcePruningEnumeration prefix:

- TerminalPrefixAncestryExtension.lean47L/2,603B.
- FoldAncestryExtension.lean145L/7,982B.
- IncomingAncestryExtension.lean231L/11,780B.
- TerminalAncestryExtension.lean114L/6,631B.

The public conclusion at each actual endpoint is:

  Extends before after ∧ after.expansionAncestry = before.expansionAncestry

Cached variants use before.core and after.core. Extends quantifies EVERY slot,
including the next fresh counter and other slots beyond the current counter.
It retains every complete historical key; it does not merely retain membership
in a shape carrier. No carrier, KeyAncestry, Packet, bounds, model or resource
admission is an input to these public observer statements.

The seven complete public source headers are in public-signatures-v1.json.
No compiler print or claimed successful build is substituted for those headers.
Every candidate retains its local notation and typeclass context in full.

Terminal public API is exactly:

  CachedTerminalAdapter.candidate_ancestry_extension
    checkEmpty r n p h k first rest caller before incoming incomingScs
    queries after candidate

The final argument is the actual run's .2 = some after observation.
The head-chain owner was sent this exact name, module and argument order.

## Proof structure and observer scope

TerminalPrefix.run_ancestry_extension takes the original successful prefix
observation. It follows the actual mapM representative reads, ordered unions,
final representative read and pure return. Its fixed-origin invariant is the
Extends/expansion pair. Those operations change only representatives, so both
fields remain exact. It does not assert that a successful prefix exists.

Fold.run_ancestry_extension takes a literal full four-field return tuple at
any supplied native/p/h fuels. It covers native errors, missing actions,
Empty/rejected raw lists, inner errors, nonsingleton raw lists and the actual
recursive singleton branch. An unchanged outer core uses reflexivity. A
successful dispatcher singleton uses root's actual dispatch observer. The
ordered tail composes Extends in forward order and expansion equalities in
reverse endpoint order. No successful-output premise excludes stopped cases.

CachedFold.candidate_ancestry_extension requires only the actual some-cache
observation. It follows the original cached fold. It uses the root adapter's
actual raw-singleton observer before the next call, including the exact core
framed into the recovered cache. Empty or otherwise attached terminal raw
shapes use that same adapter's actual cache observer. A missing cache cannot
satisfy this candidate hypothesis. No future cache supplier is assumed.

IncomingNode.run_ancestry_extension returns TWO facts: the pair at the exact
outer read core for every run result; and the pair for each actually observed
successful raw singleton. The actual findRoot read changes only the forest.
The actual successful finish writes a value and inherits expansion keys at
the target while retaining its old keys. The proof follows the literal
native-query/optional-empty branches. It does not claim a raw singleton exists.

IncomingCacheAdapter.observed_cache_ancestry_extension follows the literal
cache attachment. In the Empty raw case, the actual adapter reconstructs the
Empty value and ancestry inheritance. The proof composes the outer-read
pair with that exact reconstructed update. In the successful singleton case,
adapt_singleton_core identifies the actual cached core with the raw result.
The private helper's read/row facts are discharged by IncomingNode's actual
observer in the public theorem. They are not new public future-step oracles.

CachedAssimilation.finish_ancestry_extension is included in the Incoming
module, as authorized. The existing finish_ancestry first projection already
is all-slot Extends. The new proof derives only the additional expansion
identity from the actual Empty return or two actual NativeIndex.write calls
and the literal final frame. It does not duplicate the old ancestry proof.

CachedTerminalAdapter.candidate_ancestry_extension follows the actual Empty
short circuit, prefix singleton, cached fold and incoming attachment. The
raw singleton core is synchronized with the exact fold outer core by the
existing Fold.singleton_core theorem. The actual frame then supplies that
same folded core to the incoming adapter. Extends and expansion equalities
compose across the original prefix, fold and incoming endpoints. Failure
branches that return no cache cannot satisfy the supplied some-cache observer.

## Root dependencies checked

Root SourcePruningEnumerationAncestryExtension was read WHOLE. It defines
Extends, reflexivity, transitivity and actual allocated/assimilated retention.
Root AncestryExtensionStorage was read WHOLE. Its NativeIndex.write observer
retains Extends plus exact expansion equality. The actual NativeIndex.write
and EnumerationExpandableIndex.frame definitions were read in literal cuts.

Root CachedAdapterAncestryExtension was read WHOLE after it appeared. Its
Dispatch.dispatch_ancestry_extension has exactly the old dispatch observer
arguments after removal of carrier/bounded. Its output is the required pair.
CachedAdapter.run_ancestry_extension gives BOTH actual singleton and attached
cache pair observers in the exact tuple projections used by the draft fold.
No additional API is needed from root.

The original four KeyAncestry pipeline proofs and relevant old dispatch,
cache and assimilation proofs were read WHOLE. Their source identities are
preserved. These new modules are additive; they do not rewrite old theorems,
modify runtime definitions or cast original/prepared receipt types.

## Limits and verification

These are local actual-operation preservation statements. They do not prove
global driver termination, existence of an emitted model, coverage, a finite
handle carrier, or a fixed original native Mu degree ceiling. Exact expansion
equality is claimed only for these operations; it is not asserted for the
whole expansion-entry protocol that deliberately changes that field.

No sorry, admit, custom axiom, native_decide, evaluation limit, linter
suppression or new semantic supplier was added. No compiler was invoked.
Root may retain a separate repaired version if elaboration or strict checks
find bookkeeping errors; immutable v1 source bytes must remain unchanged.

Eleven WHOLE Lean inputs total61,067 bytes and1,146 lines. Nine exact literal
cuts total46,895 bytes and792 lines. The four WHOLE candidates total28,996
bytes and537 lines. Every candidate was read back in full. The one broad
runtime discovery call was truncated; only the later exact source cuts and
complete rereads are claimed as proof-reading scope. manifest-v1.json and
FILES-v1.json preserve source/cut/candidate identities and the final inventory.

## Haskell handoff status

This proof task found no new Haskell issue and made no Haskell change.
The earlier serialization area remains frozen. Parent reports its repair
is now verified: all four malformed prefix-class cases return LEFT; all four
valid controls return RIGHT; the package has19 examples and0 failures under
-Werror, with Fourmolu and cabal-gild checks passing. Parent owns those raw
logs and the corresponding FINDINGS entry. These are parent-reported results,
not independent execution by this child.

Freeze after final source/candidate identity readback. No further source
candidate work is needed in this bounded task.
