# Source-review scope clarifications

The storage scope manifest field `parent_reported_main` holds the integration
commit e216346905cfeb0b243799138b4c254a739de0aa. The actual fetched origin/main
commit is 63aae675c5c6b8312bc5872fff065a7de3629aef. The bootstrap and Git
publication records identify both. The original author manifest stays unchanged.

Source-only author UNTESTED labels describe author execution status. Root
performed all recorded compiler and native checks. final-proof-sources.json
and strict-source-mapping.json identify the checked final installed versions.
The dispatch binder, incoming expected-type inference and stopped-Option
reduction repairs are proof-only. Their failed inputs and raw logs stay intact.

The serialization review preserved original upstream Text.hs, Spec.hs and README
copies. Root later repaired those three files. The two Haskell identity changes
are exact in haskell-repair-identity-delta.json. The third is format documentation.
The original 817 Haskell/Cabal sources stay byte-for-byte unchanged.

The terminal review preserved Root's first adapter source. Root later repaired
its local proof binder. The public signatures are identical. Scope verification
checks the preserved reviewed copy; final-source verification checks the actual
repaired source and its successful strict compiler input.
