# Stage interfaces

SourcePruningEnumerationAncestryExtensionStorage exports:
- NativeIndex.write_ancestry_extension observed
- CachedChild.allocate_ancestry_extension observed
- CachedChild.writeSlot_ancestry_extension observed
- CachedChild.prepareOrdinary_ancestry_extension observed

Each takes the literal successful operation equation, with all runtime inputs and endpoints implicit. Each returns Extends before.core after.core and equality of after.core.expansionAncestry with before.core.expansionAncestry. No original Extends premise, model, aligned counter, or history domain is assumed.

SourcePruningEnumerationAncestryExtensionOwn exports:
- CachedOwn.suspendMany_ancestry_extension heap tries before after suspended observed
- CachedOwn.prepare_ancestry_extension observed: every actual prepared row extends before.core and preserves expansion ancestry
- CachedPrepare.rows_ancestry_extension heap fuel scs value before rows observed: every actual (fragment, after) row extends before.core and preserves expansion ancestry
- CachedPrepare.cache_ancestry_extension heap fuel scs value before after observed: the actual []/singleton cache extraction extends before.core and preserves expansion ancestry
- Finalize.run_ancestry_extension heap fuel target fragment before after observed: Extends before.core after.core and after.core.expansionAncestry = []
- SelectedEdge.finish_ancestry_extension residual fragment before: Extends before.core (finish residual fragment before).core and unchanged expansion ancestry

The existing CachedAssimilation.finish_ancestry observed first projection already has the exact Extends conclusion. Do not duplicate it merely to rename that statement.
