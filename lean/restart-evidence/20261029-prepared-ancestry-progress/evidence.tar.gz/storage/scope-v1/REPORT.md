# Actual cached ancestry extension

Timestamp: 2026-10-29 00:47:28 CET.
Root owns repository edits, compiler, native evaluation, Git, network, and board operations. Root reported main PR188 merged at `e216346905cfeb0b243799138b4c254a739de0aa`, with Lean unchanged. The author did not inspect Git or run a build.

## Frozen candidates

`candidate-v1/MicroCFTA/SourcePruningEnumerationAncestryExtensionStorage.lean`

85 lines; 4973 bytes; SHA256 `059c130d5f5c44ce9ffd932d5f7ac9920b1373e085b05080683c3a96977d58fe`.

`candidate-v1/MicroCFTA/SourcePruningEnumerationAncestryExtensionOwn.lean`

176 lines; 9154 bytes; SHA256 `14cba962f998202f1239d9dfa30f529e5bae1741f2b4fca13babe1521820f712`.

Author status: UNTESTED source candidates. Root owns compilation and installation. The fixed base interfaces were read from the actual installed `SourcePruningEnumerationAncestryExtension` module. Root's later compiler status is not inferred from source review.

## Exact stage contracts

The Storage module adds four actual-operation observations:

- `NativeIndex.write_ancestry_extension observed`.
- `CachedChild.allocate_ancestry_extension observed`.
- `CachedChild.writeSlot_ancestry_extension observed`.
- `CachedChild.prepareOrdinary_ancestry_extension observed`.

All runtime arguments are implicit, as in the older storage observers. Each literal successful equation derives `Extends before.core after.core` and `after.core.expansionAncestry = before.core.expansionAncestry`. No prior Extends, aligned counter, original model, history carrier, future heap, or preservation premise is required.

The Own module adds these six observations:

- `CachedOwn.suspendMany_ancestry_extension heap tries before after suspended observed`.
- `CachedOwn.prepare_ancestry_extension observed row member`.
- `CachedPrepare.rows_ancestry_extension heap fuel scs value before rows observed fragment after member`.
- `CachedPrepare.cache_ancestry_extension heap fuel scs value before after observed`.
- `Finalize.run_ancestry_extension heap fuel target fragment before after observed`.
- `SelectedEdge.finish_ancestry_extension residual fragment before`.

Own allocation, each own row, each shallow child row, and actual supported shallow cache extraction derive the same extension and exact expansion equality. The cache extraction includes actual Empty rejection, which returns the original cache. Unsupported and malformed observations do not satisfy that success equation. The rowwise statements make no claim about a fabricated returned cache when no row exists.

Finalization derives extension and the actual stronger endpoint equation `after.core.expansionAncestry = []`. It does not claim unchanged expansion history. Residual recording is total and preserves expansion ancestry. Its theorem has no Total parameter.

`signatures/` preserves all 10 complete public declarations. The complete candidates preserve imports, local notation, namespaces, and all implicit type parameters.

## Actual proof chain

The indexed write proof inverts its candidate and two count observations. The actual returned record changes values and indexes, so both history fields remain unchanged. `writeSlot` reuses that fact after its actual old-slot read.

Cached allocation exposes the exact core equality with `EnumerationState.allocated`. The proof uses Root's `Extends.allocated before.core node`. This is stronger than the old cached allocation relation restricted to slots below the counter. It retains old keys at EVERY slot, including the stale ancestry already stored at the next fresh counter. Expansion ancestry remains unchanged. No allocation-domain hypothesis is added.

Ordinary preparation composes its actual allocation with its actual indexed bucket write. Own `suspendMany` follows the actual ordered allocation list and composes the derived extensions. Own `prepare` follows the actual projection and suspendMany result, then checks membership in its actual returned singleton row.

Shallow child preparation follows the actual node/opaque allocation branches. The cache observer follows its actual empty or singleton result. The finalizer reuses the indexed write observer on the literal reset state. Residual finish changes only obligations.

The older `CachedAssimilation.finish_ancestry observed` first projection already has exactly the Extends conclusion. No new wrapper duplicates that result. The older CachedChild/CachedOrdinary ancestry lemmas need an aligned gate and preserve old keys only below the counter; they cannot supply the new all-slot conclusion alone. KeyAncestry carrier inclusion also does not identify the original full keys, so it is not used as a replacement for extension.

## Base source observation

The first whole read of Root's new base exposed two fresh/target proof branches where the original member still used the arbitrary slot. The author reported the need to substitute that slot. The later whole source read includes Root's `subst slot` repairs in both branches. Public helper names and hypotheses stayed unchanged. The manifest binds the exact repaired base source that the candidates consume. The author made no repository change.

## Integration and limits

The higher head worker received the exact confirmed import and argument order before authoring its composition. Each observer derives its relation from the literal runtime operation. It does not require an arbitrary stage-preservation supplier. Any recursive-hook relation in the higher pipeline remains that worker's explicit local induction contract.

These modules prove monotone retention of actual per-slot recursion keys. They do not bound native handles, prove termination, construct a globally complete run, establish full model emission, or claim equality of current expansion ancestry across finalization. They add no runtime definition or broad history contract.

## Evidence and ownership

`MANIFEST.json` records candidate and signature identities, complete copied source identities, precise whole-versus-cut read ranges, and byte equality at seal. `cuts/` preserves every listed literal source range. Copied source outside those ranges is provenance only. Some exploratory broad output was truncated; no claim is made that such unlisted ranges were read.

Both candidates, interface note, and report are immutable. No compiler, evaluator, native, Git, network, board, repository-write, or Haskell-change operation was performed by the author. Earlier frozen areas remain unchanged.
