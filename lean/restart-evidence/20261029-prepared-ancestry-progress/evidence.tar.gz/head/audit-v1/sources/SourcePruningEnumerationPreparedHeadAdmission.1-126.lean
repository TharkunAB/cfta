import MicroCFTA.SourcePruningEnumerationPreparedFiniteHeadResources

/-!
# Resource admission at an actual completed prepared head

The original stored handle and the actual prepared ordinary parent remain
separate. Both source indexes stay in the completed-head certificate.
One original prepared head producer supplies every old result field.
Each actual completion adds its own full input and returned resource receipt.
No source-to-prepared language equivalence is inferred from these inputs.
-/
namespace MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources
open EnumerationState EnumerationSchedule InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Post)
open SourceCurrentConstrainedCapGeneratedQueryResources (Fits)
open SourcePruningEnumerationIncomingReservation (Seed)
open SourcePruningEnumerationNativeBranchCompletion (Admitted Pending FragmentHistory HeadCacheBounds edgeCost)
open SourcePruningEnumerationRecursive (Packet Output)
open SourcePruningEnumerationPreparedRecursive (Failure continueWith resume Complete OutcomeResources)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Receipt" => SourcePruningEnumerationSelectedEdge.Result
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
local notation "HookResult" => SourcePruningEnumerationNativeContinuations.HookResult
local notation "advance" => SourcePruningEnumerationNativeBranches.advance
local notation "scalar" => SourceCurrentConstrainedCapTargetForecast.scalar
local notation "guardWidth" => SourcePruningEnumerationGuardWidth.width
local notation "suspendedBound" => SourcePruningEnumerationPrefixAdmission.suspendedBound
local notation "afterHead" => SourcePruningEnumerationRecursiveReservation.afterHead
local notation "finiteStep" => SourcePruningEnumerationPreparedReservation.step
local notation "massCeil" => SourcePruningEnumerationRecursiveReservation.massCeil
variable {Typing Key : Type} {bits : Nat}
variable [DecidableEq (EdgeKey Symbol Constraint)]

/-- The current input and its original edge reservation admit one actual native head. -/
structure HeadAdmission
    (seed : Seed) (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos)
    (metadata : SourcePruningRecordTypes.Metadata Typing) (before : Cached)
    (uv handle : Nat) (scs : List Suspended)
    (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
    (storedEdges : List (EdgeValue Symbol Constraint)) (depth : Nat)
    (free : List InternedBinderProtocol.Reference) (edge : EdgeValue Symbol Constraint) : Prop where
  /-- The full input memo state and captured cache satisfy the recursive packet. -/
  packet : Packet formulas solver inventory caller memos metadata before
  /-- The captured slot is a live pending root. -/
  ready : EnumerationDriver.Ready uv before.core
  /-- Stored suspended references avoid the captured class. -/
  incoming : EnumerationReferences.IncomingAvoid uv before.core
  /-- The actual native caller fits the original numeric profile. -/
  bounded : Fits seed.2 caller.checked
  /-- Every current native guard belongs to the original carrier. -/
  known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap
  /-- The original captured slot retains its own stored handle and bucket. -/
  stored : before.core.values[uv]? = some (.unenumerated (some handle) scs)
  /-- The separately indexed prepared parent is available at this actual caller. -/
  parentAvailable : Available caller.checked.native.machine.heap (.node parentEntry storedEdges depth free)
  /-- The separately indexed prepared parent is closed. -/
  parentClosed : free = []
  /-- This actual prepared parent contains the selected edge. -/
  selected : edge ∈ storedEdges
  /-- The same input seed reserves this edge's actual mixed-query cost. -/
  reserved : SourcePruningEnumerationIncomingReservation.Reserved bits seed
    (edgeCost scs before.core.counter edge)

variable [DecidableEq Symbol] [DecidableEq Node]

/-- One actual completed head retains its input admission and both own endpoint packets. -/
structure CompletedHeadReceipt
    (seed : Seed) (inherited : Nat)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos)
    (metadata : SourcePruningRecordTypes.Metadata Typing) (before : Cached)
    (checkEmpty : Bool) (uv handle : Nat) (scs : List Suspended)
    (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
    (storedEdges : List (EdgeValue Symbol Constraint)) (depth : Nat)
    (free : List InternedBinderProtocol.Reference) (edge : EdgeValue Symbol Constraint)
    (bound : Nat) (fragment : Fragments.Fragment Symbol) (reached : Caller (bits + 2))
    (saved : Queries) (after : Cached) (returnedInventory : Inventory) (returnedMemos : Memos) : Prop where
  /-- The certificate starts at the literal head input. -/
  admission : HeadAdmission seed formulas solver inventory caller memos metadata before
    uv handle scs parentEntry storedEdges depth free edge
  /-- The actual head keeps every native postcondition at its full memo state. -/
  post : Post formulas solver returnedInventory caller reached returnedMemos
  /-- The returned queries are the query field of that full memo state. -/
  query : returnedMemos.query = saved
  /-- Native effects retain the original captured cache at the reached caller. -/
  captured : Packet formulas solver returnedInventory reached returnedMemos metadata before
  /-- The actual completed cache has its own recursive packet at the same caller. -/
  completed : Packet formulas solver returnedInventory reached returnedMemos metadata after
  /-- The same completed receipt retains its actual cache admission. -/
  admitted : Admitted uv (.complete fragment reached saved after)
  /-- The same completed receipt retains its pending references. -/
  pending : Pending (.complete fragment reached saved after)
  /-- The same completed receipt retains its fragment and dependency history. -/
  history : FragmentHistory before.core (.complete fragment reached saved after)
  /-- The same completed receipt retains its original allocation bounds. -/
  cacheBounds : HeadCacheBounds before scs (scalar seed.2) (guardWidth seed.1)
    (.complete fragment reached saved after)
  /-- The reached caller fits the original padded head forecast. -/
  bounded : Fits (afterHead seed inherited).2 reached.checked
  /-- The reached native heap uses the same padded head carrier. -/
  known : Heap (fun guard => guard ∈ (afterHead seed inherited).1) reached.checked.native.machine.heap
  /-- Actual completion passes the original arity check. -/
  allowed : arityAllows edge.children.length scs = true
  /-- Actual completion uses a successful projection of this edge's own constraint. -/
  projected : ∃ (tries : List EqualityTrie.Trie) (residual : Option Constraint),
    SourcePruningEnumerationConstraint.project edge.entry.key.constraint = some (tries, residual)
  /-- Every larger common work bound returns this same actual completed receipt. -/
  running : ∀ extra, SourcePruningEnumerationCapturedEdge.run checkEmpty
    (bound + extra) (bound + extra) (bound + extra) (bound + extra) (bound + extra)
    uv scs edge caller before memos.query = some (.complete fragment reached saved after)

private theorem completed_supported
    (checkEmpty : Bool) (r n p h k uv : Nat) (scs : List Suspended)
    (edge : EdgeValue Symbol Constraint) (caller : Caller (bits + 2)) (before : Cached) (queries : Queries)
    (fragment : Fragments.Fragment Symbol) (reached : Caller (bits + 2)) (saved : Queries) (after : Cached)
