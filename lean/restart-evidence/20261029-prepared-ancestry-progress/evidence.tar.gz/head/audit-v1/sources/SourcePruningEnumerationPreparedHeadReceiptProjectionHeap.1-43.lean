import MicroCFTA.SourcePruningEnumerationPreparedHeadAdmission
import MicroCFTA.SourcePruningEnumerationCapturedPreparedProjectionHeap

/-!
# Projection at the actual prepared completed-head caller

The prepared parent supplies its own availability and closure.
The original stored handle remains separate from that parent.
The literal completed execution identifies the reached native heap.
-/
namespace MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources
open EnumerationState EnumerationCorrectness EnumerationSchedule InternedConstructorTemplates
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourcePruningEnumerationIncomingReservation (Seed Reserved)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "projectable" =>
  (fun constraint : Constraint => SourcePruningEnumerationConstraint.project constraint ≠ none)
local notation "ProjectionHeap" => SourceEqualityAnnotationHeap.Heap projectable
variable {Typing : Type} {bits : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)]
variable [DecidableEq (Value Symbol Constraint)]

/-- An actual prepared head retains projection from its original input caller. -/
theorem CompletedHeadReceipt.projection_heap
    {seed : Seed} {inherited : Nat}
    {formulas : SourceGuards.Formulas FullSyntax.Formula}
    {solver : SourceGuards.Entailment FullSyntax.Formula} {inventory : Inventory}
    {caller reached : Caller (bits + 2)} {memos returnedMemos : Memos}
    {metadata : SourcePruningRecordTypes.Metadata Typing} {before after : Cached}
    {checkEmpty : Bool} {uv handle : Nat} {scs : List Suspended}
    {parentEntry : Cache.Interned InternedBinderProtocol.NodeKey}
    {edges : List (EdgeValue Symbol Constraint)} {depth : Nat}
    {free : List InternedBinderProtocol.Reference} {edge : EdgeValue Symbol Constraint}
    {bound : Nat} {fragment : Fragments.Fragment Symbol} {saved : SourceEndpointMemo.Memos}
    {returnedInventory : Inventory}
    (head : CompletedHeadReceipt seed inherited formulas solver inventory caller memos metadata
      before checkEmpty uv handle scs parentEntry edges depth free edge bound fragment reached
      saved after returnedInventory returnedMemos)
    (originalProjection : ProjectionHeap caller.checked.native.machine.heap) :
