import MicroCFTA.SourcePruningEnumerationCachedChild

namespace MicroCFTA.SourcePruningEnumerationCachedPrepare
open EnumerationState EnumerationSchedule EnumerationCorrectness
open SourcePruningEnumerationNodes SourcePruningEnumerationObservation
local notation "Symbol" => SourcePruningTemplates.Symbol
variable {EnumGuard NativeGuard : Type}

/-- Keep rejection distinct from partiality in the cached child preparation. -/
def prepareChild
    (heap : InternedConstructorTemplates.State Symbol NativeGuard)
    (fuel : Nat) (scs : List EnumerationState.Suspended)
    (value : InternedConstructorTemplates.Value Symbol NativeGuard)
    (before : EnumerationExpandableIndex.Cached Symbol EnumGuard) :
    Option (List (Fragments.Fragment Symbol × EnumerationExpandableIndex.Cached Symbol EnumGuard)) :=
  match value with
  | .empty => some []
  | .reference _ => none
  | .node _ _ _ _ =>
      (SourcePruningEnumerationCachedChild.prepareOrdinary heap fuel scs value before).map
        fun result => [result]
  | .union _ _ _ _ | .mu _ _ _ _ =>
      if scs.any (fun sc => EqualityTrie.isTerminal sc.trie) then none
      else
        (encodeNode value).bind fun handle =>
          (SourcePruningEnumerationCachedChild.allocate heap (some handle) before).map
            fun allocation => [(.hole allocation.1, allocation.2)]

/-- Every available cached result erases to the original prepared action. -/
theorem erase_some
    (heap : InternedConstructorTemplates.State Symbol NativeGuard)
    (fuel : Nat) (scs : List EnumerationState.Suspended)
    (value : InternedConstructorTemplates.Value Symbol NativeGuard)
    (before : EnumerationExpandableIndex.Cached Symbol EnumGuard)
    (rows : List (Fragments.Fragment Symbol × EnumerationExpandableIndex.Cached Symbol EnumGuard))
    (cached : prepareChild heap fuel scs value before = some rows) :
    (SourcePruningEnumerationShallowChild.prepareChild scs value).map
      (fun action => ExceptT.run (action before.core)) =
      some (rows.map (fun row => .ok (row.1, row.2.core))) := by
  cases value with
  | empty =>
    simp only [prepareChild, Option.some.injEq] at cached
    subst rows
    rfl
  | reference name => simp [prepareChild] at cached
  | node entry edges depth free =>
    by_cases terminal : scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = true
    · simp [prepareChild, SourcePruningEnumerationCachedChild.prepareOrdinary, terminal] at cached
    simp only [prepareChild, Option.map_eq_some_iff] at cached
    obtain ⟨result, prepared, rowsSame⟩ := cached
    subst rows
    simp only [SourcePruningEnumerationCachedChild.prepareOrdinary, terminal, Bool.false_eq_true,
      ↓reduceIte, encodeNode, Option.bind_some, Option.bind_eq_some_iff,
      Option.map_eq_some_iff] at prepared
    obtain ⟨allocation, allocated, after, written, resultSame⟩ := prepared
    subst result
    simp only [SourcePruningEnumerationCachedChild.allocate, Option.map_eq_some_iff] at allocated
    obtain ⟨flag, _classified, allocationSame⟩ := allocated
    subst allocation
    simp only [SourcePruningEnumerationCachedChild.writeSlot, Option.bind_eq_some_iff] at written
    obtain ⟨old, _stored, nativeWritten⟩ := written
    simp only [SourcePruningEnumerationNativeIndex.write, Option.bind_eq_some_iff,
      Option.some.injEq] at nativeWritten
    obtain ⟨afterFlag, _afterClassified, removed, _removedCounts, saved, _savedCounts, afterSame⟩ := nativeWritten
    subst after
    simp only [SourcePruningEnumerationShallowChild.prepareChild, terminal, Bool.false_eq_true,
      ↓reduceIte, encodeNode, Option.map_some, List.map_cons, List.map_nil]
    rw [EnumerationCorrectness.bind_single _ _ before.core
      (EnumerationState.allocated (some (entry.identity + 1)) before.core) before.core.counter
      (EnumerationState.allocate_exact _ _)]
    rfl
  | union entry _ _ _ | mu entry _ _ _ =>
    by_cases terminal : scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = true
    · simp [prepareChild, terminal] at cached
    simp only [prepareChild, terminal, Bool.false_eq_true, ↓reduceIte,
      encodeNode, Option.bind_some, Option.map_eq_some_iff] at cached
    obtain ⟨allocation, allocated, rowsSame⟩ := cached
    subst rows
    simp only [SourcePruningEnumerationCachedChild.allocate, Option.map_eq_some_iff] at allocated
    obtain ⟨flag, _classified, allocationSame⟩ := allocated
    subst allocation
    simp only [SourcePruningEnumerationShallowChild.prepareChild, terminal, Bool.false_eq_true,
      ↓reduceIte, encodeNode, Option.map_some, List.map_cons, List.map_nil]
    rw [EnumerationCorrectness.bind_single _ _ before.core
      (EnumerationState.allocated (some (entry.identity + 1)) before.core) before.core.counter
      (EnumerationState.allocate_exact _ _)]
    rfl

/-- Derive the native cached allocation and all stored-state invariants. -/
theorem allocate_complete
    (heap : InternedConstructorTemplates.State Symbol NativeGuard)
    (node : Option Nat) (before : EnumerationExpandableIndex.Cached Symbol EnumGuard)
    (roots : Nat → Nat)
    (realizable : ∀ (handle : Nat), node = some handle →
      ∃ value : InternedConstructorTemplates.Value Symbol NativeGuard,
        lookupNode heap handle = some value ∧
        InternedProbeProvenance.Available heap value ∧ value.free = [])
    (storage : StorageValid before.core) (realized : PendingRealized heap before.core)
    (paths : Roots before.core.representatives roots)
    (counts : EnumerationCanonicalWaiting.Correct roots before.core.values before.waiting)
    (flags : ∀ (slot : Nat), SourcePruningEnumerationNativeIndex.candidate heap
      ((before.core.values[slot]?).getD .eliminated) = some (before.expandable slot)) :
    ∃ (flag : Bool) (after : EnumerationExpandableIndex.Cached Symbol EnumGuard),
      SourcePruningEnumerationNativeIndex.candidate heap (.unenumerated node []) = some flag ∧
      SourcePruningEnumerationCachedChild.allocate heap node before =
        some (before.core.counter, after) ∧
      ExceptT.run (EnumerationState.allocate node before.core) =
        [.ok (before.core.counter, after.core)] ∧
      after.core = EnumerationState.allocated node before.core ∧
      after.core.values[before.core.counter]? = some (.unenumerated node []) ∧
      after.core.counter = before.core.counter + 1 ∧
      after.core.counter = after.core.values.length ∧
      after.core.representatives = before.core.representatives ∧ Roots after.core.representatives roots ∧
      StorageValid after.core ∧ PendingRealized heap after.core ∧
      EnumerationCanonicalWaiting.Correct roots after.core.values after.waiting ∧
      after.waiting = before.waiting ∧
      after.expandable = (fun slot => if slot = before.core.counter then flag else before.expandable slot) ∧
      (∀ (slot : Nat), SourcePruningEnumerationNativeIndex.candidate heap
        ((after.core.values[slot]?).getD .eliminated) = some (after.expandable slot)) := by
  have classification : ∃ flag : Bool, SourcePruningEnumerationNativeIndex.candidate heap
      (.unenumerated node []) = some flag := by
    cases node with
    | none => exact ⟨false, rfl⟩
    | some handle =>
        obtain ⟨value, decoded, _available, _closed⟩ := realizable handle rfl
