import MicroCFTA.SourcePruningEnumerationNativeBranches

namespace MicroCFTA.SourcePruningEnumerationNativeContinuations
open EnumerationState InternedConstructorTemplates
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => InternedConstructorTemplates.Value Symbol Constraint
local notation "Fragment" => Fragments.Fragment Symbol
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Receipt" => SourcePruningEnumerationSelectedEdge.Result
universe u v
variable {width : Nat} {Output : Type u} {Reason : Type v}

/-- A completed continuation supplies the native endpoint for the next alternative. -/
inductive HookResult (Output : Type u) (Reason : Type v) (width : Nat) where
  /-- Empty output includes normal pruning and a stuck restart. -/
  | complete (outputs : List Output) (caller : Caller width) (queries : Queries)
  /-- Keep the explicit stop reason and any actual reached native endpoint. -/
  | stopped (outputs : List Output) (reason : Reason) (reached : Option (Caller width × Queries))

/-- Keep the exact edge receipt or continuation stop without inventing an endpoint. -/
inductive Stop (Reason : Type v) (width : Nat) where
  /-- A missing or noncontinuable edge stops before the hook and the suffix. -/
  | edge (current : Option (Receipt width))
  /-- A stopped hook retains its actual completed edge receipt. -/
  | continuation (current : Receipt width) (reason : Reason)
      (reached : Option (Caller width × Queries))

/-- Retain ordered edge receipts, continuation outputs and the exact stopping context. -/
inductive Result (Output : Type u) (Reason : Type v) (width : Nat) where
  /-- Every edge and invoked continuation completed. -/
  | complete (processed : List (Receipt width)) (outputs : List Output)
      (caller : Caller width) (queries : Queries)
  /-- Retain the finished prefix and the current edge or continuation stop. -/
  | stopped (processed : List (Receipt width)) (outputs : List Output) (current : Stop Reason width)

variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Run each completed edge's continuation before the next edge at its returned native endpoint.
The captured enumeration input is fixed. The hook can close over fixed sibling metadata.
This bounded worker does not prove completion or full source-effect correspondence. -/
noncomputable def run
    (hook : Fragment → Caller width → Queries → Cached → HookResult Output Reason width)
    (checkEmpty : Bool) (r n p h k target : Nat) (scs : List Suspended) (before : Cached) :
    List (EdgeValue Symbol Constraint) → Caller width → Queries → Result Output Reason width
  | [], caller, queries => .complete [] [] caller queries
  | edge :: rest, caller, queries =>
      match SourcePruningEnumerationCapturedEdge.run checkEmpty r n p h k target scs edge caller before queries with
      | none => .stopped [] [] (.edge none)
      | some receipt =>
          match receipt with
          | .complete fragment reached saved after =>
              match hook fragment reached saved after with
              | .stopped outputs reason endpoint =>
                  .stopped [] outputs (.continuation receipt reason endpoint)
              | .complete outputs middleCaller middleQueries =>
                  match run hook checkEmpty r n p h k target scs before rest middleCaller middleQueries with
                  | .complete processed later finalCaller finalQueries =>
                      .complete (receipt :: processed) (outputs ++ later) finalCaller finalQueries
                  | .stopped processed later current =>
                      .stopped (receipt :: processed) (outputs ++ later) current
          | other =>
              match SourcePruningEnumerationNativeBranches.advance other with
              | none => .stopped [] [] (.edge (some other))
              | some (middleCaller, middleQueries) =>
                  match run hook checkEmpty r n p h k target scs before rest middleCaller middleQueries with
                  | .complete processed outputs finalCaller finalQueries =>
                      .complete (other :: processed) outputs finalCaller finalQueries
                  | .stopped processed outputs current => .stopped (other :: processed) outputs current

/-- A missing edge result retains its absence and does not invoke the hook or suffix. -/
theorem missing
    (hook : Fragment → Caller width → Queries → Cached → HookResult Output Reason width)
    (checkEmpty : Bool) (r n p h k target : Nat) (scs : List Suspended) (before : Cached)
    (edge : EdgeValue Symbol Constraint) (rest : List (EdgeValue Symbol Constraint))
    (caller : Caller width) (queries : Queries)
    (observed : SourcePruningEnumerationCapturedEdge.run checkEmpty r n p h k target scs edge caller before queries =
      none) :
    run hook checkEmpty r n p h k target scs before (edge :: rest) caller queries =
      .stopped [] [] (.edge none) := by
  simp only [run, observed]

/-- The sibling starts at the hook's actual returned endpoint, after the head hook completes. -/
theorem completed_head
    (hook : Fragment → Caller width → Queries → Cached → HookResult Output Reason width)
    (checkEmpty : Bool) (r n p h k target : Nat) (scs : List Suspended) (before : Cached)
    (edge : EdgeValue Symbol Constraint) (rest : List (EdgeValue Symbol Constraint))
    (caller reached middleCaller : Caller width) (queries saved middleQueries : Queries)
    (fragment : Fragment) (after : Cached) (outputs : List Output)
    (observed : SourcePruningEnumerationCapturedEdge.run checkEmpty r n p h k target scs edge caller before queries =
      some (.complete fragment reached saved after))
    (continued : hook fragment reached saved after = .complete outputs middleCaller middleQueries) :
    run hook checkEmpty r n p h k target scs before (edge :: rest) caller queries =
