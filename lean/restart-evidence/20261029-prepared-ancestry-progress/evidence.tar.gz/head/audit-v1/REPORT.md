# Prepared head ancestry extension: source-only review

Status: three candidate-v2 modules are frozen and UNTESTED.
The parent owns all compilation and repository changes.
The parent reports PR188 merged as e2163469 with Lean unchanged.
No child Git call was made.

## Exact deliverable

- ChildAncestryExtension: 70 lines, 3,980 bytes, SHA256 7ae89447bb75fd5986578d3b2182febaf9ad5adda662e58832930cf1e9a68833.
- TraversalAncestryExtension: 63 lines, 3,865 bytes, SHA256 77aef0e5d446f2422c7c330df94762e24150a8ce0ec2563bcf5a5ae181f2fd9e.
- PreparedHeadAncestryExtension: 143 lines, 8,306 bytes, SHA256 244a606883e42fd665cac07255554312b418bfd4d3959f36f977d3b8249c7c0b.

Every module name has the SourcePruningEnumeration prefix.
Eight complete public statements and their actual namespace/type/instance contexts are preserved in `public/`.
Candidate-v1 drafts remain unchanged.
The v1 child draft retained one incomplete specialization from the older carrier proof.
The v2 child specialization replaces that leftover with the actual relational result.
The traversal bytes are identical in v1 and v2.

## Public contracts

ChildDispatch.observed_cache_ancestry_extension takes ONLY the runtime parameters, actual after cache, and literal `.2 = some after` observation.
It returns `Extends before.core after.core` AND exact expansionAncestry equality.
It covers every runtime tag with an attached cache; it does not assume an outer successful result.
ChildDispatch.successful_ancestry_extension specializes the exact singleton/cache observation.
It does not substitute a hypothetical returned cache or assume raw core identity beyond the literal observation.

ChildTraversal.trace_ancestry_extension composes actual child observations in the recorded order.
ChildTraversal.complete_ancestry_extension extracts the actual complete trace.
ChildTraversal.stopped_ancestry_extension extracts the actual completed prefix and the actual next stopping child.
All three return Extends and exact input expansion equality.
No arbitrary child-property supplier occurs in any statement.

SelectedEdge.observed_cache_ancestry_extension handles every exposed selected-head cache.
It inverts the actual CachedOwn.prepare row and actual ChildTraversal result, then composes residual recording.
All attached caches extend their own original input and keep its expansion history.
Unsupported or uncached branches return True; they supply no cache assertion.

CapturedEdge.observed_cache_ancestry_extension inverts actual selected completion and actual finalization.
A complete receipt returns Extends plus expansionAncestry=[].
A rejected or attached stopped receipt returns Extends plus original expansion equality.
It does not claim finalization retains active expansion ancestry.

The DISTINCT PreparedNativeHookResources.CompletedHeadReceipt.ancestry_extension takes only the actual prepared receipt.
It uses receipt.running 0 and the literal captured completion.
It returns Extends from this receipt's own captured cache and expansionAncestry=[].
Its original stored handle, prepared parent, all Packet/Memos/Post fields, edge witnesses and old reservations remain indexed in the unchanged original receipt argument.
There is no legacy receipt cast and no equation from stored source to prepared parent.

## Concrete dependencies

The base is the parent's SourcePruningEnumerationAncestryExtension module.
It preserves every slot, including stale keys outside the current counter.
The peer's frozen AncestryExtensionOwn candidate supplies actual own preparation, shallow cache, residual and finalizer observers.
Those observers require no model, Total, alignment or supplied later invariant.

The lower terminal dependency is the parent's/terminal peer's SourcePruningEnumerationTerminalAncestryExtension.
The exact promised helper is CachedTerminalAdapter.candidate_ancestry_extension with the old candidate_key_ancestry arguments minus its carrier/bounded input.
It returns Extends and expansion equality for the exact attached cache.
This dependency was not read or compiled here because its final source is still being authored by its owner.
The candidate imports this CONCRETE module; it does not replace its proof with a new premise.
Compilation and strict checking of the entire dependency chain remain the parent's work.

## Independent source review of v2

The child inversion retains the exact old dispatch branches: incoming Empty; terminal-free partition with actual cached shallow preparation; nonempty terminal partition with the actual cached terminal adapter.
The old adapter/cached-prepare argument order matches the newly agreed concrete helpers.
The shallow cache extraction still distinguishes [] rejection, singleton cache, unsupported result and missing cache.
The empty branch returns the exact unchanged cache.

The traversal induction now composes Extends relations rather than passing a global carrier predicate.
Its expansion equalities compose from the final cache back to the original cache.
The stopped proof includes BOTH the actual completed-prefix extension and the actual stopping call's attached cache.
The old complete_trace and stopped_trace signatures match the candidate calls.

The selected-head inversion keeps the old concrete row destructuring and actual singleton membership proof.
The inferred ownFields row is determined by that actual singleton, not by a new row supplier.
Its complete case composes own, child and residual extensions in runtime order.
Its stopped case composes the own stage and the actual stopping-cache extension.

The captured inversion uses the actual selected result and Option.map_eq_some_iff to recover finalization.
The actual finalizer supplies the cleared expansion field.
The prepared receipt specialization reduces only Nat.add_zero and the observed complete constructor.
No native-language, model, future endpoint, completion, or whole-worker semantic premise is introduced.
A textual check finds no leftover carrier/bounded predicate, sorry/admit/custom axiom/native_decide, or option/linter suppression in v2.
This is source review, not elaboration or compiler evidence.
No additional source-level concern was found in v2.

## Exact remaining recursive hook contract

The local head contains no recursive hook.
The hook is invoked by NativeContinuations.run AFTER a captured complete receipt.
For the actual prepared hook `continueWith (resume ... recursiveFuel)`, the needed depth-induction result is:

```
match actualHook fragment caller queries cache with
| .complete outputs _ _ | .stopped outputs _ _ =>
    forall output in outputs, Extends cache.core output.cache.core
```

This must be DERIVED for the actual recording/restart worker at the smaller depth.
It is not supplied to or concluded by these three local modules.
The recording frame can first transfer the captured input histories to the actual callback core; then the induction result handles each actual output.
If the proof uses the existing recordTypes_frame theorem, its Total premise must come from the original actual callback Packet.
No new future model or completion assertion should replace that proof.

Each sibling starts again from the FIXED captured enumeration cache.
Only the native caller and queries advance through the preceding hook.
Do NOT require Extends from a previous recursive output cache to the next sibling cache.
The correct result compares each actual head/output to its own captured input, then composes the per-hook depth induction and actual output concatenation.
Stopped hooks retain their emitted prefix outputs; the contract must cover those outputs too.

## Budget and live-root scope

These relations imply nonincrease of the fixed-handle unused shape count at the SAME RAW SLOT via Extends.unused_le.
The active boundary key is retained through own/child expansion equality until finalization clears the active field.
A key that actual allocation already copied into a slot remains at that slot through the local suffix and finalization.
The old actual allocate_ancestry and prepareOrdinary_ancestry theorems supply the explicit fresh-slot inheritance under original alignment when needed.
No new allocation/inheritance wrapper is duplicated here.

Extends alone does NOT transfer an old raw slot's keys to a DIFFERENT live representative.
A later live-root budget application must use actual ancestry transfer at assimilation, for example the existing CachedAssimilation.finish_ancestry nonempty source-to-target clause, and exact representative identities.
The current candidates do not infer that missing root-transfer fact from plain raw slot membership.
They prove no strict global decrease across unrelated siblings, native-handle bound, global search-depth bound, termination, chosen-output existence, Discharged, or language completeness.
No Haskell file or Haskell defect claim is added.

## Evidence scope

Fourteen complete source inputs, including the frozen peer Own candidate, were read whole.
Fourteen exact literal cuts preserve the needed runtime definitions and resource receipt fields.
Oversized truncated tool outputs are not counted as whole-source reads.
The full/cut byte identities, candidate identities and all eight public statements are recorded in source-manifest.json.
Only this owned TMP area was written.
No compiler, evaluator/native, Git, network, board or repository write was performed by this child.
