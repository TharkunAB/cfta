[2026-10-28 22:37:03 CET] Actual current stored recursion-key path corollary.

Candidate: /tmp/mcfta-prepared-model-lineage-20261028/head-forward/path-key-v2/candidate-v2/MicroCFTA/SourcePruningEnumerationModelPathDomain.lean
SHA256 ce9c863f7c34fd19a4273bf0903e62388fd4d5e836e18712a9929e4fcec01c0e; 5417 bytes; 103 lines.
Status: SOURCE-ONLY; UNTESTED. Root owns the compiler checks.

The entire 3781-byte v1 candidate is an exact prefix. All four previous exported
declarations and their proof bytes remain unchanged. One theorem is appended:
SourcePruningEnumerationModelPathDomain.stored_recursion_key_paths.
Its complete public signature is preserved separately.

The actual key is EnumerationState.recursionKey, defined in EnumerationState.lean.
SourcePruningEnumerationRecursion.checkRepeated uses that exact definition.
There is no separate EnumerationRecursion.lean in this source tree.

Original premises: Satisfies language meaning assignment state;
AssignmentOrigins whole state.counter assignment; Canonical state;
uv < state.counter; and the literal stored observation
state.values[uv]? = some (.unenumerated (some handle) scs).
No prepared/source identity cast, later output, future key, heap, completion,
model supplier or extra resource gate is added.

For every trie in the ACTUAL (recursionKey handle scs).tries, the theorem states:
all its represented paths belong to relativePaths whole, and its path-list
length is at most (relativePaths whole).length.

The proof unfolds only the actual key construction. Sorting preserves membership
for every comparator by List.mem_mergeSort; it needs no sorting-order hypothesis.
List.mem_eraseDups preserves membership. List.mem_map then recovers the original
stored sc. The two checked-shaped v1 local lemmas provide its path membership
and length bound. The Canonical premise is used only through stored_trie_length.

This bounds per-trie path lists at one actual stored model point. It does not
construct a complete finite list of trie shapes, bound the outer key trie-list
by a uniform finite shape universe, bound historical recursionAncestry or
expansionAncestry, bound native handles, or prove global recursion terminates.
The handle is the literal handle of the stored slot, but no restriction on its
numeric value is inferred.

Two whole Lean sources, the toolchain selector, and six exact source/stdlib
cuts are preserved with their byte/hash identities. The failed path probes and
truncated exploratory read are recorded in the manifest. No source mutation
outside this new owned area occurred. The old candidate and reports stay frozen.
