[2026-10-28 22:27:19 CET] Source-only head/callback assignment-lineage audit.

The prepared head and its callback-entry model are already constructive.
The genuine remaining semantic step is from the actual callback restart input
to an actual recursive output, while retaining exact branch alignment and old
assignment agreement. No new Lean wrapper is drafted: the local pieces below
already exist, and a restatement would not prove that remaining step.

Existing exact route

1. PreparedEntryModels.narrowed_preparation_complete_models transports the same
original assignment through prefix and actual preparation. It derives a model
at the actual entered cache and accepts the prepared value. Its unary/app/filter
admits/fits observer policies remain explicit. It keeps the source handle and
prepared value separate. This audit does not duplicate that theorem.

2. PreparedFiniteSiblingResources.alternatives_finite_complete_resources_accepting
(and its origins version) retains exact indexed events, full input/head memos,
whole Post/Packet, literal captured run and hook Invocation. Its proof transports
the SAME original assignment through every earlier completed callback Post:
NativeLanguage.satisfies_keeps applies to the captured before.core, its original
PendingRealized and hookPost.effects.keeps. Parent availability passes through
hookPost.effects.keeps.available. Earlier branch enum caches are not reused as
the next sibling's captured input. Earlier native allocation alone therefore
does not require a new semantic assignment for the chosen branch's old slots.

3. PreparedNativeHookResources.head_finite_complete_resources_accepting derives
an EXISTENTIAL extended assignment from the original model and accepted edge.
It agrees on every old < before.counter, preserves the original model, identifies
the exact produced complete receipt, fills its fragment to assignment uv, and
models the exact reached cache under its reached native heap. The origins
version also derives AssignmentOrigins whole afterCache.counter extended.
The prepared parent has separate parentAvailable/parentClosed premises. Neither
statement equates it with the original source handle's decoded node.

4. PreparedRecursive.receipt_finite_complete_resources_models retains the actual
same callback outcome. Its completed arm derives the callback Packet, literal
recordTypes singleton, frame and callback/actual-resume equalities. Given the
head model, fill=self, original pending refutation, Avoids and ProgramEncoding,
it derives Satisfies at the actual callback frame, recorded.1=false, new pending
refutation, and the literal restart equality to that same outcome.

5. The origins version and PolicyOrigins discharge local template policies from
OriginPolicies templates whole plus the selected variable's original subtree.
SourcePruningRecordTypes.pending_refutes_extension transports old refutation
using old-slot agreement and bounded pending IDs. Packet.bounded supplies those
old bounds. Ready.inside gives extended uv = original uv, so the fill equality
becomes the callback's required self equality. The callback frame keeps the
counter and therefore keeps AssignmentOrigins at its actual restart cache.

Quantifier order

Operational witnesses precede ambient and assignment inputs in these existing
producers. Fresh extensions are existential and may depend on the chosen model.
An arbitrary original assignment on fresh slots is not guaranteed to satisfy
new child/equality slots. Different sibling branches can reuse the same fresh
indices with different witness terms after restoring the captured enum input.
Do not require one extension to model every sibling output simultaneously.
The correct branch claim keeps all ORIGINAL allocated slots and constructs
one extension for the actual selected semantic branch.

Projection gates now discharged

SelectedPreparation.complete_rows_projectable already derives project != none
for EVERY actual prepared node row from original physical ProjectionHeap and
the actual successful preparation family. selected membership, including take
membership, discharges the static earlier-row support premise in SiblingCoverage
and the supported premise in PreparedFiniteParentOrigins. These facts do not
need a model for the earlier rows. They also do not need a supplied later heap.
The full finite projection producer now retains the actual aggregate endpoint
and every output's physical projection heap, including empty-output aggregate
callers. This supplies the original ProjectionHeap input for the next recursive
invocation after actual recording or an earlier completed sibling callback.
Post by itself remains a keeps-old-records fact, not a forward proof of all new
physical edge guards. Use the projection producer for that new-record fact.

Gates that projection does not remove

- Source edge coverage: selectionMembers and selectionLength do not imply that
  an accepted edge is offered. ParentOrigins explicitly uses selectedRows.Perm
  storedEdges. Keep permutation or another genuine original selector-completeness
  theorem. Projection only supports guards of edges actually present.
- Earlier callback stops: SiblingCoverage honestly returns the chosen head OR
  a strictly earlier stopped hook. Projection does not turn a finite-depth
  exhausted recursive hook into complete or guarantee that the chosen index is
  reached. Depth stability preserves an existing complete run; it does not
  prove completion exists.
- Callback and prefix semantic policies: pending refutation, OriginPolicies
  (or local Avoids/encoding), and prefix admits/fits obligations remain semantic
  input conditions. A physical projectable heap does not prove them.
- Full output semantics: callback/receipt Models and Origins stop at actual
  restart input. OutcomeResources and OutcomeProjectionHeap do not assert an
  output model or preserve a chosen old assignment through recursive results.
- Whole Discharged and arbitrary-rendering claims remain separate.

Minimum nonredundant next proof

Strengthen the ACTUAL prepared finite recursion proof with assignment/model
lineage. At a chosen completed head, consume the already-derived head extension,
callback frame model, pending refutation and origins as the induction input.
Produce a model for a specific ACTUAL emitted output and an extension agreeing
with that invocation's old allocation prefix; align its running equation with
the fixed head callback outcome at a common work bound. Native effects from
other siblings use keeps on their captured input. Exact earlier-hook stops must
remain in a bounded-depth result until a genuine original-source completion
argument removes them. A future-output model must not become an admission gate.

This report is source-grounded, not a new checked theorem. Hashes, full named
public declarations and honest whole/cut read scopes are preserved. No compiler,
evaluator, native, repository edit, Git, network or board action occurred.
