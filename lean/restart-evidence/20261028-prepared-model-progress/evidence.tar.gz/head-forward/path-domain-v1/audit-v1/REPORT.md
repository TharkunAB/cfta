[2026-10-28 22:34:25 CET] Source-only model-relative suspended path-domain audit.

Existing finite quantitative statements

EqualitySaturation.boundedPaths enumerates all existing term paths up to fuel.
boundedPaths_correct is exact. termPaths whole = boundedPaths whole.height whole;
termPaths_correct states membership iff an actual atPath lookup succeeds.
EqualitySaturation.satisfied_within already bounds every represented path of
an Active, satisfied equality-normalization state by termPaths of its model.

EqualityTermination separately proves a model-free normalization domain:
saturationDomain classes =
  words (initialAlphabet classes) (initialGap classes * ((members classes).length + 1))
and saturationBound classes = (pathPairs (saturationDomain classes)).length + 1. Its exported
mkEqConstraints_terminates/total_correct prove one actual normalization call
finishes, including unsatisfiable inputs. That per-call input domain does not
by itself give one fixed universe for all recursive enumeration callbacks.
The literal definitions and exact theorem cuts are preserved.

No existing Enumeration or Prepared use of termPaths/satisfied_within, or a
quantitative suspended-path-to-original-model domain bridge, was found in the
recorded searches. The new small candidate adds that bridge.

Important relative-path correction

A suspended path is relative to assignment uv. Even when assignment uv is an
original subtree, its relative path need not be valid at the whole term's root.
For example let W = R(A(), B(C(D()))) and assignment uv = B(C(D())). The relative
path [0,0] reaches D() there. W.atPath [0,0] is absent because W's first child is
A(). Its absolute occurrence [1,0,0] is a valid path of W.
This is a source-shaped mathematical illustration, not an evaluated native or
Haskell counterexample.

Candidate

/tmp/mcfta-prepared-model-lineage-20261028/head-forward/path-domain-v1/candidate-v1/MicroCFTA/SourcePruningEnumerationModelPathDomain.lean
SHA256 f7dfd6edc47a2436b30e5f39436b3f0a68408745a60c1fd7c2714093a0c1b97f; 3781 bytes; 71 lines.
Import MicroCFTA.SourcePruningEnumerationModelPathDomain.

relativePaths whole is an explicit FINITE LIST: enumerate every actual base
path of whole; at each existing subtree, enumerate its existing relative paths.
It can contain duplicates. Its list length is a conservative numeric bound.

origin_path_mem: Origin whole term and one actual term.atPath path = some part
imply path membership in relativePaths whole.

stored_suspended_paths: original Satisfies language meaning assignment state,
AssignmentOrigins whole state.counter assignment, uv < state.counter and a
literal stored unenumerated node scs imply for every sc and represented path:
  path belongs to relativePaths whole, and
  (assignment sc.var).height + path.length <= whole.height.
The node is an arbitrary Option Nat. The statement also covers pure equality
slots. It needs no native heap, proper-state premise, future model or later
output supplier. The model is the original model at that exact point.

stored_trie_length adds the existing original Canonical state premise. Valid
tries have prefix-free distinct path lists. Hence each represented path-list
length is <= relativePaths whole.length. This removes unbounded multiplicity.
The candidate is source-only and uncompiled. Root owns all actual checks.

What this permits next

Fix W along a genuine model lineage and write D = relativePaths W.length.
Every current canonical trie is an ordered list of at most D entries from a
fixed finite domain. A crude finite universe of lists of length <= D suffices;
no assumption of an ascending map is needed. Canonical in EnumerationValidity
means ValidSuspended, not Ascending. Do not claim exactly 2^D path-list shapes
without an additional canonical-order argument. Actual recursionKey erases
duplicate path LISTS and sorts the resulting outer trie-list. Therefore a finite
universe of per-trie lists can also bound its trie-list component independent
of equality-variable identities and raw suspended-bucket length. The combinatorial
key-universe proof is a NEXT STEP, not included in this candidate.

What remains open

1. Satisfies ignores recursionAncestry and expansionAncestry. This point theorem
does not constrain arbitrary already-attached historical keys. Derive their
shape-domain membership from genuinely bounded/empty initial ancestry, actual
Entry key insertion at a modeled stored slot, and actual allocation/assimilation
inheritance. Existing local ancestry lemmas help compose that proof.
2. The actual native handle/node field of each RecursionKey remains unbounded
by this result. A finite trie-shape universe is only one factor.
3. AssignmentOrigins and Satisfies must hold at each actual semantic input on
the chosen path. The earlier head report identifies the remaining restart-to-
recursive-output model induction. Projection closure supplies guard support;
it does not supply a model of all earlier nonaccepting sibling branches.
4. A finite key universe alone does not prove every callback decreases a
well-founded measure. Repeated actual callbacks, stopped earlier hooks and a
uniform finite recursive depth still need their actual operational argument.
5. This model-relative finite domain uses the actual finite accepted term W.
It does not use the maximum path length of the original input equality tries,
which can grow under normalization and is not the needed global invariant.

The head audit remains frozen in its sibling audit-v1 directory. Complete
candidate declarations, source hashes and honest literal cuts are preserved.
No compiler, evaluator, native, repository edit, Git, network or board action
occurred. There is no Haskell defect or global termination claim.
