# Prepared callback progress candidate

Date: 2026-10-28, Europe/Stockholm.
Status: UNTESTED source candidate. Root owns compilation and integration.
No repository, Git, compiler, evaluator, native, network or board action ran.
No Haskell file changed. No Haskell fix is claimed.

## Delivered statement

Module: `SourcePruningEnumerationPreparedCallbackProgress`.
Theorem: `PreparedRecursive.callback_record_progress`.
The candidate has 84 lines and 5,235 bytes.
SHA256: `883f772418b9011b02c89e2b36ff72d4e40745e7ac80ef87fdbeb1f1e05f27ed`.

The inputs describe the original callback entry and one actual recording call:

- The full original `Packet`, including native context and full memos.
- An allocated callback fragment.
- `ProperState` at that original callback entry.
- Literal `Success (recordTypes ... fuel ...) before.core result after`.
- One native `Satisfies` assignment at the original caller and cache.
- Arbitrary metadata stop and order policies.

The conclusion gives the actual returned framed `Packet`, `RenderStable`,
`Frame`, framed `ProperState`, the same native assignment at that frame,
and the exact restart decision unequal to `some .stuck`.
The caller and full memos remain the original ones.
The callback result and returned core are the actual supplied observations.

The statement needs no emitted output, output history, recursive depth
contract or future state supplier. It has no initial arity or projection gate.
The proof does not infer `ProperState` from `Packet`.

## Source route

`PreparedRecursive.continueWith` calls the shared `recordTypes` operation.
A singleton false result uses `frame observed before` and calls the prepared
recursive function at the exact returned metadata and restart decision.
A singleton true result returns an empty complete output list.
The new theorem concerns the scheduler decision at the actual recording frame.
It does not assert that the recursive body emits an output.

`Recursive.callback_complete` derives a safe recording result from the original
packet and allocated fragment. This is a producer for the shared recording
operation. Its original-worker continuation equation is not used by this proof.
The proof takes only its raw recording observation and returned packet.

The generated and supplied actual calls can have different recording fuels.
`recordTypes_moreFuel` extends the actual observation to their fuel sum.
The generated callback already supplies its exact observation at that sum.
`SourcePruningCallbackExact.recordTypes_exact` gives an exact raw singleton
for the extended actual observation. Singleton and product injectivity then
identify the generated metadata and core with the actual metadata and core.
This preserves the whole returned packet, including its actual cache validity
and safety. It uses no original/prepared worker or `Failure` identity cast.

`ProperState` depends only on stored values. The actual frame keeps these values.
`NativeLanguage.satisfies_frame` preserves the same complete assignment because
the native caller heap is unchanged during recording. The final step applies
`Restart.not_stuck_of_proper` to the returned packet's `valid` and `safe` fields,
the derived framed proper state and the derived actual framed model.

## Integration boundary

The existing `PreparedCallbackModels.callback_finite_complete_resources_models`
already retains the actual full finite resource tuple. Its callback field gives
the exact required `Success`, for example `(callback 0).1` at `fuel + 0`.
The original callback entry model can come from the accepted prepared head
model API. Root's actual completed-head proper proof can supply the local
original `ProperState`. These inputs describe the callback entry.
They do not describe a future output or a future recursive result.

Apply this point theorem alongside that existing producer. No clone or
replacement of its full finite tuple is required. Its chosen outcome, runtime
equations, resource receipts and model-policy results remain unchanged.
No annotation/template policy or false-record premise is needed solely to
exclude a stuck decision at the recording frame. Existing callback models
still supply nonrejection when the recursive false branch is required.

This result does not establish global no-stuck execution, recursive emission,
source-derived sufficient depth, termination, ordered sibling coverage,
discharged rendering or Haskell correspondence.

## Evidence and read scope

`manifest-v1.json` records each exact source path, copy, byte count, line count
and SHA256. It records 13 WHOLE source files with 96,737 bytes and 1,511 lines.
It also records six exact literal cuts with 12,621 bytes and 216 lines.
Each cut retains the identity of its whole source without claiming a whole read.

The first batched source read had an aggregate output truncation warning.
Separate whole reads recovered `RecursiveCallback` and `PreparedCallbackModels`.
`CallbackAdmission` was incidental discovery output and was not recovered or
used as a proof authority. The manifest records this distinction.
All copied sources and cuts were checked against their recorded identities.
The candidate was read back whole. It remains uncompiled by this author.

The memory registry search supplied only the restart-boundary convention.
All technical statements above come from the exact current source reads.
The parent reported base `41b6a7a00`; this author did not run Git to verify it.

The candidate version and this report are frozen after delivery.
