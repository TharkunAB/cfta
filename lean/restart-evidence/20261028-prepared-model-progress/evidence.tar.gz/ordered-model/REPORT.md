# Ordered prepared model-output gap

Time: 2026-10-28 22:26 CET.
Status: source-only audit. No new proof or admitted counterexample is claimed.
Parent supplied HEAD `41b6a7a00`; this child did not run Git.

The missing result is model-preserving actual recursive emission, together
with an original progress argument for callbacks that precede the chosen row.
Transport to the chosen head after completed earlier callbacks is already
implemented. A wrapper of that transport would not close the gap.

## What already selects and reaches the accepting head

`PreparedFiniteParentOrigins.parent_finite_complete_resources_origins` takes
the actual prepared parent, its separate Available/Closed facts, original
stored handle, accepted model and `selectedRows.Perm storedEdges`. It uses
`SelectorLanguage.selected_accepting_of_perm` to choose an accepted edge and
its concrete selected index. The index and edge precede extra work fuel.

`PreparedFiniteSiblingCoverage.alternatives_finite_complete_resources_accepting`
executes earlier rows and callbacks at their actual endpoints. In the successor
index case it uses `NativeLanguage.satisfies_keeps` with
`packet.valid`'s PendingRealized and `hookPost.effects.keeps`. This retains the
SAME original assignment for the unchanged captured enumeration cache at the
next sibling's actual native caller. It does not need a model of an earlier
branch's distinct cache. The edge meaning is a property of the retained edge
syntax, so the same accepted edge remains accepted.

The runtime confirms the endpoint order. `NativeContinuations.run` invokes the
head hook before the suffix. A completed hook supplies its actual returned
caller and queries, even when its output list is empty. The suffix keeps the
captured enumeration input and hook metadata. The resource proof derives the
next full packet/Memos at that endpoint. These endpoints must not be replaced
by the native head's earlier caller.

An actual earlier stopped hook skips the suffix. Existing sibling and parent
origin theorems therefore return a chosen accepted event OR an exact strictly
earlier stopped hook. The latter includes its actual outputs, reason, optional
endpoint and resource packet. It has no model-coverage conclusion. Treating
that disjunction as global coverage would discard the unresolved case.

## Forward APIs stop before recursive emission

`ChildCompletion.complete_with_fragments_resources_accepting` fixes one
original resource-produced child result. An accepted input term and its
inherited restrictions construct a singleton fragment, an agreeing assignment
extension and a model at that exact child caller/cache. The origin variant
retains structural paths for the same extension. Terminal child results can
keep the old assignment. A nonterminal child can allocate a fresh hole. This
is valid forward coverage of intended partial results.

`PreparedNativeHookResources.head_finite_complete_resources_accepting` uses
the original accepted edge to derive projection and arity admission. It aligns
the accepted child/edge construction and actual finalization with the SAME
resource-produced captured receipt. It returns a filled fragment and a model
at that receipt's actual callback-entry caller/cache. The original native
caller, callback caller and full memo states remain explicit. No source and
prepared-parent identity is assumed.

`PreparedCallbackModels.callback_finite_complete_resources_models` and
`PreparedFiniteReceiptModels.receipt_finite_complete_resources_models` align
the resource-certified actual callback outcome with recording and its exact
restart. Their conclusions preserve the callback-entry model through the
recording Frame, but do not give a model for a recursive output.

The origin APIs retain the same assignment extension and paths at the restart.
`PolicyOrigins` derives Avoids and ProgramEncoding from ORIGINAL structural
subtrees. Its pending-refutation extension uses raw pending-ID bounds and
agreement on old allocated variables. This is an actual record proof, not a
future callback oracle.

The next missing semantic conclusion is therefore:

    original resource-admitted callback entry
    + its original satisfying assignment and subtree/policy evidence
    ==> a derived finite recursive capacity and stable actual outcome,
        an output in that outcome,
        and an agreeing assignment with the model at output.caller/output.cache.

The output's own caller/cache, agreement below the original counter and
original paths must remain coupled to that SAME actual output. This displayed
implication is an unproved target. It is not a new assumption or proposed
certificate. Existing `HookInvocation.Invocation.output_mem` already lifts
literal membership in an invoked hook to the actual whole sibling result,
including outputs before later stops. No duplicate membership wrapper is needed.

## Policy, stop and selection distinctions

| Actual condition | Runtime effect | Consequence for coverage |
| --- | --- | --- |
| Configured stop produces `decision = none` | `resume` emits one output with the current cache and metadata, then returns complete | This is a partial output. A model of this entry cache supplies its model directly. It is not a stopped hook. |
| `some .done` | Emit the actual current cache | DONE can retain opaque pending boundaries; Discharged is a separate rendering condition. |
| `some .stuck` | Return complete with no outputs | Exclude this on the chosen model path through a genuine local progress invariant. Resource or projection preservation alone does not do so. |
| Left recording returns true | Return complete with no outputs; do not recurse | Earlier pruning still permits the suffix. The chosen model needs the original nonrejection policies. |
| Earlier allowed row has unsupported projection | Return an unhandled edge stop | Original projectability and actual prepared-row support now provide the relevant support route. |
| An earlier recursive hook stops | Retain its outputs and skip all later siblings | Its resources alone do not cover the later chosen model. |
| Zero recursive depth with an expansion | Stop exhausted with no outputs | More work fuel cannot repair that fixed-depth result. This does not prove all-depth failure. |

An arbitrary configured stop rule is not, by itself, an obstruction to
partial-model output coverage. It can obstruct a theorem demanding a fully
Discharged concrete output. Such a theorem would need an appropriate source
stop policy. Do not conflate the configured stop rule with `HookResult.stopped`.

Native acceptance alone does not guarantee callback-policy acceptance.
The selected Right-prefix theorem `packet_prefix_preparation_complete_models`
has three separate model admission policies: unary annotation admits/fits,
app annotation admits, and filter annotation admits. `OriginPolicies` supplies
the later Left-record Avoids/ProgramEncoding conditions. It does not replace
those three prefix policies. Without an intended admission policy, empty
pruning can be correct behavior rather than a language-completeness defect.

The resource selector premises `selectionMembers` and `selectionLength` allow
the constant-empty selector. They restrict membership and size; they do not
state that any accepted edge is offered. The existing Perm route supplies a
sufficient original selector coverage condition. This is a direct policy
boundary, not a newly constructed full admitted runtime counterexample.

The order hint can only choose an offered variable. `pickNext` falls back to
the first available variable for an invalid or absent hint. Arbitrary order
therefore does not introduce an invalid immediate selection. No fairness or
termination over indefinitely allocating executions follows from that fact.

## Progress and the exact earlier-callback obligation

`NativeProgress.not_stuck_of_proper` requires local ProperState in addition to
CacheValid, Safe and the actual satisfying assignment. It works with any stop
rule. `NativeSelectionProgress.expand_of_pending` then derives a ready selected
root with stop disabled when genuine pending work exists. The selected root
need not be the supplied slot. Neither result gives a recursive depth bound.
ProperState is separate from Packet. The new finite ProjectionHeap contract
does not carry it. A coverage induction must derive the required local progress
facts from original admission and actual operations, or prove a replacement.
It cannot assume them at future entries.

For a chosen row after a nonempty prefix, one sufficient operational route
must derive completion of each earlier reachable callback, including empty
completions, at its actual input endpoint. A smaller alternative is to prove
that an earlier stopped callback already emits an output covering the SAME
target model. The existing stopped resource certificate proves neither fact.

Derive these earlier execution bounds sequentially. Each next callback starts
at the previous callback's actual returned caller and full Memos. After the
earlier bounds are proved, `resume_complete_moreDepth` can synchronize completed
callbacks at a larger common recursive capacity without changing endpoints.
The chosen continuation then needs its own model-output induction. Exact
output-prefix preservation retains an output that was already produced; it
does not supply the first such output.

`AssignmentOrigins` gives actual original subtrees and `origin_height` gives
a non-strict height bound. These facts alone do not bound all earlier branches
whose caches need not admit the chosen model. They also do not strictly reduce
every normalization, parking or recursive-boundary step. The current fixed
finite resource forecast depends on the supplied recursive capacity; it does
not derive a sufficient capacity from the original source.

The smallest honest next proof is thus a source-derived progress/emission
induction that covers both the chosen semantic continuation and prior actual
allocating callbacks. An original finite key/state carrier and a justified
decreasing measure would be one route. This audit does not claim that such a
carrier is established, nor add an assumed terminating future-step supplier.

## Prior obstructions and current scope

The earlier findings were read before forming this conclusion. They explicitly
reject `A=f(A)|a` as an admitted divergence example: empty-bucket Mu work is
not expandable and repeated native keys can clear the bucket or park it.
Fresh UVar IDs alone do not evade those keys. Union narrowing can replace its
key-bearing value before entry. Equality normalization can lengthen paths.
These refute proposed measures, not termination of the admitted implementation.

The checked parked-progress theorem strictly reduces the candidate count for
one actual repeated-key park at a fixed allocation counter. Allocating
continuations are outside that decrease. It cannot bound the whole ordered
recursive search.

An actually infinite earlier callback with no target-covering output would
obstruct a later accepting row in this depth-first order. This is a conditional
control-flow observation. No complete original Context/Packet example that
realizes that behavior was established here or recovered from the prior
findings. This report makes no nontermination or Haskell defect claim.

No new proof draft was written. The relevant local transport and membership
lemmas already exist. The missing step requires a new source progress/emission
argument; a wrapper of earlier-stop alternatives would conceal that obligation.

## Evidence and freeze

The manifest preserves 23 WHOLE Lean sources and two WHOLE prior audit reports:
3,673 lines and 258,560 bytes. Seven literal cuts retain the relevant findings,
current coverage note, depth theorem interfaces and selection definition:
694 lines and 42,688 bytes. Complete original source hashes and cut hashes are
recorded. Only these explicit scopes are claimed. Truncated discovery and
combined reads were replaced by the complete or literal reads listed in the
manifest. The unused allocated-input-model search is discovery only.

No compiler, evaluator, native code, repository write, Git, network or board
operation was run. No old frozen artifact was changed. No Haskell change or
required fix was identified. Root retains all integration and verification
work. This audit and all its input copies are now frozen.
