"""Prepend the verified current checkpoint and preserve every prior document body."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json

ROOT = Path('/home/tritlo/Code/mcfta')
AREA = Path('/tmp/mcfta-prepared-model-lineage-20261028')
stamp = datetime.now(ZoneInfo('Europe/Stockholm')).strftime('%Y-%m-%d %H:%M %Z')
source = json.loads((AREA / 'source-push.json').read_text())
board = json.loads((AREA / 'board-verification.json').read_text())
assert source['exact'] and board['exact']
head = source['head']
note_path = 'lean/notes-current-prepared-model-progress.md'
note = f'''# Current prepared model progress proof

Verified: {stamp}. Source: `{head}` on formalize, pushed and verified.
The full formalization goal remains ACTIVE and incomplete.

## Target and strongest claim

The target is agreement between intended CFTA language semantics and the
optimized interned implementation. Every emitted value must have its original
source meaning. Search must reach every permitted model at a finite bound
under the required policies. Public language operations and count, rank,
unrank and sample integration remain in scope. Preserve older constructor and
equality proofs as secondary targets.

The strongest semantic claim remains conditional soundness. A checked rendered
output has the original native root meaning and satisfies the original
suspended constraints under fixed-PCS and whole-Discharged assumptions.
Greater recursive depth retains existing full output records in order at
fixed work fuel and other inputs. Stopped runs retain their earlier outputs.

For each supplied finite recursive capacity, original resource inputs derive
a stable actual prepared outcome at sufficiently large work fuel. The full
certificate retains actual execution histories, canonical stored tries, native
arity and physical constraint projection. The new joint result also retains
ProperState at each actual output, from ProperState at the original input.
It keeps the original bound and outcome. It does not prove output existence.

The new callback theorem excludes a stuck restart at an actual successful
recording call from an original proper satisfying callback entry. It does not
need an emitted output or an output history. The finite model path theorem
bounds stored suspended paths and each actual recursion-key trie by paths in
the original finite term's subtrees. These are local progress prerequisites.
They do not derive a sufficient recursive depth for the full ordered search.

## Actual proper-state preservation

PreparedNativeHookResources.CompletedHeadReceipt.proper consumes the full
actual prepared head receipt and original ProperState. It derives ProperState
at the same completed cache. The original stored handle supplies the bucket.
The separately available and closed prepared parent supplies the selected
edge proof. No equality between those parents is assumed.

SelectedOpaqueDispatch.complete_proper follows the actual child result and
the same actual finalizer. It covers literal completed opaque observations.
Preparation retains the stored value list. Both actual selected receipt arms
therefore preserve proper storage. Successful recordTypes retains those values.
SelectedHistoryReceipt.proper_after_callback gives the same invariant at its
actual callback core. The four ResourceHistory constructors then preserve it
through stop, done, parked and selected operations at each output's own cache.

ProperState is separate from Packet and from canonical trie validity.
It requires strict nonempty nonterminal paths in pending graph buckets.
The existing Recursive.initial_packet_proper derives the original property
at literal native startup. It remains an original gate in the general theorem.

The full exported joint theorem is:

    PreparedRecursive.run_finite_complete_resources_with_history_canonical_arity_projection_heap_proper

It retains all original Packet, Fits, Known, selection-membership/length,
suspended-mass and reservation inputs. It retains original canonicality,
arity and projection inputs. It adds only original ProperState. Its conclusion
retains the old stable bound, outcome, complete resource certificate, all
actual history witnesses, output canonicality, arity and projection, and adds
ProperState at every actual output. A complete empty output list remains valid.
This output-only conclusion cannot exclude an unobserved non-emitting branch.

## Progress before recursive emission

PreparedRecursive.callback_record_progress takes the original full Packet,
an allocated fragment, original ProperState, one original native Satisfies
assignment and literal Success of recordTypes at the supplied actual fuel.
Its result is the actual framed Packet, RenderStable, Frame, proper storage,
the SAME assignment model and exact restart decision unequal to some .stuck.
It has no future model, future cache, output-history or recursive-result gate.

The proof uses the existing complete producer for the shared raw recording
operation. It extends the actual success to a common larger recording fuel.
Exact singleton observations identify the produced result and core with the
actual result and core. This transports the safe complete Packet to the actual
frame. It does not cast an original worker or Failure into a prepared one.
The frame preserves values and the same native caller. The existing native
not_stuck_of_proper theorem supplies the final scheduler result.

The actual prepared head model APIs already supply the callback-entry model.
The new head proper proof supplies its local ProperState. Existing callback
model APIs supply the false record result under their explicit nonrejection
policies. A model of recursive outputs and sufficient depth remain open.

## Finite model-relative path domain

ModelPathDomain.relativePaths whole is an explicit finite list. It enumerates
every actual subtree of whole, then every existing relative path there.
The list may contain duplicates. Its length is a conservative numeric bound.
A root-only path domain is insufficient because suspended paths are relative
to the assigned subtree. For R(A(), B(C(D()))), path [0,0] exists relative to
B(C(D())) but does not exist at R's root. This is a mathematical illustration.
It is not an evaluated Haskell or native counterexample.

Original Satisfies, AssignmentOrigins, an allocated slot and its literal stored
observation derive finite membership for every suspended path. They also give
assignment(sc.var).height + path.length <= whole.height. The statement covers
pure equality slots. It requires no future model or native heap assumption.
Canonical stored tries have distinct represented paths. Thus each path-list
length is at most relativePaths whole.length.

stored_recursion_key_paths uses the ACTUAL EnumerationState.recursionKey at
that same stored slot. Each of its trie lists contains only domain paths and
has at most that domain length. Sorting and eraseDups preserve membership.
It does not assume Ascending. Canonical in this API means valid tries.

The proof does not yet enumerate all possible trie lists or outer key lists.
Satisfies does not constrain arbitrary historical recursionAncestry or
expansionAncestry. Derive those bounds from original empty/bounded ancestry,
actual key insertion and actual allocation/assimilation inheritance.
The native handle field remains a separate unbounded factor.

## Exact remaining work

1. Prove model-preserving actual recursive emission. Keep each output's own
   caller/cache, agreement on its original allocation prefix and original
   subtree origins coupled to that same output. Existing APIs already reach
   the accepted head and actual callback restart. A duplicate transport wrapper
   does not prove this next step. Fresh extensions are branch-specific.
2. Derive enough recursive capacity from original source. Earlier actual hooks
   execute before later selected rows. Prove their completion at actual returned
   endpoints, or prove they already emit an output for the same chosen model.
   The current earlier-stop alternative must remain until this is proved.
3. Package the finite per-trie domain into a finite shape universe. Prove
   actual historical key insertion/inheritance, then close the native handle
   and inventory factors and a justified global progress measure. The fixed
   depth reservation depends on supplied depth; it does not derive that depth.
4. Close original selector and semantic policies, origin/public API composition
   and correspondence with the optimized Haskell implementation.

Selection membership and length alone allow an empty selector. An accepting
row needs the existing real permutation/coverage route. Projection supports
all actual prepared rows, but does not establish semantic policy acceptance.
Unary fits/admits, app admits and filter admits are separate Right-prefix
policies. OriginPolicies supplies later Left-record avoidance/encoding facts.
Configured stop emits a partial output. A stopped recursive hook is different.
DONE does not imply whole Discharged. Intended partial outputs remain in scope.
No new admitted all-depth failure or termination counterexample was established.

## Validation and retained evidence

Seven modules add eleven public theorems and one finite proof-domain definition:
577 lines and 34,603 bytes. Enumerator and Haskell runtime definitions do not
change. All seven plus Audit pass eight exact strict Lean 4.34.1 checks with
warningAsError=true and linter.all=true. Audit passes 4,555 jobs and checks
81,774 theorem dependencies. Twenty-two serial compiler checks have nineteen
passes and three retained failures; all final inputs pass. Each measured cgroup
has memory.max/high=4,294,967,296 and memory.swap.max=0. No budget increase,
custom axiom, native_decide, placeholder or linter suppression was added.

Public readback retains 742 signatures/axiom lists and 63 definition bodies.
The 3,301,695-byte log has SHA256
5fd4e6d329de909e1529186e05503246b489d66bafc0370c3d510026cb961485.
The previous 3,273,340 bytes are an exact prefix. Root read all 28,355 new bytes
without a display cut. New axioms use only propext, Classical.choice and Quot.sound.
All 4,547 old non-Audit Lean, 396 stronger-source and 817 Haskell/Cabal identities
remain unchanged. Audit preserves its old body after seven imports.

The first head candidate lacked an open namespace. The first opaque candidate
needed explicit impossible-case elimination and an explicit final cache
equality. A redundant simp argument was removed before strict checking.
The first callback candidate used producer names that cases had eliminated;
the repair uses the actual result/core names. All failed versions and complete
compiler logs remain. No proof contract was weakened.

No Haskell source changed. No Haskell check ran. No new Haskell defect or fix
was established. FINDINGS retains the earlier external repair records.
GitHub port 22 timed out during source publication. The retry uses SSH port 443
with the existing trusted github.com host key and the same repository/ref.

Board sequence {board['sequence']} has ID `{board['id']}`. Its author, content
and metadata have exact verified readback. The complete evidence directory is
lean/restart-evidence/20261028-prepared-model-progress/. It archives every regular
file in /tmp/mcfta-prepared-model-lineage-20261028 without a filter, including
all candidates, repairs, full logs, input snapshots, read scopes and documents.
Historical UNTESTED labels remain accurate for their original candidate versions.
The manifest and standard-library verifier support reconstruction in a fresh
directory. Keep old and reconstructed evidence immutable. Continue in a new area.

The full goal remains ACTIVE. Start with this note, NEXT-PROMPT, HANDOFF and
FINDINGS. Refresh upstream first. Use serial capped 4 GiB compiler/native jobs.
Standing permission permits normal pushes only to the formalize branch of
git@github.com:TharkunAB/cfta.git. Final publication receipts remain outside the
frozen area. Preserve all prior proofs, repairs, counterexamples and marked drafts.
'''
assert not (ROOT / note_path).exists()
(ROOT / note_path).write_text(note)
prior = json.loads((AREA / 'prior-documents.json').read_text())
common = f'''# Verified prepared model progress update — {stamp}

Source `{head}` is pushed and verified on formalize. Full goal ACTIVE.
Read `{note_path}` for exact current contracts and next work.

Actual prepared heads, selected receipts, recording and output histories now
preserve original ProperState. The same full finite outcome keeps its old bound,
resources, histories, canonicality, arity and projection, plus proper outputs.
At a literal successful recording call, original proper model/resource inputs
derive the actual framed Packet/model and exclude a stuck restart. This local
result requires no output history. Original model/origin evidence also bounds
stored paths and each actual recursion-key trie by a finite domain of relative
paths in original subtrees. Global historical keys/native handles remain open.

Strongest semantics: conditional checked rendered soundness under fixed-PCS and
whole-Discharged, plus ordered output-prefix retention with greater depth.
Main gap: actual chosen-model recursive emission and source-derived sufficient
depth across earlier allocating callbacks. A stable finite-depth result does
not establish output existence. DONE does not imply Discharged.

Seven modules/11 public theorems/one finite proof-domain definition: 577 lines,
34,603 bytes. Eight exact strict sources pass. Audit: 4,555 jobs/81,774 theorem
dependencies. Compiler matrix: 22 commands, 19 passes, three preserved failures;
all final inputs pass at serial 4 GiB/swap zero. Public: 742 theorem readbacks,
63 definition bodies, 3,301,695 bytes SHA256
5fd4e6d329de909e1529186e05503246b489d66bafc0370c3d510026cb961485.
Prior 3,273,340 bytes remain an exact prefix. All 28,355 new bytes were read.
All 4,547 old non-Audit Lean, 396 stronger-source and 817 Haskell/Cabal hashes
remain. No Haskell source changed, no Haskell check ran and no new Haskell
defect/fix was established. FINDINGS keeps all earlier external repair records.

Evidence: `lean/restart-evidence/20261028-prepared-model-progress/`.
Board {board['sequence']}: `{board['id']}`, exact verified author/content/metadata.
The full goal remains ACTIVE. Preserve frozen evidence and use a new writable
area. Refresh upstream first; compile/native jobs stay serial under the 4 GiB
cap. Standing push permission covers git@github.com:TharkunAB/cfta.git formalize.

---

'''
for record in prior:
    old = (AREA / 'prior-document-bodies' / record['path']).read_bytes()
    assert hashlib.sha256(old).hexdigest() == record['sha256']
    assert (ROOT / record['path']).read_bytes() == old
    prefix = common
    if record['path'] == 'FINDINGS.md':
        prefix = prefix.replace('---\n\n', '''External Haskell repair record: this checkpoint establishes no new Haskell
defect or required fix. Keep every prior actionable record below. The new
results concern formal proof progress and finite model-relative path bounds.

---

''')
    (ROOT / record['path']).write_bytes(prefix.encode() + old)
final = []
for path in [r['path'] for r in prior] + [note_path]:
    data = (ROOT / path).read_bytes()
    target = AREA / 'final-document-bodies' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    final.append(dict(path=path, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
for record in prior:
    old = (AREA / 'prior-document-bodies' / record['path']).read_bytes()
    assert (ROOT / record['path']).read_bytes().endswith(old)
(AREA / 'final-documents.json').write_text(json.dumps(final, indent=2) + '\n')
(AREA / 'document-verification.json').write_text(json.dumps(dict(
    prior_bodies_exact_suffix=True, prior_documents=len(prior), final_documents=len(final),
    source_head=head, board=board, full_goal='active'), indent=2) + '\n')
print(json.dumps(dict(prior_documents=len(prior), final_documents=len(final), note=note_path)))
