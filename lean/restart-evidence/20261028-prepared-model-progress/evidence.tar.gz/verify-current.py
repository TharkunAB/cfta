"""Bind exact proof checks and preserve all inherited source identities."""
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path('/home/tritlo/Code/mcfta')
AREA = Path('/tmp/mcfta-prepared-model-lineage-20261028')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (AREA / name).write_text(json.dumps(value, indent=2) + '\n')


counts = {}
for name in ['prior-lean-sources.json', 'prior-strong-sources.json',
             'inherited-prior-haskell-sources.json']:
    records = json.loads((AREA / name).read_text())
    for record in records:
        data = (ROOT / record['path']).read_bytes()
        assert digest(data) == record['sha256'], record['path']
        if 'bytes' in record:
            assert len(data) == record['bytes'], record['path']
    counts[name] = len(records)

modules = json.loads((AREA / 'modules.json').read_text())
proofs = []
snapshot = AREA / 'root-review/final-installed'
snapshot.mkdir(exist_ok=True)
for module in modules + ['Audit']:
    path = ROOT / 'lean/MicroCFTA' / (module + '.lean')
    data = path.read_bytes()
    shutil.copyfile(path, snapshot / path.name)
    proofs.append(dict(module=module, path=str(path.relative_to(ROOT)),
                       bytes=len(data), lines=len(data.splitlines()), sha256=digest(data)))
save('final-proof-sources.json', proofs)
save('strong-sources.json', json.loads((AREA / 'prior-strong-sources.json').read_text()) + proofs[:-1])
old_audit = (AREA / 'prior-Audit.lean').read_bytes()
assert (ROOT / 'lean/MicroCFTA/Audit.lean').read_bytes() == (
    ''.join('import MicroCFTA.' + module + '\n' for module in modules).encode() + old_audit)

checks = []
for path in sorted(AREA.glob('*/report.json')):
    report = json.loads(path.read_text())
    if report.get('kind') == 'git-network':
        continue
    raw = (path.parent / 'raw.log').read_bytes()
    assert report['exit_code'] == 0 or (path.parent.name in {'build-head-proper-1', 'build-opaque-proper-1', 'build-callback-progress-1'} and report['exit_code'] == 1), path
    assert (report['bytes'], report['sha256']) == (len(raw), digest(raw)), path
    assert report['cgroup_limits'] == {
        'memory.max': '4294967296', 'memory.high': '4294967296', 'memory.swap.max': '0'}
    if 'source_sha256' in report:
        source = Path(report['command'][-1])
        assert digest(source.read_bytes()) == report['source_sha256'], path
    checks.append(dict(name=path.parent.name, **report))
assert {c['name'] for c in checks if c['exit_code'] != 0} == {'build-head-proper-1', 'build-opaque-proper-1', 'build-callback-progress-1'}
strict = {}
for proof in proofs:
    matches = [record for record in checks
        if record.get('source_sha256') == proof['sha256']
        and '-DwarningAsError=true' in record['command']
        and '-Dlinter.all=true' in record['command']
        and Path(record['command'][-1]).name == proof['module'] + '.lean'
        and record['exit_code'] == 0]
    assert len(matches) == 1, (proof['module'], len(matches))
    strict[proof['module']] = matches[0]['name']
save('compiler-matrix.json', checks)

old_public = (AREA / 'prior-public-readback.log').read_bytes()
public = (AREA / 'public-final/raw.log').read_bytes()
assert public.startswith(old_public)
public_source = (AREA / 'public-final/public.lean').read_text().splitlines()
declarations = json.loads((AREA / 'public-declarations.json').read_text())
definitions = json.loads((AREA / 'public-definitions.json').read_text())
assert len(declarations) == len(set(declarations)) == 731 + len(json.loads((AREA / 'new-public-declarations.json').read_text()))
assert len(definitions) == len(set(definitions)) == 63
assert [line.removeprefix('#check MicroCFTA.') for line in public_source
        if line.startswith('#check MicroCFTA.')] == declarations
assert sum(line.startswith('#print axioms MicroCFTA.') for line in public_source) == 731 + len(json.loads((AREA / 'new-public-declarations.json').read_text()))
assert sum(line.startswith('#print MicroCFTA.') for line in public_source) == 63
save('public-verification.json', dict(theorems=len(declarations), definitions=len(definitions),
    prior_bytes=len(old_public), bytes=len(public), sha256=digest(public),
    new_bytes=len(public) - len(old_public), prior_exact_prefix=True))

old_docs = json.loads((AREA / 'prior-documents.json').read_text())
for record in old_docs:
    data = (ROOT / record['path']).read_bytes()
    assert (len(data), digest(data)) == (record['bytes'], record['sha256']), record['path']
    target = AREA / 'prior-document-bodies' / record['path']
    assert target.read_bytes() == data
save('prior-documents.json', old_docs)
save('source-verification.json', dict(status='pass', inherited=counts,
    final_proof_sources=len(proofs), old_audit_exact_suffix=True,
    prior_documents=len(old_docs), compiler_commands=len(checks),
    compiler_failures=sum(record['exit_code'] != 0 for record in checks),
    all_final_checks_pass=True, strict_sources=len(strict)))
print(json.dumps(dict(status='pass', inherited=counts, proofs=len(proofs),
    commands=len(checks), public_bytes=len(public), prior_documents=len(old_docs))))
