import MicroCFTA.SourcePruningEnumerationSelectedEdge
import MicroCFTA.SourcePruningEnumerationSelectedEntry
import MicroCFTA.SourcePruningEnumerationFinalize
import MicroCFTA.EnumerationStratifiedTransport
import MicroCFTA.SourcePruningEnumerationSelectedEdgeProper

/-!
# Proper pending paths at actual captured-slot completion

The actual stored pending bucket supplies inherited trie validity.
The selected edge preserves proper storage at its reached caller.
The same indexed finalizer preserves it after the captured-slot write.
-/
namespace MicroCFTA.SourcePruningEnumerationCapturedEdge
open EnumerationProgress EnumerationSemantics EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationDependencies
open InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes SourcePruningEnumerationObservation
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Context Post)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => InternedConstructorTemplates.Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Fragment" => Fragments.Fragment Symbol
local notation "Result" => SourcePruningEnumerationSelectedEdge.Result
variable {width : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Actual captured-slot completion derives inherited validity and preserves proper paths. -/
theorem complete_proper
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (caller : Caller width) (before : Cached) (checkEmpty : Bool)
    (uv handle : Nat) (scs : List Suspended)
    (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
    (edges : List (EdgeValue Symbol Constraint)) (depth : Nat) (free : List InternedBinderProtocol.Reference)
    (edge : EdgeValue Symbol Constraint) (roots : Nat → Nat) (memos : Memos)
    (initial : Context formulas solver inventory caller memos)
    (ready : EnumerationDriver.Ready uv before.core)
    (stored : before.core.values[uv]? = some (.unenumerated (some handle) scs))
    (decoded : lookupNode caller.checked.native.machine.heap handle = some (.node parentEntry edges depth free))
    (realized : PendingRealized caller.checked.native.machine.heap before.core)
    (selected : edge ∈ edges)
    (paths : Roots before.core.representatives roots)
    (counts : EnumerationCanonicalWaiting.Correct roots before.core.values before.waiting)
    (flags : ∀ slot, SourcePruningEnumerationNativeIndex.candidate caller.checked.native.machine.heap
      ((before.core.values[slot]?).getD .eliminated) = some (before.expandable slot))
    (pending : InputsPending before.core scs)
    (allowed : arityAllows edge.children.length scs = true)
    (tries : List EqualityTrie.Trie) (residual : Option Constraint)
    (projected : SourcePruningEnumerationConstraint.project edge.entry.key.constraint = some (tries, residual))
    (proper : ProperState before.core)
    {r n p h k : Nat} {fragment : Fragment} {afterCaller : Caller width}
    {after : Cached} {savedQueries : Queries}
    (completed : run checkEmpty r n p h k uv scs edge caller before memos.query =
      some (.complete fragment afterCaller savedQueries after)) : ProperState after.core := by
  obtain ⟨value, lookup, available, closed⟩ := realized uv handle scs stored
  have same : value = .node parentEntry edges depth free := Option.some.inj (lookup.symm.trans decoded)
  subst value
  have bounded : ∀ sc ∈ scs, sc.var < before.core.counter :=
    ready.safe.1.values _ (List.mem_of_getElem? stored)
  have inheritedInputs : ProperInputs scs :=
    proper_inputs (.unenumerated (some handle) scs) (proper _ (List.mem_of_getElem? stored))
  have inherited : ValidSuspended scs := fun sc member => (inheritedInputs sc member).1
  unfold run at completed
  cases selectedRun : SourcePruningEnumerationSelectedEdge.run checkEmpty r n p h k
      scs edge caller before memos.query with
  | unhandled => rw [selectedRun] at completed; cases completed
  | rejected reachedCaller saved reached => rw [selectedRun] at completed; cases completed
  | stopped fragments observation candidate => rw [selectedRun] at completed; cases completed
  | complete produced reachedCaller saved reached =>
      rw [selectedRun] at completed
      simp only [Option.map_eq_some_iff] at completed
      obtain ⟨finished, finishRun, fields⟩ := completed
      have cacheSame : finished = after := (SourcePruningEnumerationSelectedEdge.Result.complete.inj fields).2.2.2
      rw [← cacheSame]
      exact SourcePruningEnumerationFinalize.run_proper reachedCaller.checked.native.machine.heap k uv
        produced reached finished
        (SourcePruningEnumerationSelectedEdge.complete_proper caller before checkEmpty parentEntry edges depth free
          edge scs roots memos initial available closed selected ready.safe realized paths counts flags bounded
          pending allowed tries residual projected proper inherited selectedRun) finishRun

end MicroCFTA.SourcePruningEnumerationCapturedEdge
