[2026-10-28 22:30:53 CET] Candidate UNTESTED.

The exact theorem is PreparedNativeHookResources.CompletedHeadReceipt.proper. Its full actual prepared receipt is an input. Original ProperState before.core is the only added premise. The conclusion is ProperState at that same receipt's after.core. No resource/result/receipt field is replaced.

The original stored source bucket supplies inherited ValidSuspended and reference bounds. Actual parentAvailable and parentClosed remain separate fields. Actual receipt.running 0 supplies the same captured completion at its original work bound. Literal run inversion obtains its actual completed selected edge and finalizer. Existing generic SelectedEdge.complete_proper and Finalize.run_proper derive the target invariant. No new runtime definition, axiom, budget, linter suppression, future state supplier or source/prepared equality is used.

The candidate follows the already-used CapturedEdge.complete_proper inversion after its source-lookup step. That lookup step is omitted because the prepared receipt already provides separate availability/closedness for its actual prepared parent. The full original head packet, full Memos and actual after cache remain indexed by the unchanged input receipt.

Candidate SHA 669378c7a258c3368e36b78ee6d64c689858d6c40e8b654394954b05b9b698c4, 75 lines, 4788 bytes. Candidate file is immutable. Complete exact source snapshots and read scopes are retained in /tmp/mcfta-prepared-model-lineage-20261028/history-forward/audit-v1/MANIFEST.json. No compiler, native evaluator, Git, repository edit, network or board operation was run. Root owns checks and repairs.
