# Prepared proper storage, actual callback progress and finite model paths

All final sources pass default and strict Lean 4.34.1 checks.
The strict checks set warningAsError=true and linter.all=true.
Seven new modules contain 577 lines and 34,603 bytes.
They add eleven public theorems and one finite proof-domain definition.
They do not change the enumerator or Haskell runtime definitions.

The actual prepared CompletedHeadReceipt now preserves ProperState.
Its source handle remains distinct from its available prepared parent.
The proof uses the actual selected child and the same actual finalizer.
The opaque completion proof also uses the actual child result and finalizer.
Neither proof needs a future proper-state supplier.
Preparation, successful recording and the four history constructors retain
proper storage at each actual emitted output. The combined finite theorem
retains the original bound, outcome, full resources, histories, canonical
storage, arity and physical projection. It adds proper output storage.
It does not assert that an output exists.

callback_record_progress does not need an output or an output history.
Its original inputs are Packet, allocated fragment, ProperState, one native
Satisfies assignment and literal successful recording at any actual fuel.
A common larger recording fuel identifies that actual result with the safe
raw recording producer. This uses shared recording semantics, not a worker
or Failure cast. It derives the actual returned Packet, RenderStable, Frame,
ProperState, the SAME assignment model and exact restart != some .stuck.
No future cache, model, recursive completion or output gate is added.
This local theorem is not a proof of global no-stuck execution.

relativePaths whole is a finite list of existing relative paths in every
actual subtree of whole. A raw root-path domain would be too small.
Original Satisfies, AssignmentOrigins, allocated membership and the literal
stored slot derive domain membership and a whole-term height bound.
Canonical adds a per-trie path-count bound. The final corollary uses the
ACTUAL EnumerationState.recursionKey construction at that same stored slot.
This bounds each current key trie. It does not yet enumerate all trie shapes,
bound the whole historical ancestry, restrict the native handle field or
prove a strictly decreasing global search measure.

The original head candidate failed because EnumerationSemantics was not open.
Its repair adds that open only. The original opaque candidate failed because
an impossible rejected/completed observation needed explicit elimination,
and cases eliminated finalizer variables. The repair keeps an explicit final
cache equality. A redundant simp argument was removed before strict checking.
The original callback candidate failed because cases eliminated producer
variable names. Its repair uses the actual result/core names that remain.
All three failed inputs and complete raw logs remain. No contract was weakened.
Opaque v2 passed with a new-source unused-simp warning; final v3 removes it.
The combined finite check in each stopped batch was NOT RUN until its prior
callback command passed. It is not recorded as a failed command.

Twenty-two serial checks have nineteen passes and three retained failures.
All final inputs pass. Each measured cgroup has memory.max/high=4294967296
and memory.swap.max=0. Audit passes 4555 jobs and checks dependencies of
81774 MicroCFTA theorems. No custom axiom, placeholder, native_decide,
linter suppression or resource-budget increase was introduced.

Public readback checks 742 signatures and axiom lists and 63 definition bodies.
The complete 3301695-byte log has SHA256
5fd4e6d329de909e1529186e05503246b489d66bafc0370c3d510026cb961485.
The previous 3273340 bytes remain an exact prefix. Root read all 28355 new
bytes, without a display cut. New dependencies use only propext,
Classical.choice and Quot.sound. Two old axiom reports have no axioms;
therefore counting only the phrase depends on axioms gives 740, not 742.
The exact public command inventory verifies all 742 reports.

All 4547 old non-Audit Lean, 396 stronger-source and 817 Haskell/Cabal
identities remain unchanged. Audit preserves its old body after seven imports.
All eighteen old documents remain unchanged before the new headers.
No Haskell source changed. No Haskell check ran. No Haskell defect or fix
was established. Root FINDINGS will retain the external repair record.

The strongest semantic theorem is still conditional checked-render soundness
under its fixed-PCS and whole-Discharged assumptions. For every supplied
finite recursion capacity, stable finite resource-certified execution and
ordered output-prefix retention remain. DONE is not whole Discharged.
Configured stop emits a partial output; it is not an exhausted stopped hook.

The main gap is actual chosen-model recursive emission and a sufficient depth
derived from original source, covering preceding actual sibling callbacks.
An earlier stopped hook must remain an alternative until it is discharged.
Global key-shape/history and native handle/inventory bounds, original policy
coverage, origin closure, public API composition and optimized Haskell
correspondence remain open. No new admitted all-depth failure is claimed.

All bounded child author/audit areas are retained unchanged. Their historical
UNTESTED labels describe those original candidate versions. Final installed
sources and compiler-matrix.json identify the checked versions.
The full goal remains ACTIVE and incomplete.
