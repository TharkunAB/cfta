from pathlib import Path
import hashlib,json,re,sys
original=Path('/tmp/mcfta-native-stored-prefix-control-20261030')
r=Path(sys.argv[1]) if len(sys.argv)>1 else original
out=Path(sys.argv[2]) if len(sys.argv)>2 else r
out.mkdir(exist_ok=True)
root=Path('/home/tritlo/Code/mcfta')
def sha(b): return hashlib.sha256(b).hexdigest()
def record(p):
    b=p.read_bytes();return {'path':str(p.relative_to(root)),'bytes':len(b),'sha256':sha(b)}
def dump(name,data): (out/name).write_text(json.dumps(data,indent=2)+'\n')
modules=json.loads((r/'modules.json').read_text())
for name in ['prior-strong-sources.json','prior-haskell-sources.json']:
    rows=json.loads((r/name).read_text())
    for row in rows:
        p=root/row['path'];b=p.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],p
oldlean=json.loads((r/'prior-lean-sources.json').read_text());changed=[]
for row in oldlean:
    if sha((root/row['path']).read_bytes())!=row['sha256']: changed.append(row['path'])
assert changed==['lean/MicroCFTA/Audit.lean'],changed
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes()==(''.join('import MicroCFTA.'+n+'\n' for n in modules)).encode()+(r/'prior-Audit.lean').read_bytes()
oldstrong=json.loads((r/'prior-strong-sources.json').read_text());newstrong=[]
for name in modules:
    row=record(root/'lean/MicroCFTA'/f'{name}.lean');row={'module':name,**row};newstrong.append(row)
dump('final-strong-sources.json',oldstrong+newstrong)
dump('final-haskell.json',json.loads((r/'prior-haskell-sources.json').read_text()))
lean=[record(p) for p in sorted((root/'lean/MicroCFTA').glob('*.lean'))]
assert len(lean)==len(oldlean)+len(modules)
dump('final-lean-sources.json',lean)
commands=[];snapshot_count=0
for d in sorted(r.iterdir()):
    if d.name.startswith('prior-') or not (d/'report.json').is_file():continue
    report=json.loads((d/'report.json').read_text());raw=(d/'raw.log').read_bytes()
    assert len(raw)==report['bytes'] and sha(raw)==report['sha256'],d
    assert json.loads((d/'started-command.json').read_text())['command']==report['command'],d
    assert report['cgroup_limits']=={'memory.max':'4294967296','memory.high':'4294967296','memory.swap.max':'0'}
    inputs=json.loads((d/'inputs.json').read_text())
    for row in inputs:
        assert sha((d/'input-sources'/f"{row['module']}.lean").read_bytes())==row['sha256'],(d,row)
        snapshot_count+=1
    if 'source_sha256' in report:
        source=Path(report['command'][-1])
        if source.is_relative_to(original):source=r/source.relative_to(original)
        assert sha(source.read_bytes())==report['source_sha256'],d
    commands.append({'label':d.name,**report,'input_snapshots':len(inputs)})
plan=json.loads((r/'verification-plan.json').read_text())
final=plan['strict']
for name,label in final.items():
    report=json.loads((r/label/'report.json').read_text());assert report['exit_code']==0
    assert (root/'lean/MicroCFTA'/f'{name}.lean').read_bytes()==(r/label/'MicroCFTA'/f'{name}.lean').read_bytes()
    if name!='Audit':assert report['bytes']==0
old=(r/'prior-public-readback/raw.log').read_bytes();public=(r/plan['public_run']/'raw.log').read_bytes()
assert public.startswith(old)
for stage in plan['earlier_public_runs']:assert public.startswith((r/stage/'raw.log').read_bytes()),stage
tail=public[len(old):].decode();names=json.loads((r/'new-public-declarations.json').read_text())
for n in names:assert 'MicroCFTA.'+n in tail,n
axioms=re.findall(r"'MicroCFTA\.([^']+)' (?:depends on axioms: \[([^\]]*)\]|(does not depend on any axioms))",tail,re.S)
assert {name for name,_,_ in axioms}==set(names),(len(axioms),len(names))
for _,a,_ in axioms:
    assert {s.strip() for s in a.split(',') if s.strip()}<={'propext','Classical.choice','Quot.sound'},a
assert '#check ' in (r/plan['public_source']).read_text()
assert len(re.findall(r'^#check ',(r/plan['public_source']).read_text(),re.M))==len(json.loads((r/'public-declarations.json').read_text()))
definition_names=json.loads((r/'public-definitions.json').read_text())
public_source=(r/plan['public_source']).read_text()
for name in definition_names:
    assert '\n#print MicroCFTA.'+name+'\n' in public_source,name
assert len(re.findall(r'^#print MicroCFTA\.',public_source,re.M))==len(definition_names)
dump('verification-commands.json',commands)
summary={'old_protected':len(oldstrong),'current_protected':len(oldstrong+newstrong),'haskell_inputs':835,'old_lean':len(oldlean),'current_lean':len(lean),'changed_old_lean':changed,'audit_old_body_exact_suffix':True,'commands':len(commands),'passed':sum(c['exit_code']==0 for c in commands),'failed':sum(c['exit_code']!=0 for c in commands),'input_snapshots':snapshot_count,'matching_current_strict':final,'public_checks':len(json.loads((r/'public-declarations.json').read_text())),'public_definitions':len(json.loads((r/'public-definitions.json').read_text())),'public_old_prefix_bytes':len(old),'public_bytes':len(public),'public_sha256':sha(public),'public_new_bytes':len(public)-len(old),'new_public_axiom_reports':len(axioms),'all_new_axioms_standard':True}
dump('verification-summary.json',summary);print(json.dumps(summary))
