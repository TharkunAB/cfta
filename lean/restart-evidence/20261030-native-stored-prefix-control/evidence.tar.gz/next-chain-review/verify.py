from pathlib import Path
import hashlib
import json

r = Path(__file__).resolve().parent
reuses = json.loads((r / 'reuse-ledger.json').read_text())
rows = []
for a in reuses:
    source = Path(a['source']).read_bytes()
    copied = (r / a['copy']).read_bytes()
    assert source == copied
    assert len(source) == a['source_bytes']
    assert len(source.splitlines()) == a['source_lines']
    assert hashlib.sha256(source).hexdigest() == a['source_sha256'] == a['copy_sha256']
    assert a['actual_lines'] == list(range(1, a['source_lines'] + 1))
    rows.append({'source': a['source'], 'classification': a['classification'], 'source_sha256': a['source_sha256'], 'fresh_old_lines': [], 'reused_lines': a['actual_lines'], 'union_lines': a['actual_lines']})
assert json.loads((r / 'acquisitions.json').read_text()) == []
v1 = (r / 'SourcePruningNarrowChainBound-v1-UNCOMPILED.lean').read_text()
v2 = (r / 'SourcePruningNarrowChainBound-v2-UNCOMPILED.lean').read_text()
contracts = json.loads((r / 'PUBLIC-CONTRACTS.json').read_text())
for d in contracts['declarations']:
    declaration = d.get('full_header', d.get('full_declaration'))
    assert declaration in v1 and declaration in v2
for number in [1, 2]:
    meta = json.loads((r / f'draft-v{number}.json').read_text())
    source = (r / meta['file']).read_bytes()
    assert hashlib.sha256(source).hexdigest() == meta['sha256']
    assert len(source) == meta['bytes']
    assert len(source.splitlines()) == meta['lines']
result = {'status': 'pass', 'authorized_new_whole_reuses': len(reuses), 'fresh_old_acquisitions': 0, 'new_old_whole_modules': 0, 'public_declarations': len(contracts['declarations']), 'public_headers_and_definitions_unchanged': True, 'owner_compiler_commands': 0, 'owner_runtime_commands': 0}
if (r / 'FROZEN').exists():
    assert json.loads((r / 'SOURCE-UNIONS.json').read_text()) == rows
    assert json.loads((r / 'source-verification.json').read_text()) == result
else:
    (r / 'SOURCE-UNIONS.json').write_text(json.dumps(rows, indent=2) + '\n')
    (r / 'source-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
