# Scope

Source-only consecutive actual filtering bound. Root owns all checking, execution, Git, network, board, production, and packaging. No spawning.

Only /tmp/mcfta-narrowing-chain-bound-review-20261030 is writable for this task. Keep all prior bundles frozen.

The parent explicitly authorizes exact whole reuse of the three NEW checked NarrowControl, NarrowLineage, and NarrowReturnedControl modules. No OLD whole module is named or acquired. Two OLD whole-module slots remain unused.

Retain actual narrowAt observations, varying keys, actual Keeps lineage, and internally derived Normal. Bound only one preserved row source. Source resets and global capacity remain open.
