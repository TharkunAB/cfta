# OLD whole source slots

Allowed: two. Used: zero. No new OLD whole or near-whole module was named or acquired.
The three reused NEW checked modules were explicitly authorized in the parent task.
