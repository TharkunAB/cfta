No source or metadata acquisition failed. A memory-registry query returned no matches with the normal rg exit code 1. It supplied no task fact. No compiler or runtime command was attempted.
