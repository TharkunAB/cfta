# Proposed public contracts

UNCOMPILED source-only. The owner ran no proof check. Root reported that its chain-bound probe remains pending.

```lean
import MicroCFTA.SourcePruningNarrowLineage
import MicroCFTA.SourcePruningNarrowReturnedControl
import Std.Tactic

/-!
# A finite bound for consecutive actual changed row filters

The carrier contains complete edges from one preserved row source.
Keys and fuel can vary at each observed step. A first actual closed filter
supplies the physical normal form. Source resets need a separate bound.

UNCOMPILED source-only draft. Root owns all checks and integration.
-/
namespace MicroCFTA.SourcePruningNativeView
open InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
local notation "Symbol" => SourcePruningTemplates.Symbol
attribute [local instance] FormulaExecutable.formulaDecidableEq
variable {Guard Key : Type}
```

```lean
noncomputable def rootRowCount (carrier : List (EdgeValue Symbol Guard))
    (value : Value Symbol Guard) : Nat :=
  match carrier with
  | [] => 0
  | edge :: rest => by
      classical
      exact if edge ∈ nodeEdges value then rootRowCount rest value + 1 else rootRowCount rest value
```

```lean
inductive ChangedFilters [DecidableEq (EdgeKey Symbol Guard)]
    (fits : Key → Symbol → Bool) (admits : Key → Value Symbol Guard → Bool) :
    State Symbol Guard → Value Symbol Guard → Nat → State Symbol Guard → Value Symbol Guard → Prop
  | nil {heap : State Symbol Guard} {value : Value Symbol Guard} :
      ChangedFilters fits admits heap value 0 heap value
  | cons {before middle after : State Symbol Guard} {value next result : Value Symbol Guard} {count : Nat}
      (fuel : Nat) (key : Key) (oldHandle newHandle : Nat)
      (returned : narrowAt fits admits fuel key value before = .done next middle)
      (oldEncoded : SourcePruningEnumerationNodes.encodeNode value = some oldHandle)
      (newEncoded : SourcePruningEnumerationNodes.encodeNode next = some newHandle)
      (changed : newHandle ≠ oldHandle)
      (rest : ChangedFilters fits admits middle next count after result) :
      ChangedFilters fits admits before value (count + 1) after result
```

```lean
theorem narrowAt_changed_rootRowCount_lt [DecidableEq (EdgeKey Symbol Guard)]
    (fits : Key → Symbol → Bool) (admits : Key → Value Symbol Guard → Bool)
    (fuel : Nat) (key : Key) (value result : Value Symbol Guard) (before after : State Symbol Guard)
    (oldHandle newHandle : Nat) (carrier : List (EdgeValue Symbol Guard))
    (ready : SourceEqualityRequiredCache.Ready before)
    (available : Available before value) (ordinary : SourceEqualityRequiredCache.Ordinary value)
    (normal : EqualityOrdinaryReadback.Normal before value)
    (included : ∀ edge ∈ nodeEdges value, edge ∈ carrier)
    (returned : narrowAt fits admits fuel key value before = .done result after)
    (oldEncoded : SourcePruningEnumerationNodes.encodeNode value = some oldHandle)
    (newEncoded : SourcePruningEnumerationNodes.encodeNode result = some newHandle)
    (changed : newHandle ≠ oldHandle) :
    rootRowCount carrier result < rootRowCount carrier value ∧
      (∀ edge ∈ nodeEdges result, edge ∈ carrier)
```

```lean
theorem ChangedFilters.rootRowCount_bound [DecidableEq (EdgeKey Symbol Guard)]
    (fits : Key → Symbol → Bool) (admits : Key → Value Symbol Guard → Bool)
    (before after : State Symbol Guard) (value result : Value Symbol Guard) (count : Nat)
    (history : ChangedFilters fits admits before value count after result)
    (carrier : List (EdgeValue Symbol Guard))
    (ready : SourceEqualityRequiredCache.Ready before)
    (available : Available before value) (closed : value.free = [])
    (ordinary : SourceEqualityRequiredCache.Ordinary value)
    (normal : EqualityOrdinaryReadback.Normal before value)
    (included : ∀ edge ∈ nodeEdges value, edge ∈ carrier) :
    count + rootRowCount carrier result ≤ rootRowCount carrier value ∧
      (∀ edge ∈ nodeEdges result, edge ∈ carrier)
```

```lean
theorem changedFilters_after_returned_bound [DecidableEq (EdgeKey Symbol Guard)]
    (fits : Key → Symbol → Bool) (admits : Key → Value Symbol Guard → Bool)
    (fuel : Nat) (key : Key) (initial value result : Value Symbol Guard)
    (before middle after : State Symbol Guard) (count : Nat)
    (ready : SourceEqualityRequiredCache.Ready before)
    (available : Available before initial) (closed : initial.free = [])
    (returned : narrowAt fits admits fuel key initial before = .done value middle)
    (history : ChangedFilters fits admits middle value count after result) :
    count ≤ (nodeEdges value).length
```
