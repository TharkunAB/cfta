# Consecutive changed-filter bound

This bundle contains a source-only, UNCOMPILED proof draft. It proposes a numeric bound for consecutive actual changed filters on one preserved row source. It does not establish the global original-input capacity bound.

## Proposed statement

Suppose a first actual `narrowAt` call succeeds on a closed Available value in a Ready heap. Let `rows` be the complete root edges of its actual returned value. Every subsequent finite history of consecutive successful filters with changed encoded handles has at most `rows.length` steps. The key and fuel can differ at each step. Including the first call gives at most `rows.length + 1` calls for this history.

The first call can perform physical normalization. Its input need not satisfy `EqualityOrdinaryReadback.Normal`. The proof obtains physical Normal, ordinary shape, closedness, Available, and Keeps for its actual result from the checked `narrowAt_returned_control` law. It does not ask for an initial historical `makeNode` observation.

This is the proposed statement. Neither draft has been compiled or evaluated by this owner. Root reported that its probe remains pending in its latest task status. The earlier checked modules are inputs, not evidence that this new draft passes.

## Measure and actual observations

`rootRowCount carrier value` counts carrier occurrences whose complete edge is a member of `nodeEdges value`. It is a classical, noncomputable mathematical measure. It is not a runtime operation. Repeated carrier edges count repeated occurrences. This permits a finite list carrier without a Nodup assumption.

The one-step theorem has an explicit inclusion premise: every current root edge occurs in the fixed carrier. It calls the checked `narrowAt_changed_loses_row` law internally. Its row subset and missing complete-edge witness follow from the literal successful filter observation, the actual encodings, their difference, and the existing Normal input. The theorem returns strict numeric descent and carrier inclusion for the result. The caller does not supply row loss.

Three private arithmetic lemmas show that the count is at most carrier length, is monotone under root-row inclusion, and strictly decreases when a carrier edge is lost. They use induction on the finite carrier. They do not assume canonical list distinctness.

`ChangedFilters` records a finite history of actual observations. Each constructor contains the literal `narrowAt ... = .done ...` equation, the old and new encoding equations, their difference, and the remaining observed history. Each next input heap and value is exactly the preceding output heap and value. Each hop chooses its own key and fuel. The relation provides no completion witness and no existence theorem for an unobserved future step.

`ChangedFilters.rootRowCount_bound` proves the stronger inequality `count + rootRowCount carrier finalValue <= rootRowCount carrier initialValue`. It also returns final carrier inclusion. The proof derives actual Keeps and all next-step gates from `narrowAt_returned_control` at each hop. It passes the resulting Ready heap and physical Normal to the next hop. No Ready, Normal, loss, or abstract growth premise is stored in the history itself.

`changedFilters_after_returned_bound` uses a first actual successful closed filter. It then chooses the literal root rows of that result as the carrier and applies the history bound. Its public premises include no Normal, ordinary shape, historical constructor, row-loss certificate, Complete predicate, coverage property, or future completion supplier.

## Exact boundary

The history contains consecutive changed filter calls. It does not count unchanged calls. It does not itself admit intervening native heap writers. Actual Keeps supplies the next heap gates through each filter result. Transport through other intervening Keeps writers is a separate extension and is not claimed here.

The first result can have more root rows than the literal root row list of a nonordinary input. This bound depends on the actual first result. It is not yet a numeric bound computed from the original input.

Incoming and dispatch intersections, selected Mu unfolding, and Prepared Mu/Union reconstruction can replace the row source. Each new source requires a new carrier and can require another first normalization call. This bundle does not bound the number of those resets. It does not transport the history through the actual worker/caller or derive a global original-depth bound.

A bound on changed calls alone does not prove termination when unchanged calls can repeat. It does not prove coverage, recursive worker completion, capacity for all earlier alternatives or staged children, public-adapter correctness, or Haskell correspondence. The full original-input, both-worker, public/Haskell goal remains open.

No Haskell source was changed. No Haskell defect, fix, or candidate was established.

## Draft versions

V1 has 166 lines and 9470 bytes. Its SHA is 329f7de994e34210b8a26433c0dcc4d63d73b9f079823f76c2e76df6187dc34a.

V2 has 171 lines and 9529 bytes. Its SHA is 5cb57a0928d2148a01eb4c9dbea64c5dfdd4fddb75a080957d3320f0433e93a0. V2 explicitly reverts and reintroduces the carrier-dependent loss premise before the private strict-count induction. No public header or definition changes. Prefer V2 for the later Root probe. V1 remains immutable.

Both versions retain their UNCOMPILED status line. No proof-check result is claimed. PUBLIC-CONTRACTS.md and PUBLIC-CONTRACTS.json retain all full public headers, definitions, constructors, imports, namespace context, local notation, variable declarations, and local instance attribute. The source files retain all proof bodies.

## Source provenance and commands

Root explicitly authorized exact whole reuse of these three NEW checked sources:

- SourcePruningNarrowControl.lean: 165 lines, SHA 4770bbbe96ea80ff3fc0159c956cf6286cced6f796b3bc09d6656536b4425e2a.
- SourcePruningNarrowLineage.lean: 81 lines, SHA 2e4ba000e24b65d9d06e1af16964383c6ac6e83bb66f9685dbdd5e6e10cb4a53.
- SourcePruningNarrowReturnedControl.lean: 115 lines, SHA 0862dc8f457d8e46cd39f6f748dfd9a64a2e44fbd3a6d3489c8fc058f062838d.

All three exact copies and provider identities are retained. All three were read in full. No OLD source body was acquired. Zero of two OLD whole-module slots were used. There are no fresh OLD cuts or locators. SOURCE-UNIONS.json records the exact full line unions of the three authorized NEW reuses. reuse-ledger.json records their source and copy hashes.

A lightweight memory-registry query returned no matches. No memory-derived claim was used. No metadata or source acquisition command failed. No compiler, evaluator, native execution, Git operation, network request, board operation, production edit, or sub-agent was used by this owner. Root stated that it will probe the draft in a later fresh phase after its current checkpoint. All prior bundles remain unchanged.
