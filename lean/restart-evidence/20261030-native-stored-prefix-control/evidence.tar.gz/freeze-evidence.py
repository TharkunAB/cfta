from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,subprocess

r=Path('/tmp/mcfta-native-stored-prefix-control-20261030')
assert not (r/'FROZEN.json').exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='183f4275451d1d3d09a1b5de12653a84549da8b4'
assert not subprocess.check_output(['git','status','--porcelain=v1'])
publication=json.loads((r/'checkpoint-publication.json').read_text())
assert publication['head']==head and publication['readback_exact'] and publication['tracking_exact']
summary=json.loads((r/'verification-summary.json').read_text())
assert summary['commands']==12 and summary['passed']==9 and summary['failed']==3
assert summary['public_checks']==1209 and summary['all_new_axioms_standard']
assert json.loads((r/'owned-verification.json').read_text())['status']=='pass'
for p in r.iterdir():
    if p.is_dir() and not p.name.startswith('prior-') and (p/'started-command.json').exists():assert (p/'report.json').exists()
rows=[]
for p in sorted(r.rglob('*')):
    if p.is_file():
        assert not p.is_symlink();b=p.read_bytes()
        rows.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
seal={'created_at':datetime.now(ZoneInfo('Europe/Stockholm')).isoformat(),'write_halt':True,'goal_turn':'progress','full_goal_complete':False,'goal_controller_observed_status':'blocked','work_continues_under_user_instruction':True,'source_head':'6dab391a2643f95181540773ba2420dc493024be','docs_head':head,'main_head':'bd5a406a6a3f84b7e3ae0906082783911509df83','latest_prior_board_sequence':787,'compiler_commands':12,'passed_commands':9,'repaired_failed_commands':3,'input_snapshots':27,'new_laws':8,'public_checks':1209,'public_definitions':116,'next_source_review_status':'chain bound frozen UNCOMPILED, all payloads retained; caller source review active outside this snapshot','payload_count_excluding_seal':len(rows),'payloads':rows}
(r/'FROZEN.json').write_text(json.dumps(seal,indent=2)+'\n')
for p in r.rglob('*'):
    if p.is_file():p.chmod(p.stat().st_mode&~0o222)
assert all(not(p.stat().st_mode&0o222) for p in r.rglob('*') if p.is_file())
print(json.dumps({'sealed':True,'payloads_excluding_seal':len(rows),'raw_bytes_excluding_seal':sum(a['bytes'] for a in rows),'source_head':seal['source_head'],'docs_head':head}))
