from pathlib import Path
import hashlib,json,sys

original=Path('/tmp/mcfta-native-stored-prefix-control-20261030')
r=Path(sys.argv[1]) if len(sys.argv)>1 else original
out=Path(sys.argv[2]) if len(sys.argv)>2 else r
out.mkdir(exist_ok=True)
repo=Path('/home/tritlo/Code/mcfta')
def sha(b):return hashlib.sha256(b).hexdigest()
def read(path):return path.read_bytes()
def owner(name,mh,ph):
    base=r/name
    assert sha(read(base/'MANIFEST.json'))==mh
    assert sha(read(base/'pins.json'))==ph
    manifest=json.loads((base/'MANIFEST.json').read_text())
    rows=manifest['files'] if 'files' in manifest else manifest['payloads']
    actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    self_files={'MANIFEST.json','pins.json'} if 'files' in manifest else {'MANIFEST.json','MANIFEST.sha256'}
    assert actual=={a['path'] for a in rows}|self_files
    if 'payloads' in manifest:assert (base/'MANIFEST.sha256').read_text().split()[0]==mh
    for a in rows:
        p=base/a['path'];b=read(p)
        assert not p.is_symlink() and not(p.stat().st_mode&0o222)
        assert len(b)==a['bytes'] and sha(b)==a['sha256'],p
    assert all(not(p.stat().st_mode&0o222) for p in base.rglob('*') if p.is_file())
    pin_data=json.loads((base/'pins.json').read_text())
    if isinstance(pin_data,dict):
        for path,h in pin_data['pins'].items():assert sha(read(base/path))==h
    return base,{'payloads':len(rows),'regular_files':len(actual),'readonly':True}

prefix,prefix_result=owner('prefix-review','dd52932014e0e7a29016acf59ed47be663f77c7b77cea6bf745a73055f9315cd','a27d9f357e118033e06990477aa1897dd4a52245e8e8ecbd212257751a1f6389')
producer,producer_result=owner('producer-review','ba06edc307a878e6517a9393ca79bfe5cb3a1f2de1a7bbf621fd08b9287d3794','27b78824d3e7a44153823ef84bb2d60c3f578db8b726a93be3eaa54a4a650309')
public,public_result=owner('public-review','0850865a76f6fac429c9df1dd35256a32c40d6d31041448c53b8af8a210c852e','159070b1a98eedf262e9b78c13d37c75211fffaebeb0e189a0a6f7d0c6638a5a')
future,future_result=owner('next-chain-review','051866ad7d59a189abb08f4bea9ecf254d586c8df21018fadc21a3cd5883ed68','37e444470856a799fcaebf986cfa6a7d2141abaf77720c84c534237b7999bb56')
maps=json.loads((r/'frozen-manifest-map.json').read_text())
def source_file(path):
    p=Path(path)
    if p.is_relative_to(original):return r/p.relative_to(original)
    if p.is_relative_to(repo):return p
    p=repo/'lean/MicroCFTA'/p.name
    assert p.is_file(),path
    return p
counts={}
for name,base in [('prefix-review',prefix),('producer-review',producer),('public-review',public),('next-chain-review',future)]:
    count=0
    for leaf in ['acquisitions.json','reuse-ledger.json','old-source-cut-ledger.json','old-source-locator-ledger.json']:
        ledger=base/leaf
        if not ledger.exists():continue
        for a in json.loads(ledger.read_text()):
            source=source_file(a.get('source_path',a.get('source')))
            b=source.read_bytes()
            assert sha(b)==a['source_sha256'],(base,source)
            assert len(b.splitlines())==a['source_lines']
            if 'source_bytes' in a:assert len(b)==a['source_bytes']
            if 'actual_lines' in a:expected=b''.join(b.splitlines(keepends=True)[i-1] for i in a['actual_lines'])
            else:
                lo,hi=a['actual'];expected=b''.join(b.splitlines(keepends=True)[lo-1:hi])
            copied=read(base/a.get('copy',a.get('cut')))
            assert copied==expected and sha(copied)==a.get('copy_sha256',a.get('cut_sha256'))
            if 'frozen_bundle' in a:
                encoded=read(r/maps[a['frozen_bundle']]);assert sha(encoded)==a['frozen_manifest_sha256']
                manifest=json.loads(encoded);entries=manifest.get('files',manifest.get('payloads'))
                entry=next(e for e in entries if e['path']==a['frozen_copy'])
                assert entry['sha256']==sha(copied),(base,a['copy'])
            count+=1
    counts[name]=count
result={'status':'pass','prefix_review':prefix_result,'producer_review':producer_result,'public_review':public_result,'next_chain_review':future_result,'next_chain_status':'UNCOMPILED, no Root probe','exact_source_records':counts,'historical_manifest_count':len(maps),'root_complete_source_and_public_read':True,'frozen_owner_drafts_remain_UNCOMPILED':True}
(out/'owned-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
