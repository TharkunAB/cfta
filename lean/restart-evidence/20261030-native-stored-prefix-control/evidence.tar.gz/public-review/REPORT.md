# Native stored-prefix and actual-returned narrowing review

Result: PASS for source and public contracts. This review found no defect in
these eight final public statements or their source proofs. This review ran
no compiler, evaluator, native test, Git, network, board or production command.
Root owns compilation and runtime evidence.

## Exact reviewed files

| Copy | Lines | Bytes | SHA-256 |
| --- | ---: | ---: | --- |
| inputs/stored-prefix-v4.lean | 343 | 25865 | b487318cb46822dbb5b1b8c9f3fb5e53bfe9ab817ead83f8e5b80539a3d0618c |
| inputs/installed-prefix.lean | 342 | 25835 | 6312a299e110065b4dd53fcc1e9b32d6980ab945d6b27b611848cf02475877ef |
| inputs/installed-returned-control.lean | 115 | 6962 | 0862dc8f457d8e46cd39f6f748dfd9a64a2e44fbd3a6d3489c8fc058f062838d |
| inputs/public-eight-tail.log | 190 | 13813 | e43d4fbfdd22b7589088d9195119f7dd2980d2d091e48fcd093419217a5d9890 |

The reviewer read all 343 draft prefix lines and all private proof branches.
The installed prefix is exactly that draft with its 30-byte uncompiled status
line removed. installed-prefix-identity.json records this comparison.
The reviewer read all 115 installed returned-control lines. The installed
sources contain 457 lines and 32797 bytes in total.

The reviewer read all 190 public-tail lines. A combined display was truncated.
The reviewer read all lines again in six separate displays. Each display
returned without truncation. public-recovery-read-ledger.json records the
six complete ranges and exact copies. read-ledger.json records the source
ranges. acquisitions.json records original paths and exact copy hashes.

## Stored-prefix public contracts

All five laws are in SourceCurrentAllocatedNativeStoredPrefix.

1. clean_prefix_stored takes an actual finite checked Trace. The trace can end
   at any remaining control and state. It requires entry Good, SemanticReady,
   Fields, Stored and Clean. It concludes Stored at the actual prefix state.
   It does not require the request or enclosing control to finish.
2. terminal_prefix_stored takes those same entry gates and actual prefix.
   Its next-step conclusion is an explicit match. Yielded gives True. Done,
   failed and blocked outcomes give Stored for their actual outcome state.
   It does not certify a successor from an unchecked yielded step.
3. node_prefix_stored uses the literal source requestNode control. It derives
   the initial Fields and Clean obligations. Good, SemanticReady, entry
   Stored and the actual finite Trace remain explicit premises.
4. edge_prefix_stored gives the corresponding literal requestEdge law with
   those same remaining gates. The ending control remains arbitrary.
5. initial_clean_prefix_stored starts from the literal partial checked
   initializer. It derives the initial Stored property from empty native
   thunk tables. The supplied equality cache need not be empty. Good,
   SemanticReady, Fields, Clean and the actual finite Trace remain gates.

The checked Trace contains an actual yielded step equation and the per-step
Inputs condition at each constructor. These laws concern those checked
prefixes. They do not turn every unchecked runtime step into a checked Trace.

Stored is conditional. For each returned native node or edge cell, a request
with an empty seen list and recursively finite ordinary operands must have a
recursively finite ordinary result whose height is at most each operand's
height. The certificate makes no such assertion when its antecedents fail.
It is distinct from the merge-context stored predicate and scoped caches.
It does not assert an unrestricted height bound for every native result.

## Stored-prefix proof review

The strong induction ranges over the actual finite prefix fuel. Its result
state and remaining control stay arbitrary. The proof derives the required
Good, semantic heap and field facts along that same trace.

The source work, enter and read branches preserve native memo tables before
the recursive call. Pure and fail controls cannot supply a yielded Trace
constructor. Clean excludes raw finishNode and finishEdge controls at entry.
The optional binder pending branch cannot supply a yielded constructor. Its
completed branch retains the memo table facts. Direct and ready memo request
branches use the actual selected cell or source body and a smaller prefix.
Absent and busy memo outcomes cannot supply the observed yielded constructor.

The cold node and edge branches start an actual owner cell. The bind-prefix
lemma splits the observed tail into two cases. If the body is unfinished,
the proof recurses on the actual shorter body prefix. If the observed prefix
already contains a completed body, it uses that actual completion. It then
handles either the prefix ending before the finish instruction, or the
actual executed finish followed by a shorter continuation prefix. Frames
retain the exact owner through the observed body.

For ordinary operand inputs, the proof derives the result certificate from
the existing finite-ordinary execution theorem. If that conditional input
gate fails, the certificate is vacuous after preservation of the previously
stored cells. The proof never asks the caller for a future pure trace,
future completed result, future certificate or completion supplier.

The terminal helper separately inspects one unchecked next step. Every
unchecked yielded case gives True. Terminal cases preserve the required
native table property. This distinction is present in the expanded public
signature, including the fully qualified Outcome.yielded constructor.

## Actual-returned narrowing contracts and proofs

The first two laws below are in SourcePruningNativeView. The third is in
SourcePruningEnumerationAction.

6. narrowAt_returned_stable starts from an actual successful narrowAt return.
   Increasing this native reader fuel preserves the exact returned value
   and heap. Ready, Available and closedness are not needed for this law.
   The proof exposes the actual successful reader outcome and applies the
   existing reader stability law. Pending or unresolved outcomes cannot
   produce the supplied successful narrowAt equation.
7. narrowAt_returned_control retains Ready, Available, closed input and the
   actual successful narrowAt equation. It derives Keeps, result Available,
   closedness, ordinary root form, physical Normal, all edges kept at the
   same key, and exact value-plus-heap replay for every native reader fuel.
   The proof obtains a sufficient fuel from the existing closed-input
   completion theorem. It aligns that completion and the actual successful
   return at the common sum of their fuels. Success injectivity identifies
   both the actual value and the actual heap. The caller supplies neither
   input Normal nor a historical makeNode or future-completion equation.
8. prepare_changed_returned_control starts from an actual successful
   Action.prepare return. It retains Ready, Available and closed input,
   both actual encodeNode equations, and unequal old and new handles.
   The proof extracts the actual outer-narrow return. Both the Mu bypass
   and the metadata.types bypass would return the original value. Either
   bypass would contradict the observed handle change. The proof therefore
   derives the actual narrowAt success and its result properties from law 7.

Normal means that makeNode of the value's complete resident outgoing edges
returns that exact value and heap. Ready plus Available is a separate gate.
The Ordinary conclusion here means only an Empty or node root. It is not the
recursive finite NodeDomain used by the native Stored certificates.

The kept-edge predicate and replay keep the same key, fits and admits.
The replay quantifier is native reader fuel. It is not enumeration worker
depth. The Action.prepare theorem describes its returned value and heap.
It makes no claim that the returned enumeration action ran or wrote a slot.
In the actual prepare definition, Empty selects rejection. A changed Empty
result does not justify a successful slot update. The theorem adds no such
claim and does not assume that its action is pure.

## Bounded old dependencies

The review acquired zero OLD whole or near-whole source files. It used 17
named contiguous cuts and three declaration locator cuts. Their exact union
is 182 distinct lines over 16 OLD modules. The largest acquired fraction of
one module is 27 of 70 lines in the trace-prefix bind module.

old-source-cut-ledger.json gives original paths, full-file hashes and sizes,
actual contiguous ranges, exact retained copies and copy hashes.
old-source-locator-ledger.json uses explicit disjoint actual_lines.
old-source-unions.json gives the combined distinct lines for each module.
Whole-file hashes and sizes were streamed as metadata; the review did not
acquire those OLD source bodies.

The cuts check the actual Trace and bind-prefix definitions, conditional
certificate and domain definitions, body and Clean gates, literal checked
initialization, reader Finished/stability gates, physical Normal, root-form
Ordinary, both outer-narrow bypasses, the actual Action.prepare branches,
and the existing closed-input completion contract.

## Validation authority and retained limits

The public tail has all eight complete expanded signatures and all eight
axiom reports. Every report lists only propext, Classical.choice and
Quot.sound. The reviewer read these reports and performed metadata checks.
The reviewer did not rerun Lean.

Root reports that the installed default and strict checks passed. Root also
reports a full Audit pass at 4750 jobs and 83011 dependency checks, plus a
public pass at 1209 checks and 116 definition prints. Root reports that all
835 native inputs and 549 prior protected inputs remain exact, and that the
Audit change adds two imports while preserving its complete prior body.
Root retained 12 compiler commands: nine passing commands and three repaired
failed candidates, with 27 input snapshots. Root reports source commits
f4521b07accf2da1ca440449f2e3310a2438a2e0 and
6dab391a2643f95181540773ba2420dc493024be. These are Root reports.

Root reports that the full public log is 4873867 bytes with SHA-256
3e41630b5aa7c368a9c5de39664d9409b7be3eb099a3cc4b0431650f5cd9a890.
Its prior 4860054 bytes are an exact prefix. This reviewer read the complete
new 13813-byte tail and did not acquire the old multi-megabyte public log.
root-reported-validation.json keeps that authority boundary explicit.

The prefix source V4 qualifies yielded constructors and removes redundant
alternatives. Root reports that the returned-control repair replaces an
unnecessary simpa with simp only. The final installed files remove their
uncompiled status lines. Root retains the failed intermediate candidates.
This reviewer found no further source or contract repair to request.

These laws do not establish original enumeration depth, a numeric strict-loss
chain bound, complete handle lineage across an entire caller, incoming
intersection control, Prepared Mu or Union bounds, whole-caller neutrality,
termination, finite global coverage, or Haskell correspondence. This review
establishes no Haskell defect or fix.

The earlier six-law narrowing public-review bundle remains frozen at
/tmp/mcfta-narrowing-public-review-20261030. This review does not modify it.
Its MANIFEST SHA-256 is
3e198a346b82971255621e781ac3ebc81cec5e9cd669502cdce5ef2523631e9b.
