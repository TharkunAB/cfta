# Independent arbitrary native prefix public review

Fresh source-only scope assigned by Root. Keep /tmp/mcfta-narrowing-public-review-20261030 frozen.
Write only within this directory. Root owns compiler, evaluator, native, Git, network, board and production work. Do not spawn.
Read all supplied new source, five public contracts and all private branches. Verify the exact supplied SHA before reuse.
At most TWO newly named OLD whole or near-whole sources. Name before acquisition. Prefer named exact cuts and frozen bundles. Record path, line, hash and cumulative unions.
The arbitrary finite Trace result must not require future pure completion. Terminal Yielded must give True, not Stored for its unchecked successor.
Wait for installed exact source and final public signatures/axioms from Root before final public-contract freeze.
A possible additional actual-returned narrowing bridge is separate source-only work until Root probes it. No Haskell defect or fix is established.
Preserve versions, complete payload inventory, incidents and full-read evidence. Freeze all files before handoff.
