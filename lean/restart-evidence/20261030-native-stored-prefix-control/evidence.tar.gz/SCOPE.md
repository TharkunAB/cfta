# Conditional native cache invariants at observed prefixes

Continue the full original-input goal; do not pause or reduce its scope.
Root owns production, compiler/evaluator/native/Git/network/board and packaging.
Check the frozen five-law arbitrary-prefix draft without a future return supplier.
Preserve per-step Inputs, Good/SemanticReady/Fields/Stored/Clean gates and actual terminal state effects.
Yielded in the terminal match gives True; its successor needs an extended actual checked Trace.
Keep all older proof/native inputs, public output, drafts, failures and root documents exact.
Every compiler command remains serial capped --mem 4G --time 5m with zero swap verified.
The sufficient original recursive capacity, global prefix coverage, caller transport and Haskell goals remain open.
No Haskell defect/fix is established. The goal backend still says blocked despite resumed instructions.

Also check the exact three-law actual-returned narrowing producer draft.
It must derive result Normal from actual success at a common internal bound.
Its prepare bridge must retain Empty rejection and leave action execution open.
The full source and public review covers all eight contracts.
