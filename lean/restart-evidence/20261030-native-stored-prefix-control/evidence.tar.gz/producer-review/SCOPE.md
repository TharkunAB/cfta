# Actual decoded ordinary normal-form producer

Root assigned this source-only task at 2026-10-30 22:48 CET.
Own only this fresh directory. No compiler, evaluator, native, Git, network, board, production or spawning.
At most TWO newly named OLD whole or near-whole modules. Name before reading. Ask Root for a third.
Retain exact source/copy hashes, literal cuts, locator rows and cumulative unions.
Allowed frozen reuse: prior normal-lineage and preparation bundles, with exact manifest identities.
Allowed exact NEW Root source: frozen Control SHA4770bbbe96ea80ff3fc0159c956cf6286cced6f796b3bc09d6656536b4425e2a and Lineage SHA2e4ba000e24b65d9d06e1af16964383c6ac6e83bb66f9685dbdd5e6e10cb4a53.
Find a real Normal producer at literal ordinary lookup/decode/encode entry to Action.prepare. Do not infer Normal from generic Ready/Available.
Inspect cached depth/free fields and actual provenance. Search existing producers first.
Do not add a future completion, coverage or model supplier. Keep source resets/intersection/Mu separate.
No Haskell defect or fix without an admitted actual execution. Freeze every payload and halt writes.
