from pathlib import Path
import hashlib
import json

r = Path(__file__).resolve().parent
acquisitions = json.loads((r / 'acquisitions.json').read_text())
reuses = json.loads((r / 'reuse-ledger.json').read_text())
unions = {}
for a in acquisitions + reuses:
    source = Path(a['source']).read_bytes()
    assert len(source) == a['source_bytes']
    assert len(source.splitlines()) == a['source_lines']
    assert hashlib.sha256(source).hexdigest() == a['source_sha256']
    copied = (r / a['copy']).read_bytes()
    selected = b''.join(source.splitlines(keepends=True)[i - 1] for i in a['actual_lines'])
    assert copied == selected
    assert hashlib.sha256(copied).hexdigest() == a['copy_sha256']
    if 'frozen_bundle' in a:
        manifest_bytes = (Path(a['frozen_bundle']) / 'MANIFEST.json').read_bytes()
        assert hashlib.sha256(manifest_bytes).hexdigest() == a['frozen_manifest_sha256']
        manifest = json.loads(manifest_bytes)
        entries = manifest.get('files', manifest.get('payloads'))
        row = next(x for x in entries if x['path'] == a['frozen_copy'])
        assert row['sha256'] == a['copy_sha256']
    if a['source'].startswith('/home/tritlo/Code/mcfta/'):
        u = unions.setdefault(a['source'], {'source_sha256': a['source_sha256'], 'source_lines': a['source_lines'], 'fresh': set(), 'reused': set()})
        u['reused' if 'frozen_bundle' in a else 'fresh'].update(a['actual_lines'])
rows = [{'source': p, 'source_sha256': u['source_sha256'], 'source_lines': u['source_lines'], 'fresh_lines': sorted(u['fresh']), 'reused_lines': sorted(u['reused']), 'union_lines': sorted(u['fresh'] | u['reused']), 'fresh_count': len(u['fresh']), 'union_count': len(u['fresh'] | u['reused'])} for p, u in sorted(unions.items())]
v1 = (r / 'SourcePruningNarrowReturnedControl-v1-UNCOMPILED.lean').read_bytes()
v2 = (r / 'SourcePruningNarrowReturnedControl-v2-UNCOMPILED.lean').read_bytes()
assert v2.startswith(v1)
result = {'status': 'pass', 'acquisitions': len(acquisitions), 'reuses': len(reuses), 'old_sources': len(rows), 'new_old_whole_modules': 0, 'near_whole_fresh': [a['source'] for a in rows if a['fresh_count'] >= .75 * a['source_lines']], 'compiler_commands': 0, 'V1_exact_prefix_of_V2': True}
assert not result['near_whole_fresh']
if (r / 'FROZEN').exists():
    assert json.loads((r / 'SOURCE-UNIONS.json').read_text()) == rows
    assert json.loads((r / 'source-verification.json').read_text()) == result
else:
    (r / 'SOURCE-UNIONS.json').write_text(json.dumps(rows, indent=2) + '\n')
    (r / 'source-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
