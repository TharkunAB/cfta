# Whole OLD source scope

Two slots were allowed. Zero were used.
All fresh OLD reads are bounded cuts or declaration locators.
SourcePruningNativeView177L is an explicitly authorized exact frozen whole reuse, not a fresh body acquisition.
The Root Control source165L is the explicitly supplied checked NEW source.
No third whole or near-whole request is needed.
