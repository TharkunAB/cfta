# Proposed public contracts

All three declarations are UNCOMPILED in this source-only bundle.
Root owns checking and integration. The source file retains each proof.

```lean
import MicroCFTA.SourcePruningNarrowControl
import MicroCFTA.MergedFreshOrdinaryColdReplay

namespace MicroCFTA.SourcePruningNativeView
open InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
local notation "Symbol" => SourcePruningTemplates.Symbol
attribute [local instance] FormulaExecutable.formulaDecidableEq
variable {Guard Key : Type}

theorem narrowAt_returned_stable [DecidableEq (EdgeKey Symbol Guard)]
    (fits : Key → Symbol → Bool) (admits : Key → Value Symbol Guard → Bool)
    (fuel extra : Nat) (key : Key) (value result : Value Symbol Guard) (before after : State Symbol Guard)
    (returned : narrowAt fits admits fuel key value before = .done result after) :
    narrowAt fits admits (fuel + extra) key value before = .done result after
```

```lean
import MicroCFTA.SourcePruningNarrowControl
import MicroCFTA.MergedFreshOrdinaryColdReplay

namespace MicroCFTA.SourcePruningNativeView
open InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
local notation "Symbol" => SourcePruningTemplates.Symbol
attribute [local instance] FormulaExecutable.formulaDecidableEq
variable {Guard Key : Type}

/-- Every actual successful filter keeps its exact result and heap at larger fuel. -/
theorem narrowAt_returned_stable [DecidableEq (EdgeKey Symbol Guard)]
    (fits : Key → Symbol → Bool) (admits : Key → Value Symbol Guard → Bool)
    (fuel extra : Nat) (key : Key) (value result : Value Symbol Guard) (before after : State Symbol Guard)
    (returned : narrowAt fits admits fuel key value before = .done result after) :
    narrowAt fits admits (fuel + extra) key value before = .done result after := by
  cases exposed : MergedFreshOrdinaryExposure.nodeEdges fuel value before with
  | done rows middle =>
      have extended := (MergedFreshOrdinaryColdReplay.nodeEdges_stable fuel extra value before
        (by simp only [exposed, MergedSourceExposure.Finished])).trans exposed
      simp only [narrowAt, exposed] at returned
      simpa only [narrowAt, extended] using returned
  | unresolved | pending | exhausted =>
      simp only [narrowAt, exposed] at returned
      cases returned

theorem narrowAt_returned_control [DecidableEq (EdgeKey Symbol Guard)]
    (fits : Key → Symbol → Bool) (admits : Key → Value Symbol Guard → Bool)
    (fuel : Nat) (key : Key) (value result : Value Symbol Guard) (before after : State Symbol Guard)
    (ready : SourceEqualityRequiredCache.Ready before)
    (available : Available before value) (closed : value.free = [])
    (returned : narrowAt fits admits fuel key value before = .done result after) :
    SourceEqualityRequiredCache.Keeps before after ∧
      Available after result ∧ result.free = [] ∧ SourceEqualityRequiredCache.Ordinary result ∧
      EqualityOrdinaryReadback.Normal after result ∧
      (∀ edge ∈ nodeEdges result, keeps fits admits key edge = true) ∧
      (∀ repeatFuel, narrowAt fits admits repeatFuel key result after = .done result after)
```

```lean
import MicroCFTA.SourcePruningNarrowControl
import MicroCFTA.MergedFreshOrdinaryColdReplay

namespace MicroCFTA.SourcePruningEnumerationAction
open InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
open SourcePruningNativeView SourcePruningEnumerationNodes
local notation "Symbol" => SourcePruningTemplates.Symbol
attribute [local instance] FormulaExecutable.formulaDecidableEq
variable {Guard EnumGuard Typing Key : Type}

theorem prepare_changed_returned_control [DecidableEq (EdgeKey Symbol Guard)]
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool)
    (admits : Key → Value Symbol Guard → Bool) (metadata : SourcePruningRecordTypes.Metadata Typing)
    (nativeFuel representativeFuel uv oldHandle newHandle : Nat) (scs : List EnumerationState.Suspended)
    (value result : Value Symbol Guard) (before after : State Symbol Guard)
    (action : Option (EnumerationState.EnumerateM Symbol EnumGuard Unit))
    (ready : SourceEqualityRequiredCache.Ready before)
    (available : Available before value) (closed : value.free = [])
    (returned : prepare holeKey fits admits metadata nativeFuel representativeFuel uv oldHandle scs value before =
      .done (result, action) after)
    (oldEncoded : encodeNode value = some oldHandle)
    (newEncoded : encodeNode result = some newHandle) (changed : newHandle ≠ oldHandle) :
    narrowAt fits admits nativeFuel (holeKey metadata.typing uv) value before = .done result after ∧
      SourceEqualityRequiredCache.Keeps before after ∧
      Available after result ∧ result.free = [] ∧ SourceEqualityRequiredCache.Ordinary result ∧
      EqualityOrdinaryReadback.Normal after result ∧
      (∀ edge ∈ nodeEdges result, keeps fits admits (holeKey metadata.typing uv) edge = true) ∧
      (∀ repeatFuel, narrowAt fits admits repeatFuel (holeKey metadata.typing uv) result after = .done result after)
```
