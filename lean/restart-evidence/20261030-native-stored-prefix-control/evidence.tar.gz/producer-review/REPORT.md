# Actual narrowing result normality

This bundle contains three UNCOMPILED source laws. Root owns all checks and integration. The laws use an actual successful filter result. They do not require input `EqualityOrdinaryReadback.Normal` or a historical `makeNode` observation. The last law connects that result to the actual changed-handle `Action.prepare` branch.

## Existing lookup and Ready gates

`SourcePruningEnumerationNodes.lookupNode` returns the complete stored payload. For a positive handle, it checks the issued key, the interner table entry, and the entry identity. It then returns `state.nodeRecords key`. It does not rebuild a value from the edge list.

`InternedRecordCoherence.NodeFields` constrains the actual stored node entry, literal edge-identity list, cached depth, and cached free names. `Coherent.nodes` supplies those fields for a stored record. `InternedProbeProvenance.Cached.nodes` supplies `Available` for stored records. `InternedEdgeResidency.Linked` supplies the complete resident edges. Cached depth and free names are therefore not the missing fields in the inspected interface.

`EqualityOrdinaryReadback.Normal state value` is the physical fixed-point equation `run (makeNode (nodeEdges value)) state = (value, state)`. `MergedNormalReadback.normal_resident` uses an existing Normal premise to obtain the canonical surviving edge list. Coherence alone relates the key to the literal edge list. It does not assert that this list already has canonical order and no duplicate rows.

The inspected Ready expansion adds live edges, flat union records, nonempty records, nonempty union members, and Mu profile/free-name/depth properties. Its generic cache-validity fields do not add an ordinary-row canonical-list condition. The name `InternedStoredMuOrigins.Normal` does not mean that every resident ordinary value satisfies `EqualityOrdinaryReadback.Normal`.

No direct lookup-to-physical-Normal proof was found. No formal countermodel was constructed. No actual runtime failure was executed. The missing row-list condition is `canonicalEdges (surviving (nodeEdges value)) = nodeEdges value`. A direct proof must supply that condition, or a reachable constructor-production observation that supplies it. This review does not prove that condition alone is a sufficient contract. A weak interface is not evidence of a Haskell defect.

## Proposed actual-success route

`SourcePruningNarrowReturnedControl-v2-UNCOMPILED.lean` contains these public declarations:

1. `SourcePruningNativeView.narrowAt_returned_stable` preserves the exact returned value and heap at every larger fuel. Its only substantive premise is the actual successful `narrowAt` observation. It uses the existing `MergedFreshOrdinaryColdReplay.nodeEdges_stable` law. It needs no Ready, Available, closedness, or Normal premise.
2. `SourcePruningNativeView.narrowAt_returned_control` assumes actual success, Ready input heap, Available input value, and closed input value. It gives the actual result a `Keeps` lineage, Available, closedness, ordinary shape, physical Normal, retained rows, and exact same-key replay at any fuel. The proof obtains an existing closed completion witness internally. It compares that witness with the actual observation at a common larger fuel. It does not request a future completion witness from the caller.
3. `SourcePruningEnumerationAction.prepare_changed_returned_control` uses the literal actual `prepare` observation, actual old/new encodings, and their difference. It derives that the branch executed `narrowAt`, then applies the second law. The changed encodings exclude both the Mu bypass and the metadata-type bypass inside the proof. The caller supplies no extra branch flag.

The full headers, namespace context, imports, local notation, local instance attribute, and variables are retained in PUBLIC-CONTRACTS.md and PUBLIC-CONTRACTS.json. The source file retains all proofs. V1 is the exact first 59 lines of V2. V2 adds the prepare bridge. Neither version has been compiled or evaluated by this owner.

## Exact action boundary

The third declaration describes the native value and heap returned by `prepare`. It does not assert that the returned enumeration action has executed or that a stored slot has changed. If the narrowed value is Empty, the actual `prepare` source returns a rejection action. A changed encoded handle can be Empty. The law therefore does not assert an unconditional slot write. For a changed nonempty encoded result, the source selects the representative/setValue branch, but this bundle does not export an execution theorem for that branch.

## Capacity implication and remaining work

After an actual successful filter, the result has the required physical Normal premise for the earlier checked ordinary-row lineage laws. A later changed filter along a preserved ordinary lineage can then use those laws. Keys may vary. This addresses the local producer gate without silently deriving physical Normal from Ready.

The first filter after a source reset can normalize a noncanonical physical source. Charge that step separately from strict row loss. A bound on the number of source resets would bound these normalization steps. This bundle supplies no such global reset bound.

Incoming and dispatch intersections, selected Mu unfolding, and Prepared Mu/Union reconstruction remain separate source-reset cases. They can replace the row source. This bundle does not cover those resets, all earlier alternatives, staged child calls, recursive whole-execution capacity, finite global coverage, or public APIs. It supplies no future trace, Complete predicate, coverage premise, chosen-target-only supplier, or model-level replacement worker.

The full original-input, both-worker, public-adapter, Haskell-correspondence goal remains open. This task establishes no Haskell defect, fix, or candidate. No Haskell source was changed.

## Evidence and scope

The only supplied checked NEW source acquired here is Root's frozen SourcePruningNarrowControl.lean, SHA 4770bbbe96ea80ff3fc0159c956cf6286cced6f796b3bc09d6656536b4425e2a. The task explicitly allowed that source. Its exact copy and provider manifest are retained. The current checked Lineage source was not acquired.

The prior frozen normal-lineage bundle has manifest SHA ad65d74d6f2fe0d7cdc8c71ee50a6bf10e93c7ede6bbac008b7f5c7e0913d638. The frozen preparation bundle has manifest SHA 013c69246cd33f1eaf77cf628fa90b7859ab368d39b5837879f74cc7fe6c3760. Exact reused NativeView and Action cuts are bound to the latter manifest. Both provider manifests are retained.

All fresh OLD reads are exact bounded cuts or retained locators. Zero of two new OLD whole-module slots were used. SOURCE-UNIONS.json separates fresh and reused line unions. acquisitions.json and reuse-ledger.json retain exact source hashes and copied ranges. verify.py rechecks their bytes. INCIDENTS.md records two metadata/locator lookup failures.

No compiler, evaluator, native execution, Git operation, network request, board operation, production edit, or sub-agent was used by this owner. Root may independently check the supplied immutable drafts after this source-only review. The bundle status remains UNCOMPILED.
