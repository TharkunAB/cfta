# Exact source cuts

All whole-source hashes appear in SOURCE-PINS.json. Line numbers are one-based.

## lean/MicroCFTA/EnumerationState.lean:23-73

```text
23: /-- Use the source-equivalent checked trie descent. -/
24: abbrev descendScs := @EqualityTrie.descendScs Nat
25: 
26: /-- Every represented path must reach the assigned equality variable. -/
27: def Suspended.Holds (assignment : Nat → Term Symbol) (term : Term Symbol) (sc : Suspended) : Prop :=
28:   ∀ path ∈ EqualityTrie.fromPathTrie sc.trie, term.atPath path = some (assignment sc.var)
29: 
30: /-- Source UVar states. A missing node is a pure equality variable. -/
31: inductive UVarValue (Symbol : Type) where
32:   | unenumerated : Option Nat → List Suspended → UVarValue Symbol
33:   | enumerated : Fragment Symbol → UVarValue Symbol
34:   | eliminated
35: 
36: /-- One graph edge and its two kinds of constraints. -/
37: structure Edge (Symbol Guard : Type) where
38:   symbol : Symbol
39:   children : List Nat
40:   equalities : List EqualityTrie.Trie
41:   residual : Option Guard
42: 
43: /-- The recursive case supplies the unfolded outer body. -/
44: inductive Node (Symbol Guard : Type) where
45:   | empty
46:   | alternatives : List (Edge Symbol Guard) → Node Symbol Guard
47:   | recursive : Nat → Node Symbol Guard
48:   | unresolved : Nat → Node Symbol Guard
49: 
50: /-- Graph primitives supplied by the interned-graph implementation. -/
51: structure Graph (Symbol Guard : Type) where
52:   node : Nat → Node Symbol Guard
53:   intersect : Nat → Nat → Nat
54: 
55: /-- Recursion keys omit equality-variable identities. -/
56: structure RecursionKey where
57:   node : Nat
58:   tries : List (List (List Nat))
59:   deriving DecidableEq
60: 
61: /-- Canonical path sets represent the source's set of suspended tries. -/
62: def recursionKey (node : Nat) (scs : List Suspended) : RecursionKey :=
63:   ⟨node, (scs.map fun sc => EqualityTrie.fromPathTrie sc.trie).eraseDups.mergeSort
64:     (fun left right => compare left right != .gt)⟩
65: 
66: /-- Mutable state copied separately for each nondeterministic branch. -/
67: structure State (Symbol Guard : Type) where
68:   counter : Nat
69:   representatives : UnionFind.Forest
70:   values : List (UVarValue Symbol)
71:   obligations : List (Guard × Fragment Symbol)
72:   recursionAncestry : Nat → List RecursionKey
73:   expansionAncestry : List RecursionKey
```

## lean/MicroCFTA/SourcePruningEnumerationParkedLanguage.lean:19-34

```text
19: theorem clear_satisfies
20:     (language : NodeLanguage Symbol) (meaning : EnumGuard → Term Symbol → Prop)
21:     (assignment : Nat → Term Symbol) (before after : State Symbol EnumGuard)
22:     (uv : Nat) (node : Option Nat) (scs : List Suspended)
23:     (stored : before.values[uv]? = some (.unenumerated node scs))
24:     (written : Success (setValue uv (.unenumerated node [])) before () after) :
25:     Satisfies language meaning assignment before ↔
26:       Satisfies language meaning assignment after ∧
27:         ∀ sc ∈ scs, Suspended.Holds assignment (assignment uv) sc := by
28:   have shape := (EnumerationDriver.modify_success _ before after).mp written
29:   have bound : uv < before.values.length := (List.getElem?_eq_some_iff.mp stored).1
30:   have oldSlot : heap language before.values uv = slot language (.unenumerated node scs) := by
31:     simp only [heap, stored, Option.getD_some]
32:   have oldMeaning : slotSatisfies assignment uv (heap language before.values uv) ↔
33:       permits (node.map language) (assignment uv) ∧
34:         ∀ sc ∈ scs, Suspended.Holds assignment (assignment uv) sc := by
```

## lean/MicroCFTA/SourcePruningEnumerationParkedLanguage.lean:67-82

```text
67: /-- An actual repeated check drops exactly the selected bucket's suspended restrictions. -/
68: theorem checkRepeated_true_satisfies
69:     (heap : InternedConstructorTemplates.State Symbol NativeGuard)
70:     (language : NodeLanguage Symbol) (meaning : EnumGuard → Term Symbol → Prop)
71:     (assignment : Nat → Term Symbol) (fuel uv handle : Nat) (scs : List Suspended)
72:     (before after : State Symbol EnumGuard)
73:     (ready : EnumerationDriver.Ready uv before)
74:     (stored : before.values[uv]? = some (.unenumerated (some handle) scs))
75:     (observed : Success (checkRepeated heap fuel uv handle scs) before true after) :
76:     Satisfies language meaning assignment before ↔
77:       Satisfies language meaning assignment after ∧
78:         ∀ sc ∈ scs, Suspended.Holds assignment (assignment uv) sc := by
79:   cases decoded : lookupNode heap handle with
80:   | none =>
81:       have impossible : Success (failure .unresolvedReference) before true after := by
82:         simpa only [checkRepeated, decoded] using observed
```

## lean/MicroCFTA/SourcePruningEnumerationRecursion.lean:16-30

```text
16: /-- Check the actual native boundary and clear the bucket only for a repeated recursion key. -/
17: def checkRepeated (heap : InternedConstructorTemplates.State Symbol NativeGuard)
18:     (fuel uv handle : Nat) (scs : List Suspended) : EnumerateM Symbol EnumGuard Bool := do
19:   match lookupNode heap handle with
20:   | none => failure .unresolvedReference
21:   | some value =>
22:       if MergedOrdinaryHeight.recursiveBoundary value then
23:         let root ← representative fuel uv
24:         let current : EnumerationState.State Symbol EnumGuard ← get
25:         if recursionKey handle scs ∈ current.recursionAncestry root then
26:           setValue root (.unenumerated (some handle) [])
27:           pure true
28:         else pure false
29:       else pure false
30: 
```

## lean/MicroCFTA/SourcePruningEnumerationSelection.lean:83-108

```text
83:   | unenumerated node scs =>
84:     obtain ⟨slot, stored⟩ := List.mem_iff_getElem?.mp member
85:     exact unblocked_avoids before roots paths counts uv root unblocked slot node scs stored
86: 
87: /-- Actual native selection derives the absence of incoming references at the same cache. -/
88: theorem incoming
89:     (heap : InternedConstructorTemplates.State Symbol NativeGuard)
90:     (before : EnumerationExpandableIndex.Cached Symbol EnumGuard)
91:     (preference : List Nat → Option Nat) (uv : Nat) (safe : Safe before.core)
92:     (roots : Nat → Nat) (paths : Roots before.core.representatives roots)
93:     (counts : EnumerationCanonicalWaiting.Correct roots before.core.values before.waiting)
94:     (flags : ∀ slot, SourcePruningEnumerationNativeIndex.candidate heap
95:       ((before.core.values[slot]?).getD .eliminated) = some (before.expandable slot))
96:     (selected : EnumerationPureSelection.next preference before = .expand uv) :
97:     EnumerationReferences.IncomingAvoid uv before.core :=
98:   unblocked_incoming before roots paths counts uv
99:     (ready heap before preference uv safe roots paths counts flags selected).root
100:     (offered before preference uv selected).2.2
101: 
102: /-- A selected native candidate has its actual closed available pending value. -/
103: theorem realized
104:     (heap : InternedConstructorTemplates.State Symbol NativeGuard)
105:     (before : EnumerationExpandableIndex.Cached Symbol EnumGuard)
106:     (preference : List Nat → Option Nat) (uv : Nat)
107:     (aligned : before.core.counter = before.core.values.length)
108:     (pending : PendingRealized heap before.core)
```

## lean/MicroCFTA/SourcePruningEnumerationSelectedClearCycles.lean:49-76

```text
49: /-- An actual selected clear retains every bucket in a closed dependency set. -/
50: theorem selected_clear_keeps_closed_references
51:     (heap : InternedConstructorTemplates.State Symbol NativeGuard)
52:     (before : EnumerationExpandableIndex.Cached Symbol EnumGuard)
53:     (preference : List Nat → Option Nat) (uv : Nat) (roots : Nat → Nat)
54:     (safe : Safe before.core) (paths : Roots before.core.representatives roots)
55:     (counts : EnumerationCanonicalWaiting.Correct roots before.core.values before.waiting)
56:     (flags : ∀ slot, SourcePruningEnumerationNativeIndex.candidate heap
57:       ((before.core.values[slot]?).getD .eliminated) = some (before.expandable slot))
58:     (selected : EnumerationPureSelection.next preference before = .expand uv)
59:     (fuel handle : Nat) (scs : List Suspended) (after : State Symbol EnumGuard)
60:     (observed : Success (checkRepeated heap fuel uv handle scs) before.core true after)
61:     (vertices : List Nat)
62:     (cycle : ∀ target ∈ vertices, ∃ source ∈ vertices,
63:       ∃ value, before.core.values[source]? = some value ∧
64:         ∃ sc ∈ references value, UnionFind.SameClass before.core.representatives target sc.var) :
65:     (∀ vertex ∈ vertices, after.values[vertex]? = before.core.values[vertex]?) ∧
66:     (∀ left right, UnionFind.SameClass after.representatives left right ↔
67:       UnionFind.SameClass before.core.representatives left right) ∧
68:     (∀ (language : NodeLanguage Symbol) (assignment : Nat → Term Symbol) vertex, vertex ∈ vertices →
69:       (slotSatisfies assignment vertex (EnumerationCorrectness.heap language after.values vertex) ↔
70:         slotSatisfies assignment vertex (EnumerationCorrectness.heap language before.core.values vertex))) := by
71:   have ready := SourcePruningEnumerationSelection.ready heap before preference uv safe roots paths counts flags selected
72:   have incoming := SourcePruningEnumerationSelection.incoming heap before preference uv safe roots paths counts flags selected
73:   have separate : ∀ vertex ∈ vertices, vertex ≠ uv := by
74:     intro vertex member same
75:     subst vertex
76:     obtain ⟨source, _sourceMember, value, stored, sc, listed, alias⟩ := cycle uv member
```

## lean/MicroCFTA/SourcePruningEnumerationSelectedClearCycles.lean:96-111

```text
96: /-- Proper suspended paths cannot form a finite closed cycle in one assignment. -/
97: theorem proper_closed_references_no_assignment
98:     (language : NodeLanguage Symbol) (meaning : EnumGuard → Term Symbol → Prop)
99:     (state : State Symbol EnumGuard) (vertices : List Nat) (nonempty : vertices ≠ [])
100:     (cycle : ∀ target ∈ vertices, ∃ source ∈ vertices, ∃ node scs,
101:       state.values[source]? = some (.unenumerated node scs) ∧
102:       ∃ sc ∈ scs, ∃ path ∈ EqualityTrie.fromPathTrie sc.trie,
103:         path ≠ [] ∧ UnionFind.SameClass state.representatives target sc.var) :
104:     ¬ ∃ assignment, Satisfies language meaning assignment state := by
105:   rintro ⟨assignment, satisfied⟩
106:   have step : ∀ target ∈ vertices, ∃ source ∈ vertices,
107:       (assignment target).height < (assignment source).height := by
108:     intro target member
109:     obtain ⟨source, sourceMember, node, scs, stored, sc, listed, path, pathMember, proper, alias⟩ := cycle target member
110:     have bucket : permits (node.map language) (assignment source) ∧
111:         ∀ suspended ∈ scs, Suspended.Holds assignment (assignment source) suspended := by
```

## lean/MicroCFTA/EnumerationAssignment.lean:79-87

```text
79: /-- A finite dependency ordering constructs a solution of every completed stored equation. -/
80: theorem stratified_assignment (state : State Symbol Guard) (safe : Safe state) (level : Nat → Nat) (frontier : Nat)
81:     (stratified : Stratified state level frontier) (fallback : Term Symbol) (language : NodeLanguage Symbol)
82:     (free : ∀ (uv : Nat) (node : Option Nat) (scs : List Suspended), state.values[uv]? = some (.unenumerated node scs) → node = none ∧ scs = []) :
83:     ∃ assignment : Nat → Term Symbol, Fragments.stateSatisfies state.representatives (heap language state.values) assignment := by
84:   obtain ⟨roots, paths⟩ := roots_exist state.representatives safe.1.total
85:   let assignment := evaluateSlots state.values roots fallback (frontier + 1)
86:   refine ⟨assignment, ?_, ?_⟩
87:   · intro left right same
```

## lean/MicroCFTA/SourcePruningEnumerationResourceHistoryMeaning.lean:163-184

```text
163: /-- A discharged path restores initial assignment meaning under only its recorded own-arity annotations. -/
164: theorem ResourceHistoryWithArity.sound
165:     (history : ResourceHistoryWithArity holeKey fits admits graph templates checkEmpty edgesOf stop order
166:       formulas solver workFuel recursiveFuel inventory caller memos metadata before seed ceiling next output)
167:     (actualNext : next = SourcePruningEnumerationRestart.decision stop order metadata before)
168:     (canonical : Canonical before.core)
169:     (discharged : SourcePruningEnumerationRendering.Discharged output.cache.core) :
170:     ∀ (ambient : InternedGuardedLanguage.Env Symbol) (assignment : Nat → Language.Term Symbol),
171:       Satisfies (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
172:         ambient output.caller.checked.native.machine.heap)
173:         (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
174:         assignment output.cache.core →
175:       Satisfies (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
176:         ambient caller.checked.native.machine.heap)
177:         (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
178:         assignment before.core := by
179:   revert actualNext canonical discharged
180:   induction history with
181:   | stopped _admission =>
182:       intro _actualNext _canonical _discharged ambient assignment satisfied
183:       exact satisfied
184:   | done _admission =>
```

## lean/MicroCFTA/SourceSynthesisCurrentUniverseOwnership.lean:285-312

```text
285: /-- The actual current source heap has no Mu or one resident replayable universe owner. -/
286: theorem current_build_single_universe
287:     [DecidableEq (EdgeKey Symbol Guard)]
288:     (lib : Library) (query : Query) (signed : Int) (whole : Expression)
289:     (accepted : SourceSynthesisCurrentConstruction.firstOrderRaw lib query signed = .ok whole)
290:     (rootValue : Value Symbol Guard) (heap : State Symbol Guard)
291:     (built : InternedFreshOrdinaryConstruction.build (ordinarySymbols whole) [] empty =
292:       .done rootValue heap) :
293:     (∀ (key : InternedBinderProtocol.NodeKey)
294:       (entry : Cache.Interned InternedBinderProtocol.NodeKey)
295:       (body depth ordinary : Value Symbol Guard),
296:       heap.nodeRecords key ≠ some (.mu entry body depth ordinary)) ∨
297:     ∃ (entry : Cache.Interned InternedBinderProtocol.NodeKey)
298:       (body depth ordinary : Value Symbol Guard),
299:       heap.nodeRecords (muKey depth ordinary) = some (.mu entry body depth ordinary) ∧
300:       Available heap (.mu entry body depth ordinary) ∧
301:       (Value.mu entry body depth ordinary).free = [] ∧
302:       (∀ later : State Symbol Guard, Grows heap later →
303:         InternedFreshOrdinaryConstruction.build
304:           (ordinarySymbols ((SourceSynthesisCurrentContext.context lib query).types)) [] later =
305:             .done (.mu entry body depth ordinary) later) ∧
306:       (∀ (key : InternedBinderProtocol.NodeKey)
307:         (other : Cache.Interned InternedBinderProtocol.NodeKey)
308:         (otherBody otherDepth otherOrdinary : Value Symbol Guard),
309:         heap.nodeRecords key = some (.mu other otherBody otherDepth otherOrdinary) →
310:           Value.mu other otherBody otherDepth otherOrdinary = .mu entry body depth ordinary) := by
311:   classical
312:   by_cases someMu : ∃ (key : NodeKey) (entry : Interned NodeKey)
```

## lean/MicroCFTA/SourceSynthesisCurrentInitialModelWork.lean:79-99

```text
79:               Projection literal Prod.fst term program ∧ toProgram literal Prod.fst term = program ∧
80:               program.components = signed.toNat ∧ assignment 0 = term ∧
81:               Satisfies (SourcePruningEnumerationNativeLanguage.handles holds ambient heap)
82:                 residualMeaning assignment startup.core ∧
83:               (∀ group ∈ metadata.pending, SourcePruningResume.Refutes assignment group) ∧
84:               SourcePruningEnumerationOrigins.AssignmentOrigins term startup.core.counter assignment ∧
85:               pendingSize startup.core assignment = NumberedTerms.size term ∧
86:               pendingSize startup.core assignment ≤ NumberedTerms.size term ∧
87:               SourcePruningEnumerationNativeWork.work (NumberedTerms.size term) startup assignment =
88:                 (NumberedTerms.size term + 1) * NumberedTerms.size term +
89:                   (if MergedOrdinaryHeight.recursiveBoundary value then 0 else 1) := by
90:   obtain ⟨fields, cache, value, heap, built, prepared, conjunctionFields, context,
91:       facts, available, roles, growth, issued, origins, identity, emptySame, emptyReady, closed, original⟩ :=
92:     SourceSynthesisCurrentCallerInitialization.accepted lib query signed expression returned
93:       width initial valid formulas solver
94:   obtain ⟨handle, encoded, decoded, startupPacket, models⟩ :=
95:     SourcePruningEnumerationRecursive.initial_packet_models_origins_work formulas solver
96:       (inventory (ordinarySymbols expression) value heap built) (caller width cache heap) globals
97:       metadata value context available closed emptyPending
98:   have mappedBuilt : InternedFreshOrdinaryConstruction.build (mapSyntax literal expression)
99:       [] empty = .done value heap := by
```

## cfta/src/Data/CFTA/Enumeration.hs:275-293

```text
275: -}
276: data RecursionKey = RecursionKey
277:     { recursiveNode :: !NodeId
278:     , suspendedTries :: !(HashSet.HashSet PathTrie)
279:     }
280:     deriving (Eq, Show)
281: 
282: -- | Hash the two fields in order, as the hash of a pair does.
283: instance Hashable RecursionKey where
284:     hashWithSalt salt (RecursionKey node tries) = salt `hashWithSalt` node `hashWithSalt` tries
285: 
286: -- | The key of a recursive node with its suspended constraints.
287: recursionKey :: Node symbol -> Seq SuspendedConstraint -> RecursionKey
288: recursionKey n scs =
289:     RecursionKey
290:         { recursiveNode = nodeIdentity n
291:         , suspendedTries = HashSet.fromList $ map scGetPathTrie $ Foldable.toList scs
292:         }
293: 
```

## cfta/src/Data/CFTA/Enumeration.hs:998-1017

```text
998:                 (should_prune, ost') <- oracle ost uv (Right narrowed)
999:                 if should_prune then mzero else continue ost'
1000:          in do
1001:                 UVarUnenumerated (Just n) scs <- getUVarValue uv
1002:                 case n of
1003:                     _ | recursiveBoundary n -> do
1004:                         uv' <- getUVarRepresentative uv
1005:                         ancestry <- gets $ IntMap.findWithDefault HashSet.empty (uvarToInt uv') . _recursionAncestry
1006:                         if HashSet.member (recursionKey n scs) ancestry
1007:                             then do
1008:                                 -- The expansion of this node with these paths led to it
1009:                                 -- again, so each further expansion repeats the last one.
1010:                                 -- Enumeration stops here, as at an unconstrained 'Mu'.
1011:                                 setUVarValue uv' (UVarUnenumerated (Just n) Sequence.Empty)
1012:                                 enumerateUntil' stop narrow expandNode ost order oracle
1013:                             else expand n scs
1014:                     _ -> expand n scs
1015: 
1016: ---------------------
1017: -------- Expanding an enumerated term fragment into a term
```

## cfta/src/Data/CFTA/Enumeration.hs:1530-1551

```text
1530:             pending <- mapM (\(constraint, fragment) -> (constraint,) <$> expandTermFragWith marker fragment) obligations
1531:             pure (local, OrderedComplete (term, pending))
1532:         ExpansionNext uv -> do
1533:             UVarUnenumerated (Just node) scs <- getUVarValue uv
1534:             let prepare = do
1535:                     (reject, updated) <- orderedOracle config global local uv (Right node)
1536:                     guard (not reject)
1537:                     pure (updated, OrderedPrepared uv)
1538:             if recursiveBoundary node
1539:                 then do
1540:                     representative <- getUVarRepresentative uv
1541:                     ancestry <- gets $ IntMap.findWithDefault HashSet.empty (uvarToInt representative) . _recursionAncestry
1542:                     if HashSet.member (recursionKey node scs) ancestry
1543:                         then do
1544:                             setUVarValue representative (UVarUnenumerated (Just node) Sequence.Empty)
1545:                             orderedPrepare marker config global local
1546:                         else prepare
1547:                 else prepare
1548: 
1549: {- | Expand one prepared hole. This action takes no global, config, or local
1550: state argument. Its raw CPS tail retains only equality-enumeration state.
1551: -}
```

## cfta/src/Data/CFTA/Enumeration.hs:596-608

```text
596: one conjunction, so a class that needs a conjunction again closes the fixed
597: point.
598: 
599: Emptiness is not decidable for every automaton with path equalities, so the
600: check cannot find every empty node. It finds a class whose intersection needs
601: the node again, with no other way to a term.
602: -}
603: {-# INLINEABLE provablyEmpty #-}
604: provablyEmpty :: forall symbol. (Hashable symbol, Typeable symbol) => Node symbol -> Bool
605: provablyEmpty = memoTypeableWith @symbol provablyEmptyCache $ \start ->
606:     -- For each conjunction that the check reads, the requirements of each edge tuple.
607:     let rows = explore emptinessBudget Map.empty [[start]]
608:      in null (freeVars start) && not (canAccept rows (grow rows Set.empty) [start])
```
