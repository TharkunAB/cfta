from pathlib import Path
import ast
import hashlib
import json
import re
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
control = base / '20261117-warm-no-new-mu-publication-control-draft'
work = base / '20261117-warm-no-new-mu-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this controller.'
archive_control = base / '20261117-warm-no-new-mu-checkpoint-control-draft'
assert Path(__file__).read_bytes() == (archive_control / 'prepare-checkpoint-controls.py').read_bytes()
runtime = base / '20261117-warm-no-new-mu-publication'
assert runtime.is_dir(), 'The checked publication must exist.'
prior_run = base / '20261117-warm-semantic-finish-publication'
prior_archive = base / '20261117-warm-semantic-finish-checkpoint'
prior_commit = 'a59893a37d6c30b25a92f6ac499e5115057b9383'
prior_manifest = 'f75f1f825214e287d7d3957c8295408d90386072c77da65e357034e5feb52826'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
bound = set()


def verify(path, record):
    data = path.read_bytes()
    digest = record['sha256'] if isinstance(record, dict) else record
    assert sha(data) == digest, str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data


def items(value):
    if isinstance(value, dict):
        return list(value.items())
    return [(item['path'], item) for item in value]


def manifest_records(manifest):
    if 'artifacts' in manifest:
        return [(item['path'], item) for item in manifest['artifacts']]
    return items(manifest['files'])


for name, record in json.loads((control / 'MANIFEST.json').read_text())['files'].items():
    verify(control / name, record)
bound.add(control / 'MANIFEST.json')
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage = json.loads(stage_path.read_text())
assert stage == json.loads((control / 'EXPECTED-STAGE.json').read_text())
assert stage['prior_checkpoint'] == prior_commit
expected = stage['components']
overrides = {audit_name: str((work / 'Audit-BEFORE.lean.txt').relative_to(root))}
assert stage['baseline_overrides'] == overrides
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'],
        stage['independent_reports']) == (6267, 5267, 698, 293)
assert (stage['new_modules'], stage['new_public_theorems'], stage['new_private_helpers'],
        stage['new_theorem_declarations'], stage['new_prop_definitions']) == (3, 3, 46, 49, 4)
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (3, 489, 492)
baseline_path = work / 'baseline-source-pins.json'
baseline = json.loads(baseline_path.read_text())
assert len(baseline) == 6264 and len(expected) == 3
new_names = {item['source_path'] for item in expected}
assert len(new_names) == 3 and not new_names.intersection(baseline)
current = sorted((root / 'lean/MicroCFTA').glob('*.lean'))
assert {str(path.relative_to(root)) for path in current} == set(baseline) | new_names


def prior_bytes(name):
    path = root / overrides.get(name, name)
    bound.add(path)
    return path.read_bytes()


def verify_prior_pins(path):
    bound.add(path)
    for name, record in items(json.loads(path.read_text())):
        data = prior_bytes(name)
        digest = record['sha256'] if isinstance(record, dict) else record
        assert sha(data) == digest, name
        if isinstance(record, dict) and 'bytes' in record:
            assert len(data) == record['bytes'], name


for name, digest in baseline.items():
    assert sha(prior_bytes(name)) == digest, name
assert len(set(baseline) - {audit_name}) == 6263
old_audit = prior_bytes(audit_name)
assert len(old_audit) == stage['old_audit_bytes'] == 429545
assert sha(old_audit) == stage['old_audit_sha256'] == '12d45e499288075d0cb51f1d3f2243c0a88ae853cad71f6a7bf1782239ab1d00'
assert old_audit.count(b'#print axioms ') == 695
verify(root / owner_name, owner_sha)
prior = json.loads((prior_run / 'checked.json').read_text())
assert (prior['source_files'], prior['independent_reports'],
        prior['resource_and_component_probes']) == (6264, 290, 489)
assert len(prior['checks']) == 5 and all(item['exit'] == 0 and not item['diagnostics']
    and not item['sorryAx'] and not item['nonstandard_axioms'] for item in prior['checks'])
verify(prior_archive / 'manifest.json', prior_manifest)
verify_prior_pins(prior_run / 'source-pins.json')
bound.add(prior_run / 'checked.json')
def verify_candidate_pin(name, record):
    verify(root / name, record)


private_control = base / '20261117-warm-no-new-mu-alias-repair-check-control-draft'
selected = json.loads((private_control / 'SELECTION.json').read_text())
private_run = base / selected['runtime']
assert stage['private_run'] == selected['runtime']
checked_path = private_run / 'checked.json'
checked = json.loads(checked_path.read_text())
receipt_path = work / 'PRIVATE-CHECK-VERIFIED.json'
receipt = json.loads(receipt_path.read_text())
assert receipt['actual_session'] == 50959 and receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
assert receipt['checks'] == checked['checks'] and checked['three_modules_checked']
assert len(checked['checks']) == 3 and all(checked['passed'])
assert checked['actual_public_axiom_reports'] == 3 and checked['actual_definition_declaration_checks'] == 0
assert checked['all_three_selected_first_headers_exact']
assert checked['private_helpers_compiled_transitively'] == 46
assert checked['private_prop_carrier_declaration_checks'] == 0
assert checked['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
verify_prior_pins(private_run / 'source-pins.json')
bound.update([checked_path, private_run / 'results.json', receipt_path])
for item in checked['checks']:
    bound.add(private_run / (item['name'] + '.txt'))
seen = set()
normal_sources = []
probes = []
public_names = []
definition_names = []
for item, chosen in zip(expected, selected['components']):
    for key, value in chosen.items():
        assert item[key] == value, (item['module'], key)
    packet = base / item['packet']
    manifest_path = packet / 'MANIFEST.json'
    verify(manifest_path, item['manifest_sha256'])
    if packet not in seen:
        seen.add(packet)
        for name, record in manifest_records(json.loads(manifest_path.read_text())):
            verify(packet / name, record)
        for pin_file in ['SOURCE-PINS.json', 'ADDITIONAL-SOURCE-PINS.json']:
            if (packet / pin_file).exists():
                for name, record in items(json.loads((packet / pin_file).read_text())):
                    verify_candidate_pin(name, record)
        if (packet / 'DEPENDENCY-PINS.json').exists():
            for name, record in items(json.loads((packet / 'DEPENDENCY-PINS.json').read_text())):
                verify(root / name, record)
                if isinstance(record, dict) and 'packet_manifest_sha256' in record:
                    verify((root / name).parent / 'MANIFEST.json', record['packet_manifest_sha256'])
        if (packet / 'FAILURE-PINS.json').exists():
            for record in json.loads((packet / 'FAILURE-PINS.json').read_text())['artifacts']:
                verify(root / record['path'], record)
    raw = verify(packet / item['source'], item['raw_sha256'])
    assert raw == (root / item['source_path']).read_bytes() and len(raw) == item['raw_bytes']
    header = verify(packet / item['header'], item['header_sha256'])
    assert header.rstrip(b'\n') in raw
    probe = verify(packet / item['probe'], item['probe_sha256'])
    assert (private_run / 'source/MicroCFTA' / (item['module'] + '.lean')).read_bytes() == raw + b'\n' + probe
    assert re.findall(r'^private theorem (\w+)', raw.decode(), re.M) == item['new_private_helper_names']
    assert re.findall(r'^private def (\w+)', raw.decode(), re.M) == item['new_private_prop_names']
    assert re.findall(r'^#print axioms (\S+)', probe.decode(), re.M) == item['names']
    assert probe.count(b'#print axioms ') == item['expected_axiom_reports']
    assert probe.count(b'#check ') == item['expected_declaration_checks']
    normal_sources.append(raw)
    probes.append(probe)
    public_names.extend(item['names'])
assert len(public_names) == len(set(public_names)) == 3 and not definition_names
assert sum(len(item['new_private_helper_names']) for item in expected) == 46
assert sum(len(item['new_private_prop_names']) for item in expected) == 4
failed_run = base / '20261117-warm-no-new-mu-three-module-check'
failed = json.loads((failed_run / 'results.json').read_text())
rejected_path = work / 'THREE-MODULE-FIRST-CHECK-REJECTED.json'
rejected = json.loads(rejected_path.read_text())
assert rejected['actual_session'] == 78575 and rejected['actual_terminal_exit'] == 1
assert rejected['checks'] == failed['checks'] and not failed['proof_credit']
assert [item['exit'] for item in failed['checks']] == [1, 1, 1]
assert [item['diagnostics'] for item in failed['checks']] == [3, 1, 1]
assert failed['checks'][0]['sorryAx'] and 'sorryAx' in failed['checks'][0]['nonstandard_axioms']
assert failed['private_helpers_compiled_transitively'] == 0
assert rejected['generated_sorryAx_report_rejected']
assert not (failed_run / 'checked.json').exists()
bound.update([failed_run / 'results.json', rejected_path])
bound.update(failed_run / (item['name'] + '.txt') for item in failed['checks'])
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
imports = (work / 'IMPORTS.lean.txt').read_bytes()
assert public == b''.join(probes)
assert imports == ''.join('import MicroCFTA.' + item['module'] + '\n' for item in expected).encode()
assert len(imports) == stage['old_audit_exact_offset'] == 189
assert (root / audit_name).read_bytes() == imports + old_audit + b'\n' + public
assert sum(line.startswith(b'import ') for line in (root / audit_name).read_bytes().splitlines()) == 5267
assert (root / audit_name).read_bytes().count(b'#print axioms ') == 698
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 290
for item in expected:
    assert ('import MicroCFTA.' + item['module'] + '\n').encode() not in prior_independent
for name in ['strict-bind.py.txt', 'publication-driver.py.txt', 'shadow-compile.py.txt']:
    ast.parse((control / name).read_text())
normal_objects = root / 'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()

# Only Root executes these checkpoint controls after review.
import gzip
import subprocess

ROOT = root
BASE = base
WORK = work
PUBLIC = runtime
ARCHIVE = '20261117-warm-no-new-mu-checkpoint'
BOARD_PREFIX = 'current-board-warm-no-new-mu-'
read = lambda path: json.loads(path.read_text())
GIT = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
bindings = read(WORK / 'prior-bindings.json')
assert bindings['prior_checkpoint'] == prior_commit
verify_prior_pins(failed_run / 'source-pins.json')
commit = read(WORK / 'SOURCE-COMMIT.json')
code = commit['source_commit']
assert code == 'ebce743f365aad5e98c31a5e4eb6415fbd50c958'
assert commit['parent'] == prior_commit and commit['actual_terminal'] and commit['actual_terminal_exit'] == 0
assert not commit['joint_finite_completion_proved'] and not commit['haskell_changed']
assert GIT('rev-parse', 'HEAD').decode().strip() == code
assert GIT('rev-parse', code + '^').decode().strip() == prior_commit
assert GIT('branch', '--show-current').decode().strip() == 'formalize'
assert not GIT('status', '--porcelain', '--untracked-files=no')
changed = new_names | {audit_name}
assert len(changed) == 4 and set(commit['files']) == changed
assert set(GIT('diff', '--name-only', prior_commit, code).decode().splitlines()) == changed
for name in changed:
    assert GIT('show', code + ':' + name) == (ROOT / name).read_bytes(), name
assert GIT('show', prior_commit + ':' + audit_name) == old_audit
report = read(PUBLIC / 'checked.json')
verified = read(WORK / 'PUBLICATION-VERIFIED.json')
assert verified['actual_session'] == 29997 and verified['actual_terminal'] and verified['actual_terminal_exit'] == 0
assert verified['checks'] == report['checks']
assert [c['total_axiom_reports'] for c in report['checks']] == [698, 3, 293, 698, 698]
assert [(c['axiom_groups'], c['axiom_free_reports']) for c in report['checks']] == [
    (692, 6), (3, 0), (290, 3), (692, 6), (692, 6)]
assert all(c['declaration_checks'] == 0 for c in report['checks'])
assert all(c['exit'] == 0 and not c['diagnostics'] and not c['nonstandard_axioms'] and not c['sorryAx'] for c in report['checks'])
for name, value in {'source_files': 6267, 'direct_audit_imports': 5267,
        'individual_reports': 698, 'independent_reports': 293,
        'fresh_resource_component_reports': 3, 'inherited_resource_component_reports': 489,
        'resource_and_component_probes': 492, 'new_modules': 3, 'changed_existing_owners': 0,
        'new_public_theorems': 3, 'new_private_helpers': 46, 'new_private_theorems': 46,
        'new_private_predicates': 4, 'new_theorem_declarations': 49,
        'new_prop_definitions': 4, 'new_definition_declaration_checks': 0,
        'actual_publication_strict_reports': 3, 'new_private_component_reports': 0,
        'fresh_owner_preflight_reports': 0, 'replaced_old_reports': 0,
        'old_source_files_byte_exact': 6263, 'old_audit_exact_offset': 189,
        'audited_theorems': 100093}.items():
    assert report[name] == value, name
for name in ['all_three_original_first_headers_exact', 'all_three_original_first_headers_byte_exact',
        'all_three_selected_first_headers_exact', 'first_three_module_failure78575_preserved',
        'checked_alias_only_repair', 'missing_checked_alias_only_repaired',
        'candidate_proof_bodies_unchanged_by_repair', 'failed_generated_sorryAx_report_rejected',
        'publication_and_private_current_pins_use_Work53_Audit_only',
        'current_public_pins_use_new_source_bytes', 'candidate_source_pins_need_no_source_override',
        'all_old_source_except_audit_byte_exact', 'all_old_proof_bodies_and_limits_unchanged',
        'actual_next_warm_mu_owner_admission_proved', 'actual_next_warm_optional_prefix_no_new_mu_proved',
        'whole_next_warm_execute_outcome_and_all_prefixes_no_new_mu_proved',
        'warm_query_no_new_mu_proved', 'next_warm_after_one_cold_prefix_no_new_mu_proved',
        'actual_execute_outcome_heap_including_blocked_and_pending_retained']:
    assert report[name], name
for name in ['first_check_passed_without_repair', 'all_new_formal_proof_checks_first_pass',
        'private_helpers_counted_as_explicit_fresh_reports', 'owner_recompiled_in_publication_strict_gate',
        'arbitrary_independent_warm_query_sequence_proved', 'every_warm_worker_call_qualification_proved',
        'joint_finite_completion_proved', 'compiled_haskell_correspondence_proved', 'haskell_changed']:
    assert not report[name], name
assert report['warm_no_new_mu_scope'] == stage['warm_no_new_mu_scope'] == verified['scope']
assert report['inherited_owner_preflight_evidence']['reports'] == 264
assert report['inherited_owner_preflight_evidence']['included_in_inherited_489']
assert report['baseline_overrides'] == overrides
assert report['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
pins = read(PUBLIC / 'source-pins.json')
# Current public pins never use historical substitutions.
for name, digest in pins.items():
    assert sha((ROOT / name).read_bytes()) == digest, name
assert verified['pins_independently_reverified'] == len(pins) == 6752
source_pins = {name: digest for name, digest in pins.items()
    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
assert len(source_pins) == 6267 and set(source_pins) == set(baseline) | new_names
prior_path = BASE / bindings['prior_archive']
for name, key in [('manifest.json', 'prior_manifest_sha256'), ('checkpoint.json', 'prior_checkpoint_json_sha256')]:
    data = (prior_path / name).read_bytes()
    assert sha(data) == bindings[key]
    assert GIT('show', prior_commit + ':' + str((prior_path / name).relative_to(ROOT))) == data
old_checkpoint = read(prior_path / 'checkpoint.json')
assert old_checkpoint['resource_and_component_probes'] == 489
assert old_checkpoint['checked_code'] == GIT('rev-parse', prior_commit + '^').decode().strip()
prior_files = {item['path']: item for item in read(prior_path / 'manifest.json')['files']}
for name in ['source-pins.json.gz', 'verification.json', 'archived-inputs.json']:
    data = (prior_path / name).read_bytes()
    assert len(data) == prior_files[name]['bytes'] and sha(data) == prior_files[name]['sha256']
    assert GIT('show', prior_commit + ':' + str((prior_path / name).relative_to(ROOT))) == data
old_pins = json.loads(gzip.decompress((prior_path / 'source-pins.json.gz').read_bytes()))
assert baseline == {name: digest for name, digest in old_pins.items()
    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
for name, digest in old_pins.items():
    assert sha(prior_bytes(name)) == digest, name
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    assert old_pins[name] == pins[name], name
request = read(WORK / (BOARD_PREFIX + 'request.json'))
canonical = read(WORK / (BOARD_PREFIX + 'canonical.json'))
assert canonical.get('verified', True)
post = canonical.get('post', canonical)
assert post['id'] == request['request_id'] == '1b88afbf-84ab-483f-b036-c26914880962'
assert post['sequence'] == 1508
for key, value in [('author', request['username']), ('thread_id', request['thread_id']),
        ('post_type', request['post_type']), ('content', request['content']), ('metadata', request['metadata'])]:
    assert post[key] == value, key
assert post['metadata']['source'] == code
cleanup = read(WORK / 'combined-terminal-cleanup-result.json')
preview = read(WORK / 'TMP-CLEANUP-PREVIEW.json')
early = read(WORK / 'EARLY-TMP-CLEANUP-RESULT.json')
assert cleanup['all_owned_terminal_only'] and cleanup['all_three_actual_runs_terminal']
assert cleanup['unknown_tmp_entries_preserved'] and cleanup['normal_lake_symlink_targets_preserved']
assert not cleanup['symlink_target_bytes_counted'] and not cleanup['live_process_references']
paths = [item['path'] for item in cleanup['removed_targets']]
assert len(paths) == len(set(paths)) == 3
assert all(not Path(path).exists() and not Path(path).is_symlink() for path in paths)
actual_runs = [(78575, '20261117-warm-no-new-mu-three-module-check'),
    (50959, '20261117-warm-no-new-mu-alias-repair-check'),
    (29997, '20261117-warm-no-new-mu-publication')]
for item, (session, run) in zip(cleanup['removed_targets'], actual_runs):
    assert item['actual_session'] == session and item['run'] == run
    assert item['path'] == read(BASE / run / 'objects.json')['path']
    assert not item['symlink_target_bytes_counted']
assert cleanup['removed_targets'] == preview['owned_terminal_targets']
assert preview['late_targets'] == cleanup['removed_targets'][2:]
assert preview['all_three_actual_runs_terminal'] and preview['normal_lake_symlink_targets_preserved']
assert preview['terminal_sessions'] == [78575, 50959, 29997]
assert cleanup['removed_targets'][:2] == early['removed_targets']
assert early['removed_bytes'] == 6882520 and early['removed_symlinks'] == 12596
assert early['normal_lake_symlink_targets_preserved'] and not early['live_process_references']
assert cleanup['early_cleanup_receipt'] == 'EARLY-TMP-CLEANUP-RESULT.json'
assert cleanup['removed_bytes'] == sum(item['bytes'] for item in cleanup['removed_targets']) == 13765040
assert cleanup['removed_symlinks'] == sum(item['symlinks'] for item in cleanup['removed_targets']) == 18894
assert cleanup['prior_cumulative_removed_bytes'] == 6449383773
assert cleanup['prior_cumulative_removed_bytes'] + cleanup['removed_bytes'] == cleanup['cumulative_removed_bytes'] == 6463148813
assert cleanup['tmp_readable_regular_file_bytes_after'] == 5385909841
assert len(cleanup['tmp_census_errors']) == 6
start = read(WORK / 'START.json')
resume = read(WORK / 'RESUME-AUTHORIZATION.json')
assert start['user_explicitly_resumed'] and start['earlier_usage_pause_lifted'] and start['work_authorized']
assert start['persistent_goal_control_status'] == 'paused'
assert start['no_goal_resume_operation_available'] and not start['goal_completion_claimed']
assert resume['user_instruction'] == "Keep going. We'll use a reset if needed."
assert resume['user_explicitly_resumed'] and resume['earlier_usage_pause_lifted'] and resume['work_authorized']
assert resume['persistent_goal_control_at_resume'] == 'paused' and resume['no_goal_resume_operation_available']
usage = read(WORK / 'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int, float] and 0 <= percent <= 100
assert usage['earlier_usage_pause_lifted_by_user_resume']
roots = read(WORK / 'selection-roots.json')
assert len(roots) == 12
additional = read(WORK / 'archive-additional-roots.json')
assert len(additional) == 3
for item in additional:
    assert re.fullmatch(r'20261117-[a-z0-9-]+', item['root'])
    assert item['manifest'] == 'MANIFEST.json' and item['current_batch_theorem_credit'] == 0
    packet = BASE / item['root']
    manifest = read(packet / 'MANIFEST.json')
    verify(packet / 'MANIFEST.json', item['sha256'])
    for name, record in manifest_records(manifest):
        verify(packet / name, record)
    assert not item['private_runtime_selected']
    if item['kind'] == 'future_proof_candidate':
        assert 'UNCOMPILED' in manifest['status']
    else:
        assert item['kind'] == 'read_only_open_target_audit'
        assert 'AUDIT' in manifest['status'].upper()
    roots.append(item['root'])
assert len(roots) == len(set(roots)) == 15
assert all((BASE / name).is_dir() and not (BASE / name).is_symlink() for name in roots)
for name in roots:
    run = BASE / name
    if (run / 'check.py').exists():
        result = read(run / ('checked.json' if (run / 'checked.json').exists() else 'results.json'))
        assert result['checks'] and all(type(item['exit']) is int for item in result['checks']), name
for item in read(WORK / 'original-header-files.json'):
    assert sha((ROOT / item['path']).read_bytes()) == item['sha256']
    assert sha((ROOT / item['original']).read_bytes()) == item['sha256']
selected_roots = sorted(str((BASE / name).relative_to(ROOT)) for name in roots)
assert not (BASE / ARCHIVE).exists()
tree = hashlib.sha256()
for name, digest in sorted(source_pins.items()):
    tree.update(name.encode() + b'\0' + digest.encode() + b'\n')
config = dict(report)
config.update(checked_code=code, prior_checkpoint=prior_commit, public_run=str(PUBLIC), public_gates=5,
    explicit_reports=report['individual_reports'], board_prefix=BOARD_PREFIX,
    board_post_id=post['id'], board_sequence=post['sequence'], source_tree_sha256=tree.hexdigest(),
    old_non_audit_source_files_byte_exact=6263,
    old_audit_contiguous_bytes_preserved=429545, old_audit_exact_offset=189,
    ordinary_audit_import_bytes=189, new_audit_imports=3, old_audit_is_prefix=False,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],
    cleanup_receipt='combined-terminal-cleanup-result.json', removed_symlinks=cleanup['removed_symlinks'],
    symlink_target_bytes_counted=False, normal_lake_symlink_targets_preserved=True,
    tmp_readable_regular_file_bytes_after=cleanup['tmp_readable_regular_file_bytes_after'],
    tmp_census_errors=cleanup['tmp_census_errors'], unknown_tmp_entries_preserved=True,
    primary_usage_percent=percent, primary_usage_checked_at=usage['event_timestamp'],
    prior_immutable_archive=bindings['prior_archive'], prior_manifest_sha256=bindings['prior_manifest_sha256'],
    fresh_strict_reports=3, inherited_component_reports=489,
    all_new_formal_proof_checks_first_pass=False, first_check_passed_without_repair=False,
    all_three_original_first_headers_exact=True, checked_alias_only_repair=True,
    candidate_proof_bodies_unchanged_by_repair=True,
    historical_failed_proofs_preserved_in_prior_immutable_chain=True,
    additional_frozen_roots=additional, additional_frozen_roots_theorem_credit=0,
    arbitrary_independent_warm_query_sequence_proved=False,
    every_warm_worker_call_qualification_proved=False,
    user_explicitly_resumed=True, earlier_usage_pause_lifted=True,
    work_authorized_by_explicit_user_resume=True, persistent_goal_control_status='paused',
    goal_resume_operation_performed=False, goal_completion_claimed=False, goal_active=False,
    joint_finite_completion_proved=False, compiled_haskell_correspondence_proved=False, haskell_changed=False)
skipped = sorted(str(path.relative_to(ROOT)) for path in BASE.iterdir()
    if path.is_dir() and path.name.startswith('20261117-') and str(path.relative_to(ROOT)) not in selected_roots)
review = {'prior_checkpoint': prior_commit, 'selected_roots': len(selected_roots), 'base_roots': 12,
    'additional_frozen_roots': additional, 'additional_frozen_roots_theorem_credit': 0,
    'fresh_reports_this_batch': 3, 'inherited_reports': 489, 'combined_reports': 492,
    'new_public_theorems': 3, 'new_private_helpers': 46, 'new_theorem_declarations': 49,
    'new_prop_definitions': 4, 'definition_checks': 0, 'definition_axiom_reports': 0,
    'new_private_explicit_reports': 0, 'private_helpers_counted_as_explicit_reports': False,
    'all_current_component_first_checks_passed': False, 'inherited_owner_reports': 264,
    'failed78575_preserved': True, 'one_local_Checked_alias_repair_preserved': True,
    'all_three_original_first_headers_byte_exact': True,
    'actual_next_warm_mu_owner_admission_proved': True,
    'actual_next_warm_optional_prefix_no_new_mu_proved': True,
    'whole_next_warm_execute_outcome_and_all_prefixes_no_new_mu_proved': True,
    'every_warm_worker_call_qualification_proved': False,
    'arbitrary_independent_warm_query_sequence_proved': False,
    'warm_query_no_new_mu_proved': True, 'joint_finite_completion_proved': False,
    'haskell_changed': False, 'goal_completion_claimed': False}
note = (WORK / 'checkpoint-note.md').read_text()
for key, value in {'THEOREMS': report['audited_theorems'], 'REMOVED': cleanup['removed_bytes'],
                   'SYMLINKS': cleanup['removed_symlinks'],
                   'CLEANUP': cleanup['cumulative_removed_bytes'], 'USAGE': percent}.items():
    note = note.replace('{{' + key + '}}', str(value))
assert set(re.findall(r'\{\{(.*?)\}\}', note)) == {'TIME', 'TREE', 'CODE'}
outputs = {'checkpoint-config.json': config, 'archive-roots.json': selected_roots,
           'skipped-published-roots.json': skipped, 'selection-review.json': review}
assert all(not (WORK / name).exists() for name in outputs)
for name, value in outputs.items():
    (WORK / name).write_text(json.dumps(value, indent=2) + '\n')
(WORK / 'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code': code, 'packet': ARCHIVE, 'roots': len(selected_roots),
    'board_sequence': post['sequence'], 'fresh_reports': 3, 'inherited_reports': 489,
    'combined_reports': 492, 'future_root_credit': 0}))
