from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shlex
import subprocess

root = Path('/home/tritlo/Code/mcfta')
runtime = Path(__file__).parent
pins = json.loads((runtime / 'source-pins.json').read_text())
group = next(line.split(':', 2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines()
             if line.startswith('0::'))
base = Path('/sys/fs/cgroup') / group.lstrip('/')
limits = {name: (base / name).read_text().strip()
          for name in ['memory.max', 'memory.high', 'memory.swap.max']}
assert limits == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
environment = dict(os.environ)
environment.pop('LEAN_SYSROOT', None)
environment['LEAN_NUM_THREADS'] = '1'
checks = []


def verify_pins():
    for name, digest in pins.items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name


def run(name, command, required_groups=0):
    verify_pins()
    (runtime / 'running.json').write_text(json.dumps({'name': name, 'at': datetime.datetime.now().astimezone().isoformat()}) + '\n')
    with (runtime / (name + '.txt')).open('w') as log:
        result = subprocess.run(['nix-shell', str(root / 'shell.nix'), '--run', command],
                                cwd=root / 'lean', env=environment, stdout=log, stderr=subprocess.STDOUT, text=True)
    output = (runtime / (name + '.txt')).read_text()
    groups = [set(x.strip() for x in group.split(',') if x.strip())
              for group in re.findall(r'depends on axioms:\s*\[([^]]*)\]', output, re.S)]
    free_reports = len(re.findall(r'does not depend on any axioms', output))
    bad = sorted(set().union(*groups) - {'propext', 'Classical.choice', 'Quot.sound'}) if groups else []
    item = {'name': name, 'exit': result.returncode, 'axiom_groups': len(groups), 'axiom_free_reports': free_reports, 'total_axiom_reports': len(groups) + free_reports, 'nonstandard_axioms': bad}
    checks.append(item)
    (runtime / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')
    print(json.dumps(item), flush=True)
    verify_pins()




jobs = [('public-dependencies', 'exec lake build MicroCFTA.SourceCurrentAllocatedNativeNodeReturnOrigin MicroCFTA.SourceCurrentNativeOrderedOriginalEntry MicroCFTA.SourceEqualityNativeDemandBodyCode MicroCFTA.SourcePruningEnumerationCachedOwn MicroCFTA.SourcePruningEnumerationFinalize MicroCFTA.SourcePruningEnumerationPendingRendering MicroCFTA.SourcePruningEnumerationRecursivePacket MicroCFTA.SourcePruningEnumerationSharedChildUnionNormal MicroCFTA.SourcePruningEnumerationSharedDispatchProper MicroCFTA.SourcePruningEnumerationSharedEagerNoneBuckets MicroCFTA.SourcePruningEnumerationSharedEagerUnionNormal MicroCFTA.SourcePruningEnumerationSharedReceiptContinuation MicroCFTA.SourceSynthesisCurrentDonePendingTypes', 0), ('worker-cps', 'exec lake env lean -j1 -DwarningAsError=true -R /home/tritlo/Code/mcfta/lean/restart-evidence/20261116-cps-rendering-ancestry-none-candidates-check/source -o /tmp/mcfta-cps-render-ancestry-none-l_1zmbbm/worker-cps.olean /home/tritlo/Code/mcfta/lean/restart-evidence/20261116-cps-rendering-ancestry-none-candidates-check/source/MicroCFTA/SourcePruningEnumerationSharedEagerUnionNormalCPS.lean', 6), ('source-done-rendering', 'exec lake env lean -j1 -DwarningAsError=true -R /home/tritlo/Code/mcfta/lean/restart-evidence/20261116-cps-rendering-ancestry-none-candidates-check/source -o /tmp/mcfta-cps-render-ancestry-none-l_1zmbbm/source-done-rendering.olean /home/tritlo/Code/mcfta/lean/restart-evidence/20261116-cps-rendering-ancestry-none-candidates-check/source/MicroCFTA/SourceSynthesisCurrentDoneRendering.lean', 1), ('domain-ancestry', 'exec lake env lean -j1 -DwarningAsError=true -R /home/tritlo/Code/mcfta/lean/restart-evidence/20261116-cps-rendering-ancestry-none-candidates-check/source -o /tmp/mcfta-cps-render-ancestry-none-l_1zmbbm/domain-ancestry.olean /home/tritlo/Code/mcfta/lean/restart-evidence/20261116-cps-rendering-ancestry-none-candidates-check/source/MicroCFTA/SourceCurrentAllocatedNativeEmptyRootDomainAncestry.lean', 1), ('none-dispatch', 'exec lake env lean -j1 -DwarningAsError=true -R /home/tritlo/Code/mcfta/lean/restart-evidence/20261116-cps-rendering-ancestry-none-candidates-check/source -o /tmp/mcfta-cps-render-ancestry-none-l_1zmbbm/none-dispatch.olean /home/tritlo/Code/mcfta/lean/restart-evidence/20261116-cps-rendering-ancestry-none-candidates-check/source/MicroCFTA/SourcePruningEnumerationSharedEagerNoneDispatch.lean', 1), ('none-cached-writers', 'exec lake env lean -j1 -DwarningAsError=true -R /home/tritlo/Code/mcfta/lean/restart-evidence/20261116-cps-rendering-ancestry-none-candidates-check/source -o /tmp/mcfta-cps-render-ancestry-none-l_1zmbbm/none-cached-writers.olean /home/tritlo/Code/mcfta/lean/restart-evidence/20261116-cps-rendering-ancestry-none-candidates-check/source/MicroCFTA/SourcePruningEnumerationSharedEagerNoneCachedWriters.lean', 7)]
for name,command,count in jobs:
    run(name,command,count)
assert len(checks)==len(jobs)
assert all(c['exit']==0 and not c['nonstandard_axioms'] and c['total_axiom_reports']==job[2]
    for c,job in zip(checks,jobs))
report={'checks':checks,'source_pins_unchanged':True,'actual_cps_and_strict_height_proved':True,'actual_source_done_rendering_proved':True,'actual_empty_root_singleton_parent_proved':True,'actual_none_dispatch_proved':True,'actual_none_cached_writers_proved':True,
    
    'full_worker_union_normal_proved':False,'whole_warm_source_history_proved':False,
    'joint_finite_completion_proved':False,'haskell_changed':False,'limits':limits}
(runtime/'checked.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
