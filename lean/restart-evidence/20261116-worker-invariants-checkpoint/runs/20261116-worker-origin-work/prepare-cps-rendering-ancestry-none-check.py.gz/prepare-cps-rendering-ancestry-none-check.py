from pathlib import Path
import hashlib
import json
import shlex
import tempfile

root=Path('/home/tritlo/Code/mcfta')
base=root/'lean/restart-evidence'
run=base/'20261116-cps-rendering-ancestry-none-candidates-check'
run.mkdir()
specs=[
 ('worker-cps','20261116-current-real-worker-union-normal-cps-draft',
  'SourcePruningEnumerationSharedEagerUnionNormalCPS.lean','907c7ca606d604d73f00001546c8b469f24d756910c8537140e4f897b093dcd4',6),
 ('source-done-rendering','20261116-current-done-source-rendering-draft',
  'SourceSynthesisCurrentDoneRendering.lean','bbeabd295f7144bddc9478168e7c594752f50fce4be51a0acf7d9d010f273c06',1),
 ('domain-ancestry','20261116-current-empty-root-singleton-enter-owner-repair',
  'SourceCurrentAllocatedNativeEmptyRootDomainAncestry.lean','f8f4efb2f5b9dfe3e953c50a8a4c1fb45b8c4aff4d71c646d37dcf12ecb75aaf',1),
 ('none-dispatch','20261116-current-real-worker-none-dispatch-guard-notation-repair',
  'SourcePruningEnumerationSharedEagerNoneDispatch.lean','7269025336b1b6f38e0bcc7b1ba70035452caf84bb4b5f5e7b0b6c8c290ede45',1),
 ('none-cached-writers','20261116-current-real-worker-none-cached-writers-draft',
  'SourcePruningEnumerationSharedEagerNoneCachedWriters.lean','8ee024ac2b2b85fa32d4d75c7bf42960e885a3e1ca979eb7e2048241b2ebf382',7)]
objects=Path(tempfile.mkdtemp(prefix='mcfta-cps-render-ancestry-none-'))
(run/'objects.json').write_text(json.dumps({'path':str(objects)},indent=2)+'\n')
imports=set();jobs=[];files=[]
for label,folder,name,digest,count in specs:
    packet=base/folder;raw=packet/name;probes=packet/('COMPONENT-PROBES.lean.txt' if label=='worker-components' else 'PROBES.lean.txt')
    assert hashlib.sha256(raw.read_bytes()).hexdigest()==digest
    assert probes.read_bytes().count(b'#print axioms ')==count
    source=run/'source/MicroCFTA'/name;source.parent.mkdir(parents=True,exist_ok=True)
    source.write_bytes(raw.read_bytes()+b'\n'+probes.read_bytes())
    imports.update(line.split()[1] for line in raw.read_text().splitlines() if line.startswith('import '))
    command='exec lake env lean -j1 -DwarningAsError=true -R '+shlex.quote(str(source.parent.parent))
    command+=' -o '+shlex.quote(str(objects/(label+'.olean')))+' '+shlex.quote(str(source))
    jobs.append((label,command,count));files += [raw,probes,source]
jobs.insert(0,('public-dependencies','exec lake build '+' '.join(sorted(imports)),0))
template=(base/'20261115-native-open-binder-helper-dependencies/check.py').read_text()
driver=template[:template.index('run("public-dependency"')]
for assertion in [
 '    assert result.returncode == 0 and not bad and len(groups) + free_reports >= required_groups\n',
 "    assert 'sorryAx' not in output\n"]:
    assert driver.count(assertion)==1
    driver=driver.replace(assertion,'')
driver+='jobs = '+repr(jobs)+'''
for name,command,count in jobs:
    run(name,command,count)
assert len(checks)==len(jobs)
assert all(c['exit']==0 and not c['nonstandard_axioms'] and c['total_axiom_reports']==job[2]
    for c,job in zip(checks,jobs))
report={'checks':checks,'source_pins_unchanged':True,'actual_cps_and_strict_height_proved':True,'actual_source_done_rendering_proved':True,'actual_empty_root_singleton_parent_proved':True,'actual_none_dispatch_proved':True,'actual_none_cached_writers_proved':True,
    
    'full_worker_union_normal_proved':False,'whole_warm_source_history_proved':False,
    'joint_finite_completion_proved':False,'haskell_changed':False,'limits':limits}
(runtime/'checked.json').write_text(json.dumps(report,indent=2)+'\\n')
print(json.dumps(report),flush=True)
'''
(run/'check.py').write_text(driver)
files += list((root/'lean/MicroCFTA').glob('*.lean'))
files += [root/n for n in ['shell.nix','lean/lean-toolchain','lean/lakefile.toml','lean/lake-manifest.json']]
files += [Path(__file__),run/'check.py']
(run/'source-pins.json').write_text(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
    for p in files},indent=2)+'\n')
print(json.dumps({'run':str(run),'objects':str(objects),'jobs':[(n,c) for n,_,c in jobs]}))
