from pathlib import Path
import hashlib
import json
import shlex
import tempfile

root=Path('/home/tritlo/Code/mcfta')
base=root/'lean/restart-evidence'
run=base/'20261116-ancestry-cached-callback-values-check'
run.mkdir()
specs=[
 ('domain-ancestry','20261116-current-empty-root-singleton-enter-core-equality-repair',
 'SourceCurrentAllocatedNativeEmptyRootDomainAncestry.lean','d490784b2b510f1e72158a932c76af2e1d585410f6336c8be3ceb87e746b17d2',1),
 ('none-cached-writers','20261116-current-real-worker-none-cached-writers-references-repair',
 'SourcePruningEnumerationSharedEagerNoneCachedWriters.lean','710e0b5032eb578590db31db04c3cee32b3cc7af765435eb8951d6f3b3c46023',7),
 ('record-types-values','20261116-current-record-types-values-pending-namespace-repair',
 'SourcePruningEnumerationRecordTypesValues.lean','2196542731e31a68dd196b01b222c6fdbc80c3044bcddb6f7f2ca5b370425743',5)]
objects=Path(tempfile.mkdtemp(prefix='mcfta-ancestry-cached-callback-'))
(run/'objects.json').write_text(json.dumps({'path':str(objects)},indent=2)+'\n')
imports=set();jobs=[];files=[]
for label,folder,name,digest,count in specs:
    packet=base/folder;raw=packet/name;probes=packet/('COMPONENT-PROBES.lean.txt' if label=='worker-components' else 'PROBES.lean.txt')
    assert hashlib.sha256(raw.read_bytes()).hexdigest()==digest
    assert probes.read_bytes().count(b'#print axioms ')==count
    source=run/'source/MicroCFTA'/name;source.parent.mkdir(parents=True,exist_ok=True)
    source.write_bytes(raw.read_bytes()+b'\n'+probes.read_bytes())
    imports.update(line.split()[1] for line in raw.read_text().splitlines() if line.startswith('import '))
    command='exec lake env lean -j1 -DwarningAsError=true -R '+shlex.quote(str(source.parent.parent))
    command+=' -o '+shlex.quote(str(objects/(label+'.olean')))+' '+shlex.quote(str(source))
    jobs.append((label,command,count));files += [raw,probes,source]
jobs.insert(0,('public-dependencies','exec lake build '+' '.join(sorted(imports)),0))
template=(base/'20261115-native-open-binder-helper-dependencies/check.py').read_text()
driver=template[:template.index('run("public-dependency"')]
for assertion in [
 '    assert result.returncode == 0 and not bad and len(groups) + free_reports >= required_groups\n',
 "    assert 'sorryAx' not in output\n"]:
    assert driver.count(assertion)==1
    driver=driver.replace(assertion,'')
driver+='jobs = '+repr(jobs)+'''
for name,command,count in jobs:
    run(name,command,count)
assert len(checks)==len(jobs)
assert all(c['exit']==0 and not c['nonstandard_axioms'] and c['total_axiom_reports']==job[2]
    for c,job in zip(checks,jobs))
report={'checks':checks,'source_pins_unchanged':True,'actual_empty_root_singleton_parent_proved':True,'actual_cached_writers_proved':True,'actual_record_types_values_proved':True,
    
    'full_worker_union_normal_proved':False,'whole_warm_source_history_proved':False,
    'joint_finite_completion_proved':False,'haskell_changed':False,'limits':limits}
(runtime/'checked.json').write_text(json.dumps(report,indent=2)+'\\n')
print(json.dumps(report),flush=True)
'''
(run/'check.py').write_text(driver)
files += list((root/'lean/MicroCFTA').glob('*.lean'))
files += [root/n for n in ['shell.nix','lean/lean-toolchain','lean/lakefile.toml','lean/lake-manifest.json']]
files += [Path(__file__),run/'check.py']
(run/'source-pins.json').write_text(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
    for p in files},indent=2)+'\n')
print(json.dumps({'run':str(run),'objects':str(objects),'jobs':[(n,c) for n,_,c in jobs]}))
