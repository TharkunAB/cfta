/-- Write the supplied UVar, not its representative. -/
def setValue (uv : Nat) (value : UVarValue Symbol) : EnumerateM Symbol Guard Unit :=
  modify fun state => {state with values := state.values.set uv value}

/-- Read one raw slot. -/
def rawValue (uv : Nat) : EnumerateM Symbol Guard (UVarValue Symbol) := do
  match (← get).values[uv]? with
  | none => failure .invalidSlot
  | some value => pure value

/-- Find and path-compress a representative. -/
def representative (fuel uv : Nat) : EnumerateM Symbol Guard Nat := do
  let state ← get
  match UnionFind.findRoot fuel state.representatives uv with
  | none => failure .representativeFuel
  | some found =>
      set {state with representatives := found.forest}
      pure found.representative

/-- Read the current representative's slot. -/
def getValue (fuel uv : Nat) : EnumerateM Symbol Guard (UVarValue Symbol) := do
  rawValue (← representative fuel uv)

/-- Give a variable the ancestry of the current expansion. -/
def inheritAncestry (uv : Nat) : EnumerateM Symbol Guard Unit :=
  modify fun state => {state with recursionAncestry := (fun other =>
    if other = uv then (state.expansionAncestry ++ state.recursionAncestry uv).eraseDups
    else state.recursionAncestry other)}

/-- Allocate a slot and inherit the current recursion ancestry. -/
def allocate (node : Option Nat) : EnumerateM Symbol Guard Nat := do
  let state ← get
  let uv := state.counter
  set {state with counter := uv + 1, values := state.values ++ [UVarValue.unenumerated node []]}
  inheritAncestry uv
  pure uv

