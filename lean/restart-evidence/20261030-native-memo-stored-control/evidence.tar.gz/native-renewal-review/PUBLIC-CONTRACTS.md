# Exact V2 contracts

The imports and implicit context follow.

```lean
import MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryExecution
import MicroCFTA.SourceEqualityNativeDemandBodyCode
import MicroCFTA.SourceCurrentAllocatedPartialInitialization

/-!
# Conditional native memo certificates through actual mixed source traces

UNCOMPILED source-only draft.
The proof uses the actual completed physical trace.
It does not prove that a future request completes.
-/
namespace MicroCFTA.SourceCurrentAllocatedNativeStoredTrace
open Cache InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand SourceEqualityNativeDemandBodyCode
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace Receipt)
open SourceCurrentAllocatedNativePhysicalCompletion (Good)
open SourceCurrentAllocatedNativeFieldClosure (Fields)
open SourceEqualityRequiredSemanticCache (SemanticReady)
open SourceCurrentAllocatedFiniteOrdinaryStored SourceCurrentAllocatedFiniteOrdinaryCode
open SourceCurrentAllocatedFiniteOrdinaryExecution (CertifiedControl)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Checked" => SourceEqualityNativeDemand.State
variable {width : Nat}

```

```lean
theorem clean_trace_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (fuel : Nat) {Output : Type} (control : Control Output) (before after : Checked width) (value : Output)
    (trace : Trace fuel control before (.code (.pure value)) after)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap)
    (fields : Fields control before) (stored : Stored before.native) (clean : Clean control) :
    Stored after.native
```

```lean
theorem node_trace_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (request : NodeRequest Symbol Guard) (before after : Checked width) (fuel : Nat) (value : Value Symbol Guard)
    (trace : Trace fuel (.code (requestNode request.domain request.left request.right)) before (.code (.pure value)) after)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap) (stored : Stored before.native) :
    Stored after.native
```

```lean
theorem edge_trace_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (request : EdgeRequest Symbol Guard) (before after : Checked width) (fuel : Nat) (value : EdgeValue Symbol Guard)
    (trace : Trace fuel (.code (requestEdge request.domain request.left request.right)) before (.code (.pure value)) after)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap) (stored : Stored before.native) :
    Stored after.native
```

```lean
theorem node_receipt_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (request : NodeRequest Symbol Guard) (before after : Checked width) (fuel : Nat) (value : Value Symbol Guard)
    (post : Machine Symbol Guard → Value Symbol Guard → Prop)
    (receipt : Receipt fuel (.code (requestNode request.domain request.left request.right)) before value after post)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap) (stored : Stored before.native) :
    Stored after.native
```

```lean
theorem edge_receipt_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (request : EdgeRequest Symbol Guard) (before after : Checked width) (fuel : Nat) (value : EdgeValue Symbol Guard)
    (post : Machine Symbol Guard → EdgeValue Symbol Guard → Prop)
    (receipt : Receipt fuel (.code (requestEdge request.domain request.left request.right)) before value after post)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap) (stored : Stored before.native) :
    Stored after.native
```

```lean
theorem initial_clean_trace_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (cache : Cache.State SourceEqualityPartialConstraintKey.Key)
    (heap : InternedConstructorTemplates.State Symbol Guard)
    (fuel : Nat) {Output : Type} (control : Control Output) (after : Checked width) (value : Output)
    (trace : Trace fuel control (SourceCurrentAllocatedPartialInitialization.checked width cache heap)
      (.code (.pure value)) after)
    (good : Good (SourceCurrentAllocatedPartialInitialization.checked width cache heap))
    (semantic : SemanticReady heap)
    (fields : Fields control (SourceCurrentAllocatedPartialInitialization.checked width cache heap))
    (clean : Clean control) : Stored after.native
```

