import MicroCFTA.SourceEqualityNativeDemandBodyCode
import MicroCFTA.SourceEqualityNativeDemandNodeReadback
import MicroCFTA.SourceEqualityNativeDemandOperations
theorem finish_edge_trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem trace_retains [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem done_retains [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem node_body_cell [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem edge_body_cell [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
