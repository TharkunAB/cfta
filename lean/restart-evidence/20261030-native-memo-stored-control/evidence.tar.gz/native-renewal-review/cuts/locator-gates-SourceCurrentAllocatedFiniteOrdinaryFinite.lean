import MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryExecution
import MicroCFTA.InternedNormalizationFree
namespace MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryFinite
variable {Symbol Guard : Type}
theorem original (value : Value Symbol Guard)
theorem closed (state : InternedConstructorTemplates.State Symbol Guard) (coherent : Coherent state)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Checked" => SourceEqualityNativeDemand.State
variable {width : Nat}
theorem finite [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
