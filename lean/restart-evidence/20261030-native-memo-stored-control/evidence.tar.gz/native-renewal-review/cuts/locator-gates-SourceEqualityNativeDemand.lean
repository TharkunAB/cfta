import MicroCFTA.SourceEqualityConstraintFieldLookup
import MicroCFTA.SourceEqualityNativeCheckedCode
import MicroCFTA.SourceEqualityIntersectionEdgeAllocation
import MicroCFTA.SourceRecursiveIntersectionNative
import MicroCFTA.SourceEqualityPCSNativeEdge
namespace MicroCFTA.SourceEqualityNativeDemand
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Native" => SourceRecursiveIntersectionThunks.State
local notation "Operations" => SourceEqualityConstraintMemoAllocation.State
structure State (width : Nat) : Type 1 where
inductive Control (Output : Type) : Type 1 where
inductive Blocked where
inductive Outcome (width : Nat) (Output : Type) : Type 1 where
def Outcome.state : Outcome width Output → State width
def lift (operations : Operations) : SourceRecursiveIntersectionNative.Outcome width Symbol Guard Output → Outcome width Output
def sentinel (request : EdgeRequest Symbol Guard) (next : EdgeValue Symbol Guard → Code Symbol Guard Output)
noncomputable def body (request : EdgeRequest Symbol Guard) (next : EdgeValue Symbol Guard → Code Symbol Guard Output)
noncomputable def step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
noncomputable def execute [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] :
noncomputable def resume [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem execute_add [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem done_stable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem blocked_stable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem body_mismatch (request : EdgeRequest Symbol Guard) (next : EdgeValue Symbol Guard → Code Symbol Guard Output)
