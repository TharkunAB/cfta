              | node request next =>
                  cases selected : lookupNode width request before.native with
                  | mk selection chosen =>
                      cases selection with
                      | direct actual =>
                          obtain ⟨key, known⟩ := node_cacheable (width := width) request certificate.1
                          simp only [lookupNode, known] at selected
                          cases selected
                      | memoized handle =>
                          have safe := selected_node_safe request before.native chosen handle inputs.2 selected
                          cases demanded : demandNode handle chosen with
                          | mk observation running =>
                              cases observation with
                              | absent | busy =>
                                  simp only [step, SourceRecursiveIntersectionNative.step, selected, demanded, lift] at one
                                  cases one
                              | ready result =>
                                  have observed := node_observed_ready request before.native chosen running handle result
                                    good.native stored inputs.1 safe selected demanded
                                  have same := Outcome.yielded.inj (by simpa only [step, SourceRecursiveIntersectionNative.step,
                                    selected, demanded, lift] using one)
                                  rcases same.1 with rfl
                                  rcases same.2 with rfl
                                  exact ih count (by omega) _ _ after value post tail advanced.1 advanced.2.2.1
                                    advanced.2.2.2 observed.2.1
                                    (certificate.2 result _ advanced.1.native.machine advanced.2.1 advanced.2.2.1 observed.2.2.2 observed.1)
                              | evaluate actual =>
                                  have started := node_started request actual before.native chosen running handle
                                    good.native stored inputs.1 safe selected demanded
                                  obtain ⟨ownerSame, runningStored, runningCell⟩ := started
                                  subst actual
                                  have same := Outcome.yielded.inj (by simpa only [step, SourceRecursiveIntersectionNative.step,
                                    selected, demanded, lift] using one)
                                  rcases same.1 with rfl
                                  rcases same.2 with rfl
                                  obtain ⟨inner, outer, result, middle, total, bodyTrace, frameTrace⟩ :=
                                    SourceCurrentAllocatedNativeSemanticTraceReadback.bind_inverse count (.code (compileNode request))
                                      (fun result => .finishNode handle result (next result))
                                      ⟨running, before.operations⟩ after value tail
                                  have bodyFields := SourceCurrentAllocatedNativeSemanticTraceReadback.fields_before_bind
                                    (.code (compileNode request)) (fun result => .finishNode handle result (next result)) _ advanced.2.2.2
                                  have machineSame : running.machine = before.native.machine := by
                                    have first := SourceRecursiveIntersectionNative.lookupNode_machine request before.native
                                    have second := SourceRecursiveIntersectionNative.demandNode_machine handle chosen
                                    simp only [selected] at first
                                    simp only [demanded] at second
                                    exact second.trans first
                                  have bodyCert := SourceCurrentAllocatedFiniteOrdinaryNode.node_certified request running.machine
                                    advanced.1.native.machine advanced.2.2.1
                                    (by rw [machineSame]; exact inputs.1.2.1) (by rw [machineSame]; exact inputs.1.2.2) certificate.1
                                  have built := ih inner (by omega) _ _ middle result (fun _ result => NodeCertificate request result)
                                    bodyTrace advanced.1 advanced.2.2.1 bodyFields runningStored bodyCert
                                  have bodyReached := reached bodyTrace advanced.1 advanced.2.2.1 bodyFields
                                  have retained := SourceCurrentAllocatedFiniteOrdinaryFrames.node_body_cell
                                    inner handle request _ middle result bodyTrace advanced.1.native runningCell
                                  have frameInputs := SourceCurrentAllocatedNativeSemanticTraceReadback.current_inputs frameTrace
                                  have available : Available middle.native.machine.heap result := frameInputs.choose_spec.2
                                  let finished : Checked width := {middle with native := finishNode handle result middle.native}
                                  have finishStep : step (.code (.finishNode handle result (next result))) middle =
                                      .yielded (.code (next result)) finished := rfl
                                  obtain ⟨remaining, frameCount, restTrace⟩ := SourceCurrentAllocatedNativeSemanticTraceReadback.after_step
                                    outer _ _ middle finished after value frameTrace finishStep
                                  have frameFields := (reached (bodyTrace.bind (fun result => .finishNode handle result (next result)))
                                    advanced.1 advanced.2.2.1 advanced.2.2.2).2.2.2
                                  have finishPrefix : Trace 1 (.code (.finishNode handle result (next result))) middle
                                      (.code (next result)) finished := .cons _ _ _ _ _ _ 0 frameInputs finishStep (.refl _ _)
                                  have finishedReached := reached finishPrefix bodyReached.1 bodyReached.2.2.1 frameFields
                                  have continuationCert := certificate.2 result finished.native.machine finishedReached.1.native.machine
                                    (advanced.2.1.trans (bodyReached.2.1.trans finishedReached.2.1)) finishedReached.2.2.1 available built.2
                                  exact ih remaining (by omega) _ finished after value post restTrace finishedReached.1
                                    finishedReached.2.2.1 finishedReached.2.2.2
