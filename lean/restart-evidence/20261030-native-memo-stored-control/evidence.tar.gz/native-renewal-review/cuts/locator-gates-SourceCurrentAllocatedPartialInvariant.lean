import MicroCFTA.SourceCurrentAllocatedPartialMemoSound
import MicroCFTA.SourceCurrentConjunctionClassScan
import MicroCFTA.SourceCurrentAllocatedMuRebuild
import MicroCFTA.SourceCurrentAllocatedNativeInventoryState
import MicroCFTA.SourceCurrentMemoMergeLanguage
namespace MicroCFTA.SourceCurrentAllocatedPartialInvariant
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
variable [DecidableEq (EdgeKey Symbol Guard)]
structure Context (formulas : SourceGuards.Formulas FullSyntax.Formula)
structure Post (formulas : SourceGuards.Formulas FullSyntax.Formula)
variable {formulas : SourceGuards.Formulas FullSyntax.Formula} {solver : SourceGuards.Entailment FullSyntax.Formula}
theorem Context.rebase (context : Context formulas solver inventory before memos)
theorem Post.refl (context : Context formulas solver inventory before memos) :
theorem Post.trans (first : Post formulas solver inventory before middle memos)
theorem Post.rebase (context : Context formulas solver inventory before memos)
