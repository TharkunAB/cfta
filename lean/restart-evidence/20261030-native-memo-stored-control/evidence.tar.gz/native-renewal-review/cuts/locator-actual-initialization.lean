def emptyValue (cache : Cache.State Key) : EqValue :=
def operations (cache : Cache.State Key) : OpState :=
def checked (width : Nat) (cache : Cache.State Key) (heap : State Symbol Guard) : Checked width :=
def caller (width : Nat) (cache : Cache.State Key) (heap : State Symbol Guard) : Caller width :=
def globals : EndpointMemoGateTrace.Memos :=
def inventory (expression : InternedNestedConstruction.Syntax Symbol Guard)
