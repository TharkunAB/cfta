def endpoint : FoldStop (Failure width Typing) width → Option (Caller width × Queries)
def finish (uv : Nat) : Fold (Output width Typing) (Failure width Typing) width → Result
noncomputable def continueWith
noncomputable def resume
noncomputable def run
