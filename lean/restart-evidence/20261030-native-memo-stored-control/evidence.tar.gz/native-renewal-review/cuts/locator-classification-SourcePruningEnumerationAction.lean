def prepare [DecidableEq (InternedConstructorTemplates.EdgeKey Symbol NativeGuard)]
theorem prepare_pending_complete
