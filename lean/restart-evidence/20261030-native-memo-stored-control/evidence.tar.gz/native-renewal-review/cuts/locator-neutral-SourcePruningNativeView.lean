def keeps (fits : Key → Symbol → Bool)
def narrowAt [DecidableEq (EdgeKey Symbol Guard)]
def emptyAt [DecidableEq (EdgeKey Symbol Guard)]
theorem narrowAt_complete [DecidableEq (EdgeKey Symbol Guard)]
theorem emptyAt_complete [DecidableEq (EdgeKey Symbol Guard)]
theorem emptyAt_mu [DecidableEq (EdgeKey Symbol Guard)]
