namespace MicroCFTA.InternedConstructorTemplates
structure EdgeKey (Symbol Guard : Type) where
inductive Value (Symbol Guard : Type) where
inductive EdgeValue (Symbol Guard : Type) where
def Value.referenceOf : Value Symbol Guard → NodeRef
def Value.depth : Value Symbol Guard → Nat
def Value.free : Value Symbol Guard → List Reference
def EdgeValue.entry : EdgeValue Symbol Guard → Interned (EdgeKey Symbol Guard)
def EdgeValue.children : EdgeValue Symbol Guard → List (Value Symbol Guard)
structure State (Symbol Guard : Type) where
def empty : State Symbol Guard := ⟨Cache.emptyState, Cache.emptyState, fun _ => none, fun _ => none⟩
def Valid (state : State Symbol Guard) : Prop := Cache.Valid state.edges ∧ Cache.Valid state.nodes
theorem empty_valid : Valid (empty (Symbol := Symbol) (Guard := Guard)) := ⟨Cache.empty_valid, Cache.empty_valid⟩
structure Grows (before after : State Symbol Guard) : Prop where
theorem grows_refl (state : State Symbol Guard) : Grows state state :=
theorem grows_trans (first : Grows before middle) (second : Grows middle after) : Grows before after :=
def edgeStep [DecidableEq (EdgeKey Symbol Guard)] (key : EdgeKey Symbol Guard)
def nodeStep (key : NodeKey) (identify : Interned NodeKey → Value Symbol Guard) (state : State Symbol Guard) :
inductive Work (Symbol Guard : Type) : Type → Type 1 where
def Work.bind (work : Work Symbol Guard First) (next : First → Work Symbol Guard Result) : Work Symbol Guard Result :=
def run [DecidableEq (EdgeKey Symbol Guard)] (work : Work Symbol Guard Result) (state : State Symbol Guard) :
theorem edgeStep_correct [DecidableEq (EdgeKey Symbol Guard)] (key : EdgeKey Symbol Guard)
theorem nodeStep_correct (key : NodeKey) (identify : Interned NodeKey → Value Symbol Guard)
theorem run_correct [DecidableEq (EdgeKey Symbol Guard)] (work : Work Symbol Guard Result)
theorem edgeStep_replay [DecidableEq (EdgeKey Symbol Guard)] (key : EdgeKey Symbol Guard)
theorem nodeStep_replay (key : NodeKey) (identify : Interned NodeKey → Value Symbol Guard)
theorem replay [DecidableEq (EdgeKey Symbol Guard)] (work : Work Symbol Guard Result)
theorem run_bind [DecidableEq (EdgeKey Symbol Guard)] (work : Work Symbol Guard First)
def canonicalFree (names : List Reference) : List Reference :=
def maximumDepth (children : List (Value Symbol Guard)) : Nat :=
def childFree (children : List (Value Symbol Guard)) : List Reference :=
def makeEdge (symbol : Symbol) (constraint : Guard) (children : List (Value Symbol Guard)) :
def surviving (edges : List (EdgeValue Symbol Guard)) : List (EdgeValue Symbol Guard) :=
def canonicalEdges (edges : List (EdgeValue Symbol Guard)) : List (EdgeValue Symbol Guard) :=
def identifyNode (edges : List (EdgeValue Symbol Guard)) (entry : Interned NodeKey) : Value Symbol Guard :=
def makeNode (edges : List (EdgeValue Symbol Guard)) : Work Symbol Guard (Value Symbol Guard) :=
def unionMembers : Value Symbol Guard → List (Value Symbol Guard)
def distinctNodes : List (Value Symbol Guard) → List (Value Symbol Guard)
def ordinaryEdges : List (Value Symbol Guard) → Option (List (EdgeValue Symbol Guard))
def makeUnion (values : List (Value Symbol Guard)) : Work Symbol Guard (Value Symbol Guard) :=
inductive Template (Symbol Guard : Type) where
inductive EdgeTemplate (Symbol Guard : Type) where
def compile (template : Template Symbol Guard) (argument : Value Symbol Guard) : Work Symbol Guard (Value Symbol Guard) :=
def compileMany (templates : List (Template Symbol Guard)) (argument : Value Symbol Guard) :
def compileEdges (templates : List (EdgeTemplate Symbol Guard)) (argument : Value Symbol Guard) :
def withoutSelfReference (name : Reference) (body : Value Symbol Guard) : Work Symbol Guard (Value Symbol Guard) :=
theorem referenceOf_self_iff (name : Reference) (value : Value Symbol Guard) :
theorem withoutSelfReference_members (name : Reference) (members : List (Value Symbol Guard))
theorem withoutSelfReference_absent (name : Reference) (entry : Interned NodeKey)
def compileBody (template : Template Symbol Guard) (name : Reference) : Work Symbol Guard (Value Symbol Guard) :=
theorem compileBody_replay [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
theorem compile_replay [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
theorem compileMany_length [DecidableEq (EdgeKey Symbol Guard)] (templates : List (Template Symbol Guard))
def ordinaryKey : NodeKey → Prop
def Ordinary (work : Work Symbol Guard Result) : Prop :=
theorem ordinary_bind (work : Work Symbol Guard First) (next : First → Work Symbol Guard Result)
theorem makeNode_ordinary (edges : List (EdgeValue Symbol Guard)) : Ordinary (makeNode edges) := by
theorem makeUnion_ordinary (values : List (Value Symbol Guard)) : Ordinary (makeUnion values) := by
theorem compile_ordinary (template : Template Symbol Guard) (argument : Value Symbol Guard) :
theorem compileMany_ordinary (templates : List (Template Symbol Guard)) (argument : Value Symbol Guard) :
theorem compileEdges_ordinary (templates : List (EdgeTemplate Symbol Guard)) (argument : Value Symbol Guard) :
theorem withoutSelfReference_ordinary (name : Reference) (body : Value Symbol Guard) :
theorem compileBody_ordinary (template : Template Symbol Guard) (name : Reference) :
theorem run_preserves_mu [DecidableEq (EdgeKey Symbol Guard)] (work : Work Symbol Guard Result)
theorem compile_preserves_mu [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
theorem compileBody_preserves_mu [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
def probes [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard) (state : State Symbol Guard) :
theorem probes_correct [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
theorem probes_replay [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
def muKey (depthShape ordinaryShape : Value Symbol Guard) : NodeKey :=
def finishMu [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
theorem finishMu_correct [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
theorem finishMu_stored [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
theorem finishMu_miss [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
theorem finishMu_replay [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
def internMu [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard) (state : State Symbol Guard) :
theorem internMu_correct [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
theorem internMu_replay [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
def cleanup : Value Symbol Guard → Value Symbol Guard
def createMu [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard) (state : State Symbol Guard) :
theorem createMu_replay [DecidableEq (EdgeKey Symbol Guard)] (template : Template Symbol Guard)
theorem childFree_member (children : List (Value Symbol Guard)) (reference : Reference) :
theorem maximumDepth_exact (children : List (Value Symbol Guard)) (limit : Nat) :
theorem identifyNode_metadata (edges : List (EdgeValue Symbol Guard)) (entry : Interned NodeKey) :
theorem canonicalEdges_ids (edges : List (EdgeValue Symbol Guard)) :
def family (template : Template Symbol Guard) : List (Template Symbol Guard) :=
def families (templates : List (Template Symbol Guard)) : List (Template Symbol Guard) :=
def edgeFamily (edges : List (EdgeTemplate Symbol Guard)) : List (Template Symbol Guard) :=
theorem family_root (template : Template Symbol Guard) : template ∈ family template := by
def warmup [DecidableEq (EdgeKey Symbol Guard)] (templates : List (Template Symbol Guard))
theorem warmup_correct [DecidableEq (EdgeKey Symbol Guard)] (templates : List (Template Symbol Guard))
theorem warmup_length [DecidableEq (EdgeKey Symbol Guard)] (templates : List (Template Symbol Guard))
theorem warmup_replay [DecidableEq (EdgeKey Symbol Guard)] (templates : List (Template Symbol Guard))
theorem family_identity_image [DecidableEq (EdgeKey Symbol Guard)] (root : Template Symbol Guard)
theorem unary_two_cache_example :
theorem self_union_canonical_example :
theorem self_union_cleanup_example :
