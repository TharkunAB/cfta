        ((∀ extra, SourcePruningEnumerationNativeContinuations.run
