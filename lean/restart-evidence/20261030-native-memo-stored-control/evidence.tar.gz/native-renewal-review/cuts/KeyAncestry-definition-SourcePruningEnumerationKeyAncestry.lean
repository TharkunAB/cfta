def KeyAncestry (carrier : List (List (List (List Nat)))) (state : State Symbol Guard) : Prop :=
  (∀ slot key, key ∈ state.recursionAncestry slot → key.tries ∈ carrier) ∧
    ∀ key, key ∈ state.expansionAncestry → key.tries ∈ carrier

/-- Literal startup has no historical keys at any slot. -/
theorem KeyAncestry.initial (carrier : List (List (List (List Nat)))) (root : Nat) :
    KeyAncestry carrier (initial root : State Symbol Guard) := by
