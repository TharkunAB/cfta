import MicroCFTA.SourceRecursiveIntersectionNativeEvaluationTrace
def BodyCode (code : Code Symbol Guard A) : Prop :=
theorem bodyCode_bind (code : Code Symbol Guard A) (next : A → Code Symbol Guard B)
theorem bodyCode_walk (call : A → Code Symbol Guard B) (values : List A)
theorem compileMu_bodyCode (domain : Interned DomainKey) (left right : Value Symbol Guard) : BodyCode (compileMu domain left right) := by
theorem compileReference_bodyCode (domain : Interned DomainKey) (name : Nat) (other : Value Symbol Guard) (left : Bool) :
theorem compileEdge_bodyCode (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (request : EdgeRequest Symbol Guard) :
theorem compileRows_bodyCode [DecidableEq Symbol] (domain : Interned DomainKey) (left right : List (EdgeValue Symbol Guard)) :
theorem compileNode_bodyCode [DecidableEq Symbol] (request : NodeRequest Symbol Guard) : BodyCode (compileNode request) := by
