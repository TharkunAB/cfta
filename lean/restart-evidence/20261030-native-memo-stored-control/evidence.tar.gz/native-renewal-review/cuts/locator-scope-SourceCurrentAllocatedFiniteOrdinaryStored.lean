namespace MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryStored
local notation "Native" => SourceRecursiveIntersectionThunks.State
local notation "NodeDomain" => SourceCurrentAllocatedFiniteOrdinaryDomain.Node
local notation "EdgeDomain" => SourceCurrentAllocatedFiniteOrdinaryDomain.Edge
variable {width : Nat} {Symbol Guard : Type}
def NodeCertificate (request : NodeRequest Symbol Guard) (result : Value Symbol Guard) : Prop :=
def EdgeCertificate (request : EdgeRequest Symbol Guard) (result : EdgeValue Symbol Guard) : Prop :=
structure Stored (state : Native width Symbol Guard) : Prop where
theorem initial_stored (width : Nat) (machine : Machine Symbol Guard) : Stored (initial width machine) :=
theorem advance_stored (state : Native width Symbol Guard) (after : Machine Symbol Guard)
theorem lookupNode_stored (state : Native width Symbol Guard) (request : NodeRequest Symbol Guard)
theorem lookupEdge_stored (state : Native width Symbol Guard) (request : EdgeRequest Symbol Guard)
theorem demandNode_stored (state : Native width Symbol Guard) (handle : Nat)
theorem demandEdge_stored (state : Native width Symbol Guard) (handle : Nat)
theorem finishNode_stored (state : Native width Symbol Guard) (handle : Nat)
theorem finishEdge_stored (state : Native width Symbol Guard) (handle : Nat)
theorem node_observed_ready (request : NodeRequest Symbol Guard)
theorem edge_observed_ready (request : EdgeRequest Symbol Guard)
theorem node_started (request actual : NodeRequest Symbol Guard)
theorem edge_started (request actual : EdgeRequest Symbol Guard)
