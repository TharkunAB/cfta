def run (fuel : Nat) (value : Value Symbol Guard) (before : State Symbol Guard) :
theorem run_complete (value : Value Symbol Guard) (before : State Symbol Guard)
