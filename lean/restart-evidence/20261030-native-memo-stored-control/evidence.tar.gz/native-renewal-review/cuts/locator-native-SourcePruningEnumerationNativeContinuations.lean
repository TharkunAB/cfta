namespace MicroCFTA.SourcePruningEnumerationNativeContinuations
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => InternedConstructorTemplates.Value Symbol Constraint
local notation "Fragment" => Fragments.Fragment Symbol
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Receipt" => SourcePruningEnumerationSelectedEdge.Result
variable {width : Nat} {Output : Type u} {Reason : Type v}
inductive HookResult (Output : Type u) (Reason : Type v) (width : Nat) where
inductive Stop (Reason : Type v) (width : Nat) where
inductive Result (Output : Type u) (Reason : Type v) (width : Nat) where
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
noncomputable def run
theorem missing
theorem completed_head
theorem stopped_hook
def identityHook (_fragment : Fragment) (caller : Caller width) (queries : Queries) (_after : Cached) :
def ofBranches : SourcePruningEnumerationNativeBranches.Result width → Result Output Reason width
theorem identity_run
