def CanonicalNode (state : Caches Symbol Guard) (reference : Nat) : Prop :=
