noncomputable def run (checkEmpty : Bool) (r n p h k : Nat)
