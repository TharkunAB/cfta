import MicroCFTA.SourceRecursiveIntersectionThunkReadback
def Code.bind (code : Code Symbol Guard A) (next : A → Code Symbol Guard B) : Code Symbol Guard B :=
theorem Code.bind_assoc (code : Code Symbol Guard A) (first : A → Code Symbol Guard B) (second : B → Code Symbol Guard C) :
def walk (call : A → Code Symbol Guard B) : List A → Code Symbol Guard (List B)
def interpret [DecidableEq (EdgeKey Symbol Guard)] (nodes : NodeCall Symbol Guard) (edges : EdgeCall Symbol Guard)
theorem result_bind_assoc (result : Result Symbol Guard A)
theorem result_bind_congr (result : Result Symbol Guard A)
theorem interpret_bind [DecidableEq (EdgeKey Symbol Guard)] (nodes : NodeCall Symbol Guard) (edges : EdgeCall Symbol Guard)
theorem interpret_walk [DecidableEq (EdgeKey Symbol Guard)] (nodes : NodeCall Symbol Guard) (edges : EdgeCall Symbol Guard)
