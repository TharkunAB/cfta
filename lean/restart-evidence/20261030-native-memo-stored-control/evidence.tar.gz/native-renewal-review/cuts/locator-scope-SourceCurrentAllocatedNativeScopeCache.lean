namespace MicroCFTA.SourceCurrentAllocatedNativeScopeCache
local notation "Native" => SourceRecursiveIntersectionThunks.State
variable {width : Nat} {Symbol Guard : Type}
def NodeLaw (request : NodeRequest Symbol Guard) (result : Value Symbol Guard) : Prop :=
def EdgeLaw (request : EdgeRequest Symbol Guard) (result : EdgeValue Symbol Guard) : Prop :=
structure Scoped (state : Native width Symbol Guard) : Prop where
theorem initial_scoped (width : Nat) (machine : Machine Symbol Guard) : Scoped (initial width machine) :=
theorem advance_scoped (state : Native width Symbol Guard) (after : Machine Symbol Guard)
theorem lookupNode_scoped (state : Native width Symbol Guard) (request : NodeRequest Symbol Guard)
theorem lookupEdge_scoped (state : Native width Symbol Guard) (request : EdgeRequest Symbol Guard)
theorem demandNode_scoped (state : Native width Symbol Guard) (handle : Nat)
theorem demandEdge_scoped (state : Native width Symbol Guard) (handle : Nat)
theorem finishNode_scoped (state : Native width Symbol Guard) (handle : Nat)
theorem finishEdge_scoped (state : Native width Symbol Guard) (handle : Nat)
theorem node_observed_ready (request : NodeRequest Symbol Guard)
theorem edge_observed_ready (request : EdgeRequest Symbol Guard)
theorem node_started (request actual : NodeRequest Symbol Guard)
theorem edge_started (request actual : EdgeRequest Symbol Guard)
