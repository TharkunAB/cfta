def advance (before : Caller width) (heap : State Symbol Constraint) : Caller width :=
theorem complete
