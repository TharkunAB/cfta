import MicroCFTA.SourceEqualityAnnotationConstruction
import MicroCFTA.SourceCurrentOuterRankAdequacy
import MicroCFTA.SourceCurrentAllocatedPartialInitialization
import MicroCFTA.SourceCurrentConstructedOuterInitial
import MicroCFTA.SourceCurrentParentInitialRoom
theorem constructed_initial_node_call
    {initial finalCache : Cache.State SourceEqualityPartialConstraintKey.Key}
    (history : SourceEqualityOriginalAllocationHistory.History initial finalCache originals)
    (valid : Cache.Valid initial)
      ⟨heap.nodes.next, heap.edges.next, 0, InternedValueMassHeap.initialBound heap⟩)
    ⟨heap.nodes.next, heap.edges.next, 0, InternedValueMassHeap.initialBound heap⟩)
  have initial : SourceCurrentAllocatedPartialInvariant.Context formulas solver inventory before
      expression value built initial.ready
    ⟨Nat.le_refl _, Nat.le_refl _, Nat.le_refl _, InternedValueMassHeap.initial heap facts⟩
    SourceCurrentResourceParentWriters.initial formulas solver
    SourceCurrentOuterClosedInputs.initial
    SourceCurrentOuterEdgeIdle.initial
  exact SourceCurrentOuterRankAdequacy.initial_node_call
    formulas solver seed initial frame numeric carrier inputs room normal supported causal merged positiveMemo
