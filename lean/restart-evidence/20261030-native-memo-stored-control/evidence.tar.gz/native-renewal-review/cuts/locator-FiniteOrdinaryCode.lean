def NodeInputs (request : NodeRequest Symbol Guard) : Prop :=
def EdgeInputs (request : EdgeRequest Symbol Guard) : Prop :=
def Certified [DecidableEq (EdgeKey Symbol Guard)] (code : Code Symbol Guard A)
theorem certified_bind [DecidableEq (EdgeKey Symbol Guard)]
theorem request_node [DecidableEq (EdgeKey Symbol Guard)]
theorem request_edge [DecidableEq (EdgeKey Symbol Guard)]
theorem certified_walk [DecidableEq (EdgeKey Symbol Guard)]
