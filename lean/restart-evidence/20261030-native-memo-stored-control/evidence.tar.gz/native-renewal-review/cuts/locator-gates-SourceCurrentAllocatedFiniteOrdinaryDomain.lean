import MicroCFTA.MergedOrdinaryHeight
import MicroCFTA.InternedShallowValues
namespace MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryDomain
variable {Symbol Guard : Type}
inductive Node : Value Symbol Guard → Prop where
inductive Rows : List (EdgeValue Symbol Guard) → Prop where
inductive Children : List (Value Symbol Guard) → Prop where
def Edge (edge : EdgeValue Symbol Guard) : Prop := Children edge.children
theorem Children.member {values : List (Value Symbol Guard)} (domain : Children values)
theorem Children.of_members (values : List (Value Symbol Guard))
theorem Rows.member {edges : List (EdgeValue Symbol Guard)} (domain : Rows edges)
theorem Rows.of_members (edges : List (EdgeValue Symbol Guard))
theorem Node.rows {entry : Interned InternedBinderProtocol.NodeKey} {edges : List (EdgeValue Symbol Guard)}
theorem Node.nodeEdges {value : Value Symbol Guard} (domain : Node value) : Rows (nodeEdges value) := by
theorem Node.child {value : Value Symbol Guard} (domain : Node value)
theorem not_reference (name : InternedBinderProtocol.Reference) :
theorem not_mu (entry : Interned InternedBinderProtocol.NodeKey) (body depth ordinary : Value Symbol Guard) :
theorem not_union (entry : Interned InternedBinderProtocol.NodeKey) (members : List (Value Symbol Guard))
theorem Node.child_lt {entry : Interned InternedBinderProtocol.NodeKey} {edges : List (EdgeValue Symbol Guard)}
theorem edgeHeight_children (edge : EdgeValue Symbol Guard) : edgeHeight edge = childrenHeight edge.children := by
theorem child_le_edge (edge : EdgeValue Symbol Guard) (child : Value Symbol Guard) (member : child ∈ edge.children) :
theorem makeEdge [DecidableEq (EdgeKey Symbol Guard)]
theorem makeEdge_bound [DecidableEq (EdgeKey Symbol Guard)]
theorem makeNode [DecidableEq (EdgeKey Symbol Guard)]
theorem ordinaryUnion [DecidableEq (EdgeKey Symbol Guard)]
theorem makeNode_bound [DecidableEq (EdgeKey Symbol Guard)]
theorem ordinaryUnion_bound [DecidableEq (EdgeKey Symbol Guard)]
