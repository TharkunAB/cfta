import MicroCFTA.SourceEqualityNativeDemandContinuation
import MicroCFTA.SourceRecursiveIntersectionBodyCode
def Clean : Control Output → Prop
theorem sentinel_bodyCode (left : EdgeValue Symbol Guard) :
theorem children_bodyCode (request : EdgeRequest Symbol Guard)
theorem body_clean (request : EdgeRequest Symbol Guard) (next : EdgeValue Symbol Guard → Code Symbol Guard Output)
