open SourceEqualityOriginalAllocationHistory
open SourceCurrentAllocatedNativeInventoryState (Inventory)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Key" => SourceEqualityPartialConstraintKey.Key
local notation "EqValue" => SourceEqualityConstraintAllocation.Value
local notation "OpState" => SourceEqualityConstraintMemoAllocation.State
local notation "Checked" => SourceEqualityNativeDemand.State
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "EqReady" => SourceEqualityConstraintAllocation.Ready
local notation "Context" => SourceCurrentAllocatedPartialInvariant.Context

/-- The empty inherited value retains the actual canonical identity. -/
def emptyValue (cache : Cache.State Key) : EqValue :=
  (SourceEqualityConstraintAllocation.intern (some []) cache).1

/-- Empty equality allocation retains the supplied physical interner. -/
def operations (cache : Cache.State Key) : OpState :=
  SourceEqualityMkEdgeAllocation.emptyField (SourceEqualityConstraintMemoAllocation.initial cache)

/-- A checked initial state uses the actual returned empty-equality interner. -/
def checked (width : Nat) (cache : Cache.State Key) (heap : State Symbol Guard) : Checked width :=
  ⟨SourceRecursiveIntersectionThunks.initial width ⟨heap, Cache.emptyState⟩, operations cache⟩

/-- The logical cold caller has separate empty merge, fourth, and result tables. -/
def caller (width : Nat) (cache : Cache.State Key) (heap : State Symbol Guard) : Caller width :=
  SourceCurrentAllocatedPartialState.initial (checked width cache heap)
    SourceCurrentMemoMergeGraph.empty SourceCurrentEmptinessMemo.empty

/-- The three global memo families start with no saved entries. -/
