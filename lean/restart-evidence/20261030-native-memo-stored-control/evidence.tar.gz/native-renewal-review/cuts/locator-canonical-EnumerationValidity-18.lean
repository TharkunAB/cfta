def Canonical (state : State Symbol Guard) : Prop :=
