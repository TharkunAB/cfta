structure Good (state : CheckedState width) : Prop where
