
local instance : Monad List where
  pure value := [value]
  bind values continuation := values.flatMap continuation

/-- Every stored suspended constraint uses a canonical trie. -/
def Canonical (state : State Symbol Guard) : Prop :=
  ∀ value ∈ state.values, ValidSuspended (references value)

/-- The initialized root has no suspended constraints. -/
theorem initial_canonical (root : Nat) : Canonical (initial root : State Symbol Guard) := by
  simp [Canonical, initial, references, ValidSuspended]

/-- Replacing one slot preserves canonical tries when its new payload is canonical. -/
theorem set_canonical (uv : Nat) (value : UVarValue Symbol) (state : State Symbol Guard)
    (valid : Canonical state) (newValue : ValidSuspended (references value)) :
    Canonical {state with values := state.values.set uv value} := by
  intro stored member
  rcases List.mem_or_eq_of_mem_set member with old | same
  · exact valid stored old
  · simpa [same] using newValue

/-- A successful source slot write preserves canonical tries. -/
theorem setValue_canonical (uv : Nat) (value : UVarValue Symbol) (before after : State Symbol Guard)
    (valid : Canonical before) (newValue : ValidSuspended (references value))
    (success : Success (setValue uv value) before () after) : Canonical after := by
  obtain rfl := (modify_success _ before after).mp success
