import MicroCFTA.SourcePruningEnumerationCachedDispatch
namespace MicroCFTA.SourcePruningEnumerationCachedAdapter
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => InternedConstructorTemplates.Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Queries" => SourceEndpointMemo.Memos
variable {width : Nat}
def adapt
noncomputable def run
theorem complete
