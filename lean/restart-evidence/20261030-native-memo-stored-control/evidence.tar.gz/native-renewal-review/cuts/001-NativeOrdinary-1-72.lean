import MicroCFTA.SourcePruningEnumerationSelectedEntry
import MicroCFTA.SourcePruningEnumerationNativeBranchCompletion

namespace MicroCFTA.SourcePruningEnumerationNativeOrdinary
open EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationDependencies
open InternedConstructorTemplates SourcePruningEnumerationNodes SourcePruningEnumerationObservation
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Context Post)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => InternedConstructorTemplates.Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Receipt" => SourcePruningEnumerationSelectedEdge.Result
local notation "Result" => SourcePruningEnumerationNativeBranches.Result
local notation "Raw" => List (Except EnumerationState.Error ((Nat × Nat × List Suspended × Node) ×
  EnumerationState.State Symbol Constraint))
variable {width : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Retain actual entry and scan the selected edges only for an ordinary nonterminal parent. -/
noncomputable def run (checkEmpty : Bool) (r n p h k uv : Nat)
    (edgesOf : Node → List (EdgeValue Symbol Constraint)) (caller : Caller width)
    (before : Cached) (queries : Queries) : Raw × Option (Result width) :=
  let raw := ExceptT.run (SourcePruningEnumerationEntry.enter caller.checked.native.machine.heap r uv before.core)
  (raw, match raw with
    | [.ok ((target, _handle, scs, parent@(.node _ _ _ _)), entered)] =>
        if scs.any (fun sc => EqualityTrie.isTerminal sc.trie) then none
        else some (SourcePruningEnumerationNativeBranches.run checkEmpty r n p h k target scs
          (EnumerationExpandableIndex.frame entered before) (edgesOf parent) caller queries)
    | _ => none)

/-- Entry errors and rejected or unsupported entry rows remain exact at every fixed bound. -/
theorem entry_readback (checkEmpty : Bool) (r n p h k uv : Nat)
    (edgesOf : Node → List (EdgeValue Symbol Constraint)) (caller : Caller width)
    (before : Cached) (queries : Queries) :
    (run checkEmpty r n p h k uv edgesOf caller before queries).1 =
      ExceptT.run (SourcePruningEnumerationEntry.enter caller.checked.native.machine.heap r uv before.core) := rfl

/-- A terminal parent does not enter the ordinary shallow alternative scan. -/
theorem terminal (checkEmpty : Bool) (r n p h k uv target handle : Nat) (scs : List Suspended)
    (entry : Cache.Interned InternedBinderProtocol.NodeKey) (edges : List (EdgeValue Symbol Constraint))
    (depth : Nat) (free : List InternedBinderProtocol.Reference)
    (edgesOf : Node → List (EdgeValue Symbol Constraint)) (caller : Caller width)
    (before : Cached) (entered : EnumerationState.State Symbol Constraint) (queries : Queries)
    (observed : ExceptT.run (SourcePruningEnumerationEntry.enter caller.checked.native.machine.heap r uv before.core) =
      [.ok ((target, handle, scs, .node entry edges depth free), entered)])
    (blocked : scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = true) :
    run checkEmpty r n p h k uv edgesOf caller before queries =
      ([.ok ((target, handle, scs, .node entry edges depth free), entered)], none) := by
  simp only [run, observed, blocked, ite_true]

/-- Numeric branch admission applies only at the actual ordinary entry endpoint. -/
def Ranges (checkEmpty : Bool) (uv : Nat) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (caller : Caller width) (before : Cached) (queries : Queries) : Prop :=
  ∀ fuel target handle scs entry edges depth free entered,
    ExceptT.run (SourcePruningEnumerationEntry.enter caller.checked.native.machine.heap fuel uv before.core) =
      [.ok ((target, handle, scs, .node entry edges depth free), entered)] →
    scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = false →
    SourcePruningEnumerationNativeBranchCompletion.Ranges checkEmpty target scs
      (EnumerationExpandableIndex.frame entered before) (edgesOf (.node entry edges depth free)) caller queries

/-- Actual ready entry retains Caller receipts and fragment history for each processed alternative. -/
theorem complete_with_history
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (caller : Caller width) (before : Cached) (checkEmpty : Bool)
    (uv handle : Nat) (scs : List Suspended)
    (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
    (storedEdges : List (EdgeValue Symbol Constraint))
