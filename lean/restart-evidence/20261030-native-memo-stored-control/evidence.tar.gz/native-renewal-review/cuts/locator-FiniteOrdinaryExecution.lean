private theorem trace_semantic [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem reached [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem selected_node_safe
private theorem node_cacheable (request : NodeRequest Symbol Guard) (inputs : NodeInputs request) :
theorem verified [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem node_trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem edge_trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
