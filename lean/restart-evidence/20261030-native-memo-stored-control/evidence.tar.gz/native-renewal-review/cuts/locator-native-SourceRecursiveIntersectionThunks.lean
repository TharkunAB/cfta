namespace MicroCFTA.SourceRecursiveIntersectionThunks
structure NodeRequest (Symbol Guard : Type) where
structure EdgeRequest (Symbol Guard : Type) where
def NodeKey (width : Nat) (request : NodeRequest Symbol Guard) (key : Triple width) : Prop :=
def EdgeKeyOf (width : Nat) (request : EdgeRequest Symbol Guard) (key : Triple width) : Prop :=
def NodeReady (machine : Machine Symbol Guard) (request : NodeRequest Symbol Guard) : Prop :=
def EdgeReady (machine : Machine Symbol Guard) (request : EdgeRequest Symbol Guard) : Prop :=
def NodeGood [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
def EdgeGood [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
structure State (width : Nat) (Symbol Guard : Type) where
structure Valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard)
def initial (width : Nat) (machine : Machine Symbol Guard) : State width Symbol Guard := ⟨machine, FlatMemoThunk.empty, FlatMemoThunk.empty⟩
theorem initial_valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard)
inductive NodeSelection (Symbol Guard : Type) where
def lookupNode (width : Nat) (request : NodeRequest Symbol Guard) (state : State width Symbol Guard) :
def lookupEdge (width : Nat) (request : EdgeRequest Symbol Guard) (state : State width Symbol Guard) :
theorem lookupNode_bypass (width : Nat) (request : NodeRequest Symbol Guard) (state : State width Symbol Guard)
theorem lookupNode_valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard)
theorem lookupEdge_valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard)
def publicationKey (key : Triple width) : FlatMemoPublication.Key := ⟨key.1.toInt, key.2.1.toInt, key.2.2.toInt⟩
theorem node_publication (width : Nat) (request : NodeRequest Symbol Guard) (key : Triple width) (handle : Nat)
theorem edge_publication (width : Nat) (request : EdgeRequest Symbol Guard) (handle : Nat)
theorem completed_nodes [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard)
theorem completed_edges [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard)
