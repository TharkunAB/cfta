import MicroCFTA.SourcePruningEnumerationIncomingNode
import MicroCFTA.SourcePruningEnumerationIncomingObservedResources
namespace MicroCFTA.SourcePruningEnumerationIncomingNode
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
variable {EnumGuard : Type} {bits : Nat}
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Core" => EnumerationState.State Symbol EnumGuard
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
local notation "forecast" => SourcePruningEnumerationIncomingQuery.forecast
local notation "queryAlphabet" => SourceCurrentGeneratedQueryGuardResources.forecast
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)]
theorem initial_ranges (profile : Profile) (beforeCaller : Caller (bits + 2)) (before : Core)
variable [DecidableEq Node]
theorem observed_resources (alphabet : List Constraint) (profile : Profile)
theorem run_complete_resources
