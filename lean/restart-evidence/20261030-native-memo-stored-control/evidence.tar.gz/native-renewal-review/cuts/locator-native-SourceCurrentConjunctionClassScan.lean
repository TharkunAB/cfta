namespace MicroCFTA.SourceCurrentConjunctionClassScan
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Checked" => SourceEqualityNativeDemand.State
local notation "Physical" => SourceCurrentConjunctionRowsAllocation.State Symbol FullSyntax.Formula
local notation "Memo" => SourceCurrentEmptinessMemo.Memo
local notation "CostHeap" => InternedFreshOrdinaryCostHeap.Heap
variable {width : Nat}
def advanceHeap (before : Checked width) (heap : State Symbol Guard) : Checked width :=
inductive Scan [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem stopped_member [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem selected_sublist [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
structure Ready (state : Checked width) : Prop where
theorem advance_ready (before : Checked width) (after : Physical) (ready : Ready before)
theorem primary_effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem secondary_effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem memo_effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
