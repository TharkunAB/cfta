def Canonical (waiting : Waiting) : Prop := ∀ uv, waiting uv = encode (read waiting uv)
