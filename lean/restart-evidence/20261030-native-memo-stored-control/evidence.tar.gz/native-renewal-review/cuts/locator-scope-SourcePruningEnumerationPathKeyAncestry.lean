namespace MicroCFTA.SourcePruningEnumerationPathKeyAncestry
local notation "Symbol" => SourcePruningTemplates.Symbol
variable {EnumGuard NativeGuard : Type}
theorem enter_key_ancestry
