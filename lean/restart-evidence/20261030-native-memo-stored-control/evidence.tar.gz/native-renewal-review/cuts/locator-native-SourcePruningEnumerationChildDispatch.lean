namespace MicroCFTA.SourcePruningEnumerationChildDispatch
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => InternedConstructorTemplates.Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "PrefixRaw" => List (Except EnumerationState.Error
local notation "FoldRaw" => List (Except EnumerationState.Error
local notation "TerminalRaw" => List (Except EnumerationState.Error
variable {width : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
noncomputable def observe
noncomputable def run
theorem erase
theorem terminal
theorem singleton_core
theorem empty
theorem nonterminal_complete
