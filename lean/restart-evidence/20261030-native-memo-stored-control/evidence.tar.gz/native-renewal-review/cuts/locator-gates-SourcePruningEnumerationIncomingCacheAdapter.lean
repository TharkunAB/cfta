import MicroCFTA.SourcePruningEnumerationCachedIncoming
namespace MicroCFTA.SourcePruningEnumerationIncomingCacheAdapter
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => InternedConstructorTemplates.Value Symbol Constraint
local notation "Checked" => SourceEqualityNativeDemand.State
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Raw" => List (Except EnumerationState.Error
variable {width : Nat}
def adapt
theorem adapt_singleton_core
noncomputable def run
theorem erase
theorem singleton_core
theorem complete
