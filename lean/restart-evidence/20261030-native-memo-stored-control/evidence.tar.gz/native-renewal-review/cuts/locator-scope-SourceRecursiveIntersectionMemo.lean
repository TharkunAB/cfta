namespace MicroCFTA.SourceRecursiveIntersectionMemo
def requestKey (width : Nat) (domain : Interned DomainKey) (left right : Value Symbol Guard) : Option (Triple width) :=
def KeySafe (width : Nat) (domain : Interned DomainKey) (left right : Value Symbol Guard) : Prop :=
theorem domain_fits (width identity : Nat) (bounded : identity < 2 ^ (width - 1)) : identity < 2 ^ width :=
theorem KeySafe.swap (safe : KeySafe width domain left right) : KeySafe width domain right left := by
theorem requestKey_nonnegative (width : Nat) (domain : Interned DomainKey) (left right : Value Symbol Guard)
theorem requestKey_injective (width : Nat) (state : Machine Symbol Guard) (valid : Valid state)
theorem swapped_key_eq_iff (width : Nat) (state : Machine Symbol Guard) (valid : Valid state)
def Produced [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
def MemoValid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
theorem produced_here [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
theorem produced_grows [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
theorem produced_spec [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
theorem produced_replay [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
theorem memo_empty [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
theorem memo_grows [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
theorem memo_hit [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
theorem memo_insert [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
