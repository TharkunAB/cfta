import MicroCFTA.SourceRecursiveIntersectionCode
def requestNode (domain : Interned DomainKey) (left right : Value Symbol Guard) : Code Symbol Guard (Value Symbol Guard) :=
def requestEdge (domain : Interned DomainKey) (left right : EdgeValue Symbol Guard) : Code Symbol Guard (EdgeValue Symbol Guard) :=
def unsupported (left right : Value Symbol Guard) : Code Symbol Guard A :=
def compileMu (domain : Interned DomainKey) (left right : Value Symbol Guard) : Code Symbol Guard (Value Symbol Guard) :=
def compileReference (domain : Interned DomainKey) (name : Nat) (other : Value Symbol Guard) (left : Bool) :
def compileEdge (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (request : EdgeRequest Symbol Guard) :
def compileRows [DecidableEq Symbol] (domain : Interned DomainKey) (left right : List (EdgeValue Symbol Guard)) :
def compileNode [DecidableEq Symbol] (request : NodeRequest Symbol Guard) : Code Symbol Guard (Value Symbol Guard) :=
theorem result_bind_pure (result : Result Symbol Guard A) : result.bind (fun value after => .done value after) = result := by
theorem interpret_requestNode [DecidableEq (EdgeKey Symbol Guard)] (nodes : NodeCall Symbol Guard) (edges : EdgeCall Symbol Guard)
theorem interpret_requestEdge [DecidableEq (EdgeKey Symbol Guard)] (nodes : NodeCall Symbol Guard) (edges : EdgeCall Symbol Guard)
theorem interpret_requestNode_fun [DecidableEq (EdgeKey Symbol Guard)] (nodes : NodeCall Symbol Guard) (edges : EdgeCall Symbol Guard)
theorem interpret_requestEdge_fun [DecidableEq (EdgeKey Symbol Guard)] (nodes : NodeCall Symbol Guard) (edges : EdgeCall Symbol Guard)
theorem compileMu_exact [DecidableEq (EdgeKey Symbol Guard)] (nodes : NodeCall Symbol Guard) (edges : EdgeCall Symbol Guard)
theorem compileReference_exact [DecidableEq (EdgeKey Symbol Guard)] (nodes : NodeCall Symbol Guard) (edges : EdgeCall Symbol Guard)
theorem compileEdge_exact [DecidableEq (EdgeKey Symbol Guard)] (nodes : NodeCall Symbol Guard) (edges : EdgeCall Symbol Guard)
theorem compileRows_exact [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (nodes : NodeCall Symbol Guard)
theorem compileNode_exact [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (nodes : NodeCall Symbol Guard)
