import MicroCFTA.SourceCurrentAllocatedNativePhysicalTraceCompletion
import MicroCFTA.SourceCurrentAllocatedNativeReferenceMeaning
theorem inputs_before_bind [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem code_fields_before_bind (operations : SourceEqualityConstraintMemoAllocation.State)
theorem fields_before_bind (control : Control A) (next : A → Code Symbol Guard B) (state : Checked width)
theorem after_step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem current_inputs [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem work_readback [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem bind_inverse [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem bind_readback [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem Walk.trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem walk_readback [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem cons_readback [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem walk_work_readback [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
