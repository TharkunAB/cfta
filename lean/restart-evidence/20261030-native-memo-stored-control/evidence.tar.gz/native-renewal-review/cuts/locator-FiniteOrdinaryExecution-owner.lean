import MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryNode
import MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryEdge
import MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryFrames
import MicroCFTA.SourceCurrentAllocatedNativeSemanticTraceReadback
              | node request next =>
                                  have started := node_started request actual before.native chosen running handle
                                    SourceCurrentAllocatedNativeSemanticTraceReadback.bind_inverse count (.code (compileNode request))
                                    (.code (compileNode request)) (fun result => .finishNode handle result (next result)) _ advanced.2.2.2
              | edge request next =>
                              have started := edge_started request actual before.native chosen running handle
