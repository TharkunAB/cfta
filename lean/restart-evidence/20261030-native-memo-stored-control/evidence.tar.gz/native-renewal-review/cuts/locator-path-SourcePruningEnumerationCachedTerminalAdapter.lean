noncomputable def run
      match SourcePruningEnumerationCachedFold.run checkEmpty nativeFuel p h recorded
                  (SourcePruningEnumerationIncomingNode.run checkEmpty representativeFuel nativeFuel p h
                  SourcePruningEnumerationIncomingCacheAdapter.run checkEmpty representativeFuel nativeFuel p h
          cases cachedFoldResult : SourcePruningEnumerationCachedFold.run checkEmpty nativeFuel p h
                        cases fallbackIncomingResult : SourcePruningEnumerationIncomingNode.run
                        cases cachedIncomingResult : SourcePruningEnumerationIncomingCacheAdapter.run
          cases foldResultEq : SourcePruningEnumerationCachedFold.run checkEmpty nativeFuel p h recorded
                        cases resultEq : SourcePruningEnumerationIncomingNode.run checkEmpty
                        cases incomingEq : SourcePruningEnumerationIncomingCacheAdapter.run checkEmpty
        SourcePruningEnumerationCachedFold.run checkEmpty (n + extra) P H recorded
            SourcePruningEnumerationIncomingNode.run checkEmpty (r + extraRepresentative) (n + extraNative) P H
        List.map_cons, List.map_nil, SourcePruningEnumerationIncomingCacheAdapter.run,
