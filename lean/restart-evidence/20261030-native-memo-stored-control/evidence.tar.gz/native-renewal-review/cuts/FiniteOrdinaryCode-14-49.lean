open Cache InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityRequiredSemanticCache (SemanticReady)
open SourceCurrentAllocatedFiniteOrdinaryStored (NodeCertificate EdgeCertificate)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "NodeDomain" => SourceCurrentAllocatedFiniteOrdinaryDomain.Node
local notation "EdgeDomain" => SourceCurrentAllocatedFiniteOrdinaryDomain.Edge

/-- A structural node request starts outside recursive binder traversal. -/
def NodeInputs (request : NodeRequest Symbol Guard) : Prop :=
  request.domain.key.seen = [] ∧ NodeDomain request.left ∧ NodeDomain request.right

/-- A structural edge request retains both complete finite ordinary forests. -/
def EdgeInputs (request : EdgeRequest Symbol Guard) : Prop :=
  request.domain.key.seen = [] ∧ EdgeDomain request.left ∧ EdgeDomain request.right

/-- Local certificates admit only source instructions in the finite ordinary fragment. -/
def Certified [DecidableEq (EdgeKey Symbol Guard)] (code : Code Symbol Guard A)
    (state : Machine Symbol Guard) (post : Machine Symbol Guard → A → Prop) : Prop :=
  match code with
  | .pure value => post state value
  | .fail _ => True
  | .work job next => ∀ value after,
      SourceRecursiveIntersectionKernel.work job state = .done value after →
      SourceEqualityNativeDemandHeapPrimitives.WorkInputs state.heap job →
      SourceRecursiveIntersectionKernel.Valid after → Extension state after → SemanticReady after.heap →
      Certified (next value) after post
  | .node request next => NodeInputs request ∧ ∀ value after,
      SourceRecursiveIntersectionKernel.Valid after → Extension state after → SemanticReady after.heap →
      Available after.heap value → NodeCertificate request value → Certified (next value) after post
  | .edge request next => EdgeInputs request ∧ ∀ value after,
      SourceRecursiveIntersectionKernel.Valid after → Extension state after → SemanticReady after.heap →
      EdgeResident after.heap value → EdgeCertificate request value → Certified (next value) after post
  | .enter .. | .read .. | .optionalBinder .. | .finishNode .. | .finishEdge .. => False

