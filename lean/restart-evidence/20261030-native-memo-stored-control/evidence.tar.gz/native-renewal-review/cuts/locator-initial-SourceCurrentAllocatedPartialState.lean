def initial (checked : Checked width) (merge : MergeMemo) (fourth : Fourth) : State width :=
