# Named NEW OLD whole proof sources

2026-10-30 21:40:42 CET
Slot1 of2: SourceCurrentAllocatedFiniteOrdinaryFinite.lean. Read the exact actual finite-return proof and its state gates. Prior frozen cuts covered only12–23 and58–106. Declare this new complete acquisition before displaying all106 lines. Slot2 remains unused.

2026-10-30 21:40:58 CET
Slot2 of2: SourceRecursiveIntersectionNative.lean132L. Read the actual native node memo/capture/finish operation. Named before body acquisition. No further new OLD whole or near-whole source is authorized.

2026-10-30 22:04:24 CET
Root explicitly approved ONE third OLD whole at22:03 CET: SourceCurrentAllocatedFiniteOrdinaryExecution.lean271L. Reason: complete actual native owner proof needed for both node/edge and exact updater contracts. Original allowance2; approved allowance3 with this named exception. No fourth whole or near-whole source allowed. Root records approval in /tmp/mcfta-native-memo-stored-control-20261030/source-review-third-whole-approval.json.
