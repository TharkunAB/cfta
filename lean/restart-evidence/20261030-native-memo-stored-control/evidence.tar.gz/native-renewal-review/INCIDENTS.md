# Incidents

The first guessed frozen draft filename ExpansionPaths-v2-UNCOMPILED.lean did not exist. The actual name is ExecutionExpansion-v2-UNCOMPILED.lean.
A broad filename-only rg list was truncated. It read no proof body. Later lookups use exact filenames.
Memory registry lines490–510 were consulted for proof/correspondence scope. Its old global-induction-open status is superseded by Root current checked worker reports. No current proof claim is taken from memory.

Two attempts to reuse prior files failed assertions before any body display. First they were tested as possible whole sources, then as prefix cuts. Their actual pinned scopes are IncomingNode30–93 and Dispatch10–91. The original metadata then supplied exact full source hashes and cut endpoints; both full hashes and copied bytes matched. No failed attempt acquired a new whole proof source. The first namespace locator missed the MicroCFTA prefix; its empty result and corrected complete result are retained.

The scope-and-memo locator display was truncated, but its complete raw output and every matched source line were retained. Later exact definition/header cuts supply the used proof scope. Two guessed Canonical/KeyAncestry filenames were absent; actual definitions were located separately. A locator script stopped on absent EnumerationStorageProgress.lean after writing two cuts. Both cuts were recovered exactly into the ledger before sealing. The first union checker did not handle an empty locator-line list and stopped with KeyError; the full short diagnostic is retained. The repaired checker distinguishes an empty list from a range and verified every source record. No compiler command failed in the owner scope. One date-only dispatch was canceled when Root input arrived; it acquired no source bytes.
