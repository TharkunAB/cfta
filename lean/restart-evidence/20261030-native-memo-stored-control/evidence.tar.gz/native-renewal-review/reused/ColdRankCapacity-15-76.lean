local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Guard
local notation "Caller" => SourceCurrentAllocatedPartialState.State
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] [DecidableEq Node]

theorem constructed_initial_node_call
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    {initial finalCache : Cache.State SourceEqualityPartialConstraintKey.Key}
    {originals : List Guard}
    (history : SourceEqualityOriginalAllocationHistory.History initial finalCache originals)
    (valid : Cache.Valid initial)
    (expression : InternedNestedConstruction.Syntax Symbol Guard)
    (covered : ∀ guard ∈ SourceEqualityConstraintOrigins.guards expression, guard ∈ originals)
    (budget : Nat) :
    ∃ value heap, ∃ _built : InternedFreshOrdinaryConstruction.build expression [] empty = .done value heap,
    let seed : List Guard × Profile := (SourceEqualityConstraintOrigins.guards expression,
      ⟨heap.nodes.next, heap.edges.next, 0, InternedValueMassHeap.initialBound heap⟩)
    let request : NodeRequest := ⟨SourceCurrentAllocatedPartialInitialization.emptyValue finalCache, value⟩
    let output := envelope budget
      (SourceCurrentPositiveQuotientCount.count (request.inherited.payload.getD []) value)
      (InternedValueMass.value value) seed
    let joined := SourceCurrentInitialSelectionForecast.cover [output.2.2.2]
      (SourceCurrentOuterInitialSchedule.node output.1 budget seed).2
    let bits := SourceCurrentParentInitialRoom.roomBits joined
    let before := SourceCurrentAllocatedPartialInitialization.caller (bits + 2) finalCache heap
    let first : Phase (bits + 2) := .node output.1 request before
    let need := SourceCurrentOuterInitialFuel.phaseNeed budget first seed
    ∃ (result : Node) (after : Caller (bits + 2)), ∀ fuel, output.1 ≤ fuel →
      nodeCall fuel need need need need need need need need need budget request before = .done result after
 := by
  let alphabet := SourceEqualityConstraintOrigins.guards expression
  have allowed : SourceEqualityAnnotationConstruction.Allowed
      (fun guard => guard ∈ alphabet) expression :=
    SourceEqualityConstraintOrigins.allowed _ expression (fun _ member => member)
  obtain ⟨value, heap, built, physicalCarrier, _annotated⟩ :=
    SourceEqualityAnnotationConstruction.closed (fun guard => guard ∈ alphabet) expression allowed
  refine ⟨value, heap, built, ?_⟩
  let seed : List Guard × Profile := (alphabet,
    ⟨heap.nodes.next, heap.edges.next, 0, InternedValueMassHeap.initialBound heap⟩)
  let request : NodeRequest := ⟨SourceCurrentAllocatedPartialInitialization.emptyValue finalCache, value⟩
  let output := envelope budget
    (SourceCurrentPositiveQuotientCount.count (request.inherited.payload.getD []) value)
    (InternedValueMass.value value) seed
  let joined := SourceCurrentInitialSelectionForecast.cover [output.2.2.2]
    (SourceCurrentOuterInitialSchedule.node output.1 budget seed).2
  let bits := SourceCurrentParentInitialRoom.roomBits joined
  let before := SourceCurrentAllocatedPartialInitialization.caller (bits + 2) finalCache heap
  let first : Phase (bits + 2) := .node output.1 request before
  let need := SourceCurrentOuterInitialFuel.phaseNeed budget first seed
  let inventory := SourceCurrentAllocatedPartialInitialization.inventory expression value heap built
  change ∃ (result : Node) (after : Caller (bits + 2)), ∀ fuel, output.1 ≤ fuel →
    nodeCall fuel need need need need need need need need need budget request before = .done result after
  obtain ⟨context, identity, same, inheritedReady, available, closed, _original⟩ :=
    SourceCurrentAllocatedPartialInitialization.constructed (bits + 2) history valid
      expression covered value heap built formulas solver
  have initial : SourceCurrentAllocatedPartialInvariant.Context formulas solver inventory before
      SourceCurrentAllocatedPartialInitialization.globals := context
  have inherited : SourceEqualityConstraintAllocation.Ready
      before.checked.operations.constraints request.inherited := by
    change SourceEqualityConstraintAllocation.Ready
