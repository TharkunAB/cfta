from pathlib import Path
import hashlib,json
r=Path('/tmp/mcfta-native-renewal-control-review-20261030')
source=(r/'cuts/WHOLE-SourceCurrentAllocatedFiniteOrdinaryExecution.lean').read_text()
production=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA/SourceCurrentAllocatedNativeStoredTrace.lean')
assert not production.exists(), 'Root owns production; do not replace it'
helpers=source[source.index('private theorem trace_semantic'):source.index('private theorem node_cacheable')]
body=source[source.index('theorem verified '):source.index('/-- A completed literal node request')]
def replace(old,new):
 global body
 assert body.count(old)==1,(body.count(old),old[:100])
 body=body.replace(old,new)
replace('''theorem verified [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (fuel : Nat) {Output : Type} (control : Control Output) (before after : Checked width) (value : Output)
    (post : Machine Symbol Guard → Output → Prop)
    (trace : Trace fuel control before (.code (.pure value)) after)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap)
    (fields : Fields control before) (stored : Stored before.native)
    (certificate : CertifiedControl control before.native.machine post) :
    Stored after.native ∧ post after.native.machine value := by
''','''theorem clean_trace_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (fuel : Nat) {Output : Type} (control : Control Output) (before after : Checked width) (value : Output)
    (trace : Trace fuel control before (.code (.pure value)) after)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap)
    (fields : Fields control before) (stored : Stored before.native) (clean : Clean control) :
    Stored after.native := by
  classical
''')
replace('| refl => exact ⟨stored, certificate⟩','| refl => exact stored')
a=body.index('          | edgeBody request next =>');z=body.index('          | code code =>',a)
body=body[:a]+'''          | edgeBody request next =>
              have restClean := SourceEqualityNativeDemandBodyCode.body_clean request next before current rest one clean
              have nativeSame : current.native = before.native := by
                have same := SourceEqualityNativeDemandOperations.body_native request next before
                simpa only [show body request next before = .yielded rest current from one, Outcome.state] using same
              exact ih count (by omega) rest current after value tail advanced.1 advanced.2.2.1
                advanced.2.2.2 (nativeSame ▸ stored) restClean
'''+body[z:]
a=body.index('              | enter | read | optionalBinder | finishNode | finishEdge =>');z=body.index('              | node request next =>',a)
body=body[:a]+'''              | finishNode | finishEdge => cases clean
              | work job next | enter domain left right first second next | read name next =>
                  have same := Outcome.yielded.inj one
                  rcases same.1 with rfl
                  rcases same.2 with rfl
                  exact ih count (by omega) _ _ after value tail advanced.1 advanced.2.2.1
                    advanced.2.2.2 ⟨stored.nodes, stored.edges⟩ (clean _)
              | optionalBinder pair pending next =>
                  cases actual : SourceRecursiveIntersectionMaybeMu.maybeMu pair pending before.native.machine.heap with
                  | pending =>
                      simp only [step, SourceRecursiveIntersectionNative.step, actual, lift] at one
                      cases one
                  | done result heap =>
                      simp only [step, SourceRecursiveIntersectionNative.step, actual, lift] at one
                      have same := Outcome.yielded.inj one
                      rcases same.1 with rfl
                      rcases same.2 with rfl
                      exact ih count (by omega) _ _ after value tail advanced.1 advanced.2.2.1
                        advanced.2.2.2 ⟨stored.nodes, stored.edges⟩ (clean _)
'''+body[z:]
replace('''                      | direct actual =>
                          obtain ⟨key, known⟩ := node_cacheable (width := width) request certificate.1
                          simp only [lookupNode, known] at selected
                          cases selected
''','''                      | direct actual =>
                          simp only [step, SourceRecursiveIntersectionNative.step, selected, lift] at one
                          have same := Outcome.yielded.inj one
                          rcases same.1 with rfl
                          rcases same.2 with rfl
                          have chosenStored : Stored chosen := by
                            simpa only [selected] using lookupNode_stored before.native request stored
                          exact ih count (by omega) _ _ after value tail advanced.1 advanced.2.2.1
                            advanced.2.2.2 chosenStored (bodyCode_bind _ _ (compileNode_bodyCode actual) clean)
''')
replace('''                                  exact ih count (by omega) _ _ after value post tail advanced.1 advanced.2.2.1
                                    advanced.2.2.2 observed.2.1
                                    (certificate.2 result _ advanced.1.native.machine advanced.2.1 advanced.2.2.1 observed.2.2.2 observed.1)
''','''                                  exact ih count (by omega) _ _ after value tail advanced.1 advanced.2.2.1
                                    advanced.2.2.2 observed.2.1 (clean result)
''')
replace('''                                  have bodyCert := SourceCurrentAllocatedFiniteOrdinaryNode.node_certified request running.machine
                                    advanced.1.native.machine advanced.2.2.1
                                    (by rw [machineSame]; exact inputs.1.2.1) (by rw [machineSame]; exact inputs.1.2.2) certificate.1
                                  have built := ih inner (by omega) _ _ middle result (fun _ result => NodeCertificate request result)
                                    bodyTrace advanced.1 advanced.2.2.1 bodyFields runningStored bodyCert
''','''                                  have built : Stored middle.native ∧ NodeCertificate request result := by
                                    by_cases ordinary : NodeInputs request
                                    · have bodyCert := SourceCurrentAllocatedFiniteOrdinaryNode.node_certified request running.machine
                                        advanced.1.native.machine advanced.2.2.1
                                        (by rw [machineSame]; exact inputs.1.2.1) (by rw [machineSame]; exact inputs.1.2.2) ordinary
                                      exact SourceCurrentAllocatedFiniteOrdinaryExecution.verified inner _ _ middle result
                                        (fun _ result => NodeCertificate request result) bodyTrace advanced.1 advanced.2.2.1
                                        bodyFields runningStored bodyCert
                                    · refine ⟨ih inner (by omega) _ _ middle result bodyTrace advanced.1 advanced.2.2.1
                                        bodyFields runningStored (compileNode_bodyCode request), ?_⟩
                                      intro seen leftDomain rightDomain
                                      exact (ordinary ⟨seen, leftDomain, rightDomain⟩).elim
''')
replace('''                                  have available : Available middle.native.machine.heap result := frameInputs.choose_spec.2
''','')
a=body.index('                                  have continuationCert := certificate.2');z=body.index('              | edge request next =>',a)
body=body[:a]+'''                                  exact ih remaining (by omega) _ finished after value restTrace finishedReached.1
                                    finishedReached.2.2.1 finishedReached.2.2.2
                                    (finishNode_stored middle.native handle request result built.1 retained.1 built.2) (clean result)
'''+body[z:]
replace('''                              exact ih count (by omega) _ _ after value post tail advanced.1 advanced.2.2.1
                                advanced.2.2.2 observed.2.1
                                (certificate.2 result _ advanced.1.native.machine advanced.2.1 advanced.2.2.1 observed.2.2.2 observed.1)
''','''                              exact ih count (by omega) _ _ after value tail advanced.1 advanced.2.2.1
                                advanced.2.2.2 observed.2.1 (clean result)
''')
replace('''                              have bodyCert : CertifiedControl (.edgeBody request .pure) running.machine
                                  (fun _ result => EdgeCertificate request result) := ⟨certificate.1, fun _ _ _ _ _ _ law => law⟩
                              have built := ih inner (by omega) _ _ middle result (fun _ result => EdgeCertificate request result)
                                bodyTrace advanced.1 advanced.2.2.1 bodyFields runningStored bodyCert
''','''                              have built : Stored middle.native ∧ EdgeCertificate request result := by
                                by_cases ordinary : EdgeInputs request
                                · have bodyCert : CertifiedControl (.edgeBody request .pure) running.machine
                                      (fun _ result => EdgeCertificate request result) := ⟨ordinary, fun _ _ _ _ _ _ law => law⟩
                                  exact SourceCurrentAllocatedFiniteOrdinaryExecution.verified inner _ _ middle result
                                    (fun _ result => EdgeCertificate request result) bodyTrace advanced.1 advanced.2.2.1
                                    bodyFields runningStored bodyCert
                                · refine ⟨ih inner (by omega) _ _ middle result bodyTrace advanced.1 advanced.2.2.1
                                    bodyFields runningStored (fun _ => trivial), ?_⟩
                                  intro seen leftDomain rightDomain
                                  exact (ordinary ⟨seen, leftDomain, rightDomain⟩).elim
''')
replace('''                              have resident : EdgeResident middle.native.machine.heap result := frameInputs.choose_spec.2
''','')
a=body.index('                              have continuationCert := certificate.2');body=body[:a]+'''                              exact ih remaining (by omega) _ finished after value restTrace finishedReached.1
                                finishedReached.2.2.1 finishedReached.2.2.2
                                (finishEdge_stored middle.native handle request result built.1 retained.1 built.2) (clean result)

'''
assert 'certificate.' not in body
prefix='''import MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryExecution
import MicroCFTA.SourceEqualityNativeDemandBodyCode

/-!
# Conditional native memo certificates through actual mixed source traces

UNCOMPILED source-only draft.
The proof uses the actual completed physical trace.
It does not prove that a future request completes.
-/
namespace MicroCFTA.SourceCurrentAllocatedNativeStoredTrace
open Cache InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand SourceEqualityNativeDemandBodyCode
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace Receipt)
open SourceCurrentAllocatedNativePhysicalCompletion (Good)
open SourceCurrentAllocatedNativeFieldClosure (Fields)
open SourceEqualityRequiredSemanticCache (SemanticReady)
open SourceCurrentAllocatedFiniteOrdinaryStored SourceCurrentAllocatedFiniteOrdinaryCode
open SourceCurrentAllocatedFiniteOrdinaryExecution (CertifiedControl)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Checked" => SourceEqualityNativeDemand.State
variable {width : Nat}

'''
corollaries='''/-- A completed literal node request retains conditional certificates without a domain gate. -/
theorem node_trace_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (request : NodeRequest Symbol Guard) (before after : Checked width) (fuel : Nat) (value : Value Symbol Guard)
    (trace : Trace fuel (.code (requestNode request.domain request.left request.right)) before (.code (.pure value)) after)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap) (stored : Stored before.native) :
    Stored after.native :=
  clean_trace_stored fuel _ before after value trace good semantic (fun _ => trivial) stored (fun _ => trivial)

/-- A completed literal edge request retains conditional certificates without a domain gate. -/
theorem edge_trace_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (request : EdgeRequest Symbol Guard) (before after : Checked width) (fuel : Nat) (value : EdgeValue Symbol Guard)
    (trace : Trace fuel (.code (requestEdge request.domain request.left request.right)) before (.code (.pure value)) after)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap) (stored : Stored before.native) :
    Stored after.native :=
  clean_trace_stored fuel _ before after value trace good semantic (fun _ => trivial) stored (fun _ => trivial)

/-- An actual returned node receipt supplies its own completed physical trace. -/
theorem node_receipt_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (request : NodeRequest Symbol Guard) (before after : Checked width) (fuel : Nat) (value : Value Symbol Guard)
    (post : Machine Symbol Guard → Value Symbol Guard → Prop)
    (receipt : Receipt fuel (.code (requestNode request.domain request.left request.right)) before value after post)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap) (stored : Stored before.native) :
    Stored after.native :=
  node_trace_stored request before after fuel value receipt.trace good semantic stored

/-- An actual returned edge receipt supplies its own completed physical trace. -/
theorem edge_receipt_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (request : EdgeRequest Symbol Guard) (before after : Checked width) (fuel : Nat) (value : EdgeValue Symbol Guard)
    (post : Machine Symbol Guard → EdgeValue Symbol Guard → Prop)
    (receipt : Receipt fuel (.code (requestEdge request.domain request.left request.right)) before value after post)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap) (stored : Stored before.native) :
    Stored after.native :=
  edge_trace_stored request before after fuel value receipt.trace good semantic stored

end MicroCFTA.SourceCurrentAllocatedNativeStoredTrace
'''
out=prefix+helpers+'/-- Actual clean source traces preserve every conditional native memo certificate. -/\n'+body+corollaries
p=r/'NativeStoredTrace-v1-UNCOMPILED.lean';assert not p.exists();p.write_text(out);p.chmod(0o444)
(r/'DRAFT-V1-METADATA.json').write_text(json.dumps(dict(source=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),lines=len(out.splitlines()),bytes=p.stat().st_size,production_absent_before_write=True,status='UNCOMPILED; owner has not run Lean',base_source='cuts/WHOLE-SourceCurrentAllocatedFiniteOrdinaryExecution.lean',base_source_sha256=hashlib.sha256(source.encode()).hexdigest(),new_public_declarations=['clean_trace_stored','node_trace_stored','edge_trace_stored','node_receipt_stored','edge_receipt_stored']),indent=2)+'\n')
print(p,len(out.splitlines()),p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
