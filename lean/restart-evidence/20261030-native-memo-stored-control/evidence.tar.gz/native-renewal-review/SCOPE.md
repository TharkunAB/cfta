# Native renewal between boundary episodes

Root assigned this fresh source-only scope at21:31 CET. The owner writes only here. Root owns compiler/evaluator/native/Git/network/board/production/publication. Do not spawn.
Follow one actual ordinary/native rewrite path, both Native and Prepared. Locate changed physical handles, actual memo/interner constraints and the next boundary-entry gates. Do not redo fixed-handle decrease or completed intersection. Draft only a law that removes a real gate. Preserve raw multiplicity vs key cardinality, and slot vs native counters. No runtime/Haskell claim without an admitted execution.
At most TWO newly named OLD whole modules. Name each before acquiring. Retain exact bounded source ranges and cumulative unions. Frozen source reuse requires source/copy identity pins.
Keep all prior bundles immutable. Preserve versions, incidents and complete contracts. Freeze every file and halt writes.

Root22:02 requested concrete clean-control conditional Stored preservation and Trace/Receipt bridges. Root22:03 explicitly approved a THIRD named whole OLD source, FiniteOrdinaryExecution271L. Root22:07 requested the actual checked initializer companion. Root22:11/22:12 reports strict probes passed exact V1/V2 with no proof repairs. Owner retains UNCOMPILED labels and does not run Lean. Root owns installed V3 and aggregate verification/publication.
