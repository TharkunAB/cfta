# Native renewal and conditional memo certificates

## Result

The immediate deliverable is `NativeStoredTrace-v2-UNCOMPILED.lean`,291L/22866B, SHA256 `e18b90153000ba98d646a54ca0bf81f57a71ff37a8923297832bbc3c180279d9`. It has six complete public preservation proofs. There are no placeholders.
Root reports exact V1 and V2 strict capped probes passed with empty output and no proof repair. V1 SHA256 is `0369d2366535b817dda3b7ea4f8c0e4b179bc88969db14f6d028d8e6cd652cec`. Root reports Lean4.34.1 with warningAsError/linter.all, max/high4GiB and swap0. The owner ran no compiler. The immutable filenames and UNCOMPILED lines preserve the original source-only status. Root owns installed V3, which removes only the status line, and all aggregate checks/publication.
The proposed production module is `MicroCFTA.SourceCurrentAllocatedNativeStoredTrace`. Its path was absent before V1 generation. The owner did not write production files.

## What the six laws establish

`PUBLIC-CONTRACTS.md/json` retain every full public header, import, local notation, implicit width, type parameter and equality instance.
`clean_trace_stored` consumes an actual completed physical `Trace`, initial physical Good, SemanticReady, Fields, conditional native Stored, and the existing syntactic Clean property. It proves conditional native Stored after that trace. It has no operand-domain, model, future callback, future completion or arbitrary mixed-verification supplier.
`node_trace_stored` and `edge_trace_stored` specialize the result to literal requestNode/requestEdge. Their source Clean and Fields facts are constructed internally. They retain Good, SemanticReady and initial Stored. They do not require NodeInputs/EdgeInputs.
`node_receipt_stored` and `edge_receipt_stored` consume the existing actual physical Receipt and use its own trace. The arbitrary original receipt postcondition remains an input. These are native physical receipts, not enumeration head receipts.
`initial_clean_trace_stored` uses the actual `SourceCurrentAllocatedPartialInitialization.checked width cache heap` definition. It constructs initial Stored with `initial_stored width ⟨heap,Cache.emptyState⟩`. It retains an actual completed Clean Trace, Good, SemanticReady and Fields. It removes the entry Stored supplier for this existing empty-native-memo initializer.
The actual initializer is pinned at PartialInitialization36–38. It keeps the supplied equality interner through `operations cache` and starts the two native thunk tables empty. The initializer companion does not require that equality interner to be empty.
V2 adds only the initializer import and final law. The five older headers and proof bodies are byte-identical to V1. This identity was checked before sealing.

## Three different cache predicates

`SourceCurrentAllocatedFiniteOrdinaryStored.Stored` certifies returned NATIVE node/edge thunk cells. Its NodeCertificate is conditional: seen=[] and recursive Node-domain for both operands imply Node-domain for the result and ordinary height bounded by EACH operand. EdgeCertificate has the corresponding forest bounds.
`SourceCurrentAllocatedNativeScopeCache.Scoped` certifies only syntactic result scope through NodeLaw/EdgeLaw. Context.ready.scopedCache has this type. It is not the finite ordinary structural certificate.
`SourceCurrentMemoMergeEffects.Stored` certifies the separate MERGE memo. Context.stored has this type. It is not native Stored.
Context.ready.good is physical `SourceCurrentAllocatedNativePhysicalCompletion.Good`. Its source comment and fields explicitly contain no semantic result receipt. This review does not infer finite ordinary certificates from abstract Good or scopedCache.
The new proof derives the native certificate by following the actual execution instead. It can provide a new invariant for original reachable calls. It does not claim that every externally supplied warm Context already contains that invariant.

## Why the mixed proof closes

Existing initial_stored, advance_stored, lookupNode_stored, lookupEdge_stored and demandNode/Edge_stored require no operand-domain premise. Only actual finishNode/finishEdge publication needs a certificate at the literal evaluating owner.
For an owner outside NodeInputs/EdgeInputs, its conditional certificate follows by contradiction from the same empty-seen/domain antecedents. This does not imply that its nested requests are outside the finite ordinary domain.
For an ordinary empty-seen owner, the proof isolates the actual body with `SemanticTraceReadback.bind_inverse`. Existing FiniteOrdinaryExecution.verified and node_certified certify that body independently of its parent. The edge case uses the existing certified checked edge-body rule.
For a nonordinary owner, the proof applies the smaller-fuel Clean induction to its actual body. It then supplies the vacuous owner certificate. Nested ordinary requests still use the real structural proof.
The existing Frames.node_body_cell/edge_body_cell retain the exact evaluating cell through the isolated body. They need the actual body Trace, physical cache validity and the running-cell equation. They need no operand-domain or result-language certificate.
The proof reuses the existing BodyCode/Clean invariant. It does not introduce a duplicate syntax predicate. Source body code excludes literal finish frames; native execution inserts those frames, which the proof handles with exact owner retention and publication.
Direct node memo bypass remains supported. Its compiled body and continuation are Clean, so the smaller-fuel induction applies. Warm hits retain the exact captured request and existing Stored certificate.
Work/enter/read/optionalBinder retain native memo tables while they update or retain the machine. Checked edge-body calculation updates operations without changing native memo tables; body_clean supplies the returned Clean code. Failed or blocked one-step branches cannot occur inside the supplied completed physical Trace.
This is postcondition preservation. No theorem here proves that a future request completes. No general Stored postcondition for every arbitrary yielded/failed/blocked prefix is claimed by these completed-trace laws.

## Actual nested-domain propagation

Compile16–85 was checked directly. The `.reset` branch explicitly requests the same operands at emptyDomain. Union branches request each member against the other operand with the SAME domain. A nonordinary Union root can therefore reach an empty-seen ordinary nested owner. Treating every nested certificate as vacuous would be invalid.
Mu compilation enters an extended domain and requests the two bodies. Reference compilation reads a binding before the next literal request. These actual instructions are admitted by BodyCode and handled by the mixed preservation induction.
The old finite-domain Certified grammar rejects enter/read/optionalBinder and raw finishes. Its verified theorem alone therefore could not simply be applied to an arbitrary mixed root. The new proof uses it only on the isolated ordinary subbody where its actual gates hold.

## One concrete enumeration handle-write chain

Native ordinary entry enters once, captures the entered cache, and scans actual selected edges through NativeContinuations.run. Prepared ordinary scanning first uses SelectedPreparation/SelectedValue and then invokes the same NativeContinuations.run at the returned caller. Native derives the parent through decoded stored residency; Prepared obtains Available for the prepared parent. These gates are distinct.
The common path is CapturedEdge.run → SelectedEdge.run → CachedOwn.prepare → ChildTraversal → ChildDispatch. A terminal suspended child enters CachedTerminalAdapter: TerminalPrefix joins its referenced slots, CachedFold merges recorded sources, and IncomingCacheAdapter/IncomingNode installs the incoming child at the chosen winner.
IncomingNode30–93 decodes an existing old handle, executes literal requestNode emptyDomain incoming old, optionally runs EnabledEmpty, encodes its replacement, writes that handle with incomingScs++oldScs, and inherits ancestry. Without an old handle it encodes the incoming value directly. A returned replacement can reuse an existing constructor handle or install a newly interned one; no concrete admitted renewal witness is asserted here.
CachedFold can also call Dispatch10–91. That query intersects the decoded source/target records and uses Assimilation.finish after optional EnabledEmpty. Both writer paths retain raw concatenated buckets and inherited/assimilated histories.
IncomingNodeResources.run_complete_resources supplies the actual caller Context, pending/root/storage/readiness and resource gates. Its output includes Available/closed replacement, encode/lookup equations, the exact stored write, and Post. It does not supply recursive finite ordinary operand domains or identify the replacement handle with either old handle.
The new native Receipt laws cover one actual completed native request. Composition through EnabledEmpty, every other caller writer, and the full caller resource interface must still carry this native Stored invariant. This review does not label that larger composition complete.

## Physical identities and existing constraints

RecursionKey.node is a constructor-value handle stored in the enumeration slot. It differs from the enumeration slot counter and from the native thunk-cell handle returned by native lookupNode.
SourceRecursiveIntersectionMemo.requestKey uses the domain identity and ordered tagged operand references. Thunk publication and demand retain exact requests. Busy demands remain blocked. Completed hits reuse their exact captured results. These per-request rules do not supply an original bound on all later operand pairs.
Constructor makeEdge keys use symbol, child references and guard. makeNode filters empty children, canonicalizes edge identities and interns the resulting row-identity list. nodeStep_replay reuses the immutable record for the SAME key under its Valid/Grows gates. Different child or row identities can still form different keys. No finite original handle carrier is inferred from interning alone.
The finite ordinary theorem fully read here constructs an actual completed request and bounds returned height by both operands. Its real gates include Good, SemanticReady, conditional native Stored, Idle, available operands, BOTH recursive Node-domain premises and actual WordRanges. The new preservation proof addresses its native Stored supplier on actual initialized/reachable request chains. It does not remove the operand-domain or WordRanges gates.

## Episode gates and remaining original capacity

The exact checked boundary budget header retains RequiredCache.Ready, available/closed decoded/encoded value, actual repeated-check false and Action.prepare/action observations, recursiveBoundary=true, initial StatePaths, Canonical and the stored slot. It preserves the physical handle/heap and strictly consumes a shape for that fixed handle.
Canonical means canonical suspended tries in every stored value. KeyAncestry bounds historical key.tries membership, not physical key.node identities. enter_key_ancestry explicitly needs StatePaths AND Canonical AND prior KeyAncestry. StatePaths alone must not be substituted for these gates.
Raw SCS concatenation remains distinct from canonical key cardinality after duplicate erasure. Slot allocation and native constructor allocation remain distinct. This memo proof gives neither a raw multiplicity bound nor a bound on neutral-step count.
The source investigation also found a pre-head writer. Action.prepare17–42 narrows first and returns representative/setValue with a new encoded handle when it differs from oldHandle. This occurs before head/fragment construction. OuterNarrow keeps Mu and known raw type positions unchanged, but other values pass through NativeView.narrowAt, which exposes rows and constructs their filtered node.
Prepared SelectedValue.run separately unfolds Mu once or exposes Union rows and constructs a node. It changes the native heap without writing enumeration slots; SelectedValueCaller.advance installs that heap before the head scan. Its new child records can later feed stored child slots. This cannot be called neutral merely from the recursiveBoundary=true retention law.
These are exact potential-write branches and gate distinctions. This scope did not construct a full admitted execution with a fresh handle there. It did not prove that such rewrites are productive, that chosen-term cost charges every rewrite, or that an arbitrary earlier alternative has a chosen target assignment. Root assigned the original renewal measure to a separate review.
The sufficient ORIGINAL recursive depth for the intended ordered prefix remains open. Earlier alternatives, staged children, ordinary/native renewal and raw work must still be controlled. The new local postcondition is not global coverage, termination, or public/Haskell correspondence.

## Scope, incidents and write halt

The original allowance was TWO new whole old proof modules. They were named before reading: FiniteOrdinaryFinite106L and RecursiveIntersectionNative132L. Root explicitly approved one named exception at22:03 CET for FiniteOrdinaryExecution271L. The complete three source copies are retained. No fourth whole or near-whole source was acquired. Every other fresh proof source is bounded; the largest non-frozen union is89/165 lines. Frozen source reuses match full current source hashes and exact retained cut bytes.
The acquisition ledger has137 records over73 sources, including declaration-only locator lines and historical report reuse. SOURCE-UNIONS records exact cumulative endpoints and source hashes. Source-only read errors, guessed missing files, a truncated locator display and its retained full raw output, and the repaired empty-locator metadata error are recorded in INCIDENTS. No owner compiler failure exists.
Memory registry guidance was used only for scope and correspondence discipline. Its old whole-worker-open status was superseded by current Root reports. No current theorem meaning or probe result is inferred from memory.
V1 was fully displayed. V2's entire five-law body was checked identical to V1; its import and complete initial companion were displayed. The final complete V2 and all public contracts/report are displayed before sealing. Root independently read V1 and exact V2 changes.
No Haskell file was read, edited, executed or tested. No Haskell fix, runtime nontermination claim or implementation defect is established for FINDINGS.
All final payloads are pinned and made read-only, including metadata, manifest, pins and seal. The owner stops writes at handoff. Root owns later checks, repairs, production and publication outside this directory.
