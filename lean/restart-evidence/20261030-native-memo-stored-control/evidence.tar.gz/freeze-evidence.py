from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,subprocess

r=Path('/tmp/mcfta-native-memo-stored-control-20261030')
assert not (r/'FROZEN.json').exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='ba46fbf1e2f2a41ecf1804334180f98c405dcf2e'
assert not subprocess.check_output(['git','status','--porcelain=v1'])
publication=json.loads((r/'checkpoint-publication.json').read_text())
assert publication['head']==head and publication['readback_exact'] and publication['tracking_exact']
summary=json.loads((r/'verification-summary.json').read_text())
assert summary['commands']==summary['passed']==7 and summary['failed']==0
assert summary['public_checks']==1195 and summary['all_new_axioms_standard']
assert json.loads((r/'owned-verification.json').read_text())['status']=='pass'
for p in r.iterdir():
    if p.is_dir() and not p.name.startswith('prior-') and (p/'started-command.json').exists():assert (p/'report.json').exists()
rows=[]
for p in sorted(r.rglob('*')):
    if p.is_file():
        assert not p.is_symlink();b=p.read_bytes()
        rows.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
seal={'created_at':datetime.now(ZoneInfo('Europe/Stockholm')).isoformat(),'write_halt':True,'goal_turn':'progress','full_goal_complete':False,'goal_controller_observed_status':'blocked','work_continues_under_user_instruction':True,'source_head':'4adf96c3fdd959a255c4b888bd40bd65b0822588','docs_head':head,'main_head':'bd5a406a6a3f84b7e3ae0906082783911509df83','latest_prior_board_sequence':783,'compiler_commands':7,'passed_commands':7,'repaired_failed_commands':0,'input_snapshots':12,'new_laws':6,'public_checks':1195,'public_definitions':116,'next_source_review_status':'frozen UNCOMPILED, all payloads retained','payload_count_excluding_seal':len(rows),'payloads':rows}
(r/'FROZEN.json').write_text(json.dumps(seal,indent=2)+'\n')
for p in r.rglob('*'):
    if p.is_file():p.chmod(p.stat().st_mode&~0o222)
assert all(not(p.stat().st_mode&0o222) for p in r.rglob('*') if p.is_file())
print(json.dumps({'sealed':True,'payloads_excluding_seal':len(rows),'raw_bytes_excluding_seal':sum(a['bytes'] for a in rows),'source_head':seal['source_head'],'docs_head':head}))
