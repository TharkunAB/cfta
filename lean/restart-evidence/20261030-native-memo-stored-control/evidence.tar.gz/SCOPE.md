# Actual native memo preservation scope

Continue the full original-input formalization. The sufficient recursive capacity gap remains open.
Follow actual native compiled control and its conditional finite ordinary memo invariant.
Read old bodies in named bounded sections. Root owns production, checks, Git, board and packaging.
The source reviewer owns only /tmp/mcfta-native-renewal-control-review-20261030.
Do not assume future verified traces, Complete, coverage or finite carriers.
No Haskell source change or defect is established.
Keep existing public laws and all original native inputs exact.
All compiler commands remain serial under the existing four GiB, zero swap, five minute cap.
The backend goal marker remains blocked despite explicit resumed work. No pause or completion is claimed.
