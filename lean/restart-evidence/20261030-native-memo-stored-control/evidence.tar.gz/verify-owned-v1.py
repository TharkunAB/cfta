from pathlib import Path
import hashlib,json,sys

original=Path('/tmp/mcfta-native-memo-stored-control-20261030')
r=Path(sys.argv[1]) if len(sys.argv)>1 else original
out=Path(sys.argv[2]) if len(sys.argv)>2 else r
out.mkdir(exist_ok=True)
repo=Path('/home/tritlo/Code/mcfta')
def sha(b):return hashlib.sha256(b).hexdigest()
def read(path):return path.read_bytes()
def owner(name,mh,ph):
    base=r/name
    assert sha(read(base/'MANIFEST.json'))==mh
    assert sha(read(base/'pins.json'))==ph
    manifest=json.loads((base/'MANIFEST.json').read_text())
    rows=manifest['files']
    actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    assert actual=={a['path'] for a in rows}|{'MANIFEST.json','pins.json'}
    for a in rows:
        p=base/a['path'];b=read(p)
        assert not p.is_symlink() and not(p.stat().st_mode&0o222)
        assert len(b)==a['bytes'] and sha(b)==a['sha256'],p
    assert all(not(p.stat().st_mode&0o222) for p in base.rglob('*') if p.is_file())
    for path,h in json.loads((base/'pins.json').read_text())['pins'].items():assert sha(read(base/path))==h
    return base,{'payloads':len(rows),'regular_files':len(actual),'readonly':True}
native,native_result=owner('native-renewal-review','47b6774915970f51a47ae360756455563910d71f44ee49da7b1ac165ed0a76d2','1a83b3f0dbc70002b0b047b45c2bb41bd4bb2369f7ecc3b38f11da1e64b9f2d5')
public,public_result=owner('public-review','9e4de3b20baeb1664749e213a9592b8654b7f5b74920032db4893871686edb02','bd6d8ed34a7fcf52d59b14f35533dc38b497fd519f6683442cea476d81db8353')
maps=json.loads((r/'frozen-manifest-map.json').read_text())
rows=json.loads((native/'acquisitions.json').read_text())
for a in rows:
    source=Path(a['source'])
    if source.is_relative_to(repo):b=read(source)
    else:
        assert source==Path('/tmp/mcfta-finite-prefix-control-20261030/ordinary-renewal-review/REPORT.md')
        b=read(r/'prior-source-reports/ordinary-renewal.md')
    assert len(b)==a['bytes'] and sha(b)==a['sha256'] and len(b.splitlines())==a['lines']
    ls=b.splitlines(keepends=True)
    if 'actual' in a:
        lo,hi=a['actual'];expected=b''.join(ls[lo-1:hi])
    else:expected=b''.join(ls[i-1] for i in a['actual_lines'])
    copied=read(native/a['copy']);assert copied==expected and sha(copied)==a['copy_sha256']
    if 'frozen_bundle' in a:
        encoded=read(r/maps[a['frozen_bundle']]);assert sha(encoded)==a['frozen_manifest_sha256']
        entries=json.loads(encoded)['files']
        if 'frozen_copy' in a:entry=next(e for e in entries if e['path']==a['frozen_copy'])
        else:
            assert source.name=='REPORT.md';entry=next(e for e in entries if e['path']=='REPORT.md')
        assert entry['sha256'] in {sha(b),sha(copied)}
        assert entry['bytes'] in {len(b),len(copied)}
assert len(rows)==137
for a in json.loads((public/'reuse-ledger.json').read_text()):
    source=Path(a['source_path']);assert source.is_relative_to(original)
    source=r/source.relative_to(original);b=read(source);copied=read(public/a['copy'])
    assert b==copied and len(b)==a['source_bytes'] and sha(b)==a['source_sha256']==a['copy_sha256']
    assert len(b.splitlines())==a['source_lines']
    assert sha(read(source.parent/'MANIFEST.json'))==a['frozen_manifest_sha256']
oldcuts=json.loads((public/'old-source-cut-ledger.json').read_text())
for a in oldcuts:
    p=Path(a['source_path']);assert p.is_relative_to(repo);b=read(p)
    assert sha(b)==a['source_sha256'] and len(b.splitlines())==a['source_lines']
    lo,hi=a['actual'];cut=b''.join(b.splitlines(keepends=True)[lo-1:hi])
    assert cut==read(public/a['copy']) and sha(cut)==a['copy_sha256']
for a in json.loads((r/'root-inspected-source-pins.json').read_text()):
    b=read(repo/a['path']);assert len(b)==a['source_bytes'] and sha(b)==a['source_sha256']
    lo,hi=a['actual'];cut=b''.join(b.splitlines(keepends=True)[lo-1:hi])
    assert cut==read(r/a['cut']) and sha(cut)==a['cut_sha256']
result={'status':'pass','native_review':native_result,'public_review':public_result,'native_source_records':len(rows),'public_old_cuts':len(oldcuts),'root_and_public_complete_contract_read':True,'no_external_historical_tmp_required':True}
(out/'owned-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
