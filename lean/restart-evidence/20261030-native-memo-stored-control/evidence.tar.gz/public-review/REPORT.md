# Native conditional cache preservation: public contract review

Result: PASS. No source or public contract defect was found.
This is a source review. Root owns compilation and publication.

## Exact reviewed inputs

The new module is SourceCurrentAllocatedNativeStoredTrace.lean.
Its SHA256 is e12f40e084180ab303d4d06301ecec61f927865c0cfd141db17daeed563da8a4.
All 290 lines and 22,836 bytes were read in four complete chunks.
All six public declarations were read against their complete expanded output.
The new public tail has 166 lines and 11,037 bytes.
Its SHA256 is 1a67ffacf2c3807f753c1b496dc259ddbe43fa9d18d03c760424cf8fa4420fd3.
The complete tail was read in three chunks. No displayed chunk was truncated.
The read ledger records exact ranges, copy hashes and complete-read status.

All three supplied input manifests were verified before reuse.
Their hashes are:

- Source: ac9d9f610269dbe33543c0f843cd9acfce9d90ad7d9ce66f25f3bd5e10b0b216.
- Tail: 3b27cd9b8aecefd2edd97169a2ffbb2c9c7308f0728a266772dbcfc314c5c8b3.
- Extra definitions: b9492d8a438e20675c08853f7a88ba42a294b0feaa2987c02ed0624999505d64.

Nine supplied old cuts cover 130 distinct lines in eight old modules.
No old whole or near-whole source was acquired.
The cumulative source unions and full source identity pins are retained.
No compiler, evaluator, native command, Git, network or board operation ran.
No production file changed. No child was spawned.

## Meaning of Stored

Returned quantifies over every cell whose phase is returned.
It relates that cell's actual stored request to its actual returned result.
Stored applies NodeCertificate and EdgeCertificate to the two native tables.

Each certificate is conditional. Its antecedents are an empty seen list and
both operands in the finite ordinary domain. Under those antecedents, the
result remains in that domain. Its height is at most each operand's height.
The edge certificate uses complete child forests and edge height.

The finite ordinary domain contains Empty and ordinary nodes recursively.
It excludes Mu, explicit union and reference records at every descendant.
A root that merely has ordinary node form need not satisfy this domain.
If an antecedent fails, that owner's certificate imposes no result bound.
The theorem does not produce domain membership for recursive operands.
It does not give an unconditional height bound for all native results.

## Six public statements

| Declaration | Exact substantive gates and result |
| --- | --- |
| clean_trace_stored | A supplied completed physical Trace, Good, SemanticReady, Fields, entry Stored and Clean imply final Stored. |
| node_trace_stored | A completed literal requestNode Trace, Good, SemanticReady and entry Stored imply final Stored. Fields and Clean are derived for the literal request. |
| edge_trace_stored | The same preservation for a completed literal requestEdge Trace. |
| node_receipt_stored | The actual literal node Receipt supplies its trace. Good, SemanticReady and entry Stored remain explicit. |
| edge_receipt_stored | The actual literal edge Receipt supplies its trace. Good, SemanticReady and entry Stored remain explicit. |
| initial_clean_trace_stored | A completed clean Trace starts at literal PartialInitialization.checked. Good, SemanticReady and Fields remain explicit. Entry Stored is derived internally. |

The initial law uses checked width cache heap. The supplied definition sets
its native state to Thunks.initial width with the supplied heap and an empty
machine cache. The separate cache parameter supplies operations. The law
uses initial_stored internally. It has no entry Stored argument or initial
state equality argument. It does not derive the other starting-state gates.

All six expanded signatures match the source. No NodeInputs, EdgeInputs,
body certificate, Complete, desired result equality, recursive worker IH,
coverage oracle or future completion supplier appears as an extra public gate.
A completed observed Trace or Receipt remains an explicit premise.
The Receipt postcondition is arbitrary. These proofs use its trace field.
They do not require a new semantic result postcondition from the caller.

## Proof path

Clean reuses the existing BodyCode predicate. BodyCode allows the compiled
source effects and requests. It excludes explicit finishNode and finishEdge
frames in the source continuation. The proof does not add a new interpreter
or a replacement cache model.

The induction follows the supplied physical trace and decreases its fuel.
Work, enter, read and completed optionalBinder branches retain the native
memo predicates while the machine can change. Checked edge-body expansion
uses body_clean. Its native state remains equal at that step.
A direct node dispatch reuses compileNode_bodyCode and bodyCode_bind.
Warm cache observations retain the existing Stored property.
Absent and busy dispatches cannot supply the completed step used here.

Each cold owner is isolated at its actual body and actual finish frame.
For true NodeInputs or EdgeInputs, the existing verified proof establishes
the result certificate and Stored together on that isolated body.
For false inputs, the smaller-fuel Clean induction retains Stored, and the
owner certificate follows from the contradiction in its antecedents.
This split is local to each owner. A nonordinary outer request does not make
all nested owner certificates vacuous. Ordinary nested requests still take
the existing verified branch when their own antecedents hold.

The actual evaluating owner is retained with Frames.node_body_cell or
Frames.edge_body_cell. The proof reads the literal finish step and updates
Stored for that same request, result and physical owner. It then continues
on the remaining trace. It does not assume a completed future body or a
separate mixed-body verifier as a caller-supplied certificate.

## Public output and boundaries

All six new axiom reports were read. Each lists only propext, Classical.choice
and Quot.sound. The tail contains exactly the six expected new signatures.

Root reports seven capped compiler commands, all passing, and 12 snapshots.
Root reports default and strict Audit at 4,746 jobs and 82,987 dependencies.
Root reports public verification at 1,195 checks and 116 definition prints.
The supplied prefix receipt records the complete old 4,837,716 bytes as an
exact prefix of the new 4,848,753-byte public output. The new full output
SHA256 is a6b8e9e53bf02426fcbc6159c5a2a1337cbe6d3c578ca4b7d131674619cc9282.
This review independently checks the complete new tail and source contracts.
It does not rerun compilation or reread the complete old public prefix.

The result is a cache preservation law after completed checked calls.
It does not prove that a future request returns or that every intermediate
failed, blocked or yielded prefix has the claimed final-state property.
It does not preserve the table contents by equality. New returned entries
can be added, and all returned entries must satisfy the conditional law.
It does not bound native allocations, handle renewal or neutral steps.
It does not prove sufficient ORIGINAL recursive capacity or finite prefix
coverage. It does not close public adapter or Haskell correspondence.
No Haskell defect, fix, repair candidate or runtime termination result is
established by this review. The full original objective remains open.
