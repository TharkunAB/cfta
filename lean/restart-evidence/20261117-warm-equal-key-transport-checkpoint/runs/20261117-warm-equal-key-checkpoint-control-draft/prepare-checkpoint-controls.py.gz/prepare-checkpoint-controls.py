from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/tritlo/Code/mcfta')
BASE = ROOT / 'lean/restart-evidence'
WORK = Path(__file__).resolve().parent
assert WORK == BASE / '20261117-source-finite-completion-probe-work'
PUBLIC = BASE / '20261117-warm-equal-key-transport-publication'
ARCHIVE = '20261117-warm-equal-key-transport-checkpoint'
BOARD_PREFIX = 'current-board-warm-equal-key-transport-'
SHA = lambda data: hashlib.sha256(data).hexdigest()
GIT = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
read = lambda path: json.loads(path.read_text())
bindings = read(WORK / 'prior-bindings.json')
prior = bindings['prior_checkpoint']
commit = read(WORK / 'SOURCE-COMMIT.json')
code = commit['source_commit']
assert re.fullmatch(r'[0-9a-f]{40}', code)
assert commit['parent'] == prior
assert GIT('rev-parse', 'HEAD').decode().strip() == code
assert GIT('rev-parse', code + '^').decode().strip() == prior
assert GIT('branch', '--show-current').decode().strip() == 'formalize'
assert not GIT('status', '--porcelain', '--untracked-files=no')
report = read(PUBLIC / 'checked.json')
verified = read(WORK / 'PUBLICATION-VERIFIED.json')
assert verified['actual_terminal'] and verified['pins_unchanged']
assert verified['checks'] == report['checks']
assert len(report['checks']) == 5
assert [item['total_axiom_reports'] for item in report['checks']] == [669, 1, 264, 669, 669]
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['nonstandard_axioms']
           and not item['sorryAx'] for item in report['checks'])
for key, expected in {'source_files': 6251, 'direct_audit_imports': 5251,
                      'individual_reports': 669, 'independent_reports': 264,
                      'fresh_resource_component_reports': 1,
                      'inherited_resource_component_reports': 461,
                      'resource_and_component_probes': 462,
                      'fresh_owner_preflight_reports': 0,
                      'actual_publication_strict_reports': 1,
                      'new_modules': 0, 'new_public_theorems': 1,
                      'new_private_component_reports': 0, 'new_private_predicates': 0,
                      'new_theorem_reports': 1, 'replaced_old_reports': 0}.items():
    assert report[key] == expected, key
assert [(item['axiom_groups'], item['axiom_free_reports']) for item in report['checks']] == [
    (663, 6), (1, 0), (261, 3), (663, 6), (663, 6)]
assert not report['owner_recompiled_in_publication_strict_gate']
assert report['fresh_owner_preflight_evidence'] is None
assert report['inherited_owner_preflight_evidence']['reports'] == 264
assert not report['inherited_owner_preflight_evidence']['fresh_this_batch']
assert report['inherited_owner_preflight_evidence']['included_in_inherited_461']
for key in ['warm_equal_key_full_pattern_transport_proved',
            'warm_equal_key_full_pattern_transport_physical_identity_only',
            'old_full_pattern_domain_and_height_identity_proved',
            'no_new_semantic_Profile_or_Gamma_supplier',
            'whole_worker_program_slots_fixed_marks_proved']:
    assert report[key], key
for key in ['earlier_source_family_semantic_IH_discharged', 'every_cell_joint_query_attachment_proved',
            'inherited_cell_semantic_chronology_proved', 'mixed_qualified_profile_height_orientation_derived',
            'independent_query_inherited_warm_tables_proved', 'warm_across_independent_queries_proved',
            'all_native_inhabitance_proved', 'source_type_marker_class_consistency_proved',
            'joint_finite_completion_proved', 'compiled_haskell_correspondence_proved', 'haskell_changed']:
    assert not report[key], key
pins = read(PUBLIC / 'source-pins.json')
for name, digest in pins.items():
    assert SHA((ROOT / name).read_bytes()) == digest, name
source_pins = {name: digest for name, digest in pins.items()
               if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
actual = {str(path.relative_to(ROOT)) for path in (ROOT / 'lean/MicroCFTA').glob('*.lean')}
assert len(source_pins) == 6251 and actual == set(source_pins)
assert verified['reverified_pins'] == len(pins)
for name in commit['files']:
    assert GIT('show', code + ':' + name) == (ROOT / name).read_bytes(), name
transport = 'lean/MicroCFTA/SourceCurrentAllocatedNativePastGammaEqualEntryPayload.lean'
audit = 'lean/MicroCFTA/Audit.lean'
stage = read(WORK / 'SOURCES-NORMAL-STAGING.json')
assert len(stage['components']) == 1
assert set(commit['files']) == {transport, audit}
assert set(GIT('diff', '--name-only', prior, code).decode().splitlines()) == {transport, audit}
baseline = read(WORK / 'baseline-source-pins.json')
assert len(baseline) == 6251 and actual == set(baseline)
for name, digest in baseline.items():
    if name not in {transport, audit}:
        assert source_pins[name] == digest, name
assert len(set(baseline) - {transport, audit}) == 6249
old_transport = (WORK / 'SourceCurrentAllocatedNativePastGammaEqualEntryPayload-BEFORE.lean.txt').read_bytes()
old_audit = (WORK / 'Audit-BEFORE.lean.txt').read_bytes()
assert GIT('show', prior + ':' + transport) == old_transport and len(old_transport) == 15882
assert GIT('show', prior + ':' + audit) == old_audit
packet = BASE / '20261117-warm-equal-key-full-pattern-transport-draft'
import_prefix = (packet / 'IMPORTS.lean.txt').read_bytes()
assert import_prefix == b'import MicroCFTA.SourceCurrentAllocatedNativeSourceWarmEntry\n' and len(import_prefix) == 61
assert (ROOT / transport).read_bytes() == import_prefix + old_transport + b'\n' + (packet / 'APPEND.lean.txt').read_bytes()
assert (ROOT / transport).read_bytes()[61:61 + len(old_transport)] == old_transport
assert old_audit.count(b'#print axioms ') == 668
assert (ROOT / audit).read_bytes() == old_audit + b'\n' + (WORK / 'PUBLIC-PROBES.lean.txt').read_bytes()
for item in stage['components']:
    assert source_pins[item['source_path']] == item['raw_sha256']
owner = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
assert source_pins[owner] == baseline[owner] == report['old_resource_owner_sha256']
prior_archive = BASE / bindings['prior_archive']
for name, key in [('manifest.json', 'prior_manifest_sha256'),
                  ('checkpoint.json', 'prior_checkpoint_json_sha256')]:
    data = (prior_archive / name).read_bytes()
    assert SHA(data) == bindings[key]
    assert GIT('show', prior + ':' + str((prior_archive / name).relative_to(ROOT))) == data
old_checkpoint = read(prior_archive / 'checkpoint.json')
assert old_checkpoint['resource_and_component_probes'] == 461
assert report['inherited_resource_component_reports'] == old_checkpoint['resource_and_component_probes']
assert old_checkpoint['checked_code'] == GIT('rev-parse', prior + '^').decode().strip()
prior_files = {item['path']: item for item in read(prior_archive / 'manifest.json')['files']}
for name in ['source-pins.json.gz', 'verification.json', 'archived-inputs.json']:
    data = (prior_archive / name).read_bytes()
    assert len(data) == prior_files[name]['bytes']
    assert SHA(data) == prior_files[name]['sha256']
    assert GIT('show', prior + ':' + str((prior_archive / name).relative_to(ROOT))) == data
old_verification = read(prior_archive / 'verification.json')
assert old_verification['checked_code'] == old_checkpoint['checked_code']
assert old_verification['source_tree_sha256'] == old_checkpoint['source_tree_sha256']
assert old_verification['prior_document_bytes_preserved']
old_pins = json.loads(gzip.decompress((prior_archive / 'source-pins.json.gz').read_bytes()))
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    assert old_pins[name] == pins[name], name
assert baseline == {name: digest for name, digest in old_pins.items()
                    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
request = read(WORK / (BOARD_PREFIX + 'request.json'))
canonical = read(WORK / (BOARD_PREFIX + 'canonical.json'))
assert canonical['verified']
post = canonical['post']
assert post['id'] == request['request_id']
assert type(post['sequence']) is int and post['sequence'] > 0
for key, expected in [('author', request['username']), ('thread_id', request['thread_id']),
                      ('post_type', request['post_type']), ('content', request['content']),
                      ('metadata', request['metadata'])]:
    assert post[key] == expected, key
assert post['metadata']['source'] == code
transport_receipt = read(WORK / 'WARM-TRANSPORT-FIRST-VERIFIED.json')
assert transport_receipt['actual_terminal_exit'] == 0 and transport_receipt['first_header_unchanged']
assert transport_receipt['old_warm_start_allowed']
assert transport_receipt['full_pattern_domain_height_identity_proved']
assert not transport_receipt['genuine_source_qualification_of_every_old_cell_proved']
transport_result = read(BASE / transport_receipt['run'] / 'checked.json')
assert transport_receipt['checks'] == transport_result['checks']
assert transport_result['normal_module_checked'] and transport_result['source_pins_unchanged']
assert transport_result['checks'][-1]['total_axiom_reports'] == 1
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['nonstandard_axioms']
           and not item['sorryAx'] for item in transport_result['checks'])
cleanup = read(WORK / 'combined-terminal-cleanup-result.json')
assert cleanup['no_double_counting']
assert cleanup['all_targets_absent']
assert cleanup['sources_logs_live_jobs_normal_lake_unknown_entries_preserved']
assert cleanup['removed_bytes'] == sum(item['bytes'] for item in cleanup['targets'])
assert cleanup['cumulative_removed_bytes'] >= cleanup['removed_bytes']
assert all(item['terminal_exit'] in [0, 1] for item in cleanup['targets'])
usage = read(WORK / 'USAGE.json')
assert 0 <= usage['rate_limits']['primary']['used_percent'] <= 80
roots = read(WORK / 'selection-roots.json')
additional_path = WORK / 'archive-additional-roots.json'
additional = read(additional_path) if additional_path.exists() else []
for item in additional:
    assert re.fullmatch(r'20261117-[a-z0-9-]+', item['root'])
    assert item['manifest'] in ['MANIFEST.json', 'manifest.json', 'MANIFEST.sha256']
    assert SHA((BASE / item['root'] / item['manifest']).read_bytes()) == item['sha256']
    roots.append(item['root'])
assert len(roots) == len(set(roots))
assert all((BASE / name).is_dir() and not (BASE / name).is_symlink() for name in roots)
# A stale running.json is not a terminal receipt. Runtime records use phases.
runtime_roots = {'20261117-source-finite-completion-probe-gmp-repair',
                 '20261117-source-finite-completion-full-stream-check'}
for name in roots:
    run = BASE / name
    if name == WORK.name:
        failed = read(WORK / 'FIRST-ENVIRONMENT-FAILURE.json')
        result = read(WORK / 'results.json')
        assert failed['actual_terminal_exit'] == 1
        assert not failed['fixture_compiled'] and not failed['enumeration_started']
        assert not failed['source_defect_established'] and failed['original_driver_and_logs_preserved']
        assert [item['exit'] for item in result['phases']] == [1]
        assert result['all_input_pins_unchanged']
    elif name in runtime_roots:
        terminal = read(run / 'terminal.json')
        result = read(run / 'results.json')
        assert terminal['all_phases_completed'] and result['all_input_pins_unchanged']
        assert terminal['phases'] == result['phases']
        assert all(item['exit'] == 0 and not item['external_timeout'] for item in terminal['phases'])
    elif (run / 'check.py').exists():
        result = read(run / ('checked.json' if (run / 'checked.json').exists() else 'results.json'))
        assert result['checks'] and all(type(item['exit']) is int for item in result['checks']), name
assert SHA((BASE / '20261117-fix-self-application-source-fixture-draft/MANIFEST.json').read_bytes()) == '1cb0e791ba5f15c1e00ba9d9376e57d99e2b8bc39aaf684ca5ea533cf38042a2'
assert SHA((BASE / '20261117-warm-inventory-profile-bypass-audit/MANIFEST.sha256').read_bytes()) == 'd00b88254d306955ec5e097bee7409153316e5b054941dc655a986c8ab66f093'
for item in read(WORK / 'original-header-files.json'):
    assert SHA((ROOT / item['path']).read_bytes()) == item['sha256'], item['path']
    assert SHA((ROOT / item['original']).read_bytes()) == item['sha256'], item['original']
selected = sorted(str((BASE / name).relative_to(ROOT)) for name in roots)
assert not (BASE / ARCHIVE).exists()
config = dict(report)
tree = hashlib.sha256()
for name, digest in sorted(source_pins.items()):
    tree.update(name.encode() + b'\0' + digest.encode() + b'\n')
config.update(checked_code=code, prior_checkpoint=prior, public_run=str(PUBLIC), public_gates=5,
    explicit_reports=report['individual_reports'], board_prefix=BOARD_PREFIX,
    board_post_id=post['id'], board_sequence=post['sequence'],
    source_tree_sha256=tree.hexdigest(),
    old_non_audit_non_changed_owner_source_files_byte_exact=6249,
    old_transport_entire_bytes_preserved=15882, old_transport_exact_offset=61,
    ordinary_owner_import_bytes=61, new_audit_imports=0, old_audit_bytes_preserved_as_prefix=True,
    old_owner_proof_bodies_unchanged=True, old_owner_proof_limits_unchanged=True,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],
    cleanup_receipt='combined-terminal-cleanup-result.json',
    primary_usage_percent=usage['rate_limits']['primary']['used_percent'],
    primary_usage_checked_at=usage['event_timestamp'],
    prior_immutable_archive=bindings['prior_archive'],
    prior_manifest_sha256=bindings['prior_manifest_sha256'],
    new_theorem_declarations=1, fresh_strict_reports=1,
    inherited_component_reports=461, replaced_old_reports=0,
    all_new_formal_proof_checks_first_pass=True,
    first_GMP_environment_failure_before_fixture_compile_preserved=True,
    runtime_source_checks_add_no_theorem_credit=True, source_audit_adds_no_theorem_credit=True,
    additional_frozen_roots=additional,
    joint_finite_completion_proved=False,
    compiled_haskell_correspondence_proved=False, haskell_changed=False, goal_active=True)
skipped = sorted(str(path.relative_to(ROOT)) for path in BASE.iterdir()
    if path.is_dir() and path.name.startswith('20261117-') and str(path.relative_to(ROOT)) not in selected)
review = {
    'prior_checkpoint': prior, 'prior_immutable_archive': bindings['prior_archive'],
    'prior_manifest_sha256': bindings['prior_manifest_sha256'], 'selected_roots': len(selected),
    'base_roots': len(read(WORK / 'selection-roots.json')), 'additional_frozen_roots': additional,
    'policy': 'Keep the exact source fixture, original GMP failure and driver, successful GMP repair and full-stream checks, first warm proof/header/check, actual publication, and frozen source-only inventory/Profile audit. Formal proof checks passed first time. Runtime source evidence and the audit add no theorem credit.',
    'new_public_theorem_reports': 1, 'new_private_component_reports': 0,
    'new_private_predicates': 0, 'new_theorem_declarations': 1,
    'fresh_owner_preflight_reports': 0, 'actual_publication_strict_reports': 1,
    'fresh_reports_this_batch': 1, 'inherited_bound_reports': 461,
    'prior_component_reports': 461, 'replaced_old_reports': 0,
    'inherited_owner_reports_included': 264,
    'all_new_formal_proof_checks_first_pass': True,
    'GMP_failure_before_fixture_compile_and_enumeration_preserved': True,
    'runtime_phase_records_and_Lean_proof_records_distinguished': True,
    'runtime_source_checks_and_source_audit_theorem_credit': 0,
    'warm_pattern_domain_height_identity_only': True,
    'earlier_source_family_semantic_IH_discharged': False,
    'every_cell_joint_query_attachment_proved': False,
    'inherited_cell_semantic_chronology_proved': False,
    'warm_across_independent_queries_proved': False, 'all_native_inhabitance_proved': False,
    'type_marker_class_consistency_proved': False, 'joint_finite_completion_proved': False,
    'haskell_changed': False, 'no_axiom_string_replay': True,
    'no_compiled_objects_or_import_overlays': True,
}
note = (WORK / 'checkpoint-note.md').read_text()
for key, value in {'THEOREMS': report['audited_theorems'], 'REMOVED': cleanup['removed_bytes'],
                   'CLEANUP': cleanup['cumulative_removed_bytes'],
                   'USAGE': config['primary_usage_percent']}.items():
    note = note.replace('{{' + key + '}}', str(value))
assert set(re.findall(r'\{\{(.*?)\}\}', note)) == {'TIME', 'TREE', 'CODE'}
outputs = {'checkpoint-config.json': config, 'archive-roots.json': selected,
           'skipped-published-roots.json': skipped, 'selection-review.json': review}
assert all(not (WORK / name).exists() for name in outputs)
for name, value in outputs.items():
    (WORK / name).write_text(json.dumps(value, indent=2) + '\n')
(WORK / 'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code': code, 'packet': ARCHIVE,
                  'roots': len(selected), 'board_sequence': post['sequence'],
                  'new_theorem_declarations': 1, 'fresh_strict_reports': 1, 'inherited_reports': 461}))
