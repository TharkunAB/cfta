from pathlib import Path
import hashlib
import json
import re
import shlex
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
work = base / '20261117-source-finite-completion-probe-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this candidate into the active Work directory'
prior_run = base / '20261117-warm-closed-root-entry-publication'
prior_archive = base / '20261117-warm-closed-root-entry-checkpoint'
runtime = base / '20261117-warm-equal-key-transport-publication'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
transport_name = 'lean/MicroCFTA/SourceCurrentAllocatedNativePastGammaEqualEntryPayload.lean'
transport_module = 'SourceCurrentAllocatedNativePastGammaEqualEntryPayload'
transport_theorem = 'old_warm_entry_full_pattern_after_equal_key_entry'
transport_sha = '35d8435e20a4273842887f966e52334c06ed2acfcc8966fb47ae1d9e07fca16a'
old_transport_sha = '259b219a188a859855d1027b39d169807f0b27901777d5706526842b74aeefb3'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
prior_commit = '85b210de894a35ef7c10e8aa1279e9a53e35ea1d'
stage = json.loads((work / 'SOURCES-NORMAL-STAGING.json').read_text())
components = stage['components']
assert len(components) == 1
component = components[0]
assert component['module'] == component.get('namespace', component['module']) == transport_module
assert component['source_path'] == transport_name and component['raw_sha256'] == transport_sha
assert component['theorems'] == [transport_theorem]
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports']) == (6251, 5251, 669)
assert stage['new_normal_modules'] == 0 and stage['new_public_theorems'] == 1
assert stage['new_private_theorems'] == 0 and stage['new_private_predicates'] == 0
assert (stage['fresh_strict_reports'], stage['inherited_bound_reports'], stage['combined_component_reports']) == (1, 461, 462)
assert stage['old_reports_replaced'] == 0
assert stage['old_non_audit_non_changed_owner_sources_exact'] == 6249
assert stage['old_audit_exact_prefix'] and stage['all_old_proof_bodies_and_limits_unchanged']
assert stage['warm_full_pattern_identity_transport_proved'] and stage['arbitrary_old_warm_start_supported']
assert not stage['inherited_cell_semantic_chronology_proved']
assert not stage['compiled_haskell_correspondence_proved']
assert component['old_owner_bytes'] == 15882 and component['old_owner_offset'] == 61
assert component['old_owner_contiguous_exact']
assert not stage['joint_finite_completion_proved'] and not stage['haskell_changed']
prior = json.loads((prior_run / 'checked.json').read_text())
assert len(prior['checks']) == 5 and all(c['exit'] == 0 and not c['nonstandard_axioms']
    and not c['diagnostics'] and not c['sorryAx'] for c in prior['checks'])
assert (prior['source_files'], prior['independent_reports'], prior['resource_and_component_probes']) == (6251, 263, 461)
assert prior['whole_worker_program_slots_proved'] and prior['whole_worker_roles_proved']
assert prior['owner_resource_probes'] == 264
assert prior['closed_root_physical_entry_chain_proved']
baseline = json.loads((work / 'baseline-source-pins.json').read_text())
assert len(baseline) == 6251
assert {str(path.relative_to(root)) for path in (root / 'lean/MicroCFTA').glob('*.lean')} == set(baseline)
old_transport = (work / (transport_module + '-BEFORE.lean.txt')).read_bytes()
old_audit = (work / 'Audit-BEFORE.lean.txt').read_bytes()
assert len(old_transport) == 15882 and sha(old_transport) == old_transport_sha
assert old_audit.count(b'#print axioms ') == 668
for name, digest in baseline.items():
    data = old_audit if name == audit_name else old_transport if name == transport_name else (root / name).read_bytes()
    assert sha(data) == digest, name
assert len(set(baseline) - {audit_name, transport_name}) == 6249
assert sha((root / owner_name).read_bytes()) == owner_sha
packet = base / '20261117-warm-equal-key-full-pattern-transport-draft'
import_prefix = (packet / 'IMPORTS.lean.txt').read_bytes()
assert import_prefix == b'import MicroCFTA.SourceCurrentAllocatedNativeSourceWarmEntry\n' and len(import_prefix) == 61
normal = (root / transport_name).read_bytes()
assert normal == import_prefix + old_transport + b'\n' + (packet / 'APPEND.lean.txt').read_bytes()
assert normal[61:61 + len(old_transport)] == old_transport
assert sha(normal) == transport_sha
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
qname = 'MicroCFTA.' + transport_module + '.' + transport_theorem
assert public == ('#check ' + qname + '\n#print axioms ' + qname + '\n').encode()
audit = (root / audit_name).read_bytes()
assert audit == old_audit + b'\n' + public
assert sum(line.startswith(b'import ') for line in audit.splitlines()) == 5251
assert audit.count(b'#print axioms ') == 669
header_path = packet / 'FIRST-HEADER.lean.txt'
text = normal.decode()
declaration = 'theorem ' + transport_theorem
start = text.index(declaration)
header = header_path.read_text()
assert text[start:text.index(' := by', start)].rstrip() == header[header.index(declaration):].rstrip()
verified_path = work / 'WARM-TRANSPORT-FIRST-VERIFIED.json'
verified = json.loads(verified_path.read_text())
assert verified['actual_terminal_exit'] == 0 and verified['first_header_unchanged']
assert verified['old_warm_start_allowed'] and verified['full_pattern_domain_height_identity_proved']
assert not verified['genuine_source_qualification_of_every_old_cell_proved']
normal_check = base / component['actual_normal_check']
assert verified['run'] == component['actual_normal_check']
normal_checked = json.loads((normal_check / 'checked.json').read_text())
assert normal_checked['normal_module_checked'] and all(normal_checked['passed'])
assert verified['checks'] == normal_checked['checks']
assert normal_checked['source_pins_unchanged']
assert normal_checked['checks'][1]['total_axiom_reports'] == 1
assert all(item['exit'] == 0 and not item['nonstandard_axioms'] and not item['diagnostics']
           and not item['sorryAx'] for item in normal_checked['checks'])
checked_source = normal_check / 'source/MicroCFTA' / (transport_module + '.lean')
assert checked_source.read_bytes().startswith(normal)
checked_inputs = [normal_check / name for name in ['checked.json', 'selection.json', 'normal-module.txt', 'source-pins.json']]
checked_inputs += [checked_source, verified_path]
# Validation above is read-only. Only Root may create the publication run.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-warm-equal-key-publication-'))
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
(runtime / 'PUBLIC-PROBES.lean.txt').write_bytes(public)
commands = []
strict_sources = []
fresh_count = 0
for component in components:
    normal = root / component['source_path']
    namespace = component.get('namespace', component['module'])
    names = component['theorems']
    probes = ''.join('#check @MicroCFTA.' + namespace + '.' + name + '\n#print axioms MicroCFTA.'
                     + namespace + '.' + name + '\n' for name in names)
    fresh_count += len(names)
    source = runtime / 'source/MicroCFTA' / normal.name
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_bytes(normal.read_bytes() + b'\n' + probes.encode())
    (runtime / (component['module'] + '-PROBES.lean.txt')).write_text(probes)
    strict_sources.append(source)
    commands.append(['lake', 'env', 'lean', '-j1', '-DwarningAsError=true', '-R',
        str(source.parent.parent), '-o', str(objects / (component['module'] + '.olean')), str(source)])
assert fresh_count == 1
independent = runtime / 'IndependentProbes.lean'
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 263
independent.write_bytes(prior_independent + b'\n' + public)
assert independent.read_bytes().count(b'#print axioms ') == 264
selection = {'prior_checkpoint': prior_commit,
    'prior_archive_manifest_sha256': sha((prior_archive / 'manifest.json').read_bytes()),
    'prior_checked_sha256': sha((prior_run / 'checked.json').read_bytes()),
    'prior_pins_sha256': sha((prior_run / 'source-pins.json').read_bytes()),
    'baseline_sha256': sha((work / 'baseline-source-pins.json').read_bytes()),
    'stage_sha256': sha((work / 'SOURCES-NORMAL-STAGING.json').read_bytes()),
    'old_audit_sha256': sha(old_audit), 'old_transport_sha256': sha(old_transport),
    'unchanged_resource_owner_sha256': owner_sha,
    'prior_source_files': 6251, 'prior_combined_reports': 461,
    'replaced_old_reports': 0, 'inherited_reports': 461, 'fresh_reports': 1, 'combined_reports': 462,
    'new_theorem_declarations': 1, 'new_public_theorems': 1, 'new_private_theorems': 0,
    'old_normal_sources_byte_exact_except_audit_and_transport': 6249,
    'old_transport_bytes': 15882, 'old_transport_exact_offset': 61,
    'old_audit_bytes_retained_as_prefix_without_new_import': True,
    'owner_preflight_reports_fresh_this_batch': 0, 'owner_reports_inherited': 264,
    'old_toolchain_and_proof_inputs_reverified': True, 'axiom_strings_replayed': False}
(runtime / 'INHERITANCE-SELECTION.json').write_text(json.dumps(selection, indent=2) + '\n')
STRICT_BINDING_TEMPLATE = '''from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/home/tritlo/Code/mcfta')
runtime = Path(__file__).parent
prior = root / 'lean/restart-evidence/20261117-warm-closed-root-entry-publication'
archive = root / 'lean/restart-evidence/20261117-warm-closed-root-entry-checkpoint'
work = root / 'lean/restart-evidence/20261117-source-finite-completion-probe-work'
sha = lambda data: hashlib.sha256(data).hexdigest()
selection = json.loads((runtime / 'INHERITANCE-SELECTION.json').read_text())
assert sha((archive / 'manifest.json').read_bytes()) == selection['prior_archive_manifest_sha256']
committed = subprocess.check_output(['git', 'show', selection['prior_checkpoint'] + ':'
    + str((archive / 'manifest.json').relative_to(root))], cwd=root)
assert committed == (archive / 'manifest.json').read_bytes()
subprocess.run(['python3', str(archive / 'verify.py')], check=True)
records = json.loads((archive / 'archived-inputs.json').read_text())
for name in ['checked.json', 'source-pins.json']:
    path = prior / name
    record = next(item for item in records if item['original'] == str(path))
    archived = (archive / record['archived']).read_bytes()
    if record['gzip']:
        archived = gzip.decompress(archived)
    assert archived == path.read_bytes()
assert sha((prior / 'checked.json').read_bytes()) == selection['prior_checked_sha256']
assert sha((prior / 'source-pins.json').read_bytes()) == selection['prior_pins_sha256']
assert sha((work / 'baseline-source-pins.json').read_bytes()) == selection['baseline_sha256']
assert sha((work / 'SOURCES-NORMAL-STAGING.json').read_bytes()) == selection['stage_sha256']
assert sha((work / 'Audit-BEFORE.lean.txt').read_bytes()) == selection['old_audit_sha256']
assert sha((work / 'SourceCurrentAllocatedNativePastGammaEqualEntryPayload-BEFORE.lean.txt').read_bytes()) == selection['old_transport_sha256']
for name, digest in json.loads((prior / 'source-pins.json').read_text()).items():
    if name == 'lean/MicroCFTA/Audit.lean':
        data = (work / 'Audit-BEFORE.lean.txt').read_bytes()
    elif name == 'lean/MicroCFTA/SourceCurrentAllocatedNativePastGammaEqualEntryPayload.lean':
        data = (work / 'SourceCurrentAllocatedNativePastGammaEqualEntryPayload-BEFORE.lean.txt').read_bytes()
    else:
        data = (root / name).read_bytes()
    assert sha(data) == digest, name
assert sha((root / 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean').read_bytes()) == selection['unchanged_resource_owner_sha256']
print(json.dumps({'inherited_component_reports_verified': 461,
                  'fresh_component_reports_expected': 1,
                  'fresh_owner_preflight_reports': 0,
                  'unchanged_owner_reports_inherited': 264,
                  'old_sources_and_toolchain_byte_exact': True}), flush=True)
'''
strict = runtime / 'strict-new-and-bind.py'
strict.write_text(STRICT_BINDING_TEMPLATE + '\ncommands = ' + repr(commands)
    + '\nfor command in commands:\n    subprocess.run(command, check=True)\n')
template = (prior_run / 'check.py').read_text()
driver = template[:template.index('\njobs =')]
jobs = [('public-build', 'exec lake build', 0),
    ('strict-new-components-and-prior-bindings', 'exec python3 ' + shlex.quote(str(strict)), 1),
    ('independent-imports', 'exec lake env lean -j1 -DwarningAsError=true ' + shlex.quote(str(independent)), 264),
    ('audit-build', 'exec lake build MicroCFTA.Audit', 0),
    ('audit-strict', 'exec lake env lean -j1 -DwarningAsError=true MicroCFTA/Audit.lean', 669)]
driver += '\njobs = ' + repr(jobs) + '''
for name, command, count in jobs:
    run(name, command, count)
assert len(checks) == 5
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx']
           and (not job[2] or c['total_axiom_reports'] == job[2]) for c, job in zip(checks, jobs))
match = re.search(r'Checked axiom dependencies of (\\d+) MicroCFTA theorems\\.', (runtime / 'audit-strict.txt').read_text())
assert match
'''
report = dict(prior)
for name in ['checks', 'limits', 'at', 'audited_theorems', 'checked_code', 'owner_preflight_evidence',
             'legacy_new_private_reports', 'legacy_new_private_reports_caveat', 'new_owner_export_maxHeartbeats',
             'replaced_old_native_reports', 'old_native_reports_rechecked',
             'fresh_native_strict_reports', 'fresh_cold_strict_reports',
             'old_native_exact_bytes', 'old_native_exact_offset',
             'old_native_bytes_preserved_contiguously',
             'all_six_old_owner_bytes_preserved_as_prefixes', 'new_imports_to_changed_old_owners',
             'old_audit_bytes_preserved_after_one_import']:
    report.pop(name, None)
for name in list(report):
    if name.startswith('old_non_audit_'):
        report.pop(name)
report.update(source_files=6251, direct_audit_imports=5251, individual_reports=669,
    independent_reports=264, resource_and_component_probes=462,
    inherited_resource_component_reports=461, fresh_resource_component_reports=1,
    replaced_old_reports=0, fresh_owner_preflight_reports=0,
    fresh_strict_normal_reports=1, actual_publication_strict_reports=1,
    resource_component_evidence='1 actual fresh strict report for the new public warm equal-key full-pattern transport law and461 inherited reports; no report replacement, fresh owner preflight or axiom-string replay; this strict gate does not recompile the resource owner',
    new_component_reports=1, new_theorem_reports=1, new_modules=0, new_public_theorems=1,
    new_private_component_reports=0, new_public_component_reports=1, new_private_predicates=0,
    new_relation_declaration_checks=0, new_relation_declaration_reports=0,
    owner_resource_probes=264, previous_owner_resource_probes=264,
    owner_recompiled_in_publication_strict_gate=False, fresh_owner_preflight_evidence=None,
    inherited_owner_preflight_evidence={'prior_run': str(prior_run), 'reports': 264,
        'normal_owner_sha256': owner_sha, 'fresh_this_batch': False, 'included_in_inherited_461': True},
    old_non_audit_non_transport_source_files_byte_exact=6249,
    old_non_audit_source_files_byte_exact=6249, entire_previous_resource_owner_byte_exact=True,
    old_resource_owner_sha256=owner_sha, changed_existing_owners=1,
    old_transport_entire_bytes_preserved=15882, old_transport_exact_offset=61,
    new_ordinary_import_to_transport_owner_only=True,
    old_audit_bytes_preserved_as_prefix=True, new_audit_imports=0,
    all_old_proof_bodies_and_limits_unchanged=True,
    warm_equal_key_full_pattern_transport_proved=True,
    warm_equal_key_full_pattern_transport_physical_identity_only=True,
    old_full_pattern_domain_and_height_identity_proved=True,
    no_new_semantic_Profile_or_Gamma_supplier=True,
    earlier_source_family_semantic_IH_discharged=False,
    every_cell_joint_query_attachment_proved=False,
    inherited_cell_semantic_chronology_proved=False,
    mixed_qualified_profile_height_orientation_derived=False,
    independent_query_inherited_warm_tables_proved=False, warm_across_independent_queries_proved=False,
    joint_finite_completion_proved=False, all_native_inhabitance_proved=False,
    source_terminal_marker_native_inhabitance_proved=False, source_type_marker_class_consistency_proved=False,
    compiled_haskell_correspondence_proved=False, haskell_changed=False,
    same_original_runtime_fuels=True, whole_worker_roles_proved=True,
    whole_worker_program_slots_proved=True, whole_worker_program_slots_fixed_marks_proved=True,
    proof_limits='unchanged defaults; unchanged owner proof settings inherited',
    prior_checkpoint=prior_commit, prior_immutable_archive=prior_archive.name, public_run=str(runtime))
driver += 'report = ' + repr(report) + '\n'
driver += '''report.update(checks=checks, limits=limits, at=datetime.datetime.now().astimezone().isoformat(),
              audited_theorems=int(match.group(1)))
(runtime / 'checked.json').write_text(json.dumps(report, indent=2) + '\\n')
print(json.dumps(report), flush=True)
'''
(runtime / 'check.py').write_text(driver)
files = list((root / 'lean/MicroCFTA').glob('*.lean'))
files += [root / name for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']]
files += [p for p in runtime.iterdir() if p.is_file()] + strict_sources
files += [Path(__file__), work / 'SOURCES-NORMAL-STAGING.json', work / 'baseline-source-pins.json',
    work / 'Audit-BEFORE.lean.txt', work / (transport_module + '-BEFORE.lean.txt'), header_path,
    packet / 'IMPORTS.lean.txt', packet / 'APPEND.lean.txt', packet / 'LAYOUT.json'] + checked_inputs
(runtime / 'source-pins.json').write_text(json.dumps(
    {str(p.relative_to(root)): sha(p.read_bytes()) for p in files}, indent=2) + '\n')
print(json.dumps({'run': str(runtime), 'gates': 5, 'fresh_component_reports': 1,
    'inherited_component_reports': 461, 'combined_component_reports': 462,
    'replaced_old_reports': 0, 'fresh_owner_preflight_reports': 0,
    'inherited_owner_reports': 264, 'independent_reports': 264,
    'audit_reports': 669, 'objects': str(objects)}))
