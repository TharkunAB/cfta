from pathlib import Path
import json,subprocess
r=Path('/tmp/mcfta-terminal-and-prefix-observation-control-20261031')
repo=Path('/home/tritlo/Code/mcfta')
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True)
assert git('branch','--show-current').strip()=='formalize'
assert git('rev-parse','HEAD').strip()=='d870352ca6a88210d31698f9298557127f073f37'
assert not git('diff','--cached','--name-only').strip()
modules=json.loads((r/'modules.json').read_text());audit=repo/'lean/MicroCFTA/Audit.lean';prior=(r/'prior-Audit.lean').read_bytes();final=audit.read_bytes();assert final==''.join('import MicroCFTA.'+m+'\n' for m in modules).encode()+prior
messages=['Prove native certificates at actual terminal returns','Derive changed-slot normalization from actual prefix results','Preserve native certificates through child dispatch']
rows=[]
for i,(module,message) in enumerate(zip(modules,messages),1):
 try:
  audit.write_bytes(''.join('import MicroCFTA.'+m+'\n' for m in modules[:i]).encode()+prior)
  subprocess.run(['git','add','--','lean/MicroCFTA/Audit.lean','lean/MicroCFTA/'+module+'.lean'],cwd=repo,check=True)
 finally:audit.write_bytes(final)
 expected={'lean/MicroCFTA/Audit.lean','lean/MicroCFTA/'+module+'.lean'};assert set(git('diff','--cached','--name-only').splitlines())==expected
 process=subprocess.run(['git','commit','-m',message],cwd=repo,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/f'source-{i}-commit.raw.log').write_text(process.stdout);assert process.returncode==0,process.stdout
 row={'module':module,'commit':git('rev-parse','HEAD').strip(),'message':message,'staged_files':sorted(expected)};rows.append(row);(r/f'source-{i}-commit.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
assert audit.read_bytes()==final
assert not git('diff','--name-only').strip()
(r/'source-commits.json').write_text(json.dumps(rows,indent=2)+'\n')
