# Actual terminal and prefix-observation transport

Retain the complete original-input and original-resource objective: sound
outputs, intended ordered finite prefix under configured order/stops, both
workers, optimized interned core, Prefix/table/count/checkpoint/public APIs,
Haskell correspondence, and older constructor/equality/exact-size/order/rank.

Check actual Terminal.run native Stored from existing CURRENT terminal entry
facts + entrynativeStored. Derive every later prefix/fold/incoming entry fact
using existing actual-observation producers. No future invariant/Ranges/Trace
or postcondition supplier. Cover every actual early/error/outcome branch.

Check extraction from one actual selected runPrefix narrowed result and its
retained core-change gate. Derive intermediate read/check/prepare/action/adapt
facts internally, then compose checked SlotTransport. The changed gate must
refer to actual fields of the retained result. No independent internal state
or implicit intermediate-observation supplier replaces final-result evidence.
No all-success Normal/global history/source-reset/original-depth claim.

Root alone owns compiler/evaluator/native/Git/network/board/production and
packaging. Keep serial4GiB/zero-swap5min limits. Preserve prior source/output,
full documents, drafts, failures and provenance. No Haskell source change or
new executable defect/fix is established. Backend remains blocked despite
user-resumed verified progress. Full goal remains incomplete.

The checked scope also includes the actual cached ChildDispatch.run native
Stored result at every outcome. Its original bucket internally supplies the
terminal subset, pending and reservation gates. The actual child traversal
proof remains the next separate task.
