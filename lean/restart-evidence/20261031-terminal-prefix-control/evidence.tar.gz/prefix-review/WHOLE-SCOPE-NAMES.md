# OLD whole scope

Slot1: SourcePruningEnumerationSelectedStep.lean. Named before acquisition at00:48 CET.
Slot2: unused.
