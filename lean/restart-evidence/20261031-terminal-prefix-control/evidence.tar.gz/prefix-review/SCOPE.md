# Scope

Source-only extraction of actual runPrefix stage observations and checked slot transport. Own only this fresh directory. Keep all prior bundles frozen.
Root owns all compiler, evaluator, native, Git, network, board, production and packaging work. No spawning.

OLD whole slot1 named before acquisition: SourcePruningEnumerationSelectedStep.lean. Slot2 remains unused.
Explicit new reuses: checked176L SlotTransport SHA55eedb67e1311dcad35710cf7c11c028cca2e51129893a8d8fe5939624158340 and previous frozen63L wrapper SHA8f6888be0194b85f6e03414e775e5a8c2b5337f080f80d6c0c32339ca12a8258, which remains UNCOMPILED.

Derive actual read/check/prepare/encoding/action/adapt stages from actual prefix tags. Do not require separate intermediate-stage equations or future Trace/Frame/Normal. Restrict Normal to a genuinely observed changed branch.
