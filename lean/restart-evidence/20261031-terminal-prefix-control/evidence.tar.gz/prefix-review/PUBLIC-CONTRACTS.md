# Proposed public contracts

UNCOMPILED source-only. No owner compiler or evaluator was used.
Both complete headers retain the single literal prefix result and its retained-field change gate.

```lean
import MicroCFTA.SourcePruningEnumerationSelectedStep
import MicroCFTA.SourcePruningNarrowSlotTransport

namespace MicroCFTA.SourcePruningEnumerationSelectedStep
open EnumerationState EnumerationCorrectness EnumerationCompressionFrame
open InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
open SourcePruningNativeView SourcePruningEnumerationNodes SourcePruningEnumerationObservation
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Core" => EnumerationState.State Symbol Constraint
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Metadata" => SourcePruningRecordTypes.Metadata
attribute [local instance] FormulaExecutable.formulaDecidableEq
variable {Typing Key : Type} {width : Nat}
variable [DecidableEq (EdgeKey Symbol Constraint)]

local instance prefixObservationMonadList : Monad List where
  pure value := [value]
  bind values continuation := values.flatMap continuation
```

```lean
theorem prefix_changed_stages
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (metadata updated : Metadata Typing)
    (readFuel checkFuel nativeFuel representativeFuel indexFuel callbackFuel uv : Nat)
    (caller reached : Caller width) (before after : Cached) (queries receivedQueries : Queries)
    (checked observed callbackCore : Core) (result : Node)
    (nextHeap : InternedConstructorTemplates.State Symbol Constraint) (action : EnumerateM Symbol Constraint Unit)
    (prefix : runPrefix holeKey fits admits graph templates stop order metadata readFuel checkFuel nativeFuel
      representativeFuel indexFuel callbackFuel uv caller before queries =
      .narrowed checked (.done (result, some action) nextHeap) reached receivedQueries
        (some [.ok ((), observed)]) (some after) (some [.ok ((false, updated), callbackCore)]) none)
    (changedCore : after.core ≠ checked) :
    ∃ (oldHandle newHandle : Nat) (scs : List Suspended) (oldValue : Node) (readAfter : Core),
      ExceptT.run (getValue readFuel uv before.core) = [.ok (.unenumerated (some oldHandle) scs, readAfter)] ∧
      ExceptT.run (SourcePruningEnumerationRecursion.checkRepeated caller.checked.native.machine.heap
        checkFuel uv oldHandle scs readAfter) = [.ok (false, checked)] ∧
      lookupNode caller.checked.native.machine.heap oldHandle = some oldValue ∧
      SourcePruningEnumerationAction.prepare holeKey fits admits metadata nativeFuel representativeFuel
        uv oldHandle scs oldValue caller.checked.native.machine.heap = .done (result, some action) nextHeap ∧
      encodeNode result = some newHandle ∧ newHandle ≠ oldHandle ∧
      ExceptT.run (action checked) = [.ok ((), observed)] ∧
      SourcePruningEnumerationNarrowAdapter.adapt nextHeap indexFuel uv oldHandle newHandle scs before observed = some after ∧
      after.core = observed ∧ callbackCore = observed ∧ updated = metadata
```

```lean
theorem prefix_changed_stores_normal
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (metadata updated : Metadata Typing)
    (readFuel checkFuel nativeFuel representativeFuel indexFuel callbackFuel uv : Nat)
    (caller reached : Caller width) (before after : Cached) (queries receivedQueries : Queries)
    (checked observed callbackCore : Core) (result : Node)
    (nextHeap : InternedConstructorTemplates.State Symbol Constraint) (action : EnumerateM Symbol Constraint Unit)
    (ready : SourceEqualityRequiredCache.Ready caller.checked.native.machine.heap)
    (realized : PendingRealized caller.checked.native.machine.heap before.core)
    (total : UnionFind.Total before.core.representatives)
    (prefix : runPrefix holeKey fits admits graph templates stop order metadata readFuel checkFuel nativeFuel
      representativeFuel indexFuel callbackFuel uv caller before queries =
      .narrowed checked (.done (result, some action) nextHeap) reached receivedQueries
        (some [.ok ((), observed)]) (some after) (some [.ok ((false, updated), callbackCore)]) none)
    (changedCore : after.core ≠ checked) :
    ∃ (oldHandle newHandle : Nat) (scs : List Suspended) (oldValue : Node),
      encodeNode result = some newHandle ∧ newHandle ≠ oldHandle ∧
      lookupNode caller.checked.native.machine.heap oldHandle = some oldValue ∧
      SourceEqualityRequiredCache.Keeps caller.checked.native.machine.heap nextHeap ∧
      Available nextHeap result ∧ result.free = [] ∧ SourceEqualityRequiredCache.Ordinary result ∧
      EqualityOrdinaryReadback.Normal nextHeap result ∧ lookupNode nextHeap newHandle = some result ∧
      (∀ edge ∈ nodeEdges result, keeps fits admits (holeKey metadata.typing uv) edge = true) ∧
      (SourceEqualityRequiredCache.Ordinary oldValue → ∀ edge ∈ nodeEdges result, edge ∈ nodeEdges oldValue) ∧
      PendingRealized nextHeap after.core ∧
      ∃ (root : Nat) (middle : Core),
        Success (representative representativeFuel uv) checked root middle ∧ Frame checked middle ∧
        middle.values[root]? = some (.unenumerated (some oldHandle) scs) ∧
        Success (setValue root (.unenumerated (some newHandle) scs)) middle () after.core ∧
        after.core = {middle with values := middle.values.set root (.unenumerated (some newHandle) scs)} ∧
        after.core.values[root]? = some (.unenumerated (some newHandle) scs)
```
