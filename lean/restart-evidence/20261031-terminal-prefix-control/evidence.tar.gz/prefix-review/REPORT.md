# Slot control extracted from an actual prefix result

This bundle proposes two UNCOMPILED laws. They derive filter-stage observations from one literal `runPrefix` result and then apply checked SlotTransport. They do not ask the caller to supply the intermediate read, check, prepare, encoding, action, or adapter equations separately.

## Exact observable branch and gate

Both public headers use this existing result constructor:

```lean
Result.narrowed checked (.done (result, some action) nextHeap) reached receivedQueries
  (some [.ok ((), observed)]) (some after)
  (some [.ok ((false, updated), callbackCore)]) none
```

`checked` is argument1 of the retained `narrowed` result. `after` is the cache in the Some candidate at argument6. The gate is `after.core ≠ checked`. Both values are fields of the single actual result equation. No separate check-stage equation is an input. The native input field `caller.checked` has a different type and role; it supplies the native heap and is not the Core value in this gate.

The native result, action, nextHeap, action output, Right metadata, and Right callback core are also retained fields of that same result. Their names in the header denote observed result data, not extra stage suppliers. The old handle, suspensions, old native value, and first read state are not retained in the tag. The extraction law recovers them existentially by inverting the literal prefix computation.

A successful narrowed/Right tag alone is insufficient for a physical Normal conclusion. The actual Mu and known-type bypass branches can return the original value with a pure action. This task does not establish a formal counterexample, but it does not assign a filter-produced ordinary shape to those bypasses.

The private actual-prepare lemma proves that equal new and old handles plus actual action success imply `observed = checked`. Actual `adapt_core` and the Right identity then imply `after.core = checked`. The retained-field difference excludes that unchanged branch and derives `newHandle ≠ oldHandle`. It does not assume that inequality as an intermediate fact.

This gate identifies actual observed Core-changing events within this exact tag. It does not bound unchanged calls, parked recursion, source-reset branches, or other result tags. No all-successful-prefix Normal claim is made.

## Extraction law

`prefix_changed_stages` takes the literal result equation and retained-field gate. It does not need native Ready, PendingRealized, or a total forest. It returns explicit actual equations for:

- The singleton pending `getValue` read.
- The singleton false recursion check.
- The actual old native lookup.
- The actual `prepare` result with the retained value, action, and native heap.
- The new encoding and its difference from the recovered old handle.
- The singleton actual successful action output.
- The actual successful adapter at the retained cache.
- `after.core = observed`, `callbackCore = observed`, and `updated = metadata`.

The proof follows the actual list and result matches in `runPrefix`. Each unsupported, failed, parked, or missing-candidate branch contradicts the retained successful tag. The last branch uses existing `recordTypes_inr`. It injects the actual constructor equality to identify the retained fields. It then uses actual `adapt_core` and the private equal-handle action law to derive the encoded-handle difference.

The explicit new-encoding equation is an output. It comes from the actual `encodeNode` match in the prefix. It is not hidden, presumed, or supplied by a future supplier.

## Composition law

`prefix_changed_stores_normal` adds only current native Ready, current PendingRealized, and totality of the current representative forest. It calls the extraction law, derives Success from the recovered actual singleton equations, and applies checked `prepare_changed_success_stores_normal`.

It returns recovered old/new handles, suspensions, and the actual old native value. It gives the explicit new encoding and changed-handle relation, old native lookup, native Keeps, Available, closedness, ordinary shape, physical Normal, exact native readback, retained filter rows, conditional ordinary-input row subset, and final PendingRealized at the retained `after.core`. It also returns the actual representative/read/write facts and exact final stored slot.

No Normal, Frame, historical constructor, reset-free history, Trace, Complete predicate, future cache result, or chosen-target supplier is an input. Old native gates and compression frames derive inside checked SlotTransport. Physical Normal is derived for the actual returned value; old physical Normal is not required.

The physical Normal and readback state is `nextHeap`, the native heap retained in the actual prepared result. This bundle does not separately expose an equality between that heap and the native machine projection of the retained `reached` caller. The exact prefix computation still determines the caller update. Its projection can be lifted in a later caller wrapper if required.

## Endpoint and remaining scope

The result equation is for literal `runPrefix`, before the legacy ordinary continuation is added by `finish`. The ordinary field is none. The proof uses the actual adapter and Right identities to preserve the action output through the returned cache. It omits no writer inside that retained branch and assumes no future Frame.

A successful action with missing encoding or missing adapter candidate cannot have the required retained tag. A parked recursion branch cannot have it. No completion or sufficient-fuel theorem for those excluded branches is claimed.

This bundle does not yet construct a full `ChangedFilters` history for either worker. It does not bound unchanged calls, source-reset counts, first carrier size from original input, or the global original-depth budget. Incoming and dispatch intersections, selected Mu unfolding, later ordinary branches, and Prepared Mu/Union reconstruction remain separate cases. All earlier alternatives and staged children, recursive whole-execution completion, global coverage, public-adapter correctness, and Haskell correspondence remain open. The full original-input, both-worker, public/Haskell objective is unchanged.

No Haskell source was changed. No Haskell defect, fix, or candidate was established.

## Versions and retained sources

V1 has272L and20071B, SHAa7d20c47e2c03259b1adbd558632c710d712d722fe683254766f3e522e2d5c7c. V2 has275L and20354B, SHA8515a53fa418dccf9a2ed99e5e67361e4dcdcc54a3a65cb6ca7e0d43339c4d71. Prefer V2. It explicitly generalizes lookup, encoding, and adapter results in the prefix hypothesis before case analysis. Both public headers are unchanged. Both drafts remain UNCOMPILED by this owner.

OLD whole slot1 was named before acquisition: SourcePruningEnumerationSelectedStep.lean,228L, SHAcf1f24b70d7132344485fc6db14dacf435b806c12da2b4241142c3de6e9be3ab. Slot2 remains unused. All other OLD acquisitions are bounded exact cuts or retained locator lines. No extra whole or near-whole module was acquired.

The exact checked176L SlotTransport input has SHA55eedb67e1311dcad35710cf7c11c028cca2e51129893a8d8fe5939624158340. The parent authorized full reuse. It is copied from the prior frozen adapter bundle under manifest8f6d9e6f783ade6f98c0433c95268c00b8d191ff28bad6f81ea77c7b10436a42. The prior63L wrapper, SHA8f6888be0194b85f6e03414e775e5a8c2b5337f080f80d6c0c32339ca12a8258, is also explicitly retained. It remains UNCOMPILED next-work evidence and is not imported by the new draft.

All full source copies, bounded cuts, and locator lines were read. PUBLIC-CONTRACTS.md/json retain both complete headers and full namespace/import/notation/variable/instance context. OBSERVABLE-GATE.md states the exact tag projection and its boundary. Exact source hashes, copies, ranges, cumulative unions, version differences, and the helper provider are retained. No acquisition failed. The memory-registry query had no matches and supplied no task fact.

No compiler, evaluator, native execution, Git operation, network request, board operation, production edit, or sub-agent was used by this owner. All prior bundles remain frozen. Root alone checks, repairs, installs, and publishes.
