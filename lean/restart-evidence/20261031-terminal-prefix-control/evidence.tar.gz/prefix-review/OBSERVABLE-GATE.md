# Exact retained-field gate

The public result equation uses this existing constructor shape:

```lean
Result.narrowed checked (.done (result, some action) nextHeap) reached receivedQueries
  (some [.ok ((), observed)]) (some after)
  (some [.ok ((false, updated), callbackCore)]) none
```

`checked` is constructor argument1. `after` is the cache in the Some candidate at constructor argument6. The gate is `after.core ≠ checked`. Both values occur in the single actual result.
The gate does not compare an independently supplied check state with the output. No separate check equation is an input.
The input native caller field `caller.checked` has a different type and role. It supplies the original native heap. It is not the checked core in this gate.

The private actual-prepare lemma proves that equal new/old handles and successful action imply `observed = checked`. Actual adapter and Right identities then imply `after.core = checked`. The retained-field gate excludes this branch.
A successful tag alone permits unchanged Mu or known-type bypasses. No result-Normal claim is made for those branches.
The gate covers actual observed core-changing events in this tag. It does not bound unchanged calls or other source-reset tags.
