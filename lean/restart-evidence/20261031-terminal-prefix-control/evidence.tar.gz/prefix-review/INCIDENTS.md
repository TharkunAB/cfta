No source acquisition failed. All exact source copies, cuts, and locator stdout/stderr were retained.
V1 is retained unchanged. Source audit produced V2 to generalize lookup, encoding, and adaptation in the prefix hypothesis before case analysis. Public headers did not change. Neither version was checked by this owner.
A memory-registry search returned no matches with the normal rg exit code1. No memory-derived claim was used.
No compiler, evaluator, or native execution was attempted.
