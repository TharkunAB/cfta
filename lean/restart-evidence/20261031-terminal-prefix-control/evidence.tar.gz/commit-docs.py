from pathlib import Path
import json,subprocess
r=Path('/tmp/mcfta-terminal-and-prefix-observation-control-20261031');repo=Path('/home/tritlo/Code/mcfta')
expected=['FINDINGS.md','HANDOFF.md','NEXT-PROMPT.md','lean/notes-current-terminal-and-prefix-observation.md']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='1e7a2b6f459ea72279ec576c23fe6b1027abe84f'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True).strip()
subprocess.run(['git','add','--',*expected],cwd=repo,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True).splitlines())==set(expected)
process=subprocess.run(['git','commit','-m','Record terminal and prefix observation proof boundaries'],cwd=repo,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/'docs-commit.raw.log').write_text(process.stdout);assert process.returncode==0,process.stdout
row={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'message':'Record terminal and prefix observation proof boundaries','files':expected};(r/'docs-commit.json').write_text(json.dumps(row,indent=2)+'\n');assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=repo,text=True).strip();print(json.dumps(row))
