# Draft versions

V1 is retained without alteration. V2 changes two local binder names only.
V2 uses priorProtected instead of protected to avoid a possible Lean keyword
collision. V2 marks the unused retained StorageValid witness _middleStorage.
The theorem header and proof strategy are unchanged. No draft was compiled.
