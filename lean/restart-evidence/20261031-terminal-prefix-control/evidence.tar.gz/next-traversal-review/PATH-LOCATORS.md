# Name-only source locators

No source content was acquired by these initial commands.

1. rg --files lean/MicroCFTA -g '*ChildTraversal*'
   Returned SourceFlatPruningChildTraversal.lean,
   SourcePruningEnumerationChildTraversal.lean, and
   SourcePruningEnumerationChildTraversalStability.lean.
2. rg --files lean/MicroCFTA -g 'SourcePruningEnumerationChild*.lean'
   The resulting bounded family is retained in child-source-paths.txt.
3. rg --files lean/MicroCFTA -g 'SourcePruningEnumerationChildren*.lean'
   -g 'SourcePruningEnumerationTraversal*.lean'
   The resulting traversal family is retained in traversal-source-paths.txt.

Exact declaration locators are separate acquisition records. Their complete
stdout and stderr files are retained. Every declaration line has full-source
metadata and a cumulative line union in the source ledger.
