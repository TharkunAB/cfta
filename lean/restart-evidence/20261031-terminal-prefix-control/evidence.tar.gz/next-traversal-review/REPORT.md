# Child-traversal native Stored handoff

2026-10-31 01:17 CET. SOURCE-ONLY. Both drafts are UNCOMPILED.

## Result

NativeStoredChildTraversal-v2-UNCOMPILED.lean contains one public theorem,
child_traversal_native_stored. Its conclusion directly inspects the actual
ChildTraversal.run result. Complete returns certify the returned caller.
Stopped returns certify the caller inside the retained exact observation.
No successful completion, final cache, or final semantic property is assumed.
Root must check the draft. The child does not claim that it elaborates.

CLOSED-HEADER.md records the exact proposed header before the proof draft.
SUCCESSOR-GATES.md records every recursive gate and its concrete producer.
The source review found a producer route under the existing current gates.
No new abstract transition supplier or future gate was added.

## Current header

The header retains the current TraversalResources admission interface:
decision instances, bits+2 caller, Seed, formulas, solver, inventory, caller,
cache, checkEmpty, original input list, roots, and original memos. It adds
arbitrary actual r/n/p/h/k and separate entry native Stored.

Current facts are Context, Safe, Roots, correct waiting counts, exact candidate
flags for the current cache, PendingRealized, current genuine input facts,
Fits, Reserved(cost inputs), known annotation heap, and entry native Stored.
The genuine facts provide incoming availability/closedness, bounded bucket
variables, and InputsPending for each original child pair.
These are the existing current traversal resource gates. Current Roots is
retained; no future Paths, Trace, Complete, or per-step supplier is supplied.

## Concrete proof route

The proof inducts on the actual input list. The empty input returns the
original caller and uses entry Stored. For each actual head dispatch it
applies the checked all-outcome ChildDispatch law using a prefix of the
original current reservation. It then inspects the exact observed result.

Every nonrecursive outcome uses the reached head Stored fact. These include
outer failure, no raw result, empty raw output, an error row, multiple rows,
and an absent cache. Only the exact singleton successful row with a present
cache reaches the recursive worker branch.

For that branch, ChildCompletion.complete_with_fragments_resources constructs
the existing canonical successor packet from original current facts inside
the proof. No completion witness is a theorem argument. Its stable run is
instantiated at its own sufficient bounds. Existing run_some_unique identifies
that packet with the actual observed singleton/cache return even when the
observed bounds differ. Both calls have supported successful shapes.

The canonical rejected shape contradicts the actual singleton row. The
canonical singleton shape gives Safe for the identified actual cache.
The packet also gives its actual Context, Roots, waiting counts, flags,
PendingRealized, Fits, known heap, counter growth, origin, and protected slots.
The proof derives every tail genuine fact from these concrete fields and
original current genuine facts. Reserved.after_prefix derives the exact tail
reservation. The packet query equality changes the recursive input to the
actual saved queries. The induction hypothesis uses the actual reached
Stored fact from the checked head law. Both recursive complete and stopped
outcomes retain that result. No whole-traversal Trace is constructed or used.

## Versions

V1 is retained unchanged. V2 changes local binder names only, as recorded in
DRAFT-VERSIONS.md. The public header and proof route are unchanged. The child
did not compile either version or run the system.

## Source scope

The two named OLD whole acquisitions are TraversalResources293L and
ChildResources153L. They were named before acquisition. The remaining OLD
sources have only exact bounded declaration locators and cuts. The largest
other cumulative union is ChildDispatchUnique30/53L. No third OLD whole or
near-whole module was acquired. No broad parent-worker source scan occurred.

The checked NEW ChildDispatch81L source was explicitly reused at the exact
installed pin b611e3f70fbe8900f7fba75cf500d008984977d427d904febf169cf7e03306f4.
Root reports the exact82L owner draft passed its first strict probe unchanged.
The installed module removes the status line only. The child did not execute
its checks. The prior source and inventory bundles remain frozen unchanged.

There are 17 source acquisition records over 10 source files. acquisitions.json
retains source path, full SHA, line/byte counts, exact acquired lines/range,
copy pin, and acquisition classification. Locator stdout and stderr are
retained. CUMULATIVE-SOURCE-UNIONS.json records every acquired line per source.
PATH-LOCATORS.md records the bounded initial file-name searches.
No command error, source drift, missing file, or output truncation occurred.

## Remaining boundaries

If Root checks this draft, it extends native ordinary empty-domain structural
certificate transport through the actual child traversal worker, including
stopped outcomes, under existing current resource gates.
It does not establish their admission from the full original public request,
original sufficient depth/capacity, whole parent enumeration, global finite
coverage, or Haskell correspondence. Native Stored remains separate from the
merge.Context Stored property. No Haskell execution, defect, or fix was
established. This task adds no Haskell FINDINGS entry.

## Validation and freeze

The child checked retained source hashes, repeated-source consistency, exact
line unions, and the two-OLD-whole scope. It ran no compiler, evaluator,
native execution, Git, network, board, or production mutation. Root owns all
checking and installation. All versions, sources, locators, and metadata are
retained in the frozen payload manifest and pins.
