# Named OLD whole scope

Named before acquisition at 2026-10-31 01:15 CET.
1. SourcePruningEnumerationTraversalResources.lean (293L).
2. SourcePruningEnumerationChildResources.lean (153L).
No third OLD whole or near-whole source is authorized.
