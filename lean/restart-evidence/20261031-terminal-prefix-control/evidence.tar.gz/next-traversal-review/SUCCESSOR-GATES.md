# Actual recursive-successor gate derivation

No future supplier occurs in the public header. The draft uses this route.

| Recursive gate | Existing actual producer |
| --- | --- |
| Exact reached native Stored | Checked ChildDispatch all-outcome law at original current entry |
| Exact caller/cache at a singleton return | ChildCompletion.complete_with_fragments_resources derived internally, then ChildDispatch.run_some_unique against the actual observed singleton/cache return |
| Context | The identified packet's Post.context |
| Safe | The packet's singleton shape; the rejected shape contradicts actual singleton by raw equality |
| Roots/waiting counts/cache flags | The identified packet's current successor fields |
| PendingRealized | The identified packet's current successor field |
| Fits/known heap | The identified packet's advanced resource fields |
| Tail incoming availability | Post.effects.keeps.available applied to original current genuine input |
| Tail incoming closedness | Original current genuine input |
| Tail variable bound | Packet counter growth applied to original current bound |
| Tail InputsPending | Packet EnumeratedOrigin and protected prior enumerated slots, applied to original current InputsPending |
| Tail reservation | Original Reserved.after_prefix at cost rest |
| Exact recursive query input | Packet final.query equality identified with the actual saved queries |

The completion packet is obtained from current entry gates inside the proof.
It is not a public completion premise. Its sufficient bounds can differ from
the observed call's bounds because run_some_unique equates two supported
successful calls at arbitrary bounds. The actual returned raw row need not
be assumed equal to the actual cache core; the worker ignores that row state.
The canonical packet's shape supplies Safe for the identified cache itself.
