# Scope

Root assigned this fresh source-only task at 2026-10-31 00:44 CET.
Close actual Terminal.run native Stored from existing current entry/resource gates and separate entry native Stored. Compose checked all-outcome Fold and Incoming. Derive actual successor entry facts. If a concrete observed-success producer is absent, prove that smallest companion and report the exact blocker. No future Ready/Realized/Fits/Room/Available, Ranges, Trace or output Stored supplier. All terminal early exits need their own reached Stored.

Root owns compiler/evaluator/native/Git/network/board/production/packaging. No spawning. All writes stay here; prior bundles remain frozen. Max two named OLD whole/near-whole modules, named before acquisition; bounded exact cuts otherwise with full provenance/unions. Explicit full checked NEW reuses: NativeStoredFold, NativeStoredDispatch and NativeStoredIncoming.
