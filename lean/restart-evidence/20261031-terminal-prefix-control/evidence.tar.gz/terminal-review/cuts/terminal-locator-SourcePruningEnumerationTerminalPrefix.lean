import MicroCFTA.EnumerationCompleteness
import MicroCFTA.EnumerationCanonicalUnion
import MicroCFTA.EnumerationBuilderCaches
import MicroCFTA.SourcePruningEnumerationObservation
namespace MicroCFTA.SourcePruningEnumerationTerminalPrefix
def run (fuel : Nat) (first : EnumerationState.Suspended) (rest : List EnumerationState.Suspended)
theorem run_complete
