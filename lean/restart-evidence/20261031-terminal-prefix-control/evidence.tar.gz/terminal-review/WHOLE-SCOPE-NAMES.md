# Named OLD whole modules

1. `lean/MicroCFTA/SourcePruningEnumerationTerminalAdmission.lean` (115 lines). Named before acquisition. It defines actual prefix and fold admission from current terminal reservations.
2. `lean/MicroCFTA/SourcePruningEnumerationTerminalObservedResources.lean` (190 lines). Named before acquisition. Its proof follows the exact actual terminal prefix/fold/incoming outcomes.
