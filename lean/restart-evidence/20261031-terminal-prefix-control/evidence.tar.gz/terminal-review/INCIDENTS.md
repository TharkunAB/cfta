# Incidents

The initial intake script stopped with AssertionError because rg returned exit 2 for a nonexistent assumed TerminalResources.lean filename. All three NEW source pins matched and all three copies had already been retained. The first interpretation as a pin failure was incorrect; INITIAL-PIN-CHECK-FAILURE.json retains the confirming hashes. The exact locator was rerun once to retain its full partial stdout/stderr and exit 2. The actual resource filenames were then located by filename only. No compiler/evaluator/native execution ran.
