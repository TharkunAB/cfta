# Native Stored through every actual terminal outcome

Status: complete source-only V1 candidate. This worker ran no compiler,
evaluator or native execution. No new law is claimed checked here.

## Result

NativeStoredTerminal-v1-UNCOMPILED.lean has 152 lines and one public theorem,
terminal_native_stored. Its conclusion concerns the actual Terminal.run result's
.2.1.checked.native. It covers every representative/native fuel r/n, p and h,
both checkEmpty modes and all terminal outcomes.

The entry premises are the EXISTING current TerminalObservedResources premises,
plus separate entry native Stored:

- Context and current Safe/Roots/canonical waiting facts.
- Bounded first/rest suspended inputs and InputsPending.
- Current PendingRealized and available/closed incoming.
- Fits seed.2 and the current mixed reservation for (first :: rest).length + 1.
- The current seed alphabet heap.
- Native Stored at beforeCaller.checked.native.

No future fold Ready, Realized, Fits, Room, availability, trace, output Stored,
success or completion is supplied. Existing exports derive all later entry
facts. No additional observed-success companion was needed.

The complete public header is in PUBLIC-CONTRACT.md. Candidate SHA-256:
cf9f3fc9a74c60782ada2c68bc3c85abb2a0c847cbefbfbab739d02210e09bc6.

## Actual prefix producer

Empty incoming returns beforeCaller directly. Every non-singleton-success
TerminalPrefix observation also returns beforeCaller. The candidate supplies
entry Stored at each such result, including prefix errors and exhausted bounds.

Only the ACTUAL singleton-success prefix enters the fold. The existing
CachedTerminalAdapter.observed_prefix producer consumes that exact prefix
observation and the current roots/waiting/safe/bounded/pending/realized facts.
It derives the actual recorded roots list, joined PendingRealized, pending
winner and pending recorded sources.

The recorded-list equality gives its length. The existing current reservation
then supplies a prefix reservation for the actual fold length. The original
Context, Fits and known heap still concern the same unchanged caller.

## All fold outcomes

The checked all-outcome Fold.fold_native_stored law is applied BEFORE any fold
outcome split. Rewriting its conclusion with the actual fold observation gives
Stored at foldCaller.

That same certificate covers all fold stops: outer error, absent result,
empty raw list, error first row and a list with multiple rows. The literal
Terminal.run definition returns foldCaller in each of these branches. Its
status and enumeration/waiting components do not change the checked caller.

Only the actual successful singleton row can enter IncomingNode.run.

## Successful-fold entry facts are derived

The successful singleton branch reuses the exact existing derivation in
TerminalObservedResources. It does not assume a future postcondition.

1. Fold.initial_ranges derives the old Ranges predicate from the CURRENT
   reservation and current validated joined slots. It is an internal result.
2. Fold.run_complete constructs its completion from those current facts.
3. Fold.ok_unique compares that constructed successful observation with the
   ACTUAL successful fold observation. It identifies the actual caller and
   saved queries. The constructed raw shape excludes rejection and identifies
   the successful row's actual enumeration state.
4. This yields the actual fold caller's post Context and PendingRealized for
   folded. The post's keeps property retains incoming availability at that
   actual caller. The closed syntax fact is unchanged.
5. Fold.observed_resources derives Fits at advance seed recorded.length from
   the actual fold observation and current entry/resource premises.
6. The ORIGINAL reservation supplies Room at that same advanced profile. Its
   bound comes from the already derived recorded length. No new Room is given
   at a future state.

These are existing proved producers. The candidate reproduces their existing
source-level composition. The internally constructed completion is not a new
public future-completion hypothesis.

The checked Incoming.incoming_run_stored law then consumes those DERIVED entry
facts and foldStored. The actual incoming result supplies Stored at its own
returned caller. All incoming error/none/some branches of Terminal.run retain
that exact caller. The mapped fragment rows affect a different tuple field.

## Exact checked inputs

The explicit full checked NEW reuses are:

- NativeStoredFold, 86 lines, SHA-256
  89e2076f35378262c6d2997bfab9c3be35ad8cfa26d3bdb985989d339d101791.
- NativeStoredDispatch, 151 lines, SHA-256
  01499c214a1a0ddf5f995ed347ae22505be36f0ec8e6ddc0c3f7462012667878.
- NativeStoredIncoming, 105 lines, SHA-256
  cd5b5db4b57e99d5f5cfe3a0c5c994464d814911b0c7cf73373d9f27fd0cae05.

All three supplied source pins matched. Root owns their compilation, execution
and review evidence. The dispatch reuse is retained as the checked fold's
explicit new-law dependency; this terminal proof invokes Fold and Incoming.

## Scope, acquisitions and incident

Two OLD whole modules were named before acquisition:

1. TerminalAdmission, 115 lines. It provides the actual generic observed_prefix
   producer and shows the derived current reservation/fold admission route.
2. TerminalObservedResources, 190 lines. Its proof contains the actual
   singleton-fold post/keeps/Realized and advanced-Fits composition reused here.

Other reads are bounded exact declaration locators and Terminal.run lines 1-66
of 309. The FoldAdmission read is declaration lines only. No third OLD whole or
near-whole module was acquired. Every complete source pin, byte/line count,
exact selected lines, retained copy and copy hash is in acquisitions.json.
CUMULATIVE-SOURCE-UNIONS.json records the repeated-read unions.

The first intake script stopped with AssertionError because rg returned exit 2
for the assumed nonexistent TerminalResources.lean filename. It had already
verified and copied all three correct NEW pins. An initial interpretation as a
pin mismatch was incorrect. The retained metadata confirms all supplied pins.
The exact locator was rerun once to retain the partial output/stderr, then the
actual resource filename was located. INCIDENTS.md and INTAKE-FAILURE.txt record
the event. No source evidence was silently discarded.

All writes stayed in /tmp/mcfta-native-terminal-stored-review-20261031. Prior
bundles remain frozen. No compiler, evaluator, native execution, Git, network,
board, production change, packaging operation or spawned worker occurred.
Root alone owns execution and checking. The complete V1 candidate is immutable.

## Boundaries

Native Stored remains the conditional structural certificate for returned
native cells. It is separate from Context.stored, which concerns the merge
memo. This law does not establish finite ordinary bounds for every recursive
request or result.

The current reservations and validated entry facts remain premises. The law
does not derive them from the initial original input. Sufficient original depth,
original-input capacity, source reset, unchanged steps, whole-worker induction,
finite global enumeration, public API correspondence and Haskell correspondence
remain outside this result.

No Haskell source changed. No admitted actual Haskell execution occurred. No
Haskell defect or fix was established. There is no new Haskell FINDINGS entry.
