# Nearest closed child-dispatch target

UNPROVED HEADER ONLY. No proof draft is supplied. Terminal152L is still
UNCOMPILED/unconfirmed in this inventory and must pass Root's checks first.
The header uses the actual ChildObservedResources current entry premises plus
separate entry native Stored. Local Symbol/Constraint/Node/Caller/Cached/Heap
notations are those in the acquired child definitions.

```lean
theorem child_dispatch_native_stored
    {bits : Nat}
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
    (seed : SourcePruningEnumerationIncomingReservation.Seed)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : SourceCurrentAllocatedNativeInventoryState.Inventory)
    (beforeCaller : SourceCurrentAllocatedPartialState.State (bits + 2))
    (before : EnumerationExpandableIndex.Cached Symbol Constraint)
    (checkEmpty : Bool) (r n p h k : Nat) (bucket : List EnumerationState.Suspended)
    (incoming : Node) (roots : Nat → Nat) (memos : EndpointMemoGateTrace.Memos)
    (initial : SourceCurrentAllocatedPartialInvariant.Context formulas solver inventory beforeCaller memos)
    (safe : Safe before.core) (paths : Roots before.core.representatives roots)
    (counts : EnumerationCanonicalWaiting.Correct roots before.core.values before.waiting)
    (realized : PendingRealized beforeCaller.checked.native.machine.heap before.core)
    (bounded : ∀ sc ∈ bucket, sc.var < before.core.counter)
    (pending : InputsPending before.core bucket)
    (available : Available beforeCaller.checked.native.machine.heap incoming)
    (closed : incoming.free = [])
    (fits : SourceCurrentConstrainedCapGeneratedQueryResources.Fits seed.2 beforeCaller.checked)
    (reserved : SourcePruningEnumerationIncomingReservation.Reserved bits seed (bucket.length + 1))
    (known : SourceEqualityAnnotationHeap.Heap (fun guard => guard ∈ seed.1)
      beforeCaller.checked.native.machine.heap)
    (stored : SourceCurrentAllocatedFiniteOrdinaryStored.Stored beforeCaller.checked.native) :
    SourceCurrentAllocatedFiniteOrdinaryStored.Stored
      (SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k bucket incoming
        beforeCaller before memos.query).1.2.1.checked.native
```

The existing erase equality reduces this cached target to observe. Empty and
nonterminal branches retain beforeCaller. For the actual terminal partition,
partition_subsets derives active bounded/pending and terminal_length_le with
Reserved.prefix derives the current terminal reservation. After verification,
the Terminal law can consume those current facts. No future entry or output
certificate is added.
