# Child-dispatch native Stored proof handoff

2026-10-31 01:11 CET. SOURCE-ONLY. UNCOMPILED child draft.

## Deliverable

`NativeStoredChildDispatch-v1-UNCOMPILED.lean` contains one public theorem:
`child_dispatch_native_stored`. It targets the exact actual cached call:

```lean
Stored (SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k bucket incoming
  beforeCaller before memos.query).1.2.1.checked.native
```

The header retains every current ChildObservedResources entry gate and adds
only the separate entry native Stored property from the prior target header.
The proof has no future Terminal entry fact, result certificate, Ranges,
Trace, abstract transition supplier, or completion premise.
Root must check the draft. The child does not claim that it elaborates.

## Current gates

The header has the existing decision instances and bits+2 width. Its current
arguments are Seed, formulas, solver, inventory, caller, cache, all five
fuel/bound numbers, bucket, incoming value, roots, and original memos.
Its current facts are Context, Safe, Roots, correct waiting counts,
PendingRealized, bounded bucket variables, InputsPending, available and closed
incoming, Fits, the bucket.length+1 reservation, known annotation heap, and
entry native Stored. It does not add a cache-candidate validity premise.

## Actual branch derivation

1. The checked existing ChildDispatch.erase equality rewrites the first
   projection of the actual cached run to the original observe function.
   This keeps the exact reached caller in every result shape.
2. The empty branch returns beforeCaller. The theorem uses entry Stored.
3. In the actual empty terminal partition, both shallow preparation outcomes
   retain beforeCaller. Its action output and cached preparation result do
   not occur in the caller projection. The theorem uses entry Stored.
4. In the actual nonempty terminal partition, partition_subsets derives the
   bounded and pending facts for first::rest from the original bucket.
   terminal_length_le and Reserved.prefix derive the exact current terminal
   reservation. The checked all-outcome Terminal law then supplies Stored
   for that actual call. No final result is matched or assumed successful.

All actual outer results, shallow result shapes, cache candidates, terminal
faults, and early exits are included in the single conclusion. The proof
uses no indexFuel bound because erase holds for arbitrary indexFuel.

## Checked dependency

Root confirmed SourceCurrentAllocatedNativeStoredTerminal.lean, 151 lines,
SHA256 fe8635931f5acb738d6dfb100501039ebd51320ac7168233cbdca9d1dacca897.
Root reports default lake and strict PASS and a full read. Its only change
from the preceding owner draft removed two unused simp arguments.
The exact installed module is retained here as an explicit checked NEW reuse.
The prior header copy keeps its old Terminal notice without alteration.

## Source scope and provenance

The two named OLD whole modules are ChildObservedResources (115 lines) and
ChildAdmission (83 lines). Both copies match their frozen owner pins and
current full-source SHA. The only other OLD source cut is ChildDispatch
lines 1-90 of 224. This cut includes observe, run, and erase. It matches the
frozen cut pin and current full-source SHA. No additional code was searched.

acquisitions.json records all four code source records. Each record includes
full-source path, SHA, line and byte counts, exact acquired range, copy pin,
and classification. Frozen reuses retain the exact prior owner manifest pin.
CUMULATIVE-SOURCE-UNIONS.json records the cumulative acquired line union per
source. metadata-reuses.json records the prior header and provenance copies.
No prior frozen payload changed. No production file changed.

## Remaining boundary

This draft extends the native ordinary empty-domain structural certificate
transport to one concrete handler if Root accepts it. It does not prove a
ChildTraversal worker law, original sufficient depth/capacity, original-input
finite enumeration, public API coverage, or Haskell correspondence.
Native Stored is separate from merge.Context Stored.
No actual Haskell execution occurred. No Haskell defect or fix was established,
so this task adds no Haskell finding or FINDINGS entry.

## Validation and freeze

The child checked source and retained-copy hashes, declared source line
counts, and the four-source cumulative scope. It did not compile or evaluate
the candidate. Root owns all proof checking and installation.
The payload manifest and pins identify the immutable handoff below.
