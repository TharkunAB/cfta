# Child-dispatch native Stored proof scope

Started 2026-10-31 01:10 CET. Source-only child task. Root owns all execution.
Prove the exact prior NEXT-CLOSED-HEADER target for actual ChildDispatch.run.
Keep the existing current ChildObservedResources gates and separate entry native Stored.
No ChildTraversal law. No future Terminal admission facts or output certificates.
No compiler, evaluator, native execution, Git, network, board, production edits, or spawning.

The two named OLD whole acquisitions are:
1. SourcePruningEnumerationChildObservedResources.lean (115 lines).
2. SourcePruningEnumerationChildAdmission.lean (83 lines).

Explicit checked NEW full reuse: SourceCurrentAllocatedNativeStoredTerminal.lean,
151 lines, SHA256 fe8635931f5acb738d6dfb100501039ebd51320ac7168233cbdca9d1dacca897.
Root reports default lake and strict checks pass. The child does not execute checks.
