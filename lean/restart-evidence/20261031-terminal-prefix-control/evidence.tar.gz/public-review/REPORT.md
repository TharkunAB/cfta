# Independent source and public contract review

PASS. The reviewer read all 512 installed source lines, all 250 new public output lines, and the complete 346-line combined repair-diff review. The current source and four public contracts agree. No source defect or public contract defect was found.

This is a source-only review. Root owns compilation, execution, native checks, Git, publication, and packaging. The reviewer changed only this owned temporary directory. Root reports that the installed modules, strict checks, full Audit, and final public readback passed. The reviewer independently checked the final public log's byte count and SHA-256 as metadata. The complete old public body was not acquired.

## Current source

| Module | Installed lines | SHA-256 |
| --- | ---: | --- |
| SourceCurrentAllocatedNativeStoredTerminal |151|fe8635931f5acb738d6dfb100501039ebd51320ac7168233cbdca9d1dacca897|
| SourcePruningNarrowPrefixObservation |280|87ef63681bbeca51338c190b152adcfe33be949e12926fe7844ba2e211c8dbee|
| SourceCurrentAllocatedNativeStoredChildDispatch |81|b611e3f70fbe8900f7fba75cf500d008984977d427d904febf169cf7e03306f4|

`acquisitions.json`, `read-ledger.json`, and the input copies pin the exact current source and public ranges. The final public tail has 250 lines and 17,988 bytes. Its SHA-256 is 73dc309f62c0217c0f770575418a9865319b8e7940aaddd038ad1ceb3b70e6c4. Every tail chunk was displayed in full. All four axiom reports contain only `propext`, `Classical.choice`, and `Quot.sound`.

## Meaning of the native certificate

`SourceCurrentAllocatedFiniteOrdinaryStored.Stored` constrains returned native node and edge cells. For a node request, an empty seen-list and finite ordinary input domains imply that the returned value has a finite ordinary domain and height at most each input height. The edge certificate gives the corresponding edge property. These are conditional structural certificates. This property does not assert result semantics, heap constructor normality, or a certificate for every active cell.

`EqualityOrdinaryReadback.Normal heap value` is the literal fixed point:

```text
run (makeNode (nodeEdges value)) heap = (value, heap)
```

This review keeps that property distinct from `Stored`. The prefix law also gives an exact `lookupNode` equation. It does not add an arbitrary recursive-reader-fuel theorem.

## Terminal law

`terminal_native_stored` retains the native certificate at the actual caller returned by `SourcePruningEnumerationTerminal.run`. The representative, native, and worker fuels are arbitrary. Both Empty-check settings are included.

The public entry conditions remain explicit: the current Context, Safe state, root relation, canonical waiting counts, bounded active variables, pending inputs, current PendingRealized, incoming availability and closure, Fits, a reservation for the active list length plus one, known guards, and entry Stored. The source and public headers match the producer header exactly.

The proof covers every actual branch:

- Empty incoming and every non-singleton or failed prefix result retain the entry caller.
- A successful singleton prefix derives the actual recorded list, joined realization, target pending fact, and recorded-source pending facts from current inputs.
- The native Fold certificate is obtained before the Fold outcome is split. Every early Fold return uses the certificate for the actual reached Fold caller.
- Only the actual singleton Fold success derives the remaining incoming entry facts. Fold ranges are derived internally from the seed and reservation. Existing completion and success uniqueness identify the actual caller and enumeration core. The proof does not request a future completion supplier from the public caller.
- Observed Fold resources, heap growth, and the remaining reservation provide the actual incoming admission. The incoming certificate covers every actual incoming outcome.

The bounded old definition of Terminal.run confirms the returned caller projections in every branch. The bounded observed-prefix, Fold completion, Fold success uniqueness, initial-ranges, and observed-resources contracts match their uses.

## Prefix stage law

`prefix_changed_stages` takes one exact `runPrefix` equality with the retained narrowed result, one successful action row, an attached cache, the literal Right-false callback row, and no final continuation. It also takes `after.core ≠ checked`. Here `checked` is the core after the actual false recursion check.

The law derives the old read, false check, old lookup, prepare equation, result encoding, changed handle, successful action, actual adaptation equation, final core identity, callback core identity, unchanged metadata, and:

```text
reached.checked.native.machine.heap = nextHeap
```

Separate read, lookup, encoding, prepare, or action-success observations are not public inputs. All those observations come from the one exact prefix result. The actual input result tag remains a condition.

The private equal-handle lemma handles every prepare branch. Empty selects rejection and cannot yield a successful action row. An encoded equal handle selects `pure ()`, so its core cannot differ from `checked`. This excludes the equal-handle case without assuming an old Frame or Normal fact. The actual action source agrees.

The literal old runPrefix definition confirms the stage order, caller advancement with `prepared.state`, adaptation, and Right callback. The callback is `pure (false, metadata)` for this input. `adapt_core` preserves the observed core. The current caller-advance and physical-advance definitions confirm that the prepared heap is the caller's actual retained heap.

## Prefix normal slot law

`prefix_changed_stores_normal` retains that same one result equality and change condition. It additionally requires only current heap Ready, current PendingRealized, and total input union-find representatives. It has no public old Frame, old Normal, old availability, old closure, stage-success, future Trace, or future completion premise.

The conclusion gives the actual caller heap equality above. At that exact heap it gives the encoded result, changed handle, old lookup, Keeps, result availability, closure, root-form Ordinary, constructor Normal, exact lookup readback, and every retained row kept at the same hole key. If the old value is root-form Ordinary, every output row is an old row.

It also gives PendingRealized for the actual final core, the actual representative operation and derived compression Frame, the old stored slot, the successful setValue operation to the actual final core, the exact list update, and the final slot value. The imported slot-transport header was checked through an explicit bounded reuse of its prior NEW source. The current prefix law derives all its observed stage inputs.

Ordinary is a root-form condition for Empty or node. It is not recursive NodeDomain. The conditional row-subset property therefore has no recursive finite-domain premise.

The scope remains the specific observed narrowed/Right-false result with a changed core. This is not a theorem for every successful prefix call, every callback, unchanged calls, reset histories, index correctness, or a global filter count.

## ChildDispatch law

`child_dispatch_native_stored` retains the native certificate at the actual first projection of `SourcePruningEnumerationChildDispatch.run`. It covers arbitrary representative, native, worker, and index fuels and both Empty-check settings.

The public gates are the current Context, Safe core, root relation, canonical waiting counts, PendingRealized, bounded variables for the original bucket, pending inputs for that bucket, incoming availability and closure, Fits, a reservation for bucket length plus one, known guards, and entry Stored. The source and public headers match the producer header exactly.

The actual cache-erasure equation exposes the physical observation and caller. Empty incoming and all nonterminal preparation outcomes retain the entry caller. In the terminal partition case, the subset theorem derives bounded and pending conditions for the actual terminal list from the original bucket. The partition length theorem shortens the original reservation. The checked Terminal law supplies the actual returned native certificate. No index-validity premise or future result supplier is added. The theorem does not certify the attached index candidate or returned result semantics.

## Retained repairs and versions

Fourteen current-task source candidates and eleven adjacent diffs are retained. Every diff line was read. Terminal has two local simp-set repairs and a status-line removal. Its public header is exact. ChildDispatch passed the first Root strict probe unchanged; its installation removes only the 71-byte status line. Its public header is exact.

The original prefix drafts used the reserved token `prefix`. Those originals did not have valid parsed typed headers. The retained repairs rename that token, preserve dependent equations, add four explicit tuple equality types, and use the definitional read equality. This review does not describe the invalid original headers as already elaborated contracts.

Root V6 strengthens both passing V5 prefix conclusions with the actual caller heap equality. The public premises are byte-identical to passing V5. The installed source then removes only the uncompiled status line. `contract-checks.json` records those comparisons.

`INCIDENTS.md` records all aborted, failed, and truncated review helpers or displays and their recovery. No incomplete display was counted as a complete source or public read. Those incidents are separate from Root's four retained repaired compiler probes.

## Provenance and verification boundary

The OLD acquisition budget is zero whole or near-whole modules, within the maximum of two. Every bounded cut, reuse, and named locator is recorded by its ORIGINAL source path, full source hash and size, exact acquired line range or line numbers, copy hash, and retained copy. `old-source-unions.json` merges cuts and locators by original source path. Reusing a prior cut or a prior NEW-source fragment does not remove it from that union. No source path exceeds 46.2 percent acquired lines.

Current source and public chunks, repair diffs, acquisition ledgers, candidate versions, helper failures, metadata-only discoveries, and the report are included in the manifest. Prior immutable review bundles were not changed. Future traversal source was not acquired or reviewed.

Root reports20 serial compiler commands:16 passes and 4 retained repaired failures, with 53 snapshots. Audit passed at 4,761 jobs and 83,079 theorem dependencies. Public readback passed at 1,227 checks and 118 definition prints. Root reports exact preservation of 559 old protected files,835 native files, and 4,758 old Lean files except Audit. Full public metadata independently matches 4,923,220 bytes and SHA-256 8209f9dc182f021905f6bfffb184fbbf043ed1a28b460a6303a0468b28e6ac3e. The old and intermediate exact-prefix identities are Root-reported.

No Haskell defect or fix is established. No Haskell file was edited. These laws do not establish whole-worker correctness, whole-caller neutrality, public API or Word64 correspondence, Haskell correspondence, original-input/reset bounds, or global execution history transport.
