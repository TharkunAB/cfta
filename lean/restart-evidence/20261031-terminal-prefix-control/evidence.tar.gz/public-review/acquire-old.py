from pathlib import Path
import json, subprocess, hashlib
r=Path(__file__).parent
prior=Path('/tmp/mcfta-slot-and-native-dispatch-public-review-20261031')
repo=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
tasks=[('SourcePruningEnumerationTerminal.lean',32,65,None),('SourcePruningEnumerationChildDispatch.lean',28,42,None),('SourcePruningEnumerationChildDispatch.lean',46,84,None),('SourcePruningEnumerationTerminalAdmission.lean',32,58,None),('SourcePruningEnumerationFold.lean',69,94,None),('SourcePruningEnumerationFoldUnique.lean',30,47,None),('SourcePruningEnumerationFoldResources.lean',29,58,None),('SourcePruningEnumerationFoldAdmission.lean',107,137,None),('SourcePruningEnumerationChildAdmission.lean',29,48,None),('SourcePruningEnumerationNarrowAdapter.lean',10,29,None),('SourcePruningRecordTypes.lean',83,95,None),('SourcePruningEnumerationSelectedStep.lean',43,94,'old-cuts/SourcePruningEnumerationSelectedStep.lean-L43-L101.txt'),('SourceCurrentAllocatedPartialState.lean',50,65,'old-cuts/SourceCurrentAllocatedPartialState.lean-explicit-reuse-L50-L65.txt'),('SourceCurrentAllocatedFiniteOrdinaryStored.lean',24,38,'old-cuts/SourceCurrentAllocatedFiniteOrdinaryStored.lean-explicit-reuse-L24-L38.txt'),('SourceCurrentConstrainedCapGeneratedQueryResources.lean',33,58,'old-cuts/SourceCurrentConstrainedCapGeneratedQueryResources.lean-explicit-reuse-L33-L58.txt'),('SourcePruningEnumerationIncomingReservation.lean',17,28,'old-cuts/SourcePruningEnumerationIncomingReservation.lean-L17-L28.txt'),('SourcePruningEnumerationIncomingReservation.lean',71,100,'old-cuts/SourcePruningEnumerationIncomingReservation.lean-L71-L100.txt'),('SourceCurrentAllocatedNativeStoredFold.lean',28,55,'inputs/installed-fold.lean'),('SourceEqualityRequiredCache.lean',19,29,None),('SourceEqualityRequiredCache.lean',68,73,None),('EqualityOrdinaryReadback.lean',15,18,None),('SourceCurrentAllocatedNativeStoredIncoming.lean',26,55,None),('SourceCurrentAllocatedQueryMemo.lean',103,113,None)]
priorcuts=json.loads((prior/'old-source-cut-ledger.json').read_text());ledger=[]
for name,lo,requestedhi,reuse in tasks:
 p=repo/name;sha=subprocess.check_output(['sha256sum',str(p)],text=True).split()[0];wc=subprocess.check_output(['wc','-lc',str(p)],text=True).split();hi=min(requestedhi,int(wc[0]));data=subprocess.check_output(['sed','-n',f'{lo},{hi}p',str(p)]);assert len(data.splitlines())==hi-lo+1,(name,lo,hi)
 rel=f'old-cuts/{name}-L{lo}-L{hi}.txt';dest=r/rel
 if dest.exists():assert dest.read_bytes()==data
 else:dest.write_bytes(data)
 rec={'source_path':str(p),'source_lines':int(wc[0]),'source_bytes':int(wc[1]),'source_sha256':sha,'requested':[lo,requestedhi],'actual':[lo,hi],'copy':rel,'copy_sha256':hashlib.sha256(data).hexdigest(),'classification':'bounded OLD actual definition or producer header','read_complete':False}
 if reuse:
  saved=prior/reuse
  if reuse.startswith('old-cuts/'):
   match=next(x for x in priorcuts if x['copy']==reuse);start=match['actual'][0];assert match['source_sha256']==sha
  else:start=1;assert hashlib.sha256(saved.read_bytes()).hexdigest()==sha
  savedData=saved.read_bytes();sub=b''.join(savedData.splitlines(keepends=True)[lo-start:hi-start+1]);assert sub==data
  rec.update(classification='explicit bounded prior reuse counted against ORIGINAL source path',reuse_from=str(saved),reuse_from_sha256=hashlib.sha256(savedData).hexdigest(),reuse_origin_range_start=start)
 ledger.append(rec);(r/'old-source-cut-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
print('Retained',len(ledger),'bounded OLD cuts; no whole modules.')
