from pathlib import Path
import json,hashlib,subprocess,re,difflib
r=Path(__file__).parent;root=Path('/tmp/mcfta-terminal-and-prefix-observation-control-20261031');repo=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,x):(r/p).write_text(json.dumps(x,indent=2)+'\n')
# Current source and public chunks were read in full untruncated displays.
l=json.loads((r/'read-ledger.json').read_text())
for x in l:x['read_complete']=True
save('read-ledger.json',l)
old=json.loads((r/'old-source-cut-ledger.json').read_text())
for x in old:x['read_complete']=True
save('old-source-cut-ledger.json',old)
# Include every previously queried OLD source path, including named no-match searches.
extra=['SourcePruningEnumerationCachedTerminalAdapter.lean','SourcePruningEnumerationChildCompletion.lean','SourcePruningEnumerationTerminalObservedResources.lean','SourcePruningEnumerationCachedTerminal.lean','SourcePruningEnumerationChildTraversal.lean','SourcePruningEnumerationDispatch.lean','SourcePruningEnumerationChildObservedResources.lean']
paths=sorted(set([Path(x['source_path']) for x in old]+[repo/n for n in extra]))
pattern=r'^import |^theorem |^private theorem |^noncomputable def |^def |^structure Ready|observed_prefix|partition_subsets|terminal_length_le|ok_unique|observed_resources|recordTypes_inr|adapt_core|:= by'
(r/'old-locators').mkdir(exist_ok=True);loc=[]
for p in paths:
 data=subprocess.run(['rg','-n',pattern,str(p)],capture_output=True,check=False).stdout;rel=f'old-locators/{p.name}.txt';(r/rel).write_bytes(data);nums=[int(line.split(b':',1)[0]) for line in data.splitlines()];wc=subprocess.check_output(['wc','-lc',str(p)],text=True).split();loc.append({'source_path':str(p),'source_lines':int(wc[0]),'source_bytes':int(wc[1]),'source_sha256':subprocess.check_output(['sha256sum',str(p)],text=True).split()[0],'pattern':pattern,'actual_line_numbers':nums,'copy':rel,'copy_sha256':sha(data),'classification':'bounded named declaration/import/helper locators; acquisition union includes all matches; no whole source body'})
save('old-source-locator-ledger.json',loc)
unions=[]
for p in paths:
 xs=[x for x in old if x['source_path']==str(p)];ys=[x for x in loc if x['source_path']==str(p)];lines=set()
 for x in xs:lines.update(range(x['actual'][0],x['actual'][1]+1))
 for y in ys:lines.update(y['actual_line_numbers'])
 meta=(xs+ys)[0];ranges=[]
 for n in sorted(lines):
  if ranges and ranges[-1][1]+1==n:ranges[-1][1]=n
  else:ranges.append([n,n])
 unions.append({'source_path':str(p),'source_lines':meta['source_lines'],'source_bytes':meta['source_bytes'],'source_sha256':meta['source_sha256'],'actual_union':ranges,'unique_lines':len(lines),'fraction':len(lines)/meta['source_lines'],'whole_or_near_whole':False,'cut_count':len(xs),'locator_count':len(ys),'explicit_prior_reuse_count':sum('reuse_from' in x for x in xs)})
save('old-source-unions.json',{'whole_or_near_whole_acquisitions':0,'maximum_permitted':2,'source_paths':len(unions),'cuts':len(old),'cut_lines':sum(x['actual'][1]-x['actual'][0]+1 for x in old),'reused_cuts':sum('reuse_from' in x for x in old),'entries':unions})
# Retain only current-task NEW source candidates; do not acquire old generated public/Audit sources or future traversal.
(r/'inputs/history').mkdir(exist_ok=True);versions=[]
files=[p for p in sorted(root.glob('*.lean')) if any(p.name.startswith(n) for n in ['native-terminal-','prefix-observation-','native-child-dispatch-','installed-terminal-','installed-prefix-','installed-child-dispatch-'])]
files += [root/'terminal-review/NativeStoredTerminal-v1-UNCOMPILED.lean',root/'prefix-review/SourcePruningNarrowPrefixObservation-v1-UNCOMPILED.lean',root/'prefix-review/SourcePruningNarrowPrefixObservation-v2-UNCOMPILED.lean']
for p in files:
 b=p.read_bytes();rel='inputs/history/'+(p.parent.name+'-' if p.parent!=root else '')+p.name;(r/rel).write_bytes(b);versions.append({'source_path':str(p),'source_lines':len(b.splitlines()),'source_bytes':len(b),'source_sha256':sha(b),'copy':rel,'copy_sha256':sha(b),'classification':'retained current-task NEW producer/probe/installed source candidate; not a complete separate version reread'})
save('candidate-version-metadata.json',versions)
(r/'diffs').mkdir(exist_ok=True)
groups=[['terminal-review-NativeStoredTerminal-v1-UNCOMPILED.lean','native-terminal-v1.lean','native-terminal-v2.lean','installed-terminal-v3.lean'],['prefix-review-SourcePruningNarrowPrefixObservation-v1-UNCOMPILED.lean','prefix-review-SourcePruningNarrowPrefixObservation-v2-UNCOMPILED.lean','prefix-observation-v2.lean','prefix-observation-v3.lean','prefix-observation-v4.lean','prefix-observation-v5.lean','prefix-observation-v6.lean','installed-prefix-v7.lean'],['native-child-dispatch-v1.lean','installed-child-dispatch-v2.lean']]
diffs=[]
for group in groups:
 for a,b in zip(group,group[1:]):
  pa=r/'inputs/history'/a;pb=r/'inputs/history'/b;data=''.join(difflib.unified_diff(pa.read_text().splitlines(keepends=True),pb.read_text().splitlines(keepends=True),fromfile=a,tofile=b));rel='diffs/'+a+'--'+b+'.patch';(r/rel).write_text(data);diffs.append({'before':str(pa.relative_to(r)),'after':str(pb.relative_to(r)),'diff':rel,'bytes':len(data.encode()),'sha256':sha(data.encode()),'read_complete':False})
save('candidate-diffs.json',diffs)
# Compare each final probe/install byte identity against the exact fully read current source.
for name,dest in [('installed-terminal-v3.lean','installed-terminal.lean'),('installed-prefix-v7.lean','installed-prefix.lean'),('installed-child-dispatch-v2.lean','installed-child.lean')]:assert (r/'inputs/history'/name).read_bytes()==(r/'inputs'/dest).read_bytes()
# Root-reported run facts; no local compiler/evaluator/native invocation.
save('root-reported-validation.json',{'owner':'Root','independent_execution':False,'audit_jobs':4761,'theorem_dependencies':83079,'public_checks':1227,'definition_prints':118,'new_standard_only_axiom_reports':4,'commands':20,'passed':16,'retained_repaired_failed_probes':4,'snapshots':53,'full_public_bytes':4923220,'full_public_sha256':'8209f9dc182f021905f6bfffb184fbbf043ed1a28b460a6303a0468b28e6ac3e','old_public_exact_prefix_bytes':4905232,'intermediate_v2_exact_prefix_bytes':4920113,'final_new_tail_bytes':17988,'final_new_tail_lines':250,'final_new_tail_sha256':'73dc309f62c0217c0f770575418a9865319b8e7940aaddd038ad1ceb3b70e6c4','old_protected_exact':559,'old_native_exact':835,'old_Lean_exact_except_Audit':4758,'source_commits':['0bc6427b0fe44296804c70a3a15a06d05c645b9a','26bc1faf496e9ceb45555bf3af7be99da79bb97c','1e7a2b6f459ea72279ec576c23fe6b1027abe84f']})
print('Old cuts:',len(old),'source paths with locator unions:',len(unions),'max acquired fraction:',round(max(x['fraction'] for x in unions),3),'candidate versions:',len(versions),'diffs:',len(diffs))
print('Diff payloads:',[(x['diff'],x['bytes']) for x in diffs if x['bytes']])
