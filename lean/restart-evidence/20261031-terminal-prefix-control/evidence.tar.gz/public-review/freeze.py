from pathlib import Path
import json,hashlib,subprocess,datetime,os
r=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def j(p):return json.loads((r/p).read_text())
# Complete range and copy verification for current source/public readbacks.
read=j('read-ledger.json');coverage={}
for x in read:
 assert x['read_complete'];data=(r/x['source']).read_bytes();assert sha(data)==x['source_sha256'];lo,hi=x['actual'];cut=b''.join(data.splitlines(keepends=True)[lo-1:hi]);assert cut==(r/x['copy']).read_bytes() and sha(cut)==x['copy_sha256'];coverage.setdefault(x['source'],set()).update(range(lo,hi+1))
for source,n in [('inputs/installed-terminal.lean',151),('inputs/installed-prefix.lean',280),('inputs/installed-child.lean',81),('inputs/public-final-new-tail.log',250)]:assert coverage[source]==set(range(1,n+1))
# Verify every retained source acquisition against its named original.
for name in ['acquisitions.json','candidate-version-metadata.json','old-source-cut-ledger.json']:
 for x in j(name):
  assert sha((r/x['copy']).read_bytes())==x['copy_sha256'];assert subprocess.check_output(['sha256sum',x['source_path']],text=True).split()[0]==x['source_sha256']
  if name=='old-source-cut-ledger.json':
   assert x['read_complete'];lo,hi=x['actual'];assert subprocess.check_output(['sed','-n',f'{lo},{hi}p',x['source_path']])==(r/x['copy']).read_bytes()
   if 'reuse_from' in x:assert sha(Path(x['reuse_from']).read_bytes())==x['reuse_from_sha256']
for x in j('candidate-diffs.json'):assert x['read_complete'] and sha((r/x['diff']).read_bytes())==x['sha256']
for x in j('old-source-locator-ledger.json'):
 assert sha((r/x['copy']).read_bytes())==x['copy_sha256'];assert subprocess.check_output(['sha256sum',x['source_path']],text=True).split()[0]==x['source_sha256']
u=j('old-source-unions.json');assert u['whole_or_near_whole_acquisitions']==0 and u['cuts']==28 and u['source_paths']==29 and u['cut_lines']==589 and u['reused_cuts']==9
assert all(x['fraction']<0.463 for x in u['entries'])
validation={'status':'PASS','current_source_lines':512,'current_public_lines':250,'all_four_contracts_read':True,'all_four_axiom_reports_standard_only':True,'old_whole_acquisitions':0,'old_cut_lines':589,'old_cuts':28,'old_source_paths_with_locators':29,'explicit_prior_reuse_cuts':9,'candidate_versions':14,'adjacent_diffs':11,'all_346_combined_diff_lines_read':True,'source_and_copy_hashes_verified':True,'prior_bundles_changed':False,'execution_owned_by':'Root','reviewer_compiler_evaluator_native_Git_network_board_production_actions':0,'Haskell_defect_or_fix_established':False}
(r/'verification.json').write_text(json.dumps(validation,indent=2)+'\n')
files=[]
for p in sorted(r.rglob('*')):
 if p.is_file() and p.name not in ['MANIFEST.json','pins.json']:
  b=p.read_bytes();files.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':sha(b)})
manifest={'schema':1,'status':'PASS; frozen independent source/public review','created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':str(r),'payload_count':len(files),'payload_bytes':sum(x['bytes'] for x in files),'files':files}
(r/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');pins={x['path']:x['sha256'] for x in files};pins['MANIFEST.json']=sha((r/'MANIFEST.json').read_bytes());(r/'pins.json').write_text(json.dumps({'pins':pins},indent=2)+'\n')
actual={str(p.relative_to(r)) for p in r.rglob('*') if p.is_file()};assert actual==set(pins)|{'pins.json'}
for path,h in pins.items():assert sha((r/path).read_bytes())==h
for p in r.rglob('*'):
 if p.is_file():p.chmod(0o444)
for p in sorted((p for p in r.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
r.chmod(0o555)
assert all(not(p.stat().st_mode&0o222) for p in r.rglob('*'))
print(json.dumps({'status':'FROZEN PASS','payload_count':len(files),'total_files':len(actual),'payload_bytes':manifest['payload_bytes'],'total_bytes':sum(p.stat().st_size for p in r.rglob('*') if p.is_file()),'MANIFEST_sha256':pins['MANIFEST.json'],'pins_sha256':sha((r/'pins.json').read_bytes()),'REPORT_sha256':pins['REPORT.md']},indent=2))
