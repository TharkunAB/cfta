# Named OLD whole modules

1. `lean/MicroCFTA/SourcePruningEnumerationChildObservedResources.lean` (115 lines). Named before acquisition. It states current child gates and terminal/prepare admission routes.
2. `lean/MicroCFTA/SourcePruningEnumerationChildAdmission.lean` (83 lines). Named before acquisition. It proves the exact terminal partition subsets, length bound and current mixed-reservation admission.
