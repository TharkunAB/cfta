# Incidents

The child-caller locator display exceeded its tool output budget. The complete raw stdout/stderr and all exact source-line copies had already been retained before display. Selected actual implementation references were then read from that retained output. No source data was lost. No compiler/evaluator/native execution ran. Inventory only; no new proof.
