    (head : SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k
        have headCommon : SourcePruningEnumerationChildDispatch.run checkEmpty (r + headR) (n + headN)
            SourcePruningEnumerationChildDispatch.run checkEmpty ((r + headR) + er) ((n + headN) + en)
        have firstHead : SourcePruningEnumerationChildDispatch.run checkEmpty (r + headR) (n + headN)
