      cases headEq : SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k
