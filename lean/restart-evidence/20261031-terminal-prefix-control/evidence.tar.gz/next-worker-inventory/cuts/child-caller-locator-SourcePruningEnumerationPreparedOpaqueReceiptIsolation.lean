      (childRun : SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k scs value caller before queries =
