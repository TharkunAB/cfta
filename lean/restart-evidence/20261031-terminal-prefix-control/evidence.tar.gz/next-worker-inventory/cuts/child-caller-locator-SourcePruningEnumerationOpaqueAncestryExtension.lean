    rcases childRun : SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k
