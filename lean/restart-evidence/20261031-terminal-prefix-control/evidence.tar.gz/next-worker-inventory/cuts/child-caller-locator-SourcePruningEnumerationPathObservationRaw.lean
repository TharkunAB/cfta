    ObservationPaths P (SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k scs incoming
  · simp only [SourcePruningEnumerationChildDispatch.observe, empty, ↓reduceIte, ObservationPaths]
                simp only [SourcePruningEnumerationChildDispatch.observe, ite_eq_right empty, partitioned, prepared,
                simp only [SourcePruningEnumerationChildDispatch.observe, ite_eq_right empty, partitioned, prepared,
            simpa only [SourcePruningEnumerationChildDispatch.observe, ite_eq_right empty, partitioned] using
