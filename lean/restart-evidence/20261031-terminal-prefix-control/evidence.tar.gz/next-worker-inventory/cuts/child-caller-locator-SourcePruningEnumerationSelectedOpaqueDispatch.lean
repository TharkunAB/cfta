    match SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k scs value caller before queries with
      match SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k scs value caller before queries with
        SourcePruningEnumerationChildDispatch.run checkEmpty r n p h (bound + extra)
      SourcePruningEnumerationChildDispatch.run checkEmpty r n p h fuel scs value caller before memos.query =
        simp only [SourcePruningEnumerationChildDispatch.run, SourcePruningEnumerationChildDispatch.observe,
