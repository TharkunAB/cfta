    ObservationPaths P (SourcePruningEnumerationTerminal.run checkEmpty r n p h first rest waiting
  · simp only [SourcePruningEnumerationTerminal.run, empty, ↓reduceIte, ObservationPaths]
  · unfold SourcePruningEnumerationTerminal.run
