      SourcePruningEnumerationTerminal.run checkEmpty representativeFuel nativeFuel p h
  · simp only [run, SourcePruningEnumerationTerminal.run, ite_eq_left empty]
      simp only [run, SourcePruningEnumerationTerminal.run, ite_eq_right empty, prefixResultEq]
        simp only [run, SourcePruningEnumerationTerminal.run, ite_eq_right empty, prefixResultEq]
          simp only [run, SourcePruningEnumerationTerminal.run, ite_eq_right empty, prefixResultEq]
            simp only [run, SourcePruningEnumerationTerminal.run, ite_eq_right empty,
        SourcePruningEnumerationTerminal.run checkEmpty (r + extraRepresentative) (n + extraNative) P H
