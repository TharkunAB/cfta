import MicroCFTA.SourcePruningEnumerationChildEffects
namespace MicroCFTA.SourcePruningEnumerationChildTraversal
inductive Result (width : Nat) where
noncomputable def run
inductive Trace (checkEmpty : Bool) (representativeFuel nativeFuel p h indexFuel : Nat) :
theorem trace_complete
theorem complete_trace
theorem uncached
theorem stopped_trace
