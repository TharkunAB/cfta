import MicroCFTA.SourcePruningEnumerationNativeIndex
import MicroCFTA.SourcePruningEnumerationObservation
namespace MicroCFTA.SourcePruningEnumerationFinalize
def finish (target : Nat) (fragment : Fragments.Fragment Symbol) :
def run (heap : InternedConstructorTemplates.State Symbol NativeGuard)
theorem written_safe
theorem complete
