        SourcePruningEnumerationChildDispatch.run checkEmpty (r + extraRepresentative) (n + extraNative)
    have actual : SourcePruningEnumerationChildDispatch.run checkEmpty r n p h (k + freshFuel)
