          generalize childEq : SourcePruningEnumerationChildDispatch.run
