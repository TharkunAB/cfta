        SourcePruningEnumerationTerminal.run checkEmpty (r + extraRepresentative) (n + extraNative) P H
      simp only [SourcePruningEnumerationTerminal.run, ite_eq_right nonempty,
      simp only [SourcePruningEnumerationTerminal.run, ite_eq_right nonempty, Nat.add_assoc,
