      (SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k bucket incoming caller before queries) := by
  simp only [SourceFlatPruningChildDispatch.run, SourcePruningEnumerationChildDispatch.run,
    SourcePruningEnumerationChildDispatch.observe, ite_eq_right nonempty, partitioned,
      SourcePruningEnumerationChildDispatch.run checkEmpty (r + extraRepresentative) nativeFuel p h
                simp only [SourcePruningEnumerationChildDispatch.run, ite_eq_right empty,
        SourcePruningEnumerationChildDispatch.run checkEmpty (r + extraRepresentative) (n + extraNative)
