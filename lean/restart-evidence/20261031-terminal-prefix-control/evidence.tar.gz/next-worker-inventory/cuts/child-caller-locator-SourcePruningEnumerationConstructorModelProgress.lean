    (observed : SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k bucket incoming caller before queries =
    simp [SourcePruningEnumerationChildDispatch.run] at observed
      simp only [SourcePruningEnumerationChildDispatch.observe, ite_eq_right nonempty,
