          have headExact : SourcePruningEnumerationChildDispatch.run checkEmpty ((r + tailR) + er)
