import MicroCFTA.SourcePruningEnumerationChildCompletion
import MicroCFTA.SourcePruningEnumerationCachedPrepareProper
import MicroCFTA.SourcePruningEnumerationOwnFinalizeProper
import MicroCFTA.SourcePruningEnumerationRecursivePacket
import MicroCFTA.EnumerationStratifiedTransport
namespace MicroCFTA.SourcePruningEnumerationSelectedOpaqueDispatch
noncomputable def run (checkEmpty : Bool) (r n p h k target : Nat)
theorem ordinary_deferred (checkEmpty : Bool) (r n p h k target : Nat)
theorem terminal_step (checkEmpty : Bool) (r n p h k target : Nat)
theorem opaque_complete
