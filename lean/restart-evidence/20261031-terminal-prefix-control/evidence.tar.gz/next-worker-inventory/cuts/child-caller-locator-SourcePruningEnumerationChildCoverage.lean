        SourcePruningEnumerationChildDispatch.run checkEmpty (r + extraRepresentative) (n + extraNative)
            SourcePruningEnumerationChildDispatch.run checkEmpty r n p h (k + indexFuel)
          simp only [SourcePruningEnumerationChildDispatch.run, SourcePruningEnumerationChildDispatch.observe,
            SourcePruningEnumerationChildDispatch.run checkEmpty r n p h (k + indexFuel)
