  have childRun : SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k scs value caller before memos.query =
      simp only [SourcePruningEnumerationChildDispatch.run, SourcePruningEnumerationChildDispatch.observe,
