      SourcePruningEnumerationChildDispatch.run checkEmpty (r + extraRepresentative) (n + extraNative)
      simpa only [SourcePruningEnumerationChildDispatch.run, ite_eq_left empty,
              SourcePruningEnumerationChildDispatch.run checkEmpty r n p h (k + indexFuel)
            simp only [SourcePruningEnumerationChildDispatch.run, SourcePruningEnumerationChildDispatch.observe,
              SourcePruningEnumerationChildDispatch.run checkEmpty r n p h (k + indexFuel)
            SourcePruningEnumerationChildDispatch.run checkEmpty (r + r0) (n + n0) (max p p0) (max h h0)
