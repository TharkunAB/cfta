      SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k bucket value
    (observed : SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k bucket value
  · simp [SourcePruningEnumerationChildDispatch.run, empty] at observed
          simp only [SourcePruningEnumerationChildDispatch.run, ite_eq_right empty,
              simp only [SourcePruningEnumerationChildDispatch.run,
                SourcePruningEnumerationChildDispatch.observe, ite_eq_right empty, partitioned, actionEq] at raw
                simpa only [SourcePruningEnumerationChildDispatch.run, ite_eq_right empty,
              simp only [SourcePruningEnumerationChildDispatch.run,
                SourcePruningEnumerationChildDispatch.observe, ite_eq_right empty, partitioned,
      SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k bucket value
