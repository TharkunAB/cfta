        SourcePruningEnumerationChildDispatch.run checkEmpty r n p h (bound + extra)
