  simp only [SourcePruningEnumerationTerminal.run, ite_eq_right nonempty, prefixRun]
