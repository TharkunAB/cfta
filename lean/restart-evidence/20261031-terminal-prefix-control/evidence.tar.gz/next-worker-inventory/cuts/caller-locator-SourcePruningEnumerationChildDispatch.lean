        SourcePruningEnumerationTerminal.run checkEmpty representativeFuel nativeFuel p h
