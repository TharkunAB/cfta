import MicroCFTA.SourcePruningEnumerationChildCompletion
import MicroCFTA.SourcePruningEnumerationTerminalAdmission
namespace MicroCFTA.SourcePruningEnumerationChildCompletion
theorem partition_subsets (bucket : List Suspended) (first : Suspended)
theorem terminal_length_le (bucket : List Suspended) (first : Suspended)
theorem initial_ranges
