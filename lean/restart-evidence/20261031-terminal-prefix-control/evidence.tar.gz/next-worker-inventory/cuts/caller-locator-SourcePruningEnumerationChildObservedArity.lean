        have actualTerminal : SourcePruningEnumerationTerminal.run checkEmpty r n p h first rest
