        have terminalObserved : SourcePruningEnumerationTerminal.run checkEmpty r n p h
