            SourcePruningEnumerationChildDispatch.run checkEmpty r n p h (opaqueBound + extra)
