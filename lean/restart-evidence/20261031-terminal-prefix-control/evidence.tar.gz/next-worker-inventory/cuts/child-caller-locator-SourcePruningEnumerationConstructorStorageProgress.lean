    (observed : SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k bucket incoming caller before queries =
    simp [SourcePruningEnumerationChildDispatch.run] at observed
          simp only [SourcePruningEnumerationChildDispatch.run, SourcePruningEnumerationChildDispatch.observe,
          simp only [SourcePruningEnumerationChildDispatch.run, SourcePruningEnumerationChildDispatch.observe,
