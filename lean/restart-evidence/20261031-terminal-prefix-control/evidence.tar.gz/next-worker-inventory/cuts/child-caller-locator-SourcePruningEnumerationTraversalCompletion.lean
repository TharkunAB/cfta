        SourcePruningEnumerationChildDispatch.run checkEmpty r n p h k bucket incoming caller before queries =
          have headExact : SourcePruningEnumerationChildDispatch.run checkEmpty ((r + tailR) + er)
