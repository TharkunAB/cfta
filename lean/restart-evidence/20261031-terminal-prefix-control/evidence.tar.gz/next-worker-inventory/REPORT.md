# Inventory of actual child handlers around Terminal.run

INVENTORY ONLY. No proof draft, compiler, evaluator or native execution ran.
Terminal152L remains UNCOMPILED/unconfirmed in this task. Its source candidate
must pass Root's next checks before a new law can depend on it.

## Nearest actual handler

SourcePruningEnumerationChildDispatch.observe is the inspected ordinary
function body that directly invokes Terminal.run. It first rejects Empty
incoming without changing the caller. It partitions the supplied bucket by
EqualityTrie.isTerminal. If the terminal part is empty, it runs the shallow
nonterminal preparation and retains beforeCaller. If it is first :: rest, it
calls Terminal.run on that exact first/rest and passes descendants as
incomingScs.

The actual cached entry is ChildDispatch.run. Its terminal branch calls
CachedTerminalAdapter.run. Its existing unconditional erase theorem proves
that the COMPLETE first observation equals ChildDispatch.observe at the same
bounds. This equality includes caller, queries, raw status, outer state and
waiting. Thus a native certificate for observe transfers to run through an
existing actual erasure equality. It does not require cache validity, a cache
candidate, a successful outcome or a new result certificate.

The nearest closed target is child_dispatch_native_stored, retained in
NEXT-CLOSED-HEADER.md. It concerns the ACTUAL cached entry result's
.1.2.1.checked.native. This header is unproved and is not a new proof draft.

Other Terminal.run references are retained as exact locators. This inventory
does not classify every reference as a runtime call. In particular, the cached
adapter's relation to the original terminal interpreter is established by its
erasure theorem. The source inventory does not claim Haskell correspondence.

## Exact current entry gates

The next target can retain the EXISTING ChildObservedResources current entry
premises, plus separate entry native Stored:

- Seed, Formulas, Entailment, Inventory and current Context.
- Safe before.core, current Roots and canonical waiting counts.
- PendingRealized for the current heap and before.core.
- Bounded bucket variables and InputsPending before.core bucket.
- Current incoming availability and closed syntax.
- Fits seed.2, Reserved bits seed (bucket.length + 1), and the known seed
  alphabet heap.
- Native Stored at beforeCaller.checked.native.

No future Terminal/worker result is an input. No future Ready, Realized,
Fits/Room, callback coverage, trace or per-step invariant function is needed
for this single child-dispatch target. Native Stored remains separate from
Context.stored, which concerns the merge memo.

## Existing terminal admission exports

ChildAdmission.partition_subsets proves that both the terminal part and its
descendants are subsets of the ORIGINAL bucket. Its terminal subset supplies
active bounded variables and active InputsPending from the current bucket
facts.

ChildAdmission.terminal_length_le bounds the terminal part's length by the
original bucket length. Reserved.prefix then supplies the terminal reservation
for (first :: rest).length + 1. This is a current finite reservation projection,
not future Room at an assumed successor.

ChildAdmission.initial_ranges already combines those exact facts with the
current terminal admission producer. It constructs the old Ranges predicate.
The new native law must not take that predicate as a new future supplier.
After Root checks Terminal, the same subset/length/reservation facts can be
passed directly to terminal_native_stored.

ChildObservedResources.observed_resources follows this same route after an
ACTUAL successful outer child observation. Its conclusion is advanced Fits
and the known heap. It has no native Stored conclusion. Its proof contains the
exact current active-bounded, active-pending and reservation projection needed
for the next native target. The native target must also handle errors and
stopped observations, rather than assume that successful outer result.

## Nonterminal and remaining local operations

The inspected definitions have these native-state effects:

| Operation or branch | Actual returned caller/native effect | Existing source fact |
| --- | --- | --- |
| Child.observe, Empty incoming | Retains beforeCaller | Literal tuple in observe |
| Child.observe, no terminal inputs | Retains beforeCaller for none or any shallow action result | prepareChild receives no Caller and returns enumeration actions only |
| Child.run, cached nonterminal preparation | First observation remains observe; optional cache changes separately | ChildDispatch.erase |
| CachedPrepare.prepareChild | Receives the native constructor heap as a read-only value; returns only cached enumeration state/fragments | Exact type and branches in CachedPrepare lines 10-27 |
| Child.run, terminal inputs | Uses the cached terminal adapter; first observation equals original observe | ChildDispatch.erase and CachedTerminalAdapter.erase |
| SelectedOpaqueDispatch.run, Empty value | Retains input caller in rejected result | Literal rejected branch |
| SelectedOpaqueDispatch.run, ordinary node without terminal inputs | Returns none and defers this route | ordinary_deferred and run definition |
| SelectedOpaqueDispatch.run, actual child singleton | Keeps reached child caller while Finalize.run edits the cache | Literal complete construction |
| Finalize.run | Takes read-only native heap; returns only optional Cached | Exact run type; it resets cached expansion ancestry and updates the cached index |

No other native heap allocation/update appears in these inspected handler
bodies. Native heap work performed inside Terminal remains part of the
UNVERIFIED terminal dependency. This inventory does not generalize the local
frame facts to uninspected constructor or main-worker operations.

ChildEffects.child proves safety, enumerated origin and protected roots for an
ACTUAL shallow child success. child_inputs preserves retained InputsPending.
retained_inputs and terminal_inputs combine current origin/protection facts
with current partition/descend facts. These exports concern enumeration
state. Their origin/protects arguments must be derived from actual child
observations; they must not become abstract future transport suppliers in a
worker's public theorem. They do not by themselves establish successor native
Ready, Fits or separate native Stored.

## Actual enclosing worker

ChildTraversal.run is the inspected ordered worker. Its head call is the exact
ChildDispatch.run above. It recurses ONLY when that call returns one successful
fragment row AND some cache. The recursive input uses reachedCaller,
savedQueries and that actual cache. All other observations stop with their
own raw observation and optional candidate. Completed-prefix fragments do not
replace the stopping observation's caller.

Its all-outcome native target must distinguish complete caller from the
caller inside a stopped observation. The exact result shape and interface are
retained in WORKER-INTERFACES.md. No proof or closed resource header for the
whole traversal is asserted here.

The next traversal proof must derive every later child entry's Context,
Safe/Roots/waiting facts, Realized, remaining bucket pending/bounds, value
availability/closedness, Fits/Reserved/known, and native Stored from original
current inputs and the ACTUAL singleton/cache successor. These are conclusions
to produce, not a new per-step invariant supplier.

ChildTraversal.complete_trace can construct a trace from an ACTUAL complete
run observation. trace_complete maps that trace back to the same run. These
are existing observation/control exports, not numeric/semantic admission
producers. Passing a desired Trace or a future per-head entry package at the
public boundary would not close the worker transport goal. This bounded
inventory did not inspect all other traversal-resource modules and does not
assert that no stronger existing actual producer exists elsewhere.

## Scope and evidence

Two OLD whole modules were named before acquisition:
ChildObservedResources115L and ChildAdmission83L. Other acquisitions are exact
caller/declaration locators or named bounded cuts. No third whole or near-whole
module was acquired. Every source pin, byte/line count, exact selected lines,
retained copy and copy hash is in acquisitions.json. Cumulative unions are in
CUMULATIVE-SOURCE-UNIONS.json. There was no NEW full proof reuse.

The child-caller locator display exceeded its output budget once. Its complete
raw output/stderr and all exact source-line copies had already been saved.
Selected actual implementation references were then read from the saved output.
No source data was lost. INCIDENTS.md retains the event.

All writes stayed in /tmp/mcfta-native-worker-stored-review-20261031. Prior
bundles remain frozen. No compiler/evaluator/native/Git/network/board/production
change, packaging operation or spawned worker occurred. No proof was drafted.

This inventory closes no formal gate. Terminal is still unconfirmed here.
Original-input capacity, source reset, unchanged-step transport, whole-worker
induction, global coverage, public APIs and Haskell correspondence remain open.
No Haskell execution, defect, fix or new Haskell FINDINGS entry was established.
