# Actual enclosing worker interfaces

Inventory only. These are source interfaces, not new proved native laws.

```lean
SourcePruningEnumerationChildTraversal.run
  (checkEmpty : Bool) (representativeFuel nativeFuel p h indexFuel : Nat) :
  List (Node × List Suspended) → Caller width → Cached → Queries →
    SourcePruningEnumerationChildTraversal.Result width
```

The actual result carries one of:

```lean
.complete fragments caller queries after
.stopped completedPrefix observation candidate
```

A native Stored postcondition over this ACTUAL result has this exact shape:

```lean
match SourcePruningEnumerationChildTraversal.run checkEmpty r n p h k
    inputs beforeCaller before queries with
| .complete _ caller _ _ =>
    SourceCurrentAllocatedFiniteOrdinaryStored.Stored caller.checked.native
| .stopped _ observation _ =>
    SourceCurrentAllocatedFiniteOrdinaryStored.Stored observation.2.1.checked.native
```

This is a result shape only. No future head invariant, trace, output Stored,
completion or coverage supplier is proposed as an input. A closed original
entry header for this full worker needs the existing actual-successor resource
producers. That broader producer inventory is not claimed complete here.

SelectedOpaqueDispatch.run is another actual child caller. It returns an
Option SelectedEdge.Result. Empty input returns rejected with the same caller;
ordinary nonterminal nodes defer with none. An actual singleton child/cache
result is finalized using a read-only heap and retains the reached child caller.
All other child observations are kept in stopped. The exact bodies and types
are in the acquired bounded source cuts.
