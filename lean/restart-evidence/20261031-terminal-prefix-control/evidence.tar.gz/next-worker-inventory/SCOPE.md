# Scope

Root assigned this fresh SOURCE INVENTORY ONLY task at 2026-10-31 00:58 CET.
Locate actual production callers of Terminal.run and the nearest worker/handler native Stored target. State exact current entry gates and existing producer exports for terminal admission and remaining nonterminal/native heap work. No new proof draft depending on unverified Terminal. No future output certificate, abstract per-step supplier or invented invariant. Terminal152L remains UNCOMPILED next work until Root confirms.

Root owns compiler/evaluator/native/Git/network/board/production/packaging. No spawning. All writes stay here; prior bundles remain frozen. Max two named OLD whole/near-whole modules, named before acquisition; bounded exact locator/cuts otherwise with source metadata/unions. Freeze complete inventory, ledger, report and pins.
