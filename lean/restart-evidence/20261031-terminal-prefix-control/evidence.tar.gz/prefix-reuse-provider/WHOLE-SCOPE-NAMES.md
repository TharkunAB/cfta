# OLD whole scope

Slot1: SourcePruningEnumerationNarrowAdapter.lean. Named before acquisition at00:39 CET.
Slot2: unused.
