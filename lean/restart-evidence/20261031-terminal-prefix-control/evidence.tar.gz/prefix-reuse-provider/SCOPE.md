# Scope

Source-only actual adapter transport after successful changed filtering. Own only this directory. Keep earlier bundles frozen.
Root owns all compiler, evaluator, native, Git, network, board, production and packaging work. No spawning.

OLD whole slot1 named before acquisition: SourcePruningEnumerationNarrowAdapter.lean. Slot2 remains unused.
Explicit full NEW reuse: installed checked SourcePruningNarrowSlotTransport.lean176L at parent-supplied exact SHA55eedb67e1311dcad35710cf7c11c028cca2e51129893a8d8fe5939624158340.

Retain actual observation equations and newEncoded. Derive old native gates and frames internally. No future reset-free history or Frame/Normal supplier. Stop at the actual observed wrapper branch.
