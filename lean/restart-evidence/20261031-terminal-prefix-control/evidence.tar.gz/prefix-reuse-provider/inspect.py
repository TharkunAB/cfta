from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent
mode=sys.argv[1];a=json.loads((r/'acquisitions.json').read_text())
if mode=='cut':
 leaf,lo,hi,label=sys.argv[2:];p=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')/leaf;b=p.read_bytes();lines=b.splitlines(keepends=True);actual=list(range(int(lo),min(int(hi),len(lines))+1));copied=b''.join(lines[i-1]for i in actual);target='cuts/'+label;(r/target).write_bytes(copied);a.append({'source':str(p),'source_bytes':len(b),'source_lines':len(lines),'source_sha256':hashlib.sha256(b).hexdigest(),'copy':target,'copy_sha256':hashlib.sha256(copied).hexdigest(),'actual_lines':actual,'kind':'bounded cut'});print(copied.decode())
elif mode=='locate':
 pattern=sys.argv[2];leaves=sys.argv[3:];paths=[str(Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')/x)for x in leaves];q=subprocess.run(['rg','--with-filename','-n',pattern,*paths],capture_output=True);n=len(list((r/'locators').glob('*.stdout.txt')))+1;out=f'locators/{n:02d}.stdout.txt';err=f'locators/{n:02d}.stderr.txt';(r/out).write_bytes(q.stdout);(r/err).write_bytes(q.stderr)
 for p in map(Path,paths):
  if not p.exists():continue
  b=p.read_bytes();actual=sorted({int(x[len(str(p))+1:].split(':',1)[0])for x in q.stdout.decode().splitlines()if x.startswith(str(p)+':')});copied=b''.join(b.splitlines(keepends=True)[i-1]for i in actual);target=f'locators/{n:02d}-{p.name}.txt';(r/target).write_bytes(copied);a.append({'source':str(p),'source_bytes':len(b),'source_lines':len(b.splitlines()),'source_sha256':hashlib.sha256(b).hexdigest(),'copy':target,'copy_sha256':hashlib.sha256(copied).hexdigest(),'actual_lines':actual,'kind':'locator','pattern':pattern,'stdout':out,'stderr':err,'returncode':q.returncode})
 print(q.stdout.decode());print(q.stderr.decode())
(r/'acquisitions.json').write_text(json.dumps(a,indent=2)+'\n')
