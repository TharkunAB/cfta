# Proposed public contract

UNCOMPILED source-only. No owner compiler or evaluator was used.

```lean
import MicroCFTA.SourcePruningNarrowSlotTransport
import MicroCFTA.SourcePruningEnumerationNarrowAdapter

namespace MicroCFTA.SourcePruningEnumerationNarrowAdapter
open EnumerationState EnumerationCorrectness EnumerationCompressionFrame
open InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
open SourcePruningNativeView SourcePruningEnumerationNodes SourcePruningEnumerationObservation
local notation "Symbol" => SourcePruningTemplates.Symbol
attribute [local instance] FormulaExecutable.formulaDecidableEq
variable {EnumGuard NativeGuard Typing Key : Type}

theorem adapt_changed_success_stores_normal [DecidableEq (EdgeKey Symbol NativeGuard)]
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool)
    (admits : Key → Value Symbol NativeGuard → Bool) (metadata : SourcePruningRecordTypes.Metadata Typing)
    (readFuel checkFuel nativeFuel representativeFuel indexFuel uv oldHandle newHandle : Nat)
    (scs : List Suspended) (value result : Value Symbol NativeGuard)
    (heap nextHeap : InternedConstructorTemplates.State Symbol NativeGuard)
    (before after : EnumerationExpandableIndex.Cached Symbol EnumGuard)
    (readAfter checked observed : EnumerationState.State Symbol EnumGuard)
    (action : EnumerateM Symbol EnumGuard Unit)
    (ready : SourceEqualityRequiredCache.Ready heap) (realized : PendingRealized heap before.core)
    (total : UnionFind.Total before.core.representatives)
    (read : Success (getValue readFuel uv) before.core (.unenumerated (some oldHandle) scs) readAfter)
    (checkedFalse : Success (SourcePruningEnumerationRecursion.checkRepeated heap checkFuel uv oldHandle scs)
      readAfter false checked)
    (decoded : lookupNode heap oldHandle = some value)
    (prepared : SourcePruningEnumerationAction.prepare holeKey fits admits metadata nativeFuel representativeFuel
      uv oldHandle scs value heap = .done (result, some action) nextHeap)
    (newEncoded : encodeNode result = some newHandle) (changed : newHandle ≠ oldHandle)
    (succeeded : Success action checked () observed)
    (adapted : adapt nextHeap indexFuel uv oldHandle newHandle scs before observed = some after) :
    after.core = observed ∧
      SourceEqualityRequiredCache.Keeps heap nextHeap ∧
      Available nextHeap result ∧ result.free = [] ∧ SourceEqualityRequiredCache.Ordinary result ∧
      EqualityOrdinaryReadback.Normal nextHeap result ∧ lookupNode nextHeap newHandle = some result ∧
      (∀ edge ∈ nodeEdges result, keeps fits admits (holeKey metadata.typing uv) edge = true) ∧
      (SourceEqualityRequiredCache.Ordinary value → ∀ edge ∈ nodeEdges result, edge ∈ nodeEdges value) ∧
      PendingRealized nextHeap after.core ∧
      ∃ (root : Nat) (middle : EnumerationState.State Symbol EnumGuard),
        Success (representative representativeFuel uv) checked root middle ∧ Frame checked middle ∧
        middle.values[root]? = some (.unenumerated (some oldHandle) scs) ∧
        Success (setValue root (.unenumerated (some newHandle) scs)) middle () after.core ∧
        after.core = {middle with values := middle.values.set root (.unenumerated (some newHandle) scs)} ∧
        after.core.values[root]? = some (.unenumerated (some newHandle) scs)
```
