from pathlib import Path
import hashlib
import json

r = Path(__file__).resolve().parent
acquisitions = json.loads((r / 'acquisitions.json').read_text())
reuses = json.loads((r / 'reuse-ledger.json').read_text())
u = {}
whole = set()
for a in acquisitions + reuses:
    source = Path(a['source']).read_bytes()
    assert len(source) == a['source_bytes']
    assert len(source.splitlines()) == a['source_lines']
    assert hashlib.sha256(source).hexdigest() == a['source_sha256']
    selected = b''.join(source.splitlines(keepends=True)[i - 1] for i in a['actual_lines'])
    assert selected == (r / a['copy']).read_bytes()
    assert hashlib.sha256(selected).hexdigest() == a['copy_sha256']
    if a.get('kind', '').startswith('named OLD whole'):
        whole.add(a['source'])
    row = u.setdefault(a['source'], {'source_sha256': a['source_sha256'], 'source_lines': a['source_lines'], 'fresh': set(), 'reused': set()})
    row['reused' if 'classification' in a else 'fresh'].update(a['actual_lines'])
assert whole == {'/home/tritlo/Code/mcfta/lean/MicroCFTA/SourcePruningEnumerationNarrowAdapter.lean'}
for a in json.loads((r / 'tool-reuse-ledger.json').read_text()):
    assert hashlib.sha256(Path(a['source']).read_bytes()).hexdigest() == a['source_sha256']
    assert Path(a['source']).read_bytes() == (r / a['copy']).read_bytes()
    provider = (r / 'provided-tool-MANIFEST.json').read_bytes()
    assert hashlib.sha256(provider).hexdigest() == a['provider_manifest_sha256']
    assert next(x for x in json.loads(provider)['files'] if x['path'] == 'inspect.py')['sha256'] == a['source_sha256']
rows = [{'source': p, 'source_sha256': x['source_sha256'], 'source_lines': x['source_lines'], 'fresh_lines': sorted(x['fresh']), 'reused_lines': sorted(x['reused']), 'union_lines': sorted(x['fresh'] | x['reused']), 'fresh_count': len(x['fresh']), 'union_count': len(x['fresh'] | x['reused'])} for p, x in sorted(u.items())]
extra = [x['source'] for x in rows if x['source'].startswith('/home/tritlo/Code/mcfta/') and x['source'] not in whole and x['fresh_count'] >= .75 * x['source_lines']]
assert not extra
meta = json.loads((r / 'draft-v1.json').read_text())
source = (r / meta['file']).read_bytes()
assert hashlib.sha256(source).hexdigest() == meta['sha256']
assert len(source) == meta['bytes'] and len(source.splitlines()) == meta['lines']
contract = json.loads((r / 'PUBLIC-CONTRACTS.json').read_text())
assert contract['full_header'] in source.decode() and contract['context'] in source.decode()
result = {'status': 'pass', 'fresh_acquisitions': len(acquisitions), 'exact_checked_new_whole_reuses': len(reuses), 'source_identities': len(rows), 'named_old_whole_modules': len(whole), 'old_whole_slots_unused': 1, 'extra_near_whole_unions_over_75_percent': extra, 'full_public_headers': 1, 'owner_compiler_commands': 0, 'owner_runtime_commands': 0, 'draft_status': 'UNCOMPILED'}
if (r / 'FROZEN').exists():
    assert json.loads((r / 'SOURCE-UNIONS.json').read_text()) == rows
    assert json.loads((r / 'source-verification.json').read_text()) == result
else:
    (r / 'SOURCE-UNIONS.json').write_text(json.dumps(rows, indent=2) + '\n')
    (r / 'source-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
