No source acquisition failed. All exact bounded cuts and locator stdout/stderr were retained and read.
A lightweight memory-registry query returned no matches with the normal rg exit code1. No memory-derived claim was used.
No compiler, evaluator, or native execution was attempted.
