Root explicitly supplied installed checked SourcePruningNarrowSlotTransport.lean176L at SHA55eedb67e1311dcad35710cf7c11c028cca2e51129893a8d8fe5939624158340.
Root reported strictPASS, full Audit4757/83053 and public1222/118 PASS. These are Root-provided check results. The source-only owner did not repeat them.
The exact source copy and provider hash are retained in reuse-ledger.json.
The earlier uncompiled owner SlotTransport draft is not used as the typed producer contract.
