import MicroCFTA.SourcePruningNarrowSlotTransport
import MicroCFTA.SourcePruningEnumerationNarrowAdapter

/-!
# Actual narrowing adapter slot transport

A successful actual adapter retains the observed action core.
The stored normal result therefore remains in the same allocated slot.
The law ends at the adapter output, before Right recording.

UNCOMPILED source-only draft. Root owns all checks and integration.
-/
namespace MicroCFTA.SourcePruningEnumerationNarrowAdapter
open EnumerationState EnumerationCorrectness EnumerationCompressionFrame
open InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
open SourcePruningNativeView SourcePruningEnumerationNodes SourcePruningEnumerationObservation
local notation "Symbol" => SourcePruningTemplates.Symbol
attribute [local instance] FormulaExecutable.formulaDecidableEq
variable {EnumGuard NativeGuard Typing Key : Type}

/-- The actual successful adapter keeps the action's stored physical normal form and exact core. -/
theorem adapt_changed_success_stores_normal [DecidableEq (EdgeKey Symbol NativeGuard)]
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool)
    (admits : Key → Value Symbol NativeGuard → Bool) (metadata : SourcePruningRecordTypes.Metadata Typing)
    (readFuel checkFuel nativeFuel representativeFuel indexFuel uv oldHandle newHandle : Nat)
    (scs : List Suspended) (value result : Value Symbol NativeGuard)
    (heap nextHeap : InternedConstructorTemplates.State Symbol NativeGuard)
    (before after : EnumerationExpandableIndex.Cached Symbol EnumGuard)
    (readAfter checked observed : EnumerationState.State Symbol EnumGuard)
    (action : EnumerateM Symbol EnumGuard Unit)
    (ready : SourceEqualityRequiredCache.Ready heap) (realized : PendingRealized heap before.core)
    (total : UnionFind.Total before.core.representatives)
    (read : Success (getValue readFuel uv) before.core (.unenumerated (some oldHandle) scs) readAfter)
    (checkedFalse : Success (SourcePruningEnumerationRecursion.checkRepeated heap checkFuel uv oldHandle scs)
      readAfter false checked)
    (decoded : lookupNode heap oldHandle = some value)
    (prepared : SourcePruningEnumerationAction.prepare holeKey fits admits metadata nativeFuel representativeFuel
      uv oldHandle scs value heap = .done (result, some action) nextHeap)
    (newEncoded : encodeNode result = some newHandle) (changed : newHandle ≠ oldHandle)
    (succeeded : Success action checked () observed)
    (adapted : adapt nextHeap indexFuel uv oldHandle newHandle scs before observed = some after) :
    after.core = observed ∧
      SourceEqualityRequiredCache.Keeps heap nextHeap ∧
      Available nextHeap result ∧ result.free = [] ∧ SourceEqualityRequiredCache.Ordinary result ∧
      EqualityOrdinaryReadback.Normal nextHeap result ∧ lookupNode nextHeap newHandle = some result ∧
      (∀ edge ∈ nodeEdges result, keeps fits admits (holeKey metadata.typing uv) edge = true) ∧
      (SourceEqualityRequiredCache.Ordinary value → ∀ edge ∈ nodeEdges result, edge ∈ nodeEdges value) ∧
      PendingRealized nextHeap after.core ∧
      ∃ (root : Nat) (middle : EnumerationState.State Symbol EnumGuard),
        Success (representative representativeFuel uv) checked root middle ∧ Frame checked middle ∧
        middle.values[root]? = some (.unenumerated (some oldHandle) scs) ∧
        Success (setValue root (.unenumerated (some newHandle) scs)) middle () after.core ∧
        after.core = {middle with values := middle.values.set root (.unenumerated (some newHandle) scs)} ∧
        after.core.values[root]? = some (.unenumerated (some newHandle) scs) := by
  have core := adapt_core nextHeap indexFuel uv oldHandle newHandle scs before after observed adapted
  refine ⟨core, ?_⟩
  have stored := SourcePruningEnumerationAction.prepare_changed_success_stores_normal
    holeKey fits admits metadata readFuel checkFuel nativeFuel representativeFuel uv oldHandle newHandle scs
    value result heap nextHeap before.core readAfter checked observed action ready realized total read
    checkedFalse decoded prepared newEncoded changed succeeded
  simpa only [core] using stored

end MicroCFTA.SourcePruningEnumerationNarrowAdapter
