# Actual narrowing adapter transport

This bundle proposes one UNCOMPILED source law. It lifts the checked actual slot producer through the literal successful narrow adapter. The returned cache has the exact observed action core. Its stored Normal value, exact native readback, and PendingRealized property therefore remain valid at that same endpoint.

## Proposed contract

`SourcePruningEnumerationNarrowAdapter.adapt_changed_success_stores_normal` takes the actual pending read, actual false recursion check, literal old lookup, actual changed preparation result, explicit `newEncoded`, successful actual returned action, and the actual `adapt ... = some after` equation. The cached input is the same `before` object used by the caller and adapter. The action result is the same `observed` state passed to the adapter.

The conclusion includes `after.core = observed`. It also gives native Keeps, Available, closedness, ordinary shape, physical Normal, complete native readback for the new handle, retained filter rows, conditional ordinary-input row subset, and PendingRealized at `after.core`. It retains the actual representative and write observations, the current old slot, the exact final core update, and the final stored new handle.

The caller supplies no old encoding, old Available, old closedness, old Normal, Frame, future history, future cache existence, Complete predicate, or reset-free certificate. Old encoding, Available, closedness, and the required frames derive inside the checked slot producer. Physical Normal is derived for the actual returned value. Old physical Normal is not required. The new encoding and every actual observation equation remain explicit.

The proof applies the existing actual `adapt_core` law, calls checked `prepare_changed_success_stores_normal`, and rewrites its postcondition to the exact returned cache core. No new predicate or abstract machinery is introduced. The owner ran no compiler or evaluator; the new wrapper is not claimed checked.

## Why the adapter preserves the endpoint

The retained whole `SourcePruningEnumerationNarrowAdapter.lean` source defines two branches. Equal handles return `frame observed before`. Different handles run the native index write and map `frame observed` over its result. Both successful branches therefore return a cache whose entire core is the observed action core.

The changed branch can compute an internal cached core during index writing. The final map restores the exact observed core. The proposed law does not silently identify that internal core with the action output. It uses the existing theorem proved from the actual adapter definition.

The native heap input remains `nextHeap`. The adapter returns only an optional cached enumeration state, so this wrapper does not introduce a new native-heap lineage premise. The stored physical Normal and readback stay in the same heap supplied to the actual adapter.

The law does not prove correctness of the returned waiting counts, expandable flags, or other cache indexes. Those need their existing index invariants. It proves the requested physical value and slot properties at the actual returned core.

## Literal caller and exact stop

The retained `SourcePruningEnumerationSelectedStep.runPrefix` cut shows the actual sequence after preparation:

1. Run the returned action on `checked` and retain its singleton successful `observed` state.
2. Read the explicit new encoding.
3. Call `adapt heap indexFuel uv oldHandle newHandle scs before observed`.
4. On `none`, return the narrowed prefix observation with its action observation and no candidate, Right observation, or ordinary continuation.
5. On `some attached`, run Right recording on `attached.core`.

The `none` branch is not a restart in this code. It ends this observed selected prefix before Right recording. The proposed law requires the literal successful `some` observation. It does not supply a future successful adapter result or prove sufficient index fuel.

The law ends at `attached.core`, which is exactly the next Right input. No writer between action success and that input is omitted.

## Right recording and later scope

A precise downstream fact was checked in source. Existing `SourcePruningRecordTypes.recordTypes_inr` states `recordTypes ... (.inr newHandle) = pure (false, metadata)`. Right recording itself therefore does not reset the slot source. A later wrapper can derive equality of its actual output core from this identity and actual success, without a supplied Frame. This bundle retains the exact definition and identity cuts but does not add that wrapper.

The literal prefix then frames the Right callback core into the attached cache. Subsequent ordinary branches, incoming or dispatch intersections, selected Mu unfolding, and Prepared Mu/Union reconstruction remain outside this law. Their exact row-source and caller-history transport still needs separate evidence. This bundle assumes no reset-free history for them.

The actual stored representative can differ from the literal queried UVar when that UVar is an alias. The law preserves the representative returned by the actual slot producer. A selected-caller readiness wrapper can identify it with the selected UVar where appropriate.

This law does not construct the full observed ChangedFilters history for either worker. It does not count unchanged calls, bound source resets, compute the first carrier size from the original input, or prove the original-depth bound. Recursive whole-execution completion, all earlier alternatives and staged children, global coverage, public-adapter correctness, and Haskell correspondence remain open. The full original-input, both-worker, public/Haskell objective remains unchanged.

No Haskell source was changed. No Haskell defect, fix, or candidate was established.

## Source identities and owner boundary

The exact typed producer is the explicitly authorized installed checked `SourcePruningNarrowSlotTransport.lean`,176L, SHA55eedb67e1311dcad35710cf7c11c028cca2e51129893a8d8fe5939624158340. Its full copy is retained and was read. Root supplied strictPASS, full Audit4757/83053, and public1222/118 PASS. These are Root's supplied check results. The owner did not repeat them. The earlier uncompiled owner slot draft is not used as the typed producer contract.

OLD whole slot1 was named before acquisition: `SourcePruningEnumerationNarrowAdapter.lean`,96L, SHA1646a80d568032f0d534bc84019be2b7cf5bdf6d30d65b737b0074464cff60a1. Slot2 remains unused. The only other OLD acquisitions are named bounded cuts and one retained locator in the actual caller and Right-recording source. No extra whole or near-whole module was acquired.

acquisitions.json, reuse-ledger.json, tool-reuse-ledger.json, and SOURCE-UNIONS.json retain exact identities, copied ranges, cumulative unions, and the helper provider manifest. PUBLIC-CONTRACTS.md/json retain the full proposed public header, imports, namespace, local notation, variables, and local instance attribute. All source copies and the new draft were read in full. All bounded cuts and locator lines were read.

The immutable V1 draft has63L and4264B, SHA8f6888be0194b85f6e03414e775e5a8c2b5337f080f80d6c0c32339ca12a8258. It remains explicitly UNCOMPILED. No source acquisition failed. A memory-registry query returned no matches and supplied no task fact.

No compiler, evaluator, native execution, Git operation, network request, board operation, production edit, or sub-agent was used by this owner. All prior bundles remain unchanged. Root owns checking, integration, and publication.
