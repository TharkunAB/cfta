# Actual prepared callback progress in the ordered scan

Review result: PASS for the exact three current task sources listed below.
The owner read the current helper, head and complete sibling source.
Root ran all compiler checks. The owner ran no compiler, evaluator, native,
Git, network or board command. The owner changed no repository source.
No subagent was used. All earlier review bundles remain immutable.
The full global/public/Haskell proof objective remains ACTIVE.

## Exact current inputs

SourcePruningEnumerationPreparedCallbackCostProgress.lean:
121 lines,8323 bytes, SHA256
9c72e8e694ac3d1d38dcd6049390fe823efa30b5e8f205185428c6ac5fdcb27a.

SourcePruningEnumerationPreparedFiniteHeadCallbackProgress.lean:
197 lines,14795 bytes, SHA256
531e06f8b20c5f9b506cd3ee95f88e9c0d48523b4c7597dc756cdc39685febbf.

SourcePruningEnumerationPreparedFiniteSiblingCallbackProgress.lean:
498 lines,37203 bytes, SHA256
eee9f749775f0811eb770d0dc9f2cecf1242b09899fbca35a1276b7370f0aad3.

The three sources were pinned before review. Their current bytes match the
exact Root strict copies. callback-cost-v1-strict, head-callback-v2-strict and
sibling-callback-v1-strict all pass with empty logs. Each uses warningAsError
and linter.all. Each reports measured4GiB memory.max/high and zero swap.
All nine input snapshot copies verify against their command manifests.
Earlier Audit snapshots are historical inputs, not claims about current Audit.
Exact reports, command starts, input manifests, logs and copies remain in
root-strict-checks. The owner executed no Lean command.

The failed head v1 remains. Its complete public header equals the final v2
header exactly. The repair adds only the direct PolicyOrigins import and
an explicit receipt case split before simplification. That split resolves
distinct generated match helpers. The import supplies pending_refutes_extension.
head-v1-to-final.patch and historical-head-failure retain the exact record.
The failure predates the owner's first current head pin. It is not reclassified
as passing or as a change to the public statement.

## Complete contract preservation and policy scope

compare-contracts.py reconstructs both complete old progress headers from
exact source cuts. Removing only the appended callback conclusion and restoring
the theorem name recovers each complete old header literally:

- Head:6567 bytes.
- Sibling:9909 bytes.

No original input was removed or added. No whitespace normalization or
mathematical-variable renaming was used. No future callback resource, callback
model or recursive semantic result became a top-level premise.

The retained old operational result blocks are2340 bytes for the head and
1880 bytes for the sibling. The entire784-byte earlier stopped-hook result
also remains literal. This preserves actual stable execution, exact full memo
and native endpoints, all receipt/output certificates, stage resources,
complete/stopped results and ordered output association.

All previous chosen-event results remain UNCONDITIONAL after original accepted
input: old-ID agreement, original and finalized models, fragment fill,
ProperState, strict pendingSize+1 decrease, actual progress Post/query and full
recursive Packet. The new policy implication follows that Packet as a NEW
conjunct inside the SAME existing inventory/memo existential.

The sibling shape is exactly:

```text
old chosen model/cost/progress results AND
exists progressInventory, progressMemos,
  progressPost AND progressQuery AND progressPacket AND
  (originalRefutes -> Avoids -> ProgramEncoding -> CallbackProgressAt at work)
```

The head uses the same shape, with forall extra before the new policy implication
and CallbackProgressAt at bound+extra. Thus the policies guard ONLY the new
callback conclusion. They do not guard or weaken any prior model, Packet or cost
clause. The parenthesis checks are both manual and literal full-header recovery.
The appended head/sibling expressions have648 and672 bytes respectively.

## Transparent actual callback postcondition

The helper namespace is SourcePruningEnumerationPreparedRecursive.
CallbackProgressAt is a transparent def, not a new opaque endpoint assumption.
Its complete body records the actual successful recordTypes call at work and
the exact singleton ExceptT.run result. It records callback=false, updated
pending refutations, Packet, RenderStable, Frame, ProperState, SAME assignment
Satisfies, strict pendingSize+1 bound and not-stuck for every stop/order policy.

Its continuation equation uses the actual PreparedRecursive.Failure type.
It quantifies operational recur in the CONCLUSION and equates continueWith
to that recur at the actual recorded frame and restart decision.
It does not ask for any future semantic property of recur.

callback_progress_at_of_success derives this body from an actual successful
observation and the original callback-input Packet, model, proper state,
fragment allocation/fill, template policies and strict head cost.
callback_record_progress supplies the exact frame/model facts.
recordTypes_exact supplies the actual singleton raw observation.
recordTypes_inl_refutes proves callback=false and updated refutations.
frame_pendingSize preserves the head's strict cost at the callback frame.
not_stuck_of_proper applies independently to every stop/order configuration.
The final continueWith equation reduces the actual raw success and false flag.

The helper's observed-success premise is internal to the composition.
The new head DERIVES it from the existing original-state receipt resource
producer. It does not expose that success as a new top-level head/sibling gate.
CallbackProgressAt should remain part of the public definition readback.

## Head bound and same-model composition

The head namespace is SourcePruningEnumerationPreparedNativeHookResources.
The theorem is head_finite_complete_resources_accepting_callback_progress.

The old checked head progress producer fixes receipt and operational bound B.
Its complete resources and original accepting-model observer are retained.
The unsupported branch remains exact. Original acceptance contradicts its
unhandled receipt, so it cannot supply a spurious accepted callback.

In the advanced branch, head_mass_le derives callback mass from original
captured mass, inherited length and actual HeadCacheBounds. The existing
receipt_finite_complete_resources_models in PreparedRecursive supplies C
from original Packet/Post, actual advance, Admitted/Pending/FragmentHistory,
afterHead Fits/knownHeap, the derived mass and HeadReserved.2.
It does so BEFORE any original assignment or acceptance is selected.

The new operational bound is B+C. The original head and hook equations are
reused at old extra=C+extra. Thus the actual receipt, hook outcome, full native
resources and captured endpoint remain unchanged at every new sufficient work.
The additional callback bound has no semantic model supplier.

For an accepted assignment, the proof keeps the SAME old head extension.
It rewrites the fixed receipt to that actual complete fragment/cache, then
extracts the produced callback's successful observation at:

```text
C + (B + extra) = (B + C) + extra
```

Packet.bounded and old-ID agreement derive refutations for that same extension
with pending_refutes_extension. That lemma uses the fixed FormulaExecutable
equality, matching the new Refutes notation. Fragment fill and Ready.inside
identify the filled term with extended uv. Original Avoids and ProgramEncoding
then rewrite through the same fragment equation.

callback_progress_at_of_success receives the old accepting extension, its
actual afterCache ProperState, its complete progress Packet and strict cost.
The raw recordTypes call is independent of the full memo/inventory witness.
The proof keeps the progress inventory and progressMemos for its Packet and
retains progressMemos.query=saved. It does not coerce a different full memo
or inventory witness to those fields.

## Exact sibling work and earlier failures

The sibling namespace is SourcePruningEnumerationPreparedFiniteSiblingResources.
The theorem is alternatives_finite_complete_resources_accepting_callback_progress.

The complete original ordered scan proof remains. It now calls the stronger
head producer. The complete-index-zero branch specializes its callback observer
at extra=work-headBound and rewrites headBound+(work-headBound)=work.
The existing inequality headBound<=work supplies that identity.

The recursive tail uses its original extra=headBound+extra and rewrites the
same tailBound+(headBound+extra)=work equation. Its exact-work callback
postcondition then passes through unchanged. The captured before.core,
metadata and original assignment are identical across siblings. Native caller,
full memos, annotation Heap, Fits and reservation advance at their actual stage.

The stopped-index-zero branch still reaches the chosen actual head before its
hook stops. Its callback observer uses the outer extra unchanged and rewrites
the exact actualCaller equality. It keeps the separate progress query equation.
If that stopped hook is earlier than the chosen index, the complete earlier
failure case remains. No accepted model or callback progress is fabricated
for an unaccepted earlier alternative.

All old ReceiptAt/OutputAt/StoppedAt clauses, prefix receipts and outputs,
actual Invocation, native endpoint metadata and exact resource certificates
remain. The output equation still retains prefixOutputs++hookOutputs.
The existing arity-allowed unsupported-projection gate also remains.

## Boundaries and source scope

The result gives actual callback progress for the chosen event under original
template policies. It does not establish semantic success of that event's
future recursive call. The earlier stopped-hook alternative remains necessary.
A later accepted term does not rank all unproductive earlier alternatives.
Pending cost cannot telescope across siblings that reuse the captured cache.

Global neutral work/control, sufficient resources from original public inputs,
symbolic unfolding/public finite-value coverage, exact public order/stops,
optimized core coverage and Haskell correspondence remain open.
DONE does not imply Discharged. No fully admitted all-capacity counterexample
was established. This owner changed no Haskell source and established no
Haskell defect or fix. Any concrete later repair still belongs in FINDINGS.

source-scope.json records exact requested/actual endpoints and complete
source/copy bytes and hashes. The only whole OLD dependency acquisition is
PreparedFiniteReceiptModels178L, within the limit of four. PolicyOrigins is an
exact17-line cut. Both complete old progress headers are assembled from exact
cuts; their old proof bodies carry no fresh whole-source review claim.

Current new task sources and the historical failed task source are recorded
separately. The helper request1–140 ended at its actual121-line EOF and is
correctly marked a WHOLE TASK source. It is not reclassified as an old partial
acquisition. Current head and sibling sources were read in bounded cuts.
All three current sources were read without display truncation.

The historical failed head's whole display was truncated. It carries no
whole-body review claim. Only the exact compact two-line repair diff and
unchanged complete header are required; both were read without truncation.
No current-source or contract claim relies on omitted historical display text.
