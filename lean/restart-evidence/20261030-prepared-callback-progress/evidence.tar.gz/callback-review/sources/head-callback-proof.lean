      _proper, _decrease, _progress⟩ := accepting ambient assignment satisfied accepted
    rw [unsupported.1] at completed
    cases completed
  · have mass := SourcePruningEnumerationRecursiveReservation.head_mass_le seed capturedMass inherited
      before scs receipt initialMass inheritedLength cacheBounds
    obtain ⟨modelFuel, _modelOutcome, _modelResources, recording⟩ :=
      SourcePruningEnumerationPreparedRecursive.receipt_finite_complete_resources_models
        holeKey fits admits graph templates checkEmpty edgesOf stop order metadata formulas solver recursiveFuel
        inventory middleInventory caller middleCaller memos middleMemos before uv receipt packet headPost advanced
        admitted pending history (afterHead seed inherited) (massCeil seed capturedMass inherited)
        headFits headKnown selectionMembers selectionLength (by cases receipt <;> exact mass) reserved.2
    let bound := oldBound + modelFuel
    refine ⟨bound, receipt, middleCaller, saved, middleMemos, middleInventory,
      ⟨?_, headPost, headQueries, admitted, pending, history, cacheBounds, headFits, headKnown,
        .inr ⟨outcome, advanced, ?_, outcomeResources, captured⟩⟩, ?_⟩
    · intro extra
      simpa only [bound, ←Nat.add_assoc] using headRun (modelFuel + extra)
    · intro extra
      cases receipt <;> simpa only [bound, ←Nat.add_assoc] using callbackRun (modelFuel + extra)
    · intro ambient assignment satisfied accepted
      obtain ⟨extended, fragment, afterCache, agree, originalSatisfied, completed, filled, afterSatisfied,
        afterProper, decrease, progressInventory, progressMemos, progressPost, progressQuery, progressPacket⟩ :=
        accepting ambient assignment satisfied accepted
      refine ⟨extended, fragment, afterCache, agree, originalSatisfied, completed, filled, afterSatisfied,
        afterProper, decrease, progressInventory, progressMemos, progressPost, progressQuery, progressPacket, ?_⟩
      rw [completed] at recording
      obtain ⟨_callerSame, _querySame, recorded, callbackCore, _current, allocated, returned, _equivalence, _models⟩ := recording
      obtain ⟨_callbackPacket, _stable, _frame, _types, _holes, _typing, callback, _running, _resources⟩ := returned
      intro extra refuted avoids encoded
      have common : modelFuel + (oldBound + extra) = bound + extra := by dsimp [bound]; omega
      have observed := (callback (oldBound + extra)).1
      rw [common] at observed
      have extendedRefuted := SourcePruningRecordTypes.pending_refutes_extension
        before.core.counter assignment extended metadata packet.bounded agree refuted
      have filledSelf : Fragments.fill extended fragment = extended uv :=
        filled.trans (agree uv ready.inside).symm
      exact SourcePruningEnumerationPreparedRecursive.callback_progress_at_of_success
        formulas solver progressInventory graph templates metadata uv fragment middleCaller progressMemos afterCache
        (bound + extra) recorded callbackCore progressPacket allocated afterProper observed ambient extended afterSatisfied
        filledSelf extendedRefuted (by simpa only [filled] using avoids) (by simpa only [filled] using encoded)
        (EnumerationStorageProgress.pendingSize before.core assignment) decrease

end MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources
