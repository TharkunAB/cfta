namespace MicroCFTA.SourcePruningRecordTypes
open Language SourcePruningPartialMatch
local notation "Symbol" => SourcePruningTemplates.Symbol
attribute [local instance] FormulaExecutable.formulaDecidableEq
variable {Typing Guard : Type}

/-- Original bounded pending IDs retain refutation under an agreeing assignment. -/
theorem pending_refutes_extension (limit : Nat) (original extended : Nat → Term Symbol)
    (metadata : Metadata Typing)
    (bounded : ∀ group ∈ metadata.pending, PendingBound limit group)
    (agree : ∀ uv < limit, extended uv = original uv)
    (refuted : ∀ group ∈ metadata.pending, SourcePruningResume.Refutes original group) :
    ∀ group ∈ metadata.pending, SourcePruningResume.Refutes extended group := by
  intro group member
  exact (SourcePruningResume.refutes_assignment_congr limit original extended group
    (bounded group member) agree).mpr (refuted group member)

