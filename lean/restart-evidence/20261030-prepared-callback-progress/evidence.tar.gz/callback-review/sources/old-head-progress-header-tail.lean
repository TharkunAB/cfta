            Packet formulas solver progressInventory middleCaller progressMemos metadata afterCache := by
