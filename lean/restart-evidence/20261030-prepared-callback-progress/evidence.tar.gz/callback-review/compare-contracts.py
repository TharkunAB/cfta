from pathlib import Path
import difflib, hashlib, json

area = Path(__file__).parent
digest = lambda b: hashlib.sha256(b).hexdigest()
def header(source, name):
    start = source.index('theorem ' + name + '\n')
    return source[start:source.index(' := by\n', start)]
head_old_source = ''.join((area / 'sources' / name).read_text() for name in ['old-head-progress-header.lean', 'old-head-progress-header-tail.lean'])
sibling_old_source = ''.join((area / 'sources' / name).read_text() for name in ['old-sibling-progress-header.lean', 'old-sibling-progress-header-tail.lean'])
head_new_source = (area / 'new-inputs/SourcePruningEnumerationPreparedFiniteHeadCallbackProgress.lean').read_text()
sibling_new_source = (area / 'new-inputs/SourcePruningEnumerationPreparedFiniteSiblingCallbackProgress.lean').read_text()
head_old = header(head_old_source, 'head_finite_complete_resources_accepting_progress')
head_new = header(head_new_source, 'head_finite_complete_resources_accepting_callback_progress')
sibling_old = header(sibling_old_source, 'alternatives_finite_complete_resources_accepting_progress')
sibling_new = header(sibling_new_source, 'alternatives_finite_complete_resources_accepting_callback_progress')
head_start = head_new.index(' ∧\n            ∀ extra,', head_new.index('            Packet formulas solver progressInventory'))
head_extra = head_new[head_start:]
head_recovered = head_new[:head_start].replace('theorem head_finite_complete_resources_accepting_callback_progress\n', 'theorem head_finite_complete_resources_accepting_progress\n')
assert head_recovered == head_old
sibling_start = sibling_new.index(' ∧\n                      ((∀ group ∈ metadata.pending, Refutes assignment group)')
sibling_end = sibling_new.index(') ∨\n                (eventIndex < index', sibling_start)
sibling_extra = sibling_new[sibling_start:sibling_end]
sibling_recovered = (sibling_new[:sibling_start] + sibling_new[sibling_end:]).replace('theorem alternatives_finite_complete_resources_accepting_callback_progress\n', 'theorem alternatives_finite_complete_resources_accepting_progress\n')
assert sibling_recovered == sibling_old
def operational(source, stop):
    start = source.index('    ∃ (bound : Nat)')
    return source[start:source.index(stop, start)]
head_operational = operational(head_old, '      ∀ (ambient')
assert head_operational == operational(head_new, '      ∀ (ambient')
sibling_operational = operational(sibling_old, '      ∀ extra,\n        let work')
assert sibling_operational == operational(sibling_new, '      ∀ extra,\n        let work')
stopped = sibling_old[sibling_old.index('                (eventIndex < index ∧'):]
assert stopped == sibling_new[sibling_new.index('                (eventIndex < index ∧'):]
for label, old, new, recovered, added in [('head',head_old,head_new,head_recovered,head_extra),('sibling',sibling_old,sibling_new,sibling_recovered,sibling_extra)]:
    for suffix,text in [('old-header',old),('new-header',new),('old-header-recovered',recovered),('callback-addition',added)]:
        (area / (label+'-'+suffix+'.lean')).write_text(text)
(area / 'head-operational-result.lean').write_text(head_operational)
(area / 'sibling-operational-result.lean').write_text(sibling_operational)
(area / 'sibling-earlier-stop-result.lean').write_text(stopped)
failed = area.parent / 'head-callback-v1-build/input-sources/SourcePruningEnumerationPreparedFiniteHeadCallbackProgress.lean'
failed_source = failed.read_text()
assert header(failed_source,'head_finite_complete_resources_accepting_callback_progress') == head_new
(area / 'historical-head-v1.lean').write_text(failed_source)
(area / 'head-v1-to-final.patch').write_text(''.join(difflib.unified_diff(failed_source.splitlines(keepends=True),head_new_source.splitlines(keepends=True),fromfile='failed-head-v1',tofile='checked-head-v2')))
results = dict(head_old_header_exact=True,sibling_old_header_exact=True,
    head_original_header_bytes=len(head_old.encode()),sibling_original_header_bytes=len(sibling_old.encode()),
    head_full_operational_result_bytes=len(head_operational.encode()),sibling_full_operational_result_bytes=len(sibling_operational.encode()),
    entire_earlier_stop_result_bytes=len(stopped.encode()),head_callback_addition_bytes=len(head_extra.encode()),sibling_callback_addition_bytes=len(sibling_extra.encode()),
    new_top_level_input_count=0,old_clauses_unconditional=True,policies_only_guard_new_callback_conclusion=True,
    historical_head_v1_public_header_exact=True,historical_head_v1_sha256=digest(failed_source.encode()),
    recovery='Remove only the appended callback conclusion and restore theorem names. No whitespace normalization or mathematical variable renaming.')
(area / 'contract-recovery.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
