 ∧
                      ((∀ group ∈ metadata.pending, Refutes assignment group) →
                      SourcePruningTemplates.Avoids templates (assignment uv) →
                      (∀ program, SourcePruningTemplates.ProgramAt (assignment uv) program →
                        SourcePruningTemplates.ProgramEncoding program) →
                      SourcePruningEnumerationPreparedRecursive.CallbackProgressAt formulas solver progressInventory
                        graph templates metadata uv fragment branchCaller progressMemos afterCache ambient extended
                        (EnumerationStorageProgress.pendingSize before.core assignment) work)