from pathlib import Path
import json

r=Path('/home/tritlo/Code/mcfta');p=Path('/tmp/mcfta-prepared-callback-progress-20261030')
old=(r/'lean/MicroCFTA/SourcePruningEnumerationPreparedFiniteSiblingProgress.lean').read_text()
source=old.replace('import MicroCFTA.SourcePruningEnumerationPreparedFiniteHeadProgress\n','import MicroCFTA.SourcePruningEnumerationPreparedFiniteHeadCallbackProgress\n')
start=source.index('/-!\n');end=source.index('namespace ',start)
source=source[:start]+'''/-!
# Actual prepared callback progress in the ordered sibling scan

The chosen event keeps one accepting assignment through its actual recording
callback. It keeps strict pending-term decrease and the whole recursive Packet.
All resource, output and earlier-failure cases remain exact. The callback
observation uses the same work index as the actual scan and prepared hook.
-/
'''+source[end:]
source=source.replace('theorem alternatives_finite_complete_resources_accepting_progress\n','theorem alternatives_finite_complete_resources_accepting_callback_progress\n')
source=source.replace('/-- The actual chosen head has strict progress or an exact earlier hook failure. -/','/-- The actual chosen head and callback preserve strict model progress or retain an earlier failure. -/')
needle='variable {Typing Key : Type} {bits : Nat}\n';assert needle in source
source=source.replace(needle,'''local notation "Refutes" => @SourcePruningResume.Refutes Symbol
  (@instDecidableEqProd String FullSyntax.Formula inferInstance FormulaExecutable.formulaDecidableEq)
'''+needle)
needle='                      Packet formulas solver progressInventory branchCaller progressMemos metadata afterCache) ∨\n';assert needle in source
source=source.replace(needle,'''                      Packet formulas solver progressInventory branchCaller progressMemos metadata afterCache ∧
                      (∀ group ∈ metadata.pending, Refutes assignment group) →
                      SourcePruningTemplates.Avoids templates (assignment uv) →
                      (∀ program, SourcePruningTemplates.ProgramAt (assignment uv) program →
                        SourcePruningTemplates.ProgramEncoding program) →
                      SourcePruningEnumerationPreparedRecursive.CallbackProgressAt formulas solver progressInventory
                        graph templates metadata uv fragment branchCaller progressMemos afterCache ambient extended
                        (EnumerationStorageProgress.pendingSize before.core assignment) work) ∨
''')
source=source.replace('SourcePruningEnumerationPreparedNativeHookResources.head_finite_complete_resources_accepting_progress\n','SourcePruningEnumerationPreparedNativeHookResources.head_finite_complete_resources_accepting_callback_progress\n')
needle='''                    .inl ⟨rfl, rfl, extended, agree, originalSatisfied, filled, afterSatisfied, afterProper, decrease, progressResources⟩⟩''';assert needle in source
source=source.replace(needle,'''                    .inl ⟨rfl, rfl, extended, agree, originalSatisfied, filled, afterSatisfied, afterProper, decrease, by
                      obtain ⟨progressInventory, progressMemos, progressPost, progressQuery, progressPacket, callbacks⟩ := progressResources
                      refine ⟨progressInventory, progressMemos, progressPost, progressQuery, progressPacket, ?_⟩
                      simpa only [Nat.add_sub_of_le hl] using callbacks (w - headBound)⟩⟩''')
needle='''                    simpa only [actualSame.1, actualSame.2] using progressResources⟩''';assert needle in source
source=source.replace(needle,'''                    obtain ⟨progressInventory, progressMemos, progressPost, progressQuery, progressPacket, callbacks⟩ := progressResources
                    refine ⟨progressInventory, progressMemos, ?_, ?_, ?_, ?_⟩
                    · simpa only [actualSame.1] using progressPost
                    · simpa only [actualSame.2] using progressQuery
                    · simpa only [actualSame.1] using progressPacket
                    · simpa only [actualSame.1, w] using callbacks extra⟩''')
# Keep the original progress packet conjunct outside the policy implication.
needle='''                      Packet formulas solver progressInventory branchCaller progressMemos metadata afterCache ∧
                      (∀ group ∈ metadata.pending, Refutes assignment group) →''';assert needle in source
source=source.replace(needle,'''                      Packet formulas solver progressInventory branchCaller progressMemos metadata afterCache ∧
                      ((∀ group ∈ metadata.pending, Refutes assignment group) →''')
source=source.replace('''(EnumerationStorageProgress.pendingSize before.core assignment) work) ∨''','''(EnumerationStorageProgress.pendingSize before.core assignment) work)) ∨''')
target=r/'lean/MicroCFTA/SourcePruningEnumerationPreparedFiniteSiblingCallbackProgress.lean';assert not target.exists();target.write_text(source)
(p/'sibling-callback-v1.json').write_text(json.dumps([['lake','sibling-callback-v1-build','MicroCFTA.SourcePruningEnumerationPreparedFiniteSiblingCallbackProgress'],['strict','sibling-callback-v1-strict','SourcePruningEnumerationPreparedFiniteSiblingCallbackProgress']],indent=2)+'\n')
print('Added exact-work callback progress at the chosen actual sibling event.')
