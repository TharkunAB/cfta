from pathlib import Path
import json

r=Path('/home/tritlo/Code/mcfta');p=Path('/tmp/mcfta-prepared-callback-progress-20261030')
old=(r/'lean/MicroCFTA/SourcePruningEnumerationPreparedFiniteHeadProgress.lean').read_text()
header=old[old.index('namespace '):old.index(' := by\n',old.index('theorem head_finite_complete_resources_accepting_progress\n'))]
header=header.replace('theorem head_finite_complete_resources_accepting_progress\n','theorem head_finite_complete_resources_accepting_callback_progress\n')
header=header.replace('/-- The actual stable head preserves its resources and derives strict accepted-model progress. -/','/-- The actual head and callback retain the same accepted model, strict cost and full resources. -/')
needle='variable {Typing Key : Type} {bits : Nat}\n';assert needle in header
header=header.replace(needle,'''local notation "Refutes" => @SourcePruningResume.Refutes Symbol
  (@instDecidableEqProd String FullSyntax.Formula inferInstance FormulaExecutable.formulaDecidableEq)
'''+needle)
assert header.endswith('metadata afterCache')
header+=''' ∧
            ∀ extra,
              (∀ group ∈ metadata.pending, Refutes assignment group) →
              SourcePruningTemplates.Avoids templates (assignment uv) →
              (∀ program, SourcePruningTemplates.ProgramAt (assignment uv) program →
                SourcePruningTemplates.ProgramEncoding program) →
              SourcePruningEnumerationPreparedRecursive.CallbackProgressAt formulas solver progressInventory
                graph templates metadata uv fragment middleCaller progressMemos afterCache ambient extended
                (EnumerationStorageProgress.pendingSize before.core assignment) (bound + extra)'''
imports='''import MicroCFTA.SourcePruningEnumerationPreparedFiniteHeadProgress
import MicroCFTA.SourcePruningEnumerationPreparedFiniteReceiptModels
import MicroCFTA.SourcePruningEnumerationPreparedCallbackCostProgress

/-!
# Same-model progress through the actual prepared head callback

The original head fixes its receipt and accepting-model observer.
Original receipt resources derive one callback bound before model selection.
The common work controls both actual actions. Original template policies
preserve the same accepting assignment and strict cost through recording.
-/
'''
body=''' := by
  obtain ⟨oldBound, receipt, middleCaller, saved, middleMemos, middleInventory, resources, accepting⟩ :=
    head_finite_complete_resources_accepting_progress holeKey fits admits graph templates checkEmpty edgesOf stop order
      metadata recursiveFuel seed formulas solver inventory caller memos before uv handle scs
      parentEntry storedEdges depth free edge packet proper ready stored parentAvailable parentClosed selected incoming
      bounded known selectionMembers selectionLength capturedMass inherited initialMass inheritedLength reserved
  rcases resources with ⟨headRun, headPost, headQueries, admitted, pending, history, cacheBounds,
    headFits, headKnown, shape⟩
  rcases shape with unsupported | ⟨outcome, advanced, callbackRun, outcomeResources, captured⟩
  · refine ⟨oldBound, receipt, middleCaller, saved, middleMemos, middleInventory,
      ⟨headRun, headPost, headQueries, admitted, pending, history, cacheBounds,
        headFits, headKnown, .inl unsupported⟩, ?_⟩
    intro ambient assignment satisfied accepted
    obtain ⟨extended, fragment, afterCache, _agree, _original, completed, _filled, _model,
      _proper, _decrease, _progress⟩ := accepting ambient assignment satisfied accepted
    rw [unsupported.1] at completed
    cases completed
  · have mass := SourcePruningEnumerationRecursiveReservation.head_mass_le seed capturedMass inherited
      before scs receipt initialMass inheritedLength cacheBounds
    obtain ⟨modelFuel, _modelOutcome, _modelResources, recording⟩ :=
      SourcePruningEnumerationPreparedRecursive.receipt_finite_complete_resources_models
        holeKey fits admits graph templates checkEmpty edgesOf stop order metadata formulas solver recursiveFuel
        inventory middleInventory caller middleCaller memos middleMemos before uv receipt packet headPost advanced
        admitted pending history (afterHead seed inherited) (massCeil seed capturedMass inherited)
        headFits headKnown selectionMembers selectionLength (by cases receipt <;> exact mass) reserved.2
    let bound := oldBound + modelFuel
    refine ⟨bound, receipt, middleCaller, saved, middleMemos, middleInventory,
      ⟨?_, headPost, headQueries, admitted, pending, history, cacheBounds, headFits, headKnown,
        .inr ⟨outcome, advanced, ?_, outcomeResources, captured⟩⟩, ?_⟩
    · intro extra
      simpa only [bound, ←Nat.add_assoc] using headRun (modelFuel + extra)
    · intro extra
      simpa only [bound, ←Nat.add_assoc] using callbackRun (modelFuel + extra)
    · intro ambient assignment satisfied accepted
      obtain ⟨extended, fragment, afterCache, agree, originalSatisfied, completed, filled, afterSatisfied,
        afterProper, decrease, progressInventory, progressMemos, progressPost, progressQuery, progressPacket⟩ :=
        accepting ambient assignment satisfied accepted
      refine ⟨extended, fragment, afterCache, agree, originalSatisfied, completed, filled, afterSatisfied,
        afterProper, decrease, progressInventory, progressMemos, progressPost, progressQuery, progressPacket, ?_⟩
      rw [completed] at recording
      obtain ⟨_callerSame, _querySame, recorded, callbackCore, _current, allocated, returned, _equivalence, _models⟩ := recording
      obtain ⟨_callbackPacket, _stable, _frame, _types, _holes, _typing, callback, _running, _resources⟩ := returned
      intro extra refuted avoids encoded
      have common : modelFuel + (oldBound + extra) = bound + extra := by dsimp [bound]; omega
      have observed := (callback (oldBound + extra)).1
      rw [common] at observed
      have extendedRefuted := SourcePruningRecordTypes.pending_refutes_extension
        before.core.counter assignment extended metadata packet.bounded agree refuted
      have filledSelf : Fragments.fill extended fragment = extended uv :=
        filled.trans (agree uv ready.inside).symm
      exact SourcePruningEnumerationPreparedRecursive.callback_progress_at_of_success
        formulas solver progressInventory graph templates metadata uv fragment middleCaller progressMemos afterCache
        (bound + extra) recorded callbackCore progressPacket allocated afterProper observed ambient extended afterSatisfied
        filledSelf extendedRefuted (by simpa only [filled] using avoids) (by simpa only [filled] using encoded)
        (EnumerationStorageProgress.pendingSize before.core assignment) decrease

end MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources
'''
target=r/'lean/MicroCFTA/SourcePruningEnumerationPreparedFiniteHeadCallbackProgress.lean';assert not target.exists();target.write_text(imports+header+body)
(p/'head-callback-v1.json').write_text(json.dumps([['lake','head-callback-v1-build','MicroCFTA.SourcePruningEnumerationPreparedFiniteHeadCallbackProgress'],['strict','head-callback-v1-strict','SourcePruningEnumerationPreparedFiniteHeadCallbackProgress']],indent=2)+'\n')
print('Added actual prepared head/callback composition from original resource and policy gates.')
