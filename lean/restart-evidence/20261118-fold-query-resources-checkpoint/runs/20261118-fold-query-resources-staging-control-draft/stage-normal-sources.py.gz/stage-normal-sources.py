from pathlib import Path
import ast
import datetime
import hashlib
import json
import re
import subprocess
import tempfile

ROOT = Path('/home/tritlo/Code/mcfta')
BASE = ROOT / 'lean/restart-evidence'
CONTROL = BASE / '20261118-fold-query-resources-staging-control-draft'
WORK = BASE / '20261118-ordered-fold-query-resources-work'
assert Path(__file__).resolve().parent == WORK.resolve(), 'Root reviews and copies this NEW preparer into the same Work59 directory.'
assert Path(__file__).read_bytes() == (CONTROL / 'stage-normal-sources.py').read_bytes()
selection = json.loads((CONTROL / 'SELECTION.json').read_text())
runtime = BASE / selection['runtime']
assert runtime.is_dir(), 'The FINAL combined private check must exist.'
assert not (WORK / 'SOURCES-NORMAL-STAGING.json').exists(), 'Preserve any earlier staging receipt.'
SHA = lambda data: hashlib.sha256(data).hexdigest()
bound = set()


def verify(path, record):
    data = path.read_bytes()
    assert SHA(data) == (record['sha256'] if isinstance(record, dict) else record), str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data


def records(manifest):
    files = manifest['files']
    return files.items() if isinstance(files, dict) else [(item.get('file', item.get('path')), item) for item in files]


for name, record in records(json.loads((CONTROL / 'MANIFEST.json').read_text())):
    verify(CONTROL / name, record)
bound.add(CONTROL / 'MANIFEST.json')
for name, record in json.loads((CONTROL / 'RECEIPT-PINS.json').read_text()).items():
    verify(ROOT / name, record)
assert selection['source_commit'] == 'f8feb9f2dc42b8213c002281cdbce449404ab2f9'
assert selection['source_files'] == 6283
assert selection['expected_checks'] == len(selection['components']) == 1
assert selection['expected_public_axiom_reports'] == 2
assert selection['expected_new_cached_public_reports'] == selection['expected_rebuilt_raw_reports'] == 1
assert selection['expected_explicit_private_axiom_reports'] == selection['expected_declaration_checks'] == 0
assert selection['new_private_helpers_transitive'] == selection['new_definitions'] == 0
assert selection['prior_checkpoint_push_required_for_private_check']
assert selection['prior_checkpoint_push_required_before_normal_Source_staging']
assert selection['prior_checkpoint_commit_is_dynamic']
prior = BASE / selection['prior_work']
publication = BASE / selection['prior_publication_runtime']
commit = json.loads((prior / 'SOURCE-COMMIT.json').read_text())
receipt = json.loads((prior / 'PUBLICATION-VERIFIED.json').read_text())
actual = json.loads((prior / 'PUBLICATION-ACTUAL-RUN.json').read_text())
checked = json.loads((publication / 'checked.json').read_text())
assert commit['source_commit'] == selection['source_commit'] and commit['actual_terminal'] and commit['actual_terminal_exit'] == 0
assert commit['publication_actual_session'] == receipt['actual_session'] == actual['actual_session'] == 83810
assert receipt['actual_terminal'] and actual['actual_terminal']
assert receipt['actual_terminal_exit'] == actual['actual_terminal_exit'] == 0
assert checked == json.loads((publication / 'results.json').read_text()) and checked['checks'] == receipt['checks']
assert SHA((publication / 'checked.json').read_bytes()) == receipt['checked_sha256']
assert SHA((publication / 'source-pins.json').read_bytes()) == receipt['source_pins_sha256']
assert [item['total_axiom_reports'] for item in checked['checks']] == [733, 7, 328, 733, 733]
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['sorryAx'] and not item['nonstandard_axioms']
    and item['declaration_checks'] == 0 for item in checked['checks'])
assert checked['all_five_gates_passed'] and checked['source_pins_unchanged']
assert receipt['source_files'] == 6283 and receipt['direct_audit_imports'] == 5283
assert receipt['audited_theorems'] == commit['audited_theorems'] == 100214
assert receipt['pins_independently_reverified'] == 8194
assert not receipt['joint_finite_completion_proved']
prior_publication_pins = json.loads((publication / 'source-pins.json').read_text())
assert len(prior_publication_pins) == receipt['pins_independently_reverified'] == 8194
for name, digest in prior_publication_pins.items():
    verify(ROOT / name, digest)
# Retain the actual rejected19321 attempt and independently rehash every failed input.
first_control = BASE / selection['first_controller']
first_manifest = json.loads(verify(first_control / 'MANIFEST.json', selection['first_controller_manifest_sha256']))
for name, record in records(first_manifest):
    verify(first_control / name, record)
first_runtime = BASE / selection['first_failed_runtime']
rejected = json.loads((ROOT / selection['first_failure_receipt']).read_text())
first_actual = json.loads((ROOT / selection['first_actual_run_receipt']).read_text())
first_results = json.loads((first_runtime / 'results.json').read_text())
first_pins = json.loads((first_runtime / 'source-pins.json').read_text())
assert rejected['actual_session'] == first_actual['actual_session'] == selection['first_failed_actual_session'] == 19321
assert rejected['actual_terminal'] and first_actual['actual_terminal']
assert rejected['actual_terminal_exit'] == first_actual['actual_terminal_exit'] == 1
assert rejected['runtime'] == first_actual['runtime'] == selection['first_failed_runtime']
assert rejected['checks'] == first_results['checks']
assert len(rejected['checks']) == 1
failed_check = rejected['checks'][0]
assert failed_check['exit'] == failed_check['diagnostics'] == failed_check['total_axiom_reports'] == 1
assert failed_check['axiom_groups'] == 1 and failed_check['axiom_free_reports'] == 0
assert not failed_check['sorryAx'] and not failed_check['nonstandard_axioms']
assert failed_check['declaration_checks'] == 0
assert rejected['credited_public_reports'] == first_results['credited_public_reports'] == 0
assert not first_results['proof_credit'] and first_results['source_pins_unchanged']
assert not (first_runtime / 'checked.json').exists()
assert SHA((first_runtime / 'results.json').read_bytes()) == rejected['results_sha256']
assert SHA((first_runtime / 'source-pins.json').read_bytes()) == rejected['source_pins_sha256']
assert len(first_pins) == rejected['pins_independently_reverified'] == 6332
for name, digest in first_pins.items():
    verify(ROOT / name, digest)
for name, record in json.loads((CONTROL / 'FIRST-FAILURE-PINS.json').read_text()).items():
    verify(ROOT / name, record)
failed_log = (first_runtime / 'SourcePruningEnumerationSharedTerminalFoldQueryEvents.txt').read_text()
assert "Local variable 'unit' resembles constructor 'PUnit.unit'" in failed_log
assert len(re.findall(r': error(?:\(|:)', failed_log)) == 1 and 'sorryAx' not in failed_log

# The checked RawFold proof is a literal preserved prefix, not fresh cached credit.
raw_runtime = BASE / selection['raw_repair_runtime']
raw_verified = json.loads((ROOT / selection['raw_repair_verified_receipt']).read_text())
raw_actual = json.loads((ROOT / selection['raw_repair_actual_receipt']).read_text())
raw_checked = json.loads((raw_runtime / 'checked.json').read_text())
raw_pins = json.loads((raw_runtime / 'source-pins.json').read_text())
assert raw_verified['actual_session'] == raw_actual['actual_session'] == selection['raw_repair_actual_session'] == 49861
assert raw_verified['actual_terminal'] and raw_actual['actual_terminal']
assert raw_verified['actual_terminal_exit'] == raw_actual['actual_terminal_exit'] == 0
assert raw_verified['runtime'] == raw_actual['runtime'] == selection['raw_repair_runtime']
assert raw_verified['checks'] == raw_checked['checks']
assert raw_checked == json.loads((raw_runtime / 'results.json').read_text())
assert raw_verified['single_component_checked'] and raw_verified['proof_credit'] and raw_verified['source_pins_unchanged']
assert raw_verified['actual_printed_public_axiom_reports'] == raw_verified['credited_public_reports'] == 1
assert raw_verified['actual_explicit_private_axiom_reports'] == raw_verified['actual_definition_declaration_checks'] == 0
assert len(raw_verified['checks']) == 1
assert all(c['exit'] == 0 and c['total_axiom_reports'] == 1 and not c['diagnostics']
    and not c['sorryAx'] and not c['nonstandard_axioms'] for c in raw_verified['checks'])
assert SHA((raw_runtime / 'checked.json').read_bytes()) == raw_verified['checked_sha256']
assert SHA((raw_runtime / 'results.json').read_bytes()) == raw_verified['results_sha256']
assert SHA((raw_runtime / 'source-pins.json').read_bytes()) == raw_verified['source_pins_sha256']
assert len(raw_pins) == raw_verified['pins_independently_reverified'] == 8283
for name, digest in raw_pins.items():
    verify(ROOT / name, digest)
raw_control = BASE / selection['raw_repair_controller']
raw_control_manifest = json.loads(verify(raw_control / 'MANIFEST.json', selection['raw_repair_controller_manifest_sha256']))
for name, record in records(raw_control_manifest):
    verify(raw_control / name, record)
push = json.loads((ROOT / selection['prior_push_verified_receipt']).read_text())
assert push['source_commit'] == selection['source_commit']
assert push['checkpoint_commit'] == push['remote_commit'] == selection['verified_prior_checkpoint_commit']
assert push['actual_push_terminal'] and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal'] and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
assert push['normal_Source_files'] == 6283

# Root's FINAL combined receipt binds exactly this selected owner and two reports.
stage = json.loads((CONTROL / 'EXPECTED-STAGE.json').read_text())
combined_verified = json.loads((WORK / 'CACHED-CHECK-VERIFIED.json').read_text())
combined_actual = json.loads((WORK / 'CACHED-CHECK-ACTUAL-RUN.json').read_text())
combined_checked = json.loads((runtime / 'checked.json').read_text())
combined_pins = json.loads((runtime / 'source-pins.json').read_text())
assert combined_verified['actual_session'] == combined_actual['actual_session'] == 70278
assert combined_verified['actual_terminal'] and combined_actual['actual_terminal']
assert combined_verified['actual_terminal_exit'] == combined_actual['actual_terminal_exit'] == 0
assert combined_verified['checks'] == combined_checked['checks']
assert combined_checked == json.loads((runtime / 'results.json').read_text())
assert combined_verified['single_component_checked'] and combined_verified['proof_credit']
assert combined_verified['source_pins_unchanged'] and combined_verified['actual_printed_public_axiom_reports'] == 2
assert combined_verified['credited_new_cached_public_reports'] == combined_verified['rebuilt_previously_checked_raw_reports'] == 1
assert combined_verified['fresh_credit_for_previously_checked_raw'] == 0
assert combined_verified['actual_explicit_private_axiom_reports'] == combined_verified['actual_definition_declaration_checks'] == 0
assert len(combined_verified['checks']) == 1
assert all(c['exit'] == 0 and c['total_axiom_reports'] == 2 and not c['diagnostics']
    and not c['sorryAx'] and not c['nonstandard_axioms'] for c in combined_verified['checks'])
assert SHA((runtime / 'checked.json').read_bytes()) == combined_verified['checked_sha256']
assert SHA((runtime / 'results.json').read_bytes()) == combined_verified['results_sha256']
assert SHA((runtime / 'source-pins.json').read_bytes()) == combined_verified['source_pins_sha256']
assert len(combined_pins) == combined_verified['pins_independently_reverified'] == 8330
for name, digest in combined_pins.items():
    verify(ROOT / name, digest)
combined_control = BASE / stage['combined_private_check']['control']
combined_control_manifest = json.loads(verify(combined_control / 'MANIFEST.json', stage['combined_private_check']['control_manifest_sha256']))
for name, record in records(combined_control_manifest):
    verify(combined_control / name, record)

# Documentation and frozen evidence may advance HEAD after this Source commit.
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT).decode().strip() == 'formalize'
subprocess.run(['git', 'merge-base', '--is-ancestor', selection['source_commit'], 'HEAD'], cwd=ROOT, check=True)
changes = subprocess.check_output(['git', 'diff', '--name-only', selection['source_commit'], 'HEAD'], cwd=ROOT).decode().splitlines()
assert all(name in ['NEXT-PROMPT.md', 'HANDOFF.md', 'FINDINGS.md'] or name.startswith('lean/restart-evidence/') for name in changes), changes
subprocess.run(['git', 'diff', '--quiet', selection['source_commit'], 'HEAD', '--',
    'lean/MicroCFTA', 'lean/lake-manifest.json', 'lean/lakefile.toml', 'lean/lean-toolchain', 'shell.nix'], cwd=ROOT, check=True)
baseline = json.loads((CONTROL / selection['source_baseline']).read_text())
assert baseline['source_commit'] == selection['source_commit'] and baseline['source_files'] == 6283
sources = sorted((ROOT / 'lean/MicroCFTA').glob('*.lean'))
assert {str(path.relative_to(ROOT)) for path in sources} == set(baseline['sources']) and len(sources) == 6283
public_pins = json.loads((publication / 'source-pins.json').read_text())
for name, record in {**baseline['sources'], **baseline['toolchain']}.items():
    verify(ROOT / name, record)
    assert public_pins[name] == record['sha256'], name
item = selection['components'][0]
assert selection['compile_order'] == [item['module']]
packet = BASE / item['packet']
manifest = json.loads(verify(packet / 'MANIFEST.json', item['manifest_sha256']))
for name, record in records(manifest):
    verify(packet / name, record)
for record in json.loads((packet / 'SOURCE-PINS.json').read_text())['files']:
    verify(ROOT / record['file'], record)
raw = verify(packet / item['source'], {'sha256': item['raw_sha256'], 'bytes': item['raw_bytes']})
base_packet = BASE / item['raw_base_packet']
base_manifest = json.loads(verify(base_packet / 'MANIFEST.json', item['raw_base_manifest_sha256']))
for name, record in records(base_manifest):
    verify(base_packet / name, record)
for record in json.loads((base_packet / 'SOURCE-PINS.json').read_text())['files']:
    verify(ROOT / record['file'], record)
raw_base = verify(base_packet / item['raw_base_source'], {'sha256': item['raw_base_sha256'], 'bytes': item['raw_base_bytes']})
before = verify(ROOT / item['owner_source'], {'sha256': item['owner_sha256'], 'bytes': item['owner_bytes']})
assert before == verify(CONTROL / 'OWNER-BEFORE.lean.txt', item['owner_sha256'])
assert raw_base[136:136 + 15875] == before and len(raw_base) == 25278
appended = verify(packet / item['append'], item['append_sha256'])
assembly = json.loads(verify(packet / item['assembly'], item['assembly_sha256']))
assert assembly['base_owner_bytes'] == len(raw_base) == 25278
assert assembly['base_owner_offset'] == 0 and assembly['new_import_bytes'] == 0
assert raw == raw_base + appended and raw[:25278] == raw_base
raw_header = verify(base_packet / item['raw_header'], item['raw_header_sha256'])
assert raw_header == (CONTROL / 'RAW-FIRST-HEADER.lean.txt').read_bytes()
assert raw_base.count(raw_header.rstrip()) == 1
header = verify(packet / item['header'], item['header_sha256'])
assert header == (CONTROL / 'FIRST-HEADER.lean.txt').read_bytes()
start = appended.index(header.splitlines()[0])
assert appended[start:appended.index(b':= by', start)].rstrip() == header.rstrip()
probe = verify(packet / item['probe'], item['probe_sha256'])
assert re.findall(r'^#print axioms (\S+)', probe.decode(), re.M) == item['public_qnames']
assert probe.count(b'#print axioms ') == item['expected_axiom_reports'] == 2 and b'#check ' not in probe
assert b'#print axioms ' not in raw and b'#check ' not in raw
assert re.findall(r'^theorem (\w+)', appended.decode(), re.M) == ['fold_observe_query_resources']
assert not re.findall(r'^private theorem ', appended.decode(), re.M)
assert not re.findall(r'^(?:private )?(?:def|inductive|structure) ', appended.decode(), re.M)
assert not re.search(rb'set_option\s+(?:maxHeartbeats|maxRecDepth|warningAsError|linter\.)', appended)
assert not re.search(rb'\b(?:sorry|axiom)\b', raw)
assert raw_base + b'\n' + (base_packet / 'PROBES.lean.txt').read_bytes() == (raw_runtime / 'source/MicroCFTA' / item['source']).read_bytes()
# Preserve the rejected original and its exact two-token RawFold repair provenance.
comparison = json.loads((CONTROL / 'REPAIR-COMPARISON.json').read_text())
original_packet = BASE / comparison['original_packet']
original_manifest = json.loads(verify(original_packet / 'MANIFEST.json', comparison['original_manifest_sha256']))
for name, record in records(original_manifest):
    verify(original_packet / name, record)
original_raw = verify(original_packet / comparison['source'], comparison['original_raw_sha256'])
expected_base = original_raw
for change in comparison['only_replacements']:
    assert expected_base.count(change['old'].encode()) == change['count'] == 1
    expected_base = expected_base.replace(change['old'].encode(), change['new'].encode(), 1)
assert expected_base == raw_base
for artifact in comparison['equal_artifacts']:
    assert verify(original_packet / artifact['file'], artifact['sha256']) == verify(base_packet / artifact['file'], artifact['sha256'])
assert original_raw + b'\n' + (base_packet / 'PROBES.lean.txt').read_bytes() == (first_runtime / 'source/MicroCFTA' / item['source']).read_bytes()

# The selected complete module replaces only its own private output object.
normal_objects = ROOT / 'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()
paths = {path.stem: path for path in sources}
active = []
seen = set()
order = []
graph = {}


def visit(name):
    assert name not in active, 'Import cycle: ' + repr(active + [name])
    if name in seen:
        return
    active.append(name)
    data = raw.decode() if name == item['module'] else paths[name].read_text()
    graph[name] = re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$', data, re.M)
    for dependency in graph[name]:
        assert dependency in paths, dependency
        visit(dependency)
    active.pop()
    seen.add(name)
    order.append(name)


visit(item['module'])
topological = json.loads((CONTROL / 'TOPOLOGICAL-ORDER.json').read_text())
assert graph == topological['direct_imports'] and order == topological['full_transitive_order']
assert len(order) == 1813 and len(seen - {item['module']}) == 1812
for name in seen - {item['module']}:
    assert (normal_objects / (name + '.olean')).is_file(), name
assert 'SourcePruningEnumerationSharedDispatchQueryEventResources' in seen
for name in ['shadow-compile.py.txt', 'check-driver.py.txt']:
    ast.parse((CONTROL / name).read_text())
# All preflight checks above are read-only. Only Root executes the following writes.
audit_path = ROOT / 'lean/MicroCFTA/Audit.lean'
audit_before = verify(audit_path, {'sha256': stage['old_audit_sha256'], 'bytes': stage['old_audit_bytes']})
assert audit_before == (CONTROL / 'AUDIT-BEFORE.lean.txt').read_bytes()
audit_eof = verify(CONTROL / 'AUDIT-EOF.lean.txt', stage['audit_EOF_sha256'])
assert audit_eof == b'\n' + probe
staged_audit = audit_before + audit_eof
assert SHA(staged_audit) == stage['staged_audit_sha256'] and len(staged_audit) == stage['staged_audit_bytes']
assert stage['audit_old_block_offset'] == 0 and staged_audit.startswith(audit_before)
assert len(re.findall(rb'^import ', audit_before, re.M)) == stage['audit_imports'] == 5283
assert len(re.findall(rb'^import ', staged_audit, re.M)) == 5283
assert len(re.findall(rb'^#print axioms ', audit_before, re.M)) == 733
for qname in item['public_qnames']:
    assert ('#print axioms ' + qname).encode() not in audit_before
assert len(re.findall(rb'^#print axioms ', staged_audit, re.M)) == stage['audit_reports'] == 735
assert b'import MicroCFTA.SourcePruningEnumerationSharedTerminalFoldQueryEvents\n' in audit_before
assert stage['new_modules'] == stage['new_definitions'] == stage['new_private_helpers_transitive'] == 0
assert stage['fresh_reports'] == 2 and stage['inherited_reports'] == 527 and stage['combined_reports'] == 529
assert stage['independent_reports'] == 330 and stage['resource_reports_inherited'] == 264
assert stage['old_other_Source_files_byte_exact'] == 6281
write_paths = {item['owner_source'], 'lean/MicroCFTA/Audit.lean'}
assert set(stage['exact_Source_write_paths']) == set(stage['baseline_overrides']) == write_paths
expected_pins = json.loads((CONTROL / 'EXPECTED-NORMAL-SOURCE-PINS.json').read_text())
assert SHA((CONTROL / 'EXPECTED-NORMAL-SOURCE-PINS.json').read_bytes()) == stage['expected_normal_source_pins_sha256']
assert len(expected_pins) == 6287
for name, record in {**baseline['sources'], **baseline['toolchain']}.items():
    expected_digest = SHA(raw) if name == item['owner_source'] else SHA(staged_audit) if name == 'lean/MicroCFTA/Audit.lean' else record['sha256']
    assert expected_pins[name] == expected_digest
snapshots = {ROOT / stage['baseline_overrides'][item['owner_source']]: before,
    ROOT / stage['baseline_overrides']['lean/MicroCFTA/Audit.lean']: audit_before}
assert all(not path.exists() for path in snapshots)
bound.add(Path(__file__))
preflight_pins = {str(path.relative_to(ROOT)): SHA(path.read_bytes()) for path in bound}
for name, digest in preflight_pins.items():
    assert SHA((ROOT / name).read_bytes()) == digest, name
for path, content in snapshots.items():
    path.write_bytes(content)
(ROOT / item['owner_source']).write_bytes(raw)
audit_path.write_bytes(staged_audit)
assert len(list((ROOT / 'lean/MicroCFTA').glob('*.lean'))) == 6283
for name, digest in expected_pins.items():
    assert SHA((ROOT / name).read_bytes()) == digest, name
for name, digest in preflight_pins.items():
    actual_path = ROOT / stage['baseline_overrides'].get(name, name)
    assert SHA(actual_path.read_bytes()) == digest, name
assert (ROOT / item['owner_source']).read_bytes()[136:136 + 15875] == before
assert audit_path.read_bytes()[:len(audit_before)] == audit_before
(WORK / 'NORMAL-SOURCE-PINS.json').write_bytes((CONTROL / 'EXPECTED-NORMAL-SOURCE-PINS.json').read_bytes())
actual_stage = dict(stage)
actual_stage.update(status='SOURCE_NORMAL_STAGING_COMPLETED', staged_at=datetime.datetime.now().astimezone().isoformat(), actual_private_session=70278,
    raw_private_session=49861, first_failed_session=19321, normal_Source_changed=True,
    published=False, actual_Source_files=6283, actual_audit_imports=5283,
    actual_audit_reports=735, prior_source_checkpoint_push_verified=True,
    normal_source_pins_sha256=SHA((WORK / 'NORMAL-SOURCE-PINS.json').read_bytes()))
(WORK / 'SOURCES-NORMAL-STAGING.json').write_text(json.dumps(actual_stage, indent=2) + '\n')
print(json.dumps(actual_stage, indent=2))
