from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
control = base / '20261118-fold-query-resources-publication-control-draft'
stage_control = base / '20261118-fold-query-resources-staging-control-draft'
work = base / '20261118-ordered-fold-query-resources-work'
runtime = base / '20261118-fold-query-resources-publication'
prior_work = base / '20261118-source-worker-seeds-components-work'
prior_run = base / '20261118-source-worker-seeds-components-publication'
prior_archive = base / '20261118-source-worker-seeds-components-checkpoint'
source_commit = 'f8feb9f2dc42b8213c002281cdbce449404ab2f9'
assert Path(__file__).resolve().parent == work.resolve()
archive_control = base / '20261118-fold-query-resources-checkpoint-control-draft'
assert Path(__file__).read_bytes() == (archive_control / 'prepare-checkpoint-controls.py').read_bytes()
assert runtime.is_dir(), 'The actual passed publication must exist.'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
bound = set()


def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data


def records(value):
    if isinstance(value, list):
        return [(item.get('file', item.get('path')), item) for item in value]
    if 'files' in value:
        return records(value['files'])
    if 'pins' in value:
        return records(value['pins'])
    return value.items()


for name, record in records(read(control / 'MANIFEST.json')['files']):
    verify(control / name, record)
bound.add(control / 'MANIFEST.json')
for name, record in records(read(control / 'ACTUAL-INPUT-PINS.json')):
    verify(root / name, record)
for name, record in records(read(stage_control / 'MANIFEST.json')['files']):
    verify(stage_control / name, record)
bound.add(stage_control / 'MANIFEST.json')
stage_bytes = (work / 'SOURCES-NORMAL-STAGING.json').read_bytes()
assert stage_bytes == (control / 'EXPECTED-STAGE.json').read_bytes()
stage = json.loads(stage_bytes)
assert stage['status'] == 'SOURCE_NORMAL_STAGING_COMPLETED'
assert stage['source_baseline'] == source_commit and stage['normal_Source_changed'] and not stage['published']
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6283, 5283, 735, 330)
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (2, 527, 529)
assert stage['new_public_theorems'] == 2 and stage['new_private_helpers_transitive'] == 0
assert stage['new_Prop_definitions'] == stage['definition_checks'] == stage['explicit_private_reports'] == 0
assert stage['resource_owner_reports_inherited'] == 264 and stage['fresh_credit_for_old_owner_theorems'] == 0
assert stage['actual_private_session'] == 70278 and stage['raw_private_session'] == 49861
bound.add(work / 'SOURCES-NORMAL-STAGING.json')
overrides = stage['baseline_overrides']
owner_source = 'lean/MicroCFTA/SourcePruningEnumerationSharedTerminalFoldQueryEvents.lean'
assert set(overrides) == {owner_source, 'lean/MicroCFTA/Audit.lean'}


def historical(name, record):
    digest = record['sha256'] if isinstance(record, dict) else record
    for path in [root / name, root / overrides.get(name, name)]:
        if path.is_file() and sha(path.read_bytes()) == digest:
            return verify(path, record)
    raise AssertionError(name)


cached_control = base / '20261118-cached-fold-query-resources-check-control-draft'
verify(cached_control / 'MANIFEST.json', 'ccd7de7200c25da1e56bc9321c3460d77cceec28586cf229380776f6d1f6ab8c')
selection_bytes = (cached_control / 'SELECTION.json').read_bytes()
assert selection_bytes == (control / 'CHECK-SELECTION.json').read_bytes()
selection = json.loads(selection_bytes)
assert len(selection['components']) == 1
item = stage['components'][0]
original = selection['components'][0]
for key in ['module', 'kind', 'packet', 'manifest_sha256', 'source', 'raw_sha256', 'raw_bytes',
            'probe', 'probe_sha256', 'public_qnames', 'expected_axiom_reports', 'expected_declaration_checks']:
    assert item[key] == original[key], key
assert len(stage['components']) == 1 and stage['compile_order'] == [item['module']]
assert item['expected_axiom_reports'] == 2 and item['expected_declaration_checks'] == 0
for name, record in records(read(cached_control / 'MANIFEST.json')['files']):
    verify(cached_control / name, record)
# The combined check prints RawFold once again. Count two distinct new laws,
# not one plus two. The failed first report supplies no proof credit.
for receipt_name, run_name, session, count, pin_count in [
        ('REPAIR-CHECK-VERIFIED.json', '20261118-ordered-fold-query-resources-repair-check', 49861, 1, 8283),
        ('CACHED-CHECK-VERIFIED.json', '20261118-cached-fold-query-resources-check', 70278, 2, 8330)]:
    receipt_path = work / receipt_name
    receipt = read(receipt_path)
    run = base / run_name
    assert receipt['actual_session'] == session and receipt['runtime'] == run_name
    assert receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
    assert receipt['source_baseline'] == source_commit
    checked = json.loads(verify(run / 'checked.json', receipt['checked_sha256']))
    assert checked == json.loads(verify(run / 'results.json', receipt['results_sha256']))
    assert checked['checks'] == receipt['checks'] and checked['proof_credit'] and checked['source_pins_unchanged']
    assert checked['actual_printed_public_axiom_reports'] == count
    assert checked['actual_explicit_private_axiom_reports'] == checked['actual_definition_declaration_checks'] == 0
    assert len(checked['checks']) == 1
    assert all(check['exit'] == 0 and not check['diagnostics'] and not check['sorryAx'] and not check['nonstandard_axioms']
        and check['total_axiom_reports'] == check['axiom_groups'] == count and check['axiom_free_reports'] == 0 for check in checked['checks'])
    assert checked['limits'] == {'memory.max':'8589934592', 'memory.high':'8589934592', 'memory.swap.max':'0'}
    pins = json.loads(verify(run / 'source-pins.json', receipt['source_pins_sha256']))
    assert len(pins) == receipt['pins_independently_reverified'] == pin_count
    for name, record in pins.items():
        historical(name, record)
    bound.add(receipt_path)
    bound.add(run / (item['module'] + '.txt'))
    if session == 70278:
        assert checked['raw_and_cached_FIRST_headers_exact'] and checked['entire_checked_raw_prefix_exact']
        assert checked['credited_new_cached_public_reports'] == checked['rebuilt_previously_checked_raw_reports'] == 1
        assert checked['fresh_credit_for_previously_checked_raw'] == 0
failed_receipt = read(work / 'FIRST-CHECK-REJECTED.json')
assert failed_receipt['actual_session'] == 19321 and failed_receipt['actual_terminal'] and failed_receipt['actual_terminal_exit'] == 1
failed_run = base / failed_receipt['runtime']
failed = json.loads(verify(failed_run / 'results.json', failed_receipt['results_sha256']))
assert not (failed_run / 'checked.json').exists() and not failed['proof_credit']
assert failed['checks'] == failed_receipt['checks'] and failed['credited_public_reports'] == 0
assert len(failed['checks']) == 1 and failed['checks'][0]['diagnostics'] == 1
assert failed['checks'][0]['total_axiom_reports'] == 1 and not failed['checks'][0]['sorryAx']
for name, record in json.loads(verify(failed_run / 'source-pins.json', failed_receipt['source_pins_sha256'])).items():
    historical(name, record)
bound.update([work / 'FIRST-CHECK-REJECTED.json', failed_run / (item['module'] + '.txt')])
baseline_path = root / stage['source_baseline_path']
baseline_wrapper = read(baseline_path)
assert baseline_wrapper['source_commit'] == source_commit and baseline_wrapper['source_files'] == 6283
baseline = {name:record['sha256'] for name,record in baseline_wrapper['sources'].items()}
assert len(baseline) == 6283
for name,record in baseline_wrapper['toolchain'].items():
    verify(root/name,record)
for name, record in baseline.items():
    historical(name, record)
current = sorted((root / 'lean/MicroCFTA').glob('*.lean'))
assert len(current) == 6283 and {str(path.relative_to(root)) for path in current} == set(baseline)
assert len(set(baseline) - set(overrides)) == 6281
normal_pins_path = work/'NORMAL-SOURCE-PINS.json'
normal_pins = json.loads(verify(normal_pins_path,stage['normal_source_pins_sha256']))
assert len(normal_pins) == 6287
for name,record in normal_pins.items():
    verify(root/name,record)
# Bind the prior actual publication and its pushed immutable archive.
push = read(prior_work / 'PUSH-VERIFIED.json')
prior_source = read(prior_work / 'SOURCE-COMMIT.json')
prior_publication = read(prior_work / 'PUBLICATION-VERIFIED.json')
assert push['source_commit'] == prior_source['source_commit'] == source_commit
assert push['checkpoint_commit'] == push['remote_commit'] == '6546febba4473d4347d8e4d4c68ea1c90cb7dae3'
assert push['actual_push_terminal'] and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal'] and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
assert prior_publication['actual_session'] == prior_source['publication_actual_session'] == 83810
assert prior_publication['actual_terminal'] and prior_publication['actual_terminal_exit'] == 0
assert prior_publication['combined_reports'] == 527 and prior_publication['resource_reports_inherited'] == 264
verify(prior_archive / 'manifest.json', push['archive_manifest_sha256'])
subprocess.run(['git','merge-base','--is-ancestor',push['checkpoint_commit'],'HEAD'],cwd=root,check=True)
prior_checked = read(prior_run / 'checked.json')
assert prior_checked['all_five_gates_passed'] and prior_checked['source_pins_unchanged']
assert (prior_checked['source_files'],prior_checked['independent_reports'],prior_checked['resource_and_component_probes']) == (6283,328,527)
for name, record in read(prior_run / 'source-pins.json').items():
    historical(name, record)
bound.update([prior_work/'PUSH-VERIFIED.json',prior_work/'SOURCE-COMMIT.json',prior_work/'PUBLICATION-VERIFIED.json',
    prior_work/'PUBLICATION-ACTUAL-RUN.json',prior_run/'checked.json',prior_run/'source-pins.json',prior_run/'IndependentProbes.lean',
    prior_archive/'manifest.json',prior_archive/'verify.py',prior_archive/'archived-inputs.json'])
packet = base / item['packet']
verify(packet / 'MANIFEST.json', item['manifest_sha256'])
for name, record in records(read(packet / 'MANIFEST.json')['files']):
    verify(packet / name, record)
for name, record in records(read(packet / 'SOURCE-PINS.json')):
    historical(name, record)
raw_base_packet = base / item['raw_base_packet']
verify(raw_base_packet / 'MANIFEST.json', item['raw_base_manifest_sha256'])
for name, record in records(read(raw_base_packet / 'MANIFEST.json')['files']):
    verify(raw_base_packet / name, record)
for name, record in records(read(raw_base_packet / 'SOURCE-PINS.json')):
    historical(name, record)
raw = verify(root / owner_source, {'sha256':item['raw_sha256'],'bytes':item['raw_bytes']})
assert raw == (packet / item['source']).read_bytes()
raw_base = verify(raw_base_packet / item['raw_base_source'], {'sha256':item['raw_base_sha256'],'bytes':item['raw_base_bytes']})
appended = verify(packet / item['append'], item['append_sha256'])
assert raw == raw_base + appended and len(raw_base) == 25278
old_owner = verify(root / overrides[owner_source], {'sha256':item['owner_sha256'],'bytes':item['owner_bytes']})
assert len(old_owner) == 15875 and raw_base[136:136+15875] == old_owner
assert raw_base[:136] == (raw_base_packet / 'IMPORTS.lean.txt').read_bytes()
raw_append = (raw_base_packet / 'APPEND.lean.txt').read_bytes()
assert raw_base == raw_base[:136] + old_owner + raw_append
for declarations in [raw_append,appended]:
    assert not re.search(rb'set_option\s+(maxHeartbeats|maxRecDepth|warningAsError|linter\.)',declarations)
    assert not re.findall(rb'^private theorem ',declarations,re.M)
    assert not re.findall(rb'^(?:private )?(?:def|inductive|structure) ',declarations,re.M)
assert len(re.findall(rb'^theorem ',raw_append+appended,re.M)) == 2
for header_packet,filename,digest in [(raw_base_packet,item['raw_header'],item['raw_header_sha256']),
        (packet,item['header'],item['header_sha256'])]:
    data = verify(header_packet / filename,digest)
    start = raw.index(data.splitlines()[0])
    assert raw[start:raw.index(b':= by',start)].rstrip() == data.rstrip()
assert b'#print axioms ' not in raw and b'#check ' not in raw
public = verify(packet / item['probe'],item['probe_sha256'])
assert re.findall(r'^#print axioms (\S+)',public.decode(),re.M) == item['public_qnames']
assert public.count(b'#print axioms ') == 2 and b'#check ' not in public
assert public == (control/'EXPECTED-PUBLIC-PROBES.lean.txt').read_bytes()
assert (stage_control/'AUDIT-EOF.lean.txt').read_bytes() == b'\n'+public
assert (base/'20261118-cached-fold-query-resources-check/source/MicroCFTA'/item['source']).read_bytes() == raw+b'\n'+public
old_audit = verify(root / overrides['lean/MicroCFTA/Audit.lean'], {'sha256':stage['old_audit_sha256'],'bytes':stage['old_audit_bytes']})
assert old_audit.count(b'#print axioms ') == 733
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes() == old_audit+b'\n'+public
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes().count(b'#print axioms ') == 735
assert sum(line.startswith(b'import ') for line in (root/'lean/MicroCFTA/Audit.lean').read_bytes().splitlines()) == 5283
prior_independent = (prior_run/'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 328
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = sha((root/owner_name).read_bytes())
assert owner_sha == baseline[owner_name]
normal_objects = root/'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()
# Recompute the full transitive order from actual normal staged sources.
edges = {}
visiting = set()
visited = set()
ordered = []


def walk(module):
    if module in visited:
        return
    assert module not in visiting, ('import cycle',module)
    visiting.add(module)
    data = (root/'lean/MicroCFTA'/(module+'.lean')).read_text()
    edges[module] = re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$',data,re.M)
    if module != item['module']:
        assert (normal_objects/(module+'.olean')).is_file(),module
    for child in edges[module]:
        walk(child)
    visiting.remove(module)
    visited.add(module)
    ordered.append(module)


walk(item['module'])
dag = read(control/'TOPOLOGICAL-ORDER.json')
assert edges == dag['direct_imports'] and ordered == dag['full_transitive_order'] and len(ordered) == 1813
for name in ['strict-bind.py.txt','publication-driver.py.txt','shadow-compile.py.txt']:
    ast.parse((control/name).read_text())

import gzip

archive = base/'20261118-fold-query-resources-checkpoint'
board_prefix = 'current-board-fold-query-resources-'
git = lambda *args: subprocess.check_output(['git',*args],cwd=root)
for name,record in records(read(archive_control/'MANIFEST.json')['files']):
    verify(archive_control/name,record)
for name,record in records(read(archive_control/'SOURCE-PINS.json')):
    verify(root/name,record)
bindings = read(archive_control/'prior-bindings.json')
assert bindings['prior_checkpoint'] == push['checkpoint_commit']
source_receipt = read(work/'SOURCE-COMMIT.json')
code = source_receipt['source_commit']
assert code == '04e2eb843816747cab7ec59a150d0897619274b4'
assert source_receipt['parent'] == push['checkpoint_commit']
assert source_receipt['actual_terminal'] and source_receipt['actual_terminal_exit'] == 0
assert source_receipt['private_actual_sessions'] == [49861,70278]
assert source_receipt['publication_actual_session'] == 72663
assert source_receipt['both_original_FIRST_headers_checked']
assert source_receipt['first_failed_session'] == 19321 and source_receipt['first_failed_credit'] == 0
assert not source_receipt['joint_finite_completion_proved'] and not source_receipt['haskell_changed']
assert git('rev-parse','HEAD').decode().strip() == code
assert git('rev-parse',code+'^').decode().strip() == push['checkpoint_commit']
assert git('branch','--show-current').decode().strip() == 'formalize'
assert not git('status','--porcelain','--untracked-files=no')
changed = {owner_source,'lean/MicroCFTA/Audit.lean'}
assert set(source_receipt['files']) == set(git('diff','--name-only',push['checkpoint_commit'],code).decode().splitlines()) == changed
for name in changed:
    assert git('show',code+':'+name) == (root/name).read_bytes(),name
    assert git('show',push['checkpoint_commit']+':'+name) == (root/overrides[name]).read_bytes(),name
# All three root documents must match committed bytes before any archive write.
for name in ['NEXT-PROMPT.md','HANDOFF.md','FINDINGS.md']:
    assert (root/name).read_bytes() == git('show',code+':'+name),name
report = read(runtime/'checked.json')
publication = read(work/'PUBLICATION-VERIFIED.json')
actual = read(work/'PUBLICATION-ACTUAL-RUN.json')
assert publication['actual_session'] == actual['actual_session'] == 72663
assert publication['actual_terminal'] and publication['actual_terminal_exit'] == 0
assert actual['actual_terminal'] and actual['actual_terminal_exit'] == 0
assert publication['runtime'] == actual['runtime'] == runtime.name
assert publication['checks'] == report['checks']
assert [check['total_axiom_reports']for check in report['checks']] == [735,2,330,735,735]
assert [(check['axiom_groups'],check['axiom_free_reports'])for check in report['checks']] == [(729,6),(2,0),(327,3),(729,6),(729,6)]
assert all(check['exit'] == 0 and not check['diagnostics'] and not check['sorryAx']
    and not check['nonstandard_axioms'] and check['declaration_checks'] == 0 for check in report['checks'])
assert report['all_five_gates_passed'] and report['source_pins_unchanged']
assert (report['source_files'],report['direct_audit_imports'],report['individual_reports'],report['independent_reports']) == (6283,5283,735,330)
assert (report['fresh_reports'],report['inherited_reports'],report['combined_reports']) == (2,527,529)
assert (report['new_public_theorems'],report['new_private_theorems'],report['new_theorem_declarations']) == (2,0,2)
assert report['new_prop_definitions'] == report['new_definition_declaration_checks'] == 0
assert report['resource_owner_reports_inherited'] == 264 and report['owner_preflight_reports_fresh_this_batch'] == 0
assert report['audited_theorems'] == publication['audited_theorems'] == source_receipt['audited_theorems'] == 100218
assert report['actual_ordered_rawFold_query_event_resources_checked'] and report['actual_cached_fold_query_event_resources_checked']
assert report['all_original_supplied_fuels_and_endpoints_retained']
for field in ['all_original_eager_worker_query_admissions_proved','original_eager_worker_all_calls_Seeds_propagation_proved',
        'native_inhabitance_proved','actual_source_type_marker_role_preservation_proved','guard_truth_proved','joint_finite_completion_proved','haskell_changed']:
    assert not report[field],field
public_pins = read(runtime/'source-pins.json')
for name,record in public_pins.items():
    verify(root/name,record)
assert len(public_pins) == publication['pins_independently_reverified'] == 8398
assert sha((runtime/'source-pins.json').read_bytes()) == publication['source_pins_sha256']
assert sha((runtime/'checked.json').read_bytes()) == publication['checked_sha256']
assert read(runtime/'results.json') == report
source_pins = {name:digest for name,digest in public_pins.items()if name.startswith('lean/MicroCFTA/')and name.endswith('.lean')}
assert len(source_pins) == 6283
# This batch used one final-receipt-bound Source commit control.
provenance = read(work/'SOURCE-COMMIT-ACTUAL-RUN.json')
assert provenance['source_commit'] == code and provenance['actual_session'] == 22154
assert provenance['actual_terminal'] and provenance['actual_terminal_exit'] == 0
assert provenance['parent'] == push['checkpoint_commit']
commit_control = base/provenance['control']
assert commit_control.name == '20261118-fold-query-resources-source-commit-control-draft'
verify(commit_control/'MANIFEST.json','a8cc23ced503ea1cdf947a0c2a1377bec68ddddac92d77eaf1c96ea5ddc484cb')
for name,record in records(read(commit_control/'MANIFEST.json')['files']):
    verify(commit_control/name,record)
for name,record in records(read(commit_control/'SOURCE-PINS.json')):
    verify(root/name,record)
assert (work/'commit-source.py').read_bytes() == (commit_control/'commit-source.py').read_bytes()
assert provenance['control_manifest_sha256'] == sha((commit_control/'MANIFEST.json').read_bytes())
assert provenance['script_sha256'] == sha((work/'commit-source.py').read_bytes())
assert provenance['final_publication_receipts_bound_before_control_freeze']
assert provenance['source_payload_files'] == 2 and not provenance['root_documents_or_checkpoint_committed']
# Bind the committed old archive. Never select or recursively copy it.
for name,field in [('manifest.json','prior_manifest_sha256'),('checkpoint.json','prior_checkpoint_json_sha256')]:
    data = (prior_archive/name).read_bytes()
    assert sha(data) == bindings[field]
    assert git('show',push['checkpoint_commit']+':'+str((prior_archive/name).relative_to(root))) == data
prior_checkpoint_data = read(prior_archive/'checkpoint.json')
assert prior_checkpoint_data['checked_code'] == bindings['prior_source_commit'] == source_commit
assert prior_checkpoint_data['resource_and_component_probes'] == 527
old_pins = json.loads(gzip.decompress((prior_archive/'source-pins.json.gz').read_bytes()))
assert baseline == {name:digest for name,digest in old_pins.items()if name.startswith('lean/MicroCFTA/')and name.endswith('.lean')}
for name,record in old_pins.items():
    historical(name,record)
for name in ['shell.nix','lean/lean-toolchain','lean/lakefile.toml','lean/lake-manifest.json']:
    assert old_pins[name] == public_pins[name]
request = read(work/(board_prefix+'request.json'))
canonical = read(work/(board_prefix+'canonical.json'))
assert canonical['verified']
post = canonical.get('post',canonical)
assert post['id'] == request['request_id'] and type(post['sequence']) is int and post['sequence'] > 0
for key,expected in [('author',request['username']),('thread_id',request['thread_id']),('post_type',request['post_type']),
        ('content',request['content']),('metadata',request['metadata'])]:
    assert post[key] == expected,key
assert post['metadata']['source'] == code
cleanup = read(work/'COMBINED-TMP-CLEANUP.json')
assert cleanup['all_owned_terminal_directories_removed'] and cleanup['unknown_tmp_entries_preserved'] and cleanup['no_cache_data_copied']
actual_runs = [(19321,'20261118-ordered-fold-query-resources-check'),(49861,'20261118-ordered-fold-query-resources-repair-check'),
    (70278,'20261118-cached-fold-query-resources-check'),(72663,runtime.name)]
assert len(cleanup['runs']) == 4
paths = []
cumulative = 6574734117
for entry,(session,name) in zip(cleanup['runs'],actual_runs):
    assert entry['actual_session'] == session and entry['runtime'] == name
    assert entry['path'] == read(base/name/'objects.json')['path']
    assert entry['owned_terminal_only'] and entry['normal_cache_preserved'] and entry['unknown_tmp_entries_preserved']
    assert entry['all_targets_removed'] and entry['no_cache_data_copied']
    assert not entry['live_process_references'] and not entry['process_scan_errors']
    assert not Path(entry['path']).exists() and not Path(entry['path']).is_symlink()
    assert entry['prior_cumulative_removed_bytes'] == cumulative
    cumulative += entry['regular_bytes_removed']
    assert entry['cumulative_removed_bytes'] == cumulative
    paths.append(entry['path'])
assert len(set(paths)) == 4
assert cleanup['regular_bytes_removed'] == sum(entry['regular_bytes_removed']for entry in cleanup['runs']) == 7406968
assert cleanup['symlinks_removed'] == sum(entry['symlinks_removed']for entry in cleanup['runs']) == 25264
assert cumulative == cleanup['cumulative_removed_bytes'] == 6582141085
assert cleanup['normal_cache_targets_at_final_cleanup'] == 6317
assert cleanup['normal_target_stat_sha256_at_final_cleanup'] == cleanup['runs'][-1]['normal_target_stat_sha256'] == 'b8b820b7f7aeb4b8b0f0df5ba04b0abb84b87d25fe3999844a50920596f21175'
start = read(work/'START.json')
assert start['source_commit'] == source_commit and start['full_goal_remains_open'] and start['private_proof_credit'] == 0
scope_update = read(work/'BATCH-SCOPE-UPDATE.json')
assert scope_update['original_START_preserved'] and scope_update['distinct_verified_public_theorems'] == 2
assert scope_update['current_complete_module_private_session'] == 70278 and scope_update['raw_original_verified_session'] == 49861
assert scope_update['failed_session_zero_credit'] == 19321 and scope_update['normal_publication_combined_reports'] == 529
combined_private = read(work/'COMBINED-PRIVATE-VERIFIED.json')
assert [entry['actual_session']for entry in combined_private['subsets']] == [49861,70278]
assert combined_private['distinct_public_reports'] == 2 and combined_private['raw_counted_once']
assert combined_private['all_selected_public_statements_checked'] and combined_private['no_subsets_recounted']
resume = read(work/'RESUME-AUTHORIZATION.json')
assert resume['manual_work_explicitly_authorized'] and resume['earlier_usage_pause_lifted']
assert "Keep going. We'll use a reset if needed." in resume['authorizing_instructions']
assert resume['persistent_goal_control_status'] == 'paused'
assert not resume['goal_operation_performed'] and not resume['goal_completion_claimed']
usage = read(work/'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int,float] and 0 <= percent <= 100
assert usage['current_usage_not_measured'] and usage['earlier_usage_pause_lifted_by_user_resume']
assert percent == 81 and '17:53:' in usage['checked_at']
handoff = (work/'LIVE-HANDOFF.md').read_text()
assert code in handoff and 'open' in handoff.lower()
roots = read(archive_control/'selection-roots.json')
assert len(roots) == len(set(roots)) == 15
additional = read(archive_control/'archive-additional-roots.json')
assert len(additional) == 2
for extra in additional:
    assert extra['current_batch_theorem_credit'] == 0 and not extra['private_runtime_selected']
    candidate = base/extra['root']
    verify(candidate/extra['manifest'],extra['sha256'])
    for name,record in records(read(candidate/extra['manifest'])['files']):
        verify(candidate/name,record)
    for filename in ['SOURCE-PINS.json','ADDITIONAL-SOURCE-PINS.json','DEPENDENCY-PINS.json']:
        if (candidate/filename).exists():
            for name,record in records(read(candidate/filename)):
                historical(name,record)
    roots.append(extra['root'])
assert len(roots) == len(set(roots)) == 17 and prior_archive.name not in roots
assert all((base/name).is_dir()and not (base/name).is_symlink()for name in roots)
assert not any('Work60' in name or 'terminal-query-resources-work' in name or 'terminal-query-resources-check' in name for name in roots)
for header in read(archive_control/'original-header-files.json'):
    assert sha((root/header['path']).read_bytes()) == sha((root/header['original']).read_bytes()) == header['sha256']
selected_roots = sorted(str((base/name).relative_to(root))for name in roots)
assert not archive.exists()
tree = hashlib.sha256()
for name,digest in sorted(source_pins.items()):
    tree.update(name.encode()+b'\0'+digest.encode()+b'\n')
config = dict(report)
config.update(checked_code=code,prior_checkpoint=push['checkpoint_commit'],public_run=str(runtime),public_gates=5,
    explicit_reports=735,board_prefix=board_prefix,board_post_id=post['id'],board_sequence=post['sequence'],
    source_tree_sha256=tree.hexdigest(),old_other_Source_files_byte_exact=6281,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],cleanup_receipt='COMBINED-TMP-CLEANUP.json',
    removed_regular_bytes=cleanup['regular_bytes_removed'],removed_symlinks=cleanup['symlinks_removed'],
    historical_primary_usage_percent=percent,historical_primary_usage_checked_at=usage['checked_at'],current_usage_not_measured=True,
    prior_immutable_archive=prior_archive.name,prior_manifest_sha256=bindings['prior_manifest_sha256'],
    actual_raw_private_session=49861,actual_combined_private_session=70278,actual_publication_session=72663,actual_source_commit_session=22154,
    executed_source_commit_control=commit_control.name,source_commit_control_bound_after_final_publication=True,
    old_usage_pause_reintroduced=False,persistent_goal_control_status='paused',work_authorized_by_explicit_user_resume=True,
    goal_active=False,goal_completion_claimed=False,existing_resource_FieldsThrough_observers_exported=True,
    original_per_event_worker_resource_attachment_proved=False,original_worker_admissions_proved=False,
    native_inhabitance_proved=False,joint_finite_completion_proved=False,compiled_haskell_correspondence_proved=False,haskell_changed=False,
    additional_frozen_roots=additional,additional_frozen_roots_theorem_credit=0,future_Work60_runtime_selected=False)
skipped = sorted(str(path.relative_to(root))for path in base.iterdir()
    if path.is_dir()and path.name.startswith(('20261117-','20261118-'))and str(path.relative_to(root))not in selected_roots)
review = {'selected_roots':17,'base_roots':15,'additional_frozen_roots':additional,'additional_frozen_roots_theorem_credit':0,
    'fresh_public_reports':2,'inherited_reports':527,'combined_reports':529,'new_public_theorems':2,'new_private_theorems':0,
    'new_theorem_declarations':2,'new_Prop_definitions':0,'Prop_declaration_checks':0,'Prop_axiom_credit':0,
    'resource_owner_reports_inherited':264,'current_batch_failures_preserved':[19321],
    'successful_private_and_public_runs_preserved':[49861,70278,72663],'source_commit_executed_control':commit_control.name,
    'all_root_documents_preserved_as_suffix':True,'existing_resource_FieldsThrough_observers_exported':True,
    'future_Work60_runtime_selected':False,'joint_finite_completion_proved':False}
note = (archive_control/'checkpoint-note.md').read_text()
normalized_note = ' '.join(note.lower().split())
assert 'historical' in normalized_note and 'current usage was not measured' in normalized_note
assert 'outside this checkpoint' in normalized_note and 'consult its separate receipts' in normalized_note
assert 'ONE' in note and 'SAME' in note
for key,value in {'THEOREMS':report['audited_theorems'],'PINS':publication['pins_independently_reverified'],
        'REMOVED':cleanup['regular_bytes_removed'],'SYMLINKS':cleanup['symlinks_removed'],
        'CLEANUP':cleanup['cumulative_removed_bytes'],'USAGE':percent,'BOARD':post['sequence']}.items():
    note = note.replace('{{'+key+'}}',str(value))
assert set(re.findall(r'\{\{(.*?)\}\}',note)) == {'TIME','TREE','CODE'}
outputs = {'checkpoint-config.json':config,'archive-roots.json':selected_roots,'skipped-published-roots.json':skipped,'selection-review.json':review}
assert all(not (work/name).exists()for name in outputs)
# No Work, archive or document mutation occurs before every preceding guard passes.
for name,value in outputs.items():
    (work/name).write_text(json.dumps(value,indent=2)+'\n')
(work/'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code':code,'archive':archive.name,'roots':17,'board_sequence':post['sequence'],
    'fresh_public_reports':2,'inherited_reports':527,'combined_reports':529,'current_usage_not_measured':True}))
