from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
control = base / '20261118-fold-query-resources-publication-control-draft'
stage_control = base / '20261118-fold-query-resources-staging-control-draft'
work = base / '20261118-ordered-fold-query-resources-work'
runtime = base / '20261118-fold-query-resources-publication'
prior_work = base / '20261118-source-worker-seeds-components-work'
prior_run = base / '20261118-source-worker-seeds-components-publication'
prior_archive = base / '20261118-source-worker-seeds-components-checkpoint'
source_commit = 'f8feb9f2dc42b8213c002281cdbce449404ab2f9'
assert Path(__file__).resolve().parent == work.resolve()
assert Path(__file__).read_bytes() == (control / 'prepare-publication.py').read_bytes()
assert not runtime.exists(), 'Preserve every previous runtime.'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
bound = set()


def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data


def records(value):
    if isinstance(value, list):
        return [(item.get('file', item.get('path')), item) for item in value]
    if 'files' in value:
        return records(value['files'])
    if 'pins' in value:
        return records(value['pins'])
    return value.items()


for name, record in records(read(control / 'MANIFEST.json')['files']):
    verify(control / name, record)
bound.add(control / 'MANIFEST.json')
for name, record in records(read(control / 'ACTUAL-INPUT-PINS.json')):
    verify(root / name, record)
for name, record in records(read(stage_control / 'MANIFEST.json')['files']):
    verify(stage_control / name, record)
bound.add(stage_control / 'MANIFEST.json')
stage_bytes = (work / 'SOURCES-NORMAL-STAGING.json').read_bytes()
assert stage_bytes == (control / 'EXPECTED-STAGE.json').read_bytes()
stage = json.loads(stage_bytes)
assert stage['status'] == 'SOURCE_NORMAL_STAGING_COMPLETED'
assert stage['source_baseline'] == source_commit and stage['normal_Source_changed'] and not stage['published']
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6283, 5283, 735, 330)
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (2, 527, 529)
assert stage['new_public_theorems'] == 2 and stage['new_private_helpers_transitive'] == 0
assert stage['new_Prop_definitions'] == stage['definition_checks'] == stage['explicit_private_reports'] == 0
assert stage['resource_owner_reports_inherited'] == 264 and stage['fresh_credit_for_old_owner_theorems'] == 0
assert stage['actual_private_session'] == 70278 and stage['raw_private_session'] == 49861
bound.add(work / 'SOURCES-NORMAL-STAGING.json')
overrides = stage['baseline_overrides']
owner_source = 'lean/MicroCFTA/SourcePruningEnumerationSharedTerminalFoldQueryEvents.lean'
assert set(overrides) == {owner_source, 'lean/MicroCFTA/Audit.lean'}


def historical(name, record):
    digest = record['sha256'] if isinstance(record, dict) else record
    for path in [root / name, root / overrides.get(name, name)]:
        if path.is_file() and sha(path.read_bytes()) == digest:
            return verify(path, record)
    raise AssertionError(name)


cached_control = base / '20261118-cached-fold-query-resources-check-control-draft'
verify(cached_control / 'MANIFEST.json', 'ccd7de7200c25da1e56bc9321c3460d77cceec28586cf229380776f6d1f6ab8c')
selection_bytes = (cached_control / 'SELECTION.json').read_bytes()
assert selection_bytes == (control / 'CHECK-SELECTION.json').read_bytes()
selection = json.loads(selection_bytes)
assert len(selection['components']) == 1
item = stage['components'][0]
original = selection['components'][0]
for key in ['module', 'kind', 'packet', 'manifest_sha256', 'source', 'raw_sha256', 'raw_bytes',
            'probe', 'probe_sha256', 'public_qnames', 'expected_axiom_reports', 'expected_declaration_checks']:
    assert item[key] == original[key], key
assert len(stage['components']) == 1 and stage['compile_order'] == [item['module']]
assert item['expected_axiom_reports'] == 2 and item['expected_declaration_checks'] == 0
for name, record in records(read(cached_control / 'MANIFEST.json')['files']):
    verify(cached_control / name, record)
# The combined check prints RawFold once again. Count two distinct new laws,
# not one plus two. The failed first report supplies no proof credit.
for receipt_name, run_name, session, count, pin_count in [
        ('REPAIR-CHECK-VERIFIED.json', '20261118-ordered-fold-query-resources-repair-check', 49861, 1, 8283),
        ('CACHED-CHECK-VERIFIED.json', '20261118-cached-fold-query-resources-check', 70278, 2, 8330)]:
    receipt_path = work / receipt_name
    receipt = read(receipt_path)
    run = base / run_name
    assert receipt['actual_session'] == session and receipt['runtime'] == run_name
    assert receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
    assert receipt['source_baseline'] == source_commit
    checked = json.loads(verify(run / 'checked.json', receipt['checked_sha256']))
    assert checked == json.loads(verify(run / 'results.json', receipt['results_sha256']))
    assert checked['checks'] == receipt['checks'] and checked['proof_credit'] and checked['source_pins_unchanged']
    assert checked['actual_printed_public_axiom_reports'] == count
    assert checked['actual_explicit_private_axiom_reports'] == checked['actual_definition_declaration_checks'] == 0
    assert len(checked['checks']) == 1
    assert all(check['exit'] == 0 and not check['diagnostics'] and not check['sorryAx'] and not check['nonstandard_axioms']
        and check['total_axiom_reports'] == check['axiom_groups'] == count and check['axiom_free_reports'] == 0 for check in checked['checks'])
    assert checked['limits'] == {'memory.max':'8589934592', 'memory.high':'8589934592', 'memory.swap.max':'0'}
    pins = json.loads(verify(run / 'source-pins.json', receipt['source_pins_sha256']))
    assert len(pins) == receipt['pins_independently_reverified'] == pin_count
    for name, record in pins.items():
        historical(name, record)
    bound.add(receipt_path)
    bound.add(run / (item['module'] + '.txt'))
    if session == 70278:
        assert checked['raw_and_cached_FIRST_headers_exact'] and checked['entire_checked_raw_prefix_exact']
        assert checked['credited_new_cached_public_reports'] == checked['rebuilt_previously_checked_raw_reports'] == 1
        assert checked['fresh_credit_for_previously_checked_raw'] == 0
failed_receipt = read(work / 'FIRST-CHECK-REJECTED.json')
assert failed_receipt['actual_session'] == 19321 and failed_receipt['actual_terminal'] and failed_receipt['actual_terminal_exit'] == 1
failed_run = base / failed_receipt['runtime']
failed = json.loads(verify(failed_run / 'results.json', failed_receipt['results_sha256']))
assert not (failed_run / 'checked.json').exists() and not failed['proof_credit']
assert failed['checks'] == failed_receipt['checks'] and failed['credited_public_reports'] == 0
assert len(failed['checks']) == 1 and failed['checks'][0]['diagnostics'] == 1
assert failed['checks'][0]['total_axiom_reports'] == 1 and not failed['checks'][0]['sorryAx']
for name, record in json.loads(verify(failed_run / 'source-pins.json', failed_receipt['source_pins_sha256'])).items():
    historical(name, record)
bound.update([work / 'FIRST-CHECK-REJECTED.json', failed_run / (item['module'] + '.txt')])
baseline_path = root / stage['source_baseline_path']
baseline_wrapper = read(baseline_path)
assert baseline_wrapper['source_commit'] == source_commit and baseline_wrapper['source_files'] == 6283
baseline = {name:record['sha256'] for name,record in baseline_wrapper['sources'].items()}
assert len(baseline) == 6283
for name,record in baseline_wrapper['toolchain'].items():
    verify(root/name,record)
for name, record in baseline.items():
    historical(name, record)
current = sorted((root / 'lean/MicroCFTA').glob('*.lean'))
assert len(current) == 6283 and {str(path.relative_to(root)) for path in current} == set(baseline)
assert len(set(baseline) - set(overrides)) == 6281
normal_pins_path = work/'NORMAL-SOURCE-PINS.json'
normal_pins = json.loads(verify(normal_pins_path,stage['normal_source_pins_sha256']))
assert len(normal_pins) == 6287
for name,record in normal_pins.items():
    verify(root/name,record)
# Bind the prior actual publication and its pushed immutable archive.
push = read(prior_work / 'PUSH-VERIFIED.json')
prior_source = read(prior_work / 'SOURCE-COMMIT.json')
prior_publication = read(prior_work / 'PUBLICATION-VERIFIED.json')
assert push['source_commit'] == prior_source['source_commit'] == source_commit
assert push['checkpoint_commit'] == push['remote_commit'] == '6546febba4473d4347d8e4d4c68ea1c90cb7dae3'
assert push['actual_push_terminal'] and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal'] and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
assert prior_publication['actual_session'] == prior_source['publication_actual_session'] == 83810
assert prior_publication['actual_terminal'] and prior_publication['actual_terminal_exit'] == 0
assert prior_publication['combined_reports'] == 527 and prior_publication['resource_reports_inherited'] == 264
verify(prior_archive / 'manifest.json', push['archive_manifest_sha256'])
subprocess.run(['git','merge-base','--is-ancestor',push['checkpoint_commit'],'HEAD'],cwd=root,check=True)
prior_checked = read(prior_run / 'checked.json')
assert prior_checked['all_five_gates_passed'] and prior_checked['source_pins_unchanged']
assert (prior_checked['source_files'],prior_checked['independent_reports'],prior_checked['resource_and_component_probes']) == (6283,328,527)
for name, record in read(prior_run / 'source-pins.json').items():
    historical(name, record)
bound.update([prior_work/'PUSH-VERIFIED.json',prior_work/'SOURCE-COMMIT.json',prior_work/'PUBLICATION-VERIFIED.json',
    prior_work/'PUBLICATION-ACTUAL-RUN.json',prior_run/'checked.json',prior_run/'source-pins.json',prior_run/'IndependentProbes.lean',
    prior_archive/'manifest.json',prior_archive/'verify.py',prior_archive/'archived-inputs.json'])
packet = base / item['packet']
verify(packet / 'MANIFEST.json', item['manifest_sha256'])
for name, record in records(read(packet / 'MANIFEST.json')['files']):
    verify(packet / name, record)
for name, record in records(read(packet / 'SOURCE-PINS.json')):
    historical(name, record)
raw_base_packet = base / item['raw_base_packet']
verify(raw_base_packet / 'MANIFEST.json', item['raw_base_manifest_sha256'])
for name, record in records(read(raw_base_packet / 'MANIFEST.json')['files']):
    verify(raw_base_packet / name, record)
for name, record in records(read(raw_base_packet / 'SOURCE-PINS.json')):
    historical(name, record)
raw = verify(root / owner_source, {'sha256':item['raw_sha256'],'bytes':item['raw_bytes']})
assert raw == (packet / item['source']).read_bytes()
raw_base = verify(raw_base_packet / item['raw_base_source'], {'sha256':item['raw_base_sha256'],'bytes':item['raw_base_bytes']})
appended = verify(packet / item['append'], item['append_sha256'])
assert raw == raw_base + appended and len(raw_base) == 25278
old_owner = verify(root / overrides[owner_source], {'sha256':item['owner_sha256'],'bytes':item['owner_bytes']})
assert len(old_owner) == 15875 and raw_base[136:136+15875] == old_owner
assert raw_base[:136] == (raw_base_packet / 'IMPORTS.lean.txt').read_bytes()
raw_append = (raw_base_packet / 'APPEND.lean.txt').read_bytes()
assert raw_base == raw_base[:136] + old_owner + raw_append
for declarations in [raw_append,appended]:
    assert not re.search(rb'set_option\s+(maxHeartbeats|maxRecDepth|warningAsError|linter\.)',declarations)
    assert not re.findall(rb'^private theorem ',declarations,re.M)
    assert not re.findall(rb'^(?:private )?(?:def|inductive|structure) ',declarations,re.M)
assert len(re.findall(rb'^theorem ',raw_append+appended,re.M)) == 2
for header_packet,filename,digest in [(raw_base_packet,item['raw_header'],item['raw_header_sha256']),
        (packet,item['header'],item['header_sha256'])]:
    data = verify(header_packet / filename,digest)
    start = raw.index(data.splitlines()[0])
    assert raw[start:raw.index(b':= by',start)].rstrip() == data.rstrip()
assert b'#print axioms ' not in raw and b'#check ' not in raw
public = verify(packet / item['probe'],item['probe_sha256'])
assert re.findall(r'^#print axioms (\S+)',public.decode(),re.M) == item['public_qnames']
assert public.count(b'#print axioms ') == 2 and b'#check ' not in public
assert public == (control/'EXPECTED-PUBLIC-PROBES.lean.txt').read_bytes()
assert (stage_control/'AUDIT-EOF.lean.txt').read_bytes() == b'\n'+public
assert (base/'20261118-cached-fold-query-resources-check/source/MicroCFTA'/item['source']).read_bytes() == raw+b'\n'+public
old_audit = verify(root / overrides['lean/MicroCFTA/Audit.lean'], {'sha256':stage['old_audit_sha256'],'bytes':stage['old_audit_bytes']})
assert old_audit.count(b'#print axioms ') == 733
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes() == old_audit+b'\n'+public
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes().count(b'#print axioms ') == 735
assert sum(line.startswith(b'import ') for line in (root/'lean/MicroCFTA/Audit.lean').read_bytes().splitlines()) == 5283
prior_independent = (prior_run/'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 328
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = sha((root/owner_name).read_bytes())
assert owner_sha == baseline[owner_name]
normal_objects = root/'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()
# Recompute the full transitive order from actual normal staged sources.
edges = {}
visiting = set()
visited = set()
ordered = []


def walk(module):
    if module in visited:
        return
    assert module not in visiting, ('import cycle',module)
    visiting.add(module)
    data = (root/'lean/MicroCFTA'/(module+'.lean')).read_text()
    edges[module] = re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$',data,re.M)
    if module != item['module']:
        assert (normal_objects/(module+'.olean')).is_file(),module
    for child in edges[module]:
        walk(child)
    visiting.remove(module)
    visited.add(module)
    ordered.append(module)


walk(item['module'])
dag = read(control/'TOPOLOGICAL-ORDER.json')
assert edges == dag['direct_imports'] and ordered == dag['full_transitive_order'] and len(ordered) == 1813
for name in ['strict-bind.py.txt','publication-driver.py.txt','shadow-compile.py.txt']:
    ast.parse((control/name).read_text())
# Root creates the publication runtime only after every read-only gate passes.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-fold-query-resources-publication-'))
(objects/'MicroCFTA').mkdir()
for dependency in normal_objects.glob('*.olean'):
    if dependency.stem != item['module']:
        (objects/'MicroCFTA'/dependency.name).symlink_to(dependency)
assert not (objects/'MicroCFTA'/(item['module']+'.olean')).exists()
(runtime/'objects.json').write_text(json.dumps({'path':str(objects)},indent=2)+'\n')
fixture = runtime/'source/MicroCFTA'/item['source']
fixture.parent.mkdir(parents=True)
fixture.write_bytes(raw)
bound.add(fixture)
fresh_import = ('import MicroCFTA.'+item['module']+'\n').encode()
(runtime/'FreshPublicProbes.lean').write_bytes(fresh_import+public)
# The prior independent fixture has no direct import of this owner.
(runtime/'IndependentProbes.lean').write_bytes(fresh_import+prior_independent+b'\n'+public)
for src,dst in [('strict-bind.py.txt','strict-new-and-bind.py'),('publication-driver.py.txt','check.py'),('shadow-compile.py.txt','shadow-compile.py')]:
    (runtime/dst).write_bytes((control/src).read_bytes())
(runtime/'REPORT-BASE.json').write_bytes((control/'REPORT-BASE.json').read_bytes())
inheritance = {'compile_order':stage['compile_order'],'definition_names':[],
    'prior_checkpoint':push['checkpoint_commit'],'prior_archive_manifest_sha256':push['archive_manifest_sha256'],
    'prior_checked_sha256':sha((prior_run/'checked.json').read_bytes()),
    'prior_pins_sha256':sha((prior_run/'source-pins.json').read_bytes()),
    'stage_sha256':sha(stage_bytes),'baseline_sha256':sha(baseline_path.read_bytes()),
    'baseline_path':str(baseline_path.relative_to(root)),
    'baseline_overrides':overrides,'override_digests':{name:sha((root/path).read_bytes())for name,path in overrides.items()},
    'inherited_reports':527,'fresh_reports':2,'combined_reports':529,
    'resource_owner_sha256':owner_sha,'resource_owner_reports_inherited':264,
    'owner_preflight_reports_fresh_this_batch':0,'new_private_helpers':0,
    'Prop_declaration_checks':0,'Prop_axiom_credit':0,'actual_raw_private_session':49861,
    'actual_combined_private_session':70278,'raw_rebuilt_reports_not_double_counted':True,
    'fresh_owner_theorem_credit':0,'cache_data_copied':False}
(runtime/'INHERITANCE-SELECTION.json').write_text(json.dumps(inheritance,indent=2)+'\n')
bound.update([Path(__file__),baseline_path,control/'TOPOLOGICAL-ORDER.json'])
bound.update(current)
bound.update(path for path in runtime.iterdir() if path.is_file())
(runtime/'source-pins.json').write_text(json.dumps({str(path.relative_to(root)):sha(path.read_bytes())for path in sorted(bound)},indent=2,sort_keys=True)+'\n')
print(json.dumps({'runtime':str(runtime),'gates':5,'strict_fresh_modules':1,'fresh_public_reports':2,
    'definition_checks':0,'inherited_reports':527,'combined_reports':529,'source_files':6283,
    'independent_reports':330,'audit_reports':735,'objects':str(objects),'normal_Source_changed':False}))
