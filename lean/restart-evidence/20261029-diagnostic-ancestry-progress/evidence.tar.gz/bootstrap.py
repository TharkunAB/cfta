"""Retain the current checkpoint before additive diagnostic proof work."""
from pathlib import Path
import subprocess,hashlib,json,shutil
ROOT=Path('/home/tritlo/Code/mcfta');AREA=Path('/tmp/mcfta-diagnostic-ancestry-progress-20261029');PRIOR=Path('/tmp/mcfta-recursive-ancestry-progress-20261029')
def record(p):
 raw=p.read_bytes();return {'path':str(p.relative_to(ROOT)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
lean=[record(p) for p in sorted((ROOT/'lean/MicroCFTA').glob('*.lean')) if p.name!='Audit.lean'];assert len(lean)==4598;(AREA/'prior-lean-sources.json').write_text(json.dumps(lean,indent=2)+'\n');strong=json.loads((PRIOR/'prior-strong-sources.json').read_text())+[{k:v for k,v in r.items() if k in ['module','path','bytes','sha256']} for r in json.loads((PRIOR/'new-source-manifest.json').read_text())];assert len(strong)==447;(AREA/'prior-strong-sources.json').write_text(json.dumps(strong,indent=2)+'\n');shutil.copyfile(ROOT/'lean/MicroCFTA/Audit.lean',AREA/'prior-Audit.lean')
for filename in ['inherited-prior-haskell-sources.json','public-declarations.json','public-definitions.json']:shutil.copyfile(PRIOR/filename,AREA/filename)
shutil.copyfile(PRIOR/'public-definitions.json',AREA/'prior-public-definitions.json');shutil.copyfile(PRIOR/'public-readback/raw.log',AREA/'prior-public-readback.log');(AREA/'prior-public-readback').mkdir();shutil.copyfile(PRIOR/'public-readback/public.lean',AREA/'prior-public-readback/public.lean')
docs=[]
for old in json.loads((PRIOR/'final-documents.json').read_text()):
 p=ROOT/old['path'];r=record(p);assert r['sha256']==old['sha256'];target=AREA/'prior-document-bodies'/old['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);docs.append(r)
assert len(docs)==24;(AREA/'prior-documents.json').write_text(json.dumps(docs,indent=2)+'\n')
for name in ['modules.json','new-public-declarations.json','new-public-definitions.json']:(AREA/name).write_text('[]\n')
for name in ['check-installed.py','run-check-batch.py']:(AREA/name).write_text((PRIOR/name).read_text().replace(str(PRIOR),str(AREA)))
(AREA/'peaks').mkdir();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();main=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip();subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],check=True);assert not subprocess.check_output(['git','status','--porcelain'],text=True);state={'head':head,'main':main,'main_is_ancestor':True,'prior_goal_turn':'verified progress','full_goal':'active','baseline_lean':len(lean),'baseline_strong':len(strong),'baseline_documents':len(docs)};(AREA/'bootstrap.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state))
