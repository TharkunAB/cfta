# Prepared finite diagnostic resource producers

Date: 2026-10-29 Europe/Stockholm.
Status: three immutable source candidates, author UNTESTED. Root owns checks.

## Complete interfaces

The three modules use the exact old theorem names plus `_with_diagnostics`.
The old recursive Complete argument becomes CompleteWithDiagnosticAncestry.
All other original gates and ALL existing return fields remain unchanged.
The literal full statements and their environments are retained in
public-signatures-v1.json. statement-preservation-v1.json verifies literal old
header equality after reversing only the announced changes below.

1. PreparedDiagnosticCallbackResources exports
   PreparedRecursive.callback_finite_complete_resources_with_diagnostics.
   It appends OutcomeDiagnosticAncestry before.core outcome LAST after the old
   OutcomeResources. No new input is added. The exact original callback Packet,
   RenderStable, Frame, metadata fields, all-fuel singleton recording equation
   and actual continueWith equations remain unchanged.
2. PreparedDiagnosticReceiptResources exports
   PreparedRecursive.receipt_finite_complete_resources_with_diagnostics.
   It appends LOCAL retained : ReceiptAncestry before.core receipt LAST after
   reserved. Its result is bound, outcome, all-extra callbackRun, original
   OutcomeResources, then OutcomeDiagnosticAncestry before.core outcome.
   Arbitrary Admitted receipts do not supply this local relation. Its callers
   must derive it from literal captured or opaque native run observations.
3. PreparedDiagnosticOpaqueResources exports
   PreparedNativeHookResources.opaque_finite_complete_resources_with_diagnostics.
   It adds no original input gate. It keeps every old existential witness and
   result field through the last actual opaqueFoldRun equation. It appends
   OutcomeDiagnosticAncestry before.core outcome, then
   OutcomeDiagnosticAncestry before.core (finish target folded).

The local receipt premise position was sent to the sibling/head producer owner.
That producer derives its relation using ReceiptAncestry.of_captured actualRun.
The root was sent the exact opaque result field order before integration.

## Actual proof route

The callback reuses the actual callback_complete recording producer. In its
true branch, the exact actual result is complete with no diagnostic. In its
false branch, the smaller-depth induction hypothesis runs at THIS callback's
framed core, own Packet, native caller and full Memos. The existing Frame gives
Extends original callbackCore. OutcomeDiagnosticAncestry.mono moves the SAME
actual result's diagnostic relation back to the original callback input.
No output needs to be emitted. The original mass proof and common-fuel arithmetic
remain intact. No future callback relation is assumed.

The receipt proof keeps the exact receipt_packet derivation. A complete receipt
calls the strengthened callback at its actual completed cache. The local literal
receipt relation transports diagnostic ancestry back to the original captured
input. Rejected and stopped receipts give the original complete-empty hook;
their own attached caches are covered by the enclosing fold's receipt relation.
An unhandled receipt contradicts the same original advance equation.

The opaque proof invokes the actual native opaque receipt producer once. Its
point headRun at extra=0 derives ReceiptAncestry.of_opaque. The receipt helper
then gives the recursive hook diagnostic relation. The literal singleton fold
has no diagnostic when it completes. When the hook stops, its stopped fold has
an empty processed list and continuation(current receipt, SAME nested reason,
SAME optional endpoint). The final proof combines actual current-receipt ancestry
with the already-derived nested FailureAncestry. This covers receipt cache plus
nested diagnostic even if the hook emits no output. The native resource Post is
used only for its original resource purpose, not as enumeration preservation.

## Induction and scope

CompleteWithDiagnosticAncestry is the internal smaller-depth contract. Root will
discharge it through the actual finite-depth induction. These three local
producers do not claim it as a new original admission. They add no model, carrier,
Origins, Canonical, Arity, ProjectionHeap, later/future Heap, child support,
termination certificate or generic preservation supplier. The prepared Failure
and callback runtime are used directly. There is no old/prepared cast or stored
source/prepared-parent identity assumption.

OutcomeDiagnosticAncestry is diagnostic-only. Complete outcomes impose True.
Failure.callback and Failure.preparation have no attached Cached by this
predicate. Raw Core rows and emitted output caches are separate scopes. The
existing output-retention theorem remains separate. This task does not prove
model/output coverage, sufficient recursive depth, global termination, a finite
native-handle universe, Haskell correspondence or arbitrary smaller work fuels.

## Evidence

All three candidates were read back WHOLE after writing, without truncation.
Inputs were read WHOLE and copied with exact byte/hash identities, except the
literal prepared-runtime cut recorded separately in inputs-v1-manifest.json.
The theorem statement comparison preserves ALL old fields and gates after only
renaming, replacing internal recursive Complete, adding the stated local receipt
premise, and appending the announced diagnostic result fields. Full source diffs
are retained for review. Public statements here are source text, not checked
Lean exports. Root owns compiler, strict-check and Audit evidence.

No compiler, evaluator, native job, repository edit, Git, network or board action
ran in this task. No Haskell defect or fix was found. No Haskell/FINDINGS file was
changed. All older areas and candidate versions remain immutable. These three
v1 files and this report are frozen. Root may own later repairs in new versions.
