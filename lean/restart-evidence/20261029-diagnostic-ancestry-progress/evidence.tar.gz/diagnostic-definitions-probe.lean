import MicroCFTA.SourcePruningEnumerationPreparedRecursive
import MicroCFTA.SourcePruningEnumerationAncestryExtension
namespace MicroCFTA.SourcePruningEnumerationPreparedRecursive
open EnumerationState SourcePruningEnumerationAncestryExtension
open SourcePruningEnumerationNativeContinuations (HookResult)
open SourcePruningEnumerationRecursive (Output)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Core" => EnumerationState.State Symbol Constraint
local notation "Receipt" => SourcePruningEnumerationSelectedEdge.Result
variable {width : Nat} {Typing : Type}
/-- Every concrete receipt cache extends the original per-slot recursion histories. -/
def ReceiptAncestry (original : Core) : Receipt width → Prop
  | .complete _ _ _ after | .rejected _ _ after | .stopped _ _ (some after) =>
      Extends original after.core
  | _ => True

/-- Retain the prefix candidate and every cache in an attached ordinary scan. -/
def PrefixAncestry (original : Core) : SourcePruningEnumerationSelectedStep.Result width Typing → Prop
  | .stopped _ _ => True
  | .parked _ candidate _ =>
      match candidate with
      | none => True
      | some after => Extends original after.core
  | .narrowed _ _ _ _ _ candidate _ ordinary =>
      (match candidate with
        | none => True
        | some after => Extends original after.core) ∧
      match ordinary with
      | none | some (_, none) => True
      | some (_, some (.complete processed _ _)) =>
          ∀ receipt ∈ processed, ReceiptAncestry original receipt
      | some (_, some (.stopped processed current)) =>
          (∀ receipt ∈ processed, ReceiptAncestry original receipt) ∧
          match current with
          | none => True
          | some receipt => ReceiptAncestry original receipt

/-- Retain every Cached value in the actual recursive stop diagnostic. -/
def FailureAncestry (original : Core) : Failure width Typing → Prop
  | .exhausted _ _ before => Extends original before.core
  | .selected _ observed => PrefixAncestry original observed
  | .callback _ _ | .preparation _ _ => True
  | .alternatives _ processed current =>
      (∀ receipt ∈ processed, ReceiptAncestry original receipt) ∧
      match current with
      | .edge candidate =>
          match candidate with
          | none => True
          | some receipt => ReceiptAncestry original receipt
      | .continuation receipt reason _ =>
          ReceiptAncestry original receipt ∧ FailureAncestry original reason

/-- Complete outcomes have no diagnostic; stopped outcomes retain every attached cache. -/
def OutcomeDiagnosticAncestry (original : Core) :
    HookResult (Output width Typing) (Failure width Typing) width → Prop
  | .complete _ _ _ => True
  | .stopped _ reason _ => FailureAncestry original reason

end MicroCFTA.SourcePruningEnumerationPreparedRecursive
