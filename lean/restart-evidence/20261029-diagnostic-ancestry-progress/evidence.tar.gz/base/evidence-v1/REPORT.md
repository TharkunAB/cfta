# Concrete prepared diagnostic ancestry

Status: FROZEN author candidate v1. Source-only authoring. Root owns compilation.

The module supplies four concrete Prop definitions and eight proof declarations.
It does not introduce a Complete contract. Root owns that separate closed induction.

## Exact predicates

ReceiptAncestry covers the literal cache in a completed or rejected SelectedEdge receipt,
and the actual Some candidate of a stopped receipt. Unhandled or missing candidates are True.

PrefixAncestry covers the parked or narrowed candidate. A narrowed result also covers every
receipt in an attached ordinary NativeBranches.Result. Its complete branch covers processed
receipts. Its stopped branch covers processed receipts AND its optional current receipt.
The raw Entry rows in the ordinary pair contain Core values and are not Cached fields.
The predicate includes the ordinary field for arbitrary diagnostics; it does not assume
that field is absent on a manually supplied Result.

FailureAncestry covers all five actual prepared Failure constructors:

- exhausted: the literal stored input cache.
- selected: the full PrefixAncestry predicate above.
- callback and preparation: True, because these payloads have raw Core rows/native state,
  with no concrete enumeration Cached field.
- alternatives: every processed receipt, followed by the actual current Stop. An edge stop
  covers its optional receipt. A continuation stop covers its current receipt AND recursively
  every attachment in the nested prepared Failure.

OutcomeDiagnosticAncestry is diagnostic-only, as Root confirmed. Complete is True.
Stopped requires FailureAncestry of the actual reason. It makes no assertion about output
caches. Root retains the existing output-ancestry theorem separately. None native endpoints
remain None; no aggregate enumeration cache is invented.

All four definitions require no DecidableEq instance. Root reported exact draft-v1 definitions
strict PASS in a minimal probe, with no output and no definition change. The same definition
bytes are retained in the full candidate. The definitions operate on the actual prepared
Failure, not its old nominal counterpart.

## Public APIs

ReceiptAncestry.mono, PrefixAncestry.mono, FailureAncestry.mono and
OutcomeDiagnosticAncestry.mono take extension : Extends original middle, then retained at
middle. They return the same predicate at original for the exact same receipt/result/reason.
Every concrete cache composes by Extends.trans. Failure transport includes nested reasons.
These four transport proofs require no DecidableEq instance.

ReceiptAncestry.of_captured takes one explicit actual CapturedEdge.run equality ending in
some receipt. All run fuels, target, edge, initial cache, Caller, Queries and receipt are implicit.
It derives ReceiptAncestry before.core receipt from the checked all-cache observer.

ReceiptAncestry.of_opaque has the same convention for actual SelectedOpaqueDispatch.run.
It covers opaque and terminal receipts, including rejection and an attached stopped cache.

PrefixAncestry.of_prefix retains the exact requested original explicit input order through
memos, then original Total and actual PrefixValid. It applies prefix_recursion_ancestry and
actual prefix_no_ordinary. It derives the candidate extension from function equality, and
uses the actual no-ordinary observation for the otherwise nonvacuous ordinary clause.
No future cache or preservation supplier is assumed.

OutcomeDiagnosticAncestry.of_finished is a small exact fold bridge. It takes original,
uv, actual Fold result, and the stopped match property FailureAncestry original
(.alternatives uv processed current). It proves the diagnostic predicate for finish uv result.
A complete fold needs True. The actual processed/current fields remain unchanged.

All twelve complete definition bodies/theorem signatures are preserved individually in public/.
public/context.lean.txt retains the imports, aliases and implicit variables. The three runtime
observers use the existing DecidableEq instances; the predicates and transport do not.

## Root compiler feedback at this freeze

The author did not run Lean, lake, a compiler or an evaluator.

Root reported that the exact four draft definitions pass strict checking. The full author v1
then failed in FailureAncestry.mono: unfolding the nested alternatives equation made no
progress while its Stop constructor was unknown. Root preserved v1 and tried v2 without
that simp. v2 could not construct the conjunction before the Stop constructor was exposed.
Root v3 splits the actual current Stop and optional edge receipt before constructing the
conjunctions. Its recursive call and sizeOf measure remain. Root reported v3 compiling.
No predicate or public statement changed in those repairs.

The frozen author candidate remains byte-identical. The installed root observation and its
exact proof delta are preserved separately when present. That copy is not independent build
evidence, and this report does not claim the full module passes. Root owns final build status.

## Scope

The predicate compares per-slot recursionAncestry at the same raw Nat slots. It includes stale
slots beyond the counter. It does not assert expansionAncestry equality, native endpoint heap
facts, index equality, model preservation, sufficient recursive depth or global termination.
Native Caller/Queries fields stay bound to the actual observations but are not enumeration
cache attachments. Raw successful Core rows are deliberately a separate scope.

No future-action invariant, generic hook supplier, Complete contract, axiom, sorry, admit,
native_decide, budget increase or linter suppression was added. No repository, Git, evaluator,
network, board or Haskell change ran. All writes are in the owned new base directory.

manifest.json preserves original candidate/draft identities, complete input snapshots, exact
reviewed cuts, public interfaces and the root repair observation. A whole input snapshot does
not claim a whole-file read. Earlier evidence areas remain unchanged.
