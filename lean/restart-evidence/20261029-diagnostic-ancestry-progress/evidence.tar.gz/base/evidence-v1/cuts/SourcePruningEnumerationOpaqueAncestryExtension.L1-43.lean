import MicroCFTA.SourcePruningEnumerationSelectedOpaqueDispatch
import MicroCFTA.SourcePruningEnumerationChildAncestryExtension
import MicroCFTA.SourcePruningEnumerationAncestryExtensionOwn

/-!
# Retained ancestry at actual opaque and terminal receipts

Each actual attached child cache retains every original slot key.
Successful captured finalization clears the active expansion history.
Stopped receipts keep their actual child cache and expansion history.
-/
namespace MicroCFTA.SourcePruningEnumerationSelectedOpaqueDispatch
open EnumerationState SourcePruningEnumerationAncestryExtension InternedConstructorTemplates
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Result" => SourcePruningEnumerationSelectedEdge.Result
variable {width : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Every actual opaque receipt extends its own input histories at each attached cache. -/
theorem observed_cache_ancestry_extension
    {checkEmpty : Bool} {r n p h k target : Nat} {scs : List Suspended} {value : Node}
    {caller : Caller width} {before : Cached} {queries : Queries} {result : Result width}
    (observed : run checkEmpty r n p h k target scs value caller before queries = some result) :
    match (generalizing := false) result with
    | .complete _ _ _ after => Extends before.core after.core ∧ after.core.expansionAncestry = []
    | .rejected _ _ after | .stopped _ _ (some after) =>
        Extends before.core after.core ∧ after.core.expansionAncestry = before.core.expansionAncestry
    | _ => True := by
  let originalValue := value
  cases value
  case empty =>
    simp only [run, ↓reduceIte] at observed
    cases observed
    exact ⟨Extends.refl before.core, rfl⟩
  case' reference =>
    simp only [run, reduceCtorEq, Bool.false_eq_true, ↓reduceIte] at observed
  case' mu =>
    simp only [run, reduceCtorEq, Bool.false_eq_true, ↓reduceIte] at observed
