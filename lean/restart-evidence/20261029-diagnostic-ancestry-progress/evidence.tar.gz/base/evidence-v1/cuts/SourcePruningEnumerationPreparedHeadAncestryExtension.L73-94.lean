local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Result" => SourcePruningEnumerationSelectedEdge.Result
variable {width : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Actual captured finalization extends every slot and clears only the active history. -/
theorem observed_cache_ancestry_extension
    {checkEmpty : Bool} {r n p h k target : Nat} {scs : List Suspended}
    {edge : EdgeValue Symbol Constraint} {caller : Caller width} {before : Cached} {queries : Queries}
    {result : Result width}
    (observed : run checkEmpty r n p h k target scs edge caller before queries = some result) :
    match (generalizing := false) result with
    | .complete _ _ _ after => Extends before.core after.core ∧ after.core.expansionAncestry = []
    | .rejected _ _ after | .stopped _ _ (some after) =>
        Extends before.core after.core ∧ after.core.expansionAncestry = before.core.expansionAncestry
    | _ => True := by
  unfold run at observed
  cases selected : SourcePruningEnumerationSelectedEdge.run checkEmpty r n p h k scs edge caller before queries with
  | unhandled | rejected =>
