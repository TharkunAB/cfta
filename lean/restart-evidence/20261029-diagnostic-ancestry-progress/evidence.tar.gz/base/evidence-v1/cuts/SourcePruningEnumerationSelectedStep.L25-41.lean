/-- Retain the actual observations of a selected source step without asserting recursive completion. -/
inductive Result (width : Nat) (Typing : Type) where
  /-- Entry or recursion checking does not supply the supported pending singleton. -/
  | stopped (read : ReadRaw) (checked : Option CheckRaw)
  /-- Repeated recursion retains its checked core and optional indexed restart observation. -/
  | parked (checked : Core) (candidate : Option Cached)
      (raw : Option (List (Except EnumerationState.Error ((Metadata Typing × Option Next) × Core))))
  /-- Narrowing retains its actual caller, action and each reached continuation stage. -/
  | narrowed (checked : Core) (prepared : Prepared) (caller : Caller width) (queries : Queries)
      (action : Option ActionRaw) (candidate : Option Cached)
      (right : Option (List (Except EnumerationState.Error ((Bool × Metadata Typing) × Core))))
      (ordinary : Option (OrdinaryRaw × Option (SourcePruningEnumerationNativeBranches.Result width)))

variable {Typing Key : Type} {width : Nat}
section Prefix
variable [DecidableEq (EdgeKey Symbol Constraint)]

