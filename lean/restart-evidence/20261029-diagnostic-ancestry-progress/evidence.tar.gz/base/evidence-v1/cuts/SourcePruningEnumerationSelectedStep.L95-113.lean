
/-- Every prefix observation leaves the ordinary continuation unexecuted. -/
theorem prefix_no_ordinary
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing)
    (readFuel checkFuel nativeFuel representativeFuel indexFuel callbackFuel uv : Nat)
    (caller : Caller width) (before : Cached) (queries : Queries) :
    match runPrefix holeKey fits admits graph templates stop order metadata readFuel checkFuel nativeFuel
      representativeFuel indexFuel callbackFuel uv caller before queries with
    | .narrowed _ _ _ _ _ _ _ ordinary => ordinary = none
    | _ => True := by
  unfold runPrefix
  dsimp only
  generalize ExceptT.run (getValue readFuel uv before.core) = read
  cases read with
  | nil => trivial
  | cons first rest =>
