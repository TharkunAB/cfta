import MicroCFTA.InternedStoredSubstitution
import MicroCFTA.InternedFreshOrdinaryActiveOrigins
import MicroCFTA.InternedFreshOrdinaryStoredSubstitution

/-!
# Binder depth in the actual stored substitution plan

Closed records become constant input slots. Only open stored Mu records
emit binder instructions. The executable record measure below is exactly
the maximum binder nesting in that prepared source plan. This theorem does
not assert a decrease during unfolding or finite cold-reader termination.
-/
namespace MicroCFTA.InternedStoredPlanBinderDepth
open InternedConstructorTemplates InternedStoredSubstitution
open InternedNestedConstruction (Syntax EdgeSyntax)
open InternedStoredShallowCompletion (BinderFree ManyBinderFree EdgesBinderFree)
open InternedBinderProtocol (Reference)

mutual
/-- Count maximum binder nesting in one source constructor plan. -/
def syntaxDepth : Syntax Symbol Guard → Nat
  | .empty | .var _ => 0
  | .node edges => syntaxEdgesDepth edges
  | .union members => syntaxManyDepth members
  | .binder _ body => 1 + syntaxDepth body
termination_by expression => sizeOf expression

/-- Ordered source child plans contribute their maximum binder depth. -/
def syntaxManyDepth : List (Syntax Symbol Guard) → Nat
  | [] => 0
  | first :: rest => max (syntaxDepth first) (syntaxManyDepth rest)
termination_by expressions => sizeOf expressions

/-- Edge labels do not change the maximum binder nesting of their children. -/
def syntaxEdgesDepth : List (EdgeSyntax Symbol Guard) → Nat
  | [] => 0
  | .mk _ _ children :: rest => max (syntaxManyDepth children) (syntaxEdgesDepth rest)
termination_by expressions => sizeOf expressions
end

mutual
/-- Count open stored binders while treating closed captured records as constants. -/
def valueDepth (value : Value Symbol Guard) : Nat :=
  if value.free.isEmpty then 0 else
  match value with
  | .empty | .reference _ => 0
  | .node _ edges .. => edgesDepth edges
  | .union _ members .. => manyDepth members
  | .mu _ body .. => 1 + valueDepth body
termination_by sizeOf value

/-- Original ordered value lists contribute their maximum open binder depth. -/
def manyDepth : List (Value Symbol Guard) → Nat
  | [] => 0
  | first :: rest => max (valueDepth first) (manyDepth rest)
termination_by values => sizeOf values

/-- Actual edge children determine the open binder depth of their stored plan. -/
def edgesDepth : List (EdgeValue Symbol Guard) → Nat
  | [] => 0
  | .mk _ children :: rest => max (manyDepth children) (edgesDepth rest)
termination_by edges => sizeOf edges
end

/-- Measure the actual body plan that one outer Mu unfolding executes. -/
def bodyDepth : Value Symbol Guard → Nat
  | .mu _ body .. => valueDepth body
  | _ => 0

mutual
/-- The actual stored compiler emits exactly the binder nesting counted from its original record. -/
theorem encode_depth (context : List (Value Symbol Guard)) (locals : List Reference) (value : Value Symbol Guard) :
    syntaxDepth (encode context locals value) = valueDepth value := by
  rw [encode.eq_def, valueDepth.eq_def]
  split
  · rw [syntaxDepth]
  · cases value with
    | empty => rw [syntaxDepth]
    | reference name =>
        dsimp only
        split <;> rw [syntaxDepth]
    | node entry edges depth free => rw [syntaxDepth]; exact encodeEdges_depth context locals edges
    | union entry members depth free => rw [syntaxDepth]; exact encodeMany_depth context locals members
    | mu entry body depth ordinary =>
        rw [syntaxDepth, encode_depth context (.interned entry.identity :: locals) body]
termination_by sizeOf value

/-- The compiler retains the maximum binder depth of the exact ordered original members. -/
theorem encodeMany_depth (context : List (Value Symbol Guard)) (locals : List Reference) (values : List (Value Symbol Guard)) :
    syntaxManyDepth (encodeMany context locals values) = manyDepth values := by
  cases values with
  | nil => rw [encodeMany, syntaxManyDepth, manyDepth]
  | cons first rest =>
      rw [encodeMany, syntaxManyDepth, manyDepth, encode_depth context locals first, encodeMany_depth context locals rest]
termination_by sizeOf values

/-- The compiler retains binder nesting through every actual edge and child position. -/
theorem encodeEdges_depth (context : List (Value Symbol Guard)) (locals : List Reference) (edges : List (EdgeValue Symbol Guard)) :
    syntaxEdgesDepth (encodeEdges context locals edges) = edgesDepth edges := by
  cases edges with
  | nil => rw [encodeEdges, syntaxEdgesDepth, edgesDepth]
  | cons first rest =>
      cases first with
      | mk entry children =>
          rw [encodeEdges, syntaxEdgesDepth, edgesDepth, encodeMany_depth context locals children,
            encodeEdges_depth context locals rest]
termination_by sizeOf edges
end

/-- Closed captured records emit no binder instruction and have measure zero. -/
