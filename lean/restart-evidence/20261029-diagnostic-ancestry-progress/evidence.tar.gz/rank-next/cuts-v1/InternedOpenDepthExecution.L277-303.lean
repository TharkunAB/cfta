theorem build_bound [DecidableEq (EdgeKey Symbol Guard)] (expression : Syntax Symbol Guard)
    (environment : List (Value Symbol Guard)) (state : State Symbol Guard) (context : Context state environment)
    (cached : InternedFreshOrdinaryDepthHeap.Heap state) (heap : Heap state)
    (bound : Nat) (inputs : ∀ value ∈ environment, valueDepth value ≤ bound)
    (value : Value Symbol Guard) (after : State Symbol Guard)
    (done : build expression environment state = .done value after) :
    valueDepth value ≤ syntaxDepth expression + bound := by
  rw [(build_depth expression environment state context cached heap).result value after done]
  apply InternedOpenDepthSemantics.evaluate_bound
  intro depth member
  obtain ⟨value, included, rfl⟩ := List.mem_map.mp member
  exact inputs value included

/-- Actual completed normalized callbacks retain the source-body and lexical-input open-depth bound. -/
theorem callback_bound [DecidableEq (EdgeKey Symbol Guard)] (body : Syntax Symbol Guard)
    (environment : List (Value Symbol Guard)) (argument : Reference) (state : State Symbol Guard)
    (context : Context state environment) (available : Available state (.reference argument))
    (cached : InternedFreshOrdinaryDepthHeap.Heap state) (heap : Heap state)
    (bound : Nat) (inputs : ∀ value ∈ environment, valueDepth value ≤ bound)
    (value : Value Symbol Guard) (after : State Symbol Guard)
    (done : callback body environment argument state = .done value after) :
    valueDepth value ≤ syntaxDepth body + bound := by
  rw [(callback_depth body environment argument state context available cached heap).result value after done]
  apply InternedOpenDepthSemantics.evaluate_bound
  intro depth member
  rcases List.mem_cons.mp member with rfl | included
  · exact Nat.zero_le _
