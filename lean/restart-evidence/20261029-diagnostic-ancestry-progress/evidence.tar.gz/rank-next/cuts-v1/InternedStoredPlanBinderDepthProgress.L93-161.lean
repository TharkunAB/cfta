      have depthOpen := InternedOpenDepthExecution.callback_depth body environment .depth state context (depth_available state) cached heap
      rw [build]
      change Lower initial bound ((callback body environment .depth state).bind fun depth afterDepth =>
        (callback body environment (.uninterned (ordinaryLevel depth)) afterDepth).bind fun ordinary afterOrdinary =>
          request smart depth ordinary (callback body environment) afterOrdinary).state
      apply bind_lower _ _ (checked .depth state context (depth_available state) cached heap lower)
      intro depth afterDepth depthDone depthLower
      have depthContext : Context afterDepth environment := by
        simpa only [depthDone, Outcome.state] using context.callback body .depth (depth_available state)
      have depthCached : InternedFreshOrdinaryDepthHeap.Heap afterDepth := by simpa only [depthDone, Outcome.state] using depthOld.heap
      have depthHeap : InternedOpenDepthReadback.Heap afterDepth := by simpa only [depthDone, Outcome.state] using depthOpen.heap
      have ordinaryOld := InternedRecordDepthExecution.callback_depth body environment (.uninterned (ordinaryLevel depth))
        afterDepth depthContext (ordinary_available afterDepth _) depthCached
      have ordinaryOpen := InternedOpenDepthExecution.callback_depth body environment (.uninterned (ordinaryLevel depth))
        afterDepth depthContext (ordinary_available afterDepth _) depthCached depthHeap
      apply bind_lower _ _ (checked (.uninterned (ordinaryLevel depth)) afterDepth depthContext
        (ordinary_available afterDepth _) depthCached depthHeap depthLower)
      intro ordinary afterOrdinary ordinaryDone ordinaryLower
      have finalContext : Context afterOrdinary environment := by
        simpa only [ordinaryDone, Outcome.state] using depthContext.callback body (.uninterned (ordinaryLevel depth)) (ordinary_available afterDepth _)
      have finalCached : InternedFreshOrdinaryDepthHeap.Heap afterOrdinary := by simpa only [ordinaryDone, Outcome.state] using ordinaryOld.heap
      have finalHeap : InternedOpenDepthReadback.Heap afterOrdinary := by simpa only [ordinaryDone, Outcome.state] using ordinaryOpen.heap
      cases installed : afterOrdinary.nodes.table (muKey depth ordinary) with
      | some entry =>
          cases present : afterOrdinary.nodeRecords (muKey depth ordinary) <;>
            simpa only [request, installed, present, Outcome.state] using ordinaryLower
      | none =>
          let key := muKey depth ordinary
          let entry := Cache.intern afterOrdinary.nodes key
          let allocated := {afterOrdinary with nodes := entry.2}
          have reserved : Context allocated environment := finalContext.reserve key
          have argument : Available allocated (.reference (.interned entry.1.identity)) :=
            (InternedConstructionProvenance.reserve_available key afterOrdinary finalContext.normal.facts.coherent finalContext.normal.facts.cached).2
          have allocatedCached : InternedFreshOrdinaryDepthHeap.Heap allocated := finalCached
          have allocatedHeap : InternedOpenDepthReadback.Heap allocated := finalHeap
          have allocatedLower : Lower initial bound allocated := ordinaryLower
          simp only [request, installed]
          change Lower initial bound ((callback body environment (.interned entry.1.identity) allocated).bind
            (fun value after => complete smart entry.1 value depth ordinary after)).state
          apply bind_lower _ _ (checked (.interned entry.1.identity) allocated reserved argument
            allocatedCached allocatedHeap allocatedLower)
          intro actual afterBody actualDone afterLower
          have upper := InternedOpenDepthExecution.callback_bound body environment (.interned entry.1.identity)
            allocated reserved argument allocatedCached allocatedHeap 0 (fun value member => Nat.le_of_eq (zeros value member))
            actual afterBody actualDone
          exact complete_lower smart entry.1 actual depth ordinary afterBody afterLower (by omega)
termination_by sizeOf expression

/-- Ordered child plans retain the same enclosing allocation bound. -/
theorem buildMany_lower [DecidableEq (EdgeKey Symbol Guard)] (expressions : List (Syntax Symbol Guard))
    (environment : List (Value Symbol Guard)) (state : State Symbol Guard) (context : Context state environment)
    (cached : InternedFreshOrdinaryDepthHeap.Heap state) (heap : InternedOpenDepthReadback.Heap state)
    (lower : Lower initial bound state) (zeros : ∀ value ∈ environment, valueDepth value = 0)
    (limited : syntaxManyDepth expressions ≤ bound) : Lower initial bound (buildMany expressions environment state).state := by
  cases expressions with
  | nil => simpa only [buildMany, Outcome.state] using lower
  | cons first rest =>
      have bounds : syntaxDepth first ≤ bound ∧ syntaxManyDepth rest ≤ bound := by
        simpa only [syntaxManyDepth, Nat.max_le] using limited
      have old := InternedRecordDepthExecution.build_depth first environment state context cached
      have opened := InternedOpenDepthExecution.build_depth first environment state context cached heap
      rw [buildMany]
      apply bind_lower _ _ (build_lower first environment state context cached heap lower zeros bounds.1)
      intro value after returned afterLower
      have afterContext : Context after environment := by simpa only [returned, Outcome.state] using context.build first
      have afterCached : InternedFreshOrdinaryDepthHeap.Heap after := by simpa only [returned, Outcome.state] using old.heap
      have afterHeap : InternedOpenDepthReadback.Heap after := by simpa only [returned, Outcome.state] using opened.heap
      exact bind_lower _ _ (buildMany_lower rest environment after afterContext afterCached afterHeap afterLower zeros bounds.2)
        (fun _ _ _ laterLower => laterLower)
