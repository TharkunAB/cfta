          have afterHeap : InternedOpenDepthReadback.Heap after := by simpa only [returned, Outcome.state] using opened.heap
          have available := verified.result values after returned
          let actual := run (makeEdge symbol constraint values) after
          have edgeContext : Context actual.2 environment := afterContext.edge symbol constraint values available
          change Lower initial bound ((buildEdges rest environment actual.2).bind _).state
          exact bind_lower _ _ (buildEdges_lower rest environment actual.2 edgeContext afterCached afterHeap afterLower zeros bounds.2)
            (fun _ _ _ laterLower => laterLower)
termination_by sizeOf expressions
end

/-- Actual zero-depth lexical inputs derive lower depth for every newly completed Mu in the full final cache. -/
theorem build_new_lower [DecidableEq (EdgeKey Symbol Guard)] (expression : Syntax Symbol Guard)
    (environment : List (Value Symbol Guard)) (state : State Symbol Guard) (context : Context state environment)
    (cached : InternedFreshOrdinaryDepthHeap.Heap state) (heap : InternedOpenDepthReadback.Heap state)
    (zeros : ∀ value ∈ environment, valueDepth value = 0) :
    Lower state (syntaxDepth expression) (build expression environment state).state :=
  build_lower expression environment state context cached heap (lower_refl state _) zeros (Nat.le_refl _)

/-- Actual stored lexical inputs retain the full source context of their available records. -/
theorem stored_context (value : Value Symbol Guard)
    (environment : InternedStoredSubstitution.Environment Symbol Guard) (state : State Symbol Guard)
    (context : Context state []) (available : Available state value)
    (replacements : InternedStoredSubstitution.Replacements state environment) :
    Context state ((InternedStoredSubstitution.leaves value).map (InternedStoredSubstitution.input environment)) :=
  ⟨context.normal, InternedStoredSubstitution.inputs_available value environment state available replacements,
    context.profiles, context.freeNames⟩

/-- Actual repaired stored substitution preserves the proved body/probe open-depth heap. -/
theorem execute_heap [DecidableEq (EdgeKey Symbol Guard)] (value : Value Symbol Guard)
