# Main remaining original-input rank gap

Date: 2026-10-29 Europe/Stockholm. Status: bounded SOURCE-ONLY audit.
No new theorem or executable counterexample was produced. No compiler,
evaluator, native operation, repository write, Git, network or board call ran.

## Current conclusion

The SAME startup Mu body-degree ceiling is still not derived at generated
optionalBinder bodies. No admitted source counterexample to that ceiling was
established. Existing Bounded/Available/origin gates do not directly entail
the missing strict inequality. The exact current definitions explain the gap.
This is a missing native result-degree proof, not an ancestry-retention gap.

The parent clarified that "MuClosure audit" names the prior mu-query REPORT
informally. There is no missing current declaration called MuClosure. That
complete frozen audit was read without modification and compared with the
current sources. The two earlier negative witnesses retain their exact scope.

## Original syntax versus actual generated syntax

Compile.compileMu enters the original pair's domain and calls a node request
on body left and body right. Its continuation feeds the ACTUAL RETURNED value
to optionalBinder. The returned body is not identified with an original operand
body. Native.step evaluates maybeMu on exactly that generated body and either
yields the returned value/cache or records a constructor block.

Bounded source limit constrains EVERY resident Mu's BODY valueDepth. It does
not assert an inequality for a later generated node-request return value.
valueDepth treats closed values as zero. An OPEN resident Mu has whole-value
degree one plus its body's degree. Consequently even a bound obtained from
an arbitrary available open resident Mu is non-strict at limit. Available is
residency/provenance; it does not remove this extra binder level. Root closedness
is not callback-body closedness: the actual binder body must retain the pair
reference before optionalBinder can bind it. Original marks the original input
codec syntax; it does not identify generated continuation results with input
subtrees. AssignmentOrigins concerns term paths, not native binder-plan syntax.

## What the existing proofs already supply

- maybeMu_eq compiles the complete native optional binder to the repaired source
  plan binder(true, encode(leaves body,[pair],body)). The pending branch and
  actual physical probes are retained.
- encode_depth equates that encoded body-plan degree with valueDepth body.
  build_new_lower bounds every newly completed resident Mu, including records
  produced by probes, below one plus that generated degree. Existing callback_bound
  and build_bound also bound the returned constructed value by its actual plan
  and lexical-input degree. These are constructive local facts, not an original
  bound on the newly returned body from a recursive node request.
- initial_complete ALREADY derives successful semantic root completion from
  original Facts, Original, Available and closed roots. No model or semantic
  completion oracle is needed for THIS original root request.
- mu_request_below then makes the actual original-scope Mu child request's
  required semantic fuel strictly smaller. Canonical domain allocation preserves
  that exact bound.
- CodeBounds.Below does not bound the generated callback value. Node/edge
  continuation clauses quantify arbitrary available/resident returned values
  after source growth. Its optionalBinder case only retains the continuation's
  request limit. The current bound proof can therefore succeed while leaving
  the callback-body degree wholly unspecified.

It would be inaccurate to call semantic Completes an unavoidable new original
input gate: initial_complete discharges it for the cited original closed-root
case. It would also be inaccurate to infer native constructor completion or a
new output-degree bound from that semantic theorem alone.

## One concrete next obligation

NEXT-OBLIGATION-v1.md gives a COMPLETE proposed observed point signature, with
no future-body or future-state bound premise. It targets a ceiling computed from
the ORIGINAL root's resident Mu limit plus its already source-derived semantic
request fuel. This is UNPROVED. The exact coefficient/additive formula remains
an obligation; it is not a claimed theorem or measured numeric bound.

The needed implementation is a joint result-degree induction for actual native
requests, ordered child returns, optionalBinder construction and actual memo
publication/ready readback. It must retain the SAME input/source descriptor and
original request rank through the trace. It must derive reached source heaps
from the actual native operation preservation lemmas. Adding a continuation
argument that assumes each returned body's desired degree would leave the
central obligation untouched. No orphan supplier contract or Lean candidate
was created in this audit.

The proposed first point theorem is for an initially empty native memo state.
Warm-state result-degree provenance and later queries on generated operands
remain additional work. A per-query rank depending on the current generated
input heap is not an original global rank for the complete prepared enumerator.
The stronger startup-only ceiling remains an unproved candidate, not refuted.

## Chosen-model alternative and its limits

A finite chosen-model derivation can avoid counting physical native handles
only if each ACTUAL preceding callback and native operation is covered by that
derivation or by a separate original rank. Current AssignmentOrigins gives
term.height ≤ whole.height, without strict descent. Empty equality classes
explicitly reuse the current term as their fresh witness. This proves that the
existing origins interface does not force a fresh variable to denote a proper
smaller subtree. It is not a new counterexample to admitted runtime termination.

Accepted constructor-child paths can have smaller term height. That fact alone
does not cover earlier ordered alternatives, rejected callbacks or recursion
before the chosen later branch. An accepted later edge cannot be used to ignore
those actual preceding operations. Thus a chosen-model rank is a useful route,
but current Origin/height results alone do not close native body closure or the
whole ordered finite-depth requirement. No model-dependent termination claim
is asserted here.

## Exact negative-witness boundary

The current 212-line OpenBodyBoundary witness has the same complete SHA256
81985a5d4cfaa355c4b81ae3b644fcef36acecc90a08db091d795a54ed970d38.
It constructs closed Original source roots, Facts, Available, complete coverage,
repaired Context, empty native memos and checked 64-bit root words. Its actual
22-step trace reaches an optionalBinder whose body contains an open nested Mu
and fails PreparedWithoutMu. That refutes universal first-order preparation
under those exact gates. It supplies no prepared whole-Packet counterexample.

native_returned proves only returned=some(.mu26), where returned observes the
referenceOf of a completed bounded result at fuel100. It proves neither literal
payload/cache equality nor divergence, and it does not refute the needed body
ceiling. No new evaluation or reduction was run. Earlier ColdUnfold findings
still refute startup-only identity inventories and decreasing cached depth;
they are not repurposed as a counterexample to this different open-body degree.

A degree ceiling also does not count handles. Different canonical Mu keys at
one degree can contain different generated probes; guards can be conjoined and
queries can later use generated operands. Closure of those keys/guards or a
proved alternative rank remains necessary. No global finiteness or sufficient
depth result follows from this audit.

## Evidence and freeze

Seven Lean sources were read WHOLE and retained, below the ten-whole-source
budget. Eight Lean literal cuts and one current-note cut retain the exact
reviewed ranges plus full source hashes. One prior audit REPORT is retained
whole. An early large proof read was truncated; it supports no whole-read claim.
Only its explicit follow-up cuts are listed as reviewed. existing-signatures-v1.json
retains sixteen complete existing theorem headers. Proposed signatures are
marked UNPROVED and are not installed checked exports.

No Haskell source was read for a new defect here. No Haskell defect, repair or
correspondence claim was established. FINDINGS needs no new Haskell-fix entry
from this bounded audit. All inputs and earlier areas remain unchanged. This
rank-next evidence area is frozen after its final identity readback.
