# Next actual native body-bound obligation

Status: PROPOSED, UNPROVED. This is a proof target, not a new assumed contract.
No Lean module or placeholder theorem is supplied.

The fixed startup Mu limit has not been proved closed under native queries.
A more credible first target allows a ceiling computed entirely from the SAME
original heap and its source-derived semantic request fuel. It still supplies
no future body degree as an input. The candidate linear bound below must be
proved; it is not an established estimate or a global enumeration rank.

With the namespaces opened as in the existing CompileMuBounds and
OpenBodyBoundary sources, the exact proposed point statement is:

```lean
-- PROPOSED HEADER ONLY. Not installed and not elaborated.
theorem optionalBinder_body_bound_from_initial_request
    {Symbol Guard : Type} {width : Nat}
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (source : InternedConstructorTemplates.State Symbol Guard)
    (facts : InternedNestedFacts.Facts source)
    (context : InternedFreshOrdinaryContext.Context source [])
    (cached : InternedFreshOrdinaryDepthHeap.Heap source)
    (opened : InternedOpenDepthReadback.Heap source)
    (holds : Guard → Language.Term Symbol → Bool)
    (left right : Value Symbol Guard)
    (leftOriginal : Original left) (rightOriginal : Original right)
    (leftAvailable : Available source left) (rightAvailable : Available source right)
    (leftClosed : left.free = []) (rightClosed : right.free = [])
    (limit : Nat) (bounded : InternedMuDepthInventory.Bounded source limit)
    (words : SourceRecursiveIntersectionMemo.KeySafe width
      IntersectionEmptyDomain.emptyDomain left right)
    (ticks : Nat) (pair : Nat × Nat) (body : Value Symbol Guard)
    (next : Value Symbol Guard → Code Symbol Guard (Value Symbol Guard))
    (reached : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (trace : Steps emptyGuard conjoin ticks
      (.node ⟨IntersectionEmptyDomain.emptyDomain, left, right⟩ .pure)
      (SourceRecursiveIntersectionThunks.initial width ⟨source, Cache.emptyState⟩)
      (.optionalBinder pair body next) reached) :
    let complete := SourceRecursiveIntersectionRequestProgress.initial_complete
      source facts holds left right leftOriginal rightOriginal
      leftAvailable rightAvailable leftClosed rightClosed
    InternedStoredPlanBinderDepth.valueDepth body < limit +
      IntersectSchedule.requiredFuel (view source holds)
        (.node (domain IntersectionEmptyDomain.emptyKey) (inputOf left) (inputOf right)) complete
```

The exact original input format is deliberately a native root call with EMPTY
native thunk/domain memo state, not an arbitrary warm machine. Reached appears
only in the literal actual trace. No reached Bounded, reached body inequality,
future model, future native-handle carrier or future completed result is an input.
Original Context/depth heaps are not claimed to follow from bare Packet here.
The displayed target is limited to calls whose existing Original/source gates
are present. It does not assert those gates for every generated future operand.

A direct proof needs a joint actual node/edge return induction, not another
continuation supplier. First derive depth of an original available operand at
most limit from Facts plus Bounded. Preserve maximum returned degree through
actual ordered rows and union/node work. A completed optionalBinder adds at most
one to its generated body's degree: maybeMu_eq plus build_bound and encode_depth
provide that local calculation from the derived actual source heaps. Couple it
with strict request-fuel descent from mu_request_below and the corresponding
actual row/ordinary request lemmas. Account for actual published/completed memo
entries and ready reads from the initially empty memo history. A mere Valid
memo state gives availability; it does not state this new result-degree fact.

This joint result-degree induction is the missing prerequisite. The current
Below predicate explicitly accepts arbitrary available values in continuations.
It has no output-depth component. Its optionalBinder branch only asks about the
continuation after a successful native result. Therefore compileMu_below cannot
by itself prove the displayed target or the stronger SAME startup limit.

If the derived fuel-dependent bound is proved, it gives one ORIGINAL bound for
ONE root query, regardless of how many physical handles that query creates.
Its fuel is derived by initial_complete, not assumed semantic completion.
Recomputing that bound on a growing heap for later generated queries does not
give a fixed original global bound. Closing that further step requires original
descriptor closure or a different well-founded measure over those later calls.
