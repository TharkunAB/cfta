from pathlib import Path
import hashlib,json,shutil
r=Path('/tmp/mcfta-native-binding-and-constraint-control-20261031');src=Path('/tmp/mcfta-native-binding-public-review-20261031');mh='6393334cf04bbd8ddfca2e8cf0d524c9b163d27b0d3dcb0111322ea70241a471';ph='9ac415b5551709db81d75c7839bd6ca4313bdc1706cd611163744e73444a2483';assert hashlib.sha256((src/'pins.json').read_bytes()).hexdigest()==mh and hashlib.sha256((src/'FROZEN.json').read_bytes()).hexdigest()==ph;rows=json.loads((src/'pins.json').read_text())['payloads'];assert len(rows)==171
for row in rows:
 data=(src/row['path']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
assert {str(x.relative_to(src)) for x in src.rglob('*') if x.is_file()}=={x['path'] for x in rows}|{'pins.json','FROZEN.json'}
for f in src.rglob('*'):
 if f.is_file():assert not f.is_symlink() and not f.stat().st_mode&0o222
owners=json.loads((r/'owners.json').read_text());assert len(owners)==14;dest=r/'public-review';assert not dest.exists();shutil.copytree(src,dest);owners.append({'name':'public-review','original':str(src),'manifest':'pins.json','manifest_sha256':mh,'pins':'FROZEN.json','pins_sha256':ph,'status':'CLEAR; complete current public/source/doc review'});(r/'owners.json').write_text(json.dumps(owners,indent=2)+'\n');(r/'add-peer-owner.py').write_bytes(Path(__file__).read_bytes());print({'owners':len(owners),'peer_regular_files':173,'peer_payloads':171})
