from pathlib import Path
import hashlib,json,shutil
r=Path('/tmp/mcfta-native-binding-and-constraint-control-20261031');owners=json.loads((r/'owners.json').read_text());items=[('incoming-none-draft','/tmp/mcfta-ordinary-incoming-none-review-20261031','0ec47b6e7e89f9cbdcf421f8a0df04afdcd05fe791b8135606966d2b0fb3caad','pins.json','cc3be3cfd5f76ee86db911bf9684c12f3e6421ddaeac4f0eb37ddb7c18a54028'),('incoming-checked-draft','/tmp/mcfta-ordinary-incoming-check-review-20261031','8a7a15b05892aec69d2847c27bd9ba551527b85a59e9dd12b8e998c4fb212828','FROZEN-PINS.txt','c5ea3c28c153505f8aeac49d2b4e880668f5a30db818163aa1eebfaaf5f2c5a3'),('interned-edge-source-draft','/tmp/mcfta-native-canonical-edge-origin-review-20261031','e0a5d056b1f1c602a9f07f49e9329e81e40ac3936361029335a5e095997c16ea','PINS.json','af44cf08885bb02a623704909fc56f850e175c338fc82ab839417e9fad6e3a84')]
for name,source,mhash,pins,phash in items:
 src=Path(source);assert hashlib.sha256((src/'MANIFEST.json').read_bytes()).hexdigest()==mhash;assert hashlib.sha256((src/pins).read_bytes()).hexdigest()==phash;rows=json.loads((src/'MANIFEST.json').read_text())['files'];expected={x['path'] for x in rows};actual={str(x.relative_to(src)) for x in src.rglob('*') if x.is_file()};extras=actual-(expected|{'MANIFEST.json',pins});assert extras<= {'FROZEN'},extras;assert expected|{'MANIFEST.json',pins}|extras==actual
 for row in rows:
  data=(src/row['path']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 for file in src.rglob('*'):
  if file.is_file():assert not file.is_symlink() and not file.stat().st_mode&0o222
 assert name not in [x['name'] for x in owners];dest=r/name;assert not dest.exists();shutil.copytree(src,dest);owner={'name':name,'original':source,'manifest':'MANIFEST.json','manifest_sha256':mhash,'pins':pins,'pins_sha256':phash,'status':'source-only future draft; UNCOMPILED'}
 if extras:owner['extra_metadata']={leaf:{'bytes':(src/leaf).stat().st_size,'sha256':hashlib.sha256((src/leaf).read_bytes()).hexdigest()} for leaf in sorted(extras)}
 owners.append(owner)
(r/'owners.json').write_text(json.dumps(owners,indent=2)+'\n');(r/'add-future-owners.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'owners':len(owners),'new_complete_future_owners':[x[0] for x in items]}))
