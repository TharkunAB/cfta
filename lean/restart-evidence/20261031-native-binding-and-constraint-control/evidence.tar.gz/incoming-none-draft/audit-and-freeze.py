from pathlib import Path
import hashlib,json,re
r=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=json.loads((r/'acquisitions.json').read_text());unions={};errors=[]
for x in a:
 p=Path(x['original_path']);data=p.read_bytes();copy=r/x['copy'];lines=data.decode().splitlines(keepends=True)
 if sha(p)!=x['source_sha256']:errors.append({'kind':'original changed','path':str(p)})
 if sha(copy)!=x['copy_sha256']:errors.append({'kind':'copy changed','path':str(copy)})
 u=unions.setdefault(str(p),{'source_sha256':x['source_sha256'],'source_lines':x['source_lines'],'lines':set()});selected=set(x.get('actual_lines',[]))
 for low,high in x.get('line_ranges',[]):selected.update(range(low,high+1))
 u['lines'].update(selected)
 expected=data if x['kind']=='named whole original'else ''.join(f'{i}:{lines[i-1]}'for i in sorted(selected)).encode()
 if copy.read_bytes()!=expected:errors.append({'kind':'source/copy reconstruction mismatch','path':str(copy)})
for u in unions.values():u['lines']=sorted(u['lines']);u['line_count']=len(u['lines'])
(r/'cumulative-source-unions.json').write_text(json.dumps(unions,indent=2)+'\n');whole=[p for p,u in unions.items()if u['line_count']==u['source_lines']]
expected_whole=['/home/tritlo/Code/mcfta/lean/MicroCFTA/SourcePruningEnumerationIncomingNode.lean','/tmp/mcfta-ordinary-graph-result-review-20261031/SourceCurrentAllocatedFiniteOrdinaryIncomingResult-v2-UNCOMPILED.lean']
if sorted(whole)!=sorted(expected_whole):errors.append({'kind':'whole acquisition mismatch','actual':whole})
provider=Path('/tmp/mcfta-ordinary-graph-result-review-20261031');meta=r/'provider-metadata';meta.mkdir(exist_ok=True);identities=[]
for name in ['MANIFEST.json','pins.json','FROZEN','MANIFEST.sha256','FROZEN-PINS.json','FROZEN-PINS.txt']:
 p=provider/name
 if p.is_file():(meta/name).write_bytes(p.read_bytes());identities.append({'name':name,'sha256':sha(p),'bytes':p.stat().st_size})
verified=[]
if (provider/'MANIFEST.json').is_file():
 manifest=json.loads((provider/'MANIFEST.json').read_text());entries=manifest.get('files',[])
 for entry in entries:
  p=provider/entry['path'];ok=p.is_file()and sha(p)==entry['sha256']and p.stat().st_size==entry['bytes'];verified.append({'path':str(p),'sha256':entry['sha256'],'bytes':entry['bytes'],'verified':ok})
  if not ok:errors.append({'kind':'provider payload mismatch','path':str(p)})
(r/'provider-closure-check.json').write_text(json.dumps({'original_owner':str(provider),'source_is_exact_named_supplied_snapshot':True,'source_sha256':'3912d9d66cad22b1f63e37be6501e9e9008bccd683ff1a22957f124b8c7e9715','imported':False,'identity_metadata':identities,'verified_payloads':verified},indent=2)+'\n')
candidate=r/'SourceCurrentAllocatedFiniteOrdinaryIncomingNone-v2-UNCOMPILED.lean';text=candidate.read_text();old=(r/'SourceCurrentAllocatedFiniteOrdinaryIncomingNone-v1-UNCOMPILED.lean').read_text();revision={'status':'source comparison only','only_change':text==old.replace('SourcePruningEnumerationWrites.available_readback','SourcePruningEnumerationNodes.available_readback'),'change':'correct available_readback qualifier from Writes to Nodes'}
(r/'SOURCE-REVISION.json').write_text(json.dumps(revision,indent=2)+'\n')
if not revision['only_change']:errors.append({'kind':'revision mismatch'})
start=text.index('theorem none_result');stop=text.index(':= by',start);(r/'PUBLIC-CONTRACT.md').write_text('# Actual None-branch public contract\n\nUNCOMPILED. Namespace: `MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryIncomingNone`. The aliases and native Stored are the original production types.\n\n```lean\n'+text[start:stop].rstrip()+'\n```\n\nThe outer result retains readState. The empty stream has no returned Core. The after state is always the actual write-prefix state and is returned only in the non-Empty branch.\n')
(r/'SOURCE-AUDIT.json').write_text(json.dumps({'status':'source/provenance only','old_whole_sources':whole,'maximum_old_wholes':2,'old_wholes_used':len(whole),'acquisition_records':len(a),'errors':errors},indent=2)+'\n')
if errors:raise SystemExit(json.dumps(errors))
(r/'STATE.md').write_text('FROZEN SOURCE-ONLY. V2 is 92 lines and uncompiled. It derives actual encoding/physical readback and representative-slot write for the literal IncomingNode.run None branch. Native Stored/current incoming Node and height cap remain explicit. All native fuels and checkEmpty are arbitrary. Actual find success and None-slot gates remain. Empty has only write-prefix after and returns no Core. Root alone checks, repairs, installs, packages and publishes. Global worker/Haskell goals remain open.\n')
(r/'INCIDENTS.md').write_text('V1 used the wrong available_readback namespace. Bounded declaration locators establish Nodes as the actual owner. V2 changes that qualifier only. Both drafts remain uncompiled. Negative declaration searches are retained. No failed read, tool failure, runtime result, or observed compiler error occurred.\n')
excluded={'MANIFEST.json','pins.json','FROZEN'};files=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(r.rglob('*'))if p.is_file()and str(p.relative_to(r))not in excluded]
(r/'MANIFEST.json').write_text(json.dumps({'kind':'complete immutable source-only ordinary incoming None owner','status':'UNCOMPILED','files':files},indent=2)+'\n')
pins={'owner':str(r),'status':'UNCOMPILED','candidate':candidate.name,'candidate_lines':len(text.splitlines()),'candidate_sha256':sha(candidate),'manifest_sha256':sha(r/'MANIFEST.json'),'report_sha256':sha(r/'REPORT.md'),'public_contract_sha256':sha(r/'PUBLIC-CONTRACT.md'),'old_whole_sources':{p:unions[p]['source_sha256']for p in whole}}
(r/'pins.json').write_text(json.dumps(pins,indent=2)+'\n');(r/'FROZEN').write_text('Complete source-only evidence. No compiler/evaluator was run. Every acquired source, version, cut, locator, and metadata record is retained.\n')
for entry in files:
 p=r/entry['path']
 if sha(p)!=entry['sha256']:raise SystemExit('post-manifest mismatch '+str(p))
result={'candidate_lines':len(text.splitlines()),'candidate_sha256':sha(candidate),'manifest_sha256':sha(r/'MANIFEST.json'),'pins_sha256':sha(r/'pins.json'),'report_sha256':sha(r/'REPORT.md'),'public_contract_sha256':sha(r/'PUBLIC-CONTRACT.md'),'payload_files':len(files),'total_files':len(files)+3,'old_wholes_used':len(whole),'provider_identity_files':len(identities),'provider_payloads_verified':len(verified),'status':'UNCOMPILED FROZEN'}
for p in r.rglob('*'):
 if p.is_file():p.chmod(0o444)
for p in sorted([p for p in r.rglob('*')if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
r.chmod(0o555);print(json.dumps(result,indent=2))
