# Actual ordinary incoming value in the None slot branch

Status: SOURCE-ONLY. Proposed V2 is 92 lines and UNCOMPILED. No compiler, evaluator, Haskell/native execution, Git, network, board, production edit, or delegation was used.

## Result

The candidate module is `MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryIncomingNone`. Its single theorem is `none_result`.

The theorem uses the original current caller Ready predicate, incoming Available and closed gates, actual successful UnionFind.findRoot observation, and actual None pending-slot lookup. The target is `found.representative`. The theorem does not identify that representative with uv.

The incoming value has the supplied current ordinary Node domain and structural height at most the current common cap. The current native Stored gate is `SourceCurrentAllocatedFiniteOrdinaryStored.Stored beforeCaller.checked.native`. No Room, Fits, target Receipt, future Trace, result, completion certificate, old physical node lookup, or new guard gate is added.

The theorem derives an actual encoded handle and exact physical incoming readback. It derives the successful setValue/inheritAncestry write prefix, the exact written state record, and the target slot lookup. It derives the exact literal run result and native Stored on that result's actual caller.

The actual output caller and query memos remain equal to their inputs. The native heap therefore remains the same heap used by physical readback. The incoming Node and height cap apply to the exact value referenced by the written handle.

## Actual endpoints and Empty rejection

The outer fourth component of IncomingNode.run is the reached read state: before with representatives replaced by found.forest. It is not the written Core. The candidate retains this distinction in the exact result equation.

The run result stream is exactly `.ok (some (if incoming = .empty then [] else [.ok ((), after)]))`. For a non-Empty constructor, after is the actual returned Core and its representative slot contains the derived handle. For the Empty constructor, no Core row returns. The existential after is then only the state of the successful write prefix. The separate prefix equation makes that meaning explicit. It is not a future result supplied by the caller.

Empty here means the literal `.empty` constructor. No semantic emptiness classification is added. The None branch does not execute the optional emptiness worker, including when checkEmpty is true.

## Fuels and excluded failures

The theorem accepts arbitrary supplied nativeFuel, p, h, and checkEmpty. The actual None branch does not use them. Representative fuel is arbitrary subject to its actual successful find observation. The theorem does not claim success at fuel values for which findRoot returns none.

The pinned literal run source reports representativeFuel error when findRoot returns none, invalidSlot for an absent representative slot, and invalidIntersection for a nonpending value. Those branches do not meet the actual successful find/None-slot premises. An encodeNode failure would produce `.ok none`; Ready, Available, and closed derive readback and exclude that case here.

## Proof

The existing SourcePruningEnumerationNodes.available_readback law derives encoding and physical lookup from current Ready coherence, Available, and closed. The actual slot lookup derives representative-slot bounds. The proof defines read and after by the literal source records. It follows the checked finish implementation by cases on the incoming constructor. The write prefix is definitional. The actual run equation follows the observed find and slot branches and derived encoding. The slot result follows the standard set-self lookup. Native Stored follows by the exact unchanged caller.

No PendingRealized or StorageValid theorem is added. All old slot values are retained by the explicit set record. This local producer does not by itself prove Packet preservation or a whole-worker common-cap invariant.

## Scope

This is a local native None-branch producer. The stateful Some/Some intersection branch is separate. The uncompiled Some/Some draft was read for API alignment and is not imported by this candidate. No generic pure Graph.intersect behavior is substituted.

No sufficient original worker depth, whole-execution capacity, global ordered prefix, captured sibling restoration, source-reset control, or Haskell correspondence follows. No Haskell defect or fix was established. There is no FINDINGS item.

## Provenance and attempts

The two OLD whole paths were named before acquisition: current SourcePruningEnumerationIncomingNode.lean (296 lines), and the exact supplied 120-line Some/Some V2 at its original private path. SourceSizedPrefixKnownOrdinary.lean was only a five-line definition cut. All other observations are retained named header/body cuts or declaration locators. Cumulative unions use ORIGINAL paths. No third whole or near-whole source was acquired.

The private Some/Some source is SHA3912d9d66cad22b1f63e37be6501e9e9008bccd683ff1a22957f124b8c7e9715. Its exact original source and retained copy remain available. Any available owner identity metadata is retained separately. The candidate imports production IncomingNode and FiniteOrdinaryStored only.

V1 is retained. Static declaration lookup showed that available_readback belongs to SourcePruningEnumerationNodes, not SourcePruningEnumerationWrites. V2 changes that one qualifier. No statement or other proof change occurred. No compiler error was observed. Root must kernel-check the exact frozen V2.

Root separately reported full current constraint-filter129 and startup54 default/strict success. Those are Root checks of other modules. This None producer remains uncompiled.
