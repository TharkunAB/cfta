# Actual None-branch public contract

UNCOMPILED. Namespace: `MicroCFTA.SourceCurrentAllocatedFiniteOrdinaryIncomingNone`. The aliases and native Stored are the original production types.

```lean
theorem none_result (heightBound : Nat) (checkEmpty : Bool)
    (r n p h uv : Nat) (found : UnionFind.Result)
    (beforeCaller : Caller width) (before : EnumerationState.State Symbol EnumGuard) (incoming : Node)
    (incomingScs oldScs : List EnumerationState.Suspended) (queries : Queries)
    (ready : SourceCurrentConjunctionClassScan.Ready beforeCaller.checked)
    (available : Available beforeCaller.checked.native.machine.heap incoming) (closed : incoming.free = [])
    (domain : NodeDomain incoming) (height : MergedOrdinaryHeight.height incoming ≤ heightBound)
    (stored : Stored beforeCaller.checked.native)
    (reading : UnionFind.findRoot r before.representatives uv = some found)
    (slot : before.values[found.representative]? = some (.unenumerated none oldScs)) :
    ∃ handle (after : EnumerationState.State Symbol EnumGuard),
      SourcePruningEnumerationNodes.encodeNode incoming = some handle ∧
      SourcePruningEnumerationNodes.lookupNode beforeCaller.checked.native.machine.heap handle = some incoming ∧
      NodeDomain incoming ∧ MergedOrdinaryHeight.height incoming ≤ heightBound ∧
      let read : EnumerationState.State Symbol EnumGuard := {before with representatives := found.forest}
      ExceptT.run ((do
        setValue found.representative (.unenumerated (some handle) (incomingScs ++ oldScs))
        inheritAncestry found.representative) read) = [.ok ((), after)] ∧
      SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
          beforeCaller before uv incoming incomingScs queries =
        (.ok (some (if incoming = .empty then [] else [.ok ((), after)])), beforeCaller, queries, read) ∧
      after = {read with
        values := read.values.set found.representative (.unenumerated (some handle) (incomingScs ++ oldScs))
        recursionAncestry := fun other => if other = found.representative then
          (read.expansionAncestry ++ read.recursionAncestry found.representative).eraseDups
          else read.recursionAncestry other} ∧
      after.values[found.representative]? = some (.unenumerated (some handle) (incomingScs ++ oldScs)) ∧
      Stored (SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
        beforeCaller before uv incoming incomingScs queries).2.1.checked.native
```

The outer result retains readState. The empty stream has no returned Core. The after state is always the actual write-prefix state and is returned only in the non-Empty branch.
