## Remaining full proof

The full returned-law history from literal empty memo tables remains open.
The source audit still requires closed requests at empty domains OR domains
with nonempty free maps, plus exact OPEN node/edge auxiliary clauses in the
SAME existing Returned law. Empty-domain A plus mixed M alone is not closed
under actual helper calls. Do not broaden the closed clause to every raw
valid domain. A ready hit can bypass reset. Exact row and marker/cutoff replay
must come from their actual smaller producers. No caller-supplied full-goal
provider or second cache framework has replaced this work.

The strongest constructive completion remains conditional on safe storage and
stratified fragment dependencies. Compatible pending choices extend to ONE
finite assignment satisfying all stored fragment equations and UF aliases,
with completion of the SAME symbolic root readback. Full native Satisfies and
acceptance by the original source root are not proved by that result.

The target stays ONE finite accepted completion of the SAME original emitted
partial root under ONE compatible assignment. It must satisfy actual native
domains, retained paths, UF aliases, residuals, readback, parked backward
recompletion and EVERY removed historical obligation on THAT output branch.
Preserve original source/root identity, noStop, ORIGINAL supplied fuels and
budgets, ALL outcomes and earlier emissions after a later stop.

Structural fragment equations and UF alone do not entail removed proper paths.
A cleared owner can remain pending. A structurally compatible leaf can violate
one proper path without refuting existence of another compatible completion.
Prove post-clear Satisfies AND every removed Holds equation under the SAME
assignment through actual continuations. Each output has its own causal
history. Sibling cache restoration prevents one global chronological clear
list. Independent local witnesses need a compatibility proof.

Original-U language, canonical Mu/Union domains, prefix-free arrow-bucket
witnesses, actual parked [1]/[2] receipts and earlier structural/native results
remain checked at their stated scope. Whole source/resource induction and the
66-probe shared eager resource owner remain open and unchanged.

The wider objective retains original typing/depth adequacy and completeness,
both LPO/preprocessing language directions, stream order, multiplicity and lazy
demand, exact node-count classes, counts, weights, training, both rank inverses,
host bounds and compiled Haskell correspondence. Keep the optimized interned
core, older constructor/equality work, all proofs, counterexamples and drafts.

