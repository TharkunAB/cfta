# Constructor storage progress and actual native stops

The full formalization goal remains ACTIVE.
Read final-documents/lean/notes-current-constructor-storage-progress.md first.
Actual nonterminal child traversal constructs one assignment and its cost.
Constructor residual finish and captured finalization consume one constructor.
Actual incoming native stops fit the original fixed-capacity forecast.
Semantic model transport, sufficient capacity and full coverage remain open.

Every regular file is archived without filtering. Keep this tree and all
reconstructions immutable. Continue in a fresh writable area. Historical
UNTESTED labels and failed attempts remain. Six exact final strict mappings
supersede draft inputs. Verification executes no Lean or Haskell code.
