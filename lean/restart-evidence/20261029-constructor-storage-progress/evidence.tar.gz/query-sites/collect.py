import sys,json,hashlib
from pathlib import Path
root=Path('/tmp/mcfta-constructor-storage-progress-20261029/query-sites/evidence-v1')
manifest=root/'read-scope.json'
entries=json.loads(manifest.read_text()) if manifest.exists() else []
for arg in sys.argv[1:]:
 name,start,end=arg.rsplit(':',2)
 source=Path(name).resolve(); data=source.read_bytes(); lines=data.splitlines(keepends=True)
 start=int(start); stop=len(lines) if end=='EOF' else min(int(end),len(lines))
 cut=b''.join(lines[start-1:stop])
 dest=root/'inputs'/f'{len(entries)+1:02d}-{source.stem}-L{start}-L{stop}.lean.txt'
 dest.write_bytes(cut)
 entry={'source':str(source),'source_sha256':hashlib.sha256(data).hexdigest(),'source_bytes':len(data),'source_lines':len(lines),'start':start,'end':stop,'requested_end':end,'whole':start==1 and stop==len(lines),'copy':str(dest),'cut_sha256':hashlib.sha256(cut).hexdigest(),'cut_bytes':len(cut)}
 entries.append(entry)
 print(json.dumps(entry))
 for n,line in enumerate(cut.decode().splitlines(),start): print(f'{n}: {line}')
 manifest.write_text(json.dumps(entries,indent=2)+'\n')
