# Actual incoming native stop storage and original forecast

Status: FROZEN SOURCE-ONLY CANDIDATES. Both Lean files are UNTESTED here. Root owns compiler and repository actions.

## Delivered proof route

Two additive modules attach `IncomingQuery.native_prefix_stored_profile` to an actual generator query observation. The first follows the literal `IncomingNode.run` branch that returns a native error. The second proves that the native query's profile ceiling fits the original positive-capacity PreparedReservation.final envelope. It derives Room from the original reservation. Neither public theorem takes a future heap bound, an arbitrary profile-comparison supplier, a future query family, or a replacement interpreter.

The actual-site theorem covers a previously excluded observation class. `IncomingNode.observed_resources` requires outer `.ok`. The new theorem takes outer `.error (.inl fault)`. This includes actual yielded native prefixes, failed native requests, constraint errors and blocked native requests. The native caller at such a stop is retained by IncomingNode.run even when no branch output is produced. The theorem bounds that actual returned caller's checked heap.

## Candidate identities

`candidate-v1/MicroCFTA/SourcePruningEnumerationIncomingNodePrefixStored.lean`

97 lines, 5738 bytes. SHA256:

`d99e960aeddde78286cf5de347f357b3879b0cdbc5094433624415871de750ed`

`candidate-v1/MicroCFTA/SourcePruningEnumerationPreparedQueryPrefixStored.lean`

95 lines, 5884 bytes. SHA256:

`bbb867d081b90af9c281adad471e706a84d5396b53942ec4a3d71de0deb494d2`

The exact three exported statement headers are retained in `public-statements.txt`. There are no runtime definitions in either candidate. There are no changed resource contracts, casts between source and prepared values, axioms, placeholders, budget changes or linter suppression. No compiler run or evaluator run was attempted. There are no compiler failures to report. The v1 files are frozen.

## Actual query site and gate provenance

`IncomingNode.run` first runs `UnionFind.findRoot` on the original core. It reads `before.values[found.representative]?`. Only a stored `.unenumerated (some oldHandle) oldScs` whose native lookup returns `old` reaches this query:

    Demand.execute nativeFuel
      (.code (requestNode emptyDomain incoming old)) beforeCaller.checked

The query uses the original beforeCaller.checked. Compression changes the enumeration representatives in readState, but it does not change the native query entry. No original-source/current-source identity is assumed.

`observed_native_error_stored` takes original Context, PendingRealized, incoming Available and closed, Fits profile and Room bits profile. Its only later observation is the literal full IncomingNode.run equation with the actual fault, actual returned Caller, saved queries and read core.

The proof inverts the actual run. Missing representative, invalid slot, absent old handle, missing lookup and the no-query direct-write branch cannot produce the specified native-error observation. At the real query branch, original PendingRealized derives an available closed value for that exact stored oldHandle. Lookup uniqueness identifies it with the literal old operand. Thus both native operand admissions come from original state data. No later Available or model premise is added.

The proof applies `IncomingQuery.native_prefix_stored_profile` at that exact caller and operand pair. In every non-done native branch, the actual returned Caller is `PartialState.advance beforeCaller fault.state beforeCaller.fourth beforeCaller.merge`. The literal run equation transports the bound to its actual checked heap. The native done branch can return a successful result or an optional-check error on the other sum arm; it cannot satisfy the native-error observation.

This theorem requires no StorageValid, root-at-uv policy, PendingAt, annotation alphabet or DecidableEq EnumGuard. Those stronger gates belong to completion producers. The new proof uses only the operand realization facts needed for this actual query.

## Original final envelope

Write

    S_i = PreparedReservation.stage depth (preparedSeed seed) ceiling ceiling sibling
    Q_j = IncomingReservation.advance S_i queryIndex

`incoming_native_profile_le_final` takes only the arithmetic index conditions

    sibling < rows seed
    queryIndex < RecursiveReservation.edgeCount S_i ceiling

and proves

    NativeResourceForecast.Le
      (NativeResourceForecast.step Q_j.2)
      (PreparedReservation.final (depth + 1) seed ceiling).2

The proof follows four existing inequalities. The native query step fits the combined incoming forecast by callerForecast_ge. The combined step at queryIndex is the incoming advance at queryIndex + 1. The remaining head reservation bounds it by afterHead S_i ceiling. The actual smaller-depth callback forecast bounds afterHead, and stage_le_final bounds that next sibling stage by the original positive-capacity final profile.

There is no final-profile inequality premise in this theorem.

`IncomingNode.observed_native_error_stored_final` uses the same literal native-error observation. It admits current Fits at Q_j.2, the current Context and original pending/input operand admissions, and the original PreparedReservation.Reserved bits (depth + 1) seed ceiling. It obtains current Room from the original reserved sibling and query entries. It invokes the first actual-site theorem, then uses the proved arithmetic mass inequality and Stored.mono. Its conclusion is Stored at the exact returned native-stop heap with ceiling

    (PreparedReservation.final (depth + 1) seed ceiling).2.mass

No final state, final heap, native error's heap, or stored bound is assumed.

## Existing producer connection

The local query admissions are already present at real producer sites.

* `CachedIncomingResources.complete_resources`, inspected lines 33–125, takes original Context, PendingRealized, incoming Available/closed, Fits and Room. It derives the exact incoming run and then calls IncomingNode.observed_resources. The new error overlay uses a weaker subset of those original admissions. It does not require a completed receipt.
* `CachedTerminalResources`, inspected lines 191–229, derives foldFits at `advance seed recorded.length`, foldRealized, foldPost.context, and transports incoming Available through the actual fold Post. It obtains current Room from the original reservation at the recorded prefix length. Lines 224–227 show the actual existing IncomingNode resource invocation with these derived gates.
* `FoldResources.observed_resources`, inspected lines 25–85, advances the original incoming profile after each actual dispatcher result, including no-action and raw-empty stops. It retains the larger remaining scheduled envelope. Its own result still requires outer `.ok`; its native-error branch rejects that hypothesis. It is not an all-error query-event theorem.

These observations show where to call the new overlay without adding a new future admission. The candidate does not modify these producers or copy their large old tuples.

## Exact remaining attachment

The new stage theorem is local to an actual query entry. It explicitly takes current Context, PendingRealized, input availability/closedness and Fits at the original planned Q_j stage. Those are the current producer's derived local admissions. They are not conclusions about a future heap. However, the new theorem does not itself prove that every query in an arbitrary outer recursive run has a particular sibling/query index. It does not add a full generator query-event trace or derive an index assignment for every stopped callback tree.

The next outer integration must retain these local admissions and consumed indices at the actual callback/child/terminal invocation, including an earlier native stop that produces no output. The existing mixed-query cost and reservation must supply the queryIndex bound; the new theorem must not replace that proof with a supplied future schedule. This bounded task stops after the first concrete actual query stop and the original-envelope arithmetic bridge.

The candidate does not cover optional-check errors `.error (.inr fault)`, all successful native prefixes before an optional check, or constructor allocations after the native query. Existing successful-result resources remain unchanged. Other owners handle constructor storage. No depth-independent global resource ceiling or sufficient recursive-capacity theorem is claimed.

No Haskell change or new Haskell defect was found.

## Evidence scope

There are 21 content acquisitions from 16 exact source identities. Two whole sources were requested and reviewed: CheckedQueryPrefixForecast (151 lines) and IncomingReservation (132 lines). The other 19 are literal numbered cuts. This is within the five-whole-source limit. Source hashes use full file bytes for identity; they do not imply review of unrequested text.

`read-scope.json` records source hashes, byte/line counts, requested and actual cut endpoints, copied cut hashes and whole flags. `inputs/` retains the exact acquired text. `source-identity-readback.json` records whether each source still matches its acquisition identity. Search results only located definitions. They are not substitutes for recorded source reads.

All writes were under the new query-sites area. No old sealed evidence, repository file, Git state, board, native process, evaluator or compiler was changed or invoked. Root may repair installed sources while retaining these exact source-only v1 candidates.
