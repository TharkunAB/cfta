theorem trace_pendingSize
    {checkEmpty : Bool} {r n p h k : Nat} {inputs : List (Node × List Suspended)}
    {caller reached : Caller width} {before after : Cached} {queries saved : Queries}
    {fragments : List Fragment}
    (trace : SourcePruningEnumerationChildTraversal.Trace checkEmpty r n p h k inputs caller before queries
      fragments reached after saved)
    (assignment : Nat → Term Symbol) (terms : List (Term Symbol))
    (lengths : terms.length = inputs.length)
    (aligned : before.core.counter = before.core.values.length)
    (nonterminal : ∀ incoming bucket, (incoming, bucket) ∈ inputs →
      bucket.any (fun sc => EqualityTrie.isTerminal sc.trie) = false) :
    ∃ extended,
      extended = install assignment before.core.counter terms ∧
      (∀ uv < before.core.counter, extended uv = assignment uv) ∧
      after.core.counter = before.core.counter + terms.length ∧
      after.core.counter = after.core.values.length ∧
      (∀ uv < before.core.counter, after.core.values[uv]? = before.core.values[uv]?) ∧
      fragments.map (Fragments.fill extended) = terms ∧
      pendingSize after.core extended = pendingSize before.core assignment + NumberedTerms.forestSize terms := by