theorem constructor_pendingSize
    (checkEmpty : Bool) (r n p h k : Nat) (inputs : List (Node × List Suspended))
    (caller reached : Caller width) (before traversed after : Cached) (queries saved : Queries)
    (fragments : List Fragment) (assignment : Nat → Term Symbol) (symbol : Symbol)
    (terms : List (Term Symbol)) (target handle : Nat) (scs : List Suspended) (residual : Option Constraint)
    (lengths : terms.length = inputs.length)
    (aligned : before.core.counter = before.core.values.length)
    (nonterminal : ∀ incoming bucket, (incoming, bucket) ∈ inputs →
      bucket.any (fun sc => EqualityTrie.isTerminal sc.trie) = false)
    (stored : before.core.values[target]? = some (.unenumerated (some handle) scs))
    (parent : assignment target = .node symbol terms)
    (completed : SourcePruningEnumerationChildTraversal.run checkEmpty r n p h k inputs caller before queries =
      .complete fragments reached saved traversed)
    (finalized : SourcePruningEnumerationFinalize.run reached.checked.native.machine.heap k target
      (.node symbol fragments) (SourcePruningEnumerationSelectedEdge.finish residual (.node symbol fragments) traversed) =
      some after) :
    ∃ extended,
      extended = install assignment before.core.counter terms ∧
      (∀ uv < before.core.counter, extended uv = assignment uv) ∧
      Fragments.fill extended (.node symbol fragments) = assignment target ∧
      pendingSize after.core extended + 1 = pendingSize before.core assignment ∧
      pendingSize after.core extended < pendingSize before.core assignment := by