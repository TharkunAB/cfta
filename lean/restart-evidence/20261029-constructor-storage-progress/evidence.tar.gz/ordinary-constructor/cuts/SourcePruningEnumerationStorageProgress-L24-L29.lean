
/-- Count assigned constructors at the actual pending graph slots. -/
def pendingSize (state : State Symbol Guard) (assignment : Nat → Term Symbol) : Nat :=
  scanCost assignment 0 state.values

private theorem from_append (assignment : Nat → Term Symbol) (first second : List (UVarValue Symbol))
