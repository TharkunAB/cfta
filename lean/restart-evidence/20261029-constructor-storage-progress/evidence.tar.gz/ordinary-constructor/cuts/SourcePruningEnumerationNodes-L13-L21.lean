variable {Guard : Type}

/-- Encode empty or a stored node identity. Free references have no handle. -/
def encodeNode (value : Value Symbol Guard) : Option Nat :=
  match value with
  | .empty => some 0
  | .reference _ => none
  | .node entry _ _ _ | .union entry _ _ _ | .mu entry _ _ _ => some (entry.identity + 1)

