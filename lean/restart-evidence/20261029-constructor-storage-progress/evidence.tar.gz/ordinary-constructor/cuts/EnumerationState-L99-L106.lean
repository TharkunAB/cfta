def require (condition : Bool) : EnumerateM Symbol Guard Unit :=
  if condition then pure () else reject

/-- Write the supplied UVar, not its representative. -/
def setValue (uv : Nat) (value : UVarValue Symbol) : EnumerateM Symbol Guard Unit :=
  modify fun state => {state with values := state.values.set uv value}

/-- Read one raw slot. -/
