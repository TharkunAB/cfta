mutual
/-- Count every constructor of a finite term. -/
def size : Term Symbol → Nat
  | .node _ children => 1 + forestSize children

/-- Count constructors in an ordered forest. -/
def forestSize : List (Term Symbol) → Nat
  | [] => 0
  | first :: rest => size first + forestSize rest
end
