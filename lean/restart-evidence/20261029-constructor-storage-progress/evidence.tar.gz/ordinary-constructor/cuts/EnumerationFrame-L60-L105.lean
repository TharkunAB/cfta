theorem neutralize_allocated (held : Nat) (node : Option Nat) (state : State Symbol Guard)
    (inside : held < state.values.length) :
    neutralize held (allocated node state) = allocated node (neutralize held state) := by
  unfold neutralize allocated
  congr 1
  exact List.set_append_left held _ inside

/-- An unrelated raw read has the same successful result with a neutral root. -/
theorem rawValue_neutral (held uv : Nat) (before after : State Symbol Guard) (value : UVarValue Symbol)
    (different : uv ≠ held) (success : Success (rawValue uv) before value after) :
    Success (rawValue uv) (neutralize held before) value (neutralize held after) := by
  obtain ⟨stored, same⟩ := (rawValue_success uv before after value).mp success
  subst after
  exact (rawValue_success uv _ _ value).mpr ⟨by rw [neutralize_read held uv before different]; exact stored, rfl⟩

/-- Representative lookup is independent of every payload value. -/
theorem representative_neutral (held fuel uv root : Nat) (before after : State Symbol Guard)
    (success : Success (representative fuel uv) before root after) :
    Success (representative fuel uv) (neutralize held before) root (neutralize held after) := by
  obtain ⟨found, lookup, rfl, rfl⟩ := (representative_success fuel uv before after root).mp success
  exact (representative_success fuel uv _ _ found.representative).mpr ⟨found, lookup, rfl, rfl⟩

/-- Union depends only on the forest and is independent of payload values. -/
theorem unionVariables_neutral (held fuel left right : Nat) (before after : State Symbol Guard)
    (success : Success (unionVariables fuel left right) before () after) :
    Success (unionVariables fuel left right) (neutralize held before) () (neutralize held after) := by
  obtain ⟨forest, result, rfl⟩ := (unionVariables_success fuel left right before after).mp success
  exact (unionVariables_success fuel left right _ _).mpr ⟨forest, result, rfl⟩

/-- An unrelated payload write commutes with neutralization. -/
theorem setValue_neutral (held uv : Nat) (value : UVarValue Symbol) (before after : State Symbol Guard)
    (different : uv ≠ held) (success : Success (setValue uv value) before () after) :
    Success (setValue uv value) (neutralize held before) () (neutralize held after) := by
  obtain rfl := (modify_success _ before after).mp success
  exact (modify_success _ _ _).mpr (neutralize_set held uv before value different)

/-- Fresh allocation has the same new identifier after neutralization. -/
theorem allocate_neutral (held : Nat) (node : Option Nat) (before after : State Symbol Guard) (uv : Nat)
    (inside : held < before.values.length) (success : Success (allocate node) before uv after) :
    Success (allocate node) (neutralize held before) uv (neutralize held after) := by
  have exactState : uv = before.counter ∧ after = allocated node before := by simpa [Success, allocate_exact, ExceptT.run] using success
  obtain ⟨rfl, rfl⟩ := exactState
  rw [neutralize_allocated held node before inside]
  simp [Success, allocate_exact, ExceptT.run, neutralize]

/-- Successful pending assimilation does not inspect or change a separate payload. -/
