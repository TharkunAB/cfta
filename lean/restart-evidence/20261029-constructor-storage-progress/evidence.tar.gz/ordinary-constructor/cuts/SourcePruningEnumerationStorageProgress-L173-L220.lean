  exact EnumerationStorageProgress.allocated_extended node before.core assignment extended aligned agree

/-- Actual own-class allocation adds only zero-cost equality slots. -/
theorem suspendMany_pendingSize
    (heap : InternedConstructorTemplates.State Symbol NativeGuard) (tries : List EqualityTrie.Trie)
    (before after : EnumerationExpandableIndex.Cached Symbol EnumGuard) (suspended : List Suspended)
    (assignment : Nat → Term Symbol)
    (observed : SourcePruningEnumerationCachedOwn.suspendMany heap tries before = some (suspended, after)) :
    pendingSize after.core assignment = pendingSize before.core assignment := by
  induction tries generalizing before after suspended with
  | nil =>
      have same : ([], before) = (suspended, after) := Option.some.inj observed
      have cacheSame : before = after := congrArg Prod.snd same
      simp only [cacheSame]
  | cons trie rest ih =>
      simp only [SourcePruningEnumerationCachedOwn.suspendMany,
        Option.bind_eq_some_iff, Option.map_eq_some_iff] at observed
      obtain ⟨allocation, allocatedRun, result, continued, same⟩ := observed
      have tail := ih allocation.2 result.2 result.1 continued
      have cacheSame : result.2 = after := congrArg Prod.snd same
      simp only [SourcePruningEnumerationCachedChild.allocate, Option.map_eq_some_iff] at allocatedRun
      obtain ⟨_flag, _classified, allocationSame⟩ := allocatedRun
      have coreSame : allocated none before.core = allocation.2.core :=
        congrArg (fun result => result.2.core) allocationSame
      rw [← cacheSame, tail, ← coreSame]
      simpa only [Nat.add_zero] using EnumerationStorageProgress.allocated_same none before.core assignment

/-- An actual successful native finalizer removes the captured pending graph cost. -/
theorem finalize_pendingSize
    (heap : InternedConstructorTemplates.State Symbol NativeGuard) (fuel target handle : Nat)
    (fragment : Fragments.Fragment Symbol) (scs : List Suspended)
    (before after : EnumerationExpandableIndex.Cached Symbol EnumGuard)
    (assignment : Nat → Term Symbol)
    (stored : before.core.values[target]? = some (.unenumerated (some handle) scs))
    (observed : SourcePruningEnumerationFinalize.run heap fuel target fragment before = some after) :
    pendingSize after.core assignment + NumberedTerms.size (assignment target) =
      pendingSize before.core assignment := by
  simp only [SourcePruningEnumerationFinalize.run, Option.bind_eq_some_iff] at observed
  obtain ⟨_old, _stored, written⟩ := observed
  simp only [SourcePruningEnumerationNativeIndex.write, Option.bind_eq_some_iff, Option.some.injEq] at written
  obtain ⟨_flag, _classified, _removed, _removedCounts, _saved, _savedCounts, same⟩ := written
  subst after
  change EnumerationStorageProgress.scanCost assignment 0 (before.core.values.set target (.enumerated fragment)) +
    NumberedTerms.size (assignment target) = EnumerationStorageProgress.scanCost assignment 0 before.core.values
  simpa only [EnumerationStorageProgress.weight, Nat.zero_add, Nat.add_zero] using
    EnumerationStorageProgress.from_set assignment before.core.values 0 target
      (.unenumerated (some handle) scs) (.enumerated fragment) stored

