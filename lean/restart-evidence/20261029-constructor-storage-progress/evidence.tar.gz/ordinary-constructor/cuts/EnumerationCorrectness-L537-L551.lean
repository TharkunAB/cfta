
/-- Install one witness per fresh class while preserving the pre-existing variable prefix. -/
def install (assignment : Nat → Term Symbol) (start : Nat) : List (Term Symbol) → Nat → Term Symbol
  | [] => assignment
  | term :: rest => install (fun uv => if uv = start then term else assignment uv) (start + 1) rest

/-- Fresh class witnesses do not change any previously allocated value. -/
theorem install_before (assignment : Nat → Term Symbol) (start : Nat) (terms : List (Term Symbol))
    (uv : Nat) (earlier : uv < start) : install assignment start terms uv = assignment uv := by
  induction terms generalizing start assignment with
  | nil => rfl
  | cons term rest ih =>
      rw [install, ih _ _ (by omega)]
      simp [show uv ≠ start by omega]

