# Original numeric filter and product initial admission

Status: progress. Start: ec5b67bd137bee0de530dfc7f99c36c813446afc.
The complete objective remains original-public-input soundness, intended finite
ordered accepted prefixes under exact configured order/stops, sufficient
original resources, optimized interned execution and BOTH workers. Retain
Prefix/table/count/checkpoint/adapters/Haskell correspondence and older
constructor/equality/exact node-count/size-order/rank/unrank obligations.
Keep generic recursive, union and opaque-field sources in the complete scope.

Immediate work: check the literal numeric equalSizes body on its current signed
source equality view and ordered Integer/Nat split transport. Then check the
original static-row-cached product startup producer at the same value/heap.
Do not add a future Packet/Fits/heap/Ready/run/domain result as a new hypothesis.
Full Constraint.equalities extraction and actual minimumSizes production remain
open. Literal reachable/trim/SCC/memo/native semantic import and worker-depth/
global-progress/public-list equality also remain open.

Root alone runs compilers/evaluators/native/Git/network/board/production edits.
Compiler checks stay serial under verified4GiB memory/high and zero swap caps.
Retain every owned payload, source cut, provider, failure and correction.
Children use at most two named OLD whole files per bounded task. Count all reuse
at original paths. Named bounded cuts apply elsewhere. No child spawning.
No Haskell edits or Haskell/native execution are planned in this phase.
