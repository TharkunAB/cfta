from pathlib import Path
import hashlib, json, sys

original = Path('/tmp/mcfta-narrowing-chain-and-native-execute-20261030')
r = Path(sys.argv[1]) if len(sys.argv) > 1 else original
out = Path(sys.argv[2]) if len(sys.argv) > 2 else r
out.mkdir(exist_ok=True)
repo = Path('/home/tritlo/Code/mcfta')
def sha(data): return hashlib.sha256(data).hexdigest()

def owner(name, manifest_name, manifest_hash, pins_name, pins_hash):
    base = r / name
    assert sha((base / manifest_name).read_bytes()) == manifest_hash
    assert sha((base / pins_name).read_bytes()) == pins_hash
    actual = {str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    if manifest_name.endswith('.json'):
        rows = json.loads((base / manifest_name).read_text())['files']
        expected = {row['path'] for row in rows}
        for row in rows:
            data = (base / row['path']).read_bytes()
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
        pins = json.loads((base / pins_name).read_text())['pins']
        for leaf, digest in pins.items(): assert sha((base / leaf).read_bytes()) == digest
    else:
        rows = [line.split('  ', 1) for line in (base / manifest_name).read_text().splitlines()]
        expected = {leaf for _, leaf in rows}
        assert len(expected) == len(rows)
        for digest, leaf in rows: assert sha((base / leaf).read_bytes()) == digest
        pins = json.loads((base / pins_name).read_text())
        assert pins['payload_files'] == len(rows)
        for leaf, record in pins['artifacts'].items():
            data = (base / leaf).read_bytes()
            assert sha(data) == record['sha256'] and len(data) == record['bytes']
            assert len(data.splitlines()) == record['lines']
    assert actual == expected | {manifest_name, pins_name}
    for p in base.rglob('*'):
        if p.is_file(): assert not p.is_symlink() and not (p.stat().st_mode & 0o222)
    return base, {'payloads': len(rows), 'regular_files': len(actual), 'readonly': True}

chain, chain_result = owner('chain-review', 'MANIFEST.json', '051866ad7d59a189abb08f4bea9ecf254d586c8df21018fadc21a3cd5883ed68', 'pins.json', '37e444470856a799fcaebf986cfa6a7d2141abaf77720c84c534237b7999bb56')
execute, execute_result = owner('execute-review', 'MANIFEST.sha256', '7f6fd8e4588a8f28df2577c9be36ea1a56efd19ecb1b0198aa140a3185e09ffb', 'FROZEN-PINS.json', 'b0e2a8b253581f4129800d8a038034c8e1c33c9d70ae8829b8d1356e28657ffd')
enabled, enabled_result = owner('enabled-review', 'MANIFEST.sha256', '774c9f8d3dd8e4d6fe0365d57572d5a4f4254d5da14db9e0b705e8775f5aa01a', 'FROZEN-PINS.json', '56a20f470c55cd44d9298c8b0bd96fd642c582d6dd986d4d855e06d0e012eff7')

public, public_result = owner('public-review', 'MANIFEST.json', '51e9a76cea2842194c18fe32e275bef2db118c39b1555190a3f6aa086207d0c0', 'pins.json', '686d6b510fe9debfdf1aa64d4082a03206c6d587caa17d4bfe3c33d186d8a891')
future, future_result = owner('next-incoming-review', 'MANIFEST.sha256', 'df68adf67b29d6b6abcaf5e7b8d475a2cf6c800d1cc9239419fe9a3cea824430', 'FROZEN-PINS.json', '3b333ed09dd9fd9f42b3b132d1e1792671edf22a4e2b6cc2e731ef97adb708af')

def source_path(path):
    p = Path(path)
    if p.is_relative_to(original): return r / p.relative_to(original)
    assert p.is_relative_to(repo), p
    return p

counts = {}
for name, base in [('chain-review', chain), ('execute-review', execute), ('enabled-review', enabled), ('public-review', public), ('next-incoming-review', future)]:
    count = 0
    for leaf in ['acquisitions.json', 'reuse-ledger.json', 'old-source-cut-ledger.json', 'old-source-locator-ledger.json']:
        ledger = base / leaf
        if not ledger.exists(): continue
        for row in json.loads(ledger.read_text()):
            data = source_path(row.get('source_path', row.get('source'))).read_bytes()
            if row.get('superseded'):
                assert row['source_sha256'] == '96b1f5f3a84a092c9718138ef896b9983bb8b04d2937d64c11a73e8c791ad1f5'
                data = (r / 'installed-chain-v5.lean').read_bytes()
                draft = (r / 'chain-bound-v4.lean').read_bytes()
                assert data == draft.replace(b'UNCOMPILED source-only draft. Root owns all checks and integration.\n', b'')
            assert sha(data) == row['source_sha256']
            assert len(data) == row['source_bytes'] and len(data.splitlines()) == row['source_lines']
            if 'actual_lines' in row:
                expected = b''.join(data.splitlines(keepends=True)[i-1] for i in row['actual_lines'])
            else:
                lo, hi = row['actual']
                expected = b''.join(data.splitlines(keepends=True)[lo-1:hi])
            copied = (base / row['copy']).read_bytes()
            assert copied == expected and sha(copied) == row['copy_sha256']
            count += 1
    counts[name] = count
result = {'status': 'pass', 'chain_review': chain_result, 'execute_review': execute_result,
          'enabled_review': enabled_result, 'public_review': public_result, 'next_incoming_review': future_result, 'exact_source_records': counts,
          'root_complete_source_lines': 325, 'root_complete_public_lines': 224,
          'next_incoming_contract': 'complete frozen UNCOMPILED V2, no Root probe'}
(out / 'owned-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
