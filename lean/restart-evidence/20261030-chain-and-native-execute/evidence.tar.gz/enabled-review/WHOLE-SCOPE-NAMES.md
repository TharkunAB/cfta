# Named OLD whole modules

1. `lean/MicroCFTA/SourceCurrentConjunctionWorker.lean` (108 lines). Named before acquisition. This module defines the actual physical conjunction call and its worklist admission branches.
2. Unused.
