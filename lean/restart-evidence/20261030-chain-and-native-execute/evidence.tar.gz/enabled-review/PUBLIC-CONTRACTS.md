# Checked core public contracts

Root reported strict candidate and default/strict installed checks passed.
This worker ran no compiler. Local notations are in the full immutable file.

```lean
theorem call_stored (p h budget : Nat) (query : Node) (before : Checked width) (memo : Fourth)
    (stored : Stored before.native) :
    Stored (SourceCurrentAllocatedConjunctionWorker.call p h budget query before memo).state.native
```

```lean
theorem check_stored (p h : Nat) (query : Node) (before : Checked width) (memo : Fourth)
    (queries : Queries) (stored : Stored before.native) :
    Stored (SourcePruningEnumerationEnabledEmpty.check p h query before memo queries).1.state.native
```

