# Scope

Root assigned this fresh bounded source-only task at 2026-10-30 23:33 CET.
Goal: preserve conditional native Stored through actual EnabledEmpty.check or establish the exact residual gate and a useful actual branch law. The full original-input finite enumeration and Haskell correspondence goals remain open.

Root owns compiler, evaluator, native execution, Git, network, board, production writes and packaging. No spawned workers. Work stays in this directory. Prior bundles remain frozen.

At most two newly named OLD whole or near-whole source modules. Name each before acquisition. Exact full reuse is authorized for installed NativeStoredExecute and prior NativeStoredPrefix. All other reads use declaration locators and bounded exact cuts with cumulative unions.
