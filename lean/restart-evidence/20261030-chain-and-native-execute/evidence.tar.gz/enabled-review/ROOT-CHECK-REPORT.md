# Root-reported checks

After the immutable 44-line V1 candidate was sent at 2026-10-30 23:39 CET, Root
reported these results through the team channel:

- Root full-read the exact V1 candidate with SHA-256
  ce4a6870ff147a85d7602f8b10949a9989e562cb818bfaa33dd8feebd00ae064.
- Root strict probe passed on the first attempt.
- Root installed SourceCurrentAllocatedNativeStoredEnabledEmpty.lean with
  43 lines and SHA-256
  5835734077c7cea16ccee0330cdaf12cab65dc96bfac55a4066c9c2dc8521d10.
- The installed change only removes the source-only status line.
- Root default and strict installed checks passed.
- Root full Audit/public review was running. This bundle does not assert a
  final Audit/public-review result.

This worker did not run those checks or acquire their raw logs. Root owns that
evidence. This report records the exact owner report.
