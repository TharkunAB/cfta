# Native Stored across EnabledEmpty

Root reported that the exact immutable V1 candidate passed its strict probe on
the first attempt. Root installed the same source after removal of the one
status line. Root reported default and strict checks passed for that installed
module. This worker ran no compiler, evaluator or native execution.

## Completed core

`NativeStoredEnabledEmpty-v1-UNCOMPILED.lean` has 44 lines and two public laws.
Its original status line remains unchanged to preserve the exact checked input.
The installed module has 43 lines.

- `call_stored` preserves native Stored in either actual outcome of
  `SourceCurrentAllocatedConjunctionWorker.call`. It accepts every query and
  every p, h and budget. Its only property premise is native Stored at entry.
- `check_stored` preserves native Stored in the actual result of the full
  `SourcePruningEnumerationEnabledEmpty.check`. It accepts every query, p, h,
  fourth memo and endpoint memo. Its only property premise is native Stored at
  entry.

The exact public signatures are in `PUBLIC-CONTRACTS.md`.

Candidate SHA-256:
`ce4a6870ff147a85d7602f8b10949a9989e562cb818bfaa33dd8feebd00ae064`.
Root-reported installed module:
`lean/MicroCFTA/SourceCurrentAllocatedNativeStoredEnabledEmpty.lean`, SHA-256
`5835734077c7cea16ccee0330cdaf12cab65dc96bfac55a4066c9c2dc8521d10`.

## Exact source reason

Native Stored contains two fields. Each field concerns completed native cells.
The node certificate says that an empty-seen request with finite ordinary
operands has a finite ordinary result whose height is bounded by each operand.
The edge certificate has the corresponding row property. These certificates
contain operand and result values. They do not depend on the current heap,
domain cache or equality operations.

The existing `SourceCurrentAllocatedFiniteOrdinaryStored.advance_stored` law
therefore preserves Stored through native machine advance.

The actual `SourceCurrentAllocatedConjunctionWorker.call` runs a physical
worker. In BOTH its done and failed cases, it lifts the exact returned physical
state with `SourceCurrentAllocatedQueryMemo.advancePhysical before after`.
That source definition is:

```lean
⟨advance before.native {before.native.machine with heap := after.heap}, after.equality⟩
```

The native nodes and edges tables are literally the entry tables. The existing
advance_stored law closes both outcome branches. Success-only `call_tables`
also confirms this frame, but the new proof uses the actual call definition so
it covers failure too.

EnabledEmpty.check first runs the endpoint memo. Its Boolean branch either
calls this exact allocated conjunction worker with budget 1000 or returns the
same checked state. The new call law and entry Stored close those two branches.

No future trace, future result, per-step Room, per-step Stored, successful
completion or desired coverage is supplied. The new proof does not inspect or
verify local nested physical worker requests. Their temporary native tables do
not replace the caller's tables in this actual lift.

## Open operands

No closedness premise is used. Both public laws quantify over every Node.
The inspected physical worker `decision` checks
`SourceCurrentConjunctionWorklist.closed start`. On a miss, its false branch
returns false with the same physical state. The public physical `call` reads
the fourth memo before that decision guard. Thus an arbitrary query can reach
the allocated caller interface. The frame proof applies to all such cases.

The whole checked proof does not need the closedness of inner row operands.
This report does not claim that every nested request has closed operands. No
attempt was made to apply execute_stored to an operand whose closedness had not
been established.

## Bounded next caller inspection

After the immutable core was sent to Root, Root authorized a cheap inspection
of actual IncomingNode.run composition. The exact run body and the existing
initial_ranges proof were acquired as bounded cuts. No incoming law was added
to the checked core. `NEXT-INCOMING-CONTRACT.md` states the next unproved target.

The inspected run uses before.values at the actual found representative. Its
read state changes only the representatives field. PendingRealized at before
can therefore supply the old decoded node's availability and closed syntax
without a new read-frame property. The existing initial_ranges proof gives the
exact PendingRealized lookup argument and the `fits.room room` projections.

A candidate full-run invariant can use current Ready, PendingRealized,
available/closed incoming, current Fits/Room, and entry native Stored. Every
raw query branch can use the checked execute_stored law. Its done continuation
can use the new unconditional check_stored law. Caller advance copies the
exact supplied checked state. Other run branches retain beforeCaller. The
finish action changes only the returned enumeration state.

No extra logical entry gate appeared in this bounded source inspection. The
actual case proof is still unproved and unchecked. Root explicitly assigned
that composition to a subsequent fresh checking phase. The core freeze does
not depend on it.

Context.stored remains the separate merge-memo invariant. This work does not
derive native Stored from that field. Whole-caller induction must maintain
native Stored as a separate property, beginning with the literal initializer.

## Boundaries

The result preserves existing conditional structural certificates in the
caller's native tables. It does not assert finite ordinary bounds for every
recursive request. It does not establish original-input enumeration capacity,
sufficient original depth, finite global coverage, whole IncomingNode.run
preservation, whole-program termination, a public API theorem or Haskell
correspondence.

No Haskell source changed. No admitted actual Haskell execution occurred. No
Haskell defect or fix was established. There is no new Haskell FINDINGS entry.

## Provenance and scope

The prior bundles remain frozen. All writes stayed in this new owned directory.
There was no compiler, evaluator, native execution, Git, network, board,
production write, packaging or spawned worker. Root performed the reported
proof checks and production installation.

Authorized exact full reuses are installed NativeStoredExecute (89 lines,
SHA-256 ed2bc2575ca4f3571e60b9c2cf5be4d14ed30f9f29e2578e82f7f82318bd9611)
and checked NativeStoredPrefix (342 lines, SHA-256
6312a299e110065b4dd53fcc1e9b32d6980ab945d6b27b611848cf02475877ef).

One newly named OLD whole module was acquired: SourceCurrentConjunctionWorker,
108 lines. It was named before acquisition. The second slot remains unused.
Other reads are exact declaration locators and bounded cuts.

acquisitions.json records every full source hash, byte/line count, exact source
line selection, retained copy path and copy hash. CUMULATIVE-SOURCE-UNIONS.json
records the union across repeated reads. Raw locators and stderr remain in this
bundle. ROOT-CHECK-REPORT.md distinguishes Root-reported checks from this
worker's source-only work. No incident or failed command occurred.
