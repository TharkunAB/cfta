# Next actual IncomingNode.run target

This is an unproved and unchecked proposed contract. It is not part of the two
checked core laws. It retains the actual entry numeric gates. It adds no future
trace, Room, result or Stored supplier.

Use the actual caller's Symbol, Constraint and Node notations. Profile and Room
are from SourceCurrentAllocatedNativeResourceForecast. Fits is from
SourceCurrentConstrainedCapGeneratedQueryResources. PendingRealized is the
existing enumeration heap realization predicate.

```lean
theorem incoming_run_stored
    {bits : Nat} {EnumGuard : Type}
    (profile : Profile) (checkEmpty : Bool)
    (representativeFuel nativeFuel p h : Nat)
    (beforeCaller : SourceCurrentAllocatedPartialState.State (bits + 2))
    (before : EnumerationState.State Symbol EnumGuard)
    (uv : Nat) (incoming : Node)
    (incomingScs : List EnumerationState.Suspended)
    (queries : SourceEndpointMemo.Memos)
    (ready : SourceCurrentConjunctionClassScan.Ready beforeCaller.checked)
    (realized : PendingRealized beforeCaller.checked.native.machine.heap before)
    (available : Available beforeCaller.checked.native.machine.heap incoming)
    (closed : incoming.free = [])
    (fits : Fits profile beforeCaller.checked) (room : Room bits profile)
    (stored : SourceCurrentAllocatedFiniteOrdinaryStored.Stored beforeCaller.checked.native) :
    SourceCurrentAllocatedFiniteOrdinaryStored.Stored
      (SourcePruningEnumerationIncomingNode.run checkEmpty representativeFuel nativeFuel p h
        beforeCaller before uv incoming incomingScs queries).2.1.checked.native
```

The existing Context supplies ready. Its stored field concerns the merge memo;
the native stored premise above is a separate maintained invariant.

The bounded case plan is:

1. Split the actual UnionFind.findRoot result and actual original values lookup.
   All branches without a raw native call retain beforeCaller.
2. On the actual old-handle lookup, apply realized to found.representative,
   oldHandle, oldScs and that exact stored-slot equation. Identify its decoded
   node with the actual lookup result. This supplies availability and closedness.
3. Apply fits.room room. Its three projections are the current bounds required
   by execute_stored. Invoke execute_stored on incoming and the actual old node.
4. Split the actual raw outcome. Every non-done branch advances with exactly
   that outcome's state. Its native Stored fact is already supplied by step 3.
5. On done, split checkEmpty. The true branch uses check_stored, without any
   closedness or extra numeric premise for the returned query. The false branch
   retains queried. Both phase outcomes have native Stored.
6. The actual Caller.advance copies the supplied checked state. encodeNode and
   finish affect the result and enumeration state, not the checked native state.

No original-slot root, pending-at-uv, suspended-variable bound or StorageValid
premise appears necessary for this native-only target. Those premises remain
necessary for the separate enumeration semantic and storage results. This
source observation is not a proof of the contract above.
