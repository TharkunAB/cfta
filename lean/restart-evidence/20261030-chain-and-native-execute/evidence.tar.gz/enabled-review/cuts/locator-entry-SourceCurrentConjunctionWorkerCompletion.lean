import MicroCFTA.SourceCurrentConjunctionWorker
import MicroCFTA.SourceCurrentConjunctionRowsWorkerActual
namespace MicroCFTA.SourceCurrentConjunctionWorkerCompletion
def StableRun (evaluation : Nat → Nat → Outcome Symbol Formula Output)
theorem explore_sound [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem explore_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem decision_sound [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] [DecidableEq (Value Symbol Guard)]
theorem decision_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] [DecidableEq (Value Symbol Guard)]
theorem call_sound [DecidableEq ConcreteSymbol] [DecidableEq (EdgeKey ConcreteSymbol ConcreteGuard)]
theorem call_complete [DecidableEq ConcreteSymbol] [DecidableEq (EdgeKey ConcreteSymbol ConcreteGuard)]
theorem explore_finite [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem call_finite [DecidableEq ConcreteSymbol] [DecidableEq (EdgeKey ConcreteSymbol ConcreteGuard)]
