import MicroCFTA.SourceCurrentAllocatedNativeEffects
import MicroCFTA.SourceCurrentConjunctionMemo
import MicroCFTA.SourceEqualityNativeDemandRunning
import MicroCFTA.SourceEqualityNativeDemandRequestExact
import MicroCFTA.SourceCurrentAllocatedNativeRunning
namespace MicroCFTA.SourceCurrentAllocatedQueryMemo
theorem key_exists (request : NodeRequest Symbol Guard)
theorem call_produced [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem inputs_head [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem query_effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
def advancePhysical (before : Checked width) (after : Physical) : Checked width :=
theorem physical_advance (before : Checked width) (after : Physical) :
theorem advance_tables (before : Checked width) (after : Physical) :
theorem advance_extension (before : Checked width) (after : Physical)
theorem advance_valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem finite_after_query [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem true_excludes_common [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
