import MicroCFTA.SourceCurrentAllocatedPartialInvariant
import MicroCFTA.SourceCurrentAllocatedConjunctionReadValidity
import MicroCFTA.SourceCurrentAllocatedProbeConjunction
namespace MicroCFTA.SourceCurrentAllocatedConjunctionCaller
theorem verified {inventory : Inventory} {budget : Nat} {before : Caller width} {after : Physical}
theorem actual {inventory : Inventory} {budget : Nat} {before : Caller width} {after : Physical}
theorem finite {inventory : Inventory} {before : Caller width} {query : Value Symbol Guard} {memos : Memos}
