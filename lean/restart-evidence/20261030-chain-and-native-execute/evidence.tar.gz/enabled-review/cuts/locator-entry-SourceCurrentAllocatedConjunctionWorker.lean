import MicroCFTA.SourceCurrentConjunctionWorker
import MicroCFTA.SourceCurrentAllocatedConjunctionMemo
namespace MicroCFTA.SourceCurrentAllocatedConjunctionWorker
inductive Outcome (width : Nat) : Type 1 where
def Outcome.state : Outcome width → Checked width
def Outcome.memo : Outcome width → Memo
noncomputable def call [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem call_hit (p h budget : Nat) (query original : Value Symbol Guard) (before : Checked width)
theorem call_lift {p h budget : Nat} {query : Value Symbol Guard} {before : Checked width}
theorem call_failed_lift {p h budget : Nat} {query : Value Symbol Guard} {before : Checked width}
theorem call_done {p h budget : Nat} {query : Value Symbol Guard} {before after : Checked width}
theorem call_failed {p h budget : Nat} {query : Value Symbol Guard} {before after : Checked width}
theorem call_tables {p h budget : Nat} {query : Value Symbol Guard} {before after : Checked width}
