import MicroCFTA.SourceCurrentConjunctionRowsWorker
import MicroCFTA.SourceCurrentConjunctionMemo
The worklist checks Empty before budget, closedness, and prior membership.
namespace MicroCFTA.SourceCurrentConjunctionWorker
open SourceCurrentConjunctionWorklist (closed)
def Outcome.state : Outcome Symbol Formula Output → Physical Symbol Formula
def Outcome.bind (first : Outcome Symbol Formula Input)
noncomputable def explore [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
      else if SourceCurrentConjunctionEmptinessTable.skip key closed budget table nodes then
      SourceCurrentConjunctionWorklist.closed budget table nodes
noncomputable def decision [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
  if closed start then
      match SourceCurrentConjunctionEmptinessTable.grow .empty key closed table (budget + 1) (fun _ => false) with
      | some known => .done (SourceCurrentConjunctionEmptinessTable.answer .empty key closed table known start) after
noncomputable def call [DecidableEq ConcreteSymbol] [DecidableEq (EdgeKey ConcreteSymbol ConcreteGuard)]
theorem call_failed [DecidableEq ConcreteSymbol] [DecidableEq (EdgeKey ConcreteSymbol ConcreteGuard)]
