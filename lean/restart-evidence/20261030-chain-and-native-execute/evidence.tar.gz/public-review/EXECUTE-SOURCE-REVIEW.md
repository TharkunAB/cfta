# Actual arbitrary-fuel execute source review

The reviewer read all 89 installed lines and the private prefix proof.
Root reports that its preceding V3 strict probe passed.

execute_stored takes current native Ready, both operands Available and
closed, entry Stored, and exactly three current numeric bounds. Ready is
SourceCurrentConjunctionClassScan.Ready. It includes Good, SemanticReady,
CostHeap, Scoped and Idle. It differs from the narrowing cache Ready.

For state width bits + 2, the bounds are nodes.next < 2^bits, edges.next
less than or equal to 2^(bits+2), and domains.next plus
2^(nodes.next + nodes.next * nodes.next) < 2^(bits+1). The theorem retains
all three assumptions. It does not derive them for arbitrary heaps.

The proof derives Original for both operands from current coherence,
availability and closedness. It derives WordRanges from those facts,
Good, SemanticReady and the exact current bounds. It derives a completed
physical receipt from the existing completion theorem. The guard function
that always returns true is used only for this physical trace. It creates
no claim about the intended semantic meaning of guards.

The private induction uses the derived receipt trace to extract the exact
state observed by execute at any supplied fuel. At fuel zero, execute
yields the entry state and the checked prefix has length zero. A trace
that has already reached pure also retains its state. A yielded step
prepends its actual checked Trace constructor to the smaller prefix.
The public proof then applies the existing literal node-prefix law.

The public theorem supplies no Trace, Original, WordRanges or future
completion premise. Its conclusion covers the actual execute outcome
state for arbitrary fuel, including budget-exhausted yielded outcomes.
This does not certify arbitrary unchecked step successors.

The requested control is the literal empty-domain requestNode for the
supplied operands. Stored describes conditional structural certificates
of returned native memo cells. It does not assert an unrestricted
structural certificate for an arbitrary returned root value.

initial_execute_stored uses the literal checked initializer. It derives
entry Stored from empty native tables. Ready, operand availability and
closedness, and all three numeric bounds remain caller assumptions.
It does not derive the whole Ready predicate from an arbitrary heap.

These statements do not establish a Word64 deployment bound, semantic
guard correspondence, full caller coverage or Haskell correspondence.
