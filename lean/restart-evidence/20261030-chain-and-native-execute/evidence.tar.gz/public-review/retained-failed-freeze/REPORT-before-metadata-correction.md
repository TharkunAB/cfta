# Changed-filter bounds and native storage review

Result: PASS for all eight final source and public contracts. The reviewer
found no source or contract defect. Root owns compiler and runtime evidence.
The reviewer ran no compiler, evaluator, native, Git, network, board,
production or spawn command.

## Final sources and full-read evidence

| Installed copy | Lines | Bytes | SHA-256 |
| --- | ---: | ---: | --- |
| inputs/installed-chain-final.lean | 193 | 11132 | b2b2e0973150d52cc63b5f26a2ee963a2fdb4ca6e9d53f68cb66fdae3abe90d6 |
| inputs/installed-execute.lean | 89 | 5557 | ed2bc2575ca4f3571e60b9c2cf5be4d14ed30f9f29e2578e82f7f82318bd9611 |
| inputs/installed-enabled-empty.lean | 43 | 2229 | 5835734077c7cea16ccee0330cdaf12cab65dc96bfac55a4066c9c2dc8521d10 |

The installed sources total 325 lines and 18918 bytes. The reviewer read
all 173 lines of the chain V4 draft, all private proof branches, and the
complete 21-line ordinary-source addition. Exact byte comparisons connect
that read to the final 193-line installed module. The reviewer also read
all 89 execute lines and all 43 EnabledEmpty lines.

The retained 172-line installed chain snapshot is an intermediate version.
It equals V4 after removal of its 68-byte uncompiled status line. The final
193-line version inserts 21 lines before the same final namespace end.
Every preceding byte remains exact. The intermediate copy remains in the
inventory. acquisitions.json marks it superseded because its original
repository path now holds the final version. Its retained snapshot hash
must be checked against that snapshot, rather than the current repository
file. The final repository source has its own acquisition record.

The final public tail is 224 lines and 16607 bytes. Its SHA-256 is
67a003f515f2cacfe94fff14c2f094090b85644ee88f0adb7d0ad904434faffd.
The reviewer read all lines in seven separate complete displays. No display
was truncated. The tail contains both definition prints, both full history
constructors, all eight complete signatures and all eight axiom reports.
read-ledger.json records exact display ranges, copies and hashes.

## Changed-filter definitions and proofs

rootRowCount counts carrier list occurrences whose complete edge occurs in
the current resident root rows. It counts complete edges, including their
child values and guards. It does not count labels alone. Carrier duplicates
are permitted and count as separate occurrences. No Nodup gate is needed.
The definition is a logical, noncomputable measure.

The private length proof checks both membership branches. The monotonicity
proof uses complete-edge subset inclusion. The strict proof combines that
inclusion with one actual lost carrier edge. It checks loss at the carrier
head and loss in the tail. A lost duplicate still gives strict decrease.

ChangedFilters records literal successful narrowAt equations. Its nil
constructor retains the same heap and value with count zero. Its cons
constructor records fuel, key, actual success, both actual encoding
equations, changed handles, and a remaining history from the exact reached
heap and value. Keys and fuel may vary. fits and admits stay fixed. No
future Normal or row-loss supplier is a constructor field.

The four public laws are in SourcePruningNativeView.

1. narrowAt_changed_rootRowCount_lt retains Ready, Available, root Ordinary,
   physical Normal, explicit carrier inclusion, actual narrowAt success,
   both actual encodeNode equations and changed handles. It derives row
   inclusion and row loss from the existing strict-loss theorem. It then
   derives strict measure decrease and inclusion for the actual result.
2. ChangedFilters.rootRowCount_bound takes the literal history and explicit
   fixed carrier inclusion. Its initial gates are Ready, Available, closed
   input, root Ordinary and Normal. Induction derives each next gate from
   the actual narrowAt return. It proves count plus final rootRowCount is
   at most the initial rootRowCount. It also preserves final inclusion.
3. changedFilters_after_returned_bound starts with one actual successful
   closed-input filter. Ready, Available and closedness remain gates. It
   derives the first result's Normal and other gates internally. It bounds
   SUBSEQUENT consecutive changed filters by that first result's row-list
   length. It requires no input Normal or first-handle-change premise.
4. changedFilters_after_ordinary_returned_bound adds root Ordinary for the
   supplied initial value. It derives inclusion in that initial row list
   from the first actual narrowAt success. It derives Normal from the
   actual returned-control law. It bounds the SUBSEQUENT changed filters
   by the INITIAL root-row list length. Recursive children are permitted.
   No recursive finite NodeDomain or input Normal premise is introduced.

The first successful filter is outside the subsequent count in laws 3 and
4. Law 4 concerns one supplied ordinary source. These statements do not
transport a source carrier through resets, unchanged actions, intervening
writers or actual worker histories. They do not establish a full public
original-input reset bound or original enumeration depth.

## Actual arbitrary-fuel node execution

The two public laws are in SourceCurrentAllocatedNativeStoredExecute.

5. execute_stored proves Stored for the actual execute outcome state at any
   supplied fuel. It uses the literal empty-domain requestNode control.
   The entry gates are current native Ready, both operands Available and
   closed, entry Stored, and exactly three current numeric bounds.
6. initial_execute_stored uses the literal checked initializer. It derives
   only entry Stored from empty native tables. Ready, availability,
   closedness and the three numeric bounds remain caller assumptions.

Here Ready means SourceCurrentConjunctionClassScan.Ready. Its actual fields
are Good, SemanticReady, CostHeap, Scoped and Idle. It differs from the
narrowing cache Ready. For state width bits + 2, the exact bounds are:

- nodes.next < 2^bits;
- edges.next <= 2^(bits+2);
- domains.next + 2^(nodes.next + nodes.next * nodes.next) < 2^(bits+1).

These bounds use the current entry counters. They are conservative,
width-parametric assumptions. The public laws do not derive them for an
arbitrary heap or establish a Word64 deployment bound.

The proof derives Original for both operands from current coherence,
availability and closedness. It derives WordRanges from the actual warm
initial range theorem and the three numeric bounds. It derives a completed
physical Receipt from the existing completion theorem. The guard function
that always returns true supplies only that physical trace. This creates
no claim about the intended semantic interpretation of guards.

The private induction extracts the exact checked prefix state observed by
execute at the requested fuel. Fuel zero yields the entry state. A trace
already at pure retains its state. A yielded step prepends its actual
checked Trace constructor to the smaller prefix. The public proof applies
the literal node-prefix Stored law to that extracted trace.

The public headers contain no Trace, Original, WordRanges, Receipt or
future-completion supplier. The conclusion covers actual budget-yielded
execute states as well as completed observations. This differs from the
previous arbitrary unchecked next-step theorem, whose yielded branch is
True. The new law certifies this literal node execution under its gates.
It does not certify arbitrary unchecked step successors.

Stored is conditional. For each returned native node or edge cell, an
empty-seen request with recursively finite ordinary operands must return
a recursively finite ordinary result whose height is at most each operand
height. The new execute law does not assert an unrestricted certificate
for every returned root value.

## Actual EnabledEmpty frame

The two public laws are in SourceCurrentAllocatedNativeStoredEnabledEmpty.

7. call_stored retains entry Stored through actual allocated conjunction
   calls at arbitrary p, h and budget. Besides ordinary arguments and
   equality instances, entry Stored is its only invariant premise.
8. check_stored retains entry Stored through the actual endpoint query
   and enabled fourth-memo check. Its enabled branch calls the literal
   existing budget 1000. Its other branch returns the original state.

The reviewer checked actual AllocatedConjunctionWorker.call and both its
physical outcome branches. Success and failure both lift the actual
reached physical state through QueryMemo.advancePhysical. That definition
retains the OUTER native node and edge tables. It changes the machine heap
and checked equality operations. The existing advance_stored theorem
preserves Stored for any replacement native machine with those same tables.

The actual check runs SourceEndpointMemo.run on the query and endpoint
memos, then splits on its Boolean result. Both branches match the new proof.
The public laws need no closedness, availability, Ready, semantic, resource
or nested-worker-completion premise. These are outer-table frame laws.
They do not prove inner worker memo correctness, heap Ready, result
semantics or full caller behavior. The separate execute laws retain their
own entry gates and concern their actual native execution states.

## Bounded old acquisitions

The review acquired zero OLD whole or near-whole source files. It used 18
contiguous cuts and 15 declaration/import locator records. Their union is
305 distinct lines over 14 OLD modules. The largest fraction is 22 of 59
lines in the warm initial range module.

old-source-cut-ledger.json records source paths, full-file metadata hashes
and sizes, actual ranges, retained copies and copy hashes. Locator records
use explicit disjoint actual_lines. old-source-unions.json records the
exact combined union. Whole-file metadata hashes were streamed without
acquiring those OLD source bodies.

The cuts check strict loss, actual returned control, ordinary row inclusion,
Ready, warm range and completion headers, Original, Receipt and actual
checked Trace, actual execute and Outcome.state, the literal node-prefix
law, conditional certificates, actual call, actual check, advancePhysical
and advance_stored. The review did not acquire nested raw-worker internals.
A small import/namespace locator from AllocatedConjunctionMemo is retained
in the union as provenance.

## Validation authority and retained provenance

All eight public axiom reports list only propext, Classical.choice and
Quot.sound. The reviewer read those reports and checked payload metadata.
The reviewer did not rerun Lean or native execution.

Root reports passing installed default and strict checks for all three
modules. Root reports a full Audit pass at 4753 jobs and 83043 dependency
checks, and a public pass at 1217 checks and 118 prints. Root reports all
551 prior protected inputs and 835 native inputs exact. The Audit change
adds three imports and preserves the entire prior body. Root retained 18
serial compiler commands: 15 passing commands and three repaired failed
candidates, with 49 snapshots. These are Root reports.

Root reports a full public log of 4890474 bytes with SHA-256
98dee0ee96e79e487a5457f98048e78ea855fe43547d17bfbc34da46acbf434e.
Its prior 4873867 bytes are an exact prefix. This reviewer acquired and read
only the complete new 16607-byte public tail. Root's final source-input
bundle has MANIFEST SHA-256
17fa0050f25f1fa8dcebfbca19c51a68fec3b692c88ab5efe3a0a5ee2af07034.
root-reported-validation.json records these authority boundaries.

Root reports that chain repairs changed 16 deprecated conditional lemma
aliases and two constructor docstrings. The ordinary-source companion adds
21 lines. Prior definitions, constructors and first three public headers
retain their meaning. Root reports that execute repairs changed dependent
constructor argument spelling and qualified execute in simp. Its public
headers remain unchanged. EnabledEmpty owner V1 passed its first strict
probe. Installed sources remove only their draft status lines after those
repairs. Root retains the compiler failures and original owner bundles.
This review retains its supplied draft, intermediate and final source copies.

The earlier narrowing and stored-prefix review bundles remain frozen.
Their directories were not changed. Two wait dispatches were aborted by
Root steering before execution. They changed no file. There was no display
truncation or helper failure in this fresh review. INCIDENTS.md records the
superseded snapshot and the compiler-evidence authority boundary.

These results do not complete actual worker history transport, resets,
incoming intersections, Prepared Mu or Union bounds, whole-caller
neutrality, original depth, global coverage or Haskell correspondence.
No Haskell defect or fix is established by this review. Root's pending
Incoming draft remains source-only future work outside this checkpoint.
