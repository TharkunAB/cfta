# Chain source review

The reviewer read all 173 lines of chain-bound-v4.lean.
Root reports that its strict probe passed.

rootRowCount counts carrier list occurrences whose complete edge occurs in
the current resident root rows. The carrier need not satisfy Nodup.
The private monotonicity proof uses actual complete-edge inclusion. The
strict proof uses an actual lost edge that occurs in the carrier.

The first public theorem retains Ready, Available, ordinary root form,
physical Normal, carrier inclusion, actual successful narrowAt, actual old
and new encoding equations, and changed handles. It derives subset and
loss internally. It also transports inclusion to the actual result.

ChangedFilters records literal successful narrowAt equations. Every next
step starts at the exact preceding result heap and value. The predicates
fits and admits stay fixed. The key and native reader fuel may change.
The nil constructor retains both heap and value. The cons constructor
records the actual encoding equations and changed handles.

The general history theorem retains Ready, Available, closedness, ordinary
root form, Normal and explicit inclusion in its fixed carrier. Induction
derives the next input gates from the actual narrowAt return. It proves
count plus the final membership count is at most the initial membership
count. It also retains final inclusion in the same carrier.

The final theorem starts with one actual successful closed-input filter.
It derives the first result gates and chooses that result's row list as
its carrier. It bounds subsequent consecutive changed filters by that
row-list length. The first filter itself need not change its handle and
is not included in the subsequent count. The bound is not stated against
the original input rows.

The contracts do not record resets, unchanged steps, intervening writes or
actual worker histories. Those require separate transport theorems.
No original-depth, whole-caller termination or Haskell claim follows.

Root later added the ordinary-source companion. The reviewer read all
21 added lines. The preceding 172-line version remains exact apart from
the insertion before the same final namespace end. The final module has
193 lines. The fourth law retains an initial root-form Ordinary premise
and derives inclusion in that initial root-row carrier from the actual
first narrowAt success. It then derives Normal from returned_control.
The subsequent changed-step count is bounded by the INITIAL root-row
list length. The first filter remains outside that count. Recursive
children are permitted; recursive finite NodeDomain is not assumed.
No input Normal or firstchanged premise is added. This is a bound for
one supplied ordinary source and literal consecutive filter history.
It is not a reset or actual-worker source-history transport theorem.
