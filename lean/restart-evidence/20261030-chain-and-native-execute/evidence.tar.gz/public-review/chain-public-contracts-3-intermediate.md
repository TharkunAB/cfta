# Chain public source contracts

These are source headers. Root final expanded signatures are pending.

Namespace MicroCFTA.SourcePruningNativeView.
Symbol means SourcePruningTemplates.Symbol. Guard and Key are implicit Types.
Each theorem retains its explicit EdgeKey decidable equality instance.

## MicroCFTA.SourcePruningNativeView.narrowAt_changed_rootRowCount_lt

Source lines 89 through 102.

```lean
theorem narrowAt_changed_rootRowCount_lt [DecidableEq (EdgeKey Symbol Guard)]
    (fits : Key → Symbol → Bool) (admits : Key → Value Symbol Guard → Bool)
    (fuel : Nat) (key : Key) (value result : Value Symbol Guard) (before after : State Symbol Guard)
    (oldHandle newHandle : Nat) (carrier : List (EdgeValue Symbol Guard))
    (ready : SourceEqualityRequiredCache.Ready before)
    (available : Available before value) (ordinary : SourceEqualityRequiredCache.Ordinary value)
    (normal : EqualityOrdinaryReadback.Normal before value)
    (included : ∀ edge ∈ nodeEdges value, edge ∈ carrier)
    (returned : narrowAt fits admits fuel key value before = .done result after)
    (oldEncoded : SourcePruningEnumerationNodes.encodeNode value = some oldHandle)
    (newEncoded : SourcePruningEnumerationNodes.encodeNode result = some newHandle)
    (changed : newHandle ≠ oldHandle) :
    rootRowCount carrier result < rootRowCount carrier value ∧
      (∀ edge ∈ nodeEdges result, edge ∈ carrier) := by
```

## MicroCFTA.SourcePruningNativeView.ChangedFilters.rootRowCount_bound

Source lines 127 through 138.

```lean
theorem ChangedFilters.rootRowCount_bound [DecidableEq (EdgeKey Symbol Guard)]
    (fits : Key → Symbol → Bool) (admits : Key → Value Symbol Guard → Bool)
    (before after : State Symbol Guard) (value result : Value Symbol Guard) (count : Nat)
    (history : ChangedFilters fits admits before value count after result)
    (carrier : List (EdgeValue Symbol Guard))
    (ready : SourceEqualityRequiredCache.Ready before)
    (available : Available before value) (closed : value.free = [])
    (ordinary : SourceEqualityRequiredCache.Ordinary value)
    (normal : EqualityOrdinaryReadback.Normal before value)
    (included : ∀ edge ∈ nodeEdges value, edge ∈ carrier) :
    count + rootRowCount carrier result ≤ rootRowCount carrier value ∧
      (∀ edge ∈ nodeEdges result, edge ∈ carrier) := by
```

## MicroCFTA.SourcePruningNativeView.changedFilters_after_returned_bound

Source lines 156 through 164.

```lean
theorem changedFilters_after_returned_bound [DecidableEq (EdgeKey Symbol Guard)]
    (fits : Key → Symbol → Bool) (admits : Key → Value Symbol Guard → Bool)
    (fuel : Nat) (key : Key) (initial value result : Value Symbol Guard)
    (before middle after : State Symbol Guard) (count : Nat)
    (ready : SourceEqualityRequiredCache.Ready before)
    (available : Available before initial) (closed : initial.free = [])
    (returned : narrowAt fits admits fuel key initial before = .done value middle)
    (history : ChangedFilters fits admits middle value count after result) :
    count ≤ (nodeEdges value).length := by
```

