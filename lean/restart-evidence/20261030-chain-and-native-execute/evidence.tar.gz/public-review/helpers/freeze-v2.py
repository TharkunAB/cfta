from pathlib import Path
import json, hashlib, subprocess
r = Path('/tmp/mcfta-chain-execute-public-review-20261030')
for x in json.loads((r / 'acquisitions.json').read_text()):
    b = (r / x['copy']).read_bytes()
    assert hashlib.sha256(b).hexdigest() == x['copy_sha256']
    assert len(b) == x['source_bytes']
    assert len(b.splitlines()) == x['source_lines']
    if not x.get('superseded'):
        assert hashlib.sha256(Path(x['source_path']).read_bytes()).hexdigest() == x['source_sha256']
for name in ['old-source-cut-ledger.json', 'old-source-locator-ledger.json']:
    for x in json.loads((r / name).read_text()):
        assert subprocess.check_output(['sha256sum', x['source_path']], text=True).split()[0] == x['source_sha256']
        if 'actual' in x:
            expr = f'{x["actual"][0]},{x["actual"][1]}p'
        else:
            expr = ';'.join(f'{i}p' for i in x['actual_lines'])
        b = subprocess.check_output(['sed', '-n', expr, x['source_path']])
        assert b == (r / x['copy']).read_bytes()
        assert hashlib.sha256(b).hexdigest() == x['copy_sha256']
for x in json.loads((r / 'read-ledger.json').read_text()):
    assert x['read_complete']
    assert hashlib.sha256((r / x['copy']).read_bytes()).hexdigest() == x['copy_sha256']
old = (r / 'inputs/installed-chain.lean').read_bytes()
draft = (r / 'inputs/chain-bound-v4.lean').read_bytes()
final = (r / 'inputs/installed-chain-final.lean').read_bytes()
status = b'UNCOMPILED source-only draft. Root owns all checks and integration.\n'
assert draft.replace(status, b'', 1) == old
end = b'end MicroCFTA.SourcePruningNativeView\n'
assert final == old[:-len(end)] + (r / 'chain-ordinary-addition-L172-L192.txt').read_bytes() + end
assert final == (r / 'inputs/chain-bound-v6.lean').read_bytes()
u = json.loads((r / 'old-source-unions.json').read_text())
assert len(u) == 14 and sum(x['union_count'] for x in u) == 305
largest = max(u, key=lambda x: x['union_count'] / x['source_lines'])
assert largest['union_count'] == 40 and largest['source_lines'] == 105
assert 'The largest fraction is 40 of 105' in (r / 'REPORT.md').read_text()
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M %Z'], text=True).strip()
(r / 'FROZEN.md').write_text(f'''# Frozen source and public review

Frozen {stamp}.
All eight final contracts, both definition prints and both constructors
pass this source-only review. Root owns compilation and runtime evidence.
The reviewer ran no compiler, evaluator, native, Git, network, board,
production or spawn command. No Haskell defect or fix was established.
The 172-line superseded snapshot remains pinned. The final 193-line source
has a separate acquisition record. One failed metadata freeze assertion
and its correction are retained. No source or contract changed.
MANIFEST.json lists all retained payloads. pins.json pins each payload
and the manifest. All files and directories are read-only.
''')
files = []
for p in sorted(r.rglob('*')):
    if p.is_file() and p.name not in {'MANIFEST.json', 'pins.json'}:
        b = p.read_bytes()
        files.append({'path': str(p.relative_to(r)), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
m = {'schema': 1, 'status': 'FROZEN_SOURCE_PUBLIC_REVIEW_PASS', 'created': stamp, 'scope': str(r),
     'payload_count': len(files), 'payload_bytes': sum(x['bytes'] for x in files), 'files': files}
(r / 'MANIFEST.json').write_text(json.dumps(m, indent=2) + '\n')
mh = hashlib.sha256((r / 'MANIFEST.json').read_bytes()).hexdigest()
pins = {x['path']: x['sha256'] for x in files}
pins['MANIFEST.json'] = mh
(r / 'pins.json').write_text(json.dumps({'pins': pins}, indent=2) + '\n')
actual = {str(p.relative_to(r)) for p in r.rglob('*') if p.is_file()}
assert actual == set(pins) | {'pins.json'}
for rel, h in pins.items():
    assert hashlib.sha256((r / rel).read_bytes()).hexdigest() == h
for p in r.rglob('*'):
    if p.is_file():
        p.chmod(0o444)
for p in sorted([p for p in r.rglob('*') if p.is_dir()], key=lambda p: len(p.parts), reverse=True):
    p.chmod(0o555)
r.chmod(0o555)
print(json.dumps({'status': 'FROZEN_PASS', 'timestamp': stamp, 'payload_count': len(files),
                  'payload_bytes': m['payload_bytes'], 'total_files': len(actual),
                  'total_bytes': sum(p.stat().st_size for p in r.rglob('*') if p.is_file()),
                  'MANIFEST_sha256': mh, 'pins_sha256': hashlib.sha256((r / 'pins.json').read_bytes()).hexdigest(),
                  'REPORT_sha256': hashlib.sha256((r / 'REPORT.md').read_bytes()).hexdigest(),
                  'old_union_lines': 305, 'old_modules': 14, 'old_whole_acquisitions': 0,
                  'all_readonly': all(p.stat().st_mode & 0o222 == 0 for p in [r, *r.rglob('*')])}, indent=2))
