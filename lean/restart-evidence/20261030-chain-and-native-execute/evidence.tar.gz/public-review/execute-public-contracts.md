# Execute public source contracts

These are complete source headers. Root expanded signatures are in inputs/public-eight-tail.log.

Symbol and Guard specialize to FullSyntax.Formula source labels and
constraints. Checked means SourceEqualityNativeDemand.State. Node means
Value Symbol Guard. checkedInitial means the literal partial initializer.
Both decidable equality instances remain explicit context.

## MicroCFTA.SourceCurrentAllocatedNativeStoredExecute.execute_stored

Source lines 44 through 56.

```lean
theorem execute_stored (bits : Nat) (before : Checked (bits + 2))
    (left right : Node) (fuel : Nat)
    (ready : SourceCurrentConjunctionClassScan.Ready before)
    (leftAvailable : Available before.native.machine.heap left)
    (rightAvailable : Available before.native.machine.heap right)
    (leftClosed : left.free = []) (rightClosed : right.free = [])
    (stored : Stored before.native)
    (nodes : before.native.machine.heap.nodes.next < 2 ^ bits)
    (edges : before.native.machine.heap.edges.next ≤ 2 ^ (bits + 2))
    (room : before.native.machine.domains.next +
      2 ^ (before.native.machine.heap.nodes.next +
        before.native.machine.heap.nodes.next * before.native.machine.heap.nodes.next) < 2 ^ (bits + 1)) :
    Stored (execute fuel (.code (requestNode IntersectionEmptyDomain.emptyDomain left right)) before).state.native := by
```

## MicroCFTA.SourceCurrentAllocatedNativeStoredExecute.initial_execute_stored

Source lines 73 through 84.

```lean
theorem initial_execute_stored (bits : Nat)
    (cache : Cache.State SourceEqualityPartialConstraintKey.Key)
    (heap : InternedConstructorTemplates.State Symbol Guard)
    (left right : Node) (fuel : Nat)
    (ready : SourceCurrentConjunctionClassScan.Ready (checkedInitial (bits + 2) cache heap))
    (leftAvailable : Available heap left) (rightAvailable : Available heap right)
    (leftClosed : left.free = []) (rightClosed : right.free = [])
    (nodes : heap.nodes.next < 2 ^ bits) (edges : heap.edges.next ≤ 2 ^ (bits + 2))
    (room : (checkedInitial (bits + 2) cache heap).native.machine.domains.next +
      2 ^ (heap.nodes.next + heap.nodes.next * heap.nodes.next) < 2 ^ (bits + 1)) :
    Stored (execute fuel (.code (requestNode IntersectionEmptyDomain.emptyDomain left right))
      (checkedInitial (bits + 2) cache heap)).state.native :=
```

