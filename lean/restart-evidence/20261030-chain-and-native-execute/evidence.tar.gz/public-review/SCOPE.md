# Chain bound and node execution source/public review

Source-only review assigned by Root on 2026-10-30.
Write only in this fresh directory. Keep all prior review bundles frozen.
Root owns compiler, evaluator, native, Git, network, board, production and
packaging commands. Do not spawn.
Read every new source line, all private proof branches and complete final
public statements. Wait for Root installed sources and signatures.
Check the actual successful changed-filter history and its explicit carrier
inclusion. The closed-input law must count after one actual filter result.
Do not claim original-input, reset, unchanged, intervening-writer or worker
history transport. Check the later arbitrary-fuel native execute companion
without assuming it passes before Root verification.
Use named exact OLD cuts. At most two named OLD whole or near-whole modules
are allowed. Record exact paths, hashes, ranges and cumulative unions.
Retain all payloads, display incidents and recovery evidence.
No Haskell defect or fix is established.
