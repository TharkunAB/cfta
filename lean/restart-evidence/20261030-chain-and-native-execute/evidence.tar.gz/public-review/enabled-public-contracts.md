# EnabledEmpty source contracts

Namespace SourceCurrentAllocatedNativeStoredEnabledEmpty.
Symbol and Guard specialize to FullSyntax.Formula source labels and
constraints. Node, Checked, Fourth and Queries use the exact aliases
listed in enabled-public-contracts.json. All three equality instances
remain explicit context.

## MicroCFTA.SourceCurrentAllocatedNativeStoredEnabledEmpty.call_stored

Source lines 22 through 24.

```lean
theorem call_stored (p h budget : Nat) (query : Node) (before : Checked width) (memo : Fourth)
    (stored : Stored before.native) :
    Stored (SourceCurrentAllocatedConjunctionWorker.call p h budget query before memo).state.native := by
```

## MicroCFTA.SourceCurrentAllocatedNativeStoredEnabledEmpty.check_stored

Source lines 35 through 37.

```lean
theorem check_stored (p h : Nat) (query : Node) (before : Checked width) (memo : Fourth)
    (queries : Queries) (stored : Stored before.native) :
    Stored (SourcePruningEnumerationEnabledEmpty.check p h query before memo queries).1.state.native := by
```

