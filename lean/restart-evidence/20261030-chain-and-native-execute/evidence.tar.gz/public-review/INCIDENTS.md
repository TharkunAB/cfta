# Review incidents

Two wait dispatches were aborted before execution by Root task steering.
They acquired no source and changed no file.
All 224 public-tail lines were read in seven complete displays. No display
was truncated.

Freeze helper V1 failed a stale maximum-fraction assertion. It expected
22 of 59 warm-range lines, but the final maximum was40 of 105 allocated-worker
lines. It failed before writing the marker, manifest or pins and before
changing permissions. The union stayed 305 lines over 14 modules. The exact
failure and superseded report are retained in retained-failed-freeze.
The corrected helper and final report use 40 of 105. No source or public
contract changed. This was a metadata error, not a Lean failure.

The retained 172-line chain snapshot is superseded. Its original repo
path now contains 193 lines. Its copy hash stays pinned. The current 193-line
source has a separate acquisition record.

Root reports three retained compiler candidate failures and successful
repairs. Root owns those logs and snapshots. The reviewer ran no compiler.
No final source or public-contract defect was found.
