from pathlib import Path
import json,re
r=Path('/tmp/mcfta-narrowing-chain-and-native-execute-20261030');root=Path('/home/tritlo/Code/mcfta')
modules=json.loads((r/'modules.json').read_text());new=[];contracts=[]
for name in modules:
    stack=[]
    for num,line in enumerate((root/'lean/MicroCFTA'/f'{name}.lean').read_text().splitlines(),1):
        m=re.match(r'^(namespace|section)(?:\s+(\S+))?\s*$',line)
        if m:
            stack.append(m.group(2) if m.group(1)=='namespace' else None)
            continue
        if re.match(r'^end(?:\s|$)',line):
            assert stack,(name,num)
            stack.pop()
            continue
        m=re.match(r'^theorem\s+([A-Za-z_][\w.]*)',line)
        if m:
            fq='.'.join([scope for scope in stack if scope]+[m.group(1)])
            assert fq.startswith('MicroCFTA.'),(name,num,fq)
            fq=fq.removeprefix('MicroCFTA.');new.append(fq)
            contracts.append({'module':name,'line':num,'declaration':fq})
    assert not stack,(name,stack)
assert len(new)==len(set(new))
old=json.loads((r/'prior-public-declarations.json').read_text());assert not set(new)&set(old)
(r/'new-public-declarations.json').write_text(json.dumps(new,indent=2)+'\n')
(r/'public-declarations.json').write_text(json.dumps(old+new,indent=2)+'\n')
definitions=json.loads((r/'prior-public-definitions.json').read_text())
for name in modules:
    stack=[]
    for line in (root/'lean/MicroCFTA'/f'{name}.lean').read_text().splitlines():
        scope=re.match(r'^(namespace|section)(?:\s+(\S+))?\s*$',line)
        if scope:
            stack.append(scope.group(2) if scope.group(1)=='namespace' else None);continue
        if re.match(r'^end(?:\s|$)',line):
            stack.pop();continue
        declaration=re.match(r'^(?:noncomputable\s+)?(?:def|inductive)\s+([A-Za-z_][\w.]*)',line)
        if declaration:
            fq='.'.join([v for v in stack if v]+[declaration.group(1)]).removeprefix('MicroCFTA.')
            assert fq not in definitions;definitions.append(fq)
(r/'public-definitions.json').write_text(json.dumps(definitions,indent=2)+'\n')
(r/'new-public-contract-locations.json').write_text(json.dumps(contracts,indent=2)+'\n')
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes()==(''.join('import MicroCFTA.'+name+'\n' for name in modules)).encode()+(r/'prior-Audit.lean').read_bytes()
print({'new_public':len(new),'total_public':len(old)+len(new),'by_module':{name:sum(c['module']==name for c in contracts) for name in modules},'audit_old_suffix':True})

old_definitions=json.loads((r/'prior-public-definitions.json').read_text())
definition_commands=''.join('#print MicroCFTA.'+name+'\n' for name in definitions if name not in old_definitions)
source=(''.join('import MicroCFTA.'+name+'\n' for name in modules)).encode()+(r/'prior-public-source.lean').read_bytes()+('\n'+definition_commands+''.join('#check MicroCFTA.'+name+'\n#print axioms MicroCFTA.'+name+'\n' for name in new)).encode()

public_source=r/'public-v2.lean'
if public_source.exists(): assert public_source.read_bytes()==source
else: public_source.write_bytes(source)
