# Public contracts and next exact caller target

SOURCE-ONLY DRAFT. No new law in this file has been checked.

The local notations and typeclass variables are those in the complete V2 draft.

```lean
theorem execute_stored (bits : Nat) (before : Checked (bits + 2))
    (left right : Node) (fuel : Nat)
    (ready : SourceCurrentConjunctionClassScan.Ready before)
    (leftAvailable : Available before.native.machine.heap left)
    (rightAvailable : Available before.native.machine.heap right)
    (leftClosed : left.free = []) (rightClosed : right.free = [])
    (stored : Stored before.native)
    (nodes : before.native.machine.heap.nodes.next < 2 ^ bits)
    (edges : before.native.machine.heap.edges.next ≤ 2 ^ (bits + 2))
    (room : before.native.machine.domains.next +
      2 ^ (before.native.machine.heap.nodes.next +
        before.native.machine.heap.nodes.next * before.native.machine.heap.nodes.next) < 2 ^ (bits + 1)) :
    Stored (execute fuel (.code (requestNode IntersectionEmptyDomain.emptyDomain left right)) before).state.native
```

```lean
theorem initial_execute_stored (bits : Nat)
    (cache : Cache.State SourceEqualityPartialConstraintKey.Key)
    (heap : InternedConstructorTemplates.State Symbol Guard)
    (left right : Node) (fuel : Nat)
    (ready : SourceCurrentConjunctionClassScan.Ready (checkedInitial (bits + 2) cache heap))
    (leftAvailable : Available heap left) (rightAvailable : Available heap right)
    (leftClosed : left.free = []) (rightClosed : right.free = [])
    (nodes : heap.nodes.next < 2 ^ bits) (edges : heap.edges.next ≤ 2 ^ (bits + 2))
    (room : (checkedInitial (bits + 2) cache heap).native.machine.domains.next +
      2 ^ (heap.nodes.next + heap.nodes.next * heap.nodes.next) < 2 ^ (bits + 1)) :
    Stored (execute fuel (.code (requestNode IntersectionEmptyDomain.emptyDomain left right))
      (checkedInitial (bits + 2) cache heap)).state.native
```

The next concrete actual-caller function has this existing source signature:

```lean
noncomputable def check
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
    (p h : Nat) (query : Node) (before : Checked width) (memo : Fourth)
    (queries : Queries) : SourceCurrentAllocatedConjunctionWorker.Outcome width × Queries
```

The required next postcondition is the following exact returned-state expression.
Its proof must derive all operation gates from the maintained caller context.
No preservation law for this target is claimed here.

```lean
SourceCurrentAllocatedFiniteOrdinaryStored.Stored
  (SourcePruningEnumerationEnabledEmpty.check p h query before memo queries).1.state.native
```
