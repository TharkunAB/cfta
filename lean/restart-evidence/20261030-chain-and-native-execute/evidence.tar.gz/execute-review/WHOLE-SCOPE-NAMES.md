# Named old whole files

1. `lean/MicroCFTA/SourceCurrentAllocatedRecursiveWarmInitialRanges.lean` (59 lines). Named before acquisition. This module defines the existing concrete original-input WordRanges producer.
2. Unused.

The checked NativeStoredPrefix and earlier checked NativeStoredTrace remain explicitly authorized full reuses.
