import MicroCFTA.SourceCurrentAllocatedPartialMemoSound
import MicroCFTA.SourceCurrentConjunctionClassScan
import MicroCFTA.SourceCurrentAllocatedMuRebuild
import MicroCFTA.SourceCurrentAllocatedNativeInventoryState
import MicroCFTA.SourceCurrentMemoMergeLanguage
namespace MicroCFTA.SourceCurrentAllocatedPartialInvariant
structure Context (formulas : SourceGuards.Formulas FullSyntax.Formula)
structure Post (formulas : SourceGuards.Formulas FullSyntax.Formula)
theorem Context.rebase (context : Context formulas solver inventory before memos)
theorem Post.refl (context : Context formulas solver inventory before memos) :
theorem Post.trans (first : Post formulas solver inventory before middle memos)
theorem Post.rebase (context : Context formulas solver inventory before memos)
