import MicroCFTA.SourceCurrentAllocatedConjunctionMemo
import MicroCFTA.SourceCurrentAllocatedGateFields
import MicroCFTA.SourceCurrentAllocatedSeededQuery
namespace MicroCFTA.SourceCurrentConjunctionClassScan
open SourceEqualityRequiredSemanticCache (SemanticReady)
def advanceHeap (before : Checked width) (heap : State Symbol Guard) : Checked width :=
      (primary : EndpointStatefulGateTrace.ClassTrace unconstrained reaches values paths
      (primary : EndpointStatefulGateTrace.ClassTrace unconstrained reaches values paths
      (secondary : SourceCurrentSecondaryTrace.ClassTrace unconstrained values paths heap true anchor)
      (primary : EndpointStatefulGateTrace.ClassTrace unconstrained reaches values paths
      (secondary : SourceCurrentSecondaryTrace.ClassTrace unconstrained values paths heap false anchor)
      (primary : EndpointStatefulGateTrace.ClassTrace unconstrained reaches values paths
      (secondary : SourceCurrentSecondaryTrace.ClassTrace unconstrained values paths heap false anchor)
theorem stopped_member [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem selected_sublist [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
structure Ready (state : Checked width) : Prop where
  semantic : SemanticReady state.native.machine.heap
theorem advance_ready (before : Checked width) (after : Physical) (ready : Ready before)
    Ready (advancePhysical before after) :=
theorem primary_effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (actual : EndpointStatefulGateTrace.ClassTrace unconstrained reaches values paths
    (ready : Ready before) (available : Values before.native.machine.heap values) :
    Ready (advanceHeap before heap) ∧
theorem secondary_effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (actual : SourceCurrentSecondaryTrace.ClassTrace unconstrained values paths
    (ready : Ready before) (available : Values before.native.machine.heap values) :
    Ready (advanceHeap before heap) ∧
theorem memo_effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (ready : Ready before) (available : Available before.native.machine.heap query)
    Ready (advancePhysical before after) ∧
