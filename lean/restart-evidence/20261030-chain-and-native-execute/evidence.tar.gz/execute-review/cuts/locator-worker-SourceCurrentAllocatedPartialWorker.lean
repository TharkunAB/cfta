import MicroCFTA.SourceCurrentAllocatedParentWorker
import MicroCFTA.SourceCurrentAllocatedPartialGraph
namespace MicroCFTA.SourceCurrentAllocatedPartialWorker
inductive Limit where
inductive Fault (width : Nat) : Type 1 where
inductive Outcome (Output : Type) (width : Nat) : Type 1 where
def Outcome.state : Outcome Output width → Caller width
def Outcome.bind (first : Outcome A width) (next : A → Caller width → Outcome B width) : Outcome B width :=
noncomputable def nodeCall (fuel g s r e p h m c n budget : Nat) (request : NodeRequest)
noncomputable def nodeBody (fuel g s r e p h m c n budget : Nat) (request : NodeRequest)
noncomputable def edgeCall (fuel g s r e p h m c n budget : Nat) (request : EdgeRequest)
noncomputable def edgeBody (_fuel g s r e p h m c n budget : Nat) (request : EdgeRequest)
noncomputable def rows (fuel g s r e p h m c n budget : Nat) (inherited : EqValue)
noncomputable def descendants (fuel g s r e p h m c n budget : Nat) (inherited : EqValue)
noncomputable def children (fuel g s r e p h m c n budget : Nat) (combined : EqValue)
noncomputable def walk (fuel g s r e p h m c n budget : Nat) (combined : EqValue) (index : Nat)
theorem nodeCall_ready (fuel g s r e p h m c n budget : Nat) (request : NodeRequest)
theorem edgeCall_ready (fuel g s r e p h m c n budget : Nat) (request : EdgeRequest)
theorem nodeCall_busy (fuel g s r e p h m c n budget : Nat) (request : NodeRequest)
theorem nodeCall_absent (fuel g s r e p h m c n budget : Nat) (request : NodeRequest)
theorem edgeCall_busy (fuel g s r e p h m c n budget : Nat) (request : EdgeRequest)
theorem edgeCall_absent (fuel g s r e p h m c n budget : Nat) (request : EdgeRequest)
theorem nodeCall_body_failed (fuel g s r e p h m c n budget : Nat) (request original : NodeRequest)
theorem edgeCall_body_failed (fuel g s r e p h m c n budget : Nat) (request original : EdgeRequest)
/-- Node evaluation executes the stored original and finishes that same selected handle. -/
theorem nodeCall_body_done (fuel g s r e p h m c n budget : Nat) (request original : NodeRequest)
theorem edgeCall_body_done (fuel g s r e p h m c n budget : Nat) (request original : EdgeRequest)
