import MicroCFTA.SourceCurrentAllocatedNativePhysicalCompletion
namespace MicroCFTA.SourceCurrentAllocatedNativePhysicalTraceCompletion
inductive Trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] :
theorem Trace.steps [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem Trace.trans [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem inputs_bind [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem Trace.bind [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem Trace.plan [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
structure Receipt [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
def Returned [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem Receipt.done [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem operations_trans {before middle after : SourceEqualityConstraintMemoAllocation.State}
private theorem before_step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem yielded_good [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem join [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem node_of_bodies [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem edge_of_bodies [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem code_of_bodies [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem all_bodies [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem code_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem node_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem edge_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem request_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem initial_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
