import MicroCFTA.SourceCurrentAllocatedPartialInvariant
import MicroCFTA.SourceCurrentAllocatedPartialFrames
import MicroCFTA.SourceCurrentAllocatedMuRebuild
namespace MicroCFTA.SourceCurrentAllocatedPartialCallSteps
theorem node_refl (request : NodeRequest) : NodeLaw formulas solver request request.value :=
theorem node_start {inventory : Inventory} {request original : NodeRequest}
theorem edge_start {inventory : Inventory} {request original : EdgeRequest}
theorem node_hit {inventory : Inventory} {request : NodeRequest} {before after : Caller width}
theorem edge_hit {inventory : Inventory} {request : EdgeRequest} {before after : Caller width}
theorem node_finish {inventory next : Inventory} {budget : Nat} {request original : NodeRequest}
theorem edge_finish {inventory next : Inventory} {budget : Nat} {request original : EdgeRequest}
theorem node_binder {inventory : Inventory} {inherited : SourceEqualityConstraintAllocation.Value}
