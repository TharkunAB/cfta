import MicroCFTA.SourceRecursiveIntersectionNativeApi
import MicroCFTA.InternedNormalizationFree
import MicroCFTA.IntersectConstruction
import MicroCFTA.SourceRecursiveIntersectionStep
namespace MicroCFTA.SourceRecursiveIntersectionInputView
def inputOf (value : Value Symbol Guard) : Input := (IntersectionFlatMemoKey.input value.referenceOf).getD .empty
def internedName : Reference → Option Nat
def freeNames (value : Value Symbol Guard) : List Nat := value.free.filterMap internedName
def payload (state : InternedConstructorTemplates.State Symbol Guard) (input : Input) : Value Symbol Guard :=
def shape (holds : Guard → Language.Term Symbol → Bool) : Value Symbol Guard → Shape (Payload Symbol)
def shapeEdge (holds : Guard → Language.Term Symbol → Bool) (edge : EdgeValue Symbol Guard) : Shape (Payload Symbol) :=
def shapeValues (holds : Guard → Language.Term Symbol → Bool) : List (Value Symbol Guard) → List (Shape (Payload Symbol))
def shapeEdges (holds : Guard → Language.Term Symbol → Bool) : List (EdgeValue Symbol Guard) → List (Shape (Payload Symbol))
def row (holds : Guard → Language.Term Symbol → Bool) (edge : EdgeValue Symbol Guard) : Row Symbol :=
def view (state : InternedConstructorTemplates.State Symbol Guard) (holds : Guard → Language.Term Symbol → Bool) : View Symbol where
theorem inputOf_codec (value : Value Symbol Guard) (input : Input)
theorem freeNames_member (value : Value Symbol Guard) (name : Nat) : name ∈ freeNames value ↔ Reference.interned name ∈ value.free := by
theorem payload_readback (state : InternedConstructorTemplates.State Symbol Guard) (facts : Facts state)
theorem free_readback (state : InternedConstructorTemplates.State Symbol Guard) (facts : Facts state)
theorem copy_readback (state : InternedConstructorTemplates.State Symbol Guard) (facts : Facts state)
theorem payload_selected (state : InternedConstructorTemplates.State Symbol Guard) (name : Nat) (input : Input)
theorem node_free_member (state : InternedConstructorTemplates.State Symbol Guard) (facts : Facts state)
theorem free_correct (state : InternedConstructorTemplates.State Symbol Guard) (facts : Facts state)
inductive Original : Value Symbol Guard → Prop where
theorem Original.codec (value : Value Symbol Guard) (original : Original value) :
theorem Original.free_interned (state : InternedConstructorTemplates.State Symbol Guard) (facts : Facts state)
theorem closed_readback (state : InternedConstructorTemplates.State Symbol Guard) (facts : Facts state)
theorem physical_step [DecidableEq Symbol] (state : InternedConstructorTemplates.State Symbol Guard) (facts : Facts state)
