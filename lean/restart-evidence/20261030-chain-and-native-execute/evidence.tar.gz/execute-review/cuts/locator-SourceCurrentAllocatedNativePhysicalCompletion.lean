import MicroCFTA.SourceCurrentAllocatedNativePhysicalExecution
import MicroCFTA.SourceCurrentAllocatedNativeRunning
namespace MicroCFTA.SourceCurrentAllocatedNativePhysicalCompletion
structure Good (state : CheckedState width) : Prop where
private theorem lift_native (operations : SourceEqualityConstraintMemoAllocation.State)
theorem step_fields [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem step_invariants [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem operations_trans {before middle after : Operations}
theorem execute_invariants [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem yielded_invariants [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem node_step_yields [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem edge_step_yields [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem body_prefix [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem pure_miss_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
