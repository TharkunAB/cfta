import MicroCFTA.SourceCurrentAllocatedNativeEffects
import MicroCFTA.SourceCurrentMemoMergeGraph
import MicroCFTA.SourceCurrentEmptinessMemo
import MicroCFTA.SourceEqualityConstraintAllocation
import MicroCFTA.FlatMemoThunkRunning
import MicroCFTA.FlatMemoThunkReturned
namespace MicroCFTA.SourceCurrentAllocatedPartialState
structure NodeRequest where
structure EdgeRequest where
def NodeRequest.key (request : NodeRequest) : NodeKey :=
def EdgeRequest.key (request : EdgeRequest) : EdgeKey :=
structure State (width : Nat) : Type 1 where
def initial (checked : Checked width) (merge : MergeMemo) (fourth : Fourth) : State width :=
def advance (before : State width) (checked : Checked width) (fourth : Fourth) (merge : MergeMemo) : State width :=
def beginNode (request : NodeRequest) (before : State width) :
def beginEdge (request : EdgeRequest) (before : State width) :
def finishNode (handle : Nat) (result : Node) (before : State width) : State width :=
def finishEdge (handle : Nat) (result : Edge) (before : State width) : State width :=
def NodeLinked (cache : Cache.State SourceEqualityPartialConstraintKey.Key) (request : NodeRequest) (key : NodeKey) : Prop :=
def EdgeLinked (cache : Cache.State SourceEqualityPartialConstraintKey.Key) (request : EdgeRequest) (key : EdgeKey) : Prop :=
structure Valid (state : State width) : Prop where
theorem initial_components (checked : Checked width) (merge : MergeMemo) (fourth : Fourth) :
theorem advance_tables (before : State width) (checked : Checked width) (fourth : Fourth) (merge : MergeMemo) :
theorem beginNode_components (request : NodeRequest) (before : State width) :
theorem beginEdge_components (request : EdgeRequest) (before : State width) :
theorem finishNode_components (handle : Nat) (result : Node) (before : State width) :
theorem finishEdge_components (handle : Nat) (result : Edge) (before : State width) :
theorem beginNode_ready (candidate original : NodeRequest) (before : State width) (handle : Nat) (result : Node)
theorem beginEdge_ready (candidate original : EdgeRequest) (before : State width) (handle : Nat) (result : Edge)
theorem beginNode_busy (candidate original : NodeRequest) (before : State width) (handle : Nat)
theorem beginEdge_busy (candidate original : EdgeRequest) (before : State width) (handle : Nat)
theorem beginNode_suspended (candidate original : NodeRequest) (before : State width) (handle : Nat)
theorem beginEdge_suspended (candidate original : EdgeRequest) (before : State width) (handle : Nat)
theorem finishNode_returned (handle : Nat) (original : NodeRequest) (result : Node) (before : State width)
theorem finishEdge_returned (handle : Nat) (original : EdgeRequest) (result : Edge) (before : State width)
theorem finishNode_ready (handle : Nat) (original : NodeRequest) (first second : Node) (before : State width)
theorem finishEdge_ready (handle : Nat) (original : EdgeRequest) (first second : Edge) (before : State width)
theorem initial_valid (checked : Checked width) (merge : MergeMemo) (fourth : Fourth) :
theorem Valid.advance (before : State width) (checked : Checked width) (fourth : Fourth) (merge : MergeMemo)
theorem beginNode_valid (request : NodeRequest) (before : State width) (valid : Valid before)
theorem beginEdge_valid (request : EdgeRequest) (before : State width) (valid : Valid before)
theorem finishNode_valid (handle : Nat) (result : Node) (before : State width) (valid : Valid before) :
theorem finishEdge_valid (handle : Nat) (result : Edge) (before : State width) (valid : Valid before) :
