import MicroCFTA.SourceCurrentAllocatedNativeSemanticHeap
import MicroCFTA.SourceCurrentAllocatedNativeCosts
import MicroCFTA.SourceCurrentConjunctionRowsAllocation
namespace MicroCFTA.SourceCurrentAllocatedNativeEffects
def physical (state : Checked width) : Physical := ⟨state.native.machine.heap, state.operations⟩
theorem state_valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem execute_effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
