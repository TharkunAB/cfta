import MicroCFTA.SourceCurrentAllocatedNativePhysicalCompletion
namespace MicroCFTA.SourceCurrentAllocatedNativePhysicalTraceCompletion
inductive Trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] :
  | refl (control : Control A) (state : Checked width) : Trace 0 control state control state
  | cons (control : Control A) (state : Checked width) (next : Control A) (after : Checked width)
theorem Trace.steps [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
  | refl => exact .refl _ _
  | cons _ _ _ _ _ _ _ _ one _ ih => exact .cons _ _ _ _ _ _ _ one ih
theorem Trace.trans [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
  | refl => simpa only [Nat.zero_add] using second
  | cons start before resume reached final result count inputs one rest ih =>
theorem Trace.bind [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
  | refl => exact .refl _ _
  | cons control state middle current final result count inputs one tail ih =>
theorem Trace.plan [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
structure Receipt [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
def Returned [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem Receipt.done [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem code_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem node_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem edge_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem request_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem initial_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
