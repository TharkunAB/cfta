import MicroCFTA.SourcePruningEnumerationNativeRequestArity
import MicroCFTA.SourceCurrentNativeTracePrefixBind
namespace MicroCFTA.SourcePruningEnumerationNativePrefixArity
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace)
open SourceCurrentAllocatedNativeSemanticTraceReadback
open SourceCurrentNativeTracePrefixBind (bind_prefix_cases)
private theorem pure_prefix_heap (first : A) (before after : Checked width)
    (trace : Trace fuel (.code (.pure first)) before remaining after)
private theorem finish_node_prefix_heap (handle : Nat) (first : Value Symbol Guard)
    (trace : Trace fuel (.code (.finishNode handle first (.pure first))) before remaining after)
private theorem finish_edge_prefix_heap (handle : Nat) (first : EdgeValue Symbol Guard)
    (trace : Trace fuel (.code (.finishEdge handle first (.pure first))) before remaining after)
theorem node_request_prefix_heap (request : NodeRequest Symbol Guard)
    (trace : Trace fuel (.code (requestNode request.domain request.left request.right)) before remaining after)
      Trace count (.code (compileNode original)) start rest final → Heap final.native.machine.heap) :
theorem edge_request_prefix_heap (request : EdgeRequest Symbol Guard)
    (trace : Trace fuel (.code (requestEdge request.domain request.left request.right)) before remaining after)
      Good start → EdgeReady start.native.machine original → Heap start.native.machine.heap →
      Trace count (.edgeBody original .pure) start rest final → Heap final.native.machine.heap) :
