import MicroCFTA.SourcePruningEnumerationNativeBodyPrefixArity
import MicroCFTA.SourcePruningEnumerationNativeRequestPrefixArity
namespace MicroCFTA.SourcePruningEnumerationNativePrefixArity
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace)
private theorem query_prefix_heaps (fuel : Nat) :
      Trace fuel (.code (requestNode request.domain request.left request.right)) before remaining after →
      Trace fuel (.code (requestEdge request.domain request.left request.right)) before remaining after →
theorem node_query_prefix_heap (request : NodeRequest Symbol Guard)
    (trace : Trace fuel (.code (requestNode request.domain request.left request.right)) before remaining after) :
theorem edge_query_prefix_heap (request : EdgeRequest Symbol Guard)
    (trace : Trace fuel (.code (requestEdge request.domain request.left request.right)) before remaining after) :
theorem node_prefix_edge_memo_fits (request : NodeRequest Symbol Guard)
    (trace : Trace fuel (.code (requestNode request.domain request.left request.right)) before remaining after)
  have reached := SourceCurrentAllocatedNativeSemanticTraceReadback.effects trace valid (fun _ => trivial)
