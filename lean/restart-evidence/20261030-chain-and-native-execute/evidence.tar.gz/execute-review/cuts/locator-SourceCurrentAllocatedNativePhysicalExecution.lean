import MicroCFTA.SourceCurrentAllocatedNativePhysicalCache
import MicroCFTA.SourceCurrentAllocatedNativeCodeProgress
import MicroCFTA.SourceEqualityNativeDemandHeap
import MicroCFTA.SourceRecursiveIntersectionKernelCalls
import MicroCFTA.SourceRecursiveIntersectionNativeDemandProgress
namespace MicroCFTA.SourceCurrentAllocatedNativePhysicalExecution
theorem work_checked [DecidableEq (EdgeKey Symbol Guard)]
def Inputs [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
private theorem lift_native (operations : SourceEqualityConstraintMemoAllocation.State)
theorem node_step_valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem edge_step_valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem step_valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem step_extension [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem inputs_heap [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem code_inputs [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
noncomputable def InputsThrough [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] :
theorem through_heap [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem step_invariants [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem execute_invariants [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem node_busy_impossible [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (view : IntersectSchedule.View Symbol)
theorem edge_busy_impossible [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (view : IntersectSchedule.View Symbol)
