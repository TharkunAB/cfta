import MicroCFTA.SourceRecursiveIntersectionCodeBounds
import MicroCFTA.SourceEqualityNativeDemandOperations
import MicroCFTA.SourceEqualityNativeDemandTrace
namespace MicroCFTA.SourceCurrentAllocatedNativeRequestBounds
theorem child_below [DecidableEq Symbol] (source : InternedConstructorTemplates.State Symbol Guard)
theorem children_below [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem sentinel_below [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem body_below [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
def Words (width : Nat) : Control Output → Prop
def WordRanges [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem WordRanges.current [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem WordRanges.after_trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem WordRanges.after_step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem words_before_bind (width : Nat) (control : Control A) (next : A → Code Symbol Guard B)
theorem WordRanges.before_bind [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem WordRanges.after_body [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
