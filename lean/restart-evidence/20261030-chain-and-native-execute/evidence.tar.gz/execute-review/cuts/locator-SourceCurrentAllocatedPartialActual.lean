import MicroCFTA.SourceCurrentAllocatedPartialCallSteps
import MicroCFTA.SourceCurrentAllocatedPartialChecks
import MicroCFTA.SourceCurrentAllocatedPartialForestLanguage
import MicroCFTA.SourceCurrentAllocatedPartialStepEffects
namespace MicroCFTA.SourceCurrentAllocatedPartialActual
def NodeClaim (top : Trace width budget) (request : NodeRequest) (before : Caller width)
def EdgeClaim (top : Trace width budget) (request : EdgeRequest) (before : Caller width)
def RowsClaim {inherited : EqValue} {values results : List Edge} {before after : Caller width}
def DescendantsClaim {inherited : EqValue} {value result : Edge} {before after : Caller width}
def ChildrenClaim {combined : EqValue} {values results : List Node} {before after : Caller width}
def WalkClaim {combined : EqValue} {index : Nat} {values results : List Node} {before after : Caller width}
private theorem values_grow {before after : Caller width} {values : List Node}
private theorem edges_grow {before after : Caller width} {values : List Edge}
theorem node_call {request : NodeRequest} {before after : Caller width} {result : Node}
theorem node_body {request : NodeRequest} {before after : Caller width} {result : Node}
theorem edge_call {request : EdgeRequest} {before after : Caller width} {result : Edge}
theorem edge_body {request : EdgeRequest} {before after : Caller width} {result : Edge}
theorem rows {inherited : EqValue} {values results : List Edge} {before after : Caller width}
theorem descendants {inherited : EqValue} {value result : Edge} {before after : Caller width}
theorem children {combined : EqValue} {values results : List Node} {before after : Caller width}
theorem walk {combined : EqValue} {index : Nat} {values results : List Node} {before after : Caller width}
theorem root_exact {inventory : Inventory} {identity : Nat} {value result : Node} {before after : Caller width}
