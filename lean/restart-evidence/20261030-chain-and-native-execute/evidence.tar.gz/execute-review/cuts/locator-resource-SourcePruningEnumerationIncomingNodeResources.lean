import MicroCFTA.SourcePruningEnumerationIncomingNode
import MicroCFTA.SourcePruningEnumerationIncomingObservedResources
namespace MicroCFTA.SourcePruningEnumerationIncomingNode
local notation "Memos" => EndpointMemoGateTrace.Memos
theorem initial_ranges (profile : Profile) (beforeCaller : Caller (bits + 2)) (before : Core)
    (uv : Nat) (incoming : Node) (ready : SourceCurrentConjunctionClassScan.Ready beforeCaller.checked)
        | some old => SourceCurrentAllocatedNativeRequestBounds.WordRanges
                  simpa only [decoded] using (SourceCurrentAllocatedRecursiveWarmInitialRanges.warm_initial_ranges bits beforeCaller.checked
theorem observed_resources (alphabet : List Constraint) (profile : Profile)
                      cases native : SourceEqualityNativeDemand.execute n
theorem run_complete_resources
