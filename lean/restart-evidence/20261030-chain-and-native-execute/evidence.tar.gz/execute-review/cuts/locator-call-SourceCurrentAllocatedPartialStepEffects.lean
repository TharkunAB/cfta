open SourceCurrentAllocatedNativeEffects (physical)
open SourceCurrentAllocatedNativeInventoryState (Inventory At)
open SourceCurrentAllocatedPartialInvariant (Context Post)
local notation "Checked" => SourceEqualityNativeDemand.State
    (context : Context formulas solver inventory before memos) (checked : Checked width)
    (context : Context formulas solver inventory before memos)
    (context : Context formulas solver inventory before memos)
    (context : Context formulas solver inventory before memos)
    (context : Context formulas solver inventory before memos) (combined : EqValue) (index : Nat)
