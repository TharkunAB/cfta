import MicroCFTA.SourceCurrentAllocatedPartialMemoSound
import MicroCFTA.SourceCurrentAllocatedPartialReads
namespace MicroCFTA.SourceCurrentAllocatedPartialEdgeCall
def Ranges (budget : Nat) (request : EdgeRequest) (before : Caller width) : Prop :=
def CallRanges (budget : Nat) (request : EdgeRequest) (before : Caller width) : Prop :=
structure Receipt (formulas : SourceGuards.Formulas FullSyntax.Formula)
theorem body_finite (formulas : SourceGuards.Formulas FullSyntax.Formula)
theorem evaluated (formulas : SourceGuards.Formulas FullSyntax.Formula)
theorem ready_hit (formulas : SourceGuards.Formulas FullSyntax.Formula)
theorem fresh (formulas : SourceGuards.Formulas FullSyntax.Formula)
private theorem not_absent (request : EdgeRequest) (before : Caller width)
theorem finite_or_busy (formulas : SourceGuards.Formulas FullSyntax.Formula)
