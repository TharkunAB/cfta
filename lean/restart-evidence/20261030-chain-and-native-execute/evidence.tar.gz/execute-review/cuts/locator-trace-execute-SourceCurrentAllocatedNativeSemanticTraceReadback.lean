import MicroCFTA.SourceCurrentAllocatedNativePhysicalTraceCompletion
import MicroCFTA.SourceCurrentAllocatedNativeReferenceMeaning
namespace MicroCFTA.SourceCurrentAllocatedNativeSemanticTraceReadback
theorem inputs_before_bind [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem code_fields_before_bind (operations : SourceEqualityConstraintMemoAllocation.State)
theorem fields_before_bind (control : Control A) (next : A → Code Symbol Guard B) (state : Checked width)
theorem after_step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
  | refl => cases one
  | cons control before rest current final after count inputs actual tail =>
theorem current_inputs [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
  | refl => trivial
  | cons control before next middle final after count inputs one tail => exact inputs
theorem work_readback [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem bind_inverse [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem effects [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
  | refl control state => exact ⟨valid, .refl _, SourceEqualityRequiredCache.pure_keeps _ valid.heap,
  | cons control state next current final result count inputs one tail ih =>
theorem bind_readback [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
inductive Walk [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (call : A → Code Symbol Guard B) :
  | cons (first : A) (rest) (before middle after : Checked width) (value values firstFuel restFuel)
theorem Walk.trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
  | cons first rest before middle after value values firstFuel restFuel called tail ih =>
theorem walk_readback [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
  | cons first rest ih =>
theorem cons_readback [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem walk_work_readback [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
