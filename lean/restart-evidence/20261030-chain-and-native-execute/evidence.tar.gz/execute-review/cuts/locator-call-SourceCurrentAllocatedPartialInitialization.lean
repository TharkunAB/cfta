open SourceCurrentAllocatedNativeInventoryState (Inventory)
local notation "Checked" => SourceEqualityNativeDemand.State
local notation "Context" => SourceCurrentAllocatedPartialInvariant.Context
    Context formulas solver (inventory expression value heap built) (caller width final heap) globals ∧
  have admitted := SourceCurrentAllocatedNativeInventoryState.initial
  have context : Context formulas solver (inventory expression value heap built)
