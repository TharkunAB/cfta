# Actual caller transport to checked native prefix certificates

Owner: /root/stored_prefix_review. Write only this fresh scope. Keep the prior prefix bundle frozen.
Source-only task. No compiler, evaluator, native command, Git, network, board, production, packaging or spawning. Root owns these actions.
Find the narrowest actual execute-observation to checked prefix producer. Derive real Inputs, Fields, Good, SemanticReady, Clean and initial Stored from existing entry gates where possible.
Do not replace a future Trace, EnabledEmpty callback, completion or desired result by a renamed supplier. Report missing gates exactly if no concrete theorem closes.
Explicit whole reuse: checked NativeStoredPrefix342L SHA6312a299e110065b4dd53fcc1e9b32d6980ab945d6b27b611848cf02475877ef and prior StoredTrace.
At most TWO newly named OLD whole or near-whole files. Name before acquisition. Ask Root before any third.
Retain source hashes, exact cuts, locator records, cumulative unions, failures, versions, complete contracts and report. Freeze all files before stopping.
The full original-input finite enumeration goal remains open. No Haskell defect/fix is established.
