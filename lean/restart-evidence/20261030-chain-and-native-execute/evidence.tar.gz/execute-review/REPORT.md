# Native execution to checked-prefix transport

Status at 2026-10-30 23:27 CET: source-only draft. No compiler or evaluator ran.
Root has checked the prior five NativeStoredPrefix laws. Those checked laws are
inputs to this draft. The two new public laws below are not checked yet.

## Result

`NativeStoredExecute-v2-UNCOMPILED.lean` is the final candidate. It has 90 lines.
It adds two public laws and one private trace lemma. V1 remains in this bundle.
V2 changes a local notation and a binder name to avoid a possible parser clash.
It does not change the proposed statement or proof method.

The candidate removes the supplied physical Trace from one concrete native
caller path. It covers the literal empty-domain node request that
`SourcePruningEnumerationIncomingNode.run` sends to
`SourceEqualityNativeDemand.execute`. It covers every supplied fuel, including
zero. Its conclusion concerns the native state in the actual returned Outcome.

The public warm-entry law needs these current entry facts:

- `SourceCurrentConjunctionClassScan.Ready before`.
- Both operands are available in the current heap and have no free names.
- The current native tables satisfy the existing conditional `Stored` predicate.
- The current node counter is less than `2 ^ bits`.
- The current edge counter is at most `2 ^ (bits + 2)`.
- The current domain counter plus the existing finite source-inventory bound is
  less than `2 ^ (bits + 1)`.

It does not take a Trace, Steps proof, InputsThrough, WordRanges, Fields,
Original proof, body-return proof, completion certificate, or desired result.
The initializer law supplies native Stored from the literal checked initializer.
It retains Ready, available/closed operands and current numeric admission.

The complete bounded signatures are in `PUBLIC-CONTRACTS.md`. The complete
candidate is in `NativeStoredExecute-v2-UNCOMPILED.lean`.

## Why the public entry facts produce a trace

The existing concrete source route is stronger than a supplied-word-safety gate.

1. `SourceCurrentConjunctionClassScan.Ready` supplies Good, SemanticReady and
   native Idle. Its other fields are costs and scopedCache.
2. `SourceRecursiveIntersectionOriginalOutput.closed_original`, as used in
   `IncomingNodeResources.initial_ranges`, derives Original from current
   coherent heap, availability and closed syntax.
3. `RecursiveWarmInitialRanges.warm_initial_ranges` derives WordRanges from
   Good, SemanticReady, Original/Available operands and the three CURRENT counter
   inequalities. It needs no idle assumption or completed execution.
4. `PhysicalTraceCompletion.initial_complete` then constructs a physical
   Receipt internally. It derives the original-root schedule bound. Its public
   WordRanges premise was discharged in step 3. The draft instantiates its
   arbitrary guard interpretation with the constant Boolean function. Only its
   physical Receipt is used. No semantic guard claim follows from that choice.
5. The private `execute_state_prefix` lemma follows the actual execute recursor.
   At zero fuel, the observed state is the entry state. At a trace cons, it uses
   that cons's exact Inputs witness and actual yielded-step equality. At the
   final pure control, the actual done step has the same state. This proves that
   the actual returned state equals a state on the internally constructed
   physical Trace. No new check is supplied by a caller.
6. The checked `NativeStoredPrefix.node_prefix_stored` supplies the native
   Stored conclusion at that exact observed state. This law derives literal
   query Fields and Clean internally.

This route derives a completed Receipt inside the proof from current original
entry facts. It does not add a future completion premise to the public result.
The private helper consumes that derived receipt. This distinction must remain
explicit in any review or published account of the result.

The observed run is a deterministic prefix of the constructed checked run.
The candidate does not add a generic law for arbitrary mixed controls, active
warm entries, or terminal states that lack their physical Inputs witnesses.

## Exact relation to the actual caller

`IncomingNode.run` reads an old pending node handle. On successful lookup it
runs this expression:

```lean
SourceEqualityNativeDemand.execute nativeFuel
  (.code (SourceRecursiveIntersectionCode.requestNode
    IntersectionEmptyDomain.emptyDomain incoming old))
  beforeCaller.checked
```

The proposed `execute_stored` conclusion is the native Stored property of this
exact expression's returned state. `IncomingNodeResources.initial_ranges`
already shows how the actual entry facts provide the required data:

- `PendingRealized` gives old availability and closed syntax for the actual
  pending slot.
- Its supplied incoming facts give incoming availability and closed syntax.
- `ready` supplies the required physical and semantic entry facts.
- `fits.room room` gives the three current inequalities used by the draft.

The raw caller's `other` branch advances with `other.state`. The done branch
continues with the query's checked state. Thus this result removes the raw
native-query transport gate in both branches, conditional on native Stored at
entry. It does not prove the subsequent EnabledEmpty phase preserves Stored.

## Remaining actual-caller gates

`SourceCurrentAllocatedPartialInvariant.Context` has Ready, admission, outer
partial memo soundness, merge Stored, merge coverage, fourth-memo correctness,
global memo validity and probe heap fields. Its named `stored` field is
`SourceCurrentMemoMergeEffects.Stored ... state.merge`. It is not the new
conditional native Stored type. This bounded review found no existing derivation
of the new native Stored type from Context. That is an absence of a producer in
the inspected cuts, not a proof that no derivation exists elsewhere.

The next caller invariant must include the native Stored fact, or derive it
from a stronger existing invariant. The literal initializer already supplies
this fact. It must then pass through every actual caller phase that can alter
native state. The new candidate covers the raw closed root native node request
under the current original numeric admission gates.

The next small concrete transport target is the actual
`SourcePruningEnumerationEnabledEmpty.check` result. Its exact source signature
is retained in `PUBLIC-CONTRACTS.md` and `cuts/EnabledEmpty-check-L17-L36.txt`.
The query memo can bypass the conjunction worker and return the same state. Its
other branch calls `SourceCurrentAllocatedConjunctionWorker.call p h 1000 ...`.
That actual worker branch needs a native Stored preservation proof through its
constructor, equality, descendant and recursive-query operations. Its required
current per-call native inputs and numeric admission must be derived from the
existing caller resource invariants. A supplied output Stored, supplied future
trace, or supplied per-iteration success/coverage predicate would leave this
producer gate open.

The concrete remaining conclusion is:

```lean
SourceCurrentAllocatedFiniteOrdinaryStored.Stored
  (SourcePruningEnumerationEnabledEmpty.check p h query before memo queries).1.state.native
```

It must follow from native Stored at entry and the actual caller's maintained
entry/resource invariants. This review does not assert that Ready alone, or
Ready plus the first raw query's entry counter inequalities alone, is sufficient
for every later conjunction operation. No such sufficiency lemma was found or
claimed in this bounded review.

Once that branch has a checked producer, the next caller theorem should add
native Stored to the result of `IncomingNodeResources.run_complete_resources`.
The existing theorem's full input list is retained through line 201 in the
acquired cut. It includes Context, PendingRealized, StorageValid, root/pending
facts, available/closed incoming, bounded suspended variables, Fits/Room and
known alphabet heap. The theorem currently produces successful actual
observations and current resource/context facts. Its supplied inputs must derive
the new native Stored postcondition. An added native Stored postcondition
supplier would not close this gate.

## Boundaries

This is a native IR state-invariant transport draft. Stored remains its existing
conditional native cache certificate. The draft does not turn it into an
unconditional certificate for all recursive memo results. It does not prove
sufficient original enumeration depth, finite global enumeration coverage,
whole-caller preservation through EnabledEmpty, whole-execution termination, a
public API theorem, or Haskell correspondence.

No Haskell source changed. No admitted actual Haskell execution occurred. No
Haskell defect or fix was established. There is no new Haskell FINDINGS entry.

## Scope, provenance and incidents

All work stayed in `/tmp/mcfta-native-prefix-caller-review-20261030`. The prior
prefix bundle remains frozen. There was no production write, Git operation,
compiler, evaluator, native execution, network, board access, or spawned worker.

The two exact full reuses authorized by Root are:

- NativeStoredPrefix, 342 lines, SHA-256
  `6312a299e110065b4dd53fcc1e9b32d6980ab945d6b27b611848cf02475877ef`.
- NativeStoredTrace, 290 lines, SHA-256
  `e12f40e084180ab303d4d06301ecec61f927865c0cfd141db17daeed563da8a4`.

One newly named OLD whole module was acquired:
RecursiveWarmInitialRanges, 59 lines. It was named before acquisition. The
second OLD whole-module slot remains unused. Other acquisitions are declaration
locators and exact bounded cuts. The largest other old-module union is
NativeEffects, 28/50 lines. See `CUMULATIVE-SOURCE-UNIONS.json` for every union.

`acquisitions.json` records source absolute paths, full source hashes, full
source byte/line counts, exact acquired ranges or locator line numbers, copy
paths and copy hashes. Repeated cuts use the same source hash. Raw locator
outputs and stderr are retained. The only incident was a Python regex string
SyntaxWarning; the process returned 0 and produced complete data. See
`INCIDENTS.md`. No theorem was claimed checked because of a source inspection.
