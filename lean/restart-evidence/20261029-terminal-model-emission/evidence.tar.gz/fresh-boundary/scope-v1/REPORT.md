# Fresh native boundary keys and actual narrowing observations

Timestamp: 2026-10-28 23:48:09 CET.
Root supplied base `73b3f496ea0eb4ddfb0b784cf4ae1393d4325cfa` and reported the branch up to date. The author ran no Git command.

## Delivered candidates

1. `candidate-v1/MicroCFTA/SourcePruningEnumerationBoundaryFreshness.lean`
   40 lines; 2194 bytes; SHA256 `2194939b0aaebe26dc714b564718f36ae907b6346680aad8c8304420f84fa5a4`.
   Root reports exact-source default and strict PASS. The author did not compile.
2. `candidate-v1/MicroCFTA/SourcePruningNativeViewObservedOrdinary.lean`
   60 lines; 2988 bytes; SHA256 `66a0eac49e76598c4e8af5685aa3a93b48cc7155c61b80bd5209632ad9aaadfa`.
   UNTESTED source candidate. Root owns installation and verification.

The first candidate remains unchanged. The second candidate is a separate source file.

## Exact first theorem

`SourcePruningEnumerationRecursionOrder.checkRepeated_false_fresh`

Explicit arguments: `heap fuel uv handle scs value before after decoded boundary observed`.

`decoded` is the actual lookup of `handle` in `heap`. `boundary` says that this decoded value is a recursive boundary. `observed` is the literal successful false `checkRepeated` observation. The result supplies its real resolved representative, the actual successful `representative fuel uv` observation at the same returned state, and absence of `recursionKey handle scs` from that state's recursion ancestry at that representative.

The proof inverts the actual boundary check. The seen-key branch cannot return false. The unseen-key branch returns the exact resolved state. The theorem needs no assumed freshness, Total, Ready, canonical state, model, later key, or later handle bound.

## Exact second theorem

`SourcePruningNativeView.narrowAt_done_ordinary`

Explicit arguments: `fits admits fuel key value before result after ready available closed observed`.

The original state satisfies `SourceEqualityRequiredCache.Ready before`. The original value is available and closed. The literal actual observation is `narrowAt fits admits fuel key value before = .done result after`. The conclusion is `SourceEqualityRequiredCache.Ordinary result` for that exact result.

A private helper derives exact stability of an actual successful narrowing point from `MergedFreshOrdinaryColdReplay.nodeEdges_stable`. The public proof calls `narrowAt_complete` once with the original resources. It compares the actual full outcome with that producer's genuine full outcome at the sum of their two fuel values. This identifies the same result and heap. The producer's ordinary-result fact then applies to the actual result. No future heap, ordinary-output premise, model, or preservation supplier is assumed.

## Actual selected-prefix order

1. `SelectedStep.runPrefix` reads `oldHandle` and `scs`. It runs the recursion check on that exact pair.
2. `Action.prepare` narrows `oldValue`. If the encoded result is `newHandle = oldHandle`, its action is pure. Otherwise its action resolves the same selected variable and writes `newHandle` with the same suspended bucket.
3. `NarrowAdapter.adapt_core` retains the exact observed action core. The Right recording branch is a pure no-op by `recordTypes_inr`.
4. `SelectedContinuations.run` calls `SelectedPreparation.run` on that actual candidate. The preparation runs Entry first. Entry reads the current stored handle and sets expansion ancestry. Only then does SelectedValue unfold Mu or expose Union. The prepared result is distinct from Entry's decoded stored value.

The generic action permits old and new handles to differ. That fact alone is not a boundary-insertion obstruction. `OuterNarrow.narrow_mu` retains Mu at every fuel. `narrow_type` retains raw type members. All other inputs use `narrowAt`. The second candidate derives that any successful fallback result is ordinary from the original resources. Such a result is neither Mu nor explicit Union. Therefore an actual later boundary value should force a retained branch. The original coherent lookup/encoding identity then identifies its handle with the checked handle.

The exact next connection is still to be proved: retain the actual prefix observations, show that a later boundary Entry uses the checked key, and align the checked representative with Entry's actual captured representative. Do not assume equality of old and new handles as a general native narrowing fact.

## Deduplicated size and remaining scope

Entry uses `(key :: priorRecursionAncestryAtTarget).eraseDups`. For an actually fresh key this equals `key :: priorRecursionAncestryAtTarget.eraseDups`, so its length increases by one over that deduplicated root ancestry. Existing `List.eraseDups_cons` and `List.filter_bne_eq_self_of_not_mem` supply the list step. No new generic list wrapper is needed.

Entry overwrites `expansionAncestry`. The size baseline is the target's prior recursion ancestry, not the previous expansion list. A global monotonic increase of the former expansion list does not follow from this local operation.

No full prefix identity or Entry size theorem is claimed in these candidates. No global finite native handle universe, global completion bound, sufficient recursive depth, or model-emission theorem is proved here.

## Evidence and ownership

`MANIFEST.json` records complete candidate signatures and identities, copied source identities, literal read cuts, current source equality at seal, and verification ownership. Partial reads remain partial in the manifest. Complete source snapshots are provenance artifacts; they do not imply that unlisted source ranges were read. Some exploratory command output was truncated; only the retained focused read ranges are listed.

Both candidates and this report are immutable. The author ran no compiler, evaluator, native execution, Git, network, or board operation. No repository file changed. No Haskell finding arose.
