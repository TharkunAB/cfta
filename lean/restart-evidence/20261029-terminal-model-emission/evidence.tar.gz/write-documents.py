"""Save exact terminal-emission and boundary-budget contracts without deleting prior text."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,shutil
ROOT=Path('/home/tritlo/Code/mcfta');AREA=Path('/tmp/mcfta-prepared-model-emission-20261028')
source=json.loads((AREA/'source-publication.json').read_text())['source_head'];board=json.loads((AREA/'board-post-verification.json').read_text());stamp=datetime.now(ZoneInfo('Europe/Stockholm')).strftime('%Y-%m-%d %H:%M %Z')
header=f'''# Verified terminal callback emission and checked boundary budgets — {stamp}

Source `{source}` is pushed and verified on formalize. Full goal ACTIVE.
Read `lean/notes-current-terminal-model-emission.md` for exact contracts and next work.
Every earlier document byte remains below unchanged.

An original valid callback model and empty candidate list now construct the
actual Left recording result and exact prepared singleton emission at every
recursive depth. The same assignment, Packet, frame, metadata fields and pending
refutation reach that emitted cache. No future output or restart supplier is an
input. This is the terminal callback case. DONE does not imply Discharged.

Actual selected Mu/Union preparation keeps the same original Mu body degree
ceiling. Actual false boundary checking derives freshness. Successful fallback
narrowing is ordinary; an actual boundary result instead retains its original
value and heap and selects the identity enumeration action. The checked action
and original model derive a finite unused shape and strict per-handle decrease
IF THAT EXACT KEY IS INSERTED. Full indexed-prefix/entry linkage remains open.
A uniform native-handle bound and nonterminal chosen-output induction remain.

Strongest semantics remains conditional checked rendered soundness under
fixed-PCS/whole-Discharged and ordered output-prefix retention at greater depth.
Source-derived sufficient depth across earlier callbacks remains the main gap.
Existing closed unfolding refutes NoNewMu/startup-only Mu inventory and
monotonically decreasing cached depth. It does not refute termination.

Eight modules/10 public theorems/one finite proof-domain function: 518 lines,
29,349 bytes. All nine final strict sources pass. Audit: 4,580 jobs/81,876 theorem
dependencies. Compiler matrix: 29 commands, 24 passes, five preserved failures;
all final inputs pass at serial 4 GiB/swap zero. Public: 787 theorem readbacks,
67 definition bodies, 3,376,571 bytes SHA256
b966ceaf09c9ec31ed06c5a6c73bff9fa42205c2292ef0206dac5d92406c5dde.
Prior 3,357,308 bytes remain an exact prefix. All 19,263 new bytes were read.
All 4,571 old non-Audit Lean, 420 stronger-source and 817 Haskell/Cabal hashes
remain. No Haskell source changed. No Haskell check ran. No new Haskell defect
or fix was established. FINDINGS retains earlier external repair records.

Evidence: `lean/restart-evidence/20261029-terminal-model-emission/`.
Board {board['sequence']}: `{board['post_id']}`, exact verified author/content/metadata.
Preserve frozen evidence. Continue in a new writable area. Refresh upstream
first. Keep compiler/native jobs serial under the measured 4 GiB cap. Standing
push permission covers git@github.com:TharkunAB/cfta.git refs/heads/formalize.
The full goal remains ACTIVE and incomplete.

---

'''
note=f'''# Actual terminal callback emission and checked boundary budgets

Checked at {stamp}. Source `{source}` on formalize.
The full formalization goal remains ACTIVE and incomplete.

## Current strongest claim

The Lean model of the optimized interned core has conditional checked rendered
soundness under its semantic/resource contracts, fixed-PCS and whole-Discharged.
Increasing recursive depth retains the existing ordered output prefix. The
finite prepared worker retains its actual resources and histories, canonical and
proper storage, arity and physical projection under its original input gates.
Those results do not assert that a chosen model is eventually emitted.

This checkpoint constructs an actual emitted cache for the terminal recording
case. It also derives actual local boundary retention and a finite shape budget
at one native handle. General recursive chosen-model emission, source-derived
sufficient depth and Haskell correspondence remain open. Configured stop can
emit a partial output. DONE does not imply Discharged.

## Actual terminal emission

`PreparedRecursive.callback_no_candidates_emits_models` starts with ORIGINAL
Packet, allocated fragment, empty original candidate list, original Satisfies,
fragment self-fill, pending Refutes and template/program policies. It constructs
one callback work bound, updated metadata and actual returned core. It retains
Packet, RenderStable, Frame, all original metadata equalities, the SAME assignment
model and pending refutation at the framed cache.

At every greater work fuel, the actual Left recordTypes call is exactly one
successful non-rejecting result. At EVERY recursive depth, the actual prepared
continueWith/resume call is exactly a complete singleton output with metadata
none, that framed cache, the original caller and original query memo. The proof
derives the actual done decision from the empty ORIGINAL candidate list and the
recording frame. It supplies no actual callback equation, future output/model,
recursive-success hypothesis or restart-decision supplier as an input.

The old core callback producer supplies actual recording and its bound. The
proof discards its nominal old continuation equation and reduces the actual
prepared worker. It does not cast an old worker into a new one. The result does
not establish Discharged, whole chosen-term rendering, or the nonterminal case.
It does not imply that an arbitrary accepted head leaves no candidates.

## Original Mu degree ceiling

`SelectedValue.run_mu_bounded` takes original SemanticReady, Available, closedness,
Bounded before limit and the literal completed selected-value observation. It
proves Bounded after with the SAME ORIGINAL limit. Actual Mu unfolding derives
Lower internally. Actual Union exposure retains the ceiling and its final
ordinary makeNode adds no Mu. Other completed value cases retain the heap.
No later bound, Lower or inventory membership is assumed.

The degree is the stored Mu body's structural degree. It differs from the
cached Value.depth. The existing initial_bounded theorem can derive an original
ceiling from an original heap. This local theorem does not prove that the same
ceiling survives all later native conjunction/query allocation. A degree ceiling
also does not bound the number of distinct lower-degree Mu identities.

## Actual boundary retention and finite shape budget

`RecursionOrder.checkRepeated_false_fresh` derives an actual representative
success and absence of the exact checked key in that returned representative's
recursion ancestry. Inputs are literal decoded boundary and successful false
check observations. Total, Ready, a model and key absence are not inputs.

`NativeView.narrowAt_done_ordinary` derives Ordinary for ANY literal successful
narrowAt observation from ORIGINAL Ready, Available and closedness. It lifts the
actual cold read and the original constructive producer to a common summed fuel.
Their actual result and heap identities agree. It does not assume a later heap
invariant or an ordinary-result supplier.

`OuterNarrow.narrow_boundary_retained` uses that observed theorem. Actual fallback
narrowing produces only empty or ordinary nodes. Therefore an ACTUAL Mu/Union
result must use the original retention branch. Its full value and heap equal
the original input. `Action.prepare_boundary_retained` then derives the identity
enumeration action from the ORIGINAL encoded handle. It does not assume equality
of a later handle. Generic old/new handle change alone is not an obstruction to
boundary insertions. The original Mu and raw type branches must be kept distinct
from ordinary fallback narrowing in the complete prefix proof.

`KeyShapeBudget.unused carrier handle history` filters a finite original carrier
for shapes whose exact handle key is absent. Its length is bounded by the
original carrier length. History inclusion cannot increase it. Inserting the
SAME fresh key, with its shape in the carrier, strictly decreases it, including
the actual eraseDups representation. Carrier duplicates are permitted. The
proof claims strict decrease, not an exact one-element length difference.
This pure module imports only EnumerationState.

`CheckedBoundaryBudget.checked_action_shape_budget` composes actual false-check,
actual prepared boundary and actual action-success observations. Original
model/origin/canonical/live stored-slot evidence derives actual key membership
in keyShapes whole. The same action leaves the enumeration core unchanged.
The checked key is absent at the returned representative, so its shape is in the
finite unused family. Inserting THAT EXACT checked key would strictly decrease
the remaining per-handle budget. Freshness and shape membership are conclusions,
not extra hypotheses. Actual check/action success remain explicit observations.

This last theorem does NOT execute or identify the complete indexed prefix and
later Entry. It does not yet show that every real insertion consumes this budget.
Full prefix/entry linkage is the next local operation. The baseline is the old
resolved target's recursionAncestry, not its former expansionAncestry. Allocation
inherits expansion keys and stale old fresh-counter slot ancestry; the earlier
all-slot KeyAncestry result remains necessary.

## Existing counterexamples and rejected measures

The unchanged SourceColdUnfoldNewMuBoundary constructs mu x. mu y. f(x,y) in an
empty Nat/Unit cache with the repaired constructor. It proves successful closed
construction and unfolding, endpoint semantic heaps, coverage, availability and
closedness. The returned Mu was absent from the source inventory and resident
in the final heap. Cached depth increases from 2 to 3, node count from 13 to 17.
The repaired cold reader still completes with one edge and count 18.

Thus complete startup Mu inventory and decreasing cached depth are false general
measures. This is an existing kernel-proved source witness. It is not whole
prepared Packet divergence, a Haskell defect or a counterexample to every finite
structural carrier. The new body degree ceiling is compatible with new lower-
degree Mu records. It does not restore NoNewMu or cached-depth decrease.

The old source note attributes the witness to 0534aad8 and records historical
aggregate validation. Its cited old /tmp audit/native logs are absent. The
source, historical attribution and missing-log limitation are retained in this
checkpoint. No historical native run was repeated or represented as recovered
raw evidence. The current aggregate Audit includes the unchanged witness.

## Main remaining work

1. Connect the derived boundary identity/action freshness through the COMPLETE
   indexed runPrefix, Right recording and actual Entry. Keep the exact handle,
   suspended bucket and representative. Derive the actual inserted-key budget
   decrease from those observations. Do not add freshness as a new supplier.
2. Derive a source-bound structural native boundary family or suitable handle
   cardinality bound across actual generated conjunction/query allocation. The
   original Mu body degree bound is one component. Per-current-heap inventory,
   Fits/Reserved at supplied depth and raw startup Nat lists do not solve this.
3. Prove nonterminal chosen-output/model induction through actual recursive
   emission. The original model must select an actual branch. Fresh assignments
   remain branch-specific because numeric fresh slots can be reused by siblings.
4. Prove sufficient depth from original source inputs, including all earlier
   allocating callbacks, or prove a valid same-target emission argument. An
   earlier stopped hook can prevent reaching a later selected row. Finite-output
   stability, local non-stuck and the new terminal case do not solve this.
5. Discharge remaining policy/solver/origin/public API contracts and prove
   optimized Haskell correspondence. Preserve older constructor/equality work.

## Validation and exact restart evidence

Eight additive modules: 518 lines/29,349 bytes; 10 public theorems, two private
proof helpers and one finite proof-domain function. Enumerator/native/Haskell
runtime definitions are unchanged. All eight plus Audit pass nine exact strict
Lean 4.34.1 checks with warningAsError=true and linter.all=true. Audit passes
4,580 jobs and checks 81,876 theorem dependencies. Only propext,
Classical.choice and Quot.sound are allowed. Counts are validation evidence.

29 serial compiler commands have 24 passes and five preserved failures. All
final inputs pass. The budget drafts had a list result type error, unavailable
sublist notation and an unavailable convenience tactic. Explicit core types and
Nat order proofs fixed them. The boundary action draft required qualified native
State types; its first strict check rejected a redundant simp argument. Removal
fixed it. No final semantic hypothesis changed. All failed inputs, full raw logs
and later repairs are retained. All commands have measured memory.max/high
4,294,967,296 and swap max zero. No budget increase, custom axiom, native_decide,
placeholder or linter suppression was added.

Public: 787 theorem checks/axiom lists and 67 definition bodies; 3,376,571 bytes,
SHA256 b966ceaf09c9ec31ed06c5a6c73bff9fa42205c2292ef0206dac5d92406c5dde.
The prior 3,357,308 bytes are an exact prefix. All 19,263 new bytes were read in
two complete contiguous ranges. No new public display cut remains. All 4,571 old
non-Audit Lean, 420 stronger-source and 817 Haskell/Cabal identities remain.
Audit keeps its complete prior body after eight imports. Twenty prior document
bodies remain exact suffixes. Twenty-one final documents are retained.
Three source-scope manifests verify 112 artifact identities. Historical Audit
source identity is checked against retained prior-Audit and its current exact
suffix. Literal source cuts remain literal cuts. Historical UNTESTED labels
remain; final source hashes identify the actual checked versions.

## External Haskell repair record

No Haskell source changed. No Haskell check ran. No new Haskell defect or fix
was established. The five failures concern new Lean proof elaboration or strict
linting. The old native measure witness and the remaining handle-family gap are
not new Haskell defects. FINDINGS.md retains all previous external repair records.
Record every later Haskell defect, proposed repair, actual fix and focused
reproduction there so another worker can act on it.

## Publication and restart

Four source commits end at `{source}`. Exact remote and tracking
heads match on git@github.com:TharkunAB/cfta.git refs/heads/formalize.
Origin/main d1ca06a1dd0c7488205feda613b529df21a08669 is an ancestor.
Normal formalize pushes remain explicitly authorized. Refresh upstream before
new work. Preserve all proofs, counterexamples, repairs, marked drafts and
unrelated work. Do not change remote or SSH configuration. The working SSH
route uses ssh.github.com port443 with the existing trusted github.com key.

Board {board['sequence']}, post `{board['post_id']}`, has exact verified
author/content/metadata. The shared project note uses the msg-board skill.
Complete unfiltered evidence: lean/restart-evidence/20261029-terminal-model-emission/.
Its README and standard-library verifier reconstruct every sealed regular file
from /tmp/mcfta-prepared-model-emission-20261028/. This includes failures,
candidates, full command input snapshots and logs, public bodies/types/axioms,
scopes, all prior/final documents, measurements, Git and board receipts. Use a
fresh extraction destination. Preserve reconstructed and frozen evidence.

Read this note and the front matter of NEXT-PROMPT.md, HANDOFF.md and FINDINGS.md.
Continue in a NEW writable directory. Compiler/native jobs stay serial under the
existing 4 GiB cap. Do not repeat passing source checks unless their inputs change.
The full goal stays ACTIVE. This checkpoint is not whole-system completion.
'''
records=[];old=json.loads((AREA/'prior-documents.json').read_text())
for row in old:
 path=ROOT/row['path'];before=(AREA/'prior-document-bodies'/row['path']).read_bytes();assert path.read_bytes()==before
 addition=header
 if row['path']=='FINDINGS.md':addition+='External Haskell repair record: no Haskell change/check and no new defect/fix.\nThe old NoNewMu/cached-depth witness remains a rejected-measure counterexample.\nThe five current repairs affect only new Lean proof elaboration or linting.\nAll earlier external repair records follow unchanged.\n\n'
 path.write_bytes(addition.encode()+before);raw=path.read_bytes();assert raw.endswith(before);records.append(dict(path=row['path'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
path=ROOT/'lean/notes-current-terminal-model-emission.md';assert not path.exists();path.write_text(note);raw=path.read_bytes();records.append(dict(path=str(path.relative_to(ROOT)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
(AREA/'final-documents.json').write_text(json.dumps(records,indent=2)+'\n');dest=AREA/'final-document-bodies';dest.mkdir()
for row in records:
 target=dest/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/row['path'],target)
(AREA/'source-head.json').write_text(json.dumps(dict(head=source),indent=2)+'\n');print(json.dumps(dict(documents=len(records),old_exact_suffixes=len(old),time=stamp,new_note_bytes=len(raw))))
