import MicroCFTA.EnumerationDriver

/-!
# Complete frames for enumeration path compression

The frame preserves every nonforest field and every root path with its size.
It makes no claim about equal lookup fuel in different forests.
-/

namespace MicroCFTA.EnumerationCompressionFrame
open Language Fragments EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationDriver

local instance : Monad List where
  pure value := [value]
  bind values continuation := values.flatMap continuation

variable {Symbol Guard : Type}

/-- Compression changes only the forest and preserves exact root paths. -/
structure Frame (before after : State Symbol Guard) : Prop where
  /-- Compression keeps the allocation counter. -/
  counter : after.counter = before.counter
  /-- Compression keeps every stored slot. -/
  values : after.values = before.values
  /-- Compression keeps every residual obligation. -/
  obligations : after.obligations = before.obligations
  /-- Compression keeps the complete per-variable ancestry function. -/
  recursionAncestry : after.recursionAncestry = before.recursionAncestry
  /-- Compression keeps the current expansion ancestry. -/
  expansionAncestry : after.expansionAncestry = before.expansionAncestry
  /-- Every finite root path has the same representative and size. -/
  reaches : ∀ uv root size,
    UnionFind.Reaches after.representatives uv root size ↔
      UnionFind.Reaches before.representatives uv root size

/-- An unchanged state satisfies the complete frame. -/
theorem Frame.refl (state : State Symbol Guard) : Frame state state :=
  ⟨rfl, rfl, rfl, rfl, rfl, fun _ _ _ => Iff.rfl⟩

/-- Consecutive frames preserve the same fields and root paths. -/
theorem Frame.trans (left : Frame before middle) (right : Frame middle after) : Frame before after :=
  ⟨right.counter.trans left.counter, right.values.trans left.values,
    right.obligations.trans left.obligations, right.recursionAncestry.trans left.recursionAncestry,
    right.expansionAncestry.trans left.expansionAncestry,
