The literal native startup gives such a reached output without an expansion.
The native renderer maps that handle to its explicit recursion marker.
-/
namespace MicroCFTA.SourcePruningEnumerationRestart
open EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationProgress
open SourcePruningEnumerationNodes SourcePruningEnumerationObservation
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Metadata" => SourcePruningRecordTypes.Metadata
variable {Typing : Type} {width : Nat}

private theorem pick_done (preference : List Nat → Option Nat) (offered : Option (List Nat)) :
    pickNext preference offered = .done ↔ offered = none := by
  cases offered with
  | none => simp [pickNext]
  | some offered =>
      cases offered with
      | nil => simp [pickNext]
      | cons first rest =>
          cases chosen : preference (first :: rest) with
          | none => simp [pickNext, chosen]
          | some uv =>
              by_cases member : uv ∈ first :: rest <;> simp [pickNext, chosen, member]

/-- A restart without a stop rule reports done exactly when its candidate list is empty. -/
theorem done_iff_candidates_nil
    (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing) (before : Cached) :
    decision none order metadata before = some .done ↔
      EnumerationIndexSelection.candidates before = [] := by
  simp only [decision, Option.some.injEq, EnumerationPureSelection.next, pick_done]
  unfold EnumerationPureSelection.find
  by_cases empty : EnumerationIndexSelection.candidates before = [] <;> simp [empty]

/-- A done native cache can retain only recursive boundaries in its graph-bearing pending slots. -/
theorem done_pending_boundary
    (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing)
    (caller : Caller width) (before : Cached)
    (valid : SourcePruningEnumerationNativeBranchCompletion.CacheValid caller before)
    (done : decision none order metadata before = some .done)
    (uv handle : Nat) (scs : List Suspended)
