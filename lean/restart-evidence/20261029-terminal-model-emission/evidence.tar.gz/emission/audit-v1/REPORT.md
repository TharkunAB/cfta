# Prepared terminal callback emission: bounded source report

Status: source-only candidate v2, UNTESTED. The parent owns compilation and repository changes.
Base: parent reports refreshed clean HEAD 73b3f496ea0eb4ddfb0b784cf4ae1393d4325cfa.

## Result

The candidate adds `SourcePruningEnumerationPreparedRecursive.callback_no_candidates_emits_models`.
It constructs a callback work bound, its actual false recording result, and one actual prepared output from an original callback model.
The original callback input must have an empty physical candidate list.
The same assignment satisfies the actual emitted cache.

The exported statement and its complete imports, namespace, notation, implicit types and instances are preserved in `public/PreparedTerminalEmissionModels.complete-public-context.txt`.
Candidate v2 is 96 lines, 6,189 bytes; SHA256 b58c85941a1adbd3b23d99edc0494597e16ab829e80c3fad617a4dddef74ec43.
Version v1 is preserved. It predates the explicit concrete Refutes instance and the retained metadata field equalities.
No compiler was run for either version.

## Original gates and exact actual result

The theorem takes the worker parameters, the original full `Packet` with its complete memos, an original fragment allocation bound, and `EnumerationIndexSelection.candidates before = []`.
It also takes original `Satisfies`, self-fill of the actual fragment, original pending-group `Refutes`, template `Avoids`, and `ProgramEncoding` for every represented program.
It assumes no callback success equation, restart decision, reached model, recursive completion, future output, or Discharged property.

The result fixes one `fuel`, one actual `updated` metadata value and one actual returned core `after`.
It retains the full returned Packet, `RenderStable`, `Frame`, the types update, unchanged open holes and typing, the same original assignment's model, and refutation of all updated pending groups.
For every `extra`, it retains BOTH actual recording `Success` and the exact raw singleton `[.ok ((false, updated), after)]` at `fuel + extra`.
For every recursive depth, including zero, the actual NEW prepared `continueWith (resume ...)` is exactly:

```
.complete [⟨none, frame after before, caller, memos.query⟩] caller memos.query
```

The returned cache, caller and query endpoint are the literal ones used by the worker.
No source handle is equated with a prepared parent, and no legacy worker result is cast to a prepared worker result.

## Why this case is missing and how the proof closes it

The current prepared head coverage producer constructs an accepted actual captured receipt and a branch-specific fresh assignment extension.
The sibling producer can instead expose a strictly earlier stopped callback.
The receipt/callback model producers preserve that branch's same assignment at the actual callback frame, derive false recording, and identify the exact recursive restart outcome.
They do not conclude that any recursively emitted output retains this model.

Existing prepared zero-depth resource/base constructors describe pure supplied none/done decisions.
Existing output-history extraction starts with membership of an already emitted output.
Existing output-prefix theorems preserve already emitted outputs.
The bounded named-declaration search found no current actual callback emission producer that derives the recording result and terminal restart from these original gates.
This finding concerns the inspected sources and search scope. It is not an exhaustive claim about every theorem in the repository.

The candidate reuses the actual core callback finite producer once.
It consumes its exact raw observations and complete packet/frame witnesses.
It discards the producer's legacy nominal worker-continuation equality.
Original model/template/refutation gates derive the actual false result through `recordTypes_inl_refutes`.
`Frame` preserves the allocation counter; `Restart.decision_frame` transfers the actual updated-metadata decision back to the original cache.
Its original empty candidate list then forces actual `some .done` for any stop rule and order.
Direct reduction of the actual prepared continuation/resume yields the literal emitted singleton.
The existing frame model theorem proves the output-cache model.

## Scope and remaining gap

This closes the terminal Left-callback-to-emission control-flow case from an original callback model.
The callback can be attached to an actual completed head once the existing coverage API supplies its reached Packet, self-filled fragment and branch-specific assignment extension, and the original callback cache is shown to have no candidates.
The theorem makes no claim that an arbitrary accepted head reaches this terminal case.
Earlier sibling callbacks can still stop before the chosen row is reached.
Nonterminal restarts still require a constructive recursive chosen-output/model step and a uniform depth argument that handles all earlier actual callbacks.
Fresh assignment extensions remain branch-specific because sibling branches can reuse fresh IDs.

DONE DOES NOT IMPLY Discharged.
The singleton can still contain intended native boundary residuals.
This theorem proves no full rendering of the chosen term, whole suspended-bucket discharge, global accepted-language completeness, or global termination.
It adds no Haskell change or Haskell defect claim.

## Read scope and evidence

All original sources are read-only.
The four required head/sibling/receipt/callback model sources exactly match the SHA identities in the prior frozen head-forward whole-read audit.
Their current complete bytes are preserved here; that identity check is recorded explicitly rather than described as a second fresh whole read.
PreparedRecursive, its equations, CallbackProgress, RecursiveCallback and RecordTypesRefutation were read whole during this bounded task.
Other read scopes are exact line cuts, preserved byte-for-byte with both original-whole and cut SHA identities in `source-manifest.json`.
The candidate's complete public statement and all four inspected model/coverage public statements are preserved separately.
Oversized earlier tool reads that were truncated are not counted as additional whole-read evidence.
No compiler, evaluator, native execution, Git, network or board was used.
