# Native factor in a finite recursion-key universe

Date: 2026-10-28, Europe/Stockholm.
Status: SOURCE-ONLY bounded audit. No proof candidate was produced.
Parent-reported base: `6908848a8a1f7c478f8089f2703f7271a3dd8ce1`.
This author did not query Git or run a compiler, evaluator, native program,
network or board operation. No repository file changed.

## Result

None of the audited APIs derives an original fixed finite carrier for every
native handle generated through the primary prepared recursive worker.
They give genuine finite carriers for one physical heap, one original operand
forest, one supported native domain, or one supplied finite resource schedule.
This is a missing proof bridge. It is not an admitted divergence result.

The minimal recursion-key target is narrower than closure of all generated
ordinary handles. The actual native `Entry.enter` inserts a key only when its
current decoded value satisfies `recursiveBoundary`. That test accepts Mu and
explicit Union. The needed native factor therefore concerns actual inserted
boundary handles. Ordinary generated records can still affect later boundary
construction and the ordered operational depth argument.

## Exact existing statements and their boundaries

| Source API | Derived result | Boundary for this task |
| --- | --- | --- |
| `InputView.inventory`, `inventory_available`, `closed_reach_inventory` | An available encoded input, and every reachable input of a closed original root, belong to the actual finite issued carrier of one fixed heap. | The carrier uses that heap's `nodes.next`. No theorem here bounds all later generated heaps by the startup heap. |
| `NativeInputInventoryModels.reachable_inventory`, `finiteInput` | Reachability from one stored finite root list stays in the fixed heap's input carrier. Bodies, row children, union members and references retain that interface. | This is closure of the fixed physical input view. It is not closure under newly generated intersection or normalization results. |
| `InventoryState.Inventory`, `At`, `query_complete` | The current inventory has physical source facts, closed available roots and cache laws. A query constructs its next inventory and actual receipt. | The conclusion explicitly sets `next.source` to the pre-query current heap and appends the current left/right operands to the roots. The source is allowed to change. |
| `InventoryRebase.extend`, `rebase` | An actual grown target heap plus current operands defines a new inventory. Old models and native cache admission survive. | `extend` uses `target` as its source. It does not derive membership of new operands in a fixed startup inventory. |
| `NativeGrownInventory.valid_grows`, `rank_exact`, `language_exact` | Enlarging the target inventory retains old admitted inputs and their exact ranks/languages. | Inclusion is from the old domain into the larger one. It does not bound the larger domain by the old one. |
| `FiniteOrdinaryKeys.Node`, `of_available`, `of_resident` | Supplied current counter bounds derive recursive key certificates for immutable ordinary operands and their rows/children. They give safe actual node/edge query keys. | The inductive domain has Empty and ordinary nodes. It excludes Mu, Union and reference inputs. It certifies input records and does not give generated-output key closure. |
| `DomainInventory.inventory`, `mem_inventory_iff`, `Supported.extend`, `supported_length_le` | Canonical typed domains supported by fixed binder/pair lists form a finite explicit inventory of length `2^(binders.length+pairs.length)`. Real domain extension preserves it when its new names and pair belong to those lists. | The support hypotheses must be proved for each extension. This bounds native query domains, not the enumeration handle field or all future generated operands. |
| `GeneratedQueryResources.Fits`, `Receipt.fits`, `complete` | Actual counters and payload mass fit the input profile; the actual query returns a state fitting `ResourceForecast.step profile`, with its own receipt and rebased inventory. | The next profile can grow. The actual input caps, room and readiness remain explicit. This is one query's constructive resource result. |
| `ResourceForecast.advance`, `Reserved`, `PreparedReservation.final`, `reserved_computed` | A fixed query count or recursive depth determines a finite forecast. Sufficient mathematical width can be computed before that bounded run. | `reserved_computed` uses `roomBits (final depth seed ceiling).2`. The bound depends on the supplied depth. It does not derive sufficient depth. |
| `AnnotationHeap.Heap`, `nodeStep`, `run` | Actual edge guards retain the given guard predicate through safe constructor work. Node allocation leaves the edge-guard invariant unchanged. | A finite guard alphabet does not itself bound structural node keys, child identities, payload size or the node counter. |
| `InternedMuDepthInventory.initial_bounded`, `counts_decrease` | The current finite heap has a bound on Mu body degrees. Visiting an unseen Mu strictly decreases the degree vector when the actual result satisfies `Lower` at that Mu's old body degree. | The theorem requires actual `Lower` evidence. It does not derive that fact through every prepared query/normalization, does not cover Union counting, and does not assert a finite fixed handle carrier. |

The finite input carrier is literal:

    empty :: (range source.nodes.next).flatMap
      (fun name => [node name, mu name, union name, ref name])

Its finiteness is real. The unresolved step is keeping a sufficient carrier
independent of all later source heaps and the supplied recursive depth.

## Important meanings of Original and of a handle

`Inventory.originals` is not evidence that its roots existed at startup.
`NativeGrownInventory.closed_originals` derives `Original` for closed resident
values in the actual target heap. `InventoryRebase.extend` uses that theorem
for newly appended current operands. Thus the word "original" in these input
APIs denotes the required physical syntax/readback property. It does not give
global startup provenance for a native identity.

`Nodes.encodeNode` maps Empty to zero and a Node, Mu or Union entry to its
raw canonical `entry.identity + 1`. `lookupNode` rejects missing entries and
losing reservations. `RecursionKey.node` is a `Nat`. It does not encode a
language quotient or an original-term subtree descriptor.

The physical constructor cache also has a natural-number counter.
`Cache.reserve` increments that counter. `nodeStep` interns its supplied full
structural key. Canonical reuse identifies the same key; it does not identify
arbitrary distinct records that happen to accept the same chosen term.
The width parameter of the checked memo state is not a bound on every one of
these natural-number handles. `Nodes` explicitly keeps native NodeId extraction
and enumeration-slot realization outside its model convention.

Consequently, a finite accepted-model subtree set or a finite guard carrier
does not alone give a finite set of literal recursion-key node fields.
No claim of an infinite admitted allocation history follows from this fact.

## Per-point bound that already follows

For one actual `lookupNode heap handle = some value`, physical cache validity
gives `handle <= heap.nodes.next`: zero is immediate; a positive handle has an
issued canonical identity strictly below the current counter. With current
`Fits profile`, this gives `handle <= profile.nodes` and membership in
`range (profile.nodes + 1)`.

This is a useful local consequence of existing lookup/counter facts.
It is not a new original global carrier. A wrapper that appends only this
inequality would leave the central quantifier unchanged, so none is drafted.

Similarly, taking `range ((final depth seed ceiling).2.nodes + 1)` after a
fixed-depth resource proof yields a depth-dependent carrier. Substituting
that carrier into the desired depth argument still leaves the supplied-depth
dependency to discharge. A width selected from that final profile has the
same dependency.

## Next meaningful source theorem

The missing result must derive the native factor before choosing recursive
capacity. It must cover the actual allocating operations and actual boundary
insertions, including operations that complete with no emitted output.
It cannot start by assuming membership of every future handle in a carrier.

A useful first source target is a finite structural descriptor/key family
computed from the original input, with a proof that every newly inserted
Mu/Union boundary has a key in that family. The proof must follow actual
native intersection/conjunction, class edits and selected normalization.
Current per-query captured origins must be connected back to that fixed
family when operands themselves came from earlier queries. Rebase alone
does not make this connection.

Actual canonical lookup stability can then connect those structural keys to
distinct actual handle counts along one branch. This distinction matters:
an original uniform cardinality bound can be sufficient even when the
particular numeric identities depend on the allocation order. Requiring one
startup-computed list of literal Nat handles across every possible allocation
order can be stronger than the required distinct-key bound.

The desired quantifier is an original bound/family before all admitted
reachable prefixes and supplied depths. The existing inventory construction
instead supplies a finite carrier for each current prefix heap. Do not swap
these quantifiers without the new structural closure proof.

`InternedMuDepthInventory.counts_decrease` supplies another real local progress
route if the actual prepared operations can derive its `Lower` condition.
That derivation and a Union argument would still be required. This audit does
not assume either condition, or claim the older Mu measure applies unchanged.

An argument restricted to prefixes retaining one chosen satisfying model must
also state that scope. It does not automatically bound every earlier ordered
callback, which can explore a different branch before the chosen edge.

## Counterexample and Haskell assessment

The retained prior findings reject fresh-UVar identity as a recursion-key
progress measure. They also reject the lightweight `A = f(A) | a` proposal
as an admitted divergence witness: empty-bucket Mu work can park, and native
repetition can clear the bucket. Union narrowing need not insert the original
Union key. Equality path-length growth refutes a proposed path measure;
it is not a fully admitted infinite native-handle trace.

This audit establishes no new admitted infinite-handle or all-depth failure
example. It also establishes no new Haskell defect or required fix. No Haskell
source, test or evaluator was used. Root's FINDINGS should retain the existing
external repair records; this audit requests no new Haskell repair entry.

## Read scope and freeze

The manifest preserves twelve WHOLE relevant Lean sources and one WHOLE prior
carrier-context note: 119,298 bytes and 1,947 lines together. Eighteen exact
literal cuts preserve 97,832 bytes and 1,649 lines. Each cut records its complete
source identity without claiming a whole read. The cuts include actual runtime
key/entry definitions, reservation/width definitions and prior findings.

An aggregate discovery search was truncated. Every named proof conclusion used
above was recovered by a subsequent whole source read or an exact recorded cut.
The manifest records unrelated discovery and wrong-location cuts explicitly.
No technical claim uses a truncated discovery result as its proof authority.
The memory registry supplied only the restart convention, not technical facts.

No candidate, generic wrapper or future-handle contract was added.
The report, input copies, manifest and file inventory are frozen after delivery.
