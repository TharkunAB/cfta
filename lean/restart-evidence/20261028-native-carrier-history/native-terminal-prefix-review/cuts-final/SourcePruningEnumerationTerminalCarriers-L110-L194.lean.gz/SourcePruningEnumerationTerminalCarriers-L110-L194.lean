/-- Every actual terminal outer core retains original carriers, including stopped outcomes. -/
theorem observed_carriers
    (checkEmpty : Bool) (r n p h : Nat) (first : Suspended) (rest : List Suspended)
    (waiting : EnumerationWaitingIndex.Waiting) (caller : Caller width) (before : Core)
    (incoming : Node) (incomingScs : List Suspended) (queries : Queries)
    (total : UnionFind.Total before.representatives) (references : ReferencesCarry before) :
    UnionFind.Total (run checkEmpty r n p h first rest waiting caller before incoming incomingScs queries).2.2.2.1.representatives ∧
      PreservesCarriers before (run checkEmpty r n p h first rest waiting caller before incoming incomingScs queries).2.2.2.1 ∧
      ReferencesCarry (run checkEmpty r n p h first rest waiting caller before incoming incomingScs queries).2.2.2.1 := by
  generalize observed : run checkEmpty r n p h first rest waiting caller before incoming incomingScs queries = result
  obtain ⟨outcome, reachedCaller, saved, outer, moved⟩ := result
  dsimp only
  unfold run at observed
  split at observed
  next empty =>
    simp only [Prod.mk.injEq] at observed
    rcases observed with ⟨rfl, rfl, rfl, rfl, rfl⟩
    exact ⟨total, .refl _, references⟩
  next nonempty =>
    split at observed
    next recorded winner transfer joined prefixObserved =>
      have prefixSuccess : Success (SourcePruningEnumerationTerminalPrefix.run r first rest waiting)
          before (recorded, winner, transfer) joined := by
        rw [Success, prefixObserved]
        exact List.mem_singleton_self _
      have joinedFacts := SourcePruningEnumerationTerminalPrefix.run_carriers r first rest waiting
        before joined recorded winner transfer total references prefixSuccess
      rcases foldObserved : SourcePruningEnumerationFold.run checkEmpty n p h recorded caller joined winner queries with
        ⟨foldResult, foldCaller, foldQueries, foldOuter⟩
      rw [foldObserved] at observed
      have foldFacts := SourcePruningEnumerationFold.run_carriers checkEmpty n p h recorded caller joined
        winner queries foldResult foldCaller foldQueries foldOuter joinedFacts.1 joinedFacts.2.2.2
        joinedFacts.2.2.1 foldObserved
      have outerFacts : UnionFind.Total foldOuter.representatives ∧ PreservesCarriers before foldOuter ∧
          ReferencesCarry foldOuter := ⟨foldFacts.1, joinedFacts.2.1.trans foldFacts.2.1, foldFacts.2.2⟩
      cases foldResult with
      | error fault =>
          simp only [Prod.mk.injEq] at observed
          rcases observed with ⟨rfl, rfl, rfl, rfl, rfl⟩
          exact outerFacts
      | ok possible =>
          cases possible with
          | none =>
              simp only [Prod.mk.injEq] at observed
              rcases observed with ⟨rfl, rfl, rfl, rfl, rfl⟩
              exact outerFacts
          | some raw =>
              dsimp only at observed
              split at observed
              next empty =>
                simp only [Prod.mk.injEq] at observed
                rcases observed with ⟨rfl, rfl, rfl, rfl, rfl⟩
                exact outerFacts
              next folded =>
                have foldedSame := SourcePruningEnumerationFold.singleton_core checkEmpty n p h recorded
                  caller joined winner queries folded foldCaller foldQueries foldOuter foldObserved
                have foldedTotal : UnionFind.Total folded.representatives := by simpa only [foldedSame] using foldFacts.1
                have foldedReferences : ReferencesCarry folded := by simpa only [foldedSame] using foldFacts.2.2
                have foldedPreserves : PreservesCarriers before folded := by simpa only [foldedSame] using outerFacts.2.1
                have incomingFacts := (SourcePruningEnumerationIncomingNode.run_carriers checkEmpty r n p h
                  foldCaller folded winner incoming incomingScs foldQueries foldedTotal foldedReferences).1
                rcases incomingObserved : SourcePruningEnumerationIncomingNode.run checkEmpty r n p h
                    foldCaller folded winner incoming incomingScs foldQueries with
                  ⟨incomingResult, reached, savedQueries, read⟩
                rw [incomingObserved] at observed incomingFacts
                dsimp only at incomingFacts
                have readFacts : UnionFind.Total read.representatives ∧ PreservesCarriers before read ∧
                    ReferencesCarry read := ⟨incomingFacts.1, foldedPreserves.trans incomingFacts.2.1, incomingFacts.2.2⟩
                cases incomingResult with
                | error fault =>
                    simp only [Prod.mk.injEq] at observed
                    rcases observed with ⟨rfl, rfl, rfl, rfl, rfl⟩
                    exact readFacts
                | ok result =>
                    cases result <;> simp only [Prod.mk.injEq] at observed <;>
                      rcases observed with ⟨rfl, rfl, rfl, rfl, rfl⟩ <;> exact readFacts
              next other =>
                simp only [Prod.mk.injEq] at observed
                rcases observed with ⟨rfl, rfl, rfl, rfl, rfl⟩
                exact outerFacts
    next other =>
      simp only [Prod.mk.injEq] at observed
      rcases observed with ⟨rfl, rfl, rfl, rfl, rfl⟩
      exact ⟨total, .refl _, references⟩

