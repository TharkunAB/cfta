theorem assimilated_carriers
    (before : EnumerationState.State Symbol EnumGuard) (source target : Nat)
    (sourceNode targetNode merged : Option Nat) (sourceScs targetScs : List Suspended)
    (total : UnionFind.Total before.representatives)
    (related : UnionFind.SameClass before.representatives target source)
    (references : ReferencesCarry before)
    (sourceStored : before.values[source]? = some (.unenumerated sourceNode sourceScs))
    (targetStored : before.values[target]? = some (.unenumerated targetNode targetScs))
    (different : source ≠ target)
    (noneOrigin : merged = none → sourceNode = none ∧ targetNode = none) :
    let after := assimilated before target source (.unenumerated merged (sourceScs ++ targetScs))
    after.representatives = before.representatives ∧ UnionFind.Total after.representatives ∧
      PreservesCarriers before after ∧ ReferencesCarry after := by
  have sourceInside := (List.getElem?_eq_some_iff.mp sourceStored).1
  have targetInside := (List.getElem?_eq_some_iff.mp targetStored).1
  have replacementBearing :
      GraphValue (.unenumerated sourceNode sourceScs : UVarValue Symbol) ∨
        GraphValue (.unenumerated targetNode targetScs : UVarValue Symbol) →
      GraphValue (.unenumerated merged (sourceScs ++ targetScs) : UVarValue Symbol) := by
    intro bearing
    cases merged with
    | some handle => trivial
    | none =>
        obtain ⟨sourceNone, targetNone⟩ := noneOrigin rfl
        rcases bearing with sourceBearing | targetBearing
        · simp only [sourceNone, GraphValue] at sourceBearing
        · simp only [targetNone, GraphValue] at targetBearing
  have preserved : PreservesCarriers before
      (assimilated before target source (.unenumerated merged (sourceScs ++ targetScs))) := by
    rintro uv ⟨held, value, same, stored, bearing⟩
    by_cases atSource : held = source
    · subst held
      have valueSame : value = .unenumerated sourceNode sourceScs :=
        Option.some.inj (stored.symm.trans sourceStored)
      refine ⟨target, .unenumerated merged (sourceScs ++ targetScs),
        UnionFind.sameClass_trans same (UnionFind.sameClass_symm related), ?_, ?_⟩
      · simp [assimilated, targetInside, different]
      · exact replacementBearing (.inl (valueSame ▸ bearing))
    · by_cases atTarget : held = target
      · subst held
        have valueSame : value = .unenumerated targetNode targetScs :=
          Option.some.inj (stored.symm.trans targetStored)
        refine ⟨target, .unenumerated merged (sourceScs ++ targetScs), same, ?_, ?_⟩
        · simp [assimilated, targetInside, different]
        · exact replacementBearing (.inr (valueSame ▸ bearing))
      · exact ⟨held, value, same,
          (assimilation_frame before target source held _ atTarget atSource).trans stored, bearing⟩
  have origin : EnumeratedOrigin before
      (assimilated before target source (.unenumerated merged (sourceScs ++ targetScs))) := by
    intro uv fragment stored
    by_cases atSource : uv = source
    · subst uv
      simp [assimilated, sourceInside] at stored
    · by_cases atTarget : uv = target
      · subst uv
        simp [assimilated, targetInside, different] at stored
      · exact (assimilation_frame before target source uv _ atTarget atSource).symm.trans stored
  exact ⟨rfl, total, preserved,
    references_transport before _ references preserved origin rfl⟩

