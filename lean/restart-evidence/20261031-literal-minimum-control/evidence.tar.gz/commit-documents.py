from pathlib import Path
import json,subprocess
r=Path('/tmp/mcfta-literal-minimum-control-20261031');repo=Path('/home/tritlo/Code/mcfta')
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert git('branch','--show-current')=='formalize' and git('rev-parse','HEAD')=='975d557b436a38c6ded6abba1668283056e87a5d';assert not git('diff','--cached','--name-only')
subprocess.run(['python3',str(r/'verify-documents.py')],check=True)
files=['NEXT-PROMPT.md','HANDOFF.md','FINDINGS.md','lean/notes-current-literal-minimum-pass.md'];subprocess.run(['git','add','--',*files],cwd=repo,check=True);assert set(git('diff','--cached','--name-only').splitlines())==set(files)
result=subprocess.run(['git','diff','--cached','--check'],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/'docs-diff-check.raw.log').write_bytes(result.stdout);assert result.returncode==0
result=subprocess.run(['git','commit','-m','Record minimum-pass convergence and remaining proof boundaries'],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/'docs-commit.raw.log').write_bytes(result.stdout);assert result.returncode==0,result.stdout
row={'commit':git('rev-parse','HEAD'),'source_head':'975d557b436a38c6ded6abba1668283056e87a5d','files':files,'clean':not git('status','--porcelain=v1')};assert row['clean'];(r/'docs-commit.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
