# Incidents

A progress message used the estimated timestamp 04:31 CET.
The next date command returned 04:29 CET.
This was a timestamp estimate error.
No source or evidence was affected.

The optional directory-name check for the previous termination bundle used cuts/.
That provider stores its files with another layout.
The command returned FileNotFoundError after the Input cut had succeeded.
No additional source was acquired by the failed directory check.

The first metadata freeze command had a parenthesis syntax error in its final print.
Python rejected the command before it executed any statement.
The source files remained unchanged and the directory remained writable.
The corrected metadata script is retained as freeze.py.
