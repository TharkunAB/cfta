from pathlib import Path
import hashlib,json,re
r=Path(__file__).resolve().parent
selected=r/'SourceSizedMinimumConvergence-v5-UNCOMPILED.lean'
s=selected.read_text()
checks={
 'selected_source':selected.name,
 'sha256':hashlib.sha256(selected.read_bytes()).hexdigest(),
 'lines':len(s.splitlines()),
 'status':'UNCOMPILED source-only owner draft',
 'forbidden_declarations_found':re.findall(r'\b(?:sorry|admit|axiom|unsafe|noncomputable|Classical)\b',s),
 'public_producer_arguments':'original Input plus DecidableEq Q only',
 'public_producer_names':['MicroCFTA.SourceSizedMinimumConvergence.minimumSizes','MicroCFTA.SourceSizedMinimumConvergence.minimum_spec'],
 'private_iteration':'settle from an internally constructed empty Working table',
 'computable_comparison':'sameOn uses Option Int decidable equality over original input.states',
 'internal_measure':'missing original keys paired with signedMass.toNat',
 'required_root_addition':'SourceSizedMinimumPass.pass_positive',
 'old_whole_acquisitions':1,
 'compiler_or_evaluator_invocations':0,
 'production_or_git_mutations':0
}
assert checks['forbidden_declarations_found']==[]
assert checks['lines']==197
assert checks['sha256']=='49f54906c6dba49230227d5bad636d76b864821fc47bbf0ba5604257c8991163'
(r/'STATIC-AUDIT.json').write_text(json.dumps(checks,indent=2)+'\n')
verifications=[]
for e in json.loads((r/'acquisitions.json').read_text()):
 p=Path(e.get('original_path',e.get('source')))
 found=hashlib.sha256(p.read_bytes()).hexdigest()
 assert found==e['source_sha256']
 copy=r/e['copy']
 assert hashlib.sha256(copy.read_bytes()).hexdigest()==e['copy_sha256']
 verifications.append({'original_path':str(p),'source_sha256':found,'retained_copy':e['copy'],'copy_sha256':e['copy_sha256'],'match':True})
(r/'SOURCE-REVERIFY.json').write_text(json.dumps(verifications,indent=2)+'\n')
manifest={'kind':'source-only frozen minimum convergence review','selected':selected.name,'status':'UNCOMPILED owner source; Root alone checks','files':[]}
for p in sorted(r.rglob('*')):
 if p.is_file() and p.name not in {'MANIFEST.json','pins.json','FROZEN'}:
  data=p.read_bytes()
  manifest['files'].append({'path':str(p.relative_to(r)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(r/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={'scope':str(r),'selected_source':selected.name,'selected_sha256':sha(selected),'selected_lines':197,'manifest_sha256':sha(r/'MANIFEST.json'),'report_sha256':sha(r/'REPORT.md'),'payload_files':len(manifest['files']),'payload_bytes':sum(e['bytes'] for e in manifest['files']),'status':'UNCOMPILED owner source; no production changes'}
(r/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(r/'FROZEN').write_text('Source-only owner bundle frozen.\nSelected draft remains UNCOMPILED.\nRoot alone compiles and integrates.\nMANIFEST.json SHA256 '+pins['manifest_sha256']+'\npins.json SHA256 '+sha(r/'pins.json')+'\n')
for e in manifest['files']:
 p=r/e['path']
 assert sha(p)==e['sha256']
for p in sorted(r.rglob('*')):
 if p.is_file():
  p.chmod(0o444)
for p in sorted([p for p in r.rglob('*') if p.is_dir()],reverse=True):
 p.chmod(0o555)
r.chmod(0o555)
print(json.dumps({'files':sum(p.is_file() for p in r.rglob('*')),'selected':pins['selected_sha256'],'manifest':pins['manifest_sha256'],'pins':sha(r/'pins.json'),'report':pins['report_sha256'],'frozen':sha(r/'FROZEN')},indent=2))
