# Scope

Source-only finite-key comparison and exact pass descent.
Root owns all compilation, evaluation, native runs, Git and production changes.
No network, board or delegation is permitted.

The two named old whole-source slots are:
1. /tmp/mcfta-literal-minimum-pass-review-20261031/SourceSizedMinimumPass-v3-UNCOMPILED.lean (214 lines).
2. /home/tritlo/Code/mcfta/lean/MicroCFTA/SourceSizedPreprocessing.lean (268 lines), only if needed.

All other source acquisitions use named bounded cuts.
Keep the 34-file minimum-pass provider and all earlier bundles unchanged.
No supplied final table, iteration count, future transition or stopping witness is allowed.
The original Map key-order adapter remains open.
The owner does not compile this source.
