import MicroCFTA.SourceSizedMinimumPass

/-!
# Finite comparison and actual signed pass descent

The comparison reads only the original finite state list.
A changed actual pass decreases the missing-key count or the signed sum.
The signed sum is not a well-founded natural measure.
Positive-table preservation and total convergence remain separate.
-/
-- SOURCE-ONLY DRAFT. No compiler or evaluator was run.
namespace MicroCFTA.SourceSizedMinimumConvergence
open SourceSizedMinimumPass
variable {Q Symbol Guard : Type}

/-- Compare table values in the supplied finite order. -/
def sameOn : List Q → Table Q → Table Q → Bool
  | [], _, _ => true
  | key :: rest, first, second =>
      decide (first key = second key) && sameOn rest first second

/-- Count states with no known value. -/
def missing : List Q → Table Q → Nat
  | [], _ => 0
  | key :: rest, known =>
      match known key with
      | none => missing rest known + 1
      | some _ => missing rest known

/-- Sum the known signed values in the original state sequence. -/
def signedMass : List Q → Table Q → Int
  | [], _ => 0
  | key :: rest, known =>
      match known key with
      | none => signedMass rest known
      | some value => value + signedMass rest known

private theorem sameOn_member (keys : List Q) (first second : Table Q)
    (compared : sameOn keys first second = true) (key : Q) (member : key ∈ keys) :
    first key = second key := by
  induction keys with
  | nil => cases member
  | cons head rest ih =>
      have parts : first head = second head ∧ sameOn rest first second = true := by
        simpa only [sameOn, Bool.and_eq_true, decide_eq_true_eq] using compared
      rcases List.mem_cons.mp member with atHead | inRest
      · exact atHead ▸ parts.1
      · exact ih parts.2 inRest

/-- The original complete finite carrier turns the computed comparison into full equality. -/
theorem sameOn_eq (input : SourceSizedPreprocessing.Input Q Symbol Guard)
    (first second : Table Q) (compared : sameOn input.states first second = true) :
    first = second := by
  funext key
  exact sameOn_member input.states first second compared key (input.complete key)

private theorem keys_progress [DecidableEq Q]
    (input : SourceSizedPreprocessing.Input Q Symbol Guard) (known : Table Q) (keys : List Q) :
    missing keys (pass input known) ≤ missing keys known ∧
    (missing keys (pass input known) = missing keys known →
      signedMass keys (pass input known) ≤ signedMass keys known) ∧
    (sameOn keys (pass input known) known = false →
      missing keys (pass input known) < missing keys known ∨
        missing keys (pass input known) = missing keys known ∧
          signedMass keys (pass input known) < signedMass keys known) := by
  induction keys with
  | nil => simp [missing, signedMass, sameOn]
  | cons key rest ih =>
      cases before : known key with
      | none =>
          cases after : pass input known key with
          | none => simpa [missing, signedMass, sameOn, before, after] using ih
          | some value =>
              simp only [missing, signedMass, before, after]
              refine ⟨by omega, ?_, ?_⟩
              · intro equalMissing
                omega
              · intro _changed
                exact Or.inl (by omega)
      | some old =>
          obtain ⟨value, actual, bounded⟩ := pass_known input known key old before
          cases after : pass input known key with
          | none => simp only [after, reduceCtorEq] at actual
          | some next =>
              have sameValue : value = next := Option.some.inj (actual.symm.trans after)
              subst value
              by_cases unchanged : next = old
              · subst next
                simpa [missing, signedMass, sameOn, before, after] using ih
              · have strictValue : next < old := by omega
                simp only [missing, signedMass, before, after]
                refine ⟨ih.1, ?_, ?_⟩
                · intro equalMissing
                  have tailBound := ih.2.1 equalMissing
                  omega
                · intro _changed
                  by_cases equalMissing : missing rest (pass input known) = missing rest known
                  · exact Or.inr ⟨equalMissing, by have tailBound := ih.2.1 equalMissing; omega⟩
                  · exact Or.inl (by have tailBound := ih.1; omega)

/-- The pair records the missing-key count and the signed known-value sum. -/
def signedMeasure (input : SourceSizedPreprocessing.Input Q Symbol Guard) (known : Table Q) : Nat × Int :=
  (missing input.states known, signedMass input.states known)

/-- The actual computable pass comparison produces equality or strict signed lexicographic loss. -/
theorem compare_pass [DecidableEq Q] (input : SourceSizedPreprocessing.Input Q Symbol Guard)
    (known : Table Q) :
    (sameOn input.states (pass input known) known = true ∧ pass input known = known) ∨
    (sameOn input.states (pass input known) known = false ∧
      Prod.Lex (fun a b : Nat => a < b) (fun a b : Int => a < b)
        (signedMeasure input (pass input known)) (signedMeasure input known)) := by
  cases compared : sameOn input.states (pass input known) known with
  | true => exact Or.inl ⟨compared, sameOn_eq input _ _ compared⟩
  | false =>
      refine Or.inr ⟨compared, ?_⟩
      rcases (keys_progress input known input.states).2.2 compared with
        fewerMissing | ⟨sameMissing, smallerMass⟩
      · exact Prod.Lex.left _ _ fewerMissing
      · unfold signedMeasure
        rw [sameMissing]
        exact Prod.Lex.right _ smallerMass

end MicroCFTA.SourceSizedMinimumConvergence
