# Minimum-pass convergence source draft

## Status

The selected source is SourceSizedMinimumConvergence-v5-UNCOMPILED.lean.
It has 197 lines.
Its SHA256 is 49f54906c6dba49230227d5bad636d76b864821fc47bbf0ba5604257c8991163.
The owner has not run a compiler, evaluator, native program or Haskell program.
The owner has not changed production or Git state.
All assertions below describe the draft contracts and source proof structure.
They are not new checked claims.

## Result proposed for checking

The draft defines a total minimumSizes function on the existing original
SourceSizedPreprocessing.Input and DecidableEq Q.
Its body starts from the empty table.
It applies the literal signed pass from the frozen 214-line provider.
It stops when a computable finite-key comparison returns true.
It returns the current table at that stop.
No final table, step count, transition invariant, future stop, or completed
execution is supplied by its public caller.

The proposed minimum_spec conclusion states:

- The computed table is fixed by the actual pass.
- Every known value is strictly positive.
- Every known key belongs to input.states.

This result does not state least accepted-term size.
The Haskell routine ignores row symbols and constraints when it computes costs.
The draft uses that same pass behavior.

## Computable equality

The sameOn function compares Option Int values in the finite state sequence.
It uses decide only for equality of Option Int.
It does not decide equality of functions.
The sameOn_eq proof uses Input.complete and function extensionality.
Input.complete enumerates every inhabitant of Q.
This fact is part of the original input.
It also proves support containment for every table represented at that type.
No later table-support witness is required from the producer caller.

The representation adapter from a finite Haskell Map domain into this finite
Q remains separate.
That adapter must include all original keys and relevant child/root states.
States with no original row must have empty rows in the model.
The actual Map key order must match the input scan order.

## Exact descent

The private keys_progress proof uses the public pass_known law.
It performs case analysis on the actual before and after lookups.
A known entry cannot become absent.
A retained known entry cannot increase.
A newly known entry strictly reduces the missing-key count.
If that count stays equal, any actual comparison difference strictly reduces
the signed sum of the known values.
The comparison also counts repeated keys if a list contains duplicates.
The proof does not require a distinctness premise.
The existing Input already supplies distinct states.

The compare_pass theorem is closed over input and the current known table.
It returns the actual comparison tag together with full equality or strict
lexicographic decrease of (missing count, signed mass).
The signed mass alone does not define a well-founded relation.
The draft does not use it as one.

## Internal positive state and total iteration

The public pass_positive wrapper is a required Root addition.
Root explicitly authorized this wrapper around the existing private
scan_positive theorem in the baseline provider.
The exact required wrapper is retained in a separate text file.
The frozen provider is unchanged.

The private Working structure stores the current table and its positive proof.
The initial table is empty, so this proof is immediate.
Each actual pass obtains its positive proof from pass_positive.
The private mass_nonnegative proof derives a nonnegative signed sum.
The natural measure is (missing count, signed mass.toNat).
The natural_decrease proof converts the actual signed decrease to strict
Prod.Lex Nat.lt Nat.lt decrease.
The private settle function recurses only in the actual false-comparison branch.
Its termination_by clause uses that natural pair.
The successful branch derives function equality from the actual finite check.
Its result certificate is produced by the function body.
It is not a public producer input.

## Checking boundary

The baseline provider was still uninstalled when this task began.
Root later reported strict success for a 222-line V6 with pass_positive.
The owner has not read or acquired that repaired source.
The original frozen 214-line source remains the acquisition pin here.
The extension needs normal Lean elaboration, termination checking and
the repository strict checks.
Possible proof-only repairs include simplifier names, reduction of the
lexicographic termination relation, and tactic normalization after lookup cases.
The owner has not tested those elaboration details.
No source version may be described as checked from this inventory.

## Remaining correspondence and global scope

The current Input finite enumeration is not a proof of actual Map key order.
The signed table represents the Integer arithmetic of the source pass.
A literal Map representation and key-scan adapter is still required.
The producer does not prove that its table contains exactly the states with
finite unconstrained derivations or their least sizes.
Those semantic minimum properties remain separate.
The producer does not prove the equality-guard extraction bridge.
It does not prove literal explore, SCC extraction, memo allocation, fromRows,
fromFTA, host or lazy Haskell correspondence.
It does not bound whole-worker recursive depth or ordered output progress.
It does not address captured sibling restoration or same-slot resume work.
The original-input/both-worker/public/Haskell objective remains open.

No new Haskell issue or fix was established.
There is no FINDINGS defect candidate from this source-only task.

## Acquisitions

The one old whole acquisition is the frozen 214-line minimum-pass source.
The other original source is the 11-line Input cut at lines 110–120.
The allowed second old whole slot was not used.
ACQUISITION-UNIONS.json records the per-original-path cumulative union.
The acquisition ledger records full source and retained-copy hashes.
The provider manifest and pins are retained as exact metadata copies.
The report retains the timestamp estimate and optional directory-name errors.
Every source version and every acquired material remains in this directory.
