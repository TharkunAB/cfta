# Versions

V1 is the signed comparison and aggregate descent draft.
V2 adds the internally positive state and total iteration.
It uses the public pass_positive wrapper that Root authorized.
V2 also rewrites fresh lookup observations after case analysis.
V3 adds an explicit tail count bound and changes the membership rewrite.
V4 replaces expression case analysis in compare_pass with by_cases.
This retains the literal comparison equation in the public disjunction.
A private Bool lemma derives the false comparison in both callers.
This avoids using an original expression equation at a reduced constructor goal.
V5 qualifies Int.le_refl in the integer base case.
Root reported the same qualification was required in the baseline.
V5 is selected.
Every version remains uncompiled owner source.
