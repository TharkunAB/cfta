# Root dependency

The selected extension imports MicroCFTA.SourceSizedMinimumPass.
The frozen provider is the exact 214-line V3 source.
Its positivity preservation theorem is private.
Root authorized a public pass_positive wrapper around scan_positive.
The intended wrapper is retained in Root-pass-positive-addition-UNCOMPILED.txt.
The extension uses that exact input/known/positive argument order.

Root reported strict success for its 222-line baseline V6 and the wrapper.
The owner has not acquired that repaired source.
Root must check the extension against the installed baseline.
The owner has not compiled any version.
The owner has not edited the frozen provider or production.

The top-level minimumSizes takes only the original Input and DecidableEq Q.
The private Working value starts from the empty table.
Each recursive step derives its positive proof from pass_positive.
No current-positive premise is requested from the producer caller.
