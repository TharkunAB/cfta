# Literal minimum pass review

Source-only. No compiler/evaluator/native/Haskell/Git/network/board/production/spawn.
Only OLD whole paths allowed: SourceSizedPreprocessing.lean and SourceSizedPrefixProductInteger.lean.
All Haskell/Map/Table/stdlib dependencies use named bounded cuts.
Model finite ordered rows and a known table with actual within-pass lookups.
No final table, iteration count, future stop/result or transition invariant supplied by public producer.
Prefer at most250L with positivity/support/nonincrease; retain any convergence boundary.
Keep original45/14/47 bundles immutable.
