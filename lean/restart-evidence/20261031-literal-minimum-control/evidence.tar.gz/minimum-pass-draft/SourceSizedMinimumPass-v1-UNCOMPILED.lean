import MicroCFTA.SourceSizedPreprocessing

/-!
# One ordered minimum-size pass

The finite original state sequence supplies the key scan order.
Each key reads the table returned by its suffix before inserting one minimum.
Map key-order and Integer-table representation correspondence remain separate.
-/
-- SOURCE-ONLY DRAFT. No compiler or evaluator was run.
namespace MicroCFTA.SourceSizedMinimumPass
open SourceSizedDecided (Row)
variable {Q Symbol Guard : Type}
abbrev Table (Q : Type) := Q → Option Nat

/-- All children are read in row order from the same current known table. -/
def transitionMinimum (known : Table Q) (row : Row Q Symbol Guard) : Option Nat :=
  (row.children.mapM known).map fun sizes => 1 + sizes.sum

/-- Select the first available size and fold min in the original row order. -/
def least : List Nat → Option Nat
  | [] => none
  | first :: rest => some (rest.foldl Nat.min first)

/-- InsertWith min retains every earlier known value as an upper bound. -/
def insertMinimum [DecidableEq Q] (key : Q) (value : Nat) (known : Table Q) : Table Q :=
  fun current => if current = key then
    some (match known key with | none => value | some old => min value old)
  else known current

/-- Every row cost uses known before the single key update. -/
def addMinimum [DecidableEq Q] (key : Q) (rows : List (Row Q Symbol Guard)) (known : Table Q) : Table Q :=
  match least (rows.filterMap (transitionMinimum known)) with
  | none => known
  | some value => insertMinimum key value known

/-- A right fold retains the actual within-pass table lookups. -/
def scan [DecidableEq Q] (source : Q → List (Row Q Symbol Guard)) : List Q → Table Q → Table Q
  | [], known => known
  | key :: rest, known => addMinimum key (source key) (scan source rest known)

/-- The original finite carrier grounds the complete pass. -/
def pass [DecidableEq Q] (input : SourceSizedPreprocessing.Input Q Symbol Guard) (known : Table Q) : Table Q :=
  scan input.rows input.states known

/-- A successful transition cost is positive even if an old known size is zero. -/
private theorem transition_positive (known : Table Q) (row : Row Q Symbol Guard) (value : Nat)
    (found : transitionMinimum known row = some value) : 0 < value := by
  cases children : row.children.mapM known with
  | none => simp [transitionMinimum, children] at found
  | some sizes =>
      simp only [transitionMinimum, children, Option.map_some, Option.some.injEq] at found
      omega

private theorem fold_positive (sizes : List Nat) (first : Nat) (positive : 0 < first)
    (others : ∀ value ∈ sizes, 0 < value) : 0 < sizes.foldl Nat.min first := by
  induction sizes generalizing first with
  | nil => exact positive
  | cons next rest ih =>
      have nextPositive := others next List.mem_cons_self
      exact ih (min first next) (by omega) (fun value member => others value (List.mem_cons_of_mem _ member))

private theorem least_positive (sizes : List Nat) (positive : ∀ value ∈ sizes, 0 < value)
    (value : Nat) (found : least sizes = some value) : 0 < value := by
  cases sizes with
  | nil => simp [least] at found
  | cons first rest =>
      simp only [least, Option.some.injEq] at found
      have bound := fold_positive rest first (positive first List.mem_cons_self)
        (fun item member => positive item (List.mem_cons_of_mem _ member))
      exact found ▸ bound

private theorem selected_positive (known : Table Q) (rows : List (Row Q Symbol Guard)) (value : Nat)
    (found : least (rows.filterMap (transitionMinimum known)) = some value) : 0 < value := by
  apply least_positive _ _ value found
  intro size member
  obtain ⟨row, _present, actual⟩ := List.mem_filterMap.mp member
  exact transition_positive known row size actual

/-- One actual key step changes only its key, with a positive nonincreasing value. -/
private theorem add_spec [DecidableEq Q] (key : Q) (rows : List (Row Q Symbol Guard))
    (known : Table Q) (current : Q) :
    addMinimum key rows known current = known current ∨
      ∃ value, addMinimum key rows known current = some value ∧ 0 < value ∧ current = key ∧
        ∀ old, known current = some old → value ≤ old := by
  cases selected : least (rows.filterMap (transitionMinimum known)) with
  | none => exact Or.inl (by simp only [addMinimum, selected])
  | some value =>
      have positive := selected_positive known rows value selected
      by_cases same : current = key
      · subst current
        cases oldLookup : known key with
        | none =>
            refine Or.inr ⟨value, ?_, positive, rfl, ?_⟩
            · simp only [addMinimum, selected, insertMinimum, if_pos, oldLookup]
            · intro old impossible
              simp only [oldLookup, reduceCtorEq] at impossible
        | some old =>
            by_cases zero : old = 0
            · subst old
              exact Or.inl (by simp [addMinimum, selected, insertMinimum, oldLookup])
            · refine Or.inr ⟨min value old, ?_, by omega, rfl, ?_⟩
              · simp only [addMinimum, selected, insertMinimum, if_pos, oldLookup]
              · intro previous found
                simp only [oldLookup, Option.some.injEq] at found
                omega
      · exact Or.inl (by simp only [addMinimum, selected, insertMinimum, if_neg same])

/-- Actual ordered scan effects preserve old support and can add only scanned keys. -/
private theorem scan_spec [DecidableEq Q] (source : Q → List (Row Q Symbol Guard))
    (keys : List Q) (known : Table Q) (current : Q) :
    scan source keys known current = known current ∨
      ∃ value, scan source keys known current = some value ∧ 0 < value ∧ current ∈ keys ∧
        ∀ old, known current = some old → value ≤ old := by
  induction keys with
  | nil => exact Or.inl rfl
  | cons key rest ih =>
      cases ih with
      | inl retained =>
          cases add_spec key (source key) (scan source rest known) current with
          | inl same => exact Or.inl (same.trans retained)
          | inr changed =>
              obtain ⟨value, found, positive, atKey, bounded⟩ := changed
              refine Or.inr ⟨value, found, positive, List.mem_cons.mpr (Or.inl atKey), ?_⟩
              intro old before
              apply bounded old
              rw [retained]
              exact before
      | inr changed =>
          obtain ⟨middle, actual, positive, listed, bounded⟩ := changed
          cases add_spec key (source key) (scan source rest known) current with
          | inl same => exact Or.inr ⟨middle, same.trans actual, positive, List.mem_cons_of_mem _ listed, bounded⟩
          | inr updated =>
              obtain ⟨value, found, nextPositive, atKey, nextBound⟩ := updated
              exact Or.inr ⟨value, found, nextPositive, List.mem_cons.mpr (Or.inl atKey),
                fun old before => Nat.le_trans (nextBound middle actual) (bounded old before)⟩

/-- Original rows and a known table derive all one-pass support and value effects. -/
theorem pass_spec [DecidableEq Q] (input : SourceSizedPreprocessing.Input Q Symbol Guard)
    (known : Table Q) (current : Q) :
    pass input known current = known current ∨
      ∃ value, pass input known current = some value ∧ 0 < value ∧ current ∈ input.states ∧
        ∀ old, known current = some old → value ≤ old :=
  scan_spec input.rows input.states known current

/-- A known entry remains known and its actual new value cannot increase. -/
theorem pass_known [DecidableEq Q] (input : SourceSizedPreprocessing.Input Q Symbol Guard)
    (known : Table Q) (current : Q) (old : Nat) (before : known current = some old) :
    ∃ value, pass input known current = some value ∧ value ≤ old := by
  rcases pass_spec input known current with retained | ⟨value, found, _positive, _listed, bounded⟩
  · exact ⟨old, retained.trans before, Nat.le_refl _⟩
  · exact ⟨value, found, bounded old before⟩

/-- The actual cold pass creates only positive values at original scanned keys. -/
theorem cold_pass [DecidableEq Q] (input : SourceSizedPreprocessing.Input Q Symbol Guard)
    (current : Q) (value : Nat) (found : pass input (fun _ => none) current = some value) :
    current ∈ input.states ∧ 0 < value := by
  rcases pass_spec input (fun _ => none) current with retained | ⟨next, actual, positive, listed, _bounded⟩
  · simp only [retained, reduceCtorEq] at found
  · have same := Option.some.inj (actual.symm.trans found)
    exact ⟨listed, same ▸ positive⟩

end MicroCFTA.SourceSizedMinimumPass
