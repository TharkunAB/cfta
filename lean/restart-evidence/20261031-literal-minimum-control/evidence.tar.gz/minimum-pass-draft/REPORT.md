# Literal ordered minimum pass: source draft

Status: SOURCE ONLY. Selected candidate is SourceSizedMinimumPass V3,
214 lines, UNCOMPILED. No compiler, evaluator, Haskell/native program, Git,
network, board, production edit or child agent was used. Root alone checks it.
Nat V1 and intermediate signed V2 remain retained. Prior 45/14/47 bundles
were not edited.

## Literal body and model

Actual Table.hs 390–403 defines minimumSizes as converge Map.empty. Each
converge pass uses Map.foldrWithKey addMinimum current rows. It compares the
computed next map with current, then returns current or recurses on next.
Each addMinimum computes mapMaybe(transitionMinimum known) transitions against
ONE fixed known accumulator, chooses minimum, then performs insertWith min.
The child lookup is traverse(Map.lookup known) in original child order, with
1+sum of the returned sizes. It does not mutate the table between source rows.

Index.hs 158–159 defines Size as Integer with the numeric and order instances.
V3 therefore uses signed Lean Int values, not an assumed positive Nat table.
Public one-pass support/nonincrease laws apply even to arbitrary signed known
inputs. The actual cold pass proves positivity internally from empty.

The candidate preserves all operational choices in that body:

- transitionMinimum uses ordered child mapM against one fixed known table.
- The original ordered rows produce filterMap of those exact transition costs.
- least selects the first available value and folds min through the remaining
  costs in row order.
- insertMinimum compares new and old values at only the current key.
- scan recursively evaluates the key suffix first. The current key reads that
  completed suffix table. This is the finite right-fold shape of the source.
- pass uses the original finite Input.rows and Input.states directly. It does
  not trim rows, erase source constraints, reorder rows or invent a target term.

Labels and constraints do not contribute to this actual minimum routine; only
ordered children do. No claim of constrained-language accepted minima follows.

## Closed one-pass properties

pass_spec is a property of the actual computed pass on an original input and
known table. At any state, the result is unchanged, or it is a known value at
an original scanned key and is no greater than every old value at that key.
pass_known derives support preservation and old-known-value nonincrease.
Neither law takes a transition invariant or a supplied future table.

The cold_pass PRODUCER takes only the original finite input. It returns its
actual pass-from-empty table and proves that every returned value is positive
and belongs to an original scanned key. No result/stopping equation is an
input to this producer. The pointwise lookup equations occur only in the
output postcondition of that computed table.

Private lookup/row/min proofs derive positive candidate costs from positive
current child values. Private scan_positive composes that property through
the actual finite suffix schedule. The cold producer discharges its initial
condition from the literal empty table. The caller supplies no positivity or
future transition invariant.

This is one actual pass, not a final minimumSizes result. A single pass can
propagate a child discovered in its suffix to the current parent. Reversing
the original key sequence can change that first-pass result. A simultaneous
map over the original table would lose this source behavior.

## Exact representation and key-order adapter still open

The finite table is represented extensionally as Q→Option Int. Its update and
lookup equations match the source operations. The source Data.Map container,
Size newtype arithmetic and equality representation have no formal host
correspondence proof in this draft. Integer is unbounded here, as in the
source Size declaration; no fixed-width overflow claim is made.

SourceSizedPreprocessing.Input has a complete distinct finite state list and
original ordered annotated rows. It does NOT assert that states is the
Data.Map key traversal order. The exact remaining adapter is named:

  input_scan_matches_foldrWithKey

It must reindex the actual finite original state/key domain into Q, preserve
all source child lookup identities and row lists, and preserve the relative
key order used by Map.foldrWithKey. Additional carrier states must have empty
rows and be proved no-op scans. Complete/distinct alone does not establish
that order. No source key-order or Map implementation proof is assumed as an
extra input to the candidate producer. The adapter remains a separate goal.

## Exact remaining convergence obligation

No final table, chosen iteration count or future fixed point is supplied.
The literal converge loop is not yet modeled or proved total.

For the positive tables generated internally from empty, use the measure:

  (number of absent original states,
   sum of Int.toNat of the known sizes over the original distinct state list).

The private strict-descent obligation is: if next=pass input current differs
from current and current is internally positive, that pair strictly decreases
under Prod.Lex Nat.lt Nat.lt. Support growth must decrease the first component.
With unchanged support, old-value nonincrease and an actual differing state
must give strict sum decrease. Input.complete identifies a differing table
entry inside the list. Input.distinct prevents duplicate-key counting errors.
The existing private positivity preservation must supply the loop condition
internally, starting at empty. It must not become a public producer premise.

After this lemma, implement a computable sameOn check over the original
finite keys and well-founded recurse on the computed next table. Derive full
table equality from that finite check and support containment maintained
internally from cold + actual pass. Do not use Classical function equality,
a final-table oracle or a supplied support certificate. The final public minimumSizes input should be only
the original finite input; its output must be the computed converged table,
fixed under pass and positive. A further proof must establish its relation to
minimum ordinary accepted tree sizes. Neither result is claimed here.

## Scope and verification boundaries

This draft advances the actual minimum pass. It does not close complete
minimum-table production, key-order/container correspondence, the sized
public-query adapter, literal fromRows SCC/memo reification, either worker's
sufficient recursive depth, all-alternative progress or Haskell correspondence.
No Haskell source was changed or executed. No executable issue, Haskell fix or
FINDINGS candidate was established.

All acquired code consists of named bounded cuts or named locator records.
No OLD whole/near-whole module was acquired; the permitted Input/Integer slots
were not needed. Full source hashes, exact actual line vectors, copy hashes,
cumulative unions, retained versions and provider pins are included.

Unresolved elaboration checks are explicit: Option/List.mapM equation names,
filterMap membership witness shape, Int min normalization in omega, structural
scan reduction at pointwise equalities, and the cold producer's final dependent
lookup postcondition. No proof has been tested in this lane.
