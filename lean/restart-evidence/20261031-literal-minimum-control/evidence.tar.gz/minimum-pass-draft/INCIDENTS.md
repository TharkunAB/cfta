# Incidents and retained versions

No read, compiler or runtime failure occurred in this scope.
V1 used natural table values. The actual Size declaration is Integer, so V2
changed to signed Int and kept positivity proofs private and internally
composed. V3 changed cold_pass to return the actual computed table and its
postcondition, so no successful lookup/result equation is a public producer
input. All three versions remain retained. None was compiled.
