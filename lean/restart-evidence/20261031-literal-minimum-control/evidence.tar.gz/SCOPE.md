# Literal signed minimum pass and convergence

The full goal remains the public system theorem from original inputs. It includes accepted membership, complete finite ordered prefixes, sufficient original resources, both recursive workers, interned allocation, public adapters and Haskell correspondence. Preserve generic Mu/Union/opaque sources and the configured order and stop rules. Do not replace the goal with a local cache, forecast or fixed-point theorem.

This phase checks the actual ordered signed minimum pass and a total empty-initialized fixed-point producer. The Map key-order/container adapter and semantic least-minimum theorem remain separate. It does not prove global worker depth, accepted prefix or Haskell correspondence. No Haskell/native execution is planned. Preserve every draft, failed command, repair and complete provider closure. Root alone runs serial 4 GiB zero-swap compiler jobs.
