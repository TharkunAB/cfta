from pathlib import Path
import hashlib
import json
import re
import shlex
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
work = base / '20261117-warm-edge-initial-profile-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this candidate into the active Work directory'
prior_run = base / '20261117-warm-node-initial-profile-publication'
prior_archive = base / '20261117-warm-node-initial-profile-checkpoint'
runtime = base / '20261117-warm-edge-initial-profile-publication'
prior_commit = 'b71affac16a3d390d7290a70a0470b672cd6ccc4'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
expected = [{'new_module': 'SourceCurrentNativeWarmEdgeInitialProfile', 'source_path': 'lean/MicroCFTA/SourceCurrentNativeWarmEdgeInitialProfile.lean', 'raw_sha256': '1d11e825c9a1f15c7a373a44826b0929d1313914a472b4e10a37e88d472e263b', 'raw_bytes': 16506, 'selected_packet': '20261117-next-warm-edge-initial-law-draft', 'selected_manifest_sha256': 'e1c1d5efdf38c44157f799c40a03673aa39330814e2d62952a878ee346ba359c', 'private_run': '20261117-warm-edge-initial-profile-first-check', 'private_receipt': 'FIRST-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentNativeWarmEdgeInitialProfile.cold_prefix_edges_qualified_for_actual_warm_history'], 'private_helper_names': ['closed_codec', 'key_of_codecs', 'qualified_key'], 'header_files': [{'file': 'PUBLIC-HEADER.lean.txt', 'sha256': '545b27d05cbcb267f6e2570e8c5fb8c0e151be428c696087fcbe0cffbfeff06b'}], 'first_check_passed_without_repair': True}, {'new_module': 'SourceCurrentNativeWarmBodyFirstInitialPayloads', 'source_path': 'lean/MicroCFTA/SourceCurrentNativeWarmBodyFirstInitialPayloads.lean', 'raw_sha256': '820261f23407337b3b12836b1369b872951ba15c9a094755ec55a0bb4c25b68b', 'raw_bytes': 19285, 'selected_packet': '20261117-body-first-warm-initial-payloads-draft', 'selected_manifest_sha256': '1041d1792b362f0f2ccef1e1aab273e30978d4fa3d98a44b0aa54434339cbc05', 'private_run': '20261117-warm-body-first-initial-payloads-first-check', 'private_receipt': 'BODY-FIRST-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentNativeWarmBodyFirstInitialPayloads.body_first_initial_payloads_for_actual_warm_history'], 'private_helper_names': ['reference_code', 'reference_read_step'], 'header_files': [{'file': 'FIRST-HEADER.lean.txt', 'sha256': '5dfd76b1cd59b199935417a3da89594d2158ef21fd45c74f400265664e496c97'}], 'first_check_passed_without_repair': True}, {'new_module': 'SourceCurrentNativeWarmCoherentInitialPayloads', 'source_path': 'lean/MicroCFTA/SourceCurrentNativeWarmCoherentInitialPayloads.lean', 'raw_sha256': '8a5c37fbfe00b6abf444ca8342a00eb214b640d748c7d7a5587c605c0bc692b5', 'raw_bytes': 16258, 'selected_packet': '20261117-coherent-warm-initial-payloads-draft', 'selected_manifest_sha256': 'd2a8d0f47149a9345a999ae3e56e46e8e8ac1e1b881b566f54d6f24c12f29fd0', 'private_run': '20261117-warm-coherent-initial-payloads-first-check', 'private_receipt': 'COHERENT-FIRST-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentNativeWarmCoherentInitialPayloads.coherent_initial_payloads_for_actual_warm_history'], 'private_helper_names': [], 'header_files': [{'file': 'FIRST-HEADER.lean.txt', 'sha256': '9110d662dc3addfc8b96a0a84f3fdfe25d46e94e079c096f0f452fcca1fb54da'}], 'first_check_passed_without_repair': True}]
expected_prior_manifest = '26ab029318508e95c06890e30438d5a5dc63c1844aeb8edf17303bc52622b82f'
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage = json.loads(stage_path.read_text())
assert stage['prior_checkpoint'] == prior_commit and stage['modules'] == expected
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6257, 5257, 684, 279)
assert (stage['new_modules'], stage['new_public_theorems'], stage['new_private_helpers'], stage['new_private_predicates']) == (3, 3, 5, 0)
assert stage['new_theorem_declarations'] == 8 and stage['fresh_explicit_axiom_reports'] == 3
assert stage['private_helpers_covered_transitively'] and not stage['private_helpers_counted_as_explicit_fresh_reports']
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (3, 475, 478)
assert stage['old_non_audit_source_files_byte_exact'] == 6253
assert stage['old_audit_bytes'] == 426147 and stage['old_audit_exact_offset'] == 188
assert stage['old_audit_contiguous_bytes_preserved']
assert stage['audit_new_import_bytes'] == 188 and stage['new_ordinary_audit_imports'] == 3
for name in ['all_old_proof_bodies_and_limits_unchanged', 'first_check_passed_without_repair',
             'all_three_original_first_headers_exact',
             'initial_edge_C_and_M_Returned_law_for_same_full_warm_history_proved',
             'four_auxiliary_initial_laws_proved', 'all_six_initial_fields_derived_including_inherited_node',
             'same_fixed_full_warm_history_retained', 'same_complete_old_snapshot_tables',
             'qualification_remains_condition_inside_derived_law']:
    assert stage[name], name
for name in ['old_authentic_entry_or_initial_semantic_law_supplied', 'warm_result_callbacks_proved',
             'warm_query_no_new_mu_proved', 'every_warm_worker_call_qualification_proved',
             'joint_finite_completion_proved', 'haskell_changed']:
    assert not stage[name], name
prior = json.loads((prior_run / 'checked.json').read_text())
assert len(prior['checks']) == 5 and all(c['exit'] == 0 and not c['nonstandard_axioms']
    and not c['diagnostics'] and not c['sorryAx'] for c in prior['checks'])
assert (prior['source_files'], prior['independent_reports'], prior['resource_and_component_probes']) == (6254, 276, 475)
assert prior['owner_resource_probes'] == 264
assert sha((prior_archive / 'manifest.json').read_bytes()) == expected_prior_manifest
baseline = json.loads((work / 'baseline-source-pins.json').read_text())
assert len(baseline) == 6254
new_sources = {item['source_path'] for item in expected}
assert not (new_sources & set(baseline))
assert {str(p.relative_to(root)) for p in (root / 'lean/MicroCFTA').glob('*.lean')} == set(baseline) | new_sources
old_audit = (work / 'Audit-BEFORE.lean.txt').read_bytes()
assert len(old_audit) == stage['old_audit_bytes'] and sha(old_audit) == stage['old_audit_sha256']
assert old_audit.count(b'#print axioms ') == 681
for name, digest in baseline.items():
    data = old_audit if name == audit_name else (root / name).read_bytes()
    assert sha(data) == digest, name
assert len(set(baseline) - {audit_name}) == 6253
assert sha((root / owner_name).read_bytes()) == owner_sha
checked_inputs = []
packets = []
headers = []
normal_sources = []
qnames = []
sessions = [82285, 77625, 79026]
for item, session in zip(expected, sessions):
    module = item['new_module']
    packet = base / item['selected_packet']
    packets.append(packet)
    normal = (root / item['source_path']).read_bytes()
    normal_sources.append(normal)
    assert normal == (packet / (module + '.lean')).read_bytes()
    assert len(normal) == item['raw_bytes'] and sha(normal) == item['raw_sha256']
    assert sha((packet / 'MANIFEST.json').read_bytes()) == item['selected_manifest_sha256']
    manifest = json.loads((packet / 'MANIFEST.json').read_text())
    for name, record in manifest['files'].items():
        data = (packet / name).read_bytes()
        digest = record['sha256'] if isinstance(record, dict) else record
        assert sha(data) == digest, name
        if isinstance(record, dict):
            assert len(data) == record['bytes'], name
    for name, record in json.loads((packet / 'SOURCE-PINS.json').read_text()).items():
        data = (root / name).read_bytes()
        digest = record['sha256'] if isinstance(record, dict) else record
        assert sha(data) == digest, name
        if isinstance(record, dict):
            assert len(data) == record['bytes'], name
    public_names = re.findall(r'^theorem ([A-Za-z0-9_]+)', normal.decode(), re.M)
    private_names = re.findall(r'^private theorem ([A-Za-z0-9_]+)', normal.decode(), re.M)
    assert ['MicroCFTA.' + module + '.' + name for name in public_names] == item['names']
    assert private_names == item['private_helper_names']
    assert not re.findall(r'^private def ', normal.decode(), re.M)
    qnames += item['names']
    for header in item['header_files']:
        path = packet / header['file']
        assert sha(path.read_bytes()) == header['sha256']
        assert path.read_text().rstrip() in normal.decode()
        headers.append(path)
    receipt_path = work / item['private_receipt']
    receipt = json.loads(receipt_path.read_text())
    assert receipt['actual_session'] == session and receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
    assert receipt['run'] == item['private_run'] and receipt['first_check_passed_without_repair']
    assert receipt['public_theorems'] == 1 and receipt['private_helpers'] == len(private_names)
    run = base / item['private_run']
    checked = json.loads((run / 'checked.json').read_text())
    assert checked['normal_module_checked'] and all(checked['passed']) and checked['source_pins_unchanged']
    assert receipt['checks'] == checked['checks']
    assert checked['checks'][1]['total_axiom_reports'] == 1
    assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx'] for c in checked['checks'])
    checked_source = run / 'source/MicroCFTA' / (module + '.lean')
    assert checked_source.read_bytes().startswith(normal)
    assert json.loads((run / 'selection.json').read_text())['sha256'] == item['raw_sha256']
    checked_inputs += [run / name for name in ['checked.json', 'selection.json', 'normal-module.txt', 'source-pins.json']]
    checked_inputs += [checked_source, receipt_path]
assert len(qnames) == len(set(qnames)) == 3
assert sum(len(item['private_helper_names']) for item in expected) == 5
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
assert public == ''.join('#check ' + q + '\n#print axioms ' + q + '\n' for q in qnames).encode()
new_import = (work / 'IMPORTS.lean.txt').read_bytes()
assert new_import == ''.join('import MicroCFTA.' + item['new_module'] + '\n' for item in expected).encode()
assert len(new_import) == 188
audit = (root / audit_name).read_bytes()
assert audit == new_import + old_audit + b'\n' + public
assert audit[len(new_import):len(new_import) + len(old_audit)] == old_audit
assert sum(line.startswith(b'import ') for line in audit.splitlines()) == 5257
assert audit.count(b'#print axioms ') == 684

import gzip
import subprocess

ROOT = root
BASE = base
WORK = work
PUBLIC = runtime
ARCHIVE = '20261117-warm-edge-initial-profile-checkpoint'
BOARD_PREFIX = 'current-board-warm-edge-initial-profile-'
read = lambda path: json.loads(path.read_text())
GIT = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
bindings = read(WORK / 'prior-bindings.json')
assert bindings['prior_checkpoint'] == prior_commit
commit = read(WORK / 'SOURCE-COMMIT.json')
code = commit['source_commit']
assert re.fullmatch(r'[0-9a-f]{40}', code) and commit['parent'] == prior_commit
assert GIT('rev-parse', 'HEAD').decode().strip() == code
assert GIT('rev-parse', code + '^').decode().strip() == prior_commit
assert GIT('branch', '--show-current').decode().strip() == 'formalize'
assert not GIT('status', '--porcelain', '--untracked-files=no')
changed = new_sources | {audit_name}
assert set(commit['files']) == changed
assert set(GIT('diff', '--name-only', prior_commit, code).decode().splitlines()) == changed
for name in changed:
    assert GIT('show', code + ':' + name) == (ROOT / name).read_bytes(), name
assert GIT('show', prior_commit + ':' + audit_name) == old_audit
report = read(PUBLIC / 'checked.json')
verified = read(WORK / 'PUBLICATION-VERIFIED.json')
assert verified['actual_session'] == 20176 and verified['actual_terminal'] and verified['actual_terminal_exit'] == 0
assert verified['checks'] == report['checks']
assert [c['total_axiom_reports'] for c in report['checks']] == [684, 3, 279, 684, 684]
assert [(c['axiom_groups'], c['axiom_free_reports']) for c in report['checks']] == [
    (678, 6), (3, 0), (276, 3), (678, 6), (678, 6)]
assert all(c['exit'] == 0 and not c['diagnostics'] and not c['nonstandard_axioms'] and not c['sorryAx'] for c in report['checks'])
for name, value in {'source_files': 6257, 'direct_audit_imports': 5257,
        'individual_reports': 684, 'independent_reports': 279,
        'fresh_resource_component_reports': 3, 'inherited_resource_component_reports': 475,
        'resource_and_component_probes': 478, 'new_modules': 3, 'new_public_theorems': 3,
        'new_private_helpers': 5, 'new_private_theorems': 5, 'new_theorem_declarations': 8,
        'actual_publication_strict_reports': 3, 'new_private_component_reports': 0,
        'fresh_owner_preflight_reports': 0, 'replaced_old_reports': 0}.items():
    assert report[name] == value, name
for name in ['first_check_passed_without_repair', 'all_new_formal_proof_checks_first_pass',
        'all_three_original_first_headers_exact', 'all_six_initial_fields_derived_including_inherited_node']:
    assert report[name], name
for name in ['private_helpers_counted_as_explicit_fresh_reports', 'owner_recompiled_in_publication_strict_gate',
        'warm_result_callbacks_proved', 'warm_query_no_new_mu_proved',
        'every_warm_worker_call_qualification_proved', 'joint_finite_completion_proved', 'haskell_changed']:
    assert not report[name], name
assert report['inherited_owner_preflight_evidence']['reports'] == 264
assert report['inherited_owner_preflight_evidence']['included_in_inherited_475']
pins = read(PUBLIC / 'source-pins.json')
for name, digest in pins.items():
    assert sha((ROOT / name).read_bytes()) == digest, name
assert verified['pins_independently_reverified'] == len(pins)
source_pins = {name: digest for name, digest in pins.items()
    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
assert len(source_pins) == 6257 and set(source_pins) == set(baseline) | new_sources
prior_path = BASE / bindings['prior_archive']
for name, key in [('manifest.json', 'prior_manifest_sha256'), ('checkpoint.json', 'prior_checkpoint_json_sha256')]:
    data = (prior_path / name).read_bytes()
    assert sha(data) == bindings[key]
    assert GIT('show', prior_commit + ':' + str((prior_path / name).relative_to(ROOT))) == data
old_checkpoint = read(prior_path / 'checkpoint.json')
assert old_checkpoint['resource_and_component_probes'] == 475
assert old_checkpoint['checked_code'] == GIT('rev-parse', prior_commit + '^').decode().strip()
prior_files = {item['path']: item for item in read(prior_path / 'manifest.json')['files']}
for name in ['source-pins.json.gz', 'verification.json', 'archived-inputs.json']:
    data = (prior_path / name).read_bytes()
    assert len(data) == prior_files[name]['bytes'] and sha(data) == prior_files[name]['sha256']
    assert GIT('show', prior_commit + ':' + str((prior_path / name).relative_to(ROOT))) == data
old_pins = json.loads(gzip.decompress((prior_path / 'source-pins.json.gz').read_bytes()))
assert baseline == {name: digest for name, digest in old_pins.items()
    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    assert old_pins[name] == pins[name], name
request = read(WORK / (BOARD_PREFIX + 'request.json'))
canonical = read(WORK / (BOARD_PREFIX + 'canonical.json'))
assert canonical.get('verified', True)
post = canonical.get('post', canonical)
assert post['id'] == request['request_id'] and type(post['sequence']) is int and post['sequence'] > 0
for key, value in [('author', request['username']), ('thread_id', request['thread_id']),
        ('post_type', request['post_type']), ('content', request['content']), ('metadata', request['metadata'])]:
    assert post[key] == value, key
assert post['metadata']['source'] == code
cleanup = read(WORK / 'combined-terminal-cleanup-result.json')
preview = read(WORK / 'TMP-CLEANUP-PREVIEW.json')
assert cleanup['all_owned_terminal_only'] and cleanup['all_four_actual_runs_terminal'] and cleanup['unknown_tmp_entries_preserved']
paths = [item['path'] for item in cleanup['removed_targets']]
assert len(paths) == len(set(paths)) and all(not Path(path).exists() for path in paths)
owned = {read(BASE / item['private_run'] / 'objects.json')['path'] for item in expected}
owned.add(read(PUBLIC / 'objects.json')['path'])
assert set(paths) == owned
assert cleanup['removed_targets'] == preview['owned_terminal_targets']
assert preview['all_four_actual_runs_terminal'] and not preview['live_process_references']
assert preview['terminal_sessions'] == sessions + [20176]
assert cleanup['removed_bytes'] == sum(item['bytes'] for item in cleanup['removed_targets'])
assert cleanup['prior_cumulative_removed_bytes'] + cleanup['removed_bytes'] == cleanup['cumulative_removed_bytes']
start = read(WORK / 'START.json')
resume = read(WORK / 'RESUME-AUTHORIZATION.json')
assert start['user_explicitly_resumed'] and start['earlier_usage_pause_lifted'] and start['active_work_authorized']
assert resume['user_instruction'] == "Keep going. We'll use a reset if needed."
assert resume['user_explicitly_resumed'] and resume['earlier_usage_pause_lifted'] and resume['work_authorized']
assert resume['persistent_goal_control_at_resume'] == 'paused' and resume['no_goal_resume_operation_available']
usage = read(WORK / 'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int, float] and 0 <= percent <= 100
assert usage['earlier_usage_pause_lifted_by_user_resume']
roots = read(WORK / 'selection-roots.json')
assert len(roots) == 10
additional = read(WORK / 'archive-additional-roots.json')
for item in additional:
    assert re.fullmatch(r'20261117-[a-z0-9-]+', item['root'])
    assert item['manifest'] in ['MANIFEST.json', 'manifest.json', 'MANIFEST.sha256']
    manifest_path = BASE / item['root'] / item['manifest']
    assert sha(manifest_path.read_bytes()) == item['sha256']
    manifest = read(manifest_path)
    assert 'UNCOMPILED' in manifest['status']
    for name, record in manifest['files'].items():
        data = (manifest_path.parent / name).read_bytes()
        assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), name
        if isinstance(record, dict):
            assert len(data) == record['bytes'], name
    roots.append(item['root'])
assert len(roots) == len(set(roots))
assert all((BASE / name).is_dir() and not (BASE / name).is_symlink() for name in roots)
for name in roots:
    run = BASE / name
    if (run / 'check.py').exists():
        result = read(run / 'checked.json')
        assert result['checks'] and all(type(item['exit']) is int for item in result['checks']), name
for item in read(WORK / 'original-header-files.json'):
    assert sha((ROOT / item['path']).read_bytes()) == item['sha256']
    assert sha((ROOT / item['original']).read_bytes()) == item['sha256']
selected = sorted(str((BASE / name).relative_to(ROOT)) for name in roots)
assert not (BASE / ARCHIVE).exists()
tree = hashlib.sha256()
for name, digest in sorted(source_pins.items()):
    tree.update(name.encode() + b'\0' + digest.encode() + b'\n')
config = dict(report)
config.update(checked_code=code, prior_checkpoint=prior_commit, public_run=str(PUBLIC), public_gates=5,
    explicit_reports=report['individual_reports'], board_prefix=BOARD_PREFIX,
    board_post_id=post['id'], board_sequence=post['sequence'], source_tree_sha256=tree.hexdigest(),
    old_non_audit_source_files_byte_exact=6253,
    old_audit_contiguous_bytes_preserved=426147, old_audit_exact_offset=188,
    ordinary_audit_import_bytes=188, new_audit_imports=3, old_audit_is_prefix=False,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],
    cleanup_receipt='combined-terminal-cleanup-result.json',
    tmp_readable_regular_file_bytes_after=cleanup['tmp_readable_regular_file_bytes_after'],
    tmp_census_errors=cleanup['tmp_census_errors'], unknown_tmp_entries_preserved=True,
    primary_usage_percent=percent, primary_usage_checked_at=usage['event_timestamp'],
    prior_immutable_archive=bindings['prior_archive'], prior_manifest_sha256=bindings['prior_manifest_sha256'],
    fresh_strict_reports=3, inherited_component_reports=475,
    all_new_formal_proof_checks_first_pass=True, first_check_passed_without_repair=True,
    historical_failed_proofs_preserved_in_prior_immutable_chain=True,
    additional_frozen_roots=additional, additional_frozen_roots_theorem_credit=0,
    warm_callback_origin_gap_preserved=True,
    user_explicitly_resumed=True, earlier_usage_pause_lifted=True,
    work_authorized_by_explicit_user_resume=True, persistent_goal_control_status='paused',
    goal_resume_operation_performed=False, goal_completion_claimed=False, goal_active=False,
    joint_finite_completion_proved=False, compiled_haskell_correspondence_proved=False, haskell_changed=False)
skipped = sorted(str(path.relative_to(ROOT)) for path in BASE.iterdir()
    if path.is_dir() and path.name.startswith('20261117-') and str(path.relative_to(ROOT)) not in selected)
review = {'prior_checkpoint': prior_commit, 'selected_roots': len(selected), 'base_roots': 10,
    'additional_frozen_roots': additional, 'additional_frozen_roots_theorem_credit': 0,
    'fresh_reports_this_batch': 3, 'inherited_reports': 475, 'combined_reports': 478,
    'new_public_theorems': 3, 'new_private_helpers': 5, 'new_theorem_declarations': 8,
    'new_private_explicit_reports': 0, 'private_helpers_counted_as_explicit_reports': False,
    'all_current_component_first_checks_passed': True, 'inherited_owner_reports': 264,
    'all_six_initial_fields_derived_including_inherited_node': True,
    'warm_callback_origin_gap_preserved': True, 'warm_result_callbacks_proved': False,
    'warm_query_no_new_mu_proved': False, 'joint_finite_completion_proved': False,
    'haskell_changed': False, 'goal_completion_claimed': False}
note = (WORK / 'checkpoint-note.md').read_text()
for key, value in {'THEOREMS': report['audited_theorems'], 'REMOVED': cleanup['removed_bytes'],
                   'CLEANUP': cleanup['cumulative_removed_bytes'], 'USAGE': percent}.items():
    note = note.replace('{{' + key + '}}', str(value))
assert set(re.findall(r'\{\{(.*?)\}\}', note)) == {'TIME', 'TREE', 'CODE'}
outputs = {'checkpoint-config.json': config, 'archive-roots.json': selected,
           'skipped-published-roots.json': skipped, 'selection-review.json': review}
assert all(not (WORK / name).exists() for name in outputs)
for name, value in outputs.items():
    (WORK / name).write_text(json.dumps(value, indent=2) + '\n')
(WORK / 'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code': code, 'packet': ARCHIVE, 'roots': len(selected),
    'board_sequence': post['sequence'], 'fresh_reports': 3, 'inherited_reports': 475,
    'combined_reports': 478, 'future_root_credit': 0}))
