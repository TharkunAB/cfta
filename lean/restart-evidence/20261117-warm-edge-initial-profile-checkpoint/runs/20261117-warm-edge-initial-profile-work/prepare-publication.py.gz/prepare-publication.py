from pathlib import Path
import hashlib
import json
import re
import shlex
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
work = base / '20261117-warm-edge-initial-profile-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this candidate into the active Work directory'
prior_run = base / '20261117-warm-node-initial-profile-publication'
prior_archive = base / '20261117-warm-node-initial-profile-checkpoint'
runtime = base / '20261117-warm-edge-initial-profile-publication'
prior_commit = 'b71affac16a3d390d7290a70a0470b672cd6ccc4'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
expected = [{'new_module': 'SourceCurrentNativeWarmEdgeInitialProfile', 'source_path': 'lean/MicroCFTA/SourceCurrentNativeWarmEdgeInitialProfile.lean', 'raw_sha256': '1d11e825c9a1f15c7a373a44826b0929d1313914a472b4e10a37e88d472e263b', 'raw_bytes': 16506, 'selected_packet': '20261117-next-warm-edge-initial-law-draft', 'selected_manifest_sha256': 'e1c1d5efdf38c44157f799c40a03673aa39330814e2d62952a878ee346ba359c', 'private_run': '20261117-warm-edge-initial-profile-first-check', 'private_receipt': 'FIRST-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentNativeWarmEdgeInitialProfile.cold_prefix_edges_qualified_for_actual_warm_history'], 'private_helper_names': ['closed_codec', 'key_of_codecs', 'qualified_key'], 'header_files': [{'file': 'PUBLIC-HEADER.lean.txt', 'sha256': '545b27d05cbcb267f6e2570e8c5fb8c0e151be428c696087fcbe0cffbfeff06b'}], 'first_check_passed_without_repair': True}, {'new_module': 'SourceCurrentNativeWarmBodyFirstInitialPayloads', 'source_path': 'lean/MicroCFTA/SourceCurrentNativeWarmBodyFirstInitialPayloads.lean', 'raw_sha256': '820261f23407337b3b12836b1369b872951ba15c9a094755ec55a0bb4c25b68b', 'raw_bytes': 19285, 'selected_packet': '20261117-body-first-warm-initial-payloads-draft', 'selected_manifest_sha256': '1041d1792b362f0f2ccef1e1aab273e30978d4fa3d98a44b0aa54434339cbc05', 'private_run': '20261117-warm-body-first-initial-payloads-first-check', 'private_receipt': 'BODY-FIRST-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentNativeWarmBodyFirstInitialPayloads.body_first_initial_payloads_for_actual_warm_history'], 'private_helper_names': ['reference_code', 'reference_read_step'], 'header_files': [{'file': 'FIRST-HEADER.lean.txt', 'sha256': '5dfd76b1cd59b199935417a3da89594d2158ef21fd45c74f400265664e496c97'}], 'first_check_passed_without_repair': True}, {'new_module': 'SourceCurrentNativeWarmCoherentInitialPayloads', 'source_path': 'lean/MicroCFTA/SourceCurrentNativeWarmCoherentInitialPayloads.lean', 'raw_sha256': '8a5c37fbfe00b6abf444ca8342a00eb214b640d748c7d7a5587c605c0bc692b5', 'raw_bytes': 16258, 'selected_packet': '20261117-coherent-warm-initial-payloads-draft', 'selected_manifest_sha256': 'd2a8d0f47149a9345a999ae3e56e46e8e8ac1e1b881b566f54d6f24c12f29fd0', 'private_run': '20261117-warm-coherent-initial-payloads-first-check', 'private_receipt': 'COHERENT-FIRST-CHECK-VERIFIED.json', 'names': ['MicroCFTA.SourceCurrentNativeWarmCoherentInitialPayloads.coherent_initial_payloads_for_actual_warm_history'], 'private_helper_names': [], 'header_files': [{'file': 'FIRST-HEADER.lean.txt', 'sha256': '9110d662dc3addfc8b96a0a84f3fdfe25d46e94e079c096f0f452fcca1fb54da'}], 'first_check_passed_without_repair': True}]
expected_prior_manifest = '26ab029318508e95c06890e30438d5a5dc63c1844aeb8edf17303bc52622b82f'
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage = json.loads(stage_path.read_text())
assert stage['prior_checkpoint'] == prior_commit and stage['modules'] == expected
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6257, 5257, 684, 279)
assert (stage['new_modules'], stage['new_public_theorems'], stage['new_private_helpers'], stage['new_private_predicates']) == (3, 3, 5, 0)
assert stage['new_theorem_declarations'] == 8 and stage['fresh_explicit_axiom_reports'] == 3
assert stage['private_helpers_covered_transitively'] and not stage['private_helpers_counted_as_explicit_fresh_reports']
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (3, 475, 478)
assert stage['old_non_audit_source_files_byte_exact'] == 6253
assert stage['old_audit_bytes'] == 426147 and stage['old_audit_exact_offset'] == 188
assert stage['old_audit_contiguous_bytes_preserved']
assert stage['audit_new_import_bytes'] == 188 and stage['new_ordinary_audit_imports'] == 3
for name in ['all_old_proof_bodies_and_limits_unchanged', 'first_check_passed_without_repair',
             'all_three_original_first_headers_exact',
             'initial_edge_C_and_M_Returned_law_for_same_full_warm_history_proved',
             'four_auxiliary_initial_laws_proved', 'all_six_initial_fields_derived_including_inherited_node',
             'same_fixed_full_warm_history_retained', 'same_complete_old_snapshot_tables',
             'qualification_remains_condition_inside_derived_law']:
    assert stage[name], name
for name in ['old_authentic_entry_or_initial_semantic_law_supplied', 'warm_result_callbacks_proved',
             'warm_query_no_new_mu_proved', 'every_warm_worker_call_qualification_proved',
             'joint_finite_completion_proved', 'haskell_changed']:
    assert not stage[name], name
prior = json.loads((prior_run / 'checked.json').read_text())
assert len(prior['checks']) == 5 and all(c['exit'] == 0 and not c['nonstandard_axioms']
    and not c['diagnostics'] and not c['sorryAx'] for c in prior['checks'])
assert (prior['source_files'], prior['independent_reports'], prior['resource_and_component_probes']) == (6254, 276, 475)
assert prior['owner_resource_probes'] == 264
assert sha((prior_archive / 'manifest.json').read_bytes()) == expected_prior_manifest
baseline = json.loads((work / 'baseline-source-pins.json').read_text())
assert len(baseline) == 6254
new_sources = {item['source_path'] for item in expected}
assert not (new_sources & set(baseline))
assert {str(p.relative_to(root)) for p in (root / 'lean/MicroCFTA').glob('*.lean')} == set(baseline) | new_sources
old_audit = (work / 'Audit-BEFORE.lean.txt').read_bytes()
assert len(old_audit) == stage['old_audit_bytes'] and sha(old_audit) == stage['old_audit_sha256']
assert old_audit.count(b'#print axioms ') == 681
for name, digest in baseline.items():
    data = old_audit if name == audit_name else (root / name).read_bytes()
    assert sha(data) == digest, name
assert len(set(baseline) - {audit_name}) == 6253
assert sha((root / owner_name).read_bytes()) == owner_sha
checked_inputs = []
packets = []
headers = []
normal_sources = []
qnames = []
sessions = [82285, 77625, 79026]
for item, session in zip(expected, sessions):
    module = item['new_module']
    packet = base / item['selected_packet']
    packets.append(packet)
    normal = (root / item['source_path']).read_bytes()
    normal_sources.append(normal)
    assert normal == (packet / (module + '.lean')).read_bytes()
    assert len(normal) == item['raw_bytes'] and sha(normal) == item['raw_sha256']
    assert sha((packet / 'MANIFEST.json').read_bytes()) == item['selected_manifest_sha256']
    manifest = json.loads((packet / 'MANIFEST.json').read_text())
    for name, record in manifest['files'].items():
        data = (packet / name).read_bytes()
        digest = record['sha256'] if isinstance(record, dict) else record
        assert sha(data) == digest, name
        if isinstance(record, dict):
            assert len(data) == record['bytes'], name
    for name, record in json.loads((packet / 'SOURCE-PINS.json').read_text()).items():
        data = (root / name).read_bytes()
        digest = record['sha256'] if isinstance(record, dict) else record
        assert sha(data) == digest, name
        if isinstance(record, dict):
            assert len(data) == record['bytes'], name
    public_names = re.findall(r'^theorem ([A-Za-z0-9_]+)', normal.decode(), re.M)
    private_names = re.findall(r'^private theorem ([A-Za-z0-9_]+)', normal.decode(), re.M)
    assert ['MicroCFTA.' + module + '.' + name for name in public_names] == item['names']
    assert private_names == item['private_helper_names']
    assert not re.findall(r'^private def ', normal.decode(), re.M)
    qnames += item['names']
    for header in item['header_files']:
        path = packet / header['file']
        assert sha(path.read_bytes()) == header['sha256']
        assert path.read_text().rstrip() in normal.decode()
        headers.append(path)
    receipt_path = work / item['private_receipt']
    receipt = json.loads(receipt_path.read_text())
    assert receipt['actual_session'] == session and receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
    assert receipt['run'] == item['private_run'] and receipt['first_check_passed_without_repair']
    assert receipt['public_theorems'] == 1 and receipt['private_helpers'] == len(private_names)
    run = base / item['private_run']
    checked = json.loads((run / 'checked.json').read_text())
    assert checked['normal_module_checked'] and all(checked['passed']) and checked['source_pins_unchanged']
    assert receipt['checks'] == checked['checks']
    assert checked['checks'][1]['total_axiom_reports'] == 1
    assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx'] for c in checked['checks'])
    checked_source = run / 'source/MicroCFTA' / (module + '.lean')
    assert checked_source.read_bytes().startswith(normal)
    assert json.loads((run / 'selection.json').read_text())['sha256'] == item['raw_sha256']
    checked_inputs += [run / name for name in ['checked.json', 'selection.json', 'normal-module.txt', 'source-pins.json']]
    checked_inputs += [checked_source, receipt_path]
assert len(qnames) == len(set(qnames)) == 3
assert sum(len(item['private_helper_names']) for item in expected) == 5
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
assert public == ''.join('#check ' + q + '\n#print axioms ' + q + '\n' for q in qnames).encode()
new_import = (work / 'IMPORTS.lean.txt').read_bytes()
assert new_import == ''.join('import MicroCFTA.' + item['new_module'] + '\n' for item in expected).encode()
assert len(new_import) == 188
audit = (root / audit_name).read_bytes()
assert audit == new_import + old_audit + b'\n' + public
assert audit[len(new_import):len(new_import) + len(old_audit)] == old_audit
assert sum(line.startswith(b'import ') for line in audit.splitlines()) == 5257
assert audit.count(b'#print axioms ') == 684

# Validation above is read-only. Only Root may create the publication run.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-warm-edge-and-aux-publication-'))
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
(runtime / 'PUBLIC-PROBES.lean.txt').write_bytes(public)
commands = []
strict_sources = []
for item, normal in zip(expected, normal_sources):
    module = item['new_module']
    probes = ''.join('#check @' + name + '\n#print axioms ' + name + '\n' for name in item['names'])
    assert probes.count('#print axioms ') == 1
    strict_source = runtime / 'source/MicroCFTA' / (module + '.lean')
    strict_source.parent.mkdir(parents=True, exist_ok=True)
    strict_source.write_bytes(normal + b'\n' + probes.encode())
    strict_sources.append(strict_source)
    (runtime / (module + '-PROBES.lean.txt')).write_text(probes)
    commands.append(['lake', 'env', 'lean', '-j1', '-DwarningAsError=true', '-R',
        str(strict_source.parent.parent), '-o', str(objects / (module + '.olean')), str(strict_source)])
independent = runtime / 'IndependentProbes.lean'
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 276
assert all(('import MicroCFTA.' + item['new_module'] + '\n').encode() not in prior_independent for item in expected)
independent.write_bytes(new_import + prior_independent + b'\n' + public)
assert independent.read_bytes().count(b'#print axioms ') == 279
selection = {'prior_checkpoint': prior_commit,
    'prior_archive_manifest_sha256': expected_prior_manifest,
    'prior_checked_sha256': sha((prior_run / 'checked.json').read_bytes()),
    'prior_pins_sha256': sha((prior_run / 'source-pins.json').read_bytes()),
    'baseline_sha256': sha((work / 'baseline-source-pins.json').read_bytes()),
    'stage_sha256': sha(stage_path.read_bytes()), 'old_audit_sha256': sha(old_audit),
    'unchanged_resource_owner_sha256': owner_sha,
    'prior_source_files': 6254, 'prior_combined_reports': 475,
    'replaced_old_reports': 0, 'inherited_reports': 475, 'fresh_reports': 3, 'combined_reports': 478,
    'new_theorem_declarations': 8, 'new_public_theorems': 3, 'new_private_theorems': 5,
    'new_private_explicit_reports': 0, 'private_helpers_counted_as_explicit_fresh_reports': False,
    'old_normal_sources_byte_exact_except_audit': 6253,
    'old_audit_bytes_retained_contiguously_after_three_imports': True,
    'old_audit_offset': len(new_import), 'new_audit_imports': 3,
    'owner_preflight_reports_fresh_this_batch': 0, 'owner_reports_inherited': 264,
    'old_toolchain_and_proof_inputs_reverified': True, 'axiom_strings_replayed': False}
(runtime / 'INHERITANCE-SELECTION.json').write_text(json.dumps(selection, indent=2) + '\n')
STRICT_BINDING_TEMPLATE = "from pathlib import Path\nimport gzip\nimport hashlib\nimport json\nimport subprocess\n\nroot = Path('/home/tritlo/Code/mcfta')\nruntime = Path(__file__).parent\nprior = root / 'lean/restart-evidence/20261117-warm-node-initial-profile-publication'\narchive = root / 'lean/restart-evidence/20261117-warm-node-initial-profile-checkpoint'\nwork = root / 'lean/restart-evidence/20261117-warm-edge-initial-profile-work'\nsha = lambda data: hashlib.sha256(data).hexdigest()\nselection = json.loads((runtime / 'INHERITANCE-SELECTION.json').read_text())\nassert sha((archive / 'manifest.json').read_bytes()) == selection['prior_archive_manifest_sha256']\nassert selection['prior_archive_manifest_sha256'] == '26ab029318508e95c06890e30438d5a5dc63c1844aeb8edf17303bc52622b82f'\ncommitted = subprocess.check_output(['git', 'show', selection['prior_checkpoint'] + ':'\n    + str((archive / 'manifest.json').relative_to(root))], cwd=root)\nassert committed == (archive / 'manifest.json').read_bytes()\nsubprocess.run(['python3', str(archive / 'verify.py')], check=True)\nrecords = json.loads((archive / 'archived-inputs.json').read_text())\nfor name in ['checked.json', 'source-pins.json']:\n    path = prior / name\n    record = next(item for item in records if item['original'] == str(path))\n    archived = (archive / record['archived']).read_bytes()\n    if record['gzip']:\n        archived = gzip.decompress(archived)\n    assert archived == path.read_bytes()\nassert sha((prior / 'checked.json').read_bytes()) == selection['prior_checked_sha256']\nassert sha((prior / 'source-pins.json').read_bytes()) == selection['prior_pins_sha256']\nassert sha((work / 'baseline-source-pins.json').read_bytes()) == selection['baseline_sha256']\nassert sha((work / 'SOURCES-NORMAL-STAGING.json').read_bytes()) == selection['stage_sha256']\nassert sha((work / 'Audit-BEFORE.lean.txt').read_bytes()) == selection['old_audit_sha256']\nfor name, digest in json.loads((prior / 'source-pins.json').read_text()).items():\n    data = (work / 'Audit-BEFORE.lean.txt').read_bytes() if name == 'lean/MicroCFTA/Audit.lean' else (root / name).read_bytes()\n    assert sha(data) == digest, name\nassert sha((root / 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean').read_bytes()) == selection['unchanged_resource_owner_sha256']\nprint(json.dumps({'inherited_component_reports_verified': 475,\n                  'fresh_public_reports_expected': 3,\n                  'new_private_helper_declarations': 5,\n                  'new_private_explicit_reports': 0,\n                  'fresh_owner_preflight_reports': 0,\n                  'unchanged_owner_reports_inherited': 264,\n                  'old_sources_and_toolchain_byte_exact': True}), flush=True)\n"
strict = runtime / 'strict-new-and-bind.py'
strict.write_text(STRICT_BINDING_TEMPLATE + '\ncommands = ' + repr(commands)
    + '\nfor command in commands:\n    subprocess.run(command, check=True)\n')
template = (prior_run / 'check.py').read_text()
driver = template[:template.index('\njobs =')]
jobs = [('public-build', 'exec lake build', 0),
    ('strict-new-components-and-prior-bindings', 'exec python3 ' + shlex.quote(str(strict)), 3),
    ('independent-imports', 'exec lake env lean -j1 -DwarningAsError=true ' + shlex.quote(str(independent)), 279),
    ('audit-build', 'exec lake build MicroCFTA.Audit', 0),
    ('audit-strict', 'exec lake env lean -j1 -DwarningAsError=true MicroCFTA/Audit.lean', 684)]
driver += '\njobs = ' + repr(jobs) + '''
for name, command, count in jobs:
    run(name, command, count)
assert len(checks) == 5
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx']
           and (not job[2] or c['total_axiom_reports'] == job[2]) for c, job in zip(checks, jobs))
assert checks[1]['axiom_groups'] == 3 and checks[1]['axiom_free_reports'] == 0
assert checks[2]['axiom_groups'] == 276 and checks[2]['axiom_free_reports'] == 3
assert checks[4]['axiom_groups'] == 678 and checks[4]['axiom_free_reports'] == 6
match = re.search(r'Checked axiom dependencies of (\\d+) MicroCFTA theorems\\.', (runtime / 'audit-strict.txt').read_text())
assert match
'''
report = dict(prior)
for name in ['checks', 'limits', 'at', 'audited_theorems', 'checked_code', 'owner_preflight_evidence',
             'first_rejected_parser_run_and_identifier_repair_preserved',
             'old_audit_bytes_preserved_as_prefix']:
    report.pop(name, None)
for name in list(report):
    if name.startswith('old_non_audit_'):
        report.pop(name)
report.update(source_files=6257, direct_audit_imports=5257, individual_reports=684,
    independent_reports=279, resource_and_component_probes=478,
    inherited_resource_component_reports=475, fresh_resource_component_reports=3,
    replaced_old_reports=0, fresh_owner_preflight_reports=0,
    fresh_strict_normal_reports=3, actual_publication_strict_reports=3,
    resource_component_evidence='3 actual fresh public strict reports plus475 inherited reports;5 private helpers checked transitively add no explicit report; no replacement, fresh owner preflight or axiom-string replay',
    new_component_reports=3, new_theorem_reports=3, new_theorem_declarations=8,
    new_modules=3, new_public_theorems=3, new_private_theorems=5,
    new_private_component_reports=0, new_public_component_reports=3, new_private_predicates=0,
    new_private_helpers=5, private_helpers_checked_transitively=True,
    private_helpers_counted_as_explicit_fresh_reports=False,
    new_relation_declaration_checks=0, new_relation_declaration_reports=0,
    owner_resource_probes=264, previous_owner_resource_probes=264,
    owner_recompiled_in_publication_strict_gate=False, fresh_owner_preflight_evidence=None,
    inherited_owner_preflight_evidence={'prior_run': str(prior_run), 'reports': 264,
        'normal_owner_sha256': owner_sha, 'fresh_this_batch': False, 'included_in_inherited_475': True},
    old_non_audit_source_files_byte_exact=6253, entire_previous_resource_owner_byte_exact=True,
    old_resource_owner_sha256=owner_sha, changed_existing_owners=0,
    old_audit_bytes_preserved_contiguously_after_three_imports=True,
    old_audit_bytes_preserved_contiguously_after_one_import=False,
    old_audit_exact_offset=len(new_import), new_audit_imports=3,
    all_old_proof_bodies_and_limits_unchanged=True,
    first_check_passed_without_repair=True, all_new_formal_proof_checks_first_pass=True,
    prior_node_parser_failure_preserved_in_inherited_checkpoint=True,
    all_three_original_first_headers_exact=True,
    initial_edge_C_and_M_Returned_law_for_same_full_warm_history_proved=True,
    body_first_node_and_edge_initial_fields_proved=True,
    coherent_node_and_toprow_edge_initial_fields_proved=True,
    four_auxiliary_initial_laws_proved=True, all_six_initial_fields_derived_including_inherited_node=True,
    same_fixed_full_warm_history_retained=True, same_complete_old_snapshot_tables=True,
    qualification_remains_condition_inside_derived_law=True,
    old_authentic_entry_or_initial_semantic_law_supplied=False,
    edge_seed_header_not_compiled=False, full_open_header_not_compiled=True,
    edge_initial_law_proved=True, warm_result_callbacks_proved=False,
    initial_law_scope={'old_history': 'actual cold prefix at arbitrary oldControl; same complete old memo tables',
        'new_history': 'one fixed full actual warm trace retained jointly for all cells and qualifiers',
        'fields': 'inherited node C/M plus new edge C/M, BodyFirst node/edge, Coherent node/TopRow edge',
        'meaning': 'Profile or exact product/row shape under the stated qualifier; no language inhabitance',
        'not_covered': 'warm body/result callback rules, full warm NoNewMu or finite completion'},
    future_Profile_or_Gamma_or_model_supplier=False,
    every_warm_worker_call_qualification_proved=False, warm_query_no_new_mu_proved=False,
    all_warm_cells_source_qualification_proved=False,
    earlier_source_family_semantic_IH_discharged=False,
    every_cell_joint_query_attachment_proved=False, inherited_cell_semantic_chronology_proved=False,
    mixed_qualified_profile_height_orientation_derived=False,
    joint_finite_completion_proved=False, all_native_inhabitance_proved=False,
    source_terminal_marker_native_inhabitance_proved=False, source_type_marker_class_consistency_proved=False,
    compiled_haskell_correspondence_proved=False, haskell_changed=False,
    same_original_runtime_fuels=True,
    proof_limits='unchanged defaults; unchanged owner proof settings inherited',
    prior_checkpoint=prior_commit, prior_immutable_archive=prior_archive.name, public_run=str(runtime))
driver += 'report = ' + repr(report) + '\n'
driver += '''report.update(checks=checks, limits=limits, at=datetime.datetime.now().astimezone().isoformat(),
              audited_theorems=int(match.group(1)))
(runtime / 'checked.json').write_text(json.dumps(report, indent=2) + '\\n')
print(json.dumps(report), flush=True)
'''
(runtime / 'check.py').write_text(driver)
files = list((root / 'lean/MicroCFTA').glob('*.lean'))
files += [root / name for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']]
files += [p for p in runtime.iterdir() if p.is_file()] + strict_sources
files += [Path(__file__), stage_path, work / 'baseline-source-pins.json', work / 'PUBLIC-PROBES.lean.txt',
    work / 'IMPORTS.lean.txt', work / 'Audit-BEFORE.lean.txt'] + headers + checked_inputs
for packet in packets:
    files += [packet / name for name in ['MANIFEST.json', 'SOURCE-PINS.json', 'PROBES.lean.txt']]
(runtime / 'source-pins.json').write_text(json.dumps(
    {str(p.relative_to(root)): sha(p.read_bytes()) for p in files}, indent=2) + '\n')
print(json.dumps({'run': str(runtime), 'gates': 5, 'fresh_component_reports': 3,
    'inherited_component_reports': 475, 'combined_component_reports': 478,
    'new_theorem_declarations': 8, 'new_private_explicit_reports': 0,
    'replaced_old_reports': 0, 'fresh_owner_preflight_reports': 0,
    'inherited_owner_reports': 264, 'independent_reports': 279,
    'audit_reports': 684, 'objects': str(objects)}))
