# Existing source APIs

Source excerpts only. The new candidate has not been compiled.

## lean/MicroCFTA/SourceRecursiveIntersectionCode.lean

```lean
-- lines 18-27
  | fail (failure : Failure) : Code Symbol Guard A
  | work {X : Type} (job : Work Symbol Guard X) (next : X → Code Symbol Guard A) : Code Symbol Guard A
  | enter (domain : Interned DomainKey) (left right : Value Symbol Guard) (first second : Nat)
      (next : Interned DomainKey → Code Symbol Guard A) : Code Symbol Guard A
  | read (name : Nat) (next : Option (Value Symbol Guard) → Code Symbol Guard A) : Code Symbol Guard A
  | optionalBinder (key : Nat × Nat) (body : Value Symbol Guard)
      (next : Value Symbol Guard → Code Symbol Guard A) : Code Symbol Guard A
  | node (request : NodeRequest Symbol Guard) (next : Value Symbol Guard → Code Symbol Guard A) : Code Symbol Guard A
  | edge (request : EdgeRequest Symbol Guard) (next : EdgeValue Symbol Guard → Code Symbol Guard A) : Code Symbol Guard A
  | finishNode (handle : Nat) (value : Value Symbol Guard) (next : Code Symbol Guard A) : Code Symbol Guard A
```

## lean/MicroCFTA/SourceEqualityNativeDemand.lean

```lean
-- lines 104-130
/-- A finite bound retains the exact remaining control and every current cache. -/
noncomputable def execute [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] :
    Nat → Control Output → State width → Outcome width Output
  | 0, control, state => .yielded control state
  | fuel + 1, control, state =>
      match step control state with
      | .yielded next after => execute fuel next after
      | .done value after => .done value after
      | .failed failure after => .failed failure after
      | .constraintError message after => .constraintError message after
      | .blocked reason next after => .blocked reason next after

/-- Only yielded work continues under another finite bound. -/
noncomputable def resume [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (fuel : Nat) : Outcome width Output → Outcome width Output
  | .yielded next after => execute fuel next after
  | .done value after => .done value after
  | .failed failure after => .failed failure after
  | .constraintError message after => .constraintError message after
  | .blocked reason next after => .blocked reason next after

/-- Splitting a bound preserves every continuation, publication, and operation cache. -/
theorem execute_add [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (fuel extra : Nat) (control : Control Output) (state : State width) :
    execute (fuel + extra) control state = resume extra (execute fuel control state) := by
  induction fuel generalizing control state with
  | zero => simp only [Nat.zero_add, execute, resume]
```

## lean/MicroCFTA/SourceRecursiveIntersectionNative.lean

```lean
-- lines 35-50
/-- One native step performs one effect or expands one published recursive request. -/
def step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (code : Code Symbol Guard A) (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) : Outcome width Symbol Guard A :=
  match code with
  | .pure value => .done value state
  | .fail failure => .failed failure state
  | .work job next =>
      let actual := InternedConstructorTemplates.run job state.machine.heap
      .yielded (next actual.1) (advance state { state.machine with heap := actual.2 })
  | .enter domain left right first second next =>
      let entered := SourceRecursiveIntersectionEnvironment.enter state.machine.domains domain.key left right first second
      .yielded (next entered.1) (advance state { state.machine with domains := entered.2 })
  | .read name next => .yielded (next (SourcePreparedSharedRows.read state.machine.heap name)) state
  | .optionalBinder key body next =>
      match SourceRecursiveIntersectionMaybeMu.maybeMu key body state.machine.heap with
      | .done value after => .yielded (next value) (advance state { state.machine with heap := after })
```

## lean/MicroCFTA/SourceRecursiveIntersectionNativeEffects.lean

```lean
-- lines 32-56
/-- Native domain entry uses the original canonical allocation before entering the continuation. -/
theorem enter_step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (domain : Interned DomainKey) (left right : Value Symbol Guard) (first second : Nat)
    (next : Interned DomainKey → Code Symbol Guard A) (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) :
    let actual := SourceRecursiveIntersectionEnvironment.enter state.machine.domains domain.key left right first second
    step emptyGuard conjoin (.enter domain left right first second next) state =
      .yielded (next actual.1) (advance state { state.machine with domains := actual.2 }) := rfl

/-- Actual canonical domain allocation retains every pending memo request and creates a valid body domain. -/
theorem enter_step_valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard)
    (conjoin : Guard → Guard → Guard) (state : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (valid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin state)
    (domain : Interned DomainKey) (known : Domain state.machine domain) (left right : Value Symbol Guard)
    (leftAvailable : InternedProbeProvenance.Available state.machine.heap left)
    (rightAvailable : InternedProbeProvenance.Available state.machine.heap right) (first second : Nat)
    (next : Interned DomainKey → Code Symbol Guard A) :
    let actual := SourceRecursiveIntersectionEnvironment.enter state.machine.domains domain.key left right first second
    SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin (step emptyGuard conjoin (.enter domain left right first second next) state).state ∧
      Domain (step emptyGuard conjoin (.enter domain left right first second next) state).state.machine actual.1 := by
  have checked := entered state.machine valid.machine domain known left right leftAvailable rightAvailable first second
  exact ⟨advance_valid width emptyGuard conjoin state valid _ checked.1 checked.2.1, checked.2.2⟩

/-- Original physical binding reads retain every current source and memo cache. -/
theorem read_step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (name : Nat) (next : Option (Value Symbol Guard) → Code Symbol Guard A) (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) :
```

## lean/MicroCFTA/SourceRecursiveIntersectionKernelCalls.lean

```lean
-- lines 32-48
    exact InternedBinderProtocol.intern_grows _ _

/-- Actual Mu-domain allocation derives validity, exact growth, and the new complete binding invariant. -/
theorem entered (state : Machine Symbol Guard) (valid : Valid state) (domain : Interned DomainKey) (known : Domain state domain)
    (left right : Value Symbol Guard) (leftAvailable : Available state.heap left) (rightAvailable : Available state.heap right)
    (first second : Nat) :
    let actual := SourceRecursiveIntersectionEnvironment.enter state.domains domain.key left right first second
    let after : Machine Symbol Guard := {state with domains := actual.2}
    Valid after ∧ Extension state after ∧ Domain after actual.1 := by
  obtain ⟨domainValid, represented, canonical, typed, bindings⟩ := SourceRecursiveIntersectionEnvironment.enter_correct
    state.heap state.domains valid.2 domain.key known.bindings left right leftAvailable rightAvailable first second
  have growth := make_domain_grows state.domains
    (extend domain.key ((SourceRecursiveIntersectionEnvironment.bindings left right).map Prod.fst)
      (SourceRecursiveIntersectionControl.pair first second))
  refine ⟨⟨valid.1, domainValid⟩, ⟨grows_refl _, extends_refl _, growth⟩, ?_⟩
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [represented.1]
```

## lean/MicroCFTA/SourceRecursiveIntersectionKernelFacts.lean

```lean
-- lines 17-57

/-- Later caller states retain physical records, issued identities, and canonical domain entries. -/
structure Extension (before after : Machine Symbol Guard) : Prop where
  heap : Grows before.heap after.heap
  history : Extends before.heap.nodes.issued after.heap.nodes.issued
  domains : Extends before.domains.table after.domains.table

/-- A call with no cache effect retains every earlier record. -/
theorem Extension.refl (state : Machine Symbol Guard) : Extension state state :=
  ⟨grows_refl _, extends_refl _, extends_refl _⟩

/-- Ordered caller effects compose both physical and domain histories. -/
theorem Extension.trans (first : Extension before middle) (second : Extension middle after) : Extension before after :=
  ⟨grows_trans first.heap second.heap, extends_trans first.history second.history, extends_trans first.domains second.domains⟩

/-- All earlier complete physical records survive recursive caller effects. -/
theorem Extension.available {before after : Machine Symbol Guard} (extension : Extension before after) (value : Value Symbol Guard)
    (available : Available before.heap value) : Available after.heap value :=
  available.grows before.heap after.heap extension.heap extension.history

/-- A source domain retains its actual cache identity and original complete Mu bindings. -/
structure Domain (state : Machine Symbol Guard) (domain : Interned DomainKey) : Prop where
  represented : IntersectionEmptyDomain.Represents state.domains domain.key domain
  canonical : Canonical domain.key
  typed : Typed domain.key
  bindings : AvailableBindings state.heap domain.key

/-- An earlier source domain remains valid after later caller effects. -/
theorem Domain.grows (domain : Interned DomainKey) (known : Domain before domain) (extension : Extension before after) :
    Domain after domain := by
  refine ⟨⟨known.represented.1, ?_⟩, known.canonical, known.typed,
    known.bindings.grows before.heap after.heap domain.key extension.heap extension.history⟩
  by_cases empty : domain.key = IntersectionEmptyDomain.emptyKey
  · simpa only [empty, ite_true] using known.represented.2
  · obtain ⟨entry, present, same⟩ := by simpa only [empty, ite_false] using known.represented.2
    simpa only [empty, ite_false] using
      (show ∃ entry, after.domains.table domain.key = some entry ∧ domain.identity = entry.identity + 1 from
        ⟨entry, extension.domains _ _ present, same⟩)

/-- The reserved empty source domain requires no cache allocation or physical binding. -/
theorem empty_domain (state : Machine Symbol Guard) : Domain state IntersectionEmptyDomain.emptyDomain := by
```

## lean/MicroCFTA/SourceCurrentAllocatedNativePhysicalExecution.lean

```lean
-- lines 46-55
/-- Each check refers only to the current instruction, current inputs, and current running cell. -/
def Inputs [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    : Control Output → CheckedState width → Prop
  | .code (.work job _), state => WorkInputs state.native.machine.heap job
  | .code (.enter domain left right _ _ _), state =>
      Domain state.native.machine domain ∧ Available state.native.machine.heap left ∧ Available state.native.machine.heap right
  | .code (.optionalBinder _ value _), state => Available state.native.machine.heap value
  | .code (.node request _), state => NodeReady state.native.machine request ∧
      ∀ key, SourceRecursiveIntersectionMemo.requestKey width request.domain request.left request.right = some key →
        SourceRecursiveIntersectionMemo.KeySafe width request.domain request.left request.right
-- lines 113-147

/-- Current physical checks preserve both memo families on every actual step outcome. -/
theorem step_valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (control : Control Output) (state : CheckedState width)
    (valid : SourceCurrentAllocatedNativePhysicalCache.Valid state.native) (inputs : Inputs control state) :
    SourceCurrentAllocatedNativePhysicalCache.Valid (step control state).state.native := by
  cases control with
  | edgeBody request next =>
      rw [step, SourceEqualityNativeDemandOperations.body_native]
      exact valid
  | code code =>
      cases code with
      | pure | fail | read => exact valid
      | work job next =>
          have checked := work_checked job state.native.machine valid.machine inputs
          exact SourceCurrentAllocatedNativePhysicalCache.advance_valid state.native valid _ checked.1 checked.2
      | enter domain left right first second next =>
          have checked := entered state.native.machine valid.machine domain inputs.1 left right inputs.2.1 inputs.2.2 first second
          exact SourceCurrentAllocatedNativePhysicalCache.advance_valid state.native valid _ checked.1 checked.2.1
      | optionalBinder pair body next =>
          have checked := construction_checked state.native.machine valid.machine _ Available
            (SourceRecursiveIntersectionMaybeMu.verified pair body state.native.machine.heap valid.machine.1 inputs)
          cases actual : SourceRecursiveIntersectionMaybeMu.maybeMu pair body state.native.machine.heap with
          | done value heap | pending key heap =>
              have physical := checked.valid
              have growth := checked.extension
              simp only [actual, construction, Result.state] at physical growth
              simpa only [step, SourceRecursiveIntersectionNative.step, actual, lift, Outcome.state] using
                SourceCurrentAllocatedNativePhysicalCache.advance_valid state.native valid _ physical growth
      | node request next => exact node_step_valid request next state valid inputs.1 inputs.2
      | edge request next => exact edge_step_valid request next state valid inputs.1 inputs.2
      | finishNode handle value next =>
          obtain ⟨request, running, resident⟩ := inputs
          exact SourceCurrentAllocatedNativePhysicalCache.finishNode_valid state.native valid handle request value running resident
      | finishEdge handle value next =>
-- lines 151-178
/-- Each actual checked instruction retains physical records, issued identities, and source domains. -/
theorem step_extension [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (control : Control Output) (state : CheckedState width)
    (valid : SourceRecursiveIntersectionKernel.Valid state.native.machine) (inputs : Inputs control state) :
    Extension state.native.machine (step control state).state.native.machine := by
  cases control with
  | edgeBody request next =>
      rw [step, SourceEqualityNativeDemandOperations.body_native]
      exact .refl _
  | code code =>
      cases code with
      | pure | fail | read | finishNode | finishEdge => exact .refl _
      | work job next => exact (work_checked job state.native.machine valid inputs).2
      | enter domain left right first second next =>
          exact (entered state.native.machine valid domain inputs.1 left right inputs.2.1 inputs.2.2 first second).2.1
      | optionalBinder pair value next =>
          have checked := construction_checked state.native.machine valid _ Available
            (SourceRecursiveIntersectionMaybeMu.verified pair value state.native.machine.heap valid.1 inputs)
          cases actual : SourceRecursiveIntersectionMaybeMu.maybeMu pair value state.native.machine.heap with
          | done result heap | pending key heap =>
              have growth := checked.extension
              simpa only [actual, construction, Result.state, step, SourceRecursiveIntersectionNative.step,
                lift, Outcome.state, advance] using growth
      | node request next =>
          change Extension state.native.machine
            (lift state.operations (SourceRecursiveIntersectionNative.step SourceEqualityConstraintConstructors.top
              SourceEqualityPCSNativeEdge.conjoin (.node request next) state.native)).state.native.machine
          rw [lift_native, SourceRecursiveIntersectionNative.node_step_machine]
```

## lean/MicroCFTA/SourceCurrentAllocatedNativePhysicalTraceCompletion.lean

```lean
-- lines 33-42
  | refl (control : Control A) (state : Checked width) : Trace 0 control state control state
  | cons (control : Control A) (state : Checked width) (next : Control A) (after : Checked width)
      (final : Control A) (result : Checked width) (fuel : Nat)
      (inputs : Inputs control state)
      (actual : step control state = .yielded next after)
      (rest : Trace fuel next after final result) : Trace (fuel + 1) control state final result

/-- Erasure retains the literal yielded controls and all current state fields. -/
theorem Trace.steps [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (trace : Trace fuel control state next after) : Steps fuel control state next after := by
```

## lean/MicroCFTA/SourceCurrentAllocatedRecursivePrefixCode.lean

```lean
-- lines 96-109
    (next : Interned DomainKey → Code Symbol Guard A) (state : Machine Symbol Guard)
    (post : Machine Symbol Guard → A → Prop)
    (certificate : Certified source inventory (.enter domain left right first second next) state post)
    (semantic : SemanticReady state.heap) :
    let actual := SourceRecursiveIntersectionEnvironment.enter state.domains domain.key left right first second
    let after : Machine Symbol Guard := {state with domains := actual.2}
    SourceRecursiveIntersectionKernel.Valid after ∧ Extension state after ∧ SemanticReady after.heap ∧
      Certified source inventory (next actual.1) after post :=
  ⟨certificate.safe.1, certificate.safe.2.1, semantic, certificate.safe.2.2,
    certificate.operands.2.2.2, certificate.domain.2.2.2⟩

/-- A literal current-heap read retains all local certificates at the same machine. -/
theorem read_next (name : Nat) (next : Option (Value Symbol Guard) → Code Symbol Guard A)
    (state : Machine Symbol Guard) (post : Machine Symbol Guard → A → Prop)
```

## lean/MicroCFTA/SourceCurrentAllocatedNativeDomainTrace.lean

```lean
-- lines 23-34
/-- Only a literal enter instruction needs an initial domain inventory entry. -/
def CodeEntered (inventory : List DomainKey) : Code Symbol Guard A → Prop
  | .enter domain left right first second _ =>
      SourceRecursiveIntersectionDomain.extend domain.key
        ((SourceRecursiveIntersectionEnvironment.bindings left right).map Prod.fst)
        (SourceRecursiveIntersectionControl.pair first second) ∈ inventory
  | _ => True

/-- The checked edge body allocates no intersection domain. -/
def Entered (inventory : List DomainKey) : Control A → Prop
  | .code code => CodeEntered inventory code
  | .edgeBody .. => True
-- lines 151-159
/-- Every admitted raw checked prefix derives its actual sequential domain allocation history. -/
theorem trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (inventory : List DomainKey) (fuel : Nat) (control next : Control A) (before after : Checked width)
    (actual : Steps fuel control before next after) (admitted : Prefixes inventory control before) :
    Allocation inventory before.native.machine.domains after.native.machine.domains := by
  induction actual with
  | refl => exact .refl _
  | cons control before middle current final result fuel one rest ih =>
      exact (yielded inventory control middle before current admitted.current one).trans
```

## lean/MicroCFTA/SourceRecursiveIntersectionDomainEquivalence.lean

```lean
-- lines 32-38
/-- Actual domain allocation returns the exact canonical extension key. -/
theorem entered_key (cache : Cache.State DomainKey) (valid : Cache.Valid cache) (source : DomainKey)
    (left right : InternedConstructorTemplates.Value Symbol Guard) (first second : Nat) :
    (SourceRecursiveIntersectionEnvironment.enter cache source left right first second).1.key =
      SourceRecursiveIntersectionDomain.extend source
        ((SourceRecursiveIntersectionEnvironment.bindings left right).map Prod.fst) (SourceRecursiveIntersectionControl.pair first second) :=
  (IntersectionEmptyDomain.make_correct cache valid _).2.1
```

## lean/MicroCFTA/SourceCurrentNativeRequestSourceScope.lean

```lean
-- lines 32-50
    (left right : Node) (leftAvailable : Available before.native.machine.heap left)
    (rightAvailable : Available before.native.machine.heap right)
    (leftClosed : left.free = []) (rightClosed : right.free = [])
    (nodes : before.native.machine.heap.nodes.next < 2 ^ bits)
    (edges : before.native.machine.heap.edges.next ≤ 2 ^ (bits + 2))
    (room : before.native.machine.domains.next +
      2 ^ (before.native.machine.heap.nodes.next + before.native.machine.heap.nodes.next * before.native.machine.heap.nodes.next) <
        2 ^ (bits + 1))
    {count : Nat} (queried : NodeRequest Symbol Guard) (next : Node → Code Symbol Guard Node)
    {after : Checked (bits + 2)}
    (actual : Steps count (.code (requestNode emptyDomain left right)) before
      (.code (.node queried next)) after) :
    NodeScope before.native.machine.heap queried ∧
      queried.domain.key ∈ SourceRecursiveIntersectionSourceInventory.domains before.native.machine.heap := by
  let source := before.native.machine.heap
  let inventory := SourceRecursiveIntersectionSourceInventory.domains source
  let request : NodeRequest Symbol Guard := ⟨emptyDomain,left,right⟩
  have facts := good.native.machine.1
  have resources : SourceCurrentAllocatedRecursivePrefixAdmission.Resources bits source inventory before.native.machine.domains :=
```

## lean/MicroCFTA/SourceCurrentNativeOptionalChildOrigin.lean

```lean
-- lines 88-121
/-- The same optional site retains its queried owner and actual completed child writer. -/
def Origin (request : NodeRequest Symbol Guard) (fuel : Nat) (before siteBefore : Checked width)
    (pair : Nat × Nat) (siteBody : Node) (siteNext : Node → Code Symbol Guard Node) : Prop :=
    ∃ (queryFuel childFuel : Nat) (queried : NodeRequest Symbol Guard)
        (callerNext : Node → Code Symbol Guard Node) (queryBefore : Checked width)
        (handle : Nat) (chosen running : SourceRecursiveIntersectionThunks.State width Symbol Guard)
        (first second : Nat),
      let compilerBefore : Checked width := ⟨running, queryBefore.operations⟩
      let entered := SourceRecursiveIntersectionEnvironment.enter compilerBefore.native.machine.domains
        queried.domain.key queried.left queried.right first second
      let childBefore : Checked width :=
        {compilerBefore with native := advance compilerBefore.native {compilerBefore.native.machine with domains := entered.2}}
      fuel = queryFuel + 2 + childFuel ∧
      Trace queryFuel (.code (requestNode request.domain request.left request.right)) before
        (.code (.node queried callerNext)) queryBefore ∧
      Inputs (.code (.node queried callerNext)) queryBefore ∧
      lookupNode width queried queryBefore.native = (.memoized handle, chosen) ∧
      demandNode handle chosen = (.evaluate queried, running) ∧
      chosen.nodes.cells handle = some ⟨queried, .suspended⟩ ∧
      running.nodes.cells handle = some ⟨queried, .evaluating⟩ ∧
      running.machine = queryBefore.native.machine ∧
      step (.code (.node queried callerNext)) queryBefore = .yielded
        (.code ((compileNode queried).bind (fun value => .finishNode handle value (callerNext value)))) compilerBefore ∧
      (SourceRecursiveIntersectionControl.decision queried.domain.key queried.left queried.right = .bothMu ∨
        SourceRecursiveIntersectionControl.decision queried.domain.key queried.left queried.right = .leftMu ∨
        SourceRecursiveIntersectionControl.decision queried.domain.key queried.left queried.right = .rightMu) ∧
      SourceRecursiveIntersectionControl.identity queried.left = some first ∧
      SourceRecursiveIntersectionControl.identity queried.right = some second ∧
      pair = SourceRecursiveIntersectionControl.pair first second ∧
      Inputs (.code (compileMu queried.domain queried.left queried.right)) compilerBefore ∧
      step (.code (compileMu queried.domain queried.left queried.right)) compilerBefore =
        .yielded (.code ((requestNode entered.1 (body queried.left) (body queried.right)).bind
          (fun value => .optionalBinder (SourceRecursiveIntersectionControl.pair first second) value .pure))) childBefore ∧
      Trace childFuel (.code (requestNode entered.1 (body queried.left) (body queried.right)))
```

## lean/MicroCFTA/SourceCurrentNativeKeyAdmission.lean

```lean
-- lines 36-56
/-- Initial source admission turns a literal closed-request prefix into its checked trace and numeric bounds. -/
theorem node_prefix (bits : Nat) (before : Checked (bits + 2))
    (good : Good before) (semantic : SourceEqualityRequiredSemanticCache.SemanticReady before.native.machine.heap)
    (left right : Node) (leftAvailable : Available before.native.machine.heap left)
    (rightAvailable : Available before.native.machine.heap right)
    (leftClosed : left.free = []) (rightClosed : right.free = [])
    (nodes : before.native.machine.heap.nodes.next < 2 ^ bits)
    (edges : before.native.machine.heap.edges.next ≤ 2 ^ (bits + 2))
    (room : before.native.machine.domains.next +
      2 ^ (before.native.machine.heap.nodes.next + before.native.machine.heap.nodes.next * before.native.machine.heap.nodes.next) <
        2 ^ (bits + 1))
    {count : Nat} {next : Control Node} {after : Checked (bits + 2)}
    (actual : Steps count (.code (requestNode emptyDomain left right)) before next after) :
    Trace count (.code (requestNode emptyDomain left right)) before next after ∧
    Good after ∧ SourceCurrentAllocatedNativeFieldClosure.Fields next after ∧
    Stored (massAfter count (initialBound before.native.machine.heap)) after.native.machine.heap ∧
    after.native.machine.heap.nodes.next ≤ before.native.machine.heap.nodes.next + credit count (initialBound before.native.machine.heap) ∧
    after.native.machine.heap.edges.next ≤ before.native.machine.heap.edges.next + credit count (initialBound before.native.machine.heap) ∧
    after.native.machine.domains.next ≤ before.native.machine.domains.next + count := by
  let source := before.native.machine.heap
  let inventory := SourceRecursiveIntersectionSourceInventory.domains source
```

## lean/MicroCFTA/SourceSynthesisUniverseMixedDescendantFreshness.lean

```lean
-- lines 33-59

/-- Equal identities of closed available operands select the same complete physical value. -/
theorem closed_identity_injective (heap : State Symbol Guard) (facts : Facts heap)
    (left right : Value Symbol Guard) (leftAvailable : Available heap left)
    (rightAvailable : Available heap right) (leftClosed : left.free = []) (rightClosed : right.free = [])
    (name : Nat) (leftIdentity : identity left = some name) (rightIdentity : identity right = some name) :
    left = right := by
  have leftRead := SourcePreparedSharedRows.read_identity heap facts left leftAvailable name
    (closed_reference left leftClosed name leftIdentity)
  have rightRead := SourcePreparedSharedRows.read_identity heap facts right rightAvailable name
    (closed_reference right rightClosed name rightIdentity)
  exact Option.some.inj (leftRead.symm.trans rightRead)

/-- Strict prefix descent excludes the ancestor's physical identity. -/
theorem strict_prefix_height_identity_ne (heap : State Symbol Guard) (facts : Facts heap)
    (pattern operand : Value Symbol Guard) (patternAvailable : Available heap pattern)
    (operandAvailable : Available heap operand) (patternClosed : pattern.free = [])
    (operandClosed : operand.free = []) (patternId operandId : Nat)
    (patternIdentity : identity pattern = some patternId) (operandIdentity : identity operand = some operandId)
    (smaller : height operand < height pattern) : operandId ≠ patternId := by
  intro same
  have original : identity operand = some patternId := by rw [operandIdentity, same]
  have equal := closed_identity_injective heap facts pattern operand patternAvailable operandAvailable
    patternClosed operandClosed patternId patternIdentity original
  have sameHeight := congrArg height equal
  omega

-- lines 72-92
    (state : Machine Symbol Guard) (valid : SourceRecursiveIntersectionKernel.Valid state)
    (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard)
    (universeAvailable : Available state.heap (.mu entry body depth ordinary))
    (pattern : Value Symbol Guard) (patternAvailable : Available state.heap pattern)
    (patternClosed : pattern.free = []) (patternId : Nat)
    (patternIdentity : identity pattern = some patternId) :
    let universeValue : Value Symbol Guard := .mu entry body depth ordinary
    let entered := SourceRecursiveIntersectionEnvironment.enter state.domains IntersectionEmptyDomain.emptyKey
      universeValue pattern entry.identity patternId
    let initial : Machine Symbol Guard := ⟨state.heap, entered.2⟩
    ∀ later : Machine Symbol Guard, SourceRecursiveIntersectionKernel.Valid later → Extension initial later →
      ∀ operand : Value Symbol Guard, Available later.heap operand → operand.free = [] →
      ∀ operandId : Nat, identity operand = some operandId → height operand < height pattern →
      operandId ≠ patternId ∧
      pair entry.identity operandId ≠ pair entry.identity patternId ∧
      pair operandId entry.identity ≠ pair entry.identity patternId ∧
      pair entry.identity operandId ∉ entered.1.key.seen ∧
      pair operandId entry.identity ∉ entered.1.key.seen ∧
      Domain later entered.1 ∧
      lookup later.heap entered.1.key entry.identity = some universeValue := by
  let universeValue : Value Symbol Guard := .mu entry body depth ordinary
```
