# Constructor callback refutation and progress: Root checked

The required refutation transport already exists. No new primitive or owner
repository mutation was needed. Root reused the existing metadata wrapper in
SourcePruningEnumerationConstructorCallback.accepted_constructor_callback.

Final Root source: 265 lines,18905 bytes, SHA256:
`b2e89b75c22a4ac33e95cad00cb7e8f94929b88d22a910c6f46ce2f65286bd52`.
Root's build passes2073 jobs. Strict Lean passes warningAsError and linter.all
with an empty log. Three Root commands are retained: v1 fails, v2 builds,
and v2 strict passes. All9 saved command input hashes verify. All commands
have measured4GiB memory.max/high and zero swap. Root runs every compiler.
This owner ran no compiler, evaluator, native, Git, network or board command.

## Existing exact transport and callback equality instance

SourcePruningAssignmentRefutation.lean15 proves
SourcePruningResume.refutes_assignment_congr:

    Refutes extended pending <-> Refutes assignment pending

PendingBound limit pending bounds every raw pending variable. Agreement of
extended with assignment below that same original limit therefore preserves
all matched entries and their exact refutation. Use `.mpr` for the original
to extended direction. No future-refutation supplier or endpoint model is an
input. SourcePruningEnumerationPolicyOrigins.lean48 already wraps that law as
SourcePruningRecordTypes.pending_refutes_extension for every metadata group.
Root applies that wrapper to packet.bounded and the original old-ID agreement.

The actual callback API is SourcePruningRecordTypes.recordTypes_inl_refutes,
in SourcePruningRecordTypesRefutation.lean22-34. Its local equality instance is
FormulaExecutable.formulaDecidableEq. The full symbol instance is:

    @instDecidableEqProd String FullSyntax.Formula inferInstance
      FormulaExecutable.formulaDecidableEq

The new theorem fixes that exact instance in its Refutes notation. The
existing AcceptedHeadPolicy.lean171-176 demonstrates the same explicit call.
A generic [DecidableEq Symbol] can mismatch this callback's concrete predicate.
The fixed metadata wrapper avoids that mismatch.

## Source review and exact retained contracts

The first result group retains the ENTIRE old ConstructorIteration result,
exactly3522 bytes as a literal substring. The original accepted parent and
edge, physical Packet and resource envelope remain inputs. The first result
therefore keeps actual selected/captured operations, old-ID agreement, the
same extended assignment, original/recorded/finalized models, resources,
recursive Packet, proper state, fragment admission/history and pending-input
bounds. No old conclusion is removed.

The second group retains the ENTIRE callback_complete_semantics result.
Its original1833-byte body becomes2007 bytes after simultaneous identifier
renaming and width instantiation. Removal of whitespace then recovers that
whole body exactly. inventory/caller/memos become next/afterCaller/final;
result/after/before/fuel become callback/callbackCore/finalized/callbackFuel;
uv becomes target; width becomes(bits+2). This is an actual specialization of
the generic callback API to the constructor's native width.

The first265-line added source had one copied `Caller width` binder. The
source review identified it. Root v1 reports two uses with that type mismatch.
Root v2 changes this binder to Caller(bits+2), with an indentation change.
The2002-byte renamed callback count applied to v1 before this required width
instantiation. Do not claim literal callback body bytes or an unchanged public
header between v1 and v2. root-width-repair.diff and both public headers retain
the exact difference. Root made no other change and added no suppression.

## Original policy gates and actual continuation

The new original gates are refutation of every original metadata.pending
group, Avoids templates term, and the existing ProgramEncoding obligation
for programs at that original chosen term. They are explicit input policies.
No callback false flag, future refutation, future model, desired cost decrease
or supplied recursive continuation result is an input.

The proof obtains the actual accepted constructor Packet once. Its old-ID
agreement transports original metadata refutation. Its actual fill equation
and original parent assignment identify the filled fragment with the same
extended target term. Original Avoids and ProgramEncoding then instantiate
the actual recordTypes_inl_refutes theorem at the finalized state and actual
callback action. That theorem derives callback.1=false and refutation of all
updated pending groups. The false result is not supplied or assumed.

The original callback_semantics producer runs once. Its actual Frame retains
all stored values, so ProperState and pendingSize transport to the callback
cache. Its full semantic equivalence supplies the SAME extended assignment's
postcallback Satisfies. Combining that frame with the original constructor
bound gives:

    pendingSize callbackCache extended + 1 <= pendingSize original assignment

The retained actual callback equation is then specialized with the derived
false flag and actual saved query equality. For arbitrary recur, nextStop and
nextOrder, it calls exactly that recur with actual updated metadata, native
caller, query, callback cache and restart decision. No recursive result is
prescribed. Proper state plus this same model also exclude `.stuck` at that
returned cache for arbitrary nextStop/nextOrder. This permits configured stop
and DONE; it does not establish Discharged or future acceptance.

A common local work value is r+n+p+h+k+callbackFuel. Every work+extra supplies
all original selected/captured stage bounds and the actual callback bound.
The retained captured-run equation and false continuation equation then hold
at that same common work. This result controls this one constructor route.
It does not control earlier alternatives, the full driver prefix, the Right
callback, neutral operations, recursive future results or global depth.
Unfolding, complete public coverage and Haskell correspondence remain open.
No Haskell defect or fix was found.

## Evidence scope

Four existing Lean sources were reviewed whole, within the four-source limit:
ResumeRefutation, PartialMatch, AssignmentRefutation and the50-line callback
RecordTypesRefutation. The1-60 callback request ends at EOF and counts as whole.
Six other existing acquisitions are literal pinned cuts, including the two
complete old public result contracts. All10 source/cut identities verify.
The added Root callback source was reviewed whole as a new task source; its
v1 and final v2 copies and headers are retained separately. Root command input
copies are historical artifacts, with no unrelated source-body review claim.
No required source display was truncated. The manual minute-ahead task label
was corrected by Root; evidence timestamps use measured dates.

REPORT-draft.md and the original source scopes and public headers retain the
initial existing-theorem finding. All prior task bundles remain sealed.
The full formalization objective remains ACTIVE.
