      Packet formulas solver next afterCaller final callback.2 (EnumerationExpandableIndex.frame callbackCore finalized) ∧
      RenderStable finalized.core callbackCore ∧ Frame finalized.core callbackCore ∧
      callback.2.types = updatedTypes metadata target (.inl fragment) ∧
      callback.2.openHoles = metadata.openHoles ∧ callback.2.typing = metadata.typing ∧
      (∀ extra,
        Success (recordTypes graph templates (callbackFuel + extra) metadata target (.inl fragment)) finalized.core callback callbackCore ∧
        ExceptT.run (recordTypes graph templates (callbackFuel + extra) metadata target (.inl fragment) finalized.core) =
          [.ok (callback, callbackCore)] ∧
        ∀ (recur : Metadata Typing → Caller (bits + 2) → Queries → Cached → Option Next → Result) stop order,
          continueWith recur graph templates stop order (callbackFuel + extra) metadata target fragment afterCaller final.query finalized =
            if callback.1 then .complete [] afterCaller final.query
            else recur callback.2 afterCaller final.query (EnumerationExpandableIndex.frame callbackCore finalized)
              (SourcePruningEnumerationRestart.decision stop order callback.2
                (EnumerationExpandableIndex.frame callbackCore finalized))) ∧
      ∀ (ambient : InternedGuardedLanguage.Env Symbol)
        (residualMeaning : Constraint → Language.Term Symbol → Prop)
        (assignment : Nat → Language.Term Symbol),
        Satisfies
          (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
            ambient afterCaller.checked.native.machine.heap) residualMeaning assignment
          (EnumerationExpandableIndex.frame callbackCore finalized).core ↔
        Satisfies
          (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
            ambient afterCaller.checked.native.machine.heap) residualMeaning assignment finalized.core