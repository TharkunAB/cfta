# Original pending refutation under assignment extension

Result: the required theorem and metadata wrapper ALREADY exist. No new
module or repository mutation is needed.

SourcePruningAssignmentRefutation.lean15 defines
SourcePruningResume.refutes_assignment_congr. Its result is:

    Refutes extended pending <-> Refutes assignment pending

Its inputs are PendingBound limit pending and pointwise agreement of extended
with assignment at all uv<limit. Use `.mpr` to transport original refutation
to the extended assignment. It proves the equivalence directly by rewriting
each bounded pending entry. No future-refutation supplier or model premise
is needed.

SourcePruningEnumerationPolicyOrigins.lean48 defines
SourcePruningRecordTypes.pending_refutes_extension. It applies that theorem
to every original metadata.pending group. It takes exactly the original
bounded-group premise, old-ID agreement and original refutation. This is the
smallest direct reuse for the constructor callback.

The exact callback API is SourcePruningRecordTypes.recordTypes_inl_refutes
in SourcePruningRecordTypesRefutation.lean22-34. The namespace and filename
are not SourceRecordTypesRefutation. That API uses the local instance
FormulaExecutable.formulaDecidableEq at line14. Its full symbol equality is:

    @instDecidableEqProd String FullSyntax.Formula inferInstance
      FormulaExecutable.formulaDecidableEq

SourcePruningEnumerationAcceptedHeadPolicy.lean171-176 already performs the
same bounded transfer with that explicit instance. A generic caller's
[DecidableEq Symbol] can fail to match the callback's concrete Refutes
predicate. Use the metadata wrapper, which fixes the same instance, or the
explicit @SourcePruningResume.refutes_assignment_congr application retained
in the pinned AcceptedHeadPolicy cut.

Four whole existing Lean sources were read, at the four-source limit:
ResumeRefutation, PartialMatch, AssignmentRefutation and the50-line callback
RecordTypesRefutation. Four other dependencies are literal pinned cuts.
The original requested callback1-60 interval ends at EOF and is counted as a
whole review. There is no overrun and no truncated required source display.
source-scope.json retains exact copies, endpoints and hashes. Three raw public
headers are retained. Search results found the existing theorem before any
new source draft was written. No compiler, evaluator, native, Git, network or
board command was run by this owner. Root owns all proof execution/checks.

No Haskell defect or fix was found. The full formalization goal and its global
coverage, sufficient-resource and public/Haskell correspondence boundaries
remain open. This finding removes one local callback transport obligation.
