    (origin : SourcePruningEnumerationOrigins.Origin whole term) : OriginPolicies templates term := by
  intro child nested
  exact policies child (SourcePruningEnumerationOrigins.origin_trans whole term child origin nested)

/-- An allocated variable with an original path inherits the local source policies. -/
theorem OriginPolicies.assignment (templates : List (Template.Pattern Symbol))
    (whole : Term Symbol) (limit : Nat) (assignment : Nat → Term Symbol)
    (policies : OriginPolicies templates whole)
    (origins : SourcePruningEnumerationOrigins.AssignmentOrigins whole limit assignment)
    (uv : Nat) (inside : uv < limit) :
    Avoids templates (assignment uv) ∧
      ∀ program, ProgramAt (assignment uv) program → ProgramEncoding program :=
  policies (assignment uv) (origins uv inside)

end MicroCFTA.SourcePruningTemplates

namespace MicroCFTA.SourcePruningRecordTypes
open Language SourcePruningPartialMatch
local notation "Symbol" => SourcePruningTemplates.Symbol
attribute [local instance] FormulaExecutable.formulaDecidableEq
variable {Typing Guard : Type}

/-- Original bounded pending IDs retain refutation under an agreeing assignment. -/
theorem pending_refutes_extension (limit : Nat) (original extended : Nat → Term Symbol)
    (metadata : Metadata Typing)
    (bounded : ∀ group ∈ metadata.pending, PendingBound limit group)
    (agree : ∀ uv < limit, extended uv = original uv)
    (refuted : ∀ group ∈ metadata.pending, SourcePruningResume.Refutes original group) :
    ∀ group ∈ metadata.pending, SourcePruningResume.Refutes extended group := by
  intro group member
  exact (SourcePruningResume.refutes_assignment_congr limit original extended group
    (bounded group member) agree).mpr (refuted group member)

/-- Actual recording uses original subtree policies and bounded old pending refutation. -/
theorem recordTypes_inl_refutes_of_origin (graph : EnumerationState.Graph Symbol Guard)
    (language : EnumerationCorrectness.NodeLanguage Symbol) (meaning : Guard → Term Symbol → Prop)
    (original extended : Nat → Term Symbol) (templates : List (Template.Pattern Symbol))
    (whole : Term Symbol) (fuel uv limit : Nat) (metadata : Metadata Typing)
    (fragment : Fragments.Fragment Symbol) (before after : EnumerationState.State Symbol Guard)
    (result : Bool × Metadata Typing) (total : UnionFind.Total before.representatives)
    (satisfied : EnumerationCorrectness.Satisfies language meaning extended before)
