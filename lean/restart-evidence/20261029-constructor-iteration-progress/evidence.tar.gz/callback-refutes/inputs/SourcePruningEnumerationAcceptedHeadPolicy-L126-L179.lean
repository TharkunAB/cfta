        Satisfies
          (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
            ambient caller.checked.native.machine.heap)
          (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
          assignment before.core →
        InternedGuardedLanguage.edgeMeaning (SourceEqualityPCSGuard.holds formulas solver)
          ambient edge (assignment uv) →
        (∀ group ∈ metadata.pending, @SourcePruningResume.Refutes Symbol
          (@instDecidableEqProd String FullSyntax.Formula inferInstance FormulaExecutable.formulaDecidableEq) assignment group) →
        SourcePruningTemplates.Avoids templates (assignment uv) →
        (∀ program, SourcePruningTemplates.ProgramAt (assignment uv) program →
          SourcePruningTemplates.ProgramEncoding program) →
        ∃ (extended : Nat → Language.Term Symbol) (fragment : Fragments.Fragment Symbol) (afterCache : Cached),
          (∀ old < before.core.counter, extended old = assignment old) ∧
          Satisfies
            (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
              ambient caller.checked.native.machine.heap)
            (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
            extended before.core ∧
          receipt = .complete fragment middleCaller saved afterCache ∧
          Fragments.fill extended fragment = assignment uv ∧
          Satisfies
            (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
              ambient middleCaller.checked.native.machine.heap)
            (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
            extended afterCache.core ∧
          Fragments.fill extended fragment = extended uv ∧
          (∀ group ∈ metadata.pending, @SourcePruningResume.Refutes Symbol
            (@instDecidableEqProd String FullSyntax.Formula inferInstance FormulaExecutable.formulaDecidableEq) extended group) ∧
          SourcePruningTemplates.Avoids templates (Fragments.fill extended fragment) ∧
          ∀ program, SourcePruningTemplates.ProgramAt (Fragments.fill extended fragment) program →
            SourcePruningTemplates.ProgramEncoding program := by
  obtain ⟨bound, receipt, middleCaller, saved, middleMemos, middleInventory, retained⟩ :=
    head_finite_complete_resources_accepting holeKey fits admits graph templates checkEmpty edgesOf stop order
      metadata recursiveFuel seed formulas solver recursive inventory caller memos before uv handle scs parentEntry
      storedEdges depth free edge packet ready stored decoded selected incoming bounded known selectionMembers selectionLength
      capturedMass inherited initialMass inheritedLength reserved
  refine ⟨bound, receipt, middleCaller, saved, middleMemos, middleInventory, retained, ?_⟩
  obtain ⟨_running, _post, _queries, _admitted, _pending, _history, _cacheBounds, _headFits,
    _headKnown, _shape, accepting⟩ := retained
  intro ambient assignment satisfied accepted refuted avoids encoded
  obtain ⟨extended, fragment, afterCache, agree, beforeModel, completed, filled, afterModel⟩ :=
    accepting ambient assignment satisfied accepted
  have self : Fragments.fill extended fragment = extended uv :=
    filled.trans (agree uv ready.inside).symm
  have pendingRefutes : ∀ group ∈ metadata.pending, @SourcePruningResume.Refutes Symbol
      (@instDecidableEqProd String FullSyntax.Formula inferInstance FormulaExecutable.formulaDecidableEq) extended group := by
    intro group member
    exact (@SourcePruningResume.refutes_assignment_congr Symbol
      (@instDecidableEqProd String FullSyntax.Formula inferInstance FormulaExecutable.formulaDecidableEq)
      before.core.counter assignment extended group (packet.bounded group member) agree).mpr (refuted group member)
  refine ⟨extended, fragment, afterCache, agree, beforeModel, completed, filled, afterModel,
    self, pendingRefutes, ?_, ?_⟩
  · rw [filled]
