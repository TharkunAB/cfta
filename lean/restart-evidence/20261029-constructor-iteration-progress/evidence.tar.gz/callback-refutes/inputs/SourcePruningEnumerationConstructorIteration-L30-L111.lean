theorem accepted_constructor_packet
    (seed : Seed) (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (caller : Caller (bits + 2)) (before : Cached) (checkEmpty : Bool)
    (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
    (edges : List (EdgeValue Symbol Constraint)) (depth : Nat) (free : List InternedBinderProtocol.Reference)
    (edge : EdgeValue Symbol Constraint) (scs : List Suspended) (memos : Memos)
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing)
    (packet : SourcePruningEnumerationRecursive.Packet formulas solver inventory caller memos metadata before)
    (proper : ProperState before.core) (target handle : Nat)
    (chosen : SourcePruningEnumerationRestart.decision stop order metadata before = some (.expand target))
    (stored : before.core.values[target]? = some (.unenumerated (some handle) scs))
    (parentLookup : lookupNode caller.checked.native.machine.heap handle = some (.node parentEntry edges depth free))
    (selected : edge ∈ edges)
    (ambient : InternedGuardedLanguage.Env Symbol) (assignment : Nat → Term Symbol) (term : Term Symbol)
    (parentValue : assignment target = term)
    (satisfied : Satisfies
      (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
        ambient caller.checked.native.machine.heap)
      (fun guard value => SourceEqualityPCSGuard.holds formulas solver guard value = true)
      assignment before.core)
    (accepted : InternedGuardedLanguage.edgeMeaning (SourceEqualityPCSGuard.holds formulas solver) ambient edge term)
    (tries : List EqualityTrie.Trie) (residual : Option Constraint)
    (projected : SourcePruningEnumerationConstraint.project edge.entry.key.constraint = some (tries, residual))
    (fits : Fits seed.2 caller.checked)
    (reserved : Reserved bits seed (SourcePruningEnumerationSelectedEdge.cost edge scs before.core.counter tries))
    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap) :
    ∃ (r n p h k : Nat) (fragment : Fragment) (afterCaller : Caller (bits + 2))
      (recorded finalized : Cached) (savedQueries : Queries) (final : Memos) (next : Inventory)
      (afterRoots : Nat → Nat) (extended : Nat → Term Symbol),
      (
      (∀ er en P H ek, p ≤ P → h ≤ H →
        SourcePruningEnumerationSelectedEdge.run checkEmpty (r + er) (n + en) P H (k + ek)
          scs edge caller before memos.query = .complete fragment afterCaller savedQueries recorded) ∧
      (∀ ek, SourcePruningEnumerationFinalize.run afterCaller.checked.native.machine.heap (k + ek)
        target fragment recorded = some finalized) ∧
      Post formulas solver next caller afterCaller final ∧ final.query = savedQueries ∧
      (∀ uv < before.core.counter, extended uv = assignment uv) ∧
      Satisfies
        (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
          ambient caller.checked.native.machine.heap)
        (fun guard value => SourceEqualityPCSGuard.holds formulas solver guard value = true)
        extended before.core ∧
      Fragments.fill extended fragment = term ∧
      Satisfies
        (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
          ambient afterCaller.checked.native.machine.heap)
        (fun guard value => SourceEqualityPCSGuard.holds formulas solver guard value = true)
        extended recorded.core ∧
      Satisfies
        (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
          ambient afterCaller.checked.native.machine.heap)
        (fun guard value => SourceEqualityPCSGuard.holds formulas solver guard value = true)
        extended finalized.core ∧
      Safe finalized.core ∧ EnumerationValidity.Canonical finalized.core ∧
      Roots finalized.core.representatives afterRoots ∧ StorageValid finalized.core ∧
      PendingRealized afterCaller.checked.native.machine.heap finalized.core ∧
      EnumerationCanonicalWaiting.Correct afterRoots finalized.core.values finalized.waiting ∧
      (∀ slot, SourcePruningEnumerationNativeIndex.candidate afterCaller.checked.native.machine.heap
        ((finalized.core.values[slot]?).getD .eliminated) = some (finalized.expandable slot)) ∧
      Fits (advance seed (SourcePruningEnumerationSelectedEdge.cost edge scs before.core.counter tries)).2
        afterCaller.checked ∧
      Heap (fun guard => guard ∈ (advance seed
        (SourcePruningEnumerationSelectedEdge.cost edge scs before.core.counter tries)).1)
        afterCaller.checked.native.machine.heap ∧
      EnumerationStorageProgress.pendingSize finalized.core extended + 1 ≤
        EnumerationStorageProgress.pendingSize before.core assignment
      ) ∧
      (∀ er en P H ek, p ≤ P → h ≤ H →
        SourcePruningEnumerationCapturedEdge.run checkEmpty (r + er) (n + en) P H (k + ek)
          target scs edge caller before memos.query =
          some (.complete fragment afterCaller savedQueries finalized)) ∧
      SourcePruningEnumerationRecursive.Packet formulas solver next afterCaller final metadata finalized ∧
      ProperState finalized.core ∧
      SourcePruningEnumerationNativeBranchCompletion.Admitted target
        (.complete fragment afterCaller savedQueries finalized) ∧
      SourcePruningEnumerationNativeBranchCompletion.FragmentHistory before.core
        (.complete fragment afterCaller savedQueries finalized) ∧
      ∀ (uv : Nat) (node : Option Nat) (bucket : List Suspended),
        finalized.core.values[uv]? = some (UVarValue.unenumerated node bucket) →
        InputsPending finalized.core bucket ∧ ∀ sc ∈ bucket, sc.var < finalized.core.counter := by
