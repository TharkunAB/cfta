theorem refutes_assignment_congr (limit : Nat)
    (assignment extended : Nat → Term Symbol) (pending : Pending Symbol)
    (bounded : PendingBound limit pending)
    (agree : ∀ uv < limit, extended uv = assignment uv) :
    Refutes extended pending ↔ Refutes assignment pending
