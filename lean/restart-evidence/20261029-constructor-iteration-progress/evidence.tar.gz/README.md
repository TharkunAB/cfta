# Constructor iteration and actual Left callback

The full formalization goal remains ACTIVE.
Read final-documents/lean/notes-current-constructor-iteration-progress.md first.
An original accepted constructor derives actual captured execution and its
whole returned recursive Packet. Its actual Left callback preserves the same
model and strict pending-term decrease and calls the operational continuation.
One common local work bound controls both actions. Original policies remain.
The outer prefix, earlier alternatives and semantic recursive continuation
remain open. Global resources/rank, unfolding/public coverage, exact public
order/stops and Haskell correspondence remain in the full objective.

Every regular file is archived without filtering. Keep this tree and every
reconstruction immutable. Continue in a fresh writable area. Historical failed
attempts and source-only UNTESTED labels remain. Three strict mappings identify
the exact final sources. Verification executes no Lean or Haskell code.
