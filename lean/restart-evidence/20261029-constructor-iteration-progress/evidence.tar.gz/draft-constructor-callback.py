from pathlib import Path
import re

root = Path('/home/tritlo/Code/mcfta')
old = (root / 'lean/MicroCFTA/SourcePruningEnumerationConstructorIteration.lean').read_text()
start = old.index('    ∃ (r n p h k : Nat)')
end = old.index(' := by\n', start)
statement = old[start:end]
body_start = statement.index('      (\n')
existentials, original_result = statement[:body_start], statement[body_start:]
header = old[:start]
header = header.replace('import MicroCFTA.SourcePruningEnumerationAcceptedConstructorProgress', '''import MicroCFTA.SourcePruningEnumerationConstructorIteration
import MicroCFTA.SourcePruningEnumerationRecursiveCallbackLanguage
import MicroCFTA.SourcePruningEnumerationPolicyOrigins
import MicroCFTA.SourcePruningRecordTypesRefutation
import MicroCFTA.SourcePruningEnumerationStorageCallbackProgress''')
header = header.replace('namespace MicroCFTA.SourcePruningEnumerationConstructorIteration',
                        'namespace MicroCFTA.SourcePruningEnumerationConstructorCallback')
header = header.replace('open SourceCurrentAllocatedPartialInvariant (Post)', '''open SourceCurrentAllocatedPartialInvariant (Post)
open SourcePruningEnumerationRecursive (Packet continueWith)
open SourcePruningRecordTypes (recordTypes updatedTypes)
open EnumerationDriver (RenderStable)
open EnumerationCompressionFrame (Frame)''')
header = header.replace('/-- An actually selected accepted constructor retains its full model result and derives the next recursive packet. -/\ntheorem accepted_constructor_packet', '''local notation "Result" => SourcePruningEnumerationNativeContinuations.HookResult
  (SourcePruningEnumerationRecursive.Output (bits + 2) Typing)
  (SourcePruningEnumerationRecursive.Failure (bits + 2) Typing) (bits + 2)
local notation "Refutes" => @SourcePruningResume.Refutes Symbol
  (@instDecidableEqProd String FullSyntax.Formula inferInstance FormulaExecutable.formulaDecidableEq)

/-- Original constructor and template admissions derive the actual non-rejecting callback with strict progress. -/
theorem accepted_constructor_callback''')
assert header.endswith('    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap) :\n')
header = header[:-len(' :\n')] + '''
    (graph : EnumerationState.Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (refuted : ∀ group ∈ metadata.pending, Refutes assignment group)
    (avoids : SourcePruningTemplates.Avoids templates term)
    (encoded : ∀ program, SourcePruningTemplates.ProgramAt term program →
      SourcePruningTemplates.ProgramEncoding program) :
'''
cb = (root / 'lean/MicroCFTA/SourcePruningEnumerationRecursiveCallbackLanguage.lean').read_text()
cb_start = cb.index('    ∃ fuel result after,')
cb_end = cb.index(' := by\n', cb_start)
cb_result = cb[cb_start:cb_end]
cb_body = cb_result[cb_result.index('      Packet formulas'):]
rename = {'inventory':'next', 'caller':'afterCaller', 'memos':'final', 'before':'finalized',
          'uv':'target', 'result':'callback', 'after':'callbackCore', 'fuel':'callbackFuel'}
mapped_callback = re.sub(r'\b(' + '|'.join(rename) + r')\b', lambda m: rename[m.group()], cb_body)
callback_result = '\n'.join('  ' + line for line in mapped_callback.splitlines())
tail = '''        ) ∧
        callback.1 = false ∧
        (∀ group ∈ callback.2.pending, Refutes extended group) ∧
        ProperState (EnumerationExpandableIndex.frame callbackCore finalized).core ∧
        Satisfies
          (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
            ambient afterCaller.checked.native.machine.heap)
          (fun guard value => SourceEqualityPCSGuard.holds formulas solver guard value = true)
          extended (EnumerationExpandableIndex.frame callbackCore finalized).core ∧
        EnumerationStorageProgress.pendingSize (EnumerationExpandableIndex.frame callbackCore finalized).core extended + 1 ≤
          EnumerationStorageProgress.pendingSize before.core assignment ∧
        (∀ (nextStop : Option (Metadata Typing → Nat → Bool))
          (nextOrder : Metadata Typing → List Nat → Option Nat),
          SourcePruningEnumerationRestart.decision nextStop nextOrder callback.2
            (EnumerationExpandableIndex.frame callbackCore finalized) ≠ some .stuck) ∧
        ∃ work, ∀ extra,
          SourcePruningEnumerationCapturedEdge.run checkEmpty (work + extra) (work + extra)
            (work + extra) (work + extra) (work + extra) target scs edge caller before memos.query =
            some (.complete fragment afterCaller savedQueries finalized) ∧
          ∀ (recur : Metadata Typing → Caller (bits + 2) → Queries → Cached → Option Next → Result)
            (nextStop : Option (Metadata Typing → Nat → Bool))
            (nextOrder : Metadata Typing → List Nat → Option Nat),
            continueWith recur graph templates nextStop nextOrder (work + extra)
              metadata target fragment afterCaller savedQueries finalized =
              recur callback.2 afterCaller savedQueries (EnumerationExpandableIndex.frame callbackCore finalized)
                (SourcePruningEnumerationRestart.decision nextStop nextOrder callback.2
                  (EnumerationExpandableIndex.frame callbackCore finalized)) := by
  obtain ⟨r, n, p, h, k, fragment, afterCaller, recorded, finalized, savedQueries, final, next,
    afterRoots, extended, original⟩ :=
    SourcePruningEnumerationConstructorIteration.accepted_constructor_packet seed formulas solver inventory caller
      before checkEmpty parentEntry edges depth free edge scs memos stop order metadata packet proper target handle
      chosen stored parentLookup selected ambient assignment term parentValue satisfied accepted tries residual
      projected fits reserved known
  have retainedOriginal := original
  rcases original with ⟨constructor, capturedRun, returned, finalProper, admitted, _history, _pendingInputs⟩
  rcases constructor with ⟨_selectedRun, _finalizedRun, _post, querySame, agree, _originalModel,
    filled, _recordedModel, finalModel, _finalSafe, _finalCanonical, _finalPaths, _finalStorage,
    _finalRealized, _finalCounts, _finalFlags, _finalFits, _finalKnown, decrease⟩
  obtain ⟨callbackFuel, callback, callbackCore, callbackPacket⟩ :=
    SourcePruningEnumerationRecursive.callback_complete_semantics formulas solver next graph templates
      metadata target fragment afterCaller final finalized returned admitted.2.2.1
  have retainedCallback := callbackPacket
  rcases callbackPacket with ⟨callbackReturned, _stable, frame, _types, _holes, _typing, callbackRun, meaning⟩
  have inside : target < before.core.counter := by
    rw [packet.safe.1.aligned]
    exact (List.getElem?_eq_some_iff.mp stored).1
  have filledSelf : Fragments.fill extended fragment = extended target :=
    filled.trans ((agree target inside).trans parentValue).symm
  have extendedRefuted := SourcePruningRecordTypes.pending_refutes_extension
    before.core.counter assignment extended metadata packet.bounded agree refuted
  have callbackRefutation := SourcePruningRecordTypes.recordTypes_inl_refutes graph
    (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
      ambient afterCaller.checked.native.machine.heap)
    (fun guard value => SourceEqualityPCSGuard.holds formulas solver guard value = true)
    extended templates (callbackFuel + 0) target metadata fragment finalized.core callbackCore callback
    returned.safe.1.total finalModel filledSelf extendedRefuted
    (by simpa only [filled] using avoids) (by simpa only [filled] using encoded) (callbackRun 0).1
  have callbackProper : ProperState (EnumerationExpandableIndex.frame callbackCore finalized).core := by
    change ProperState callbackCore
    simpa only [ProperState, frame.values] using finalProper
  have callbackModel := (meaning ambient
    (fun guard value => SourceEqualityPCSGuard.holds formulas solver guard value = true) extended).mpr finalModel
  have callbackDecrease :
      EnumerationStorageProgress.pendingSize (EnumerationExpandableIndex.frame callbackCore finalized).core extended + 1 ≤
        EnumerationStorageProgress.pendingSize before.core assignment := by
    change EnumerationStorageProgress.pendingSize callbackCore extended + 1 ≤ _
    rw [EnumerationStorageProgress.frame_pendingSize finalized.core callbackCore extended frame]
    exact decrease
  have callbackContinue : ∀ extra
      (recur : Metadata Typing → Caller (bits + 2) → Queries → Cached → Option Next → Result)
      (nextStop : Option (Metadata Typing → Nat → Bool))
      (nextOrder : Metadata Typing → List Nat → Option Nat),
      continueWith recur graph templates nextStop nextOrder (callbackFuel + extra)
        metadata target fragment afterCaller savedQueries finalized =
        recur callback.2 afterCaller savedQueries (EnumerationExpandableIndex.frame callbackCore finalized)
          (SourcePruningEnumerationRestart.decision nextStop nextOrder callback.2
            (EnumerationExpandableIndex.frame callbackCore finalized)) := by
    intro extra recur nextStop nextOrder
    have actual := (callbackRun extra).2.2 recur nextStop nextOrder
    simpa only [callbackRefutation.1, Bool.false_eq_true, ↓reduceIte, querySame] using actual
  refine ⟨r, n, p, h, k, fragment, afterCaller, recorded, finalized, savedQueries, final, next,
    afterRoots, extended, retainedOriginal, callbackFuel, callback, callbackCore,
    retainedCallback, callbackRefutation.1, callbackRefutation.2, callbackProper, callbackModel,
    callbackDecrease, ?_, ?_⟩
  · intro nextStop nextOrder
    exact SourcePruningEnumerationRestart.not_stuck_of_proper formulas solver nextStop nextOrder callback.2
      afterCaller (EnumerationExpandableIndex.frame callbackCore finalized) callbackReturned.valid
      callbackReturned.safe callbackProper ambient
      (fun guard value => SourceEqualityPCSGuard.holds formulas solver guard value = true) extended callbackModel
  · let work := r + n + p + h + k + callbackFuel
    refine ⟨work, ?_⟩
    intro extra
    have sameR : r + (work + extra - r) = work + extra := by dsimp only [work]; omega
    have sameN : n + (work + extra - n) = work + extra := by dsimp only [work]; omega
    have sameK : k + (work + extra - k) = work + extra := by dsimp only [work]; omega
    refine ⟨?_, ?_⟩
    · simpa only [sameR, sameN, sameK] using capturedRun (work + extra - r) (work + extra - n)
        (work + extra) (work + extra) (work + extra - k) (by dsimp only [work]; omega)
        (by dsimp only [work]; omega)
    · intro recur nextStop nextOrder
      have sameCallback : callbackFuel + (work + extra - callbackFuel) = work + extra := by
        dsimp only [work]
        omega
      simpa only [sameCallback] using callbackContinue (work + extra - callbackFuel) recur nextStop nextOrder

end MicroCFTA.SourcePruningEnumerationConstructorCallback
'''
source = header + existentials + '      (\n' + original_result + '\n      ) ∧\n' + '''      ∃ (callbackFuel : Nat) (callback : Bool × Metadata Typing)
        (callbackCore : EnumerationState.State Symbol Constraint),
        (
''' + callback_result + '\n' + tail
assert original_result in source
target = root / 'lean/MicroCFTA/SourcePruningEnumerationConstructorCallback.lean'
assert not target.exists()
target.write_text(source)
print(dict(path=str(target), lines=len(source.splitlines()), bytes=len(source.encode()), previous_iteration_result_bytes=len(original_result.encode()), mapped_callback_result_bytes=len(mapped_callback.encode())))
