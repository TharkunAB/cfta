/-- Recover a cache candidate from one original Incoming observation. -/
def adapt
    (heap : InternedConstructorTemplates.State Symbol Constraint)
    (indexFuel target : Nat) (incomingScs : List EnumerationState.Suspended)
    (before : EnumerationExpandableIndex.Cached Symbol Constraint)
    (read : EnumerationState.State Symbol Constraint) (raw : Raw) :
    Option (EnumerationExpandableIndex.Cached Symbol Constraint) :=
  match raw with
  | [] =>
      match read.values[target]? with
      | some (.unenumerated _oldNode oldScs) =>
        let value : EnumerationState.UVarValue Symbol :=
          .unenumerated (some 0) (incomingScs ++ oldScs)
        let core : EnumerationState.State Symbol Constraint :=
          {read with
            values := read.values.set target value
            recursionAncestry := fun other => if other = target then
              (read.expansionAncestry ++ read.recursionAncestry target).eraseDups
              else read.recursionAncestry other}
        (SourcePruningEnumerationNativeIndex.write heap indexFuel target value incomingScs []
          (EnumerationExpandableIndex.frame read before)).map (EnumerationExpandableIndex.frame core)
      | _ => none
  | [.ok ((), returned)] =>
      (returned.values[target]?).bind fun slotValue =>
        (SourcePruningEnumerationNativeIndex.write heap indexFuel target slotValue incomingScs []
          (EnumerationExpandableIndex.frame read before)).map (EnumerationExpandableIndex.frame returned)
  | _ => none

/-- A successful raw singleton supplies the candidate's exact core. -/
theorem adapt_singleton_core
    (heap : InternedConstructorTemplates.State Symbol Constraint)
    (indexFuel target : Nat) (incomingScs : List EnumerationState.Suspended)
    (before after : EnumerationExpandableIndex.Cached Symbol Constraint)
    (read returned : EnumerationState.State Symbol Constraint)
    (adapted : adapt heap indexFuel target incomingScs before read [.ok ((), returned)] = some after) :
    after.core = returned := by
  simp only [adapt, Option.bind_eq_some_iff, Option.map_eq_some_iff] at adapted
  obtain ⟨value, _stored, cached, _written, same⟩ := adapted
  subst after
  rfl

/-- Retain one original observation and attach its optional cache candidate. -/
noncomputable def run
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
    (checkEmpty : Bool) (representativeFuel nativeFuel p h indexFuel : Nat)
    (beforeCaller : Caller width) (before : EnumerationExpandableIndex.Cached Symbol Constraint)
    (target : Nat) (incoming : Node) (incomingScs : List EnumerationState.Suspended) (queries : Queries) :
    ((Except (SourceEqualityNativeDemand.Outcome width Node ⊕
      SourceCurrentAllocatedConjunctionWorker.Outcome width) (Option Raw)) ×
      Caller width × Queries × EnumerationState.State Symbol Constraint) ×
      Option (EnumerationExpandableIndex.Cached Symbol Constraint) :=
  let observed : (Except (SourceEqualityNativeDemand.Outcome width Node ⊕
      SourceCurrentAllocatedConjunctionWorker.Outcome width) (Option Raw)) ×
      Caller width × Queries × EnumerationState.State Symbol Constraint :=
    SourcePruningEnumerationIncomingNode.run checkEmpty representativeFuel nativeFuel p h
      beforeCaller before.core target incoming incomingScs queries
  (observed, match observed with
    | (.ok (some raw), reachedCaller, _savedQueries, read) =>
        adapt reachedCaller.checked.native.machine.heap indexFuel target incomingScs before read raw
    | _ => none)

