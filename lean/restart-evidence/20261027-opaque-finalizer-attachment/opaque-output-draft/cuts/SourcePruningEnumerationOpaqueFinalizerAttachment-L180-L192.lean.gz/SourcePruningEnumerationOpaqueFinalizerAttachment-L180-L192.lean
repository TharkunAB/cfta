    have endpoints := SourcePruningEnumerationChildTraversal.Result.complete.inj suffixSame
    obtain ⟨fragmentsSame, callerSame, queriesSame, cacheSame⟩ := endpoints
    subst nextSuffixFragments suffixCaller suffixQueries nextChildCache
    have different : uv ≠ eventBefore.core.counter := by
      have inside := head.admission.ready.inside
      omega
    refine ⟨eventBefore.core.counter, opaqueHandle, ?_, ?_⟩
    · exact lookupNode_keeps eventCaller.checked.native.machine.heap reached.checked.native.machine.heap
        suffixPost.effects.keeps opaqueHandle value lookup
    · exact finalizerIsolated residual fragment nextWork uv headCache different nextFinalized
  · rw [suffixStopped] at suffixSame
    cases suffixSame

