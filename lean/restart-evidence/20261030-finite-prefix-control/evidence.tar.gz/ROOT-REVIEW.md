# Finite original path carrier and actual raw path transport

The previous published head is 60f1a52358922238f7ce655f861f68f273db1989.
Root refreshed formalize and main before this phase.
Main remained bd5a406a6a3f84b7e3ae0906082783911509df83.
The protected baseline has 518 sources and 835 native inputs.

At the first review checkpoint, 15 new public laws pass production leaf builds and matching strict checks.
These laws occupy eight new modules.
The actual child-observation raw producer is still a draft at this checkpoint.
Later verification records control the final installed source set.

Root read every installed new proof in full before its passing probe.
Root also read the complete 219-line child-observation draft.
All compiler source versions and complete raw diagnostics remain in this area.
Root read the smaller failed reports in full.
Root read all 619 lines of the 26255-byte fold report.
Root inspected bounded error and goal cuts of the 47693-byte fold report and the 58409-byte observation report.
Root does not claim a full read of those two larger reports.
The source owner reviews the complete larger reports before its final seal.

The helper/prefix owner report, recursion-carrier owner report, and ordinary-renewal owner report were read in full.
Their exact payload verification records remain beside this file.
The helper/prefix report retains its acquisition-ledger race, the corrupt original, and the verified repair.
The native owner retains its corrected timestamp and every failed source version.

## Correction to the frozen helper/prefix assessment

The prepared-path-review report says that a fixed original alphabet does not make paths finite or bound path length.
That sentence conflates two different objects.
A finite alphabet of path indices does not bound the length of arbitrary words.
The actual original guard alphabet is a finite list of Constraint values.
ForecastPathDomain.carrier collects their concrete projected paths and suffixes, together with the initial paths.
That carrier is finite and bounds the length of its members.
PathKeyShapes uses this actual finite path carrier.
The source owner confirmed this correction by text at 2026-10-30 07:15 CET.
The frozen report remains unchanged so that its provenance is exact.
The correction changes no Lean declaration, proof, source hash, or compiler result.
Native handles, raw multiplicity, neutral control, ordinary renewal, and sufficient original recursive capacity remain open.

## Current mathematical boundary

Both existing original-input fixed-D results derive finite local-work stabilization and resource preservation.
Complete still permits exhaustion and other stopped outcomes.
The new path and shape laws do not derive sufficient original D.
Fixed-handle shape consumption does not bound the handles of later children.
Binder valueDepth is zero for closed values and is not ordinary height.
The finite ordinary-tree native API already proves finite completion and height preservation in its stated domain.
The mixed Mu/union control proof still needs progress across actual child selection and native rewriting.
A whole fixed-D path result must cover actual hook inputs and false-callback calls as well as retained outputs.
Successful finish discards processed receipts, so output-only paths are insufficient.

No Haskell source was changed.
No native runtime command was run.
No new Haskell defect or repair was established.
The root FINDINGS update must retain that status and all earlier repair candidates.
The full goal remains active.

## Final source checkpoint

All 17 new public laws have passing strict probes.
There are nine new modules and five new public definitions.
The final production, Audit, and public run is recorded in final-verification-batch.json.
Its command reports and verification-summary.json determine the aggregate result.
The final child-observation source is path-observation-raw-v7.lean.
Its SHA256 is 018f34315cee3e71ce6d114d53bcf42a0897537c037b5392c71914f2acb629d2.
The 7428-byte pp.all diagnostic confirms identical symbols and universe levels.
Only the generated copied matcher and actual Terminal.run matcher differ.
The final proof removes the copied map helper and inspects each actual returned row.
Root read that diagnostic and the complete final source change.
No public hypothesis was added by this repair.
The child observation law covers ChildDispatch, not all ChildTraversal or CapturedEdge raw rows.
Those compositions and the whole fixed-D execution path induction remain next tasks.

All final checks pass: Audit 4726 jobs and 82860 dependency reports; public 1147 checks and 100 definitions.
All 17 new theorem axiom reports are standard.
All 299 command input snapshots match; 48 compiler commands contain 32 passes and 16 failed drafts or diagnostics.
All four frozen reports were read in full.
The owned verifier checks 461 exact payload pins and the exact file sets.
Its first version expected a Boolean write_halt field, but the native seal uses an ISO timestamp.
The failed verifier and full assertion text remain with the schema incident record.
The current verifier validates the timezone-aware measured timestamp and FROZEN status.
This metadata correction changes no compiler command, source, proof, or owned bundle.
An earlier metadata-only read guessed uppercase PINS.json for the prepared review; the actual manifest is lowercase pins.json.
That failed read changed no files and ran no compiler.
The full prepared manifest is checked by hashes and exact file set; a capped manifest display is not claimed as a semantic source read.
