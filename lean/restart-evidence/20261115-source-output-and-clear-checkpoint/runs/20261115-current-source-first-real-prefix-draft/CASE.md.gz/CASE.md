# First real source prefix

2026-11-15 01:05 CET. This packet is uncompiled. Root owns validation.

The candidate proves a producer from the accepted original source initialization.
It retains the supplied original build, stored universe, inventory and cold caller.
It calls the real `SourcePruningOuterNarrow.narrow` through `SelectedStep.runPrefix`.
It does not use an identity narrowing operation or a legacy visitor.

The only new initial metadata condition is `metadata.pending = []`.
This is already an input of `SourceSynthesisCurrentProgramEagerResources.accepted`.
The candidate derives the initial packet with `Recursive.initial_packet`.
It then applies `SelectedStep.restart_prefix_complete`.
That result supplies one finite common bound for the six prefix fuels.
The candidate chooses a positive larger bound for the actual initial read.

The proof excludes stopped and parked results at that bound.
The initial slot read returns the original root handle and an empty suspended list.
The accepted root has no recursive boundary.
Its actual recursion check therefore returns false without a representative call.
The proof extracts these facts from the produced prefix contract.
It does not assume a successful read, check, prefix or returned context.

The candidate retains the exact actual prefix observation and real narrowing equation.
It derives the returned `Post` at the original inventory.
That `Post` contains the returned caller context.
It also derives the narrowed result's ordinary shape from the original source theorem.

There are two sufficient-fuel cases.

- Empty returns the actual empty action, no retained cache and no callback.
- A nonempty result returns the actual action, indexed cache, root slot, readiness,
  safe storage, pending references and unchanged waiting index.
  The actual callback returns false and the same metadata at that cache's Core.

An Empty source root narrows to Empty at every native fuel.
The candidate gives its exact result and unchanged source heap within the receipt.
Zero common prefix fuel returns the literal representative-fuel stop.
The finite bound is sufficient; the proof does not claim it is minimal.
For positive smaller budgets, the literal worker still determines the result.
This packet does not replace their failure or partial branches with success.

`PrefixValid` uses a finish expression as a proposition.
The private field-preservation lemma copies the checked proof from `PrefixPacket`.
The actual shared worker does not execute that legacy finish expression.
The candidate returns the observed prefix with `ordinary = none`.

The next operation remains open in this packet.
The nonempty receipt must supply the packet at the retained cache via
`Recursive.prefix_packet`, then enter the literal `SelectedPreparation.run`.
The actual shared branch must carry that entered cache to its root row and first child.
The source-position worker theorem and all its original clauses remain open.
This packet does not prove whole-worker reachability, typing, language intersection,
or termination from atom closure.

No Haskell source changed. No Haskell fix was identified.

