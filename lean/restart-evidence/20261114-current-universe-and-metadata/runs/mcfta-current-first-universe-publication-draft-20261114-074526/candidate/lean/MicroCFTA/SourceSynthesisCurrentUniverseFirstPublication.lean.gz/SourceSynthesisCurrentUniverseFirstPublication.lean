import MicroCFTA.SourceSynthesisCurrentUniverseOrigins
import MicroCFTA.SourceSynthesisLabelProgramBuildRoles
import MicroCFTA.SourceSynthesisUniverseNativeInput
import MicroCFTA.SourceCurrentNativeOriginalPublicationTrace

/-!
# First universe publication in the actual current root build

One completed current root build supplies its publication trace.
The trace can have no Mu writer. Otherwise its first publication executes
the computed universe at the original empty lexical environment.
The result does not yet prove that all source Mu records have one owner.
-/
namespace MicroCFTA.SourceSynthesisCurrentUniverseFirstPublication
open Cache InternedConstructorTemplates InternedProbeProvenance
open InternedNestedConstruction (Syntax EdgeSyntax Outcome)
open InternedFreshOrdinaryConstruction (build)
open InternedFreshOrdinaryFacts (callback)
open InternedStoredShallowCompletion (BinderFree ManyBinderFree EdgesBinderFree)
open InternedShallowHeap (NoNewMu)
open InternedBinderProtocol (NodeKey Reference)
open SourceSynthesisTypeSyntax (Library Query allTypes allTypesBody)
open SourceSynthesisGeneralizeSyntax (Guard top)
open SourceSynthesisFirstOrderConstruction (Expression Row)
open SourceSynthesisUniverseOrigins (OverUniverse)
open SourceSynthesisProgramBuildRolesGeneric
  (mapSyntax mapChildren mapEdges mapEdge mapChildren_eq_map mapEdges_eq_map)
open SourceCurrentNativeMuPublication (Publication)
open SourceCurrentNativeOriginalPublicationTrace (events)
open SourceCurrentNativeMuGrowthHistory (reserve_growth publication_growth)
open InternedFreshOrdinarySourceHistory (Reached)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "literal" => SourceSynthesisLabelProgramBuildRoles.literal
local notation "ordinarySymbols" => SourceSynthesisUniverseCallerBoundary.ordinarySymbols
local notation "SourcePath" => InternedFreshOrdinaryActiveOrigins.Path
local notation "Crossing" => InternedFreshOrdinaryActiveOrigins.Crossing
local notation "IssuedPath" => SourceCurrentNativeMuIssuedHistory.Path

set_option autoImplicit false

mutual
private theorem mapped_free (expression : Expression) (clean : BinderFree expression) :
    BinderFree (mapSyntax literal expression) := by
  cases expression with
  | empty | var => trivial
  | binder => exact False.elim clean
  | node rows => exact mapped_edges_free rows clean
  | union members => exact mapped_many_free members clean
termination_by sizeOf expression

private theorem mapped_many_free (expressions : List Expression) (clean : ManyBinderFree expressions) :
    ManyBinderFree (mapChildren literal expressions) := by
  cases expressions with
  | nil => trivial
  | cons first rest => exact ⟨mapped_free first clean.1, mapped_many_free rest clean.2⟩
termination_by sizeOf expressions

private theorem mapped_edges_free (rows : List Row) (clean : EdgesBinderFree rows) :
    EdgesBinderFree (mapEdges literal rows) := by
  cases rows with
  | nil => trivial
  | cons row rest =>
      cases row with
      | mk name guard children =>
          exact ⟨mapped_many_free children clean.1, mapped_edges_free rest clean.2⟩
termination_by sizeOf rows
end

private theorem many_free_member (children : List (Syntax Symbol Guard))
    (clean : ManyBinderFree children) (child : Syntax Symbol Guard) (member : child ∈ children) :
    BinderFree child := by
  induction children with
  | nil => cases member
  | cons first rest ih =>
      rcases List.mem_cons.mp member with rfl | later
      · exact clean.1
      · exact ih clean.2 later

private theorem row_free_child (rows : List (EdgeSyntax Symbol Guard))
    (clean : EdgesBinderFree rows) (symbol : Symbol) (guard : Guard)
    (children : List (Syntax Symbol Guard)) (member : .mk symbol guard children ∈ rows)
    (child : Syntax Symbol Guard) (inside : child ∈ children) : BinderFree child := by
  induction rows with
  | nil => cases member
  | cons first rest ih =>
      cases first with
      | mk name ownGuard ownChildren =>
          rcases List.mem_cons.mp member with same | later
          · cases same
            exact many_free_member children clean.1 child inside
          · exact ih clean.2 later

private theorem mapped_node_child (rows : List Row)
    {symbol : Symbol} {guard : Guard} {children : List (Syntax Symbol Guard)}
    {child : Syntax Symbol Guard}
    (edge : .mk symbol guard children ∈ mapEdges literal rows) (member : child ∈ children) :
    ∃ (name : String) (ownGuard : Guard) (sourceChildren : List Expression) (sourceChild : Expression),
      .mk name ownGuard sourceChildren ∈ rows ∧ sourceChild ∈ sourceChildren ∧
      child = mapSyntax literal sourceChild := by
  have mappedMember : .mk symbol guard children ∈ rows.map (mapEdge literal) := by
    simpa only [mapEdges_eq_map] using edge
  obtain ⟨row, included, same⟩ := List.mem_map.mp mappedMember
  cases row with
  | mk name ownGuard sourceChildren =>
      simp only [mapEdge, EdgeSyntax.mk.injEq] at same
      obtain ⟨_symbol, _guard, childrenSame⟩ := same
      rw [← childrenSame] at member
      have childMember : child ∈ sourceChildren.map (mapSyntax literal) := by
        simpa only [mapChildren_eq_map] using member
      obtain ⟨sourceChild, inside, childSame⟩ := List.mem_map.mp childMember
      exact ⟨name, ownGuard, sourceChildren, sourceChild, included, inside, childSame.symm⟩

section Trace
variable [DecidableEq (EdgeKey Symbol Guard)]

private theorem path_free
    {root expression : Syntax Symbol Guard} {inputs environment : List (Value Symbol Guard)}
    {crossings : List (Crossing Symbol Guard)}
    (path : SourcePath root inputs expression environment crossings)
    (clean : BinderFree root) : BinderFree expression := by
  induction path with
  | here => exact clean
  | node edge member nested ih => exact ih (row_free_child _ clean _ _ _ edge _ member)
  | union member nested ih => exact ih (many_free_member _ clean _ member)
  | binder crossing nested ih => exact False.elim clean

/-- An ordinary prefix cannot cross a callback before it reaches its universe binder. -/
private theorem mapped_prefix_binder (catalog : List (String × Nat)) (expression : Expression)
    (origin : OverUniverse (allTypes top catalog) expression) :
    ∀ (initial current : List (Value Symbol Guard)) (smart : Bool) (body : Syntax Symbol Guard)
      (crossings : List (Crossing Symbol Guard)),
      SourcePath (mapSyntax literal expression) initial (.binder smart body) current crossings →
      .binder smart body = mapSyntax literal (allTypes top catalog) ∧ current = initial ∧ crossings = [] := by
  induction origin with
  | atom =>
      intro initial current smart body crossings path
      generalize sameRoot : mapSyntax literal (allTypes top catalog) = root at path
      cases path with
      | here => exact ⟨sameRoot.symm, rfl, rfl⟩
      | node edge member nested => cases sameRoot
      | union member nested => cases sameRoot
      | binder crossing nested =>
          change .binder true (mapSyntax literal (allTypesBody top catalog)) =
            .binder crossing.smart crossing.body at sameRoot
          have sameBody := (Syntax.binder.inj sameRoot).2
          have bodyFree : BinderFree crossing.body := sameBody ▸
            mapped_free (allTypesBody top catalog)
              (SourceSynthesisUniverseNativeInput.allTypesBody_binderFree top catalog)
          have impossible := path_free nested bodyFree
          exact False.elim impossible
  | node rows children ih =>
      intro initial current smart body crossings path
      cases path with
      | node edge member nested =>
          obtain ⟨name, guard, inputs, child, included, inside, same⟩ :=
            mapped_node_child rows edge member
          rw [same] at nested
          exact ih (.mk name guard inputs) included child inside initial current smart body crossings nested
  | union members children ih =>
      intro initial current smart body crossings path
      cases path with
      | union member nested =>
          have mappedMember : _ ∈ members.map (mapSyntax literal) := by
            simpa only [mapChildren_eq_map] using member
          obtain ⟨child, included, same⟩ := List.mem_map.mp mappedMember
          rw [← same] at nested
          exact ih child included initial current smart body crossings nested

private theorem current_reached_binder
    (lib : Library) (query : Query) (signed : Int) (whole : Expression)
    (accepted : SourceSynthesisCurrentConstruction.firstOrderRaw lib query signed = .ok whole)
    {smart : Bool} {body : Syntax Symbol Guard} {environment : List (Value Symbol Guard)}
    {state : State Symbol Guard}
    (site : Reached (ordinarySymbols whole) [] (.binder smart body) environment state) :
    smart = true ∧
      body = ordinarySymbols (allTypesBody top (SourceSynthesisCurrentContext.constructorCatalog lib query)) ∧
      environment = [] := by
  obtain ⟨crossings, path, _⟩ := site
  have sourcePath : SourcePath (mapSyntax literal whole) [] (.binder smart body) environment crossings := by
    simpa only [SourceSynthesisLabelProgramBuildRoles.mapSyntax_ordinarySymbols] using path
  obtain ⟨same, inputs, _⟩ := mapped_prefix_binder
    (SourceSynthesisCurrentContext.constructorCatalog lib query) whole
    (SourceSynthesisCurrentUniverseOrigins.firstOrderRaw_overUniverse lib query signed whole accepted)
    [] environment smart body crossings sourcePath
  change .binder smart body = .binder true (mapSyntax literal
    (allTypesBody top (SourceSynthesisCurrentContext.constructorCatalog lib query))) at same
  have fields := Syntax.binder.inj same
  refine ⟨fields.1, ?_, inputs⟩
  simpa only [SourceSynthesisLabelProgramBuildRoles.mapSyntax_ordinarySymbols] using fields.2

/-- Every event in the actual issued path retains both surrounding growth intervals. -/
private theorem event_bounds {before after : State Symbol Guard} (path : IssuedPath before after) :
    ∀ event, event ∈ events path → Grows before event.before ∧ Grows event.after after := by
  induction path with
  | refl | retain => intro event member; simp only [events, List.not_mem_nil] at member
  | trans first next firstIH nextIH =>
      intro event member
      simp only [events, List.mem_append] at member
      rcases member with left | right
      · obtain ⟨prefix, suffix⟩ := firstIH event left
        exact ⟨prefix, grows_trans suffix next.growth⟩
      · obtain ⟨prefix, suffix⟩ := nextIH event right
        exact ⟨grows_trans first.growth prefix, suffix⟩
  | publication event depthPath ordinaryPath bodyPath depthIH ordinaryIH bodyIH =>
      intro selected member
      have cutFinal : Grows event.cut event.after :=
        grows_trans (reserve_growth event) (grows_trans bodyPath.growth (publication_growth event))
      have depthFinal : Grows event.afterDepth event.after := grows_trans ordinaryPath.growth cutFinal
      have beforeAllocated : Grows event.before event.allocated :=
        grows_trans depthPath.growth (grows_trans ordinaryPath.growth (reserve_growth event))
      simp only [events, List.mem_append, List.mem_singleton] at member
      rcases member with ((inDepth | inOrdinary) | inBody) | same
      · obtain ⟨prefix, suffix⟩ := depthIH selected inDepth
        exact ⟨prefix, grows_trans suffix depthFinal⟩
      · obtain ⟨prefix, suffix⟩ := ordinaryIH selected inOrdinary
        exact ⟨grows_trans depthPath.growth prefix, grows_trans suffix cutFinal⟩
      · obtain ⟨prefix, suffix⟩ := bodyIH selected inBody
        exact ⟨grows_trans beforeAllocated prefix, grows_trans suffix (publication_growth event)⟩
      · subst selected
        exact ⟨grows_refl _, grows_refl _⟩

private theorem first_publication_or_noMu (original : Syntax Symbol Guard)
    (result : Value Symbol Guard) (heap : State Symbol Guard)
    (actual : build original [] empty = .done result heap) :
    NoNewMu empty heap ∨
      ∃ (path : IssuedPath empty heap) (event : Publication (Symbol := Symbol) (Guard := Guard)),
        (events path)[0]? = some event ∧
        Reached original [] (.binder event.smart event.expression) event.environment event.before ∧
        NoNewMu empty event.afterBody ∧ Grows event.after heap := by
  obtain ⟨path, sites, writers, earlier⟩ :=
    SourceCurrentNativeOriginalPublicationTrace.build_trace_writers original [] empty
      SourceCurrentConstrainedCapSourceHistory.empty_context
      (by intro key entry body depth ordinary absent; cases absent) result heap actual
  cases listed : events path with
  | nil =>
      left
      intro key entry body depth ordinary present
      obtain ⟨index, event, selected, _⟩ := writers key entry body depth ordinary present
      simp only [listed, List.getElem?_nil] at selected; cases selected
  | cons event rest =>
      right
      have selected : (events path)[0]? = some event := by simp only [listed, List.getElem?_cons_zero]
      have clean : NoNewMu empty event.afterBody := by
        intro key entry body depth ordinary present
        obtain ⟨index, previous, less, _⟩ := earlier 0 event selected key entry body depth ordinary present
        omega
      exact ⟨path, event, selected, sites 0 event selected, clean,
        (event_bounds path event (List.mem_of_getElem? selected)).2⟩

private theorem before_body_growth (event : Publication (Symbol := Symbol) (Guard := Guard)) :
    Grows event.before event.afterBody := by
  obtain ⟨depthContext, cutContext, bodyContext⟩ := SourceCurrentNativeMuPublicationCallbacks.contexts event
  have first : Grows event.before event.afterDepth := by
    simpa only [event.depthDone, Outcome.state] using
      (InternedFreshOrdinaryActiveOrigins.callback_growing event.expression event.environment .depth
        event.before event.context.base.normal.facts.coherent.valid).2
  have second : Grows event.afterDepth event.cut := by
    simpa only [event.ordinaryDone, Outcome.state] using
      (InternedFreshOrdinaryActiveOrigins.callback_growing event.expression event.environment
        (.uninterned (InternedFreshOrdinaryConstruction.ordinaryLevel event.depth)) event.afterDepth
        depthContext.base.normal.facts.coherent.valid).2
  have called : callback event.expression event.environment (.interned event.entry.identity) event.allocated =
      .done event.body event.afterBody := event.bodyDone
  have third : Grows event.allocated event.afterBody := by
    simpa only [called, Outcome.state] using
      (InternedFreshOrdinaryActiveOrigins.callback_growing event.expression event.environment
        (.interned event.entry.identity) event.allocated bodyContext.base.normal.facts.coherent.valid).2
  exact grows_trans first (grows_trans second (grows_trans (reserve_growth event) third))

end Trace

/-- The same actual current build has no Mu writer or supplies its first universe publication. -/
private theorem current_first_universe_publication
    [DecidableEq (EdgeKey Symbol Guard)]
    (lib : Library) (query : Query) (signed : Int) (whole : Expression)
    (accepted : SourceSynthesisCurrentConstruction.firstOrderRaw lib query signed = .ok whole)
    (rootValue : Value Symbol Guard) (heap : State Symbol Guard)
    (built : build (ordinarySymbols whole) [] empty = .done rootValue heap) :
    NoNewMu empty heap ∨
      ∃ (path : IssuedPath empty heap) (event : Publication (Symbol := Symbol) (Guard := Guard)),
        (events path)[0]? = some event ∧
        Reached (ordinarySymbols whole) []
          (ordinarySymbols (allTypes top (SourceSynthesisCurrentContext.constructorCatalog lib query)))
          [] event.before ∧
        event.smart = true ∧
        event.expression = ordinarySymbols
          (allTypesBody top (SourceSynthesisCurrentContext.constructorCatalog lib query)) ∧
        event.environment = [] ∧
        NoNewMu empty event.before ∧ NoNewMu empty event.afterBody ∧
        Grows event.after heap ∧
        build (ordinarySymbols (allTypes top (SourceSynthesisCurrentContext.constructorCatalog lib query)))
          [] event.before = .done event.result event.after := by
  rcases first_publication_or_noMu (ordinarySymbols whole) rootValue heap built with clean | selected
  · exact .inl clean
  · obtain ⟨path, event, first, site, clean, growth⟩ := selected
    obtain ⟨smart, body, environment⟩ := current_reached_binder lib query signed whole accepted site
    have binderSame : .binder event.smart event.expression =
        ordinarySymbols (allTypes top (SourceSynthesisCurrentContext.constructorCatalog lib query)) := by
      rw [smart, body]
      rfl
    have reached : Reached (ordinarySymbols whole) []
        (ordinarySymbols (allTypes top (SourceSynthesisCurrentContext.constructorCatalog lib query)))
        [] event.before := by
      simpa only [binderSame, environment] using site
    have beforeClean : NoNewMu empty event.before := by
      intro key entry body depth ordinary present
      exact clean key entry body depth ordinary ((before_body_growth event).nodeRecords key _ present)
    have called : build
        (ordinarySymbols (allTypes top (SourceSynthesisCurrentContext.constructorCatalog lib query)))
        [] event.before = .done event.result event.after := by
      simpa only [binderSame, environment] using event.build_done
    exact .inr ⟨path, event, first, reached, smart, body, environment, beforeClean, clean, growth, called⟩

#print axioms current_first_universe_publication

end MicroCFTA.SourceSynthesisCurrentUniverseFirstPublication
