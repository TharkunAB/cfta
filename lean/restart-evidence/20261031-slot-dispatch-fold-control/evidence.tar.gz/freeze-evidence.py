from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,subprocess

r=Path('/tmp/mcfta-slot-and-native-dispatch-control-20261031')
assert not (r/'FROZEN.json').exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='a91460330f2b55c2b59ec56dbc40acdba53bd2e4'
assert not subprocess.check_output(['git','status','--porcelain=v1'])
publication=json.loads((r/'checkpoint-publication.json').read_text())
assert publication['head']==head and publication['readback_exact'] and publication['tracking_exact']
assert publication['refs']['refs/heads/main']=='bd5a406a6a3f84b7e3ae0906082783911509df83'
summary=json.loads((r/'verification-summary.json').read_text())
assert summary['commands']==19 and summary['passed']==15 and summary['failed']==4
assert summary['input_snapshots']==52 and summary['public_checks']==1223 and summary['all_new_axioms_standard']
assert json.loads((r/'owned-verification.json').read_text())['status']=='pass'
assert json.loads((r/'document-verification.json').read_text())['all_current_pins']=='pass'
for p in r.iterdir():
    if p.is_dir() and not p.name.startswith('prior-') and (p/'started-command.json').exists():
        assert (p/'report.json').exists()
rows=[]
for p in sorted(r.rglob('*')):
    if p.is_file():
        assert not p.is_symlink();b=p.read_bytes()
        rows.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
seal={'created_at':datetime.now(ZoneInfo('Europe/Stockholm')).isoformat(),'write_halt':True,
      'goal_turn':'progress','full_goal_complete':False,'goal_controller_observed_status':'blocked',
      'work_continues_under_user_instruction':True,
      'dispatch_source_head':'14e7fa6d7494e65a301d9f0b5fc6bc64d6292160',
      'slot_source_head':'bcd4a68303df554b8efe05839ac218c597a42e47',
      'source_head':'a5a174707fe610082b61e1fb501f74f99b7d351d','docs_head':head,
      'main_head':'bd5a406a6a3f84b7e3ae0906082783911509df83','latest_prior_board_sequence':792,
      'compiler_commands':19,'passed_commands':15,'repaired_failed_commands':4,'input_snapshots':52,
      'new_laws':4,'public_checks':1223,'public_definitions':118,
      'root_source_lines':413,'root_public_lines':137,
      'future_contracts':'complete Terminal152L and adapter63L drafts retained UNCOMPILED with full owners',
      'next_source_tasks':'actual final-prefix observation extraction and Terminal check; no extra Root check claimed',
      'payload_count_excluding_seal':len(rows),'payloads':rows}
(r/'FROZEN.json').write_text(json.dumps(seal,indent=2)+'\n')
for p in r.rglob('*'):
    if p.is_file():p.chmod(p.stat().st_mode&~0o222)
assert all(not(p.stat().st_mode&0o222) for p in r.rglob('*') if p.is_file())
print(json.dumps({'sealed':True,'payloads_excluding_seal':len(rows),
 'raw_bytes_excluding_seal':sum(a['bytes'] for a in rows),'source_head':seal['source_head'],'docs_head':head}))
