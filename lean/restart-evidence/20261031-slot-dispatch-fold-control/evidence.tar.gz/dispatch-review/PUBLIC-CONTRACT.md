# Dispatcher public contract

Complete source-only candidate. No new law is claimed checked.
The local notations and typeclass variables are in the complete V1 file.

```lean
theorem dispatch_native_stored (profile : Profile) (checkEmpty : Bool) (nativeFuel p h : Nat)
    (beforeCaller : Caller (bits + 2)) (before : EnumerationState.State Symbol EnumGuard)
    (source target : Nat) (queries : Queries)
    (ready : SourceCurrentConjunctionClassScan.Ready beforeCaller.checked)
    (realized : PendingRealized beforeCaller.checked.native.machine.heap before)
    (fits : Fits profile beforeCaller.checked) (room : Room bits profile)
    (stored : Stored beforeCaller.checked.native) :
    Stored (SourcePruningEnumerationDispatch.dispatch checkEmpty nativeFuel p h
      beforeCaller before source target queries).2.1.checked.native
```
