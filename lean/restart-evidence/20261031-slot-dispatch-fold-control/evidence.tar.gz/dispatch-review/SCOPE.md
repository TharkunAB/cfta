# Scope

Root assigned this fresh source-only task at 2026-10-31 00:21 CET.
Prove the exact dispatch_native_stored target from current Ready, PendingRealized, Fits/Room and entry native Stored. Follow actual Dispatch.dispatch and afterQuery. Derive both decoded operands and numeric checks internally. No Fold theorem, future trace, output Stored or completion supplier.

Root owns compiler, evaluator, native execution, Git, network, board, production and packaging. No spawning. All writes stay here. Prior bundles remain frozen. Max two named OLD whole/near-whole modules; name before acquisition. Other reads use bounded exact cuts with source metadata/unions. Explicit full new-law reuses are the checked NativeStoredExecute and NativeStoredEnabledEmpty used in this proof.
