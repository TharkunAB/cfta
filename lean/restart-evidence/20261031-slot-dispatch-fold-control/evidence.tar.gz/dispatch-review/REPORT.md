# Native Stored through the actual dispatcher

Status: complete source-only V1 candidate. This worker ran no compiler,
evaluator or native execution. No new law is claimed checked here.

## Result

NativeStoredDispatch-v1-UNCOMPILED.lean has 150 lines. Its one public law is
`dispatch_native_stored`. The conclusion concerns the actual returned
Dispatch.dispatch tuple's .2.1.checked.native. It covers every nativeFuel, p
and h, both checkEmpty modes, every source/target index, all returned actions
and all actual native or conjunction outcomes.

The public property premises are exactly:

- Ready beforeCaller.checked.
- PendingRealized for the current original enumeration state before.
- Fits profile beforeCaller.checked and Room bits profile.
- Native Stored beforeCaller.checked.native.

The proof adds no availability or closedness premise for either operand. It
derives both from the actual stored slots. It adds no pending-at-source,
pending-at-target, representative root, StorageValid, native WordRanges,
future Trace, per-step future certificate, output Stored, future success or
completion supplier.

The complete public signature is in PUBLIC-CONTRACT.md. The candidate SHA-256
is 5b82e86c40509b60a255cf146d5174f1584fd891a34b34d971afae08523d6340.

## Both operand producers

The actual dispatcher reads before.values[source]? and before.values[target]?.
Only their unenumerated/some-handle branches can reach the raw native call.
The source and target lookup equations therefore have exactly the forms used
by the current PendingRealized predicate.

The proof applies realized separately at source and target, with the actual
handle, suspended list and original stored-slot equation. Each result gives a
decoded node, its exact heap lookup equation, availability and closed syntax.
Equality with the actual heap lookup identifies each decoded value with the
actual left or right operand. There is no guessed original slot or new
semantic classification of source/target.

The proof then uses fits.room room. Its three current counter projections are
the existing execute_stored node, edge and domain admission bounds. The raw
query in Dispatch.dispatch is literally the empty-domain request on left and
right. The checked execute_stored law derives the necessary Original,
WordRanges and physical checks internally from these current entry facts.

## Actual query continuation

The one private lemma, after_query_stored, follows the exact afterQuery code.
Its Stored premise concerns its OWN current queried entry. It is not an output
Stored or future-state supplier for the public dispatcher theorem. The public
proof invokes it only after deriving queried Stored from the actual raw execute
observation.

The helper handles both checkEmpty modes. The true mode uses the checked
unconditional EnabledEmpty.check_stored law. The false mode retains queried.
It then cases the actual phase outcome. Both success and failure call
Caller.advance with the phase's own checked state. Explicit change statements
reduce this checked projection to checkedAfter.native.

The successful helper returns an optional encoded action, but that action is
in a different tuple field. Its encoding or later enumeration effects cannot
change the checked caller that afterQuery already returns. No closedness or
extra numeric gate is required for the returned query at this stage.

EnumGuard is specified explicitly when the helper is called. It occurs in the
returned enumeration action type and can otherwise disappear below the Caller
projection. This is an elaboration parameter, not a logical gate.

## Complete dispatcher branch account

- Equal source/target returns the same caller and a no-op action.
- Missing source or target slots retain the same caller.
- Eliminated source returns the same caller and a no-op action.
- Enumerated source or non-unenumerated target returns the same caller with
  the literal invalid-intersection action.
- Missing source or target handles retain the same caller with finishOptional.
- Failed source or target heap decode retains the same caller.
- Two actual decoded nodes invoke the checked execute_stored law after the
  internal operand/counter derivation above.
- Actual yielded, failed, constraintError and blocked raw outcomes advance
  with that outcome's own returned checked state. Explicit checked-state
  changes and the raw Stored observation close every case.
- Actual done invokes afterQuery at the exact queried state. Its returned
  caller is retained even if its action is absent or its phase fails. Mapping
  the error tag cannot change this caller projection.

The source proof exposes dispatch and Id.run, splits the actual early return,
and cases the actual original slot/handle/decode results. A bounded locator
records the existing dispatcher proof's Id.run reduction pattern. No execute
or callback was run by this worker.

## Checked inputs and scope

The exact full new-law reuses are:

- SourceCurrentAllocatedNativeStoredExecute.lean, 89 lines, SHA-256
  ed2bc2575ca4f3571e60b9c2cf5be4d14ed30f9f29e2578e82f7f82318bd9611.
- SourceCurrentAllocatedNativeStoredEnabledEmpty.lean, 43 lines, SHA-256
  5835734077c7cea16ccee0330cdaf12cab65dc96bfac55a4066c9c2dc8521d10.

Both exact source hashes were verified before use. Root owns their execution
and checking evidence. This worker checked only that all four import paths
exist; IMPORT-PATH-CHECKS.json retains that filesystem observation. It is not a
Lean import, compilation or evaluation check.

No OLD whole or near-whole module was acquired. Both slots remain unused.
The old bodies are exact cuts of Dispatch (1-92 of 435), IncomingNodeResources
(11-70 of 239, for the existing realized/fits producer pattern), and PartialState
(61-65 of 250, for the literal Caller.advance definition). The extra dispatcher
read contains only the named Id.run reduction locator lines.

All writes stayed in /tmp/mcfta-native-dispatch-stored-review-20261031. Prior
bundles remain frozen. There was no compiler, evaluator, native execution,
Git, network, board, production write, packaging operation or spawned worker.
The complete source ledger and cumulative line unions are retained.

## Boundaries

This candidate preserves the existing conditional native structural
certificates. It does not establish finite ordinary bounds for every recursive
request or result. Context.stored remains the separate merge-memo invariant;
native Stored is an explicit separate maintained entry property.

No Fold theorem was attempted or claimed. This task did not read Fold source.
Original-input capacity, sufficient original depth, source reset and unchanged
steps, whole-worker induction, finite global enumeration, public API
correspondence and Haskell correspondence remain outside this law.

No Haskell source changed. No admitted actual Haskell execution occurred. No
Haskell defect or fix was established. There is no new Haskell FINDINGS entry.
