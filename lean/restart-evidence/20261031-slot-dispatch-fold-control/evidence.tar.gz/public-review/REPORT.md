# Native dispatch, actual slot transport and native Fold review

Result: PASS for all four final source and public contracts. The reviewer
found no source or public-contract defect. The reviewer ran no compiler,
evaluator, native, Git, network, board, production or spawn command. Root
owns compilation, runtime evidence and production operations.

## Exact scope and complete reads

| Final installed copy | Lines | Bytes | SHA-256 |
| --- | ---: | ---: | --- |
| inputs/installed-dispatch.lean | 151 | 9257 | 01499c214a1a0ddf5f995ed347ae22505be36f0ec8e6ddc0c3f7462012667878 |
| inputs/installed-slot.lean | 176 | 11447 | 55eedb67e1311dcad35710cf7c11c028cca2e51129893a8d8fe5939624158340 |
| inputs/installed-fold.lean | 86 | 5133 | 89e2076f35378262c6d2997bfab9c3be35ad8cfa26d3bdb985989d339d101791 |

The installed total is 413 lines and 25837 bytes. The reviewer read every
151 dispatch line, every 177 slot V4 line and every 87 Fold draft line,
including all private proof branches. Exact byte comparisons connect the
slot and Fold reads to their installed versions. Installation removes only
the 68-byte slot status line and 48-byte Fold status line.

The final new public output has 137 lines and 10211 bytes. Its SHA-256 is
003620fddb76ee15fb3d4d33e25a201abc3d533205b0d436d05ffb4c14547fe7.
It is exactly the fully read 105-line three-law tail followed by the fully
read 32-line Fold tail. No display was truncated. All four complete expanded
signatures and axiom reports were read. No new definitions were printed.

The completed intermediate 327-line source scope and 105-line public tail
remain retained. Root preserves the complete intermediate public-v2 log.
This review pins that log's size and SHA-256 as metadata without acquiring
its old multi-megabyte body. read-ledger.json, acquisitions.json and the
installation identities record the exact read ranges, copies and hashes.

## Dispatch: every actual reached native state

SourceCurrentAllocatedNativeStoredDispatch.dispatch_native_stored retains
current native Ready, PendingRealized for the original values array, Fits
profile, Room bits profile and entry native Stored. It does not require
separate supplied availability or closedness for the two decoded operands.

The reviewer checked the actual dispatch, afterQuery and finishOptional
definitions. Equal source and target, missing slots, eliminated source,
invalid slot forms, missing handles and failed lookups all retain the
caller's native state. Enumeration actions in those branches remain
separate from that caller projection.

When both handles decode, PendingRealized is applied at the actual source
and target indices in the original values array. The two lookup equations
identify the actual operands. Their availability and closedness derive
from those observations. Fits.room supplies exactly the CURRENT node,
edge and domain bounds required by the existing arbitrary-fuel execute
law. The proof does not reset counters or supply a future execution trace.

All five native observations are covered: yielded, failed, constraintError,
blocked and done. The first four retain the actual observed state through
Caller.advance. For done, the private after-query proof covers checkEmpty
true and false and both conjunction outcomes. The actual reached checked
state is retained in the result caller. Native fuel zero and every other
supplied fuel are included.

Ready here is SourceCurrentConjunctionClassScan.Ready, with Good,
SemanticReady, CostHeap, Scoped and Idle fields. Fits includes current
counter and heap-mass gates. Its derived numeric bounds at width bits+2
are nodes.next < 2^bits, edges.next <= 2^(bits+2), and
 domains.next + 2^(nodes.next + nodes.next*nodes.next) < 2^(bits+1).
These remain explicit conservative resource assumptions. No Word64
runtime bound or result semantics follows.

## False recursion check: derive the complete frame

SourcePruningEnumerationRecursion.checkRepeated_false_frame takes current
UnionFind.Total and an actual successful false checkRepeated observation.
It derives Frame. No Frame premise is supplied.

The reviewer checked the actual checkRepeated definition. A missing decode
cannot give the supplied success. Outside the recursive boundary, false is
pure. Inside it, the actual representative lookup gives a compression
frame. The actual get-success equalities identify the state that is read.
The branch that writes the recursion marker returns true and contradicts
the observed false result. The remaining branch is pure false.

Frame retains counter, values, obligations, both ancestry components and
representative reachability with the same representative and size. It
permits path compression. This is the exact frame needed for the next
representative read and allocated-slot proof.

## Successful changed preparation: the actual stored value

SourcePruningEnumerationAction.prepare_changed_success_stores_normal
retains cache Ready, PendingRealized and UnionFind.Total at the initial
enumeration state. Its observation inputs are exact:

- a successful getValue returning the old handle and ancestry list;
- a successful false checkRepeated from that read's reached state;
- the actual old-handle lookup equation;
- successful prepare returning the result and the actual action;
- the observed new encoding equation and changed handle;
- actual action Success from the checked state to final.

The newEncoded observation remains an input. The OLD encoding equation,
old availability and old closedness derive internally. Input Normal is
neither assumed nor proved. RESULT Normal derives from the actual changed
prepare result. All Frames and allocation bounds derive internally.

The successful getValue exposes the actual representative and old stored
slot in the original values array. PendingRealized and the actual lookup
supply the old value's availability and closedness. Current coherence
derives its old encoding. The existing actual changed-returned control
law supplies heap Keeps, result availability, closedness, root Ordinary,
physical Normal and kept canonical outgoing edges.

The proof inspects the actual prepare branches. Empty selects reject and
cannot satisfy action Success. Reference, Union and Mu roots contradict
the derived root Ordinary result. For a node result, the observed encoding
and changed handle identify the actual action as representative followed
by setValue. No pure-action or successful-Empty assumption is added.

The initial read, false check and successful representative read derive
frames and preserve the representative class. representative_agrees
identifies the final selected root with the original slot's representative.
The retained old slot proves that root is in bounds. The actual setValue
success gives the exact final list.set update and the actual stored new
handle. Current readback and heap Keeps derive result lookup and final
PendingRealized.

The postcondition states that the actually stored result is available,
closed, root Ordinary and physically Normal. Its complete outgoing edges
satisfy keeps at the SAME hole key. If the old value has an Ordinary root,
those result edges are a subset of its canonical root rows. Ordinary here
allows recursive children. This is not a recursive finite NodeDomain
assumption or an old-input Normal theorem. No strict row loss is asserted
for an arbitrary old input that lacks Normal.

## Exact slot endpoint and name resolution repair

The reviewer read the literal SourcePruningEnumerationSelectedStep.runPrefix
body. Its changed-success path performs getValue, false checkRepeated,
old lookup, prepare and the action. It then tests the new encoding, calls
NarrowAdapter.adapt, attaches index state and can run Right recordTypes.

The new slot theorem's final is the action's successfully observed state.
The literal runPrefix branch reaches that state at its singleton-success
match. The theorem takes action Success as its observation premise. It
stops BEFORE adaptation, index updates and Right recording. Its premises
are separate actual stage observations. The public theorem does not
itself extract those observations from a final runPrefix result, nor
transport the conclusion through later operations.

All four source header TEXTS match their original owner texts. For the
slot header, this is not a claim about an already elaborated original type.
The owner source left bare nodeEdges unresolved. Adding open
InternedEdgeResidency repairs its intended constant resolution. The final
expanded public postcondition explicitly uses
MicroCFTA.InternedEdgeResidency.nodeEdges. There is no implicit nodeEdges
parameter. The source header text comparison, resolution repair and
current canonical name are recorded separately.

## Fold: actual all-outcome induction

SourceCurrentAllocatedNativeStoredFold.fold_native_stored retains current
Seed, Context, PendingRealized, targetPending, the pending-or-eliminated
source selection, Fits, Reserved, the current known guard alphabet and
entry native Stored. There is no future Ranges, outputStored or certificate
function supplier.

The reviewer read actual Fold.run, the observed_singleton producer header,
and Seed, step and Reserved. Reserved requires numeric Room at each finite
forecast index before the selected list length. It is an original numeric
reservation, not a premise that future actual memo states satisfy Stored.
Its head supplies current Room. Its tail supplies the residual reservation.

For a nonempty source list, the new proof obtains reachedStored from the
ACTUAL dispatch observation before any outcome split. Dispatch error,
no action, empty raw results, an error result and multiple results all
return that same reached caller. Each early return uses reachedStored.

Only actual singleton action success enters recursion. In that branch,
observed_singleton takes the actual dispatch equation and exact singleton
raw-result equation. It derives successor Context, PendingRealized,
targetPending, remaining selection, Fits and known alphabet. querySame
identifies the actual saved query memo. reserved.tail and those derived
facts feed the induction hypothesis with the derived reachedStored.
No future Stored fact is supplied by the caller or producer theorem.

The empty source list returns the entry caller. The law covers every actual
Fold outcome at arbitrary fixed execution bounds. It concerns this concrete
finite fold. It makes no Terminal or whole-worker claim.

## Meaning of the native invariant and remaining boundaries

Native Stored concerns returned native node and edge memo cells. For an
empty-seen request with recursively finite ordinary operands, its returned
result must be recursively finite ordinary and have height at most each
operand's height. The certificate is conditional. It does not assert an
unrestricted property for every returned root or pending memo cell.

The dispatch and Fold laws preserve that invariant at the actual reached
caller. The slot law proves a different property about the physically
normal value actually written to the enumeration slot. These laws do not
establish final emptiness-answer semantics, arbitrary returned-root
semantics, larger filter histories, reset control, actual later
adaptation/index/Right-recording transport, original enumeration depth,
global coverage, Terminal, whole-worker proof or Haskell correspondence.
The pending 63-line adapter corollary remains an uncompiled next draft
outside this checkpoint. No Haskell defect or fix is established here.

## Bounded old acquisitions and retained provenance

The OLD union is 571 lines over 22 original source paths. It consists of
27 contiguous cuts and 15 declaration locator records. Zero OLD whole or
near-whole modules were acquired. The maximum fraction is 42 of 132 lines
in the incoming reservation module.

Nine bounded prior reuses total 120 lines. Eight reuse the earlier R8 cuts.
One reuses the R7 ordinary-row subset cut. Two source modules were NEW and
fully read in R7; this review reacquires only their 13-line execute and
three-line EnabledEmpty headers. It does not silently treat them as fresh
NEW bodies. All current reuses count by ORIGINAL repository path.
prior-bounded-reuses.json records origins, hashes and ranges. The two
prior full reviews remain frozen. Old-source ledgers retain all exact
source hashes, sizes, line unions and copy hashes. Full-file hashes and
sizes were streamed as metadata without acquiring the OLD bodies.

The bundle retains supplied owner sources, Root candidate versions,
installed snapshots, proof diffs, all new public pieces, read ledgers and
header comparisons. Installation identities are exact. Root reports four
repaired failed probes, including one retained indentation failure. The
review does not independently assign that indentation failure to a
particular version. Root owns the compiler logs and snapshots.

One dispatch was aborted before execution when Root sent the Fold update.
It changed no file. A header extraction helper failed because it assumed
arguments start on the theorem declaration line. The false-frame theorem
uses the next line. The corrected parser recovered all four exact header
texts. Its failure and recovery are retained. No display was truncated.
No source or public-contract defect was found.

## Validation authority

All four public reports use only standard axioms. The false-frame law uses
propext and Quot.sound. The other reports also use Classical.choice.
The reviewer read every report and checked payload metadata. Lean and
native execution were not rerun by this reviewer.

Root reports final installed default and strict passes, a full Audit pass
at 4758 jobs and 83054 dependency checks, and a public pass at 1223 checks
and 118 definition prints. Root reports 19 serial compiler commands:
15 passing and four retained repaired failures, with 52 snapshots. Root
reports all 556 old protected inputs and 835 native inputs exact, with
559 current protected files and 4758 Lean sources. These are Root reports.

Root reports the final full public output is 4905232 bytes with SHA-256
880a139e02bcad10fe1275f5927c2ff0565bd4f74f37038a28502df382b847ab.
Both the old 4895021-byte output and intermediate 4902860-byte output are
exact prefixes. Root retains the complete intermediate public-v2 output;
this review independently pins its size and hash as metadata. It retains
and reads the entire NEW 10211-byte final tail. The prior multi-megabyte
public body was not acquired here. root-reported-validation.json records
that authority boundary.
