# Actual dispatch and changed-filter slot transport

Retain the full original public-input and original-resource objective.
Prove sound outputs, the intended ordered finite prefix under configured order
and stops, both workers, optimized interned core, Prefix/table/count/checkpoint
and public adapters, plus Haskell correspondence. Retain older constructor,
equality, exact node-count, size-order and rank/unrank contracts.

This phase checks two observed-code bridges. Dispatch keeps native Stored in
all actual outcomes from current Ready/Realized/Fits/Room/entryStored facts.
The slot law follows actual read -> false check -> changed preparation ->
successful action, deriving Frame, Normal, allocated readback and Realized.
No future Trace, output invariant, completion producer, input Normal or
historical makeNode witness replaces the required actual equations.
Do not infer global worker history or original depth from either local law.
Root alone owns compiler/evaluator/native/Git/network/board/production and
packaging. Use unchanged serial4GiB/zero-swap/five-minute command limits.
Preserve all previous source, output, documents, drafts and failures.
No Haskell source change or new executable defect/fix is established.
The backend marker remains blocked despite user-resumed verified work.

Extend through actual Fold.run in all outcomes. Its existing current Seed,
Context, Realized, selected/target, Fits, Reserved and known-heap premises remain.
Only an actual singleton-success action enters the recursive branch. Existing
observed_singleton derives its next entry; no future Ranges/Stored supplier.
The intermediate two-source checks and complete public output remain.
