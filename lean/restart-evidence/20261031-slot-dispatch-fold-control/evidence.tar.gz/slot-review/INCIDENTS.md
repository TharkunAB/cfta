The first broad declaration locator returned more text than the tool output budget. Its complete stdout, stderr, per-source line copies, and exact source identities were retained. The retained Correctness locator was then read in two segments; the retained State, Frame, and PendingReplacement locators were read separately. No acquisition was lost.

The consumer filename-only search used a Python string with a literal backslash-dot escape. Python emitted SyntaxWarning: invalid escape sequence. The rg search completed with the intended literal-dot pattern and retained its complete stdout/stderr. This metadata warning did not execute Lean or Haskell.

A memory-registry search returned no matches with the normal rg exit code1. No memory-derived claim was used. No compiler, evaluator, or native execution was attempted.
