# OLD whole scope

Slot 1: SourcePruningEnumerationAction.lean. Named before acquisition at00:06 CET.
Slot 2: SourcePruningEnumerationIdentity.lean. Named before acquisition at00:15 CET.
No third whole or near-whole acquisition is authorized.
