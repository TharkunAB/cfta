# Scope

Source-only actual filter action and slot transport. Root owns compilation, evaluation, native execution, Git, network, board, production, and packaging. No spawning.

Own only this fresh directory. Keep prior bundles frozen.

Named OLD whole slot 1 before acquisition: SourcePruningEnumerationAction.lean. Slot 2 remains unused.

Retain actual prepare/action equations. Derive Normal internally. Do not assume a future Trace or omit intervening writes. Source resets and global capacity remain open.
