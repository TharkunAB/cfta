# Actual changed-filter slot transport

This source-only bundle proposes two UNCOMPILED laws. The second law connects the actual successful filter action to its actual representative slot. It derives the stored value's physical Normal internally. The owner ran no compiler or evaluator.

## Proposed result

Start with a Ready native heap, realized pending slots, and a total representative forest. Observe the actual pending `getValue` call, the actual false recursion check, the literal native lookup, the actual changed `prepare` result, and success of the actual returned action on that checked state.

The proposed law proves that the action writes the actual returned native value's encoded handle and the captured suspensions into the same allocated representative slot. The handle has exact native readback to that returned value. The value is Available, closed, ordinary, and physical Normal in the actual returned heap. The actual native heap relation is Keeps. The final enumeration state is PendingRealized in that heap. Every returned row satisfies the filter key. If the input value is ordinary, every complete returned root row belongs to the input root rows.

The caller supplies no Frame, Normal, input Available, input closedness, input encoding, historical constructor observation, future Trace, Complete predicate, or row-loss certificate. Input Available and closedness follow from the actual pending read and PendingRealized. The encoding follows from the literal successful lookup and coherence. Physical Normal follows from checked `prepare_changed_returned_control` for the actual preparation result.

This is a proposed statement. No checked slot-transport result is claimed in this bundle. Root owns probing and production integration.

## Literal caller and branch

The retained `SourcePruningEnumerationSelectedStep.runPrefix` source performs these operations:

1. Read the pending handle with `getValue`.
2. Run `SourcePruningEnumerationRecursion.checkRepeated` on the read state.
3. In the actual false branch, look up the old native value and evaluate `prepare`.
4. Run the returned action directly on the checked state.
5. Pass the observed state to the narrow adapter, then run Right recording if adaptation succeeds.

There is no enumeration-state writer between that false-check output and the action input in this code branch. The proposed law uses those exact state endpoints. It does not replace an arbitrary intervening writer with an assumed frame.

`SourcePruningEnumerationRecursion.checkRepeated` has one write branch: a recursive boundary whose key occurs in the current ancestry writes the same handle with an empty suspension list and returns true. Its false branches perform only representative compression or pure return. The first proposed law derives a complete Frame from the actual false observation. The true branch is not covered by that frame law. It is a separate parked-recursion control branch.

`prepare` returns rejection for Empty. The proof derives impossibility of that branch from the supplied actual action success. It does not assume nonempty output. Mu and known-type bypasses return the original value. The checked changed-prepare law excludes them internally from the different encodings.

In the changed nonempty branch, `prepare` reselects the representative and calls `setValue` with the captured new handle and suspension list. It does not inspect the current payload before that write. `setValue` uses `List.set` and has no explicit bounds failure. Thus arbitrary action success alone does not prove that the target was allocated or that the overwritten source is the old value.

The actual earlier read, actual false check, and actual second representative read solve both problems here. `representative_agrees` identifies the same root across their actual compression frames. The earlier stored slot then supplies its current payload and bounds. The action's actual success determines the exact final state update.

If another writer is inserted before this action, or if the representative classes change, this theorem cannot be applied with the same endpoints. The captured payload can then replace a different current payload unless another contract relates them. This is a precise scope boundary. No runtime counterexample or Haskell defect was established.

## Proof structure

`SourcePruningEnumerationRecursion.checkRepeated_false_frame` unfolds the actual function. A failed lookup cannot have a successful false observation. In the recursive-boundary case, the proof decomposes the actual representative and state reads. The write branch cannot return false. The remaining branch composes the representative frame with the pure-return frame.

`SourcePruningEnumerationAction.prepare_changed_success_stores_normal` derives the old native value gates from the observed pending slot and actual lookup. It applies checked actual-result control. It extracts the exact changed action from the observed preparation and decomposes the actual successful bind. It then derives the current old slot, its bound, the exact write, and the final stored handle.

The native readback follows from Available, closedness, coherence, and the actual new encoding. Existing realized-slot preservation and available-value write laws supply final PendingRealized. The internally constructed expected write is equated with the observed final state through the exact write equation. It is not a supplied future result.

The ordinary-input root-row subset follows from checked `narrowAt_ordinary_rows` applied to the actual filter observation obtained by changed preparation control. The theorem does not assert strict row loss without an old physical Normal premise. The existing chain laws handle that later numeric step.

## Remaining connections

This law ends at the actual action output. It does not yet transport the result through the narrow adapter, expandable-index updates, Right recording, incoming or dispatch intersections, or later Prepared Mu/Union reconstruction. Those operations can require separate slot or row-source arguments.

The same allocated slot need not be the literal queried UVar when the UVar is an alias. The theorem returns the actual representative root. The selected caller's stronger root-readiness facts can identify it with the selected UVar in a later wrapper.

This bundle does not construct the full observed ChangedFilters history for either worker. It does not count unchanged operations, bound source resets, derive a first carrier size from the original input, or prove the global original-depth bound. It does not establish recursive whole-execution completion, all earlier alternatives or staged children, coverage, public-adapter correctness, or Haskell correspondence. The full original-input, both-worker, public/Haskell objective remains open.

No Haskell source was changed. No Haskell defect, fix, or candidate was established.

## Sources and scope

OLD whole slot1 was named before acquisition: SourcePruningEnumerationAction.lean,150L, SHA e2f54fb2192c5c8e74e44a3dae620d7bcb448bd9c5096cb767271145f2086ba0.

OLD whole slot2 was named before acquisition: SourcePruningEnumerationIdentity.lean,58L. Its exact source hash is retained in acquisitions.json. Both full sources were read. No third whole or near-whole source was acquired. All other OLD body acquisitions are named bounded cuts or retained declaration locators. SOURCE-UNIONS.json records their cumulative line unions.

The parent explicitly authorized full reuse of the previous owned chain draft. Its exact V2 source, SHA5cb57a0928d2148a01eb4c9dbea64c5dfdd4fddb75a080957d3320f0433e93a0, is retained under the prior bundle manifest051866ad7d59a189abb08f4bea9ecf254d586c8df21018fadc21a3cd5883ed68. That retained copy remains UNCOMPILED and is not asserted to be byte-identical to published R7. The slot draft does not import it.

Bounded reuse of the checked ReturnedControl context and full actual changed-prepare header is tied to the same prior frozen manifest. Its complete source identity is0862dc8f457d8e46cd39f6f748dfd9a64a2e44fbd3a6d3489c8fc058f062838d. The initial partial context cut and the later complete header cut are both retained.

PUBLIC-CONTRACTS.md/json retain both complete new headers, imports, namespace context, local notation, variables, local instance definitions, and the local decidable-equality attribute. The immutable source draft retains all proofs. INCIDENTS.md records output truncation and one Python regex-string metadata warning. No acquisition data was lost.

No compiler, evaluator, native execution, Git operation, network request, board operation, production edit, or sub-agent was used by this owner. All prior bundles remain unchanged.
