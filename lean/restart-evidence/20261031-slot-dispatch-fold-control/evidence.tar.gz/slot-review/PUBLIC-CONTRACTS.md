# Proposed public contracts

UNCOMPILED source-only. The owner ran no compiler or evaluator.

```lean
import MicroCFTA.SourcePruningNarrowReturnedControl
import MicroCFTA.SourcePruningEnumerationRecursion
import MicroCFTA.EnumerationObservations

namespace MicroCFTA.SourcePruningEnumerationRecursion
open EnumerationState EnumerationCorrectness EnumerationCompressionFrame
local notation "Symbol" => SourcePruningTemplates.Symbol
variable {EnumGuard NativeGuard : Type}

local instance slotCheckMonadList : Monad List where
  pure value := [value]
  bind values continuation := values.flatMap continuation

theorem checkRepeated_false_frame
    (heap : InternedConstructorTemplates.State Symbol NativeGuard)
    (fuel uv handle : Nat) (scs : List Suspended)
    (before after : EnumerationState.State Symbol EnumGuard)
    (total : UnionFind.Total before.representatives)
    (observed : Success (checkRepeated heap fuel uv handle scs) before false after) :
    Frame before after
```

```lean
import MicroCFTA.SourcePruningNarrowReturnedControl
import MicroCFTA.SourcePruningEnumerationRecursion
import MicroCFTA.EnumerationObservations

namespace MicroCFTA.SourcePruningEnumerationAction
open EnumerationState EnumerationCorrectness EnumerationCompressionFrame EnumerationObservations
open InternedConstructorTemplates InternedProbeProvenance
open SourcePruningNativeView SourcePruningEnumerationNodes SourcePruningEnumerationObservation
local notation "Symbol" => SourcePruningTemplates.Symbol
attribute [local instance] FormulaExecutable.formulaDecidableEq
variable {EnumGuard NativeGuard Typing Key : Type}

local instance slotTransportMonadList : Monad List where
  pure value := [value]
  bind values continuation := values.flatMap continuation

theorem prepare_changed_success_stores_normal [DecidableEq (EdgeKey Symbol NativeGuard)]
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool)
    (admits : Key → Value Symbol NativeGuard → Bool) (metadata : SourcePruningRecordTypes.Metadata Typing)
    (readFuel checkFuel nativeFuel representativeFuel uv oldHandle newHandle : Nat)
    (scs : List Suspended) (value result : Value Symbol NativeGuard)
    (heap nextHeap : InternedConstructorTemplates.State Symbol NativeGuard)
    (before readAfter checked final : EnumerationState.State Symbol EnumGuard)
    (action : EnumerateM Symbol EnumGuard Unit)
    (ready : SourceEqualityRequiredCache.Ready heap) (realized : PendingRealized heap before)
    (total : UnionFind.Total before.representatives)
    (read : Success (getValue readFuel uv) before (.unenumerated (some oldHandle) scs) readAfter)
    (checkedFalse : Success (SourcePruningEnumerationRecursion.checkRepeated heap checkFuel uv oldHandle scs)
      readAfter false checked)
    (decoded : lookupNode heap oldHandle = some value)
    (prepared : prepare holeKey fits admits metadata nativeFuel representativeFuel uv oldHandle scs value heap =
      .done (result, some action) nextHeap)
    (newEncoded : encodeNode result = some newHandle) (changed : newHandle ≠ oldHandle)
    (succeeded : Success action checked () final) :
    SourceEqualityRequiredCache.Keeps heap nextHeap ∧
      Available nextHeap result ∧ result.free = [] ∧ SourceEqualityRequiredCache.Ordinary result ∧
      EqualityOrdinaryReadback.Normal nextHeap result ∧ lookupNode nextHeap newHandle = some result ∧
      (∀ edge ∈ nodeEdges result, keeps fits admits (holeKey metadata.typing uv) edge = true) ∧
      (SourceEqualityRequiredCache.Ordinary value → ∀ edge ∈ nodeEdges result, edge ∈ nodeEdges value) ∧
      PendingRealized nextHeap final ∧
      ∃ (root : Nat) (middle : EnumerationState.State Symbol EnumGuard),
        Success (representative representativeFuel uv) checked root middle ∧ Frame checked middle ∧
        middle.values[root]? = some (.unenumerated (some oldHandle) scs) ∧
        Success (setValue root (.unenumerated (some newHandle) scs)) middle () final ∧
        final = {middle with values := middle.values.set root (.unenumerated (some newHandle) scs)} ∧
        final.values[root]? = some (.unenumerated (some newHandle) scs)
```
