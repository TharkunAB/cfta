from pathlib import Path
import hashlib
import json
import sys

r = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/tmp/mcfta-slot-and-native-dispatch-control-20261031')
out = Path(sys.argv[2]) if len(sys.argv) > 2 else r
out.mkdir(exist_ok=True)
repo = Path('/home/tritlo/Code/mcfta')
rows = []
for name in ['NEXT-PROMPT.md', 'HANDOFF.md', 'FINDINGS.md']:
    data = (repo / name).read_bytes()
    prior = (r / 'prior-documents' / name).read_bytes()
    assert data.endswith(prior), name
    rows.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                 'prior_exact_suffix_bytes': len(prior)})
name = 'lean/notes-current-slot-and-native-dispatch.md'
data = (repo / name).read_bytes()
rows.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
expected = r / 'final-document-pins.json'
if expected.exists():
    assert json.loads(expected.read_text()) == rows
else:
    assert out == r
    expected.write_text(json.dumps(rows, indent=2) + '\n')
(out / 'document-verification.json').write_text(json.dumps({'all_current_pins': 'pass',
    'all_prior_root_document_suffixes': 'pass', 'documents': rows}, indent=2) + '\n')
print(json.dumps({'documents': len(rows), 'old_root_bodies_exact_suffixes': 3, 'current_pins': 'pass'}))
