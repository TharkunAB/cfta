# Native Stored through every actual fold outcome

Status: complete source-only V1 candidate. This worker ran no compiler,
evaluator or native execution. No new law is claimed checked here.

## Result

NativeStoredFold-v1-UNCOMPILED.lean has 87 lines and one public theorem,
fold_native_stored. Its conclusion concerns the actual Fold.run result's
.2.1.checked.native. It covers every native fuel n, p and h, both checkEmpty
modes, all recorded source lists and EVERY returned fold outcome.

Its current entry gates are exactly the assigned target:

- Seed and the original Formulas/Entailment/Inventory parameters.
- Current Context and PendingRealized.
- Pending target and selected PendingOrEliminated source slots.
- Current Fits seed.2 and Reserved bits seed sources.length.
- Known alphabet heap for seed.1.
- Separate native Stored at the current beforeCaller.checked.native.

There is no Ranges, future trace, per-step output Stored, successor
postcondition function, completion supplier or successful-fold result premise.
The complete public header is retained in PUBLIC-CONTRACT.md.

Candidate SHA-256:
8dfa9df7a905a8fc46d764d97dfca747018d8c899e798a17b5d40509567e09ff.

## Actual head producer

The proof inducts on the finite source list. On the empty list, Fold.run returns
the entry caller.

On source :: rest, the proof cases the ACTUAL Dispatch.dispatch observation.
Before it splits any result, it applies the checked dispatch_native_stored law.
Context.ready supplies the current Ready premise. Current PendingRealized and
Fits are unchanged. The current reservation's head supplies Room. Rewriting
with the actual dispatch equation gives native Stored at reachedCaller.

This head certificate is therefore available for error observations as well
as successful observations. No successful-only receipt is used to cover an
unobserved error branch.

## Every nonrecursive fold result

The literal fold returns reachedCaller without recursion in each of these cases:

- Dispatch returns an error.
- Dispatch returns .ok none.
- The returned action produces an empty list.
- Its first row is an error.
- Its first row succeeds but has at least one following row.

Each branch simplifies the exact Fold.run definition with the actual dispatch
and action equations. The head's reachedStored certificate supplies the
conclusion at that same checked native state. The enumeration action has no
Caller argument or Caller result. Its returned list does not alter the reached
checked caller.

## The only recursive branch

The recursive branch has an ACTUAL returned action observation:

```lean
ExceptT.run (action before) = [.ok ((), middle)]
```

The proof does not assume this equation at entry. It obtains the equation by
casing the literal action list, its first Except result, Unit, and list tail.
Only the singleton-success branch can recurse.

The existing Fold.observed_singleton producer consumes this actual dispatch
equation and actual action equation. It derives next Inventory, final Memos,
post Context, exact final.query relation, PendingRealized, pending target,
remaining-source selection, Fits for step seed, and the step-seed known heap.
The candidate supplies no such postcondition as a hypothesis.

The reservation's tail supplies Reserved at the actual successor seed. The
query relation rewrites the actual saved query memo to final.query. The
induction hypothesis then uses the DERIVED reachedStored together with these
DERIVED successor entry facts. The native certificate is not obtained from
post.context.stored, whose stored field concerns the separate merge memo.

This structure follows the existing actual-outcome FoldResources proof pattern.
The new proof handles errors and all non-singleton action observations too.

## Exact checked input and source scope

Root supplied and authorized complete reuse of the installed new dispatch law:
SourceCurrentAllocatedNativeStoredDispatch.lean, 151 lines, SHA-256
01499c214a1a0ddf5f995ed347ae22505be36f0ec8e6ddc0c3f7462012667878.
Root reported lake and strict checks passed. This worker verified the complete
copied source hash. It did not run or acquire Root's raw check logs.

Two OLD whole modules were named before acquisition:

1. SourcePruningEnumerationFoldAdmission.lean, 133 lines. It defines the exact
   observed_singleton producer and reservation induction.
2. SourcePruningEnumerationFoldResources.lean, 114 lines. Its proof supplies the
   exact existing list/outcome case and successor-transport pattern.

The only other old source acquisition is Fold.run lines 1-42 of 353.
No third whole or near-whole module was acquired. No Terminal source was read
or Terminal law attempted.

acquisitions.json records every complete source hash, byte/line count, exact
acquired lines, retained copy and copy hash. CUMULATIVE-SOURCE-UNIONS.json
records all source unions. The single complete V1 candidate is retained
immutable. No command failed or output was truncated.

## Boundaries

Native Stored retains its existing conditional structural meaning for returned
native cells. This result does not establish a finite ordinary certificate for
every recursive request or result. Context.stored remains the separate
merge-memo invariant. Native Stored remains an explicit maintained entry
property.

The law consumes the current original reservation and validated slot/context
facts. It does not establish their existence from the initial original input.
Sufficient original depth, original-input capacity, source reset, unchanged
steps, Terminal transport, whole-worker induction, finite global enumeration,
public API correspondence and Haskell correspondence remain outside this law.

No Haskell source changed. No admitted actual Haskell execution occurred. No
Haskell defect or fix was established. There is no new Haskell FINDINGS entry.

All writes stayed in /tmp/mcfta-native-fold-stored-review-20261031. Prior bundles
remain frozen. There was no compiler, evaluator, native execution, Git, network,
board, production write, packaging operation or spawned worker. Root alone
owns execution and checking.
