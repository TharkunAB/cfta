# Scope

Root assigned this fresh source-only task at 2026-10-31 00:36 CET.
Prove exact all-outcome fold_native_stored from current Seed/Context/Realized/targetPending/selected/Fits/Reserved/known/entry native Stored. Use checked dispatch_native_stored and actual observed_singleton successor transport. No future Ranges, per-step output Stored, postcondition supplier or future Trace. No Terminal theorem.

Root owns compiler, evaluator, native execution, Git, network, board, production and packaging. No spawning. All writes stay here. Prior bundles remain frozen. Max two OLD whole/near-whole modules, named before acquisition. Other reads use exact bounded cuts and source metadata/unions. Explicit NEW whole reuse: installed NativeStoredDispatch151L.
