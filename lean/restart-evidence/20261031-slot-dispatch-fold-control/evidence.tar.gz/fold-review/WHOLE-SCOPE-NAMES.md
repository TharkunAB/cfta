# Named OLD whole modules

1. `lean/MicroCFTA/SourcePruningEnumerationFoldAdmission.lean` (133 lines). Named before acquisition. It defines the actual singleton-success transport and current reservation induction.
2. `lean/MicroCFTA/SourcePruningEnumerationFoldResources.lean` (114 lines). Named before acquisition. Its proof gives the exact existing actual-outcome fold case and successor-transport pattern.
