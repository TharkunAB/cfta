from pathlib import Path
import hashlib, json, sys

original = Path('/tmp/mcfta-slot-and-native-dispatch-control-20261031')
r = Path(sys.argv[1]) if len(sys.argv) > 1 else original
out = Path(sys.argv[2]) if len(sys.argv) > 2 else r
out.mkdir(exist_ok=True)
repo = Path('/home/tritlo/Code/mcfta')
def sha(data): return hashlib.sha256(data).hexdigest()

def owner(name, manifest_name, manifest_hash, pins_name, pins_hash):
    base = r / name
    assert sha((base / manifest_name).read_bytes()) == manifest_hash
    assert sha((base / pins_name).read_bytes()) == pins_hash
    actual = {str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    if manifest_name.endswith('.json'):
        rows = json.loads((base / manifest_name).read_text())['files']
        expected = {row['path'] for row in rows}
        for row in rows:
            data = (base / row['path']).read_bytes()
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
        pins = json.loads((base / pins_name).read_text())['pins']
        for leaf, digest in pins.items(): assert sha((base / leaf).read_bytes()) == digest
    else:
        rows = [line.split('  ', 1) for line in (base / manifest_name).read_text().splitlines()]
        expected = {leaf for _, leaf in rows}
        assert len(expected) == len(rows)
        for digest, leaf in rows: assert sha((base / leaf).read_bytes()) == digest
        pins = json.loads((base / pins_name).read_text())
        assert pins['payload_files'] == len(rows)
        for leaf, record in pins['artifacts'].items():
            data = (base / leaf).read_bytes()
            assert sha(data) == record['sha256'] and len(data) == record['bytes']
            assert len(data.splitlines()) == record['lines']
    assert actual == expected | {manifest_name, pins_name}
    for p in base.rglob('*'):
        if p.is_file(): assert not p.is_symlink() and not (p.stat().st_mode & 0o222)
    return base, {'payloads': len(rows), 'regular_files': len(actual), 'readonly': True}

owners=json.loads((r/'owners.json').read_text())
results={}
for row in owners:
    base,result=owner(row['name'],row['manifest'],row['manifest_sha256'],row['pins'],row['pins_sha256'])
    results[row['name']]=result

def source_path(value):
    p=Path(value)
    if p.is_relative_to(original):return r/p.relative_to(original)
    for row in owners:
        previous=Path(row['original'])
        if p.is_relative_to(previous):return r/row['name']/p.relative_to(previous)
    assert p.is_relative_to(repo),p
    return p

counts={}
for row in owners:
    base=r/row['name'];count=0
    for leaf in ['acquisitions.json','reuse-ledger.json','old-source-cut-ledger.json','old-source-locator-ledger.json']:
        ledger=base/leaf
        if not ledger.exists():continue
        for record in json.loads(ledger.read_text()):
            data=source_path(record.get('source_path',record.get('source'))).read_bytes()
            assert sha(data)==record['source_sha256'],(row['name'],leaf,record)
            assert len(data)==record['source_bytes'] and len(data.splitlines())==record['source_lines']
            if 'actual_lines' in record:
                expected=b''.join(data.splitlines(keepends=True)[i-1] for i in record['actual_lines'])
            else:
                lo,hi=record['actual'];expected=b''.join(data.splitlines(keepends=True)[lo-1:hi])
            copied=(base/record['copy']).read_bytes()
            assert copied==expected and sha(copied)==record['copy_sha256'],(base,record)
            count+=1
    counts[row['name']]=count
result={'status':'pass','owners':results,'exact_source_records':counts,
        'root_complete_source_lines':413,'root_complete_public_lines':137,
        'public_contracts':'all four source/public contracts match; nodeEdges resolves to its intended canonical constant',
        'future_contracts':'63L adapter draft retained UNCOMPILED; Terminal and actual prefix-observation extraction are next'}
(out/'owned-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
