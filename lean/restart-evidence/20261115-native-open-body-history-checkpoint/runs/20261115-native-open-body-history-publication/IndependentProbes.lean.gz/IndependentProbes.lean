import MicroCFTA.SourceCurrentAllocatedNativeRawOpenBodyProductReplay
import MicroCFTA.SourceCurrentAllocatedNativeOpenBodyQueryGlobalLaws
import MicroCFTA.SourceCurrentAllocatedNativeSourceDiagonalFirstActualMuBody
import MicroCFTA.SourceCurrentAllocatedNativeOpenBodyRightMuQueryGlobalLaws
import MicroCFTA.SourceCurrentAllocatedNativeRawReferencePredicateReplay
import MicroCFTA.SourceCurrentAllocatedNativeSourceDiagonalKeyReferenceRead

#check @MicroCFTA.SourceCurrentAllocatedNativeRawOpenBodyProductReplay.open_body_product_trace_result
#print axioms MicroCFTA.SourceCurrentAllocatedNativeRawOpenBodyProductReplay.open_body_product_trace_result
#check @MicroCFTA.SourceCurrentAllocatedNativeOpenBodyQueryGlobalLaws.query_returned_and_raw_results
#print axioms MicroCFTA.SourceCurrentAllocatedNativeOpenBodyQueryGlobalLaws.query_returned_and_raw_results
#check @MicroCFTA.SourceCurrentAllocatedNativeOpenBodyQueryGlobalLaws.initial_node_query_returned_and_raw_results
#print axioms MicroCFTA.SourceCurrentAllocatedNativeOpenBodyQueryGlobalLaws.initial_node_query_returned_and_raw_results
#check @MicroCFTA.SourceCurrentAllocatedNativeOpenBodyQueryGlobalLaws.initial_edge_query_returned_and_raw_results
#print axioms MicroCFTA.SourceCurrentAllocatedNativeOpenBodyQueryGlobalLaws.initial_edge_query_returned_and_raw_results
#check @MicroCFTA.SourceCurrentAllocatedNativeSourceDiagonalFirstActualMuBody.current_stored_universe_diagonal_first_actual_mu_body
#print axioms MicroCFTA.SourceCurrentAllocatedNativeSourceDiagonalFirstActualMuBody.current_stored_universe_diagonal_first_actual_mu_body
#check @MicroCFTA.SourceCurrentAllocatedNativeOpenBodyRightMuQueryGlobalLaws.query_returned_and_raw_results
#print axioms MicroCFTA.SourceCurrentAllocatedNativeOpenBodyRightMuQueryGlobalLaws.query_returned_and_raw_results
#check @MicroCFTA.SourceCurrentAllocatedNativeOpenBodyRightMuQueryGlobalLaws.initial_node_query_returned_and_raw_results
#print axioms MicroCFTA.SourceCurrentAllocatedNativeOpenBodyRightMuQueryGlobalLaws.initial_node_query_returned_and_raw_results
#check @MicroCFTA.SourceCurrentAllocatedNativeOpenBodyRightMuQueryGlobalLaws.initial_edge_query_returned_and_raw_results
#print axioms MicroCFTA.SourceCurrentAllocatedNativeOpenBodyRightMuQueryGlobalLaws.initial_edge_query_returned_and_raw_results
#check @MicroCFTA.SourceCurrentAllocatedNativeRawReferencePredicateReplay.reference_trace_predicate_of_actual_read
#print axioms MicroCFTA.SourceCurrentAllocatedNativeRawReferencePredicateReplay.reference_trace_predicate_of_actual_read
#check @MicroCFTA.SourceCurrentAllocatedNativeSourceDiagonalKeyReferenceRead.current_stored_universe_diagonal_first_body_reference_read_at_same_key
#print axioms MicroCFTA.SourceCurrentAllocatedNativeSourceDiagonalKeyReferenceRead.current_stored_universe_diagonal_first_body_reference_read_at_same_key


/-!
# Initialized open body history from the original diagonal source

Original source facts supply the current-handle compiler and ordered inputs.
The same original body equations align all source witnesses.
Both complete memo laws retain the original machine, plans, and fuel.
Every bounded raw return has the exact open original-body product shape.
-/
namespace MicroCFTA.SourceCurrentAllocatedNativeDiagonalOpenBodyHistoryIntegrationProbe
open Cache Language InternedConstructorTemplates InternedNestedFacts InternedProbeProvenance
open InternedBinderProtocol (NodeKey Reference)
open SourceRecursiveIntersectionControl SourceRecursiveIntersectionDomain
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceSynthesisTypeSyntax (Library Query)
open SourceSynthesisFirstOrderConstruction (Expression)
open InternedStoredSubstitution (input)
open InternedStoredSubstitutionRebind (replacement)
open SourceEqualityNativeDemand
open SourceCurrentAllocatedNativeContextCache (Returned)
open SourceCurrentAllocatedNativePhysicalExecution (InputsThrough)
open SourceEqualityNativeDemandOperations (FieldsThrough)
open SourceCurrentAllocatedNativeOpenBodyQueryGlobalLaws (NodeResult ProductShape)
open SourceCurrentAllocatedNativeTopRowQueryGlobalLaws (KnownResult EdgeResult)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "ordinarySymbols" => SourceSynthesisUniverseCallerBoundary.ordinarySymbols

set_option autoImplicit false

set_option maxHeartbeats 1000000 in
/-- The complete original source supplies initialized open-body history at every actual terminal-key handle. -/
theorem current_stored_universe_diagonal_open_body_results
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
    (lib : Library) (query : Query) (signed : Int) (whole : Expression)
    (accepted : SourceSynthesisCurrentConstruction.firstOrderRaw lib query signed = .ok whole)
    (rootValue : Value Symbol Guard) (sourceHeap : InternedConstructorTemplates.State Symbol Guard)
    (built : InternedFreshOrdinaryConstruction.build (ordinarySymbols whole) [] empty =
      .done rootValue sourceHeap)
    (key : NodeKey) (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard)
    (stored : sourceHeap.nodeRecords key = some (.mu entry body depth ordinary))
    (machine : SourceRecursiveIntersectionKernel.Machine Symbol Guard)
    (machineValid : SourceRecursiveIntersectionKernel.Valid machine)
    (facts : Facts machine.heap) (growth : Grows sourceHeap machine.heap)
    (domains : Cache.State IntersectionFlatMemoKeyDomain.DomainKey) (cacheValid : Cache.Valid domains)
    (pattern : Value Symbol Guard) (_patternAvailable : Available machine.heap pattern)
    (_patternClosed : pattern.free = []) (patternId : Nat)
    (_patternIdentity : identity pattern = some patternId)
    (_patternKind : tag pattern = 1 ∨ tag pattern = 3) :
    ∃ (bodyEntry : Interned NodeKey) (bodyRows : List (EdgeValue Symbol Guard)),
      body = .node bodyEntry bodyRows 0 [.interned entry.identity] ∧
      let universeValue : Value Symbol Guard := .mu entry body depth ordinary
      let referenceValue : Value Symbol Guard := .reference (.interned entry.identity)
      let original := SourceRecursiveIntersectionEnvironment.enter domains IntersectionEmptyDomain.emptyKey
        universeValue pattern entry.identity patternId
      let diagonalFirst := SourceRecursiveIntersectionEnvironment.enter original.2 original.1.key
        universeValue referenceValue entry.identity entry.identity
      let diagonalTerminal := SourceRecursiveIntersectionEnvironment.enter diagonalFirst.2 diagonalFirst.1.key
        body universeValue bodyEntry.identity entry.identity
      ∀ (actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey),
      actualDomain.key = diagonalTerminal.1.key →
      ∀ (operations : SourceEqualityConstraintMemoAllocation.State)
        (_operationsValid : SourceEqualityConstraintMemoAllocation.Valid operations) (fuel : Nat),
      let start : SourceEqualityNativeDemand.State width :=
        ⟨SourceRecursiveIntersectionThunks.initial width machine, operations⟩
      InputsThrough fuel (.code (.node ⟨actualDomain, body, body⟩ .pure)) start →
      FieldsThrough fuel (.code (.node ⟨actualDomain, body, body⟩ .pure)) start →
      Returned (NodeResult entry.identity entry.identity entry.identity diagonalTerminal.1.key body)
        (execute fuel (.code (.node ⟨actualDomain, body, body⟩ .pure)) start).state.native.nodes ∧
      Returned EdgeResult
        (execute fuel (.code (.node ⟨actualDomain, body, body⟩ .pure)) start).state.native.edges ∧
      ∀ (count : Nat) (result : Value Symbol Guard) (after : SourceEqualityNativeDemand.State width),
        count ≤ fuel →
        Steps count (.code (.node ⟨actualDomain, body, body⟩ .pure)) start (.code (.pure result)) after →
        ProductShape entry.identity entry.identity entry.identity body result := by
  obtain ⟨bodyEntry, bodyRows, bodyShape, _bodyApart, sourceFacts⟩ :=
    SourceCurrentAllocatedNativeSourceDiagonalFirstActualMuBody.current_stored_universe_diagonal_first_actual_mu_body
      (width := width) lib query signed whole accepted rootValue sourceHeap built key entry body depth ordinary
      stored machine.heap facts growth domains cacheValid pattern _patternAvailable _patternClosed
      patternId _patternIdentity _patternKind
  obtain ⟨inputEntry, inputRows, inputShape, rowInputs⟩ :=
    SourceCurrentAllocatedNativeSourceDiagonalKeyRowInputs.current_stored_universe_diagonal_shortcut_inputs_at_same_key
      (width := width) lib query signed whole accepted rootValue sourceHeap built key entry body depth ordinary
      stored machine.heap facts growth domains cacheValid pattern _patternAvailable _patternClosed
      patternId _patternIdentity _patternKind
  have sameInputEntry : inputEntry = bodyEntry := (Value.node.inj (inputShape.symm.trans bodyShape)).1
  have sameInputRows : inputRows = bodyRows := (Value.node.inj (inputShape.symm.trans bodyShape)).2.1
  subst inputEntry
  subst inputRows
  let universeValue : Value Symbol Guard := .mu entry body depth ordinary
  let referenceValue : Value Symbol Guard := .reference (.interned entry.identity)
  let original := SourceRecursiveIntersectionEnvironment.enter domains IntersectionEmptyDomain.emptyKey
    universeValue pattern entry.identity patternId
  let diagonalFirst := SourceRecursiveIntersectionEnvironment.enter original.2 original.1.key
    universeValue referenceValue entry.identity entry.identity
  let diagonalTerminal := SourceRecursiveIntersectionEnvironment.enter diagonalFirst.2 diagonalFirst.1.key
    body universeValue bodyEntry.identity entry.identity
  dsimp only at sourceFacts rowInputs
  obtain ⟨_bodyIdentity, _universeIdentity, _bodyOpen, _cutoffApart, _incomingFacts, terminalFacts⟩ :=
    sourceFacts
  have compiler : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = diagonalTerminal.1.key →
      compileNode ⟨actualDomain, body, body⟩ =
        compileRows actualDomain (InternedEdgeResidency.nodeEdges body) (InternedEdgeResidency.nodeEdges body) := by
    intro actualDomain sameKey
    exact (terminalFacts actualDomain sameKey).2.2
  have sourceRows : InternedEdgeResidency.nodeEdges body = bodyRows := by
    rw [bodyShape]
    rfl
  have orderedInputs : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = diagonalTerminal.1.key → ∀ row ∈ InternedEdgeResidency.nodeEdges body,
      All₂ (fun (children : Value Symbol Guard × Value Symbol Guard) (value : Value Symbol Guard) =>
        KnownResult ⟨actualDomain, children.1, children.2⟩ value)
        (row.children.zip row.children)
        (row.children.map (input (replacement (.interned entry.identity)
          (repeatedValue (pair entry.identity entry.identity))))) := by
    intro actualDomain sameKey row member
    exact rowInputs actualDomain sameKey row (by rw [← sourceRows]; exact member)
  refine ⟨bodyEntry, bodyRows, bodyShape, ?_⟩
  dsimp only
  intro actualDomain sameKey operations operationsValid fuel plan fields
  have completed := SourceCurrentAllocatedNativeOpenBodyQueryGlobalLaws.initial_node_query_returned_and_raw_results
    (width := width) lib query signed whole accepted rootValue sourceHeap built key entry body depth ordinary stored
    diagonalTerminal.1.key entry.identity entry.identity compiler orderedInputs
    machine machineValid growth operations operationsValid fuel ⟨actualDomain, body, body⟩ plan fields
  refine ⟨completed.1.1, completed.1.2, ?_⟩
  intro count result after bounded actual
  exact (completed.2 count result after bounded actual).2 sameKey rfl rfl

end MicroCFTA.SourceCurrentAllocatedNativeDiagonalOpenBodyHistoryIntegrationProbe

import MicroCFTA.SourceOpenBodyHistoryIntegration

#check @MicroCFTA.SourceCurrentAllocatedNativeDiagonalOpenBodyHistoryIntegrationProbe.current_stored_universe_diagonal_open_body_results
#print axioms MicroCFTA.SourceCurrentAllocatedNativeDiagonalOpenBodyHistoryIntegrationProbe.current_stored_universe_diagonal_open_body_results



/-!
# Initialized right-Mu body history from the original diagonal source

Original source facts supply the current-cache Mu entry and ordered inputs.
The same original body equations align all source witnesses.
Both complete memo laws retain the original machine, plans, and fuel.
Every bounded B/U raw return has the exact open original-body product shape.
-/
namespace MicroCFTA.SourceCurrentAllocatedNativeDiagonalOpenBodyMuIntegrationProbe
open Cache Language InternedConstructorTemplates InternedNestedFacts InternedProbeProvenance
open InternedBinderProtocol (NodeKey Reference)
open SourceRecursiveIntersectionControl SourceRecursiveIntersectionDomain
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceSynthesisTypeSyntax (Library Query)
open SourceSynthesisFirstOrderConstruction (Expression)
open InternedStoredSubstitution (input)
open InternedStoredSubstitutionRebind (replacement)
open SourceEqualityNativeDemand
open SourceCurrentAllocatedNativeContextCache (Returned)
open SourceCurrentAllocatedNativePhysicalExecution (InputsThrough)
open SourceEqualityNativeDemandOperations (FieldsThrough)
open SourceCurrentAllocatedNativeOpenBodyRightMuQueryGlobalLaws (NodeResult)
open SourceCurrentAllocatedNativeOpenBodyQueryGlobalLaws (ProductShape)
open SourceCurrentAllocatedNativeTopRowQueryGlobalLaws (KnownResult EdgeResult)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "ordinarySymbols" => SourceSynthesisUniverseCallerBoundary.ordinarySymbols

set_option autoImplicit false

set_option maxHeartbeats 1000000 in
/-- The complete original source supplies initialized right-Mu product history at every actual first-key handle. -/
theorem current_stored_universe_diagonal_open_body_mu_results
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
    (lib : Library) (query : Query) (signed : Int) (whole : Expression)
    (accepted : SourceSynthesisCurrentConstruction.firstOrderRaw lib query signed = .ok whole)
    (rootValue : Value Symbol Guard) (sourceHeap : InternedConstructorTemplates.State Symbol Guard)
    (built : InternedFreshOrdinaryConstruction.build (ordinarySymbols whole) [] empty =
      .done rootValue sourceHeap)
    (key : NodeKey) (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard)
    (stored : sourceHeap.nodeRecords key = some (.mu entry body depth ordinary))
    (machine : SourceRecursiveIntersectionKernel.Machine Symbol Guard)
    (machineValid : SourceRecursiveIntersectionKernel.Valid machine)
    (facts : Facts machine.heap) (growth : Grows sourceHeap machine.heap)
    (domains : Cache.State IntersectionFlatMemoKeyDomain.DomainKey) (cacheValid : Cache.Valid domains)
    (pattern : Value Symbol Guard) (_patternAvailable : Available machine.heap pattern)
    (_patternClosed : pattern.free = []) (patternId : Nat)
    (_patternIdentity : identity pattern = some patternId)
    (_patternKind : tag pattern = 1 ∨ tag pattern = 3) :
    ∃ (bodyEntry : Interned NodeKey) (bodyRows : List (EdgeValue Symbol Guard)),
      body = .node bodyEntry bodyRows 0 [.interned entry.identity] ∧
      let universeValue : Value Symbol Guard := .mu entry body depth ordinary
      let referenceValue : Value Symbol Guard := .reference (.interned entry.identity)
      let original := SourceRecursiveIntersectionEnvironment.enter domains IntersectionEmptyDomain.emptyKey
        universeValue pattern entry.identity patternId
      let diagonalFirst := SourceRecursiveIntersectionEnvironment.enter original.2 original.1.key
        universeValue referenceValue entry.identity entry.identity
      let diagonalTerminal := SourceRecursiveIntersectionEnvironment.enter diagonalFirst.2 diagonalFirst.1.key
        body universeValue bodyEntry.identity entry.identity
      ∀ (actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey),
      actualDomain.key = diagonalFirst.1.key →
      ∀ (operations : SourceEqualityConstraintMemoAllocation.State)
        (_operationsValid : SourceEqualityConstraintMemoAllocation.Valid operations) (fuel : Nat),
      let start : SourceEqualityNativeDemand.State width :=
        ⟨SourceRecursiveIntersectionThunks.initial width machine, operations⟩
      InputsThrough fuel (.code (.node ⟨actualDomain, body, universeValue⟩ .pure)) start →
      FieldsThrough fuel (.code (.node ⟨actualDomain, body, universeValue⟩ .pure)) start →
      Returned (NodeResult entry.identity entry.identity entry.identity diagonalTerminal.1.key
        diagonalFirst.1.key body universeValue)
        (execute fuel (.code (.node ⟨actualDomain, body, universeValue⟩ .pure)) start).state.native.nodes ∧
      Returned EdgeResult
        (execute fuel (.code (.node ⟨actualDomain, body, universeValue⟩ .pure)) start).state.native.edges ∧
      ∀ (count : Nat) (result : Value Symbol Guard) (after : SourceEqualityNativeDemand.State width),
        count ≤ fuel →
        Steps count (.code (.node ⟨actualDomain, body, universeValue⟩ .pure)) start (.code (.pure result)) after →
        ProductShape entry.identity entry.identity entry.identity body result := by
  obtain ⟨bodyEntry, bodyRows, bodyShape, _bodyApart, sourceFacts⟩ :=
    SourceCurrentAllocatedNativeSourceDiagonalFirstActualMuBody.current_stored_universe_diagonal_first_actual_mu_body
      (width := width) lib query signed whole accepted rootValue sourceHeap built key entry body depth ordinary
      stored machine.heap facts growth domains cacheValid pattern _patternAvailable _patternClosed
      patternId _patternIdentity _patternKind
  obtain ⟨inputEntry, inputRows, inputShape, rowInputs⟩ :=
    SourceCurrentAllocatedNativeSourceDiagonalKeyRowInputs.current_stored_universe_diagonal_shortcut_inputs_at_same_key
      (width := width) lib query signed whole accepted rootValue sourceHeap built key entry body depth ordinary
      stored machine.heap facts growth domains cacheValid pattern _patternAvailable _patternClosed
      patternId _patternIdentity _patternKind
  have sameInputEntry : inputEntry = bodyEntry := (Value.node.inj (inputShape.symm.trans bodyShape)).1
  have sameInputRows : inputRows = bodyRows := (Value.node.inj (inputShape.symm.trans bodyShape)).2.1
  subst inputEntry
  subst inputRows
  let universeValue : Value Symbol Guard := .mu entry body depth ordinary
  let referenceValue : Value Symbol Guard := .reference (.interned entry.identity)
  let original := SourceRecursiveIntersectionEnvironment.enter domains IntersectionEmptyDomain.emptyKey
    universeValue pattern entry.identity patternId
  let diagonalFirst := SourceRecursiveIntersectionEnvironment.enter original.2 original.1.key
    universeValue referenceValue entry.identity entry.identity
  let diagonalTerminal := SourceRecursiveIntersectionEnvironment.enter diagonalFirst.2 diagonalFirst.1.key
    body universeValue bodyEntry.identity entry.identity
  dsimp only at sourceFacts rowInputs
  obtain ⟨bodyIdentity, _universeIdentity, _bodyOpen, cutoffApart, incomingFacts, terminalFacts⟩ :=
    sourceFacts
  have compiler : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = diagonalTerminal.1.key →
      compileNode ⟨actualDomain, body, body⟩ =
        compileRows actualDomain (InternedEdgeResidency.nodeEdges body) (InternedEdgeResidency.nodeEdges body) := by
    intro actualDomain sameKey
    exact (terminalFacts actualDomain sameKey).2.2
  have sourceRows : InternedEdgeResidency.nodeEdges body = bodyRows := by
    rw [bodyShape]
    rfl
  have orderedInputs : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = diagonalTerminal.1.key → ∀ row ∈ InternedEdgeResidency.nodeEdges body,
      All₂ (fun (children : Value Symbol Guard × Value Symbol Guard) (value : Value Symbol Guard) =>
        KnownResult ⟨actualDomain, children.1, children.2⟩ value)
        (row.children.zip row.children)
        (row.children.map (input (replacement (.interned entry.identity)
          (repeatedValue (pair entry.identity entry.identity))))) := by
    intro actualDomain sameKey row member
    exact rowInputs actualDomain sameKey row (by rw [← sourceRows]; exact member)
  have rightMu : ∀ actualIncoming : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualIncoming.key = diagonalFirst.1.key →
      decision actualIncoming.key body universeValue = .rightMu := by
    intro actualIncoming sameKey
    exact (incomingFacts actualIncoming sameKey).1
  have enteredKey : ∀ actualIncoming : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualIncoming.key = diagonalFirst.1.key →
      ∀ current : Cache.State IntersectionFlatMemoKeyDomain.DomainKey, Cache.Valid current →
      (SourceRecursiveIntersectionEnvironment.enter current actualIncoming.key body universeValue
        bodyEntry.identity entry.identity).1.key = diagonalTerminal.1.key := by
    intro actualIncoming sameKey current currentValid
    exact (incomingFacts actualIncoming sameKey).2.2 current currentValid
  have pairedApart : pair bodyEntry.identity entry.identity ≠ pair entry.identity entry.identity :=
    fun same => cutoffApart same.symm
  refine ⟨bodyEntry, bodyRows, bodyShape, ?_⟩
  dsimp only
  intro actualDomain sameKey operations operationsValid fuel plan fields
  have completed := SourceCurrentAllocatedNativeOpenBodyRightMuQueryGlobalLaws.initial_node_query_returned_and_raw_results
    (width := width) lib query signed whole accepted rootValue sourceHeap built key entry body depth ordinary stored
    diagonalTerminal.1.key entry.identity entry.identity compiler orderedInputs
    diagonalFirst.1.key bodyEntry.identity rightMu bodyIdentity enteredKey pairedApart
    machine machineValid growth operations operationsValid fuel ⟨actualDomain, body, universeValue⟩ plan fields
  refine ⟨completed.1.1, completed.1.2, ?_⟩
  intro count result after bounded actual
  exact (completed.2 count result after bounded actual).2 sameKey rfl rfl

end MicroCFTA.SourceCurrentAllocatedNativeDiagonalOpenBodyMuIntegrationProbe

#check @MicroCFTA.SourceCurrentAllocatedNativeDiagonalOpenBodyMuIntegrationProbe.current_stored_universe_diagonal_open_body_mu_results
#print axioms MicroCFTA.SourceCurrentAllocatedNativeDiagonalOpenBodyMuIntegrationProbe.current_stored_universe_diagonal_open_body_mu_results
