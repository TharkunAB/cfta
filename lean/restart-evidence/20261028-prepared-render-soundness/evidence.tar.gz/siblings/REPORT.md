# Prepared finite sibling arity candidates

Candidate-v1 adds two modules. The owner did not run a compiler. Root owns compilation and repository changes.

## Public interfaces

`SourcePruningEnumerationPreparedFiniteSiblingResourcesArity` exports `PreparedFiniteSiblingResources.alternatives_finite_complete_resources_arity`. The explicit arguments keep the order of the actual prepared sibling producer. The smaller-depth contract is `PreparedRecursive.CompleteWithArity`. The final input is the initial `ArityOrigins.Heap`, after `ScanReserved`. The result keeps all prior fields and appends the reached caller Heap and the Heap of every actual output caller.

`SourcePruningEnumerationPreparedFiniteSiblingFinishResourcesArity` exports `alternatives_finite_finish_resources_arity` in the same namespace. It keeps all prior fields, including the old finished `OutcomeResources`. It then appends the reached caller Heap, every output Heap and `PreparedRecursive.OutcomeResourcesWithArity` for that exact finished result.

## Proof route

The nil scan keeps the input caller Heap. Each native head uses the actual prepared finite-head arity producer. An unsupported head retains its reached caller Heap and emits no output. A handled complete callback yields aggregate Heap at its actual caller. The caller equality in the strengthened callback certificate identifies that caller. The suffix receives this Heap even when the callback emits no outputs. The prefix and suffix output lists retain their own individual Heaps. A stopped callback supplies its existing endpoint relation and all its own output Heaps.

The suffix transports the separate prepared parent availability through `hookPost.effects.keeps.available`. It does not infer new Heap arity from Post. The original source handle remains separate from the prepared parent. The finish wrapper pads only the existing resource bounds. It packages Heap certificates already derived by the actual sibling producer.

## Original gates and scope

Both producers retain the original Packet, full memos, captured cache, Ready, original stored source handle, separate prepared parent availability and closedness, chosen-edge membership, IncomingAvoid, Fits, known guard Heap, global selectionMembers and selectionLength, mass ceiling, inherited length and prepared ScanReserved. Only input arity and the strengthened smaller-depth induction contract are added. There is no endpoint Heap, later successful result or semantic model premise.

The aggregate conclusion is about the returned caller witness. A complete result identifies that caller exactly. A stopped result retains the original relation: its endpoint is absent or equals the caller and final query. The statement does not identify an unexposed failure endpoint when that endpoint is absent. Per-output conclusions use each output caller. This bounded pair does not alone close the whole prepared-driver arity induction.

## Source verification

The entire previous prepared public statement is unchanged in each candidate after removal of only the declared arity additions, with whitespace ignored. All eight predecessor sources and all five new peer interface/proof sources were read whole. Copies, byte lengths and SHA256 identities are in `source-identities.json`. Candidate identities and static checks are in `validation.json`.

No Haskell change or defect claim is part of these candidates. No compiler, native execution, Git, network or board call was made by this owner.
