from pathlib import Path
import json, subprocess, sys

root = Path('/home/tritlo/Code/mcfta')
area = Path('/tmp/mcfta-prepared-producer-arity-20261028')
modules = json.loads((area / 'modules.json').read_text())
groups = [
    ('Preserve arity through prepared native heads', modules[:3]),
    ('Carry arity through prepared recursive callbacks', modules[3:9]),
    ('Preserve aggregate arity through prepared sibling scans', modules[9:14]),
    ('Prove finite prepared arity with original histories', modules[14:18]),
    ('Prove rendered language soundness for prepared outputs', modules[18:] + ['Audit'])]
record_path = area / 'source-commits.json'
records = json.loads(record_path.read_text()) if record_path.exists() else []
for number in map(int, sys.argv[1:]):
    assert number not in [row['group'] for row in records]
    message, names = groups[number - 1]
    files = ['lean/MicroCFTA/' + name + '.lean' for name in names]
    subprocess.run(['git', 'add', '--', *files], cwd=root, check=True)
    result = subprocess.run(['git', 'commit', '-m', message], cwd=root, check=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip()
    row = dict(group=number, head=head, message=message, files=files, output=result.stdout.decode())
    records.append(row)
    record_path.write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(row), flush=True)
