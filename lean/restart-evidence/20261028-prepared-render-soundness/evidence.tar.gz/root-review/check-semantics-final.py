from pathlib import Path
import json, os, subprocess

area = Path('/tmp/mcfta-prepared-producer-arity-20261028')
env = dict(os.environ, XDG_RUNTIME_DIR='/run/user/1000',
           DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/1000/bus',
           HEAVY_PEAKS=str(area / 'peaks/records.log'))
modules = json.loads((area / 'modules.json').read_text())[18:] + ['Audit']
for index, module in enumerate(modules, 19):
    label = 'strict-final-' + str(index) + '-' + module
    command = ['/home/tritlo/Code/heavy-management/bin/capped', '--mem', '4G', '--time', '5m',
               'python3', str(area / 'check-installed.py'), 'strict', label, module]
    result = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (area / (label + '-launcher.log')).write_bytes(result.stdout)
    print(json.dumps(dict(module=module, exit_code=result.returncode)), flush=True)
    if result.returncode:
        print(result.stdout.decode(), flush=True)
        raise SystemExit(result.returncode)
result = subprocess.run(['/home/tritlo/Code/heavy-management/bin/capped', '--mem', '4G', '--time', '5m',
                         'python3', str(area / 'check-installed.py'), 'public', 'public-readback-final'],
                        env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(area / 'public-final-launcher.log').write_bytes(result.stdout)
print(json.dumps(dict(public_readback_exit_code=result.returncode)), flush=True)
if result.returncode:
    print(result.stdout.decode(), flush=True)
raise SystemExit(result.returncode)
