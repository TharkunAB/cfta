from pathlib import Path
import json
r=Path('/home/tritlo/Code/mcfta');a=Path(__file__).resolve().parents[1]
s=(r/'lean/MicroCFTA/SourcePruningEnumerationPreparedOpaqueResources.lean').read_text()
s=s.replace('import MicroCFTA.SourcePruningEnumerationSelectedOpaqueDispatch\nimport MicroCFTA.SourcePruningEnumerationChildBoundedResources\nimport MicroCFTA.SourcePruningEnumerationEdgeScalarBounds','import MicroCFTA.SourcePruningEnumerationPreparedOpaqueResources\nimport MicroCFTA.SourcePruningEnumerationChildObservedArity')
s=s.replace('# Resources through actual prepared opaque and terminal dispatch','# Arity through actual prepared opaque and terminal resources').replace('theorem opaque_complete_resources\n','theorem opaque_complete_resources_arity\n')
s=s.replace('local notation "Heap" => SourceEqualityAnnotationHeap.Heap','local notation "Heap" => SourceEqualityAnnotationHeap.Heap\nlocal notation "ArityHeap" => SourcePruningEnumerationArityOrigins.Heap')
old='(known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap) :';new='(known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)\n    (initialArity : ArityHeap caller.checked.native.machine.heap) :';assert s.count(old)==1;s=s.replace(old,new)
old='receipt = .rejected caller memos.query before) := by';new='receipt = .rejected caller memos.query before) ∧\n      ArityHeap reached.checked.native.machine.heap := by';assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('?_, ?_, Or.inr (Or.inr rfl)⟩','?_, ?_, Or.inr (Or.inr rfl), initialArity⟩') if False else s
old='?_, Or.inr (Or.inr rfl)⟩';assert s.count(old)==1;s=s.replace(old,'?_, Or.inr (Or.inr rfl), initialArity⟩')
old='    rcases shape with rejected | ⟨fragment, singleton, middleSafe, fragmentBound, fragmentPending, fragmentSeparate⟩';new='''    have reachedArity := SourcePruningEnumerationChildDispatch.observed_heap seed formulas solver inventory
      caller before checkEmpty childBound childBound childBound childBound childBound scs value roots memos
      packet.context packet.safe paths counts realized bucketBound pendingInputs available closed bounded reserved known
      initialArity (childAt childBound (Nat.le_refl _))
'''+old;assert s.count(old)==1;s=s.replace(old,new)
old='Or.inr (Or.inl ⟨middle, outer, waiting, rfl, counterBound, massBound⟩)⟩';assert s.count(old)==1;s=s.replace(old,'Or.inr (Or.inl ⟨middle, outer, waiting, rfl, counterBound, massBound⟩), reachedArity⟩')
old='Or.inl ⟨fragment, after, rfl, afterPacket, finalCounter, finalMass⟩⟩';assert s.count(old)==1;s=s.replace(old,'Or.inl ⟨fragment, after, rfl, afterPacket, finalCounter, finalMass⟩, reachedArity⟩')
m='SourcePruningEnumerationPreparedOpaqueResourcesArity';p=r/'lean/MicroCFTA'/f'{m}.lean';assert not p.exists();p.write_text(s)
mods=json.loads((a/'modules.json').read_text());mods.append(m);(a/'modules.json').write_text(json.dumps(mods,indent=2)+'\n')
