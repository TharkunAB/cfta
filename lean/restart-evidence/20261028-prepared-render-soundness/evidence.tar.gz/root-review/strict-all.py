from pathlib import Path
import json, os, subprocess

area = Path('/tmp/mcfta-prepared-producer-arity-20261028')
env = dict(os.environ, XDG_RUNTIME_DIR='/run/user/1000',
           DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/1000/bus',
           HEAVY_PEAKS=str(area / 'peaks/records.log'))
reports = []
for index, module in enumerate(json.loads((area / 'modules.json').read_text()), 1):
    label = 'strict-' + str(index).zfill(2) + '-' + module
    cmd = ['/home/tritlo/Code/heavy-management/bin/capped', '--mem', '4G', '--time', '5m',
           'python3', str(area / 'check-installed.py'), 'strict', label, module]
    result = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (area / (label + '-launcher.log')).write_bytes(result.stdout)
    print(json.dumps(dict(module=module, exit_code=result.returncode)), flush=True)
    reports.append(dict(module=module, exit_code=result.returncode, label=label))
    (area / 'strict-matrix.json').write_text(json.dumps(reports, indent=2) + '\n')
    if result.returncode:
        print(result.stdout.decode(), flush=True)
        raise SystemExit(result.returncode)
