from pathlib import Path
import json
r=Path('/home/tritlo/Code/mcfta');a=Path(__file__).resolve().parents[1]
old=(r/'lean/MicroCFTA/SourcePruningEnumerationFiniteArityContract.lean').read_text()
pre=(r/'lean/MicroCFTA/SourcePruningEnumerationPreparedZeroOutcomeResources.lean').read_text()
header=pre[:pre.index('/-- The exact zero-depth')]
header=header.replace('import MicroCFTA.SourcePruningEnumerationPreparedFiniteContract','import MicroCFTA.SourcePruningEnumerationPreparedFiniteArityContract')
header=header.replace('local notation "Heap" => SourceEqualityAnnotationHeap.Heap','local notation "Heap" => SourceEqualityAnnotationHeap.Heap\nlocal notation "ArityHeap" => SourcePruningEnumerationArityOrigins.Heap')
start=old.index('/-- Zero depth retains');end=old.index('/-- The original finite-driver contract adds',start)
zero=header+old[start:end]+'variable {bits : Nat}\n\n'+old[old.index('/-- The exact initial decision closes'):]
zero=zero.replace('SourcePruningEnumerationFiniteReservation','SourcePruningEnumerationPreparedReservation').replace('end MicroCFTA.SourcePruningEnumerationRecursive','end MicroCFTA.SourcePruningEnumerationPreparedRecursive')
(r/'lean/MicroCFTA/SourcePruningEnumerationPreparedZeroOutcomeResourcesArity.lean').write_text(zero)
s=(r/'lean/MicroCFTA/SourcePruningEnumerationPreparedFiniteParkedResources.lean').read_text()
s=s.replace('import MicroCFTA.SourcePruningEnumerationPreparedFiniteContract','import MicroCFTA.SourcePruningEnumerationPreparedFiniteArityContract')
s=s.replace('theorem parked_finite_complete_resources\n','theorem parked_finite_complete_resources_arity\n').replace('(recursive : Complete (bits := bits)','(recursive : CompleteWithArity (bits := bits)')
s=s.replace('local notation "Heap" => SourceEqualityAnnotationHeap.Heap','local notation "Heap" => SourceEqualityAnnotationHeap.Heap\nlocal notation "ArityHeap" => SourcePruningEnumerationArityOrigins.Heap')
needle='(prefixFuel + extra) (prefixFuel + extra) (prefixFuel + extra) uv caller before memos.query)) :';assert s.count(needle)==1;s=s.replace(needle,needle[:-2]+'\n    (initialArity : ArityHeap caller.checked.native.machine.heap) :')
needle='(SourcePruningEnumerationPreparedReservation.final (recursiveFuel + 1) seed ceiling) outcome := by';assert s.count(needle)==1;s=s.replace(needle,'(SourcePruningEnumerationPreparedReservation.final (recursiveFuel + 1) seed ceiling) outcome ∧\n      OutcomeResourcesWithArity formulas solver caller\n        (SourcePruningEnumerationPreparedReservation.final (recursiveFuel + 1) seed ceiling) outcome := by')
s=s.replace('have resources : OutcomeResources (Typing := Typing)','have resources : OutcomeResourcesWithArity (Typing := Typing)').replace('Post.refl packet.context, bounded, known, rfl, rfl, ?_⟩','Post.refl packet.context, bounded, known, initialArity, rfl, rfl, ?_⟩')
s=s.replace('refine ⟨prefixFuel, .complete [] caller memos.query, ?_, resources.mono growth.1 growth.2⟩','have padded := resources.mono growth.1 growth.2\n    refine ⟨prefixFuel, .complete [] caller memos.query, ?_, padded.forget, padded⟩')
s=s.replace('⟨resumeFuel, outcome, running, resources⟩ := recursive','⟨resumeFuel, outcome, running, _resources, strengthened⟩ := recursive').replace('selectionMembers selectionLength boundedMass reserved.first.2','selectionMembers selectionLength boundedMass reserved.first.2 initialArity')
s=s.replace('refine ⟨prefixFuel + resumeFuel, outcome, ?_, resources.mono growth.1 growth.2⟩','have padded := strengthened.mono growth.1 growth.2\n    refine ⟨prefixFuel + resumeFuel, outcome, ?_, padded.forget, padded⟩')
(r/'lean/MicroCFTA/SourcePruningEnumerationPreparedFiniteParkedResourcesArity.lean').write_text(s)
mods=json.loads((a/'modules.json').read_text());mods+=['SourcePruningEnumerationPreparedZeroOutcomeResourcesArity','SourcePruningEnumerationPreparedFiniteParkedResourcesArity'];(a/'modules.json').write_text(json.dumps(mods,indent=2)+'\n')
