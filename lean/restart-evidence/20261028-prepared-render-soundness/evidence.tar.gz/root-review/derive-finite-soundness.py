from pathlib import Path
import json

root = Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
area = Path('/tmp/mcfta-prepared-producer-arity-20261028')
base = (root / 'SourcePruningEnumerationPreparedFiniteHistoryCanonicalArity.lean').read_text()
start = base.index('/-- Original finite resources')
end = base.index(' := by\n', start)
header = base[start:end]
original_name = 'run_finite_complete_resources_with_history_canonical_arity'
sound_name = 'run_finite_complete_resources_with_history_canonical_sound'
render_name = 'run_finite_complete_resources_with_history_canonical_render_sound'
intro = '''import MicroCFTA.SourcePruningEnumerationPreparedFiniteHistoryCanonicalArity
import MicroCFTA.SourcePruningEnumerationPreparedHistoryRenderingSoundness

/-!
# Original finite inputs and sound actual prepared outputs

Original input arity derives the same actual output arity.
Each discharged output model satisfies the original cached restrictions.
Checked rendering supplies the complete final assignment.
The original stored root then supplies its native language and suspended constraints.
The original bound, outcome, resources, histories and canonical storage remain unchanged.
-/
''' + base[base.index('namespace MicroCFTA.'):start]
intro = intro.replace('open EnumerationState EnumerationValidity InternedConstructorTemplates',
                      'open Language EnumerationState EnumerationCorrectness EnumerationValidity InternedConstructorTemplates')
intro = intro.replace('local notation "Heap" => SourceEqualityAnnotationHeap.Heap',
                      'local notation "Heap" => SourceEqualityAnnotationHeap.Heap\nlocal notation "Core" => EnumerationState.State Symbol Constraint')
models = '''(∀ output ∈ SourcePruningEnumerationHookInvocation.hookOutputs outcome,
        SourcePruningEnumerationArityOrigins.Heap output.caller.checked.native.machine.heap ∧
        (SourcePruningEnumerationRendering.Discharged output.cache.core →
          ∀ (ambient : InternedGuardedLanguage.Env Symbol) (assignment : Nat → Term Symbol),
            Satisfies
              (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
                ambient output.caller.checked.native.machine.heap)
              (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
              assignment output.cache.core →
            Satisfies
              (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
                ambient caller.checked.native.machine.heap)
              (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
              assignment before.core))'''
observer = '''(∀ output ∈ SourcePruningEnumerationHookInvocation.hookOutputs outcome,
        SourcePruningEnumerationRendering.Discharged output.cache.core →
        ∀ (ambient : InternedGuardedLanguage.Env Symbol) (marker : Symbol) (fuel uv : Nat)
          (after : Core) (term : Term Symbol) (pending : List (Constraint × Term Symbol)),
          Success
            (SourcePruningEnumerationRendering.render output.caller.checked.native.machine.heap marker fuel uv)
            output.cache.core (term, pending) after →
          (∀ obligation ∈ pending,
            SourceEqualityPCSGuard.holds formulas solver obligation.1 obligation.2 = true) →
          ∀ (handle : Nat) (bucket : List Suspended) (value : Node),
            before.core.values[uv]? = some (.unenumerated (some handle) bucket) →
            lookupNode caller.checked.native.machine.heap handle = some value →
            ∃ assignment : Nat → Term Symbol,
              Satisfies
                (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
                  ambient caller.checked.native.machine.heap)
                (fun guard accepted => SourceEqualityPCSGuard.holds formulas solver guard accepted = true)
                assignment before.core ∧
              InternedGuardedLanguage.meaning (SourceEqualityPCSGuard.holds formulas solver) ambient value term ∧
              (∀ sc ∈ bucket, Suspended.Holds assignment term sc) ∧ term = assignment uv ∧
              EnumerationCompressionFrame.Frame output.cache.core after ∧
              Satisfies
                (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
                  ambient output.caller.checked.native.machine.heap)
                (fun guard accepted => SourceEqualityPCSGuard.holds formulas solver guard accepted = true)
                assignment output.cache.core ∧
              Satisfies
                (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
                  ambient output.caller.checked.native.machine.heap)
                (fun guard accepted => SourceEqualityPCSGuard.holds formulas solver guard accepted = true)
                assignment after)'''
sound_header = header.replace(original_name, sound_name).replace(
    '/-- Original finite resources and canonical storage derive canonicality at every actual output. -/',
    '/-- Original finite inputs derive output arity and backward meaning for every discharged actual output. -/')
sound_body = ''' := by
  obtain ⟨bound, outcome, running, resources, histories, canonicalOutputs, strengthened⟩ :=
    run_finite_complete_resources_with_history_canonical_arity
      holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver recursiveFuel
      inventory caller memos before metadata seed ceiling packet bounded known
      selectionMembers selectionLength initialMass reserved canonical initialArity
  have outputHeaps : ∀ output ∈ SourcePruningEnumerationHookInvocation.hookOutputs outcome,
      SourcePruningEnumerationArityOrigins.Heap output.caller.checked.native.machine.heap := by
    obtain ⟨_reached, _next, _final, _post, _bounded, _known, _arity, shape⟩ := strengthened
    cases outcome with
    | complete outputs reached queries => exact fun output member => (shape.2.2 output member).2
    | stopped outputs reason endpoint => exact fun output member => (shape.2 output member).2
  refine ⟨bound, outcome, running, resources, histories, canonicalOutputs, strengthened, ?_⟩
  intro output member
  refine ⟨outputHeaps output member, ?_⟩
  intro discharged ambient assignment satisfied
  exact (histories 0 output member).sound rfl canonical (outputHeaps output member)
    discharged ambient assignment satisfied

'''
render_header = header.replace(original_name, render_name).replace(
    '/-- Original finite resources and canonical storage derive canonicality at every actual output. -/',
    '/-- Checked rendering of a discharged finite output satisfies the original stored native root. -/')
render_body = ''' := by
  obtain ⟨bound, outcome, running, resources, histories, canonicalOutputs, strengthened, meanings⟩ :=
    run_finite_complete_resources_with_history_canonical_sound
      holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver recursiveFuel
      inventory caller memos before metadata seed ceiling packet bounded known
      selectionMembers selectionLength initialMass reserved canonical initialArity
  refine ⟨bound, outcome, running, resources, histories, canonicalOutputs, strengthened, meanings, ?_⟩
  intro output member discharged ambient marker fuel uv after term pending observed checked
    handle bucket value stored decoded
  exact (histories 0 output member).render_sound rfl canonical (meanings output member).1 discharged
    ambient marker fuel uv after term pending observed checked handle bucket value stored decoded

end MicroCFTA.SourcePruningEnumerationPreparedRecursive
'''
name = 'SourcePruningEnumerationPreparedFiniteHistorySoundness'
s = intro + sound_header + ' ∧\n      ' + models + sound_body
s += render_header + ' ∧\n      ' + models + ' ∧\n      ' + observer + render_body
(root / (name + '.lean')).write_text(s)
p = area / 'modules.json'; modules = json.loads(p.read_text()); modules.append(name)
p.write_text(json.dumps(modules, indent=2) + '\n')
