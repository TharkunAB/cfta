from pathlib import Path
import hashlib, json, re

area = Path('/tmp/mcfta-prepared-producer-arity-20261028')
root = Path('/home/tritlo/Code/mcfta')
modules = json.loads((area / 'modules.json').read_text())
checks = []
for module in modules + ['Audit']:
    raw = (root / 'lean/MicroCFTA' / (module + '.lean')).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    matches = []
    for path in area.glob('strict-*/report.json'):
        report = json.loads(path.read_text())
        if report.get('source_sha256') == digest and report['exit_code'] == 0 and report['command'][-1].endswith('/' + module + '.lean'):
            matches.append(str(path.relative_to(area)))
    assert matches, module
    checks.append(dict(module=module, bytes=len(raw), sha256=digest, passing_exact_source_reports=matches))
    if module != 'Audit':
        for pattern in [r'\bsorry\b', r'\badmit\b', r'^\s*axiom\s', r'\bnative_decide\b',
                        r'set_option\s+(maxHeartbeats|maxRecDepth|linter\.)']:
            assert not re.search(pattern, raw.decode(), re.M), (module, pattern)
(area / 'exact-final-strict-matrix.json').write_text(json.dumps(checks, indent=2) + '\n')
results = []
for path in sorted(area.glob('*/report.json')):
    report = json.loads(path.read_text())
    results.append(dict(path=str(path.relative_to(area)), exit_code=report['exit_code'], bytes=report['bytes'],
                        sha256=report['sha256'], limits=report['cgroup_limits']))
    assert report['cgroup_limits'] == {'memory.max': '4294967296', 'memory.high': '4294967296', 'memory.swap.max': '0'}
    assert hashlib.sha256((path.parent / 'raw.log').read_bytes()).hexdigest() == report['sha256']
failed = [report for report in results if report['exit_code']]
assert [report['bytes'] for report in failed] == [2195, 21783]
result = dict(exact_final_sources=len(checks), all_compiler_commands=len(results), retained_failed_commands=failed,
              successful_commands=len(results) - len(failed), heartbeat_or_recursion_increase=False,
              linter_suppression=False, prohibited_proof_terms=False)
(area / 'validation-final.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
