from pathlib import Path
import json

root = Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
area = Path('/tmp/mcfta-prepared-producer-arity-20261028')
original = 'SourcePruningEnumerationPreparedFiniteHistoryCanonical'
name = original + 'Arity'
s = (root / (original + '.lean')).read_text()
s = s.replace('import MicroCFTA.SourcePruningEnumerationPreparedFiniteHistoryResources\n',
              'import MicroCFTA.SourcePruningEnumerationPreparedFiniteHistoryCanonical\nimport MicroCFTA.SourcePruningEnumerationPreparedFiniteResourcesArity\n')
s = s.replace('theorem run_finite_complete_resources_with_history_canonical\n',
              'theorem run_finite_complete_resources_with_history_canonical_arity\n')
s = s.replace('(canonical : Canonical before.core) :',
              '(canonical : Canonical before.core)\n    (initialArity : SourcePruningEnumerationArityOrigins.Heap caller.checked.native.machine.heap) :')
s = s.replace('      ∀ output ∈ SourcePruningEnumerationHookInvocation.hookOutputs outcome,\n        Canonical output.cache.core := by',
              '      (∀ output ∈ SourcePruningEnumerationHookInvocation.hookOutputs outcome,\n        Canonical output.cache.core) ∧\n      OutcomeResourcesWithArity formulas solver caller\n        (SourcePruningEnumerationPreparedReservation.final recursiveFuel seed ceiling) outcome := by')
start = s.index('  obtain ⟨bound, outcome, running, resources, histories⟩ :=\n')
s = s[:start] + '''  obtain ⟨bound, outcome, running, resources, histories, canonicalOutputs⟩ :=
    run_finite_complete_resources_with_history_canonical
      holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver recursiveFuel
      inventory caller memos before metadata seed ceiling packet bounded known
      selectionMembers selectionLength initialMass reserved canonical
  obtain ⟨arityBound, arityOutcome, arityRunning, _arityResources, strengthened⟩ :=
    run_finite_complete_resources_with_arity
      holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver recursiveFuel
      inventory caller memos before metadata seed ceiling packet bounded known
      selectionMembers selectionLength initialMass reserved initialArity
  have arityAt := arityRunning bound
  have common : arityBound + bound = bound + arityBound := Nat.add_comm _ _
  rw [common] at arityAt
  have same : arityOutcome = outcome := arityAt.symm.trans (running arityBound)
  rw [same] at strengthened
  exact ⟨bound, outcome, running, resources, histories, canonicalOutputs, strengthened⟩

end MicroCFTA.SourcePruningEnumerationPreparedRecursive
'''
s = s.replace('# Initial canonical storage at every finite prepared output',
              '# Original histories, canonical storage and arity at the same finite outcome')
s = s.replace('The result retains the same bound, outcome, native resources and histories.',
              'The result retains the same bound, outcome, native resources and histories.\nA common larger work bound identifies the arity producer outcome.\nOriginal caller arity supplies each output arity and each exposed endpoint arity.')
(root / (name + '.lean')).write_text(s)
p = area / 'modules.json'
modules = json.loads(p.read_text()); modules.append(name)
p.write_text(json.dumps(modules, indent=2) + '\n')
