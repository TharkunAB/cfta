from pathlib import Path
import json

root = Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
area = Path('/tmp/mcfta-prepared-producer-arity-20261028')

def replace_once(source, before, after):
    assert source.count(before) == 1, (source.count(before), before)
    return source.replace(before, after)

name = 'SourcePruningEnumerationPreparedFiniteExpansionResources'
s = (root / (name + '.lean')).read_text()
for dependency in ['PreparedFiniteParkedResources', 'PreparedOrdinaryResources', 'PreparedOpaqueFiniteResources']:
    s = s.replace('import MicroCFTA.SourcePruningEnumeration' + dependency + '\n',
                  'import MicroCFTA.SourcePruningEnumeration' + dependency + 'Arity\n')
s = s.replace('import MicroCFTA.SourcePruningEnumerationPrefixCheckpoint\n',
              'import MicroCFTA.SourcePruningEnumerationPrefixCheckpoint\nimport MicroCFTA.SourcePruningEnumerationPrefixArity\n')
s = s.replace('local notation "Heap" => SourceEqualityAnnotationHeap.Heap',
              'local notation "Heap" => SourceEqualityAnnotationHeap.Heap\nlocal notation "ArityHeap" => SourcePruningEnumerationArityOrigins.Heap')
s = s.replace('theorem selected_finite_complete_resources\n', 'theorem selected_finite_complete_resources_arity\n')
s = s.replace('(recursive : Complete (bits := bits)', '(recursive : CompleteWithArity (bits := bits)')
s = replace_once(s, '(chosen : SourcePruningEnumerationRestart.decision stop order metadata before = some (.expand uv)) :',
                 '(chosen : SourcePruningEnumerationRestart.decision stop order metadata before = some (.expand uv))\n    (initialArity : ArityHeap caller.checked.native.machine.heap) :')
s = replace_once(s, '(Forecast (recursiveFuel + 1) seed ceiling) outcome := by',
                 '(Forecast (recursiveFuel + 1) seed ceiling) outcome ∧\n      OutcomeResourcesWithArity formulas solver caller\n        (Forecast (recursiveFuel + 1) seed ceiling) outcome := by')
s = replace_once(s, 'obtain ⟨bound, outcome, running, resources⟩ := parked_finite_complete_resources',
                 'obtain ⟨bound, outcome, running, resources, strengthened⟩ := parked_finite_complete_resources_arity')
s = replace_once(s, 'selectionMembers selectionLength initialMass reserved phase',
                 'selectionMembers selectionLength initialMass reserved phase initialArity')
s = replace_once(s, 'simpa only [SourcePruningEnumerationPreparedReservation.final_succ] using resources⟩',
                 'simpa only [SourcePruningEnumerationPreparedReservation.final_succ] using resources, by\n      simpa only [SourcePruningEnumerationPreparedReservation.final_succ] using strengthened⟩')
prefix_arity = '''    have narrowedArity := SourcePruningEnumerationSelectedStep.prefix_heap
      holeKey fits admits graph templates checkEmpty edgesOf stop order metadata formulas solver inventory
      (prefixFuel + 0) uv caller before memos packet.context realized initialArity _ valid
'''
s = replace_once(s, '    rw [(phase 0).1] at valid\n', '    rw [(phase 0).1] at valid\n' + prefix_arity)
s = replace_once(s, '    rw [prefixAt] at valid\n', '    rw [prefixAt] at valid\n' + prefix_arity)
s = replace_once(s, 'have certificate : OutcomeResources (Typing := Typing)',
                 'have certificate : OutcomeResourcesWithArity (Typing := Typing)')
s = replace_once(s, 'post, resources.1, resources.2, rfl, query.symm,',
                 'post, resources.1, resources.2, narrowedArity, rfl, query.symm,')
s = replace_once(s, '''    refine ⟨prefixFuel, .complete [] reached memos.query, ?_, certificate.mono
      ((SourcePruningEnumerationPreparedReservation.normalizationProfile_ge
        (SourcePruningEnumerationExpansionAdmission.narrowSeed seed).2).trans stageGrowth.1) stageGrowth.2⟩''',
'''    have padded := certificate.mono
      ((SourcePruningEnumerationPreparedReservation.normalizationProfile_ge
        (SourcePruningEnumerationExpansionAdmission.narrowSeed seed).2).trans stageGrowth.1) stageGrowth.2
    refine ⟨prefixFuel, .complete [] reached memos.query, ?_, padded.forget, padded⟩''')
s = replace_once(s, 'entered, retained, ordinary⟩ :=', 'entered, retained, ordinary, preparedArity⟩ :=')
s = replace_once(s, 'SourcePruningEnumerationPreparedNativeOrdinaryResources.complete_resources\n',
                 'SourcePruningEnumerationPreparedNativeOrdinaryResources.complete_resources_arity\n')
s = replace_once(s, 'currentMass inheritedBound reserved.scan', 'currentMass inheritedBound reserved.scan narrowedArity')
s = replace_once(s, '_scanPacket, dispatchRun, _fullPost, resources⟩',
                 '_scanPacket, dispatchRun, _fullPost, _resources, strengthened⟩')
s = replace_once(s, '''      refine ⟨prefixFuel + (preparationFuel + scanFuel), finish uv folded, ?_,
        (resources.mono growth.1 growth.2).post middlePost⟩''',
'''      have original := (strengthened.mono growth.1 growth.2).post middlePost
      refine ⟨prefixFuel + (preparationFuel + scanFuel), finish uv folded, ?_,
        original.forget, original⟩''')
s = replace_once(s, '_shape, _paddedFits, _paddedKnown, _callbackRun, _receiptRun, resources, opaqueFoldRun⟩',
                 '_shape, _paddedFits, _paddedKnown, _callbackRun, _receiptRun, _resources, opaqueFoldRun, strengthened⟩')
s = replace_once(s, 'SourcePruningEnumerationPreparedNativeHookResources.opaque_finite_complete_resources\n',
                 'SourcePruningEnumerationPreparedNativeHookResources.opaque_finite_complete_resources_arity\n')
s = replace_once(s, 'inherited inherited enteredMass inheritedBound reserved.first',
                 'inherited inherited enteredMass inheritedBound reserved.first preparedArity')
s = replace_once(s, 'have padded : OutcomeResources formulas solver',
                 'have padded : OutcomeResourcesWithArity formulas solver')
s = replace_once(s, '        resources.mono growth.1 growth.2\n',
                 '        strengthened.mono growth.1 growth.2\n')
s = replace_once(s, '''        simpa only [SourcePruningEnumerationPreparedReservation.final_succ] using original⟩''',
'''        simpa only [SourcePruningEnumerationPreparedReservation.final_succ] using original.forget, by
        simpa only [SourcePruningEnumerationPreparedReservation.final_succ] using original⟩''')
s = s.replace('endpoint, full memos, cache packet and resource bound.',
              'endpoint, full memos, cache packet and resource bound. Original caller arity\nalso derives the aggregate endpoint arity and each output heap arity.')
(root / (name + 'Arity.lean')).write_text(s)

name = 'SourcePruningEnumerationPreparedFiniteRunStep'
s = (root / (name + '.lean')).read_text()
s = s.replace('import MicroCFTA.SourcePruningEnumerationPreparedFiniteExpansionResources\n',
              'import MicroCFTA.SourcePruningEnumerationPreparedFiniteExpansionResourcesArity\n')
s = s.replace('import MicroCFTA.SourcePruningEnumerationPreparedZeroOutcomeResources\n',
              'import MicroCFTA.SourcePruningEnumerationPreparedZeroOutcomeResourcesArity\n')
s = s.replace('local notation "Heap" => SourceEqualityAnnotationHeap.Heap',
              'local notation "Heap" => SourceEqualityAnnotationHeap.Heap\nlocal notation "ArityHeap" => SourcePruningEnumerationArityOrigins.Heap')
s = s.replace('theorem run_finite_succ_complete_resources\n', 'theorem run_finite_succ_complete_resources_arity\n')
s = s.replace('(recursive : Complete (bits := bits)', '(recursive : CompleteWithArity (bits := bits)')
s = replace_once(s, '(reserved : SourcePruningEnumerationPreparedReservation.Reserved bits (recursiveFuel + 1) seed ceiling) :',
                 '(reserved : SourcePruningEnumerationPreparedReservation.Reserved bits (recursiveFuel + 1) seed ceiling)\n    (initialArity : ArityHeap caller.checked.native.machine.heap) :')
s = replace_once(s, '(SourcePruningEnumerationPreparedReservation.final (recursiveFuel + 1) seed ceiling) outcome := by',
                 '(SourcePruningEnumerationPreparedReservation.final (recursiveFuel + 1) seed ceiling) outcome ∧\n      OutcomeResourcesWithArity formulas solver caller\n        (SourcePruningEnumerationPreparedReservation.final (recursiveFuel + 1) seed ceiling) outcome := by')
s = replace_once(s, 'obtain ⟨bound, outcome, running, resources⟩ := selected_finite_complete_resources',
                 'obtain ⟨bound, outcome, running, resources, strengthened⟩ := selected_finite_complete_resources_arity')
s = replace_once(s, 'initialMass reserved chosen', 'initialMass reserved chosen initialArity')
s = replace_once(s, 'using running extra, resources⟩', 'using running extra, resources, strengthened⟩')
s = replace_once(s, 'obtain ⟨outcome, running, resources⟩ := resume_zero_outcome_resources',
                 'obtain ⟨outcome, running, _resources, strengthened⟩ := resume_zero_outcome_resources_arity')
s = replace_once(s, '      seed packet bounded known\n', '      seed packet bounded known initialArity\n')
s = replace_once(s, '    refine ⟨0, outcome, ?_, resources.mono growth.1 growth.2⟩',
                 '    have padded := strengthened.mono growth.1 growth.2\n    refine ⟨0, outcome, ?_, padded.forget, padded⟩')
(root / (name + 'Arity.lean')).write_text(s)

name = 'SourcePruningEnumerationPreparedFiniteResources'
s = (root / (name + '.lean')).read_text()
s = s.replace('import MicroCFTA.SourcePruningEnumerationPreparedFiniteRunStep\n',
              'import MicroCFTA.SourcePruningEnumerationPreparedFiniteRunStepArity\n')
s = s.replace('local notation "Heap" => SourceEqualityAnnotationHeap.Heap',
              'local notation "Heap" => SourceEqualityAnnotationHeap.Heap\nlocal notation "ArityHeap" => SourcePruningEnumerationArityOrigins.Heap')
s = s.replace('theorem finite_complete\n', 'theorem finite_complete_with_arity\n')
s = s.replace('    Complete (bits := bits)', '    CompleteWithArity (bits := bits)')
start = s.index('  | zero =>\n')
end = s.index('  | succ recursiveFuel ih =>\n')
s = s[:start] + '''  | zero =>
      exact zero_complete_with_arity holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver
''' + s[end:]
s = replace_once(s, 'selectionMembers selectionLength initialMass reserved\n      exact run_finite_succ_complete_resources',
                 'selectionMembers selectionLength initialMass reserved initialArity\n      exact run_finite_succ_complete_resources_arity')
s = replace_once(s, 'selectionMembers selectionLength initialMass reserved\n\n/--',
                 'selectionMembers selectionLength initialMass reserved initialArity\n\n/--')
s = s.replace('theorem run_finite_complete_resources\n', 'theorem run_finite_complete_resources_with_arity\n')
s = replace_once(s, '(reserved : SourcePruningEnumerationPreparedReservation.Reserved bits recursiveFuel seed ceiling) :',
                 '(reserved : SourcePruningEnumerationPreparedReservation.Reserved bits recursiveFuel seed ceiling)\n    (initialArity : ArityHeap caller.checked.native.machine.heap) :')
s = replace_once(s, '(SourcePruningEnumerationPreparedReservation.final recursiveFuel seed ceiling) outcome :=',
                 '(SourcePruningEnumerationPreparedReservation.final recursiveFuel seed ceiling) outcome ∧\n      OutcomeResourcesWithArity formulas solver caller\n        (SourcePruningEnumerationPreparedReservation.final recursiveFuel seed ceiling) outcome :=')
s = replace_once(s, '  finite_complete holeKey', '  finite_complete_with_arity holeKey')
s = replace_once(s, '    selectionMembers selectionLength initialMass reserved\n\nend',
                 '    selectionMembers selectionLength initialMass reserved initialArity\n\nend')
s = s.replace('public result. Explicit stopped outcomes keep their exact observations.',
              'public result. Original caller arity derives arity at the aggregate\nendpoint and each emitted output. Explicit stopped outcomes keep their exact observations.')
(root / (name + 'Arity.lean')).write_text(s)

p = area / 'modules.json'
modules = json.loads(p.read_text())
modules += [name + 'Arity' for name in [
    'SourcePruningEnumerationPreparedFiniteExpansionResources',
    'SourcePruningEnumerationPreparedFiniteRunStep',
    'SourcePruningEnumerationPreparedFiniteResources']]
p.write_text(json.dumps(modules, indent=2) + '\n')
