# Prepared producer arity contract review

Status: PASS. Frozen at 2026-10-28 18:02:44 CET.

I read all six assigned public blocks in full. They contain 69,088 bytes and 924 lines. I read all six exact installed source modules in full, including each proof. They contain 80,506 bytes and 1,134 lines. I read block 18 separately. No output was truncated. The copied blocks match every assigned manifest byte count and SHA256.

Every new signature retains the complete original prepared signature. For each declaration, I removed only the new initial arity input and returned arity or strong-resource fields. I restored the original prepared Complete name where the new theorem uses CompleteWithArity. All six complete signature comparisons pass modulo whitespace. Literal original cuts and projected cuts are retained. Every initialArity input is last and applies to the original caller heap.

| Block | Named conclusion | Checked result |
| --- | --- | --- |
| 03 | opaque_complete_resources_arity | Original opaque receipt resources plus actual reached heap arity. |
| 04 | complete_with_history_resources_prepared_arity | Original captured prepared-edge witnesses and fields plus actual reached heap arity. |
| 05 | head_complete_resources_prepared_arity | Original native head cases and resources plus actual reached heap arity. |
| 14 | head_finite_complete_resources_arity | Original head, callback and captured-packet fields plus middle arity and strong resources for the same outcome. |
| 17 | opaque_finite_complete_resources_arity | Original opaque receipt, continuation and folded result plus strong resources for the same finished outcome. |
| 18 | complete_resources_arity | Entire original preparation packet and ordinary scan witnesses plus prepared heap arity and strong resources for the same finished outcome. |

The native captured route uses separate prepared parent availability and closedness. It retains the original stored source handle. It does not identify the decoded source with the prepared parent. The ordinary preparation route derives the prepared heap through the actual SelectedPreparation.run_heap evidence. The preparation language and Satisfies equivalences are returned conclusions. They are not supplied model premises.

The finite head and opaque routes derive middle arity from the actual native producer. They supply that fact to the actual prepared receipt/callback producer. The ordinary route uses the actual prepared sibling-finish producer. The finite helpers use actual PreparedRecursive.Failure, continueWith, resume and finish. They do not cast an old worker or old Failure to the prepared execution. Aggregate arity remains available when callbacks emit no outputs.

The finite helpers explicitly require the smaller-depth prepared CompleteWithArity induction hypothesis. They do not assume a Heap or a logical model at a specified future endpoint. Composing Post changes the origin of resources that were already proved; it does not transport arity forward through arbitrary heap growth. Each printed axiom list contains exactly propext, Classical.choice and Quot.sound.

Initial ArityOrigins.Heap remains a genuine original-input gate. These helpers do not derive it from bare Packet. These six exports are local producer results. They do not by themselves establish a whole-driver theorem, projectability, semantic completeness, unrestricted termination or Haskell correspondence. The top-level producer exports belong to the separate root review.

No concrete correction is required. The manifest records all source and block hashes, literal signature cuts, read scopes, named conclusions and scope gates. I did not run a compiler, build, native program, Git, network or board operation. The strict build and Audit results were supplied by root.
