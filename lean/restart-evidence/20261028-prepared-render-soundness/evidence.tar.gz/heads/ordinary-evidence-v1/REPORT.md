# Prepared ordinary producer arity candidate

The additive candidate is ready for root compilation.
It is `ordinary-candidate-v1/MicroCFTA/SourcePruningEnumerationPreparedOrdinaryResourcesArity.lean`.
The public theorem is `PreparedNativeOrdinaryResources.complete_resources_arity`.
It has 225 lines and 17,563 bytes.
Its SHA256 is `38394a12e115ddf7bc375b61234b0ab78f2023dbe8c23bbee3d9962d3aaeffc3`.

## Required change

The actual original ordinary producer takes PreparedRecursive.Complete.
The new CompleteWithArity contract has a genuine original input Heap condition.
It cannot be cast to the old unqualified contract.
This candidate rebuilds the actual ordinary producer with the arity-aware sibling producer.
It does not apply or weaken the old Complete premise.

All original input gates remain, including both global selector conditions,
Packet, incoming references, initial suspended mass, inherited length and ScanReserved.
The only added original input is initialArity, last after reserved.
The recursive hypothesis is the actual prepared CompleteWithArity at the smaller depth.
The actual prepared Failure type remains throughout.

## Exact result additions

The five existential witnesses remain preparationBound, decoded, result, heap and entered.
Their conjunction is:

- the complete original preparation packet;
- the original ordinaryCases function, with strong finished resources appended inside each ordinary case;
- ArityOrigins.Heap heap, outside the ordinaryCases function.

For an ordinary case, the seven existential witnesses remain scanBound,
processed, outputs, afterCaller, next, final and folded.
Their conjunction keeps the complete original scan packet, actual selected-run family,
full original-caller Post and old finished OutcomeResources.
It appends OutcomeResourcesWithArity for the same `PreparedRecursive.finish uv folded` result last.
This stronger resource relation uses the original caller as its Post source.
The same actual aggregate and output callers retain arity, including an empty output list.

## Actual proof route

The original preparation producer runs once and retains every original field.
The exact decoded lookup and `preparedRun 0` feed SelectedPreparation.run_heap.
This derives the prepared heap from initialArity at the original caller.
The result is valid before the ordinary value case split.
The proof passes that derived heap to the compiled sibling finish arity producer.
It preserves the existing normalization profile, selected-row reservation and common work bound.
The strong finished resource receipt composes the actual preparation Post.
That composition retains already-derived arity at the same reached callers.
It does not infer forward arity from a Post alone.

The stored handle and decoded value remain separate from the prepared value.
The ordinary branch substitutes only its actual prepared result using its own case equality.
No source/prepared identity or old/prepared worker cast is used.
No prepared or reached Heap is an input assumption.
No semantic model oracle or future endpoint condition is introduced.

## Statement preservation and validation

The exact original, extended and projected signatures are retained here.
After removing only the declared arity additions and restoring CompleteWithArity
as the original Complete name, the projected signature matches the actual
original PreparedOrdinaryResources signature after whitespace normalization.
This check passes. No original witness or resource field was removed.

Root reported BUILD PASS for the previous captured/native/head and callback/sibling chain.
This candidate was not compiled by this agent. Root owns its compilation and integration.
No compiler, native execution, Git, network, board or repository write ran here.
No budget or linter setting changed. The original local reducibility annotation is retained.
Earlier candidate and report versions remain unchanged.

The smaller-depth strong contract remains a local induction hypothesis.
This candidate alone does not close the prepared depth induction or prove whole-history semantics,
accepted-output coverage, sufficient original depth or Haskell correspondence.
No Haskell source changed and no new Haskell defect or required fix was established.
