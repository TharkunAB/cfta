# Prepared head arity candidates

Three additive source candidates are ready for root compilation.
They retain the original prepared-parent and original stored-handle indexes.
They derive returned edge-record arity from the actual input Heap.
No compiler, native execution, Git, network, board or repository edit ran here.
The base is the parent-reported pulled `formalize c46d380b4`.
Earlier frozen evidence areas remain unchanged.

## Immutable candidates and interfaces

1. `candidate-v1/MicroCFTA/SourcePruningEnumerationCapturedPreparedResourcesArity.lean`
   exports `CapturedEdge.complete_with_history_resources_prepared_arity`.
   It preserves the entire original prepared captured resource statement.
   It adds initialArity after known and appends the returned caller Heap last.
   Its parentAvailable and parentClosed are separate from the original stored handle.
2. `candidate-v1/MicroCFTA/SourcePruningEnumerationNativePreparedResourcesArity.lean`
   exports `NativeBranchCompletion.head_complete_resources_prepared_arity`.
   It preserves every original prepared native head input and result field.
   It adds initialArity last and appends returned Heap last.
   The native head retains its full Context, memo state and actual cache admissions.
3. `finite-head-candidate-v1/MicroCFTA/SourcePruningEnumerationPreparedFiniteHeadResourcesArity.lean`
   exports `PreparedNativeHookResources.head_finite_complete_resources_arity`.
   It keeps the original Packet, both original global selection gates, suspended-mass bound,
   separate parent availability/closedness, inherited-length bound and prepared reservation.
   It uses the actual prepared smaller-depth CompleteWithArity contract.
   It adds initialArity last, strong same-outcome resources inside the handled branch,
   and native head endpoint Heap as the final result conjunct.

`MANIFEST.json` records whole source hashes, exact literal read cuts and candidate hashes.
All three candidates total 507 lines and 35,058 bytes.
The signature projection checks all pass.
After removing only the declared arity additions, each candidate signature matches
its original prepared resource signature after whitespace normalization.
The finite comparison also restores the original recursive contract name Complete.
These comparisons establish retained statement fields. They do not assert old/prepared execution identity.

## Exact native result scope

The producer fixes sufficient work bounds under its original resource assumptions.
It covers each producer-admitted head shape:

- a completed selected edge and its actual captured-slot finalization;
- a stopped child with the original empty successful raw observation and actual cache;
- an arity-rejected head;
- an unsupported projection, returned as unhandled.

The complete and stopped-child branches obtain returned Heap from the existing
SelectedEdgeResourcesArity producer at the actual reached caller.
The actual captured finalizer changes the enumeration cache and retains that caller.
Rejected and unsupported branches retain the original caller and its input Heap.
This does not classify every arbitrary insufficient-fuel raw outcome.
It preserves the original finite producer contract and appends arity for its own result.

## Finite callback and earlier siblings

The finite head obtains all-shape native arity before calling the actual prepared receipt callback.
Its original cache bounds come from the same literal observed head execution.
The callback consumes that middleArity and the smaller-depth CompleteWithArity contract.
Its actual prepared OutcomeResourcesWithArity retains both aggregate and emitted-output heaps.
The aggregate heap remains necessary when the callback emits an empty output list.
It supplies the caller used by later sibling heads.

The finite tuple is:
bound, receipt, middleCaller, saved, middleMemos, middleInventory,
headRun, headPost, headQueries, admitted, pending, history, cacheBounds,
headFits, headKnown, shape, middleArity.
The handled shape is:
outcome, advanced, callbackRun, original OutcomeResources,
original completed-captured endpoint match, strengthened same-outcome resources.
The sibling owner has this exact interface.

All callback and outcome types use PreparedRecursive.Failure and the actual prepared worker.
Shared native operations and Packet are reused by their actual common interfaces.
No source handle is identified with its prepared ordinary parent.
No old worker is cast to the prepared worker.
No forward arity fact is inferred from an arbitrary Post.
No later/output Heap or semantic model is an input gate.

## Remaining scope and validation

The native candidates do not require a recursive completeness hypothesis.
The finite head candidate uses the stronger smaller-depth hypothesis.
The finite-depth induction must establish that hypothesis in its own producer.
These candidates alone do not prove whole prepared-driver arity, whole-history semantics,
accepted-output coverage, a sufficient original recursive depth or public Haskell correspondence.
Original source checks or another genuine same-input arity origin remain an upstream obligation.
Bare Packet is not used as an arity certificate.

Root owns strict compilation, dependency repairs, integration and full validation.
No compilation success is asserted by this report.
The source text contains no sorry, admit, custom axiom, native_decide or set_option.
No Haskell source changed. No new Haskell defect or required repair was established.
