# Final prepared finite semantic contract review

Status: PASS. Frozen at 2026-10-28 18:11:41 CET. No concrete correction is required.

I read both complete public exports, blocks 28 and 29. They contain 21,265 bytes and 272 lines. Their copies match the final manifest byte counts and SHA256 hashes. I read the whole exact installed PreparedFiniteHistorySoundness source. I also read the whole canonical-arity producer, local history rendering soundness module and output rendering module. The manifest records each read scope, literal source copy and hash. Three additional definition cuts record whole-cache discharge, actual Success and fixed PCS guard semantics.

Block 28, run_finite_complete_resources_with_history_canonical_sound, retains the complete prior canonical-arity contract. Block 29, run_finite_complete_resources_with_history_canonical_render_sound, retains the complete block 28 contract. Both entire signature projections pass modulo whitespace and theorem name. The original bound, literal run family, outcome, OutcomeResources, all per-output histories, output canonicality and same-result strong resources remain unchanged.

Both exports take only original-caller arity, as their last original input. All original resource, global selection membership/length, suspended mass, reservation and canonical gates remain explicit. Neither export takes a later arity heap, a supplied final model, or a recursive-completeness oracle as a producer input. Block 28 derives each actual output heap from the same-result strong resources, for both complete and stopped outcomes.

The observers have distinct roles:

- Block 28 retains a backward model observer. Output membership, whole-cache Discharged, an ambient environment, an assignment and final Satisfies are its antecedents. Original-cache Satisfies for that same assignment is its conclusion. It does not claim model existence by itself.
- Block 29 adds an actual rendering observer. Its antecedents include output membership, whole-cache Discharged, actual rendering Success, every reported pending obligation passing the fixed checked PCS semantics, and the original stored native-root handle and lookup. It derives an existential assignment and model. It also derives the original native value meaning, every suspended restriction in the full original bucket, equality of the rendered term with assignment uv, the compression Frame, and satisfaction of both the output and rendered after cores.

Whole-cache Discharged requires EVERY remaining unenumerated slot to have no native handle and an empty suspended bucket. It allows free unrestricted equality variables. It is not merely a condition on the rendered root. Success means membership of an actual Except.ok branch in the actual state action.

The global rendering proof calls the matching histories 0 output member and supplies (meanings output member).1 to local ResourceHistory.render_sound. That fact is the output arity already derived from original input arity. It discharges actualNext by rfl. The local observer derives the complete assignment from actual checked rendering, restores original Satisfies through history.sound, then obtains original native meaning by handles_lookup. It obtains every original suspended restriction from the same original stored slot. No source/prepared-parent identity cast or forward arity inference from arbitrary Post growth occurs.

Both statements fix residual interpretation to SourceEqualityPCSGuard.holds formulas solver. The checked predicate includes raw PCS equality satisfaction and the actual public guard decision .yes. There is no arbitrary residual interpretation parameter. Every printed axiom block contains exactly propext, Classical.choice and Quot.sound.

These are conditional soundness statements for the formalized prepared finite worker. They do not claim that each run emits an output, reaches a discharged cache, enumerates every accepted term, or corresponds to the Haskell implementation. The work-bound statement keeps recursive depth fixed. I did not run a compiler, build, native program, Git, network or board operation. Root supplied the strict build and final Audit status.
