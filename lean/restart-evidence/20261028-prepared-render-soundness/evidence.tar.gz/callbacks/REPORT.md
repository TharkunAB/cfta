# Prepared callback and receipt arity candidates

Recorded: 2026-10-28T17:41:03+01:00.
Root-reported source base: `c46d380b4`; Root reported its pull current.
This child ran no Git, compiler, build, native, network or board command.
All writes stayed in `/tmp/mcfta-prepared-producer-arity-20261028/callbacks`.

## Completed candidate scope

Four immutable additive modules contain 404 lines in total.
They are uncompiled candidates. Root owns installation, repair and strict checks.
`manifest.json` gives every candidate byte count, SHA-256 and named conclusion.

1. `PreparedOutcomeResourcesArity` defines `OutcomeResourcesWithArity` on the actual prepared `HookResult`. It includes `forget`, `post` and `mono`.
2. `PreparedFiniteArityContract` defines `CompleteWithArity` for the actual prepared driver.
3. `PreparedFiniteCallbackResourcesArity` derives the actual finite metadata callback and its stronger same-result resources.
4. `PreparedFiniteReceiptResourcesArity` derives that callback from its actual receipt and retains stronger same-result resources.

The aggregate property keeps `reached`, `next`, full `final` memos, `Post`,
`Fits`, guard `Heap`, and the original endpoint/absence shape. It adds aggregate
arity before that shape. Every actual output carries `OutputResources` followed
by its own arity `Heap`. An empty output list does not remove aggregate arity.
The `forget` proof reuses all original existential witnesses and output
certificates. It drops only the new arity conjuncts.

`CompleteWithArity` retains all actual Prepared `Complete` inputs: original
`Packet`, numeric resources, known guards, global selection membership and
length, original suspended mass ceiling, and `PreparedReservation.Reserved`.
It adds the original caller arity heap last. It returns a stable actual outcome,
old `OutcomeResources`, and `OutcomeResourcesWithArity` for that same outcome and
same final prepared seed. This definition is the induction goal. This task does
not claim that it has discharged the whole driver induction.

## Actual callback proof and exact type boundary

Prepared `Failure` is a separate inductive type. Its `preparation` case differs
from the old worker's `ordinary` case. These candidates use `Failure` in the
actual `PreparedRecursive` namespace. They do not cast an old hook or define a
generic abstraction over arbitrary failures.

The actual prepared callback source reconstructs `continueWith` from exact
`recordTypes` facts. Its reconstruction block is byte-identical in the new
callback candidate. This preserves the actual prepared continuation type.
The callback keeps the returned `Packet`, render/frame facts, all metadata
fields, singleton raw recording, and exact stable continuation observations.
Its only added local input is the callback caller's initial arity heap.
Recording does not change that native caller. Rejection therefore derives the
empty-output aggregate heap directly from that initial heap. The other branch
uses the smaller-depth `CompleteWithArity` induction hypothesis at the actual
recorded callback cache. It does not assume arity at a desired output.

The receipt candidate retains its original `Post`, literal `advance` equation,
`Admitted`, `Pending`, `FragmentHistory`, mass, selection and reservation gates.
Its local initial heap is at the receipt's actual callback caller `reached`.
The native/finite head producer must derive that input before calling this
helper. Rejected or stopped handled receipts derive the empty-output aggregate
heap from this local initial heap. A completed receipt derives its actual
callback packet, then invokes the new prepared callback producer.

## Static checks and remaining ownership

`STATIC-CHECKS.json` records successful syntax and byte checks. Removing only
the announced new fields from the stronger property/contract/statements gives
the exact original prepared bodies or statements, up to whitespace. The
callback's nominal continuation reconstruction block is byte-identical.
The candidates contain no `sorry`, `admit`, custom axiom, `native_decide`, unsafe
proof, budget option, linter suppression, old Failure qualification or old
finite reservation reference. These are static checks, not Lean validation.

All eight requested original source files were read whole. Ten source files
were copied whole for identity. The two core worker snapshots have explicit
partial read ranges. The manifest also identifies literal read cuts. Initial
combined source outputs that truncated were recovered with full or targeted
untruncated reads. All four candidates were read whole without truncation.

Root owns zero outcome/base proofs, parked and opaque producers, selected
expansion, run step and full induction. `ordinary_gates` owns native and finite
head arity. `opaque_meaning` owns sibling scans and finish. Those agents received
exact interface names, tuple order, and immutable candidate paths before
composition. This task adds no global history or language theorem.

No Haskell source changed. This task supplies no new Haskell fix for FINDINGS.
No old frozen or reconstructed evidence area changed. All completed files in
this owned area are read-only. Root may install copies and record any repairs.
