# Actual prepared history backward-language candidate

Recorded: 2026-10-28T17:59:29+01:00.
Candidate: `SourcePruningEnumerationPreparedResourceHistoryLanguage.lean`.
SHA-256: `b9a720059d7d46b4dba0ac85b22e3afb852cb59eb6440ae912f917cdd855dc1b`.
Size: 12403 bytes, 175 lines.
Status: bounded candidate complete; Root must compile it.

One theorem, `PreparedRecursive.ResourceHistory.sound`, consumes the ACTUAL
`ResourceHistory`. It introduces no decorated history type or per-head oracle.
The exact public argument order is history, actualNext, initial Canonical,
finalOutputHeap, whole final Discharged, ambient, assignment, final Satisfies.
The conclusion restores whole initial Satisfies at the original caller.
Both models use the fixed PCS residual interpretation.

`finalOutputHeap` is an explicit LOCAL lemma premise. The top driver theorem
must derive it from the same output's `OutcomeResourcesWithArity`; it must not
expose an assumed later heap. The local theorem derives each ordinary head
input Heap by `tail.arity_before` and then `completed.post.arity_before`.
It derives fresh projected arity from the prepared parent's own available
physical edge. It does not identify that parent with the original decoded value.

Ordinary child retention follows from the actual completed head, false callback,
remaining history and SAME final Discharged output. An actual nonterminal opaque
completion contradicts that Discharged output through the SAME callback/tail.
The opaque retained-bucket gate is therefore derived locally. Callback recording
uses its observed singleton and actual completed Packet for whole model
transport. Original prefix semantics restores the original recursive input.
The entered cache's original expandable/waiting equalities fit the literal
prepared head to its framed cache. No source/prepared node identity is used.

The whole candidate was read without truncation. Its imported API and relevant
exact core/source ranges were reviewed; whole source copies and SHA-256 values
are in the manifest. Static searches found no admitted proof, custom axiom,
native proof, unsafe proof, compiler budget option or linter suppression.
The two local irreducibility attributes match the existing opaque semantic
wrapper; they change no compiler budget or theorem premise.

No compiler, Git, native, network or board command ran. No repository file or
old frozen evidence changed. The preceding route audit is separately frozen in
`callbacks/history-semantics-audit-v1`. Root owns installation and all strict
checks. No global language theorem is claimed until Root checks this candidate
and derives its final-output arity in the top producer.
