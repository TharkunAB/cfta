# Actual prepared history backward-semantics route audit

Recorded: 2026-10-28T17:53:55+01:00.
Verdict: the route is direct composition. This report asserts no global theorem.

The smallest local goal is `PreparedRecursive.ResourceHistory.sound` on the
ACTUAL history. Its inputs are the literal history, actual restart decision,
initial Canonical storage, final output arity Heap, and whole final Discharged.
Its result is whole final Satisfies implies whole initial Satisfies for each
ambient environment and assignment. Use the fixed PCS residual interpretation
`fun guard term => holds formulas solver guard term = true`. The ordinary
semantic theorem does not supply an arbitrary residual interpretation.
The final arity Heap is a local lemma premise. The top producer must derive it.

## Exact induction route

- Stopped and done: return the same model.
- Parked: actualNext and `parked_tail_created_isolated` contradict the SAME final
  output Discharged. No parked backward lemma or dropped bucket premise is needed.
- Selected: actual prefix validity preserves Canonical. The receipt's actual
  false callback preserves Canonical for the recursive IH. Apply the IH to the
  same final model, preserving the exact callback caller and full memo state.
- Ordinary arm: `tail.arity_before finalOutputHeap` derives Heap at headCaller.
  `completed.post.arity_before` reflects that Heap to the actual local head
  input. `completed.freshArity_of_origin_heap` derives its projected arity.
  `completed_head_output_retained` derives every child retention gate from the
  exact completed head, callback, tail and final Discharged. Apply
  `sound_ordinary_callback_input`, then `prefix_semantics`.
- Opaque arm: if its original bucket is nonterminal, the literal opaque
  completion, actual completed Packet, actual false callback and same tail
  contradict Discharged via `completed_opaque_output_not_discharged`.
  Therefore terminal=true supplies the explicit retention disjunction.
  Restore the actual callback model through `recordTypes_success_semantics`.
  `HistoryAdmission.prepared_opaque_sound_retained` supplies narrowed input
  semantics, original resource recovery and actual complete-point stability.
  Apply `prefix_semantics` to restore the original recursive input.

The rich ordinary receipt's entered cache equals
`frame entered.core narrowed` by its ORIGINAL expandable/waiting equalities.
Use that literal cache equality to fit the existing ordinary semantic theorem.
The prepared node equality rewrites only the prepared witness. It does not
identify the original decoded source with that prepared node.

## Producer alignment and remaining work

The history and finite-arity producers may select different stable bounds.
Evaluate both runs at their sum. Determinism identifies their actual prepared
outcomes. Extract every emitted output's arity Heap from
`OutcomeResourcesWithArity` on that SAME outcome. No later Heap assumption is
needed in the top producer. All original Packet/Fits/Known/selection/mass and
PreparedReservation inputs remain unchanged, with original initial Heap.

No new history type, per-head arity oracle, forward Post arity shortcut, future
model invariant, or original-model callback policy is needed. Full Posts reflect
arity BACKWARD. Actual callback model transport uses the observed singleton
recording and the actual completed Packet's totality.

Remaining implementation: one actual ResourceHistory induction; a small
same-result producer alignment and per-output Heap extraction; then the
separate exact output/render assignment bridge. Canonical, whole Discharged and
whole final Satisfies remain explicit. Rendering success alone is insufficient
for Discharged because the renderer permits recursive boundary markers.

Root reported the full finite arity and old-history alignment default builds
PASS, first 17 strict PASS, and Audit81555 PASS at 17:52 CET. This child ran no
compiler, Git, native, network or board command. This is a route audit only.
The assigned source snapshots and exact reviewed line ranges are in
`manifest.json`. No repository or earlier frozen evidence changed.
