from pathlib import Path
P=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA/SourcePruningEnumerationPreparedFiniteHeadResources.lean')
O=Path('/tmp/mcfta-prepared-models-20261028/ordinary-head-models')
s=P.read_text();start=s.index('theorem head_finite_complete_resources\n');end=s.index(' := by\n',start)
decl=s[start:end].replace('theorem head_finite_complete_resources\n','theorem head_finite_complete_resources_accepting\n',1)
# Group the entire old returned conjunction. Keep its witnesses and fields exact.
a=decl.index('      (∀ extra,')
decl=decl[:a]+decl[a:].replace('      (∀ extra,','      ((∀ extra,',1)+') ∧\n'
observer='''      ∀ (ambient : InternedGuardedLanguage.Env Symbol)
        (assignment : Nat → Language.Term Symbol),
        Satisfies
          (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
            ambient caller.checked.native.machine.heap)
          (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
          assignment before.core →
        InternedGuardedLanguage.edgeMeaning (SourceEqualityPCSGuard.holds formulas solver)
          ambient edge (assignment uv) →
        ∃ (extended : Nat → Language.Term Symbol) (fragment : Fragments.Fragment Symbol) (afterCache : Cached),
          (∀ old < before.core.counter, extended old = assignment old) ∧
          Satisfies
            (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
              ambient caller.checked.native.machine.heap)
            (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
            extended before.core ∧
          receipt = .complete fragment middleCaller saved afterCache ∧
          Fragments.fill extended fragment = assignment uv ∧
          Satisfies
            (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
              ambient middleCaller.checked.native.machine.heap)
            (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
            extended afterCache.core'''
header=s[s.index('namespace MicroCFTA.'):start]
header=header.replace('open EnumerationState EnumerationSchedule','open EnumerationState EnumerationCorrectness EnumerationSchedule EnumerationDependencies')
header=header.replace('open SourcePruningEnumerationNodes\n','open SourcePruningEnumerationNodes SourcePruningEnumerationObservation\n')
header=header[:header.index('/-- A prepared parent')]
imports='''import MicroCFTA.SourcePruningEnumerationPreparedFiniteHeadResources
import MicroCFTA.SourcePruningEnumerationSelectedEdgeCoverage
import MicroCFTA.SourcePruningEnumerationSelectedEdgeAdmission
import MicroCFTA.SourcePruningEnumerationFinalizeLanguage

/-!
# Constructive acceptance at an actual prepared finite head

The complete prepared head resource packet is retained first.
The prepared parent supplies Available and closed facts separately from the
original stored handle. An original model and accepted edge construct the
same actual captured receipt. The new recursive callback keeps its exact
resource outcome. Its later outputs are not given a semantic model here.
-/
'''
proof=''' := by
  obtain ⟨bound, receipt, middleCaller, saved, middleMemos, middleInventory, resources⟩ :=
    head_finite_complete_resources holeKey fits admits graph templates checkEmpty edgesOf stop order
      metadata recursiveFuel seed formulas solver recursive inventory caller memos before uv handle scs
      parentEntry storedEdges depth free edge packet ready stored parentAvailable parentClosed selected incoming
      bounded known selectionMembers selectionLength capturedMass inherited initialMass inheritedLength reserved
  refine ⟨bound, receipt, middleCaller, saved, middleMemos, middleInventory, resources, ?_⟩
  intro ambient assignment satisfied accepted
  obtain ⟨running, _headPost, headQueries, _admitted, _pendingReceipt, _history,
    _cacheBounds, _headFits, _headKnown, headShape⟩ := resources
  obtain ⟨roots, paths, _storage, realized, counts, flags⟩ := packet.valid
  have inheritedModel : ∀ sc ∈ scs, Suspended.Holds assignment (assignment uv) sc := by
    have model := satisfied.1.2 uv
    simp only [heap, stored, Option.getD_some, slot, Fragments.slotSatisfies,
      List.forall_mem_map] at model
    exact model.2
  obtain ⟨tries, residual, _terms, projected, _valid, _termShape, _children,
    _length, allowed, _ownEqualities, _residualHolds⟩ :=
    SourcePruningEnumerationSelectedEdgeAdmission.selected_admission formulas solver inventory caller memos
      parentEntry storedEdges depth free edge scs packet.context parentAvailable selected ambient assignment
      (assignment uv) accepted inheritedModel
  obtain ⟨children, own⟩ := SourcePruningEnumerationRecursiveReservation.edge_shape_from_packet
    seed formulas solver inventory caller memos metadata before packet bounded known
    parentEntry storedEdges depth free parentAvailable edge selected
  have costBound := SourcePruningEnumerationRecursiveReservation.edge_cost_le seed inherited scs
    before.core.counter edge children own inheritedLength
  have actualCost : edgeCost scs before.core.counter edge =
      SourcePruningEnumerationSelectedEdge.cost edge scs before.core.counter tries := by
    simp only [edgeCost, allowed, ↓reduceIte, projected]
  have actualReserved : SourcePruningEnumerationIncomingReservation.Reserved bits seed
      (SourcePruningEnumerationSelectedEdge.cost edge scs before.core.counter tries) := by
    simpa only [actualCost] using reserved.edge costBound
  have bucketBound : ∀ sc ∈ scs, sc.var < before.core.counter :=
    ready.safe.1.values _ (List.mem_of_getElem? stored)
  have pending := EnumerationReferences.pending_inputs before.core packet.pending uv (some handle) scs stored
  have avoids := ready.avoids handle scs stored
  obtain ⟨r, n, p, h, k, actualCaller, middle, actualSaved, _final, _next, afterRoots, edgeResult,
    edgeRun, _post, _querySame, _growth, middlePaths, middleStorage, middleRealized, middleCounts,
    middleFlags, _origin, _retained, protects, _pendingHistory, _incomingHistory, shape,
    _returnedFits, _returnedKnown, edgeAccepting⟩ :=
    SourcePruningEnumerationSelectedEdge.complete_with_fragments_resources_accepting seed formulas solver
      inventory caller before checkEmpty parentEntry storedEdges depth free edge scs roots memos packet.context
      parentAvailable parentClosed selected ready.safe realized paths counts flags bucketBound pending
      allowed tries residual projected bounded actualReserved known
  obtain ⟨terms, termShape, childrenAccepted, guardHolds⟩ :=
    (InternedGuardedLanguage.edgeMeaning_all
      (SourceEqualityPCSGuard.holds formulas solver) ambient edge (assignment uv)).mp accepted
  obtain ⟨extended, fragment, agree, originalSatisfied, completed, filled, middleSatisfied⟩ :=
    edgeAccepting ambient assignment terms satisfied childrenAccepted
      (by simpa only [termShape] using guardHolds)
      (by simpa only [termShape] using inheritedModel)
  rcases shape with ⟨built, builtComplete, _middleSafe, fragmentBound, _fragmentPending, _fragmentSeparate⟩ |
    ⟨_fragments, _outer, _waiting, stopped⟩
  · subst edgeResult
    have sameFragment : built = fragment :=
      (SourcePruningEnumerationSelectedEdge.Result.complete.inj completed).1
    subst built
    have frame := protects uv ready.inside ready.root avoids
    have currentStored : middle.core.values[uv]? = some (.unenumerated (some handle) scs) :=
      frame.value.trans stored
    obtain ⟨fuel, after, finishRun, _raw, written, _finalStored, _finalFlag, _finalWaiting,
      _afterPaths, _afterCounts, _afterFlags, _afterStorage, _afterRealized, _afterSafe⟩ :=
      SourcePruningEnumerationFinalize.complete actualCaller.checked.native.machine.heap middle uv fragment
        (.unenumerated (some handle) scs) currentStored afterRoots middlePaths middleCounts middleFlags
        middleStorage fragmentBound middleRealized
    let padding := r + n + p + h + k + fuel
    let work := bound + padding
    have rl : r ≤ work := by dsimp [work, padding]; omega
    have nl : n ≤ work := by dsimp [work, padding]; omega
    have pl : p ≤ work := by dsimp [work, padding]; omega
    have hl : h ≤ work := by dsimp [work, padding]; omega
    have kl : k ≤ work := by dsimp [work, padding]; omega
    have fl : fuel ≤ work := by dsimp [work, padding]; omega
    have selectedAt := edgeRun (work - r) (work - n) work work (work - k) pl hl
    simp only [Nat.add_sub_of_le rl, Nat.add_sub_of_le nl, Nat.add_sub_of_le kl] at selectedAt
    have finalizedAt := finishRun (work - fuel)
    simp only [Nat.add_sub_of_le fl] at finalizedAt
    have capturedAt : SourcePruningEnumerationCapturedEdge.run checkEmpty work work work work work
        uv scs edge caller before memos.query = some (.complete fragment actualCaller actualSaved after) := by
      simp only [SourcePruningEnumerationCapturedEdge.run, selectedAt, finalizedAt, Option.map_some]
    have receiptSame : receipt = .complete fragment actualCaller actualSaved after :=
      Option.some.inj ((running padding).symm.trans capturedAt)
    have reached : advance receipt = some (middleCaller, saved) := by
      rcases headShape with ⟨unsupported, _allowed, _projected⟩ |
        ⟨_outcome, advanced, _callback, _resources, _captured⟩
      · rw [receiptSame] at unsupported
        cases unsupported
      · simpa only [headQueries] using advanced
    rw [receiptSame] at reached
    change some (actualCaller, actualSaved) = some (middleCaller, saved) at reached
    have sameEndpoint := Option.some.inj reached
    have sameCaller : actualCaller = middleCaller := congrArg Prod.fst sameEndpoint
    have sameQueries : actualSaved = saved := congrArg Prod.snd sameEndpoint
    have finalSatisfied : Satisfies
        (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
          ambient actualCaller.checked.native.machine.heap)
        (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
        extended after.core := by
      have selfValue : Fragments.fill extended fragment = extended uv :=
        (filled.trans termShape.symm).trans (agree uv ready.inside).symm
      exact (SourcePruningEnumerationFinalize.written_semantics middle.core after.core uv fragment
        (List.getElem?_eq_some_iff.mp currentStored).1 written
        (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
          ambient actualCaller.checked.native.machine.heap)
        (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true) extended).mpr
        ⟨EnumerationFrame.neutralize_satisfies
          (SourcePruningEnumerationNativeLanguage.handles (SourceEqualityPCSGuard.holds formulas solver)
            ambient actualCaller.checked.native.machine.heap)
          (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
          extended uv middle.core middleSatisfied, selfValue⟩
    refine ⟨extended, fragment, after, agree, originalSatisfied, ?_, filled.trans termShape.symm, ?_⟩
    · simpa only [sameCaller, sameQueries] using receiptSame
    · simpa only [sameCaller] using finalSatisfied
  · rw [stopped] at completed
    cases completed

end MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources
'''
result=imports+header+'/-- Retain every prepared head resource and construct its actual accepted captured receipt. -/\n'+decl+observer+proof
p=O/'drafts/v1/SourcePruningEnumerationPreparedFiniteHeadCoverage.lean'
assert not p.exists();p.write_text(result)
# Retain the entire original declaration and literal recovery under name/grouping only.
old=s[start:end]
recovered=decl.removesuffix(') ∧\n').replace('theorem head_finite_complete_resources_accepting\n','theorem head_finite_complete_resources\n',1)
recovered=recovered.replace('      ((∀ extra,','      (∀ extra,',1)
assert recovered==old
(O/'contracts').mkdir(exist_ok=True)
(O/'contracts/old-entire-declaration.txt').write_text(old)
(O/'contracts/recovered-entire-declaration.txt').write_text(recovered)
