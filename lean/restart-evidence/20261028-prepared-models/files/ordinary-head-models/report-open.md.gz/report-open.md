# Prepared head models and indexed sibling coverage

The prepared head and sibling observers are checked by Root. Both use the actual new worker and retain their complete existing resource results. This bundle remains OPEN. No seal or publication claim is made.

Only /tmp/mcfta-prepared-models-20261028/ordinary-head-models was written. No compiler, build, native program, Git, network or board operation was run by this owner. Older review areas were not changed.

## Prepared head interface and exact old packet

New module: SourcePruningEnumerationPreparedFiniteHeadCoverage.
Namespace: MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources.
Public theorem: head_finite_complete_resources_accepting.

The theorem fixes bound, receipt, middleCaller, saved, middleMemos and middleInventory before the universal semantic observer. It keeps the ENTIRE existing PreparedFiniteHeadResources returned conjunction under those same witnesses. This includes all five-axis stable head equations, the actual full Post/Memos, admission, pending constraints, fragment history, head cache bounds, afterHead resources, the exact new-worker callback equation/outcome, and the complete or stopped callback packet.

The original head producer is called once. The current prepared ordinary parent's Available and closed facts remain separate from the original SOME stored handle and inherited bucket. The proof does not rewrite or re-enter that original handle. No new operational definition or helper predicate is introduced.

For every original head-input assignment satisfying the native cache and accepting the selected edge at assignment uv, the appended observer constructs an extension, actual fragment and actual final cache. It preserves all variables below the original counter and original cache satisfaction. It identifies the SAME fixed receipt as complete at the SAME fixed middleCaller and saved queries. The fragment fills to the original selected term. Satisfaction at that actual captured endpoint is derived.

The theorem does not assert satisfaction of the callback's output list. Its appended model concerns actual completed captured-head input to that callback. The callback may stop. Its full exact resource outcome remains in the original packet.

## How the prepared-parent dependency is discharged

NativeHeadCoverage and CapturedEdgeCoverage use a lookup identifying the original stored handle with their ordinary parent. That premise cannot be supplied for an independently prepared parent. The new proof does not supply it.

Existing SelectedEdgeCoverage already uses actual parent Available, closed and selected-row membership. The proof derives every inherited Suspended.Holds fact from the original model and actual stored bucket. SelectedEdgeAdmission derives arity and the actual successful projection from those Holds facts, actual Context and edge acceptance. Packet and original Fits/known guards derive child/projection shape bounds. The original HeadReserved condition pays the exact selected-edge cost. No universal Ranges or future cache/model premise is added.

SelectedEdgeCoverage supplies the actual selected-edge run and a constructive model extension. Its stopped case contradicts the accepted model. In its completed case, the actual protected raw slot retains the original stored handle. Finalize.complete derives the real captured-slot write. A sufficiently large common diagonal aligns that actual selected run and actual finalizer with the old head producer's stable family. Equality of these actual runs identifies the SAME fixed receipt. Its actual advance identifies the SAME old middleCaller and saved queries.

This replay uses stability at sufficient work fuel. It does not infer arbitrary-low-fuel uniqueness or monotonicity of an unsupported raw observation. The original returned work bound is unchanged and remains uniform over all models. Auxiliary proof replay fuel may be selected inside the semantic proof; it is not a replacement producer bound.

The new final cache model follows from Finalize.written_semantics and neutralize_satisfies. The old-variable agreement at uv identifies the filled fragment with the final captured assignment value. Final Satisfies is a conclusion, not an input.

## Head source revisions and actual checks

Owned head-v1: 242 lines, 17370 bytes, SHA256 711826500d4159cf768ba872a5613e711674a2904131b8fc92df0e91b50281ad.
Root checked this exact source. It failed with a 187-byte raw log: unknown identifier completed after an ambiguous subst chose the semantic equation.

Owned head-v2: 241 lines, 17391 bytes, SHA256 1c22b750c3fa8c270708866c6bf891d15dbe1dbff55f66a636ecea524657fc6d.
It replaces that substitution with explicit constructor equality and rewrites the operational equality at selectedAt. The public declaration is unchanged. Root's head-models-v2 strict check passes with an empty raw log.

Root then removed the supplied Complete binder, imported the existing PreparedFiniteResources theorem and derived recursive locally with the proved NEW PreparedRecursive.finite_complete. The old producer call still uses that genuine local completion theorem. Every returned field and semantic observer is unchanged. This strengthened root-head-v3 source is retained here. Its SHA256 is 73d8b6b7530dacdd5c23baa64b61a7305c943a9effebb4c8843f7b0816ec3eca. Root's head-models-v3 strict check passes with an empty raw log.

The complete old prepared-head declaration is 4615 bytes, SHA256 d1d0b4332770bbc4818c182a7dbe54e5d127651857f72f01cf383cd410598127. Literal recovery removes the theorem-name suffix and appended observer/grouping. For root-head-v3 it also restores the explicitly discharged Complete binder. These differences are recorded. There is no claim that the stronger current public theorem still requires that binder.

All three actual tested snapshots, reports and raw logs are retained under evidence. They record warningAsError and all linters, memory.max/high 4294967296 bytes and zero swap. This owner read the complete 187-byte failed log and exact root-v3 change. No source-only revision is mislabeled as a compiler failure.

## Checked prepared sibling extension

New module: SourcePruningEnumerationPreparedFiniteSiblingCoverage.
Namespace: MicroCFTA.SourcePruningEnumerationPreparedFiniteSiblingResources.
Public theorem: alternatives_finite_complete_resources_accepting.

Checked source: drafts/sibling-v2/SourcePruningEnumerationPreparedFiniteSiblingCoverage.lean, 475 lines, 34752 bytes, SHA256 4f3bde9dc1efcc81dd298856a140ffb47572fc58c89a0fa4a5558875176569b5. Root checked these exact bytes in sibling-models-v1. The first actual strict check passes with an empty raw log. Its tested snapshot, installed source and immutable sibling-v2 source match exactly. The actual report records warningAsError/all linters, measured 4 GiB memory.max/high and zero swap. The earlier sibling-v1 remains source-only and untested.

This is the existing indexed continuation-coverage induction adapted to the actual NEW prepared worker, NEW Failure, NEW OutcomeResources, PreparedReservation stages and current prepared certificates. It uses the strengthened actual prepared head theorem. It retains the entire existing prepared sibling packet before the universal observer. It derives no old-worker completion or semantic result by identity.

The exact entire current prepared sibling resource declaration is 4181 bytes, SHA256 ba99eb41ce654ad6251588f6acabf6bede4db3c70d36337b817e64ec8b7e012a. Removing the observer/theorem-name suffix and restoring the discharged Complete binder recovers it byte for byte. Every old return field and witness remains. Sibling-v1, which still supplied Complete, and its exact directional change to sibling-v2 remain as source-only history.

No supplied Complete remains in sibling-v2. Each actual head theorem derives it from proved finite_complete. The direct sibling induction does not introduce an unused local completion witness. It does not ask for semantic correctness of recursive outcomes.

The observer takes the chosen ORIGINAL list index and getElem equation. Duplicated edges retain their exact occurrence. Prefix support is required only for earlier elements of selectedEdges.take index, and only when their actual arity check allows continuation. These conditions exclude an earlier unsupported projection; they do not assume a future invocation or scan completion.

At every returned sufficient fuel, the conclusion identifies an actual event index, exact edge occurrence, actual input Inventory/Caller/full Memos, completed actual prefix run, prefix receipt length, original-to-input Post/Packet/resource reservation, actual completed CapturedEdge run, actual whole-list HookInvocation, actual branch Post/full Memos and current ReceiptAt certificate.

The result is either the chosen accepted occurrence with the constructed same-model extension and actual fragment fill, OR a strictly earlier actual stopped continuation hook. The earlier-stop alternative retains its exact hook outputs, new Failure reason, optional endpoint, aggregate stopped scan equation and OutcomeResources. A chosen hook may itself stop after its captured head is reached; that remains the chosen-event alternative. A stopping completed receipt is not incorrectly included in processed receipts.

For a completed earlier hook, the suffix starts at its actual reached Caller/full Memos. Prepared-parent availability transfers through that same actual Post. The captured enumeration cache and metadata stay fixed. Native Satisfies transports through actual Keeps in the correct direction. The reverse direction transfers the chosen extension's original cache model back to the initial scan caller. The common sum aligns head and suffix fuel, including the actual new recursive callback. No inter-sibling cache or memo endpoint is invented.

## Source scope and open boundaries

source-index.json retains exact whole copies and literal cuts. The selected-edge interface, admission proof, finalizer and assignment laws, native advance, existing prepared resource packet and old indexed coverage induction are source-connected. Whole-file identities are distinct from indicated read cuts. Initial capture retains twelve inputs; the checked head and sibling dependencies extend that index. All cuts use exact line intervals and bytes.

The constructive head result closes the prepared-parent admission gap for one actual accepted selected edge. The sibling result adds a real indexed chosen-event-or-earlier-hook-stop law. Neither proves that every recursive callback preserves an accepted model or emits it. In particular, a later chosen accepted alternative does not itself exclude a stopped hook on an earlier incompatible alternative. That actual continuation boundary must remain explicit in the next semantic induction.

Original-root preparation/model composition, policy/template/typing origins, sufficient recursive depth, global accepted-output coverage, new history/carrier/render closure and physical Haskell correspondence remain separate obligations. No new Haskell defect or required patch is claimed. This review area remains OPEN for Root compiler/integration/public/document evidence.
