from pathlib import Path
import hashlib,json,datetime
A=Path('/tmp/mcfta-prepared-models-20261028');O=A/'ordinary-head-models';R=Path('/home/tritlo/Code/mcfta')
assert not (O/'FROZEN.json').exists()
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():assert p.read_bytes()==b,p
 else:p.write_bytes(b)
 return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def cp(p,q):return save(q,p.read_bytes())
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
index=json.loads((O/'source-index.json').read_text())
def pin(p,scope,spans=()):
 b=p.read_bytes();short=sha(b)[:12];record=next((s for s in index['sources'] if s['source']==str(p) and s['whole']['sha256']==sha(b)),None)
 if not record:
  record={'source':str(p),'whole':save(O/'sources'/f'{p.name}.{short}.whole',b),'cuts':[],'read_scope':scope};index['sources'].append(record)
 lines=b.splitlines(keepends=True)
 for lo,hi in spans:
  bb=b''.join(lines[lo-1:hi]);c={**save(O/'cuts'/f'{p.name}.{short}.L{lo}-L{hi}.txt',bb),'first_line':lo,'last_line':hi}
  if c not in record['cuts']:record['cuts'].append(c)
 return record
for n in ['source-validation.json','public-validation.json','audit-summary.json','document-inverse.json','source-head.txt','published-base.txt','strict-checks.json','modules.json','public-cuts.json','new-public-declarations.json','public-declarations.json','public-definitions.json']:
 p=A/n;cp(p,O/'final-evidence'/n);pin(p,'Whole current metadata read or identity/status checked. This does not assert review of every referenced proof.')
sv=json.loads((A/'source-validation.json').read_text());strict=json.loads((A/'strict-checks.json').read_text());pv=json.loads((A/'public-validation.json').read_text())
assert sv['status']==pv['status']=='pass' and len(sv['commands'])==25 and sv['failures']==7
commands=[]
for c in sv['commands']:
 d=A/c['folder'];rep=json.loads((d/'report.json').read_text());raw=(d/'raw.log').read_bytes()
 assert rep['exit_code']==c['exit_code'] and rep['bytes']==len(raw)==c['bytes'] and rep['sha256']==sha(raw)==c['sha256']
 limits=rep['cgroup_limits'];assert limits['memory.max']==limits['memory.high']=='4294967296' and limits['memory.swap.max']=='0'
 for p in sorted(d.rglob('*')):
  if p.is_file() and p.suffix in {'.lean','.json','.log','.diff','.patch','.txt'}:cp(p,O/'evidence'/c['folder']/p.relative_to(d))
 if 'source_sha256' in rep:
  candidates=list(d.rglob('*.lean'));assert any(sha(p.read_bytes())==rep['source_sha256'] for p in candidates),(d,'tested source identity missing')
 commands.append({'folder':c['folder'],'report':rep,'read_scope':'Own head/sibling strict reports/raw and final aggregate/Audit/public evidence read. Other historical raw logs preserved and hash-checked, not all read semantically by this owner.'})
assert sum(c['report']['exit_code']!=0 for c in commands)==7
for name,h in sv['source_hashes'].items():
 p=R/'lean/MicroCFTA'/f'{name}.lean';assert sha(p.read_bytes())==h
 tested=A/strict[name]/'MicroCFTA'/p.name;assert tested.read_bytes()==p.read_bytes()
 pin(p,'Installed final source identity matches actual final strict snapshot. Whole semantic proof review is limited to the two owned head/sibling modules; other six are dependency/status provenance.')
# Confirm owned identities did not change after their already reviewed final strict receipts.
assert sv['source_hashes']['SourcePruningEnumerationPreparedFiniteHeadCoverage']=='73d8b6b7530dacdd5c23baa64b61a7305c943a9effebb4c8843f7b0816ec3eca'
assert sv['source_hashes']['SourcePruningEnumerationPreparedFiniteSiblingCoverage']=='4f3bde9dc1efcc81dd298856a140ffb47572fc58c89a0fa4a5558875176569b5'
full=A/'public-readback-final/raw.log';prior=A/'prior-public-readback/raw.log';append=A/'new-public-blocks.txt'
assert full.read_bytes()==prior.read_bytes()+append.read_bytes()
assert full.stat().st_size==pv['bytes']==1902411 and sha(full.read_bytes())==pv['sha256']
assert prior.stat().st_size==pv['prior_bytes']==1774860 and append.stat().st_size==pv['new_bytes']==127551
assert sha(append.read_bytes())==pv['new_sha256']
for p in [full,prior,append,A/'public-readback-final/public.lean']:
 cp(p,O/'final-public'/p.relative_to(A));pin(p,'Whole public artifact preserved and exact-prefix/identity checked. Semantic read scope consists of the two complete owned public blocks; no all-eight/current-or-prior public-block read is claimed.')
blocks=[]
for name,size in [('SourcePruningEnumerationPreparedNativeHookResources.head_finite_complete_resources_accepting',13324),('SourcePruningEnumerationPreparedFiniteSiblingResources.alternatives_finite_complete_resources_accepting',22877)]:
 p=A/'public-cuts'/f'{name}.txt';b=p.read_bytes();assert len(b)==size and full.read_bytes().count(b)==1 and append.read_bytes().count(b)==1
 pin(p,'WHOLE complete printed signature and axiom block read, no elision.',[(1,len(b.splitlines()))]);cp(p,O/'final-public'/p.name);blocks.append({'declaration':name,**save(O/'final-public'/p.name,b)})
# Current doc insertion records do not contain offsets. Locate each exact literal insertion once.
inv=json.loads((A/'document-inverse.json').read_text());assert len(inv)==9
common=(A/'document-insertions/common.md').read_bytes();findings=(A/'document-insertions/findings.md').read_bytes();doc_records=[]
for p in [A/'document-insertions/common.md',A/'document-insertions/findings.md']:
 pin(p,'WHOLE exact new insertion text read.',[(1,len(p.read_bytes().splitlines()))]);cp(p,O/'final-documents'/p.name)
for rel,d in inv.items():
 p=R/rel;current=p.read_bytes();insert=findings if rel=='FINDINGS.md' else common
 assert len(insert)==d['inserted_bytes'] and sha(insert)==d['inserted_sha256'] and sha(current)==d['after_sha256']
 assert current.count(insert)==1
 offset=current.index(insert);old=current[:offset]+current[offset+len(insert):]
 prior_doc=A/'prior-documents'/rel;assert prior_doc.read_bytes()==old and sha(old)==d['before_sha256']
 current_meta=cp(p,O/'final-documents/current'/rel);prior_meta=cp(prior_doc,O/'final-documents/prior'/rel);insert_meta=save(O/'final-documents/insertions'/(rel.replace('/','--')+'.txt'),insert)
 lo=current[:offset].count(b'\n')+1;hi=lo+len(insert.splitlines())-1
 assert b''.join(current.splitlines(keepends=True)[lo-1:hi])==insert
 pin(p,'ONLY exact new insertion semantically reviewed. Whole current body is retained for inverse identity; no whole giant historical-body read.',[(lo,hi)])
 pin(prior_doc,'Whole prior document preserved only as inverse-byte evidence; historical body not reread semantically.')
 doc_records.append({'source':str(p),'offset':offset,'current':current_meta,'prior':prior_meta,'insert':insert_meta,'inverse_exact':True})
note=R/'lean/notes-current-prepared-models.md';b=note.read_bytes();assert len(b)==13035 and sha(b)=='50a5a880023726b733d5a1e252e6f703cd32594cea8610d5d55b0fd2ac042e66'
pin(note,'WHOLE final new note read.',[(1,len(b.splitlines()))]);cp(note,O/'final-documents'/note.name)
# The aggregate failure's Audit source is declared as a late snapshot/reconstruction, not a contemporaneous snapshot.
late=A/'audit-build-final/late-source-snapshot.json';pin(late,'Whole source provenance disclaimer read; retains after-failure-before-repair snapshot timing and reconstruction.')
dump(O/'source-index.json',index)
dump(O/'final-command-identities.json',{'commands':commands,'command_count':25,'actual_failures':7,'execution_owner':'Root','owner_no_compiler_build_git_native_network_board':True,'failure_read_scope':'Own187B head failure fully read; all seven failures retained/hash-checked. Root states all were read before repair; this owner does not claim all large logs were semantically read.'})
dump(O/'document-inverse-checks.json',{'status':'pass','documents':doc_records,'new_note':save(O/'final-documents'/note.name,b),'read_scope':'Whole new note and nine exact insertion regions; old bodies inverse-byte checked only.'})
dump(O/'final-public-review.json',{'status':'CLEAR','whole_read_blocks':blocks,'all_new_blocks_read':False,'public_theorem_blocks':449,'printed_definitions':41,'exact_old_prefix_bytes':1774860,'public_bytes':1902411,'public_sha256':pv['sha256'],'axioms':pv['axioms']})
dump(O/'final-review-status.json',{'status':'CLEAR; authorized final exact-set seal pending local self-verification','source_head':(A/'source-head.txt').read_text().strip(),'note_bytes':13035,'note_sha256':sha(b),'source_records':len(index['sources']),'literal_cuts':sum(len(s['cuts']) for s in index['sources']),'timestamp':datetime.datetime.now().astimezone().isoformat()})
print(json.dumps({'status':'final capture PASS','sources':len(index['sources']),'cuts':sum(len(s['cuts']) for s in index['sources']),'commands':25,'failures':7,'document_inverses':9,'owned_public_blocks':2}))
