# Exact inspected source excerpts

Source audit only. No new compiled theorem.

## lean/MicroCFTA/SourceRecursiveIntersectionCompile.lean

```lean
-- lines 14-33

/-- A node request retains its domain and ordered original operands. -/
def requestNode (domain : Interned DomainKey) (left right : Value Symbol Guard) : Code Symbol Guard (Value Symbol Guard) :=
  .node ⟨domain, left, right⟩ .pure

/-- A row request retains its domain and ordered complete edge records. -/
def requestEdge (domain : Interned DomainKey) (left right : EdgeValue Symbol Guard) : Code Symbol Guard (EdgeValue Symbol Guard) :=
  .edge ⟨domain, left, right⟩ .pure

/-- Unsupported operands retain their original references. -/
def unsupported (left right : Value Symbol Guard) : Code Symbol Guard A :=
  .fail (.unsupported left.referenceOf right.referenceOf)

/-- Mu entry allocates the actual extended domain before requesting the two original bodies. -/
def compileMu (domain : Interned DomainKey) (left right : Value Symbol Guard) : Code Symbol Guard (Value Symbol Guard) :=
  match identity left, identity right with
  | some first, some second =>
      .enter domain left right first second fun entered =>
        .node ⟨entered, body left, body right⟩ fun value =>
          .optionalBinder (pair first second) value .pure
-- lines 36-43
/-- Original free binding lookup precedes the next physical node request. -/
def compileReference (domain : Interned DomainKey) (name : Nat) (other : Value Symbol Guard) (left : Bool) :
    Code Symbol Guard (Value Symbol Guard) :=
  if name ∈ names domain.key then
    .read name fun found => match found with
      | some bound => if left then requestNode domain bound other else requestNode domain other bound
      | none => .fail (.missingPayload name)
  else .fail (.missingBinder name)
-- lines 54-85
def compileRows [DecidableEq Symbol] (domain : Interned DomainKey) (left right : List (EdgeValue Symbol Guard)) :
    Code Symbol Guard (Value Symbol Guard) :=
  (walk (fun rows => requestEdge domain rows.1 rows.2) (pairs left right)).bind fun values => .work (makeNode values) .pure

/-- Compile the full physical source branch selector without evaluating recursive requests. -/
def compileNode [DecidableEq Symbol] (request : NodeRequest Symbol Guard) : Code Symbol Guard (Value Symbol Guard) :=
  let domain := request.domain
  let left := request.left
  let right := request.right
  match decision domain.key left right with
  | .empty => .pure .empty
  | .reset => requestNode IntersectionEmptyDomain.emptyDomain left right
  | .self => .pure left
  | .swap => requestNode domain right left
  | .repeated key => .pure (repeatedValue key)
  | .bothMu | .leftMu | .rightMu => compileMu domain left right
  | .leftUnion => match left with
    | .union _ members _ _ => (walk (fun member => requestNode domain member right) members).bind fun values => .work (makeUnion values) .pure
    | _ => unsupported left right
  | .rightUnion => match right with
    | .union _ members _ _ => (walk (fun member => requestNode domain left member) members).bind fun values => .work (makeUnion values) .pure
    | _ => unsupported left right
  | .leftReference => match left with
    | .reference (.interned name) => compileReference domain name right true
    | _ => unsupported left right
  | .rightReference => match right with
    | .reference (.interned name) => compileReference domain name left false
    | _ => unsupported left right
  | .ordinary => match left, right with
    | .node _ first _ _, .node _ second _ _ => compileRows domain first second
    | _, _ => unsupported left right
  | .unsupported => unsupported left right
```

## lean/MicroCFTA/SourceRecursiveIntersectionControl.lean

```lean
-- lines 47-55
  left.referenceOf == .empty || right.referenceOf == .empty

/-- Closed calls reset a nonempty free environment before the self shortcut. -/
def reset (domain : DomainKey) (left right : Value Symbol Guard) : Bool :=
  left.free.isEmpty && right.free.isEmpty && !domain.free.isEmpty

/-- Canonical source equality and stored closedness select the existing payload. -/
def closedSelf (left right : Value Symbol Guard) : Bool :=
  left.referenceOf == right.referenceOf && left.free.isEmpty
-- lines 77-91

/-- Read the exact physical source guard order and recursive payload branch. -/
def decision (domain : DomainKey) (left right : Value Symbol Guard) : Branch :=
  if hasEmpty left right then .empty
  else if reset domain left right then .reset
  else if closedSelf left right then .self
  else if greater left right then .swap
  else match identity left, identity right with
  | some first, some second =>
      if pair first second ∈ domain.seen then .repeated (pair first second)
      else payload left right
  | _, _ => .unsupported

/-- The repeated-pair branch returns the actual source RecIntersect placeholder. -/
def repeatedValue (key : Nat × Nat) : Value Symbol Guard := .reference (.intersection key.1 key.2)
```

## lean/MicroCFTA/SourceRecursiveIntersectionNative.lean

```lean
-- lines 51-64
      | .pending pending after => .blocked (.constructor pending) code (advance state { state.machine with heap := after })
  | .node request next =>
      let selected := lookupNode width request state
      match selected.1 with
      | .direct actual => .yielded ((compileNode actual).bind next) selected.2
      | .memoized handle =>
          let demanded := demandNode handle selected.2
          match demanded.1 with
          | .absent => .blocked (.absentNode handle) code demanded.2
          | .busy => .blocked (.nodeBusy handle) code demanded.2
          | .ready value => .yielded (next value) demanded.2
          | .evaluate actual =>
              .yielded ((compileNode actual).bind fun value => .finishNode handle value (next value)) demanded.2
  | .edge request next =>
```

## lean/MicroCFTA/SourceEqualityNativeDemand.lean

```lean
-- lines 57-100

/-- Sentinel demand retains the canonical empty equality-field allocation before direct edge interning. -/
def sentinel (request : EdgeRequest Symbol Guard) (next : EdgeValue Symbol Guard → Code Symbol Guard Output)
    (state : State width) : Outcome width Output :=
  .yielded (.code ((SourceEqualityNativeCheckedCode.sentinel request.left).bind next))
    {state with operations := SourceEqualityMkEdgeAllocation.emptyField state.operations}

/-- Check a published original edge before compiling any child request. -/
noncomputable def body (request : EdgeRequest Symbol Guard) (next : EdgeValue Symbol Guard → Code Symbol Guard Output)
    (state : State width) : Outcome width Output :=
  if request.left.children.length ≠ request.right.children.length then sentinel request next state
  else
    match SourceEqualityConstraintFieldLookup.load request.left.entry.key.constraint state.operations.constraints with
    | .error message => .constraintError message state
    | .ok none => .blocked (.missingField request.left.entry.key.constraint) (.edgeBody request next) state
    | .ok (some first) =>
        match SourceEqualityConstraintFieldLookup.load request.right.entry.key.constraint state.operations.constraints with
        | .error message => .constraintError message state
        | .ok none => .blocked (.missingField request.right.entry.key.constraint) (.edgeBody request next) state
        | .ok (some second) =>
            let checked := SourceEqualityIntersectionEdgeAllocation.run GuardStructuralOrder.le first second
              request.left.children.length request.right.children.length state.operations
            let after := {state with operations := checked.2}
            match checked.1 with
            | .error message => .constraintError message after
            | .ok .mismatch | .ok .rejected => sentinel request next after
            | .ok (.ready combined) =>
                .yielded (.code ((SourceEqualityNativeCheckedCode.children request.domain request.left request.right combined).bind next)) after

/-- One instruction retains native publication and demand while replacing the eager edge body. -/
noncomputable def step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (control : Control Output) (state : State width) : Outcome width Output :=
  match control with
  | .edgeBody request next => body request next state
  | .code (.edge request next) =>
      let selected := lookupEdge width request state.native
      let demanded := demandEdge selected.1 selected.2
      let after := {state with native := demanded.2}
      match demanded.1 with
      | .absent => .blocked (.native (.absentEdge selected.1)) control after
      | .busy => .blocked (.native (.edgeBusy selected.1)) control after
      | .ready value => .yielded (.code (next value)) after
      | .evaluate actual =>
          .yielded (.edgeBody actual (fun value => .finishEdge selected.1 value (next value))) after
```

## lean/MicroCFTA/SourceRecursiveIntersectionMemo.lean

```lean
-- lines 16-18
/-- The actual source memo key retains shifted domain identity and ordered tagged operands. -/
def requestKey (width : Nat) (domain : Interned DomainKey) (left right : Value Symbol Guard) : Option (Triple width) :=
  sourceKey width domain left.referenceOf right.referenceOf
-- lines 29-32

/-- Swapping operands retains each source machine bound without normalizing the ordered request key. -/
theorem KeySafe.swap (safe : KeySafe width domain left right) : KeySafe width domain right left := by
  obtain ⟨positive, bounded, first, second, firstInput, secondInput, firstSafe, secondSafe⟩ := safe
```

## lean/MicroCFTA/SourceRecursiveIntersectionDomain.lean

```lean
-- lines 18-31
/-- The source domain's free-map keys are its enclosing Mu identities. -/
def names (domain : DomainKey) : List Nat := domain.free.map Prod.fst

/-- Source binder entries retain the original Mu under that same identity. -/
def Typed (domain : DomainKey) : Prop := ∀ binding ∈ domain.free, binding.2 = NodeRef.mu binding.1

/-- Every source free binding has its actual complete physical Mu payload. -/
def AvailableBindings (state : State Symbol Guard) (domain : DomainKey) : Prop :=
  ∀ name ∈ names domain, ∃ entry body depth ordinary,
    entry.identity = name ∧ Available state (.mu entry body depth ordinary)

/-- Extend the source map and recursive-pair set, then read both in canonical key order. -/
def extend (domain : DomainKey) (bound : List Nat) (pair : Nat × Nat) : DomainKey :=
  ⟨(sortedSet (bound ++ names domain)).map (fun name => (name, NodeRef.mu name)), sortedSet (pair :: domain.seen)⟩
```

## lean/MicroCFTA/SourceSynthesisUniverseClosedResetSteps.lean

```lean
-- lines 21-41
/-- The literal original Mu entry retains a nonempty free map independently of later effects. -/
theorem mixed_entry_nonempty_free_map
    (domains : Cache.State IntersectionFlatMemoKeyDomain.DomainKey) (valid : Cache.Valid domains)
    (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard)
    (pattern : Value Symbol Guard) (patternId : Nat) :
    let universeValue : Value Symbol Guard := .mu entry body depth ordinary
    let original := enter domains IntersectionEmptyDomain.emptyKey universeValue pattern entry.identity patternId
    original.1.key.free.isEmpty = false := by
  let universeValue : Value Symbol Guard := .mu entry body depth ordinary
  let original := enter domains IntersectionEmptyDomain.emptyKey universeValue pattern entry.identity patternId
  have added : entry.identity ∈ (bindings universeValue pattern).map Prod.fst := by
    change entry.identity ∈ entry.identity :: (binder pattern).map Prod.fst
    exact List.mem_cons_self
  have originalKey := SourceRecursiveIntersectionSchedule.entered_key domains valid
    IntersectionEmptyDomain.emptyKey universeValue pattern entry.identity patternId
  have named : entry.identity ∈ names original.1.key := by
    rw [originalKey]
    exact (extend_names _ _ _ _).mpr (Or.inl added)
  change original.1.key.free.isEmpty = false
  cases freeMap : original.1.key.free with
  | nil => simp only [names, freeMap, List.map_nil, List.not_mem_nil] at named
-- lines 44-64
/-- Positive-fuel closed calls preserve Empty priority or reset to the exact lower-fuel call. -/
theorem execute_closed_nonempty_domain_step
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (fuel : Nat)
    (domain : Interned IntersectionFlatMemoKeyDomain.DomainKey)
    (nonempty : domain.key.free.isEmpty = false)
    (left right : Value Symbol Guard) (leftClosed : left.free = []) (rightClosed : right.free = [])
    (state : Machine Symbol Guard) :
    execute emptyGuard conjoin (fuel + 1) domain left right state =
      if hasEmpty left right = true then .done .empty state
      else execute emptyGuard conjoin fuel IntersectionEmptyDomain.emptyDomain left right state := by
  by_cases empty : hasEmpty left right = true
  · have selected := empty_first domain.key left right empty
    rw [ite_eq_left empty, execute]
    simp only [onNode, selected]
  · have noEmpty : hasEmpty left right = false := by
      cases value : hasEmpty left right <;> simp_all
    have restart : reset domain.key left right = true := by
      simp [reset, leftClosed, rightClosed, nonempty]
    have selected := reset_first domain.key left right noEmpty restart
    rw [ite_eq_right empty, execute]
```

## lean/MicroCFTA/SourceSynthesisUniverseOffDiagonalReferenceControl.lean

```lean
-- lines 21-41
/-- Three native steps return the body/Mu cutoff and the exact reached domain cache. -/
theorem execute_ref_self_off_diagonal
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (u b : Interned NodeKey) (rows : List (EdgeValue Symbol Guard))
    (depth ordinary : Value Symbol Guard)
    (domain : Interned IntersectionFlatMemoKeyDomain.DomainKey) (state : Machine Symbol Guard)
    (facts : Facts state.heap) (cacheValid : Cache.Valid state.domains)
    (universeAvailable : Available state.heap
      (.mu u (.node b rows 0 [.interned u.identity]) depth ordinary))
    (bound : u.identity ∈ SourceRecursiveIntersectionDomain.names domain.key)
    (seen : pair b.identity u.identity ∈ domain.key.seen)
    (fresh : pair u.identity u.identity ∉ domain.key.seen) :
    let universeValue : Value Symbol Guard := .mu u (.node b rows 0 [.interned u.identity]) depth ordinary
    let reference : Value Symbol Guard := .reference (.interned u.identity)
    let entered := SourceRecursiveIntersectionEnvironment.enter state.domains domain.key
      universeValue reference u.identity u.identity
    execute emptyGuard conjoin 3 domain reference reference state =
      .done (repeatedValue (pair b.identity u.identity)) {state with domains := entered.2} := by
  dsimp only
  let universeValue : Value Symbol Guard := .mu u (.node b rows 0 [.interned u.identity]) depth ordinary
```

## lean/MicroCFTA/SourceSynthesisUniverseOffDiagonalBody.lean

```lean
-- lines 233-274
theorem node_target_readback
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (top : Guard) (conjoin : Guard → Guard → Guard) (conjoinTop : conjoin top top = top)
    (u b m : Interned NodeKey) (bodyRows markerRows : List (EdgeValue Symbol Guard))
    (depth ordinary : Value Symbol Guard)
    (domain : Interned IntersectionFlatMemoKeyDomain.DomainKey) (state : Machine Symbol Guard)
    (valid : SourceRecursiveIntersectionKernel.Valid state) (known : Domain state domain)
    (universeAvailable : Available state.heap (.mu u (.node b bodyRows 0 [.interned u.identity]) depth ordinary))
    (referenceAvailable : Available state.heap (.reference (.interned u.identity)))
    (markerAvailable : Available state.heap (.node m markerRows 0 []))
    (bound : u.identity ∈ SourceRecursiveIntersectionDomain.names domain.key)
    (seen : pair b.identity u.identity ∈ domain.key.seen)
    (fresh : pair u.identity u.identity ∉ domain.key.seen)
    (bodyTop : ∀ row ∈ bodyRows, row.entry.key.constraint = top)
    (bodyChildren : ∀ row ∈ bodyRows, ∀ child ∈ row.children,
      child = .node m markerRows 0 [] ∨ child = .reference (.interned u.identity))
    (functional : ∀ left ∈ bodyRows, ∀ right ∈ bodyRows,
      left.entry.key.symbol = right.entry.key.symbol → left.children.length = right.children.length →
        left.children = right.children)
    (arrow : EdgeValue Symbol Guard) (arrowMember : arrow ∈ bodyRows)
    (arrowChildren : arrow.children = [.node m markerRows 0 [],
      .reference (.interned u.identity), .reference (.interned u.identity)]) :
    ∃ product final entry targets,
      node top conjoin (execute top conjoin 8 domain) bodyRows bodyRows state = .done product final ∧
      SourceRecursiveIntersectionKernel.Valid final ∧ Extension state final ∧ Available final.heap product ∧
      product = .node entry (canonicalEdges targets) 0
        [.intersection (pair b.identity u.identity).1 (pair b.identity u.identity).2] ∧
      All₂ (fun (source : EdgeValue Symbol Guard) target =>
        target.children = source.children.map (input (replacement (.interned u.identity)
          (repeatedValue (pair b.identity u.identity)))) ∧
        target.entry.key = ⟨source.entry.key.symbol,
          (source.children.map (input (replacement (.interned u.identity)
            (repeatedValue (pair b.identity u.identity))))).map Value.referenceOf, top⟩) bodyRows targets ∧
      (∀ target ∈ targets, EdgeResident final.heap target) ∧
      (∀ target ∈ targets, dead target = false) ∧
      run (makeNode targets) final.heap = (product, final.heap) := by
  let cutoff : Reference := .intersection (pair b.identity u.identity).1 (pair b.identity u.identity).2
  let reads := fun (source target : EdgeValue Symbol Guard) =>
    target.children = source.children.map (input (replacement (.interned u.identity) (.reference cutoff))) ∧
    target.entry.key = ⟨source.entry.key.symbol,
      (source.children.map (input (replacement (.interned u.identity) (.reference cutoff)))).map Value.referenceOf, top⟩
  have bodyAvailable : Available state.heap (.node b bodyRows 0 [.interned u.identity]) :=
```

## lean/MicroCFTA/SourceSynthesisUniverseRowTransform.lean

```lean
-- lines 21-32

/-- Target children use the existing source substitution input map. -/
def children (uId : Nat) (source : EdgeValue Symbol Guard) : List (Value Symbol Guard) :=
  source.children.map
    (InternedStoredSubstitution.input
      (InternedStoredSubstitutionRebind.replacement (.interned uId) (repeatedValue (pair uId uId))))

/-- A result has the literal transformed children, source symbol, and top guard. -/
def Readback (top : Guard) (uId : Nat) (source result : EdgeValue Symbol Guard) : Prop :=
  result.children = children uId source ∧
    result.entry.key = ⟨source.entry.key.symbol, (children uId source).map Value.referenceOf, top⟩

```

## lean/MicroCFTA/SourceSynthesisCurrentUniverseReferenceIdentity.lean

```lean
-- lines 565-586
    (bodyFresh : pair b.identity u.identity ∉ domain.key.seen)
    (bodyDiagonalFresh : pair b.identity b.identity ∉ domain.key.seen) :
    let universeValue : Value S G := .mu u (.node b rows 0 [.interned u.identity]) depth ordinary
    let sourceBody : Value S G := .node b rows 0 [.interned u.identity]
    let reference : Value S G := .reference (.interned u.identity)
    let first := SourceRecursiveIntersectionEnvironment.enter state.domains domain.key
      universeValue reference u.identity u.identity
    let second := SourceRecursiveIntersectionEnvironment.enter first.2 first.1.key
      sourceBody universeValue b.identity u.identity
    execute emptyGuard conjoin 13 domain reference universeValue state =
      ((node emptyGuard conjoin (execute emptyGuard conjoin 8 second.1)
        rows rows {state with domains := second.2}).bind
        (fun product after => construction
          (SourceRecursiveIntersectionMaybeMu.maybeMu (pair b.identity u.identity) product after.heap) after)).bind
        (fun product after => construction
          (SourceRecursiveIntersectionMaybeMu.maybeMu (pair u.identity u.identity) product after.heap) after) := by
  dsimp only
  let universeValue : Value S G := .mu u (.node b rows 0 [.interned u.identity]) depth ordinary
  let sourceBody : Value S G := .node b rows 0 [.interned u.identity]
  let referenceValue : Value S G := .reference (.interned u.identity)
  let first := SourceRecursiveIntersectionEnvironment.enter state.domains domain.key
    universeValue referenceValue u.identity u.identity
-- lines 1241-1278
  let bodyEntered := SourceRecursiveIntersectionEnvironment.enter initial.domains entered.1.key
    nativeB nativeU b.identity entry.identity
  let bodyInitial : Machine Symbol Guard := {initial with domains := bodyEntered.2}
  have bodyChecked := SourceRecursiveIntersectionKernel.entered initial initialValid entered.1 initialKnown
    nativeB nativeU bAvailable nativeUniverse b.identity entry.identity
  have bodyInitialValid : SourceRecursiveIntersectionKernel.Valid bodyInitial := bodyChecked.1
  have bodyInitialKnown : Domain bodyInitial bodyEntered.1 := bodyChecked.2.2
  have bodyEntrySeen := mixed_enter_seen initial.domains initialValid.2 entered.1.key
    nativeB nativeU b.identity entry.identity
  have selectedSeen : pair b.identity entry.identity ∈ bodyEntered.1.key.seen :=
    (bodyEntrySeen _).mpr (Or.inl rfl)
  have selectedFresh : pair entry.identity entry.identity ∉ bodyEntered.1.key.seen := by
    intro member
    rcases (bodyEntrySeen _).mp member with same | old
    · exact bNeU (mixed_pair_diagonal _ _ _ same.symm).1
    · exact diagonalFresh old
  have selectedBodyFresh : pair b.identity b.identity ∉ bodyEntered.1.key.seen := by
    intro member
    rcases (bodyEntrySeen _).mp member with same | old
    · exact bNeU (mixed_pair_diagonal _ _ _ same.symm).2.symm
    · exact bodyDiagonalFresh old
  have bodyEntryKey := SourceRecursiveIntersectionSchedule.entered_key initial.domains initialValid.2
    entered.1.key nativeB nativeU b.identity entry.identity
  have selectedBound : entry.identity ∈ SourceRecursiveIntersectionDomain.names bodyEntered.1.key := by
    rw [bodyEntryKey]
    apply (SourceRecursiveIntersectionDomain.extend_names _ _ _ _).mpr
    left
    simp [SourceRecursiveIntersectionEnvironment.bindings, SourceRecursiveIntersectionEnvironment.binder,
      nativeB, nativeU]
  obtain ⟨product, middle, productEntry, targets, bodyDone, middleValid, bodyGrowth,
      productAvailable, productRead, aligned, targetResident, _targetLive, _nodeReplay⟩ :=
    SourceSynthesisUniverseOffDiagonalBody.node_target_readback top SourceEqualityPCSNativeEdge.conjoin
      SourceSynthesisUniverseTopConjunction.native_conjoin_top entry b m bodyRows [markerRow] depth ordinary
      bodyEntered.1 bodyInitial bodyInitialValid bodyInitialKnown nativeUniverse referenceAvailable nativeMarker
      selectedBound selectedSeen selectedFresh bodyTop bodyChildren functional arrow arrowMember nativeArrowChildren
  have totalGrowth : Extension initial middle := bodyChecked.2.1.trans bodyGrowth
  let cutoff : Reference := .intersection (pair b.identity entry.identity).1 (pair b.identity entry.identity).2
  have productNodeAvailable : Available middle.heap
-- lines 1330-1376
  have depthCallback : SourceRecursiveIntersectionMaybeMu.callback cutoff product .depth middle.heap =
      .done depth middle.heap := probeCallbacks false
  have ordinaryCallback : SourceRecursiveIntersectionMaybeMu.callback cutoff product
      (.uninterned (InternedFreshOrdinaryConstruction.ordinaryLevel depth)) middle.heap =
        .done ordinary middle.heap := probeCallbacks true
  dsimp only [cutoff] at depthCallback ordinaryCallback
  have finalUniverse : Available middle.heap (.mu entry body depth ordinary) := totalGrowth.available _ universeAvailable
  obtain ⟨_keySame, table, record⟩ := available_mu_key middle.heap middleValid.1 entry body depth ordinary finalUniverse
  have kept : finish true (.mu entry body depth ordinary) = .mu entry body depth ordinary := by
    simp [finish, cleanup, bodyEq, Value.free, Value.referenceOf]
  have pendingMember : Reference.intersection (pair b.identity entry.identity).1
      (pair b.identity entry.identity).2 ∈ product.free := by
    simp only [productRead, Value.free, List.mem_singleton]
  have outerDone : SourceRecursiveIntersectionMaybeMu.maybeMu (pair b.identity entry.identity) product middle.heap =
      .done (.mu entry body depth ordinary) middle.heap := by
    simp only [SourceRecursiveIntersectionMaybeMu.maybeMu, ite_eq_left pendingMember,
      SourceRecursiveIntersectionMaybeMu.construct, depthCallback, Outcome.bind, ordinaryCallback,
      InternedNestedConstruction.request, table, record, kept]
  have outerNode : SourceRecursiveIntersectionMaybeMu.maybeMu (pair b.identity entry.identity) product middle.heap =
      .done nativeU middle.heap := by
    simpa only [nativeU, bodyEq, bodyRows] using outerDone
  have tag12 : compare (1 : Nat) 2 = .lt := by decide
  have bodyMuBranch : decision entered.1.key nativeB nativeU = .rightMu := by
    simp [decision, hasEmpty, reset, closedSelf, greater, compareValue, tag, identity, payload,
      Value.referenceOf, Value.free, nativeU, nativeB, bodyFresh, tag12]
  have bodyOrdinaryBranch : decision bodyEntered.1.key nativeB nativeB = .ordinary := by
    simp [decision, hasEmpty, reset, closedSelf, greater, compareValue, tag, identity, payload,
      Value.referenceOf, Value.free, nativeB, selectedBodyFresh]
  have nativeDone : execute top SourceEqualityPCSNativeEdge.conjoin 10 entered.1 nativeB nativeU initial =
      .done nativeU middle := by
    rw [execute]
    simp only [onNode, bodyMuBranch]
    change (execute top SourceEqualityPCSNativeEdge.conjoin 9 bodyEntered.1 nativeB nativeB bodyInitial).bind
      (fun value after => construction
        (SourceRecursiveIntersectionMaybeMu.maybeMu (pair b.identity entry.identity) value after.heap) after) = _
    rw [execute]
    simp only [onNode, bodyOrdinaryBranch]
    change (node top SourceEqualityPCSNativeEdge.conjoin
      (execute top SourceEqualityPCSNativeEdge.conjoin 8 bodyEntered.1) bodyRows bodyRows bodyInitial).bind
      (fun value after => construction
        (SourceRecursiveIntersectionMaybeMu.maybeMu (pair b.identity entry.identity) value after.heap) after) = _
    rw [bodyDone, Result.bind, outerNode]
    rfl
  have done : execute top SourceEqualityPCSNativeEdge.conjoin 10 entered.1 body universeValue initial =
      .done universeValue middle := by
    simpa only [nativeB, nativeU, universeValue, bodyEq, bodyRows] using nativeDone
  refine ⟨10, middle, ?_, middleValid, totalGrowth⟩
```

## lean/MicroCFTA/SourceCurrentAllocatedNativeReturnedProperties.lean

```lean
-- lines 21-39
/-- A ready node hit returns its exact stored payload and conditional property. -/
theorem node_ready_property
    (law : NodeRequest Symbol Guard → Value Symbol Guard → Prop)
    (state : Native width Symbol Guard)
    (physical : SourceCurrentAllocatedNativePhysicalCache.Valid state)
    (returned : Returned law state.nodes)
    (request original : NodeRequest Symbol Guard) (ready : NodeReady state.machine request)
    (key : IntersectionFlatMemoKeyDomain.Triple width) (checked : NodeKey width request key)
    (handle : Nat) (published : state.nodes.table key = some handle) (value : Value Symbol Guard)
    (stored : state.nodes.cells handle = some ⟨original, .returned value⟩) :
    original = request ∧ lookupNode width request state = (.memoized handle, state) ∧
      demandNode handle state = (.ready value, state) ∧ Available state.machine.heap value ∧
      law request value := by
  obtain ⟨same, selected, demanded, available⟩ :=
    SourceCurrentAllocatedNativePhysicalCache.node_ready_receipt state physical request original
      ready key checked handle published value stored
  have localLaw := returned handle original value stored
  rw [same] at localLaw
  exact ⟨same, selected, demanded, available, localLaw⟩
-- lines 60-80

/-- A node finish retains prior properties and stores the same actual producer payload. -/
theorem finishNode_property
    (law : NodeRequest Symbol Guard → Value Symbol Guard → Prop)
    (state : Native width Symbol Guard)
    (physical : SourceCurrentAllocatedNativePhysicalCache.Valid state)
    (returned : Returned law state.nodes)
    (handle : Nat) (request : NodeRequest Symbol Guard) (value : Value Symbol Guard)
    (running : state.nodes.cells handle = some ⟨request, .evaluating⟩)
    (available : Available state.machine.heap value) (localLaw : law request value) :
    SourceCurrentAllocatedNativePhysicalCache.Valid (finishNode handle value state) ∧
      Returned law (finishNode handle value state).nodes ∧
      (finishNode handle value state).nodes.cells handle = some ⟨request, .returned value⟩ ∧
      (finishNode handle value state).machine = state.machine ∧
      (finishNode handle value state).edges = state.edges := by
  have physicalAfter := SourceCurrentAllocatedNativePhysicalCache.finishNode_valid
    state physical handle request value running available
  have returnedAfter := SourceCurrentAllocatedNativeContextCache.returned_finish
    law handle request value state.nodes returned running localLaw
  have exactCell := FlatMemoThunk.setStatus_cell handle (.returned value)
    state.nodes ⟨request, .evaluating⟩ running
```

## lean/MicroCFTA/SourceCurrentAllocatedNativeContextCache.lean

```lean
-- lines 93-102
    (key : Key) (request : Request) (state : FlatMemoThunk.State Key Request Answer) (valid : Returned law state) :
    Returned law (FlatMemoThunk.lookupOrInsert key request state).2 := by
  cases found : state.table key with
  | some handle => simpa only [FlatMemoThunk.lookupOrInsert, found] using valid
  | none =>
      intro handle original result stored
      by_cases same : handle = state.next
      · subst handle
        simp [FlatMemoThunk.lookupOrInsert, found, Cache.put] at stored
      · exact valid handle original result (by
-- lines 145-156
structure Contextual (view : IntersectSchedule.View Symbol) (model : IntersectSchedule.InputMeaning view)
    (ranked : IntersectSchedule.RankedInput view model.valid) (holds : Guard → Term Symbol → Bool)
    (state : Native width Symbol Guard) : Prop where
  nodes : Returned (NodeLaw view model ranked holds) state.nodes
  edges : Returned (EdgeLaw view model ranked holds) state.edges

section Lifecycle
variable (view : IntersectSchedule.View Symbol) (model : IntersectSchedule.InputMeaning view)
  (ranked : IntersectSchedule.RankedInput view model.valid) (holds : Guard → Term Symbol → Bool)

/-- Empty tables need no supplied completed contextual answer. -/
theorem initial_contextual (width : Nat) (machine : Machine Symbol Guard) :
```

## lean/MicroCFTA/SourceCurrentAllocatedNativeMuClosedChildFootprints.lean

```lean
-- lines 100-135
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (request : NodeRequest Symbol Guard) (before after : Checked width)
    (first second fuel universeIdentity : Nat) (value : Value Symbol Guard)
    (leftIdentity : SourceRecursiveIntersectionControl.identity request.left = some first)
    (rightIdentity : SourceRecursiveIntersectionControl.identity request.right = some second)
    (selected : SourceRecursiveIntersectionControl.decision request.domain.key request.left request.right = .bothMu ∨
      SourceRecursiveIntersectionControl.decision request.domain.key request.left request.right = .leftMu ∨
      SourceRecursiveIntersectionControl.decision request.domain.key request.left request.right = .rightMu)
    (done : SourceEqualityNativeDemand.execute fuel (.code (compileNode request)) before = .done value after)
    (children :
      let entered := SourceRecursiveIntersectionEnvironment.enter before.native.machine.domains request.domain.key
        request.left request.right first second
      let started : Checked width :=
        {before with native := advance before.native {before.native.machine with domains := entered.2}}
      ∀ childFuel, childFuel < fuel → ∀ child middle,
        SourceEqualityNativeDemand.execute childFuel
          (.code (requestNode entered.1 (SourceRecursiveIntersectionKernel.body request.left)
            (SourceRecursiveIntersectionKernel.body request.right))) started = .done child middle →
        child.free = [] ∧ ∀ atom ∈ InternedBoundaryAtoms.atoms child, atom = .mu universeIdentity) :
    value.free = [] ∧
      (∀ atom ∈ InternedBoundaryAtoms.atoms value, atom = .mu universeIdentity) ∧
      ∃ childSteps,
        childSteps + 1 < fuel ∧
        Steps childSteps
          (.code (requestNode
            (SourceRecursiveIntersectionEnvironment.enter before.native.machine.domains request.domain.key
              request.left request.right first second).1
            (SourceRecursiveIntersectionKernel.body request.left) (SourceRecursiveIntersectionKernel.body request.right)))
          {before with native := advance before.native {before.native.machine with domains :=
            (SourceRecursiveIntersectionEnvironment.enter before.native.machine.domains request.domain.key
              request.left request.right first second).2}}
          (.code (.pure value)) after := by
  obtain ⟨child, middle, childSteps, restSteps, shorter, _entered, childTrace, binderDone⟩ :=
    node_mu_observation request before after first second fuel value leftIdentity rightIdentity selected done
  have childDone := trace_done childSteps _ _ middle child childTrace
  have profile := children (childSteps + 1) shorter child middle childDone
```
