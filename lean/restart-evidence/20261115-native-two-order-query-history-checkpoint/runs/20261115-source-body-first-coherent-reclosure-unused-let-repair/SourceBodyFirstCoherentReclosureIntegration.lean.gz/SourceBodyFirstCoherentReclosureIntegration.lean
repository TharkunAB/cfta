import MicroCFTA.SourceCurrentAllocatedNativeSourceBodyFirstActualMuCutoff
import MicroCFTA.SourceCurrentAllocatedNativeSourceBodyFirstReferenceRead
import MicroCFTA.SourceCurrentAllocatedNativeBodyFirstKeyQueryGlobalLaws
import MicroCFTA.SourceCurrentAllocatedNativePrefixOperations
import MicroCFTA.SourceCurrentNativeOpenRequestResults

/-!
# Original-source body-first coherent history and same-state reclosure

The original source supplies every actual-domain structural condition.
Each actual incoming handle retains the body-first key and its own identity.
Both complete memo laws use the original machine, plans, and fuel.
Each actual B/B return recloses to full U at its same complete state.
-/
namespace MicroCFTA.SourceCurrentAllocatedNativeBodyFirstCoherentReclosureIntegrationProbe
open Cache Language InternedConstructorTemplates InternedNestedFacts InternedProbeProvenance
open InternedBinderProtocol (NodeKey Reference)
open SourceRecursiveIntersectionControl SourceRecursiveIntersectionDomain
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceSynthesisTypeSyntax (Library Query)
open SourceSynthesisFirstOrderConstruction (Expression)
open SourceEqualityNativeDemand
open SourceCurrentAllocatedNativeContextCache (Returned)
open SourceCurrentAllocatedNativePhysicalExecution (InputsThrough)
open SourceEqualityNativeDemandOperations (FieldsThrough)
open SourceCurrentAllocatedNativeBodyFirstKeyQueryGlobalLaws (NodeResult EdgeResult)
open SourceCurrentAllocatedNativeCoherentOpenBodyResult (ProductShape)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "ordinarySymbols" => SourceSynthesisUniverseCallerBoundary.ordinarySymbols

set_option autoImplicit false

private theorem reference_code [DecidableEq Symbol]
    (domain : Interned IntersectionFlatMemoKeyDomain.DomainKey) (name : Nat)
    (chosen : decision domain.key (.reference (.interned name) : Value Symbol Guard)
      (.reference (.interned name)) = .leftReference) :
    compileNode (⟨domain, .reference (.interned name), .reference (.interned name)⟩ : NodeRequest Symbol Guard) =
      compileReference domain name (.reference (.interned name)) true := by
  simp only [compileNode, chosen]

private theorem reference_read_step
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
    (domain : Interned IntersectionFlatMemoKeyDomain.DomainKey) (name : Nat)
    (other value : Value Symbol Guard) (current : SourceEqualityNativeDemand.State width)
    (bound : name ∈ names domain.key)
    (read : SourcePreparedSharedRows.read current.native.machine.heap name = some value) :
    SourceEqualityNativeDemand.step (.code (compileReference domain name other true)) current =
      .yielded (.code (requestNode domain value other)) current := by
  simp [compileReference, bound, SourceEqualityNativeDemand.step,
    SourceRecursiveIntersectionNative.step, read, SourceEqualityNativeDemand.lift]

set_option maxHeartbeats 1200000 in
/-- The original source supplies both body-first memo histories and same-state full-U reclosure. -/
theorem current_stored_universe_body_first_coherent_reclosure
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
    (lib : Library) (query : Query) (signed : Int) (whole : Expression)
    (accepted : SourceSynthesisCurrentConstruction.firstOrderRaw lib query signed = .ok whole)
    (rootValue : Value Symbol Guard) (sourceHeap : InternedConstructorTemplates.State Symbol Guard)
    (built : InternedFreshOrdinaryConstruction.build (ordinarySymbols whole) [] empty =
      .done rootValue sourceHeap)
    (key : NodeKey) (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard)
    (stored : sourceHeap.nodeRecords key = some (.mu entry body depth ordinary))
    (machine : SourceRecursiveIntersectionKernel.Machine Symbol Guard)
    (machineValid : SourceRecursiveIntersectionKernel.Valid machine)
    (facts : Facts machine.heap) (growth : Grows sourceHeap machine.heap)
    (domains : Cache.State IntersectionFlatMemoKeyDomain.DomainKey) (cacheValid : Cache.Valid domains)
    (pattern : Value Symbol Guard) (_patternAvailable : Available machine.heap pattern)
    (_patternClosed : pattern.free = []) (patternId : Nat)
    (_patternIdentity : identity pattern = some patternId)
    (_patternKind : tag pattern = 1 ∨ tag pattern = 3) :
    ∃ (bodyEntry : Interned NodeKey) (bodyRows : List (EdgeValue Symbol Guard)),
      body = .node bodyEntry bodyRows 0 [.interned entry.identity] ∧
      let universeValue : Value Symbol Guard := .mu entry body depth ordinary
      let original := SourceRecursiveIntersectionEnvironment.enter domains IntersectionEmptyDomain.emptyKey
        universeValue pattern entry.identity patternId
      let bodyFirst := SourceRecursiveIntersectionEnvironment.enter original.2 original.1.key
        body universeValue bodyEntry.identity entry.identity
      ∀ (actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey),
      actualDomain.key = bodyFirst.1.key →
      ∀ (operations : SourceEqualityConstraintMemoAllocation.State)
        (_operationsValid : SourceEqualityConstraintMemoAllocation.Valid operations) (fuel : Nat),
      let start : SourceEqualityNativeDemand.State width :=
        ⟨SourceRecursiveIntersectionThunks.initial width machine, operations⟩
      InputsThrough fuel (.code (.node ⟨actualDomain, body, body⟩ .pure)) start →
      FieldsThrough fuel (.code (.node ⟨actualDomain, body, body⟩ .pure)) start →
      Returned (NodeResult entry.identity bodyEntry.identity bodyFirst.1.key body universeValue)
        (execute fuel (.code (.node ⟨actualDomain, body, body⟩ .pure)) start).state.native.nodes ∧
      Returned (EdgeResult entry.identity bodyEntry.identity bodyFirst.1.key universeValue)
        (execute fuel (.code (.node ⟨actualDomain, body, body⟩ .pure)) start).state.native.edges ∧
      ∀ (count : Nat) (result : Value Symbol Guard) (after : SourceEqualityNativeDemand.State width),
        count ≤ fuel →
        Steps count (.code (.node ⟨actualDomain, body, body⟩ .pure)) start (.code (.pure result)) after →
        ProductShape entry.identity bodyEntry.identity entry.identity body result ∧
        SourceRecursiveIntersectionMaybeMu.maybeMu (pair bodyEntry.identity entry.identity) result
          after.native.machine.heap = .done universeValue after.native.machine.heap ∧
        SourceEqualityNativeDemand.step
          (.code (.optionalBinder (pair bodyEntry.identity entry.identity) result .pure)) after =
          .yielded (.code (.pure universeValue)) after ∧
        SourceEqualityNativeDemand.execute 2
          (.code (.optionalBinder (pair bodyEntry.identity entry.identity) result .pure)) after =
          .done universeValue after := by
  obtain ⟨bodyEntry, bodyRows, bodyShape, bodyApart, sourceFacts⟩ :=
    SourceCurrentAllocatedNativeSourceBodyFirstActualMuCutoff.current_stored_universe_body_first_actual_mu_cutoff
      (width := width) lib query signed whole accepted rootValue sourceHeap built key entry body depth ordinary
      stored machine.heap facts growth domains cacheValid pattern _patternAvailable _patternClosed
      patternId _patternIdentity _patternKind
  obtain ⟨readEntry, readRows, readShape, readFacts⟩ :=
    SourceCurrentAllocatedNativeSourceBodyFirstReferenceRead.current_stored_universe_body_first_reference_read
      (width := width) lib query signed whole accepted rootValue sourceHeap built key entry body depth ordinary
      stored machine.heap facts growth domains cacheValid pattern _patternAvailable _patternClosed
      patternId _patternIdentity _patternKind
  have sameEntry : readEntry = bodyEntry := (Value.node.inj (readShape.symm.trans bodyShape)).1
  have sameRows : readRows = bodyRows := (Value.node.inj (readShape.symm.trans bodyShape)).2.1
  subst readEntry
  subst readRows
  let universeValue : Value Symbol Guard := .mu entry body depth ordinary
  let referenceValue : Value Symbol Guard := .reference (.interned entry.identity)
  let original := SourceRecursiveIntersectionEnvironment.enter domains IntersectionEmptyDomain.emptyKey
    universeValue pattern entry.identity patternId
  let bodyFirst := SourceRecursiveIntersectionEnvironment.enter original.2 original.1.key
    body universeValue bodyEntry.identity entry.identity
  dsimp only at sourceFacts readFacts
  have originalValid : Cache.Valid original.2 :=
    (IntersectionEmptyDomain.make_correct domains cacheValid _).1
  have originalKey : original.1.key = extend IntersectionEmptyDomain.emptyKey
      ((SourceRecursiveIntersectionEnvironment.bindings universeValue pattern).map Prod.fst)
      (pair entry.identity patternId) :=
    SourceRecursiveIntersectionSchedule.entered_key domains cacheValid IntersectionEmptyDomain.emptyKey
      universeValue pattern entry.identity patternId
  have bodyKey : bodyFirst.1.key = extend original.1.key
      ((SourceRecursiveIntersectionEnvironment.bindings body universeValue).map Prod.fst)
      (pair bodyEntry.identity entry.identity) :=
    SourceRecursiveIntersectionSchedule.entered_key original.2 originalValid original.1.key
      body universeValue bodyEntry.identity entry.identity
  have diagonalParts (first second owner : Nat) (same : pair first second = pair owner owner) :
      first = owner ∧ second = owner := by
    have lower := congrArg Prod.fst same
    have upper := congrArg Prod.snd same
    simp only [pair, Nat.min_self, Nat.max_self] at lower upper
    omega
  have freshBodyPair : pair bodyEntry.identity bodyEntry.identity ∉ bodyFirst.1.key.seen := by
    intro member
    rw [bodyKey] at member
    rcases (extend_seen _ _ _ _).mp member with same | previous
    · exact bodyApart (diagonalParts bodyEntry.identity entry.identity bodyEntry.identity same.symm).2.symm
    · rw [originalKey] at previous
      rcases (extend_seen _ _ _ _).mp previous with same | empty
      · exact bodyApart (diagonalParts entry.identity patternId bodyEntry.identity same.symm).1.symm
      · simp only [IntersectionEmptyDomain.emptyKey, List.not_mem_nil] at empty
  have sourceRows : InternedEdgeResidency.nodeEdges body = bodyRows := by
    rw [bodyShape]
    rfl
  have compiler : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = bodyFirst.1.key →
      compileNode ⟨actualDomain, body, body⟩ =
        compileRows actualDomain (InternedEdgeResidency.nodeEdges body) (InternedEdgeResidency.nodeEdges body) := by
    intro actualDomain sameKey
    have fresh : pair bodyEntry.identity bodyEntry.identity ∉ actualDomain.key.seen := by
      rw [sameKey]
      exact freshBodyPair
    have shaped : decision actualDomain.key
        (.node bodyEntry bodyRows 0 [.interned entry.identity])
        (.node bodyEntry bodyRows 0 [.interned entry.identity]) = .ordinary := by
      simp [decision, hasEmpty, reset, closedSelf, greater, compareValue, tag, identity, payload,
        Value.referenceOf, Value.free, fresh]
    have literalCompiled : compileNode ⟨actualDomain,
        .node bodyEntry bodyRows 0 [.interned entry.identity],
        .node bodyEntry bodyRows 0 [.interned entry.identity]⟩ = compileRows actualDomain bodyRows bodyRows := by
      simp only [compileNode, shaped]
    calc
      compileNode ⟨actualDomain, body, body⟩ = compileNode ⟨actualDomain,
          .node bodyEntry bodyRows 0 [.interned entry.identity],
          .node bodyEntry bodyRows 0 [.interned entry.identity]⟩ :=
        congrArg (fun value : Value Symbol Guard => compileNode ⟨actualDomain, value, value⟩) bodyShape
      _ = compileRows actualDomain bodyRows bodyRows := literalCompiled
      _ = compileRows actualDomain (InternedEdgeResidency.nodeEdges body)
          (InternedEdgeResidency.nodeEdges body) := by rw [sourceRows]
  have selected : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = bodyFirst.1.key →
      decision actualDomain.key universeValue referenceValue = .leftMu := by
    intro actualDomain sameKey
    rw [sameKey]
    exact sourceFacts.1
  have childPure : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = bodyFirst.1.key →
      ∀ current : Cache.State IntersectionFlatMemoKeyDomain.DomainKey, Cache.Valid current →
      compileNode ⟨(SourceRecursiveIntersectionEnvironment.enter current actualDomain.key
        universeValue referenceValue entry.identity entry.identity).1,
        SourceRecursiveIntersectionKernel.body universeValue,
        SourceRecursiveIntersectionKernel.body referenceValue⟩ =
        .pure (repeatedValue (pair bodyEntry.identity entry.identity)) := by
    intro actualDomain sameKey current currentValid
    rw [sameKey]
    exact (sourceFacts.2.2.2.1 current currentValid).2.2
  have absent : let binder := pair entry.identity entry.identity
      Reference.intersection binder.1 binder.2 ∉
        (repeatedValue (pair bodyEntry.identity entry.identity) : Value Symbol Guard).free :=
    sourceFacts.2.2.1
  have read : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = bodyFirst.1.key →
      ∀ current : SourceEqualityNativeDemand.State width,
      SourceCurrentAllocatedNativePhysicalCache.Valid current.native →
      Grows sourceHeap current.native.machine.heap →
      SourceEqualityNativeDemand.step
        (.code (compileNode ⟨actualDomain, referenceValue, referenceValue⟩)) current =
        .yielded (.code (requestNode actualDomain universeValue referenceValue)) current := by
    intro actualDomain sameKey current physical currentGrowth
    have bound : entry.identity ∈ names actualDomain.key := by
      rw [sameKey]
      exact readFacts.1
    have referenceSelected : decision actualDomain.key referenceValue referenceValue = .leftReference := by
      rw [sameKey]
      exact readFacts.2.1
    have compiled : compileNode ⟨actualDomain, referenceValue, referenceValue⟩ =
        compileReference actualDomain entry.identity referenceValue true :=
      reference_code actualDomain entry.identity referenceSelected
    have sourceRead : SourcePreparedSharedRows.read current.native.machine.heap entry.identity =
        some universeValue := (readFacts.2.2.2 current physical.machine.1 currentGrowth).1
    exact (congrArg (fun code : Code Symbol Guard (Value Symbol Guard) =>
      SourceEqualityNativeDemand.step (.code code) current) compiled).trans
        (reference_read_step actualDomain entry.identity referenceValue universeValue current bound sourceRead)
  refine ⟨bodyEntry, bodyRows, bodyShape, ?_⟩
  dsimp only
  intro actualDomain sameKey operations operationsValid fuel plan fields
  have completed := SourceCurrentAllocatedNativeBodyFirstKeyQueryGlobalLaws.initial_node_query_returned_and_raw_results
    (width := width) lib query signed whole accepted rootValue sourceHeap built key entry body depth ordinary stored
    bodyFirst.1.key bodyEntry.identity compiler selected childPure absent read
    machine machineValid growth operations operationsValid fuel ⟨actualDomain, body, body⟩ plan fields
  refine ⟨completed.1.1, completed.1.2, ?_⟩
  intro count result after bounded actual
  have shape := (completed.2 count result after bounded actual).2.2.2 sameKey rfl rfl
  let request : NodeRequest Symbol Guard := ⟨actualDomain, body, body⟩
  let start : SourceEqualityNativeDemand.State width :=
    ⟨SourceRecursiveIntersectionThunks.initial width machine, operations⟩
  have physical : SourceCurrentAllocatedNativePhysicalCache.Valid start.native :=
    SourceCurrentAllocatedNativePhysicalCache.initial_valid machine machineValid
  have reached := SourceCurrentAllocatedNativePrefixOperations.prefix_operations_before_bind
    fuel count (.code (.node request .pure)) (.code (.pure result)) .pure start after sourceHeap
    physical plan fields operationsValid growth actual bounded
  have available : Available after.native.machine.heap result :=
    SourceCurrentNativeOpenRequestResults.node_result count request start after result physical reached.1
  have reclosed := SourceCurrentAllocatedNativeCoherentOpenBodyResult.stored_open_product_optional_reclosure
    lib query signed whole accepted rootValue sourceHeap built key entry body depth ordinary stored
    after reached.2.1.machine.1 reached.2.2.2.1 bodyEntry.identity entry.identity result available shape
  exact ⟨shape, reclosed⟩

end MicroCFTA.SourceCurrentAllocatedNativeBodyFirstCoherentReclosureIntegrationProbe
