# Tuple-budget completion follow-up

Status: AUTHOR UNTESTED. Root owns compilation.

Root requested a separate total-run existence proof after the first candidate pair was delivered.
Version 1 and all version-1 report bytes remain unchanged.

The new `SourceCurrentConjunctionTupleBudgetCompletion.lean` imports the first model module.
It exports `run_complete` for every finite initial table and pending list.
The conclusion is an actual finite `Run` witness.
It requires no language meaning, source exposure law, future table, or table-size bound.

The proof uses strong induction on the remaining tuple budget.
The inner induction follows the pending list and generalizes the table.
Empty and skipped heads use the inner induction hypothesis.
Fresh overflow has positive incoming budget and invokes the outer hypothesis at zero.
A fitting positive charge invokes the outer hypothesis at `budget - count`.
A zero charge gives an empty sample and therefore an empty sampled row list.
It inserts that row and uses the inner hypothesis with the updated table and unchanged pending tail.

This source candidate addresses the total-run existence obligation identified in REPORT-v1.md.
Its mathematical statement is complete, but it is not checked until Root compiles it.
The literal grow/public Boolean bridge, physical bounded cold-exposure schedule, numeric resource accounting, and Haskell runtime correspondence remain outside this candidate.
No total-table or grow-round bound is added.

The complete 52-line new module was read back.
No additional whole project source was acquired.
A name-only search confirmed the existing `List.length_eq_zero_iff` API.
The version-1 four-whole-source scope remains the complete semantic read scope.
No compiler, evaluator, native process, Git, network, board, repository edit, or Haskell edit was performed.
