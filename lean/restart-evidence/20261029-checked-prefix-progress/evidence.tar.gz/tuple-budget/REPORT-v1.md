# PR 193 tuple-budget audit

Status: SOURCE-ONLY. Both additive candidates are AUTHOR UNTESTED.
Root owns compilation, native tests, Haskell edits, Git, and publication.

## Current source change

The current `Enumeration.hs` checks EmptyNode first.
It then checks exhausted budget, free references, and prior table membership.
Only a fresh closed nonempty conjunction reaches tuple sampling.
It samples `take (budget + 1) (edgeTuples ns)` and computes the sample length before equality rejection.
If the count exceeds the remaining budget, it inserts no table entry and drains the remaining queue at budget zero.
Otherwise it subtracts the full sample count, inserts the rows that survive equality combination, and prepends their requirements.
A zero-tuple product therefore costs zero and inserts an empty row list while the budget remains positive.
The public initial budget is now 10000.

The sample preserves the exact original edge-tuple fold order.
Its components retain the tail operands first and the original head operand last.
Symbol and arity matching precede equality combination.
A contradictory equality tuple contributes to the charge even though it contributes no stored row.

## Exact existing model gap

`SourceCurrentConjunctionEmptinessTable.explore`, physical `Worklist.Run.admit`, and `Worker.explore` subtract one per admitted conjunction.
They build full tuple rows and have no overflow-without-publication branch.
They remain valid secondary targets for the earlier conjunction-charged algorithm.
Changing the public budget constant cannot make them describe the tuple-charged algorithm.
No old definition, theorem, constant, or evidence was modified.

The old physical RowsWorker first completes the full operand exposure schedule, forms all tuples, and executes all tuple equality/projection jobs.
It does not represent a bounded lazy sample before tuple-row work.
Its existing documentation already excludes host lazy forcing correspondence.

## Additive candidates

`SourceCurrentConjunctionTupleBudget.lean` adds a separate `currentTupleBudget = 10000`, the exact sample, and sampled tuple rows.
`sample_eq_of_fits` proves that every admitted sample is the full original tuple list.
`sample_overflow_iff` identifies the exact overflow test.
`sampledRows_eq` identifies every admitted stored row list with the existing full `tupleRows`.
`no_tuples` retains zero charge and an empty row list.

The new `Run` relation follows the source guard order.
Its overflow constructor publishes no row and gives the tail budget zero.
Its admission constructor subtracts the sampled tuple count before inserting concrete sampled rows.
`Run.zero_table`, `overflow_absent`, and `overflow_outside` derive the conservative treatment of an overflowing fresh conjunction.
They do not assume a final-table oracle.

`SourceCurrentConjunctionTupleBudgetSoundness.lean` proves `Run.stored` and `Run.sound`.
It reuses the source `edgeTuples`, actual equality combination, actual requirement construction, and `tupleRows_witness` through the existing finite-table soundness theorem.
It is not only a generic List.take result.
Its conclusion excludes every finite term from the queried initial node when the resulting finite-table `provablyEmpty` verdict is true.

## Exact theorem boundary

The new relation uses a finite extensional edge-list observation and the existing pure-table local exposure, path-projection, empty-language, and key-faithfulness laws.
Those remain explicit source-interface premises.
The candidate does not derive them for arbitrary Haskell Node values.
It does not extend the stronger allocated physical Worklist proof or derive a host execution trace.
It does not assert that the Lean evaluator avoids materializing a Cartesian product.
The List.take model states extensional sample contents and charge, not runtime cost.

The candidate proves soundness for an actual finite `Run` receipt.
It does not yet prove that every input has such a receipt.
It also uses the existing finite-table `provablyEmpty` observer.
The direct bridge from a completed literal `grow` and the public closed guard to that observer is unchanged work for this new Run family.
Existing generic finite-table fixed-point laws support that bridge.
No sufficient Haskell execution bound, host termination proof, or full implementation correspondence is claimed.

## Zero-charge resource boundary

The old general table bound `final.length ≤ table.length + budget` used one unit for every table insertion.
A fresh zero-tuple conjunction now inserts a row without consuming a unit.
Therefore that proof and its empty-start corollary do not transfer to the new Run.
This is a failure of the old generic accounting argument.
It is not an admitted counterexample to Haskell input invariants.

`SourceCurrentConjunctionDecision.complete` and `Worker.decision` use `budget + 1` grow rounds after the old table bound.
That grow bound must be reconsidered for the tuple-charged table.
`WorklistResources.forecast` iterates a whole row-allocation forecast once per old admission-budget unit.
That schedule also needs a new proof.
A zero product generates no new requirements, but its original cold exposure schedule can still allocate.
Do not claim the old physical resource schedule transfers because zero tuple rows perform no equality/projection jobs.
Positive-charge admissions may be bounded by the initial tuple budget.
No theorem for that fact is supplied here.
A revised resource proof should also account for the pending queue that positive admissions generate.

## Smallest next obligations

First prove total existence of the new finite Run:
`∀ budget table pending, ∃ final, Run empty key closed edges project budget table pending final`.
Use the lexicographic measure `(budget, pending.length)`.
A positive sample charge decreases budget.
A zero sample has no rows and removes the pending head.
Overflow has positive incoming budget and moves to zero.
Empty, exhausted, open, and repeated inputs remove the pending head.
This needs no model or future-table assumption.

Then add the bounded tuple observation to the actual physical exposure/row pipeline.
It must retain the actual reached heap when cold reads are needed to observe the prefix.
It must execute tuple equality and requirement work only after the complete fitting sample is established.
A fitting sample may reuse the existing full-row coverage theorem.
The overflow arm must publish no row and must not require full remaining operand exposure.
Carry pending-queue accounting separately from tuple charge before reusing numeric worker or grow ceilings.

## Haskell finding for FINDINGS

The initial Haddock text said the check reads at most `emptinessBudget` edge tuples.
The sentinel can inspect one extra tuple when a product exceeds the remaining budget.
Root accepted this documentation correction and the final read shows `emptinessBudget + 1` in the main Haddock paragraph.
This is a documentation-only repair.
The algorithm remains unchanged by this audit.
No functional Haskell defect was established.

## Evidence

The complete 191-line candidate pair was read back without truncation.
Four distinct whole Lean sources were reviewed; all other semantic reads are recorded cuts.
The full RowsWorker counts as a whole source because two ranges cover its EOF.
Initial broad search output was truncated and is not credited as whole-source evidence.
All retained source and copy byte hashes pass readback.
No compiler, evaluator, native job, Git, network, board, or repository mutation was performed.
No earlier sealed evidence was changed.
