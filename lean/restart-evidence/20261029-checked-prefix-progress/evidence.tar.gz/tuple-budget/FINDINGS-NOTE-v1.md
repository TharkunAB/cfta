# FINDINGS handoff: tuple-budget documentation

Source: cfta/src/Data/CFTA/Enumeration.hs, provablyEmpty Haddock.

Initial observation: "The check reads at most 'emptinessBudget' edge tuples."
The new `take (budget + 1)` samples one overflow sentinel in addition to the remaining charge.
The correct maximum observed tuple count is the original budget plus one.
Root accepted a documentation-only correction.
The final source read shows "'emptinessBudget' + 1" in the main Haddock paragraph.
No functional Haskell change was proposed by this audit.
Root owns the repository FINDINGS entry and validation.
