# PR193 emptiness budget: 2026-10-29 20:49 CET

Main 7b8db072fbde44f20ce9a803736de5624050f038 is integrated at ec6d21f68ee7e7ff702a4c8edbff413d802766d7.
The old budget counted conjunctions. One conjunction can have a very large
Cartesian product of edges. The new code samples at most remaining budget
+ 1 tuples. Overflow adds no table entry and ends further tuple reads.
Other cases charge every tuple, including tuples rejected by equality.
The configured budget is now 10000 tuples. Unknown conjunctions remain
possibly accepting. No false emptiness result is introduced by this cutoff.

The actual Nix core suite passed 384 examples with seed 492294335. This
includes the upstream constrained recursive regression. Raw output and
exact integrated inputs are retained in the checked-prefix evidence area.
The only additional Haskell change here corrects the Haddock read bound to
emptinessBudget + 1. The extra tuple detects overflow. Runtime code is
unchanged by this documentation repair. Record it for external pickup.
The exact parent implementation and regression remain upstream PR193.

The older Lean worklists count conjunctions and use 1000. They remain
historical models. A new model must charge tuple samples, omit overflow
entries and retain zero-tuple entries without a charge. Changing only the
constant would not establish current Haskell correspondence. Total table
length need not be bounded by the tuple budget. The source audit and proofs
are in progress. All earlier evidence and parser/probe repairs remain.
The full formalization goal remains ACTIVE.

---
