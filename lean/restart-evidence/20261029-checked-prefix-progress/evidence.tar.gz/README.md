# Checked query prefix bounds and tuple-budget emptiness

The full formalization goal remains ACTIVE.
Read final-documents/lean/notes-current-checked-prefix-progress.md first.
The checked per-query all-fuel existential bound is now proved.
The current tuple-budget model has finite exploration and a sound public verdict.
Global bounds, physical tuple sampling and Haskell correspondence remain open.

Every regular file is sealed and archived without filtering. Keep this tree
and reconstructions immutable. Continue in a fresh writable area. Historical
UNTESTED labels and failed attempts remain. final-check-map.json identifies
the exact six strict final sources. Verification executes no archived code.
