set -eu
fourmolu --mode check cfta/src/Data/CFTA/Enumeration.hs cfta/test/Data/CFTA/EqualitySpec.hs
cabal-gild --mode check --input cfta/cfta.cabal
