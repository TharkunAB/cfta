# Derived completion bounds all checked query observations

Date: 2026-10-29 20:48 CET.
Status: candidate-v1 is SOURCE-ONLY and UNTESTED here. Root owns compilation.
The repository, all older frozen evidence areas, and Haskell were unchanged.
No compiler, evaluator, native job, Git, network or board call was made.

## Result

The existing successful checked-query producer suffices for an existential
body ceiling over all runtime fuels. A duplicate semantic-rank/degree induction
is unnecessary for this weaker result. This refines the previous generator-query
audit's proposed proof route. It does not invalidate the separate sharp bare
native bounds or supply a sharp checked bound of L + semantic requiredFuel.

The candidate exports two additive theorems in one module:

1. PhysicalTraceCompletion.Trace.prefix_bounded takes an actual physical trace
from the original control/state to .code (.pure value), original physical cache
validity, and original RequiredCache.Ready. It concludes one Bounded ceiling for
the exact Demand.execute outcome heap at EVERY runtime fuel.
2. IncomingQuery.native_prefix_bounded takes only original caller admission:
Profile, Context, actual left/right current Available and closedness, Fits and
Room. It derives the actual finite completion itself and concludes the ceiling
for the literal requestNode emptyDomain left right at beforeCaller.checked.
No completion receipt, future heap fact, body bound, or later degree supplier is
an input to this final theorem.

The whole candidate was read back without truncation. It contains 105 lines,
6365 bytes, SHA256 3a864b3b1e2a5d1541763b6f521a4fe1b707df91255ec514579bfdbfae5c4593.
Draft-v1 has identical bytes and remains preserved. No compiler failure or
compiler repair has occurred in this child task. The exact public statements
are also stored separately in this evidence directory.

## Generic proof and exact state binding

Physical Trace.cons records the literal checked step = yielded next middle and
the physical Inputs at that step. PhysicalExecution.step_invariants derives
middle physical validity and RequiredCache.Keeps from original physical validity,
RequiredCache.Ready, and those Inputs. Keeps.ready supplies the next Ready.
Thus induction needs neither an all-future invariant supplier nor code Fields.
The stronger Good/Fields step theorem also exists but is unnecessary here.

At a zero-length completed trace the control is literally .code (.pure value).
Demand.execute at any runtime fuel has the same original state. Facts in the
original physical machine give InternedMuDepthInventory.initial_bounded for
that actual heap.

At each cons step the proof obtains the tail's one ceiling and selects the max
of that ceiling and the current heap's finite initial_bounded inventory ceiling.
Runtime fuel zero uses the current heap. A positive runtime fuel follows the
recorded yielded equation into the exact next checked state and the actual tail.
Every bound is selected before the universal runtimeFuel quantifier. The proof
retains the whole checked states in Trace; it projects only the requested heap
for Bounded. It never casts an original source into a prepared/current endpoint.

This is a finite maximum over actual reached states, implemented by trace
induction. It does not enumerate hypothetical future states. It includes the
final pure state's finite ceiling, so all larger runtime fuels are covered by
the same proof without a separate done_stable invocation.

## Actual caller producer

The caller follows the existing IncomingQuery.complete_resources derivation:
Fits.room gives original current counters and domain headroom. Original
Available + closed with initial coherent Facts derive original operand syntax.
WarmInitialRanges.warm_initial_ranges derives checked WordRanges at the literal
query-entry state, with no all-future range supplier.

The proof calls the smaller existing SourceCurrentAllocatedTargetQuery.finite
once. This is the native query producer used below IncomingQuery.complete and
complete_resources. It returns the actual TargetQuery.Receipt. Its actual field
is Step.run containing the exact PhysicalTraceCompletion.Trace for this same
request and same original checked state. The generic theorem then consumes that
trace with initial.ready.good.native and initial.ready.good.heap.

Using this lower-stage producer avoids the unrelated enabled-empty phase and
guard-alphabet forecast. The final theorem therefore needs no known annotation
alphabet, no checkEmpty argument, no DecidableEq Node, and no assumed successful
external observation. Its existing Context and Profile gates are sufficient
original admissions. The source remains the literal
beforeCaller.checked.native.machine.heap, independently of inventory.source.

## Circularity check

TargetQuery.finite takes Ready, inventory At, original operand availability and
closedness, checked WordRanges, and original global-memo validity. It constructs
the trace through the pre-existing Inventory.query_complete/covered/warm query
completion chain. These APIs do not take a future body-depth bound, the new
prefix result, a final Bounded heap, or a future degree supplier. Their semantic
completion/rank certificates are derived from the original source and input
model. The numeric Fits and Room premises bound only the original caller and
supply the already-proved width/range admission.

Within the generic proof initial_bounded is applied separately at each ACTUAL
reached heap after its Facts are derived from physical preservation. Such use
is legitimate for an existential ceiling over a derived finite trace. It is not
a public later-heap assumption. The proof does not obtain a uniform ceiling by
applying initial_bounded to an arbitrary unknown future heap family.

The supplied generic Trace is a local intermediate premise. The final caller
proof derives it from original admission rather than exposing it as a new
completion oracle. All original completion fields remain in the old producer;
the new proof adds an independent theorem and changes no old receipt.

## Quantitative and domain limits

The resulting ceiling is existential and can depend on the derived finite
completion trace. This candidate does not identify it with an explicit formula
of Profile, the computed instructionBound, or L + semanticR. The old computed
fuel/stability theorem remains available independently. No efficient runtime
algorithm for computing this maximum is claimed.

All runtime fuels are covered for each admitted original call. Because such a
call has a completed physical trace, a terminal error or stable blocked outcome
from the SAME entry cannot coexist with that completion. The theorem includes
all actual finite observations under its admissions, including yielded finite
prefixes. It is not a bound for malformed checked starts that violate those
admissions or for native blockers in unrelated calls.

The theorem does not prove a ceiling fixed by generator startup data across
arbitrarily many generated queries. Inventories still rebase to later physical
query-entry heaps. Each actual next query must receive its own proved original
admission. A global cross-query ceiling, finite global native-handle universe,
whole-generator termination/coverage and Haskell correspondence are separate.

## Provenance and read scope

No whole Lean source acquisition was made in this task; every repository source
read was an exact literal cut. read-scope.json records all requested endpoints,
actual endpoints, full input identities, copied cut bytes, SHA256 values, and
whole/partial status. Source copies are not labeled as whole files. Repository
source hashes were verified again before freeze. Candidate and draft were
whole-read independently of the repository-source acquisition budget.
