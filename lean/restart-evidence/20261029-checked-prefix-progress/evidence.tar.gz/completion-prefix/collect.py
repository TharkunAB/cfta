from pathlib import Path
import hashlib,json,sys
b=Path('/tmp/mcfta-checked-prefix-progress-20261029/completion-prefix/evidence-v1');m=b/'read-scope.json';rs=json.loads(m.read_text()) if m.exists() else []
for arg in sys.argv[1:]:
 source,start,end=arg.split(':');p=Path(source);d=p.read_bytes();ls=d.splitlines(keepends=True);start=int(start);requested=end;end=len(ls) if end=='EOF' else min(int(end),len(ls));c=b''.join(ls[start-1:end]);t=b/'inputs'/f'{len(rs)+1:02d}-{p.stem}-L{start}-L{end}.lean.txt';t.write_bytes(c);r={'source':str(p.resolve()),'source_sha256':hashlib.sha256(d).hexdigest(),'source_bytes':len(d),'source_lines':len(ls),'start':start,'end':end,'requested_end':requested,'whole':start==1 and end==len(ls),'copy':str(t),'cut_sha256':hashlib.sha256(c).hexdigest(),'cut_bytes':len(c)};rs.append(r);print(json.dumps(r));print(''.join(f'{n}: {v.decode()}' for n,v in enumerate(ls[start-1:end],start)),end='')
m.write_text(json.dumps(rs,indent=2)+'\n')
