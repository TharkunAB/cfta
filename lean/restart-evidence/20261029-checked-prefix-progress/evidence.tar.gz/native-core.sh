set -eu
CFTA_TASK_Z3_BIN_DIR=$(dirname "$(command -v z3)")
export PATH="$CFTA_TASK_Z3_BIN_DIR:/usr/bin:$PATH"
cabal test cfta:unit-tests --test-show-details=direct --test-options='--seed 492294335'
