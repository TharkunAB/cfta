from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/tritlo/Code/mcfta');area=Path('/tmp/mcfta-accepted-prefix-20261028');review=area/'root-source-review';review.mkdir()
def digest(data):return hashlib.sha256(data).hexdigest()
sources=[]
modules=json.loads((area/'modules.json').read_text())
for module in modules:
 p=root/'lean/MicroCFTA'/(module+'.lean');b=p.read_bytes();q=review/'sources'/p.name;q.parent.mkdir(exist_ok=True);q.write_bytes(b)
 sources.append(dict(source=str(p),whole=dict(path=str(q.relative_to(review)),bytes=len(b),sha256=digest(b)),cuts=[],review_scope='Whole final source read through initial whole text and all exact version deltas. Actual failed check lineage retained.'))
for name in ['new-public-blocks.txt','root-contract-comparisons.json','public-prefix-comparison.json','source-validation.json','preservation-validation.json']:
 p=area/name;b=p.read_bytes();q=review/'sources'/name;q.write_bytes(b);sources.append(dict(source=str(p),whole=dict(path=str(q.relative_to(review)),bytes=len(b),sha256=digest(b)),cuts=[],review_scope='Whole new public text or validation record read. Final public delta read in full.'))
p=root/'lean/notes-current-accepted-prefix-models.md';b=p.read_bytes();q=review/'sources'/p.name;q.write_bytes(b);sources.append(dict(source=str(p),whole=dict(path=str(q.relative_to(review)),bytes=len(b),sha256=digest(b)),cuts=[],review_scope='Whole new note read.'))
for r in json.loads((area/'document-validation.json').read_text()):
 if 'inserted_bytes' not in r:continue
 p=root/r['path'];b=p.read_bytes();old=(area/'prior-documents'/r['path']).read_bytes();offset=r['offset'];end=offset+r['inserted_bytes'];assert b[:offset]+b[end:]==old;ins=b[offset:end];q=review/'insertions'/(r['path'].replace('/','__')+'.txt');q.parent.mkdir(exist_ok=True);q.write_bytes(ins)
 first=len(b[:offset].splitlines())+1;last=first+len(ins.splitlines())-1
 sources.append(dict(source=str(p),source_bytes=len(b),source_sha256=digest(b),reconstruction=dict(prior=dict(path=str(area/'prior-documents'/r['path']),bytes=len(old),sha256=digest(old)),insert=dict(path=str(q),bytes=len(ins),sha256=digest(ins)),offset=offset),cuts=[dict(path=str(q.relative_to(review)),bytes=len(ins),sha256=digest(ins),first_line=first,last_line=last)],review_scope='Only exact current insertion read. Whole older body preserved by inverse.'))
(review/'source-index.json').write_text(json.dumps(dict(sources=sources),indent=2)+'\n')
commands=[]
for p in sorted(area.glob('*/report.json')):
 
 if p.parent.name=='prior-public-readback':continue
 r=json.loads(p.read_text());b=(p.parent/'raw.log').read_bytes();assert len(b)==r['bytes'] and digest(b)==r['sha256'];assert r['cgroup_limits']=={'memory.max':'4294967296','memory.high':'4294967296','memory.swap.max':'0'};commands.append(dict(name=p.parent.name,report=r))
assert len(commands)==14 and sum(r['report']['exit_code']!=0 for r in commands)==4
(area/'actual-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(area/'current-document-changes.patch').write_bytes(subprocess.check_output(['git','diff','--',*json.loads((area/'document-paths.json').read_text())],cwd=root))
(review/'report.md').write_text("""# Root final source and evidence review

CLEAR. All six final sources read through initial whole sources and exact repair deltas. Entire 14-block new public appendix (1008 lines, 78219 bytes), whole 13050-byte new note, all nine exact new document insertion regions and complete validation records read. Eight common insertion regions are byte-identical; FINDINGS adds the Haskell handoff. Whole older bodies are inverse-preserved. No whole-reading claim applies to large historical document bodies.

An original accepted native term supplies literal startup Satisfies and empty pending refutation. Actual selected-prefix forward preservation retains the SAME assignment at the actual parked or narrowed cache under three explicit sufficient original fits/admits policies. Full Mu/Union meaning uses existing Read.exact under the original Context's guarded and budget semantic heaps. No accepted returned-row or future graph-language premise is introduced. Actual stored reads, representatives, writes and frame give the result. The old canonical prefix producer fixes its bound before all models, retains all three old stable families and runs once. A parked model does not establish raw continuation progress or eventual output existence.

The accepted-head callback extension retains the entire original 16289-byte declaration, original producer once, original pending refutation/avoidance/per-program encoding. The same actual callback Frame transports the SAME extended assignment to the literal framed recursive input. Original non-rejection, pending refutation and exact summed-fuel resume equation remain. Startup1485B and prefix2466B declarations also recover literally after name/grouping/observer removal. No input model gate or old resource-field loss.

DONE is empty expandable candidates. CacheValid classifies retained SOME pending handles as recursive boundaries with empty buckets. ProperState handles NONE slots; explicit nonrecursive reached pending handles yield Discharged. Original boundary-root startup gives full Packet/Proper/carriers, NOTDischarged, actual singleton DONE output at the SAME caller/cache/query for every fuel, and actual marker rendering. This is an original-admission family, no closed instantiated physical Context or public Haskell run. The Haskell marker and TruncatedRecursion source paths agree with intentional opacity; no new defect or required fix is inferred. FINDINGS retains previous integrated LPO/KBO repair evidence. No Haskell/Cabal edit, test or benchmark ran.

Full objective remains whole CFTA: graph transformations, soundness and permitted-policy coverage, public APIs, rank/sample and physical Haskell correspondence. Largest remaining gap composes original accepted-model preservation through the SAME recursive run and proves appropriate output coverage INCLUDING intended opaque/truncated recursive outputs. Do not require every DONE output Discharged. Selected-variable ProgramAt and public typing/template origins remain. Native acceptance does not imply forbidden-template avoidance. Aggregate zero-output endpoint invariant remains separate. Goal ACTIVE; checkpoint PROGRESS.

Final seven strict source/Audit checks PASS; full Audit4331 jobs80527 dependencies. Existing replay warning remains distinguished from strict checks. All14 current compiler/build/public commands retained, four full failures read before repairs. Prefix failures concern projections, shadowing, contains/Empty normalization and unnecessarySimpa; boundary failures concern explicit types/namespace/localexistingMonad and compiled resume matcher. No intended statement was weakened. Accidental duplicate PrefixMeaning removed before compilation; both drafts retained. Optional low-level completion wrapper remains UNTESTED/unpublished. No suppressions/customaxioms/sorry/admit/native_decide. Serial measured4GiB memory.max/high and zero swap.

Public323 theorem blocks9defs1292203B SHA d69e320cb852a354647a64dec18fd3aaa5da747cf84793bc085d6bf8dee6d25c, exactold309+9defs1213984Bprefix, new78219B. Onlystandard3axioms. All4324oldnonAuditLean173strong810trackedHaskellsource/evidence bytes preserved. Audit onlysiximports. Fresh current reviews own only their subtrees; all earlier evidence remains frozen.
""")
print(json.dumps(dict(status='pass',root_source_records=len(sources),commands=len(commands),failures=4)))
