# The complete candidate and its exact diff from the frozen completed proof are retained. No generation rerun is required.
