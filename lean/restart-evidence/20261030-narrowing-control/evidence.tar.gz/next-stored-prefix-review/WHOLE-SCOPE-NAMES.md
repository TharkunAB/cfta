# Named new old whole sources

Both slots unused.

2026-10-30 22:35 CET: Slot1of2 names SourceCurrentNativeTracePrefixBind.lean70L before whole-body acquisition. Its checked prefix decomposition may remove the need for a new helper. Slot2 unused.
