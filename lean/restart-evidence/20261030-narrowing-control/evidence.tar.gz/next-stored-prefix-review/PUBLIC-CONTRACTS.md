# Complete public contracts

Status: UNCOMPILED source-only candidate. Root owns checks.

```lean
import MicroCFTA.SourceCurrentAllocatedNativeStoredTrace
import MicroCFTA.SourceCurrentNativeTracePrefixBind

/-!
# Conditional native cache certificates at actual checked prefixes

UNCOMPILED source-only draft.
The proof consumes a finite actual prefix. It does not require a future return.
-/
namespace MicroCFTA.SourceCurrentAllocatedNativeStoredPrefix
open Cache InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand SourceEqualityNativeDemandBodyCode
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace)
open SourceCurrentAllocatedNativePhysicalCompletion (Good)
open SourceCurrentAllocatedNativeFieldClosure (Fields)
open SourceEqualityRequiredSemanticCache (SemanticReady)
open SourceCurrentAllocatedFiniteOrdinaryStored SourceCurrentAllocatedFiniteOrdinaryCode
open SourceCurrentAllocatedFiniteOrdinaryExecution (CertifiedControl)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Checked" => SourceEqualityNativeDemand.State
variable {width : Nat}

```

```lean
theorem clean_prefix_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (fuel : Nat) {Output : Type} (control : Control Output) (before after : Checked width) (remaining : Control Output)
    (trace : Trace fuel control before remaining after)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap)
    (fields : Fields control before) (stored : Stored before.native) (clean : Clean control) :
    Stored after.native
```

```lean
theorem terminal_prefix_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (fuel : Nat) {Output : Type} (control remaining : Control Output) (before after : Checked width)
    (trace : Trace fuel control before remaining after)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap)
    (fields : Fields control before) (stored : Stored before.native) (clean : Clean control) :
    match step remaining after with
    | .yielded .. => True
    | observed => Stored observed.state.native
```

```lean
theorem node_prefix_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (request : NodeRequest Symbol Guard) (before after : Checked width) (fuel : Nat)
    (remaining : Control (Value Symbol Guard))
    (trace : Trace fuel (.code (requestNode request.domain request.left request.right)) before remaining after)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap) (stored : Stored before.native) :
    Stored after.native
```

```lean
theorem edge_prefix_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (request : EdgeRequest Symbol Guard) (before after : Checked width) (fuel : Nat)
    (remaining : Control (EdgeValue Symbol Guard))
    (trace : Trace fuel (.code (requestEdge request.domain request.left request.right)) before remaining after)
    (good : Good before) (semantic : SemanticReady before.native.machine.heap) (stored : Stored before.native) :
    Stored after.native
```

```lean
theorem initial_clean_prefix_stored [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (cache : Cache.State SourceEqualityPartialConstraintKey.Key)
    (heap : InternedConstructorTemplates.State Symbol Guard)
    (fuel : Nat) {Output : Type} (control remaining : Control Output) (after : Checked width)
    (trace : Trace fuel control (SourceCurrentAllocatedPartialInitialization.checked width cache heap) remaining after)
    (good : Good (SourceCurrentAllocatedPartialInitialization.checked width cache heap))
    (semantic : SemanticReady heap)
    (fields : Fields control (SourceCurrentAllocatedPartialInitialization.checked width cache heap))
    (clean : Clean control) : Stored after.native
```
