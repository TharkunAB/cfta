# Native Stored preservation at actual prefixes

Owner: /root/stored_prefix_review. Source-only bounded work.
Write only in this fresh directory. No compiler, evaluator, native, Git, network, board, production, or spawning. Root owns these actions.
Find an existing prefix bind decomposition or draft the smallest actual-prefix Stored preservation law.
Keep observed physical Inputs and step equations. Never assume a future completed Trace or desired completion.
At most TWO newly named OLD whole or near-whole modules. Name before acquisition. Ask Root for any third.
Retain exact source hashes, literal cuts, cumulative unions and incidents. Frozen reuse requires manifest/source/copy identities.
Allowed frozen reuse: native-renewal-review manifest47b6774915970f51a47ae360756455563910d71f44ee49da7b1ac165ed0a76d2 and public-review-source-inputs manifestac9d9f610269dbe33543c0f843cd9acfce9d90ad7d9ce66f25f3bd5e10b0b216 in the published native-memo-stored-control bundle.
The full original-input, both-worker, order/stop, optimized-core, public adapter and Haskell goal remains open. No Haskell defect/fix is established.
Freeze report, complete contracts, metadata, original drafts and all files before stopping.
