# Native Stored at actual finite prefixes

## Status

Source-only deliverable: NativeStoredPrefix-v3-UNCOMPILED.lean.
The proposed production module is MicroCFTA.SourceCurrentAllocatedNativeStoredPrefix.
The final draft has343lines/25897bytes, SHA256
fb53f7f56684003ec08a490db803900457033199f5105f4d7e875f55c0307391.
It contains five complete public proof candidates and no placeholders.
The owner ran no compiler, evaluator, native command, Git, network or board.
Root reports that no prefix draft has been probed yet. All versions remain
UNCOMPILED. Root will check V3 after the separate narrowing checkpoint.
No theorem acceptance or runtime behavior result is claimed here.

## Existing helper removes the proposed new decomposition

SourceCurrentNativeTracePrefixBind.bind_prefix_cases already handles the
exact checked physical Trace. It preserves each Inputs witness and actual
step equation. Its first branch gives an unfinished unbound call prefix at
the same fuel and state. Its second branch gives an actually completed body
and an actual continuation prefix, with exact fuel addition and shared state.
The pure return adds no instruction. The helper does not require a future
completed call. No new bind-prefix definition or verifier is introduced.
This70-line old module was named before whole acquisition as slot1of2.
The lower native PrefixSplit modules were inspected only at declarations.
They do not need to replace the existing checked helper.

## Five complete public contracts

PUBLIC-CONTRACTS.md/json retain all headers, imports, local aliases, implicit
width and Output types, equality instances and the exact terminal match.

| Law | Exact supplied observation and result |
| --- | --- |
| clean_prefix_stored | Any actual finite physical Trace from a Clean control to an arbitrary remaining control retains conditional native Stored. |
| terminal_prefix_stored | After that prefix, inspect the actual next step. Done, Failed, ConstraintError and Blocked retain Stored in their own returned state. Yielded has conclusion True. |
| node_prefix_stored | The literal node request supplies its own Fields and Clean. Its actual remaining control can be arbitrary. |
| edge_prefix_stored | The corresponding literal edge request prefix law. |
| initial_clean_prefix_stored | Start at the literal existing checked initializer and derive initial Stored internally. |

The generic prefix law retains initial Good, SemanticReady, Fields, Stored
and Clean. Every prefix step still has its actual Inputs witness. Literal
request companions derive Fields/Clean and retain the other gates.
The initial companion has no entry Stored or initial-state-equality input.
It retains Good, SemanticReady, Fields and Clean at the existing initializer.
No NodeInputs, EdgeInputs, body certificate, desired outcome, future completed
Trace, Complete or coverage callback is supplied by a caller.

Stored keeps its existing conditional meaning. Empty-seen requests with
both operands recursively finite ordinary receive the structural result and
both height bounds. Other requests impose no result condition for that owner.
These laws do not prove recursive operand domains or unrestricted heights.
They do not identify native Stored with result scope or the separate merge
memo predicate. An arbitrary externally supplied warm Context still needs
its own initial native Stored argument unless it comes from the literal
initializer and an admitted actual prefix.

## Prefix proof argument

The candidate adapts the exact frozen completed-call source. It retains the
same actual primitive, direct dispatch and warm-cache cases. The new induction
generalizes the final control rather than requiring a final pure value.
For each cold owner it first obtains Fields for the unbound compiled body.
It applies the existing checked bind-prefix decomposition to the actual tail.
If the tail is still inside that body, the smaller-fuel prefix induction
applies to that actual body prefix. It needs no result certificate yet.
If the body has actually returned, the old completed-call certificate proof
is used on that observed completed body. Ordinary owners use verified;
nonordinary owners use the existing completed Clean law and the conditional
certificate contradiction. No future body return is inferred or assumed.

A zero-length finish prefix leaves Stored unchanged before publication.
A nonempty finish prefix has the actual literal finish step. Frames retain
its exact evaluating owner through the actual completed body. The proof
publishes that owner's real certificate and applies the prefix induction to
the remaining continuation. Nested ordinary owners are treated individually.
No outer nonordinary request makes all nested certificates vacuous.

## Terminal state distinction

A checked Trace contains yielded steps. A terminal observation can still
change its returned heap or memo phase after the final yielded prefix.
The private terminal-step candidate handles this separate effect.
Node and edge terminal demands retain Stored by the existing unconditional
lookup/demand laws. Optional binder blocking advances only the machine.
The checked edge body retains the literal native state in every outcome.
Pure returns and source failure keep the same native tables. Raw driver
finish always yields and therefore has no stopped-case assertion here.

The public terminal law computes the actual step. It makes no assertion
about the successor of a Yielded step. To cover that successor, extend the
actual checked Trace with its Inputs witness and use clean_prefix_stored.
It does not claim an arbitrary unchecked final step preserves certificates.
The terminal helper supplies no semantic guarantee for an unvalidated result.

## Preserved versions and source reads

V1 is284lines/22337bytes, SHA256
f57f878523f4240031a4ca901d4c60489a1321f2a1c79c9c1c1fe2c9a2a5762e.
It has the four prefix laws without the terminal companion.
V2 adds the terminal helper and companion. V3 removes one trailing trivial
from the direct yielded case because simp already closes it. This is a
source-review repair. No compiler failure or pass was observed by this owner.
All four V1 headers and proof bodies remain byte-identical inside V3.
Removing V3's inserted terminal block reproduces the full V1 exactly.
The final draft, all five headers and the full old completed source were read.
READ-DISPLAYS.json records complete read coverage and exact unchanged reuse.

The ledger has13 records over10 sources. Only one newly named old whole
source was acquired. Slot2 remains unused. Other fresh source unions are
57of160,46of209,18of267,9of145,9of559, and four declaration lines in each
of the two lower PrefixSplit modules. Frozen whole source reuses are the
published290-line StoredTrace and132-line native dispatch source. Both
match their retained manifest entries and complete current source hashes.
The metadata verification checks every source hash, cut and cumulative union.
There were no failed source commands, truncated body displays or scope
exceptions in this task. No Haskell source was read or changed.

## Remaining work

Root must compile exact V3 and repair it outside this frozen owner scope.
The full whole-caller/EnabledEmpty transport remains separate. These laws
consume existing observed physical traces; they do not derive all such
traces from arbitrary raw execute observations. They do not prove future
termination, sufficient original recursive depth, handle renewal bounds,
raw multiplicity/work bounds, ordered finite-prefix coverage, public adapters
or Haskell correspondence. No Haskell defect, fix or repair candidate follows.
The original full goal remains open.

The owner freezes every payload, manifest, pins and version, then stops writes.
