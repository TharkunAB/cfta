import MicroCFTA.SourceEqualityNativeDemandTraceSplit
namespace MicroCFTA.SourceEqualityNativeDemand
theorem steps_bind_cases [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem Steps.length_le_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
