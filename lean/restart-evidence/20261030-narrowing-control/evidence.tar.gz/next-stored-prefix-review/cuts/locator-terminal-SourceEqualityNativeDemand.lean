inductive Outcome (width : Nat) (Output : Type) : Type 1 where
def Outcome.state : Outcome width Output → State width
def lift (operations : Operations) : SourceRecursiveIntersectionNative.Outcome width Symbol Guard Output → Outcome width Output
