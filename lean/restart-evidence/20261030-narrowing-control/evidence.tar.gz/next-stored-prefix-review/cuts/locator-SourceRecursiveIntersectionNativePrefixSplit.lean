import MicroCFTA.SourceRecursiveIntersectionNativeTraceSplit
namespace MicroCFTA.SourceRecursiveIntersectionNative
theorem steps_bind_cases [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
theorem Steps.length_le_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
