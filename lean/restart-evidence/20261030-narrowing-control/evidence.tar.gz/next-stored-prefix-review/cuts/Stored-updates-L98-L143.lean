theorem initial_stored (width : Nat) (machine : Machine Symbol Guard) : Stored (initial width machine) :=
  ⟨returned_empty _, returned_empty _⟩

/-- Physical machine changes retain the same stored structural certificates. -/
theorem advance_stored (state : Native width Symbol Guard) (after : Machine Symbol Guard)
    (stored : Stored state) : Stored (advance state after) := ⟨stored.nodes, stored.edges⟩

/-- Node publication creates only a suspended request and retains completed certificates. -/
theorem lookupNode_stored (state : Native width Symbol Guard) (request : NodeRequest Symbol Guard)
    (stored : Stored state) : Stored (lookupNode width request state).2 := by
  cases key : SourceRecursiveIntersectionMemo.requestKey width request.domain request.left request.right with
  | none => simpa only [lookupNode, key] using stored
  | some keyValue =>
      simp only [lookupNode, key]
      exact ⟨returned_lookup _ keyValue request state.nodes stored.nodes, stored.edges⟩

/-- Edge publication retains completed certificates in both families. -/
theorem lookupEdge_stored (state : Native width Symbol Guard) (request : EdgeRequest Symbol Guard)
    (stored : Stored state) : Stored (lookupEdge width request state).2 :=
  ⟨stored.nodes, returned_lookup _ _ request state.edges stored.edges⟩

/-- Node demand cannot add a returned result. -/
theorem demandNode_stored (state : Native width Symbol Guard) (handle : Nat)
    (stored : Stored state) : Stored (demandNode handle state).2 :=
  ⟨returned_demand _ handle state.nodes stored.nodes, stored.edges⟩

/-- Edge demand cannot add a returned result. -/
theorem demandEdge_stored (state : Native width Symbol Guard) (handle : Nat)
    (stored : Stored state) : Stored (demandEdge handle state).2 :=
  ⟨stored.nodes, returned_demand _ handle state.edges stored.edges⟩

/-- Node finish stores a local certificate at its literal evaluating owner. -/
theorem finishNode_stored (state : Native width Symbol Guard) (handle : Nat)
    (request : NodeRequest Symbol Guard) (result : Value Symbol Guard) (stored : Stored state)
    (running : state.nodes.cells handle = some ⟨request, .evaluating⟩)
    (certificate : NodeCertificate request result) : Stored (finishNode handle result state) :=
  ⟨returned_finish _ handle request result state.nodes stored.nodes running certificate, stored.edges⟩

/-- Edge finish stores a local certificate at its literal evaluating owner. -/
theorem finishEdge_stored (state : Native width Symbol Guard) (handle : Nat)
    (request : EdgeRequest Symbol Guard) (result : EdgeValue Symbol Guard) (stored : Stored state)
    (running : state.edges.cells handle = some ⟨request, .evaluating⟩)
    (certificate : EdgeCertificate request result) : Stored (finishEdge handle result state) :=
  ⟨stored.nodes, returned_finish _ handle request result state.edges stored.edges running certificate⟩

/-- A physical warm node hit identifies the request before reading its conditional certificate. -/
