# Named old whole acquisitions

No whole acquisitions yet. Two slots available.

Slot 1 of 2, named before complete acquisition: SourcePruningNativeView.lean177L. The exact completion proof supplies read_closed intermediate readiness and constructor effects for normalized completion. Existing cuts cover106/177. Slot 2 remains unused.
