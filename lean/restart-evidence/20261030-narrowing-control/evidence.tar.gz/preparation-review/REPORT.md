# Nonboundary preparation renewal: exact row-filter control

Status: SOURCE REVIEW AND UNCOMPILED DRAFT. No compiler or evaluator ran.
The full original-input objective remains incomplete.
Root owns all production, checks, Git, network, board and publication.

## Result and limit

The generic Action.prepare function has a changed-handle write branch.
Its actual OuterNarrow.narrow supplier uses NativeView.narrowAt.
This primitive filters complete root rows and rebuilds an ordinary node.
It does not perform native recursive intersection.
The complete edge records, including children, remain unchanged.
This gives a smaller normalization argument for this particular writer.
Incoming and dispatch intersection writers remain separate.
A potential writer is not an admitted renewal execution or a Haskell defect.

Four public source drafts are in SourcePruningNarrowControl-v3-UNCOMPILED.lean.
The exact draft has 159 lines and 9,572 bytes.
SHA256: d150dc8bbd935e0cd728cdd3d50e44e0a21fd9d3a680b19a4f4c8a7906389202.
V1 and V2 remain. All versions are UNCOMPILED.

| Draft law | Actual supplied gates | Intended local result |
| --- | --- | --- |
| SourcePruningNativeView.narrowAt_of_normal | Ordinary root, literal physical Normal, all current rows retained by this key | Every fuel returns the same complete value and exact heap. |
| SourcePruningNativeView.narrowAt_complete_control | Ready, Available, closed actual input | Derive one stable actual narrowing result with Keeps, Available, closedness, Ordinary, physical Normal, retained complete rows, and exact same-key replay at every fuel. |
| SourcePruningNativeView.narrowAt_ordinary_rows | Actual successful narrowing equation, Ready, Available, Ordinary root | Each returned complete root edge was an original root edge and passes this key. No recursive finite-ordinary child-domain gate or closedness premise. |
| SourcePruningEnumerationAction.prepare_of_normal | Ordinary root, physical Normal, all current rows retained, actual encodeNode equation | The actual preparation returns the same value and heap with the literal pure action. It cannot rewrite the stored handle in this case. |

The completion companion derives physical Normal from the actual makeNode
operation with EqualityOrdinaryReadback.makeNode_normal. It does not assume
that its future result is normalized. The existing read_closed theorem
supplies its finite source reader, intermediate Ready, resident rows and
closed rows. Existing node construction supplies its actual Keeps packet.
No new future coverage, completion, trace or verification supplier is used.
The old narrowAt_complete theorem remains unchanged.

The Normal premise in the replay and preparation laws is exact:
run (makeNode (nodeEdges value)) heap = (value, heap).
Generic Ready and Available do not by themselves state this property.
The completion law derives it at the returned heap. Existing normal_grows
can retain it under actual coherent cache growth.

## Literal call chain

1. OuterNarrow.narrow11-21 retains Mu and slots in metadata.types.
   Its remaining branch calls NativeView.narrowAt at holeKey metadata.typing uv.
2. NativeView.narrowAt33-43 exposes root rows and executes
   makeNode (rows.filter (keeps fits admits key)).
   keeps21-30 checks full labels and annotation values. It retains whole rows.
3. Action.prepare26-41 encodes that result. Equal handles select pure ().
   Different handles select representative then setValue with the same SCS.
4. SelectedStep.runPrefix50-91 reads the pending slot, checks repetition,
   calls this preparation, runs its action, adapts the index, and calls Right
   recording before any ordinary sibling scan in this prefix.
5. SelectedPreparation.run45-52 then enters the selected slot and invokes
   SelectedValue.run. This is a separate preparation operation.
6. SelectedValue.run19-34 unfolds one selected Mu, exposes and rebuilds a
   selected Union, or retains any other value.
7. SelectedValueCaller.advance27-29 installs that returned heap and retains
   the other caller components. This immediate stage does not overwrite core.
8. SelectedContinuations.run41-60 and SelectedOrdinaryDispatch.run36-46 pass
   the entered core and this advanced caller to the actual subsequent branch.
   Terminal SCS selects the opaque branch first. A nonterminal node selects
   the ordinary scan. Other prepared values use opaque dispatch.
   Later dispatch needs its own storage-write analysis.

The recursiveBoundary=true retention law covers its checked boundary case.
It does not establish neutrality for every nonboundary preparation branch.
The new draft uses the actual nonboundary filtering implementation instead.

## Varying keys and original resources

The row-subset draft applies to every actual key. It has no unchanged-key
premise. Repeated filter-only steps cannot introduce a complete root row.
The source key of each makeNode request is the canonical surviving edge-ID
set. Thus subsets of a fixed source row list give a finite request-key carrier.
The literal constructor definition is ConstructorTemplates248-253.
NodeSetCongruence.makeNode_same_ids29-38 equates requests with equal surviving
identity sets under coherent resident-row gates.

This is not yet a checked bound on physical handles across all executions.
Identities can differ between independent heaps. A concrete monotone cache
lineage must connect repeated requests to the same interned identities.
A useful next strict measure is the finite set of complete root edges in a
filter-only segment after its first ordinary normalization. If both results
are physical normal forms in a common coherent growing heap, equal surviving
row sets give the same makeNode request and the same physical value. An actual
changed encoded handle would therefore require a strict row-set loss.
The strict finite-cardinality argument is not included in this draft.

Incoming intersections can replace children and reset the row carrier.
Prepared selected Mu unfolding and Union exposure use different operations.
Their effects are not bounded by this root-row filtering argument.
No sufficient ORIGINAL recursive depth, complete ordered prefix, bound on
all earlier alternatives or staged children, or Haskell correspondence follows.
Do not present fixed-key replay as a guarantee that future metadata keys stay
unchanged. Recording can update metadata.typing.

## Acquisition and preservation

SCOPE.md names the source-only boundary. Exactly one old whole module was
named before acquisition: SourcePruningNativeView.lean177L. One slot is unused.
There are 28 literal cut rows. Locator output remains in full in this bundle.
Pins retain exact source hashes, line lists and cumulative unions.
Only the named NativeView source reaches the whole/near-whole threshold.
No frozen historical body was reused. No unfrozen sibling file was read.

Initial filename guesses for NativeFilter, NodeResidency, MergedNormalFacts,
MergedNormalInputs and Prepared drivers did not exist. Their source searches
ran no evaluator. Locator results and the failed guesses remain identified
in inspection-incidents.json. An initial filename listing returned no matches;
an explicit directory-name listing located the selected dispatch modules.
No failed proof check exists because no proof check ran.

No Haskell source changed. No native command ran. No executable defect, fix,
or repair candidate is established. Root should keep that boundary in FINDINGS.
