# Preparation renewal measure source review

Own only this fresh directory. Root owns production, compiler, evaluator, native, Git, network, board and packaging. Do not spawn.
Follow actual nonboundary preparation before constructor production and the corresponding Prepared selection branch.
Find an original well-founded measure or exact normalization bound for changed physical handles. Preserve full original-input goal and both-worker, order/stop, optimized-core and Haskell correspondence scope.
Read old modules in bounded ranges and retain source identities, exact cuts, and cumulative unions. At most two newly named old whole or near-whole modules. Name each before body acquisition. Ask Root before any third.
Reuse only frozen neutral-recording root/source bundles with identity pins. Do not read unfrozen sibling bundles.
No future coverage/completion/trace supplier, selected-branch-only argument, or equation of key shape cardinality with raw work.
A potential handle writer is not an admitted renewal execution or a Haskell defect.
Freeze all outputs before reporting.
