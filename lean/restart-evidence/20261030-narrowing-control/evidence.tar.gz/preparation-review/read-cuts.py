from pathlib import Path
import sys,json,hashlib
r=Path('/tmp/mcfta-preparation-renewal-measure-review-20261030');root=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
pins=r/'pins.json';rows=json.loads(pins.read_text()) if pins.exists() else []
name,lo,hi=sys.argv[1],int(sys.argv[2]),int(sys.argv[3]);p=root/name;data=p.read_bytes();ls=data.splitlines(keepends=True);hi=min(hi,len(ls));assert 1<=lo<=hi
union=set(range(lo,hi+1))
for row in rows:
 if row['source']==str(p):union.update(row['actual_lines'])
whole=json.loads((r/'whole-names.json').read_text()) if (r/'whole-names.json').exists() else []
assert len(union)<=0.70*len(ls) or name in whole,('whole/near-whole requires named slot',name,len(union),len(ls))
cut=b''.join(ls[lo-1:hi]);target=r/'cuts'/f'{name}-L{lo}-L{hi}.txt';target.parent.mkdir(exist_ok=True);target.write_bytes(cut)
rows.append({'source':str(p),'source_bytes':len(data),'source_lines':len(ls),'source_sha256':hashlib.sha256(data).hexdigest(),'actual_lines':list(range(lo,hi+1)),'cut':str(target.relative_to(r)),'cut_sha256':hashlib.sha256(cut).hexdigest(),'cumulative_union':len(union)})
pins.write_text(json.dumps(rows,indent=2)+'\n')
print(f'{name}:{lo}-{hi}, cumulative {len(union)}/{len(ls)}')
for n,line in enumerate(ls[lo-1:hi],lo):print(f'{n}: '+line.decode().rstrip('\n'))
