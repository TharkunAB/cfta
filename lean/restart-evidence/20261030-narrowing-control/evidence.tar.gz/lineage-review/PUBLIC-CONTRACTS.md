# Complete UNCOMPILED public contracts

```lean
theorem narrowAt_changed_loses_row [DecidableEq (EdgeKey Symbol Guard)]
    (fits : Key → Symbol → Bool) (admits : Key → Value Symbol Guard → Bool)
    (fuel : Nat) (key : Key) (value result : Value Symbol Guard) (before after : State Symbol Guard)
    (oldHandle newHandle : Nat)
    (ready : SourceEqualityRequiredCache.Ready before)
    (available : Available before value) (ordinary : SourceEqualityRequiredCache.Ordinary value)
    (normal : EqualityOrdinaryReadback.Normal before value)
    (returned : narrowAt fits admits fuel key value before = .done result after)
    (oldEncoded : SourcePruningEnumerationNodes.encodeNode value = some oldHandle)
    (newEncoded : SourcePruningEnumerationNodes.encodeNode result = some newHandle)
    (changed : newHandle ≠ oldHandle) :
    (∀ edge ∈ nodeEdges result, edge ∈ nodeEdges value) ∧
      ∃ edge ∈ nodeEdges value, edge ∉ nodeEdges result
```

```lean
theorem narrowAt_constructed_changed_loses_row [DecidableEq (EdgeKey Symbol Guard)]
    (fits : Key → Symbol → Bool) (admits : Key → Value Symbol Guard → Bool)
    (fuel : Nat) (key : Key) (edges : List (EdgeValue Symbol Guard))
    (value result : Value Symbol Guard) (original built before after : State Symbol Guard)
    (oldHandle newHandle : Nat)
    (ready : SourceEqualityRequiredCache.Ready original)
    (resident : InternedNestedProvenance.Edges original edges)
    (closed : MergedColdReaderClosedInputs.ClosedEdges edges)
    (constructed : run (makeNode edges) original = (value, built))
    (lineage : SourceEqualityRequiredCache.Keeps built before)
    (returned : narrowAt fits admits fuel key value before = .done result after)
    (oldEncoded : SourcePruningEnumerationNodes.encodeNode value = some oldHandle)
    (newEncoded : SourcePruningEnumerationNodes.encodeNode result = some newHandle)
    (changed : newHandle ≠ oldHandle) :
    (∀ edge ∈ nodeEdges result, edge ∈ nodeEdges value) ∧
      ∃ edge ∈ nodeEdges value, edge ∉ nodeEdges result
```

