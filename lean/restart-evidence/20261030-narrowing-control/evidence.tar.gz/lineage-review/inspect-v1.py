from pathlib import Path
import json,hashlib,sys,subprocess
r=Path(__file__).parent
repo=Path('/home/tritlo/Code/mcfta')
ledger_path=r/'acquisitions.json'
ledger=json.loads(ledger_path.read_text()) if ledger_path.exists() else []
kind=sys.argv[1]
if kind=='cut':
 name,lo,hi,label=sys.argv[2:];lo=int(lo);hi=int(hi);source=repo/'lean/MicroCFTA'/name;data=source.read_bytes();lines=data.splitlines(keepends=True);actual=list(range(lo,min(hi,len(lines))+1));copy='cuts/'+label;target=r/copy;target.parent.mkdir(exist_ok=True);b=b''.join(lines[i-1] for i in actual);target.write_bytes(b);row={'source':str(source),'source_bytes':len(data),'source_lines':len(lines),'source_sha256':hashlib.sha256(data).hexdigest(),'actual_lines':actual,'copy':copy,'copy_sha256':hashlib.sha256(b).hexdigest(),'classification':'bounded exact source cut'};ledger.append(row);print(b.decode())
elif kind=='locate':
 pattern=sys.argv[2];names=sys.argv[3:];cmd=['rg','-n',pattern,*['lean/MicroCFTA/'+n for n in names]];p=subprocess.run(cmd,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE);index=sum(a['classification']=='declaration locator' for a in ledger);(r/f'locator-{index}.stdout').write_bytes(p.stdout);(r/f'locator-{index}.stderr').write_bytes(p.stderr);print(p.stdout.decode());print(p.stderr.decode());
 for name in names:
  source=repo/'lean/MicroCFTA'/name
  if not source.exists():continue
  data=source.read_bytes();lines=data.splitlines(keepends=True);prefix='lean/MicroCFTA/'+name+':'
  indices=[int(line[len(prefix):].split(':',1)[0]) for line in p.stdout.decode().splitlines() if line.startswith(prefix)];copy='locators/'+name+'.'+str(index)+'.txt';target=r/copy;target.parent.mkdir(exist_ok=True);b=b''.join(lines[i-1] for i in indices);target.write_bytes(b);ledger.append({'source':str(source),'source_bytes':len(data),'source_lines':len(lines),'source_sha256':hashlib.sha256(data).hexdigest(),'actual_lines':indices,'copy':copy,'copy_sha256':hashlib.sha256(b).hexdigest(),'classification':'declaration locator'})
else:raise ValueError(kind)
ledger_path.write_text(json.dumps(ledger,indent=2)+'\n')
unions={}
for a in ledger:
 u=unions.setdefault(a['source'],{'source_sha256':a['source_sha256'],'source_lines':a['source_lines'],'lines':set()});assert u['source_sha256']==a['source_sha256'];u['lines'].update(a['actual_lines'])
(r/'SOURCE-UNIONS.json').write_text(json.dumps([{'source':p,'source_sha256':u['source_sha256'],'source_lines':u['source_lines'],'actual_lines':sorted(u['lines']),'union_count':len(u['lines'])} for p,u in sorted(unions.items())],indent=2)+'\n')
