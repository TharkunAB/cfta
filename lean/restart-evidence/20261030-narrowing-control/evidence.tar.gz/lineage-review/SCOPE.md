# Ordinary narrowing normalization across heap lineage

Source-only task from Root at 2026-10-30 22:33 CET.
Own only this fresh directory. No compiler, evaluator, native, Git, network, board, production or spawning.
At most TWO newly named OLD whole or near-whole modules. Name before reading. Ask Root for any third.
Retain every exact source hash, cut, locator and cumulative union.
Allowed frozen reuse: /tmp/mcfta-native-memo-stored-control-20261030/next-preparation-review, manifest 013c69246cd33f1eaf77cf628fa90b7859ab368d39b5837879f74cc7fe6c3760.
Allowed current NEW source: /tmp/mcfta-narrowing-control-20261030/narrow-control-v5.lean, SHA6c29153253d594c221f93200bec39939df8bfd5fa02b0652d782370a11fec20c. No other unfrozen sibling or Root files.
Investigate Normal preservation across actual Keeps/Grows, then strict complete-row loss for changed encoded handles or a finite handle carrier along the concrete lineage.
Do not infer physical Normal from generic Ready/Available. Incoming/dispatch intersection and Prepared Mu/Union remain separate.
No future trace, Complete, coverage or chosen-target-only supplier. Full original-input/both-worker/public/Haskell goal stays open.
No Haskell defect/fix without a fully admitted actual execution. Freeze all payloads before stopping.
