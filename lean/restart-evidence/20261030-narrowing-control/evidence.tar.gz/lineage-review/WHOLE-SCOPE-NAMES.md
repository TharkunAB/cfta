# OLD whole-source allowance

Two slots were available. Neither slot was used.
All OLD acquisitions are bounded source cuts or declaration locators.
The three reused OLD cuts are bound to the explicitly allowed frozen manifest.
The supplied Root V5 is NEW source, read under its explicit exact-byte authorization.
