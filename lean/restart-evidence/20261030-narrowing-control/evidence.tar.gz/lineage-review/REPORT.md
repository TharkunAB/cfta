# Normal narrowing lineage and strict row loss

## Result

The new deliverable is SourcePruningNarrowLineage-v2-UNCOMPILED.lean.
It has80lines/4633bytes, SHA25691a1d4aaca406915a8102cd54eaaebf7de5b358651a013083ca012c445a6a1bc.
It contains two complete source proof drafts. No compiler, evaluator or native command ran.
Root must check these exact bytes before any promotion. V1 remains unchanged.
The unique proposed module is MicroCFTA.SourcePruningNarrowLineage.
It imports Root's supplied SourcePruningNarrowControl module.

## Existing transport already closes the first gate

The explicitly allowed frozen EqualityOrdinaryReadback13–50 cut contains
normal_grows at19–25. It proves Normal after value from Normal before value,
Valid before, and the actual Grows before after relation. Its proof replays
the same original makeNode request. It does not assume generic Ready implies
Normal. There is no need to add another generic Normal transport abstraction.
SourceEqualityRequiredCache.Keeps25–29 supplies actual Grows and Ready after.
Its available law transports earlier Available through the same heap lineage.

The same frozen cut contains makeNode_normal34–50. It derives Normal for the
literal result of actual makeNode from coherent/linked resident constructor
gates and the actual result-heap growth. It does not normalize an arbitrary
unrelated stored value. The existing set_replay proof uses surviving complete
edge-set membership. A sorted-row-list uniqueness extension is not needed here.

## First new actual-step contract

narrowAt_changed_loses_row consumes an actual successful narrowAt equation.
It keeps Ready, Available, Ordinary and physical Normal at that input heap.
It also keeps the actual old/new encodeNode observations and unequal handles.
The key and both filter predicates are arbitrary for the individual step.
The conclusion states that every complete result edge belongs to the input,
and that one complete input edge is absent from the result. This is proper
set loss. Losing only one duplicate occurrence cannot satisfy this conclusion.
There is no recursive finite-ordinary NodeDomain or closed-input gate here.
Ordinary is only the actual root-form predicate. Mu children remain permitted.

The proof first uses Root's arbitrary-key narrowAt_ordinary_rows law. Suppose
no original complete row is lost. Then every original row occurs in the result,
so the same law says every original row passes keeps. Root's narrowAt_of_normal
then gives the literal original value and heap at that same fuel. The actual
successful equation identifies its result with that value. The two encodeNode
observations contradict unequal handles. This avoids distinct-cardinality or
sorted-list machinery while proving strict complete-row-set loss.

## Constructor and lineage companion

narrowAt_constructed_changed_loses_row removes current Normal, Available and
Ordinary suppliers. It consumes the literal earlier run(makeNode edges)
equation, original Ready, resident complete edges, closed edges, and the
actual Keeps relation from that constructed heap to the current input heap.
SourceEqualityRequiredCache.node derives the built result's Ready, Available,
closedness and Ordinary. makeNode_normal derives the built physical Normal.
normal_grows transports Normal through the actual Keeps.growth. Keeps.available
transports Available. The first new law then proves strict row loss.
The constructor observation concerns an actual earlier call and its returned
value/heap. It is not a requested future completion or coverage result.
The closed-row premise is explicit in this companion's constructor producer.
The first law does not need that premise.

## Exact boundaries

These are UNCOMPILED one-step source proofs. They do not give a numeric bound
on a sequence or a checked finite physical-handle carrier for the whole worker.
A sequence that retains one fixed row source and loses a complete distinct row
on every change has the required local strict relation. Formal composition
must still identify that same lineage and control source resets.
Incoming/dispatch native intersection can replace the source value and rows.
Prepared selected Mu/Union reconstruction is a different operation. Neither
writer is bounded by these two narrowing contracts. Earlier alternatives,
staged children, raw SCS work, slot creation and all neutral transitions remain.
No sufficient ORIGINAL recursive depth, ordered-prefix coverage, public adapter
result or Haskell correspondence follows. The full objective remains open.
No Haskell file was read, edited, executed or tested. No Haskell defect, fix,
repair candidate or admitted runtime renewal witness is established.

## Provenance and write halt

Eight acquisition records and four exact reuses are retained over five old
source unions. The largest fresh union is51/105lines in RequiredCache.
Zero new OLD whole or near-whole modules were acquired. Both allowed slots
remain unused. Three OLD cuts come from the exact authorized frozen manifest.
Their full repository source identities and literal cut bytes were verified.
The supplied NEW Root V5 source has exact SHA6c29153253d594c221f93200bec39939df8bfd5fa02b0652d782370a11fec20c.
All166lines were read in two complete chunks. Both new draft versions and all
complete public headers were read. READ-DISPLAYS records those ranges.
The first locator helper omitted rg filename prefixes on one-source queries.
Its original helper, ledger and empty copy remain. The corrected helper always
requests filenames and the recovered ledger keeps exactly the two shown lines.
No source-only error was hidden and no proof check was run here.
All payloads, pins and manifest will be frozen. The owner stops writes.
