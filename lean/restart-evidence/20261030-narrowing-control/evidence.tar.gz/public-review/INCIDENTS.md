# Review metadata incident

The final-tail bundle was verified and copied completely. The first extraction
script then reused the old tail filename new-public-tail.log. The final bundle
uses new-public-tail-v3.log. That script raised FileNotFoundError before the
added tail read. The exact filename list was printed. The corrected extraction
uses the actual manifest filename. No input, source or proof payload changed.
No compiler command ran.
