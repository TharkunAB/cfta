# Pruning row-filter control: independent public review

Status: source and public contracts PASS. One supplied Ordinary definition cut is pending.
This is a source-only review. Root owns compiler checks and publication.

## Complete reviewed inputs

The installed SourcePruningNarrowControl source has 165 lines and 9,839 bytes.
Its SHA256 is 4770bbbe96ea80ff3fc0159c956cf6286cced6f796b3bc09d6656536b4425e2a.
All source lines were read in three complete chunks. The full new public tail
has 96 lines and 7,332 bytes. All tail lines were read in two complete chunks.
Its SHA256 is 5d595f9487ce8895fbd1a687ad26e5d3d10941648c924aa8e78d251ba9707316.
No displayed chunk was truncated.

The source input manifest is cb1208eb45521373fb4a9571951034049c2bcbd8cae2627f14f6536202aeb8a2.
The public-tail manifest is 263f7ca1e79c4e529ad249f85a479c900e5d52fcb732443ed2d7c8215f4799c0.
Every supplied file was checked against its manifest before copying.
Root supplied the new source, original candidate, repair diff and exact old
definition cuts. The candidate is marked UNCOMPILED. No old whole or near-whole
proof source was acquired. No compiler, evaluator, native, Git, network,
board or production operation ran. No child was spawned.

## Four contracts

| Declaration | Actual gates and result |
| --- | --- |
| narrowAt_of_normal | Ordinary value, exact Normal in the given heap, and every root edge kept at this key imply exact value and heap replay at every supplied native fuel. |
| narrowAt_complete_control | Ready, Available and closed input imply an actual finite exposure and construction, completed filtering, Keeps, available closed ordinary Normal result, retained complete rows, larger-fuel stability from the original input, and every-fuel replay from the resulting value and heap at the same key. |
| narrowAt_ordinary_rows | Ready, Available, Ordinary root and actual successful filtering imply that every complete output edge is an input root edge retained by that key. |
| prepare_of_normal | Ordinary, Normal, every root edge kept at the actual hole key and the encode equation imply an unchanged value and heap, with rejection for Empty and the pure action for a nonempty ordinary node. |

Normal is the literal equation run(makeNode(nodeEdges value)) state=(value,state).
The first law does not replace Normal by Ready or Available. It also needs the
kept predicate at the exact same key. Changing the key can remove more rows.
The completion law derives Normal and kept for its actual output internally.
It does not ask the caller to supply a future result or its normalization.
Its replay is at the resulting heap. The original input stabilizes only from
the produced sufficient native fuel onward. Native reader fuel here is not
the enumeration worker's recursive depth.

The row-subset law has no separate recursive NodeDomain or closedness input.
It retains Ready, Available, Ordinary and the actual success equation.
Its result is complete-edge membership. It does not state a sublist law,
strict length decrease, finite physical ID carrier or identity preservation
through arbitrary later operations.

## Actual source path and Empty correction

The supplied narrowAt definition reads rows, filters them with keeps, and runs
makeNode on those selected complete rows. It performs no native recursive
intersection in that primitive. The proof derives retained-edge membership
through surviving and canonicalEdges. It does not create replacement child
records to establish its subset conclusion.

The entire first NativeView namespace, including the first three theorem
headers and proof bodies, is byte-identical between the original V3 candidate
and installed source. The identity is recorded with a SHA256.

The original fourth conclusion was too strong. It returned the pure action
for Empty. The actual Action.prepare definition selects some reject for an
Empty result before inspecting encodeNode. The corrected theorem preserves
that branch. Its nonempty node branch uses the actual encode equation and
the equality of the new and old handles to select pure().

Root reports that V4's unqualified reject became an implicit parameter.
The installed source qualifies EnumerationState.reject. The complete public
signature has no reject parameter and explicitly prints the Empty rejection.
Its printed dependent match also carries the ordinary, normal, kept and
encoded proof binders. Those binders are the existing stated premises.
They do not supply a new outcome or action oracle.

All four expanded public signatures match the source. All four axiom reports
list only propext, Classical.choice and Quot.sound. No sorry axiom appears.

## Verification evidence and limits

Root reports final default and strict Audit at 4,747 jobs and 82,991 dependency
checks. Root reports public verification at 1,199 checks and the unchanged
116 definition prints. Eight compiler commands were retained: six pass and
two failed candidate probes were repaired. Thirteen input snapshots remain.
This review ran no compiler command. It independently read the complete new
source, tail and four actual contracts.

The supplied prefix verification states that all previous 4,848,753 bytes
are an exact prefix of the new 4,856,085-byte output. Its full SHA256 is
1f1656fd1c7529357b618d41623de957271651c6d4aee8822468a2a666a6fce8.
This review does not reread that old complete prefix or rerun its checks.

The four laws control this row-filter operation. They do not prove a strict
row loss from every changed handle or a finite physical identity carrier
through an actual sequence of changing heaps. Incoming and dispatch
intersections remain separate. Prepared Mu and Union reconstruction remain
separate. Whole-caller neutrality, sufficient ORIGINAL recursive depth,
all earlier alternatives and staged children, global prefix coverage,
public adapters and Haskell correspondence remain open.

The Empty correction changes a proof statement. It identifies no Haskell
source defect or required runtime fix. No Haskell file was read, changed or
executed in this review. The full original objective remains incomplete.
