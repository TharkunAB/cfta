# Pruning row-filter control: independent public review

Result: PASS. All six final public contracts match the complete source and output.
This is a source-only review. Root owns compiler checks and publication.

## Complete reviewed inputs

The installed SourcePruningNarrowControl source has 165 lines and 9,839 bytes.
Its SHA256 is 4770bbbe96ea80ff3fc0159c956cf6286cced6f796b3bc09d6656536b4425e2a.
All source lines were read in three complete chunks. The first four-law public tail
has 96 lines and 7,332 bytes. All tail lines were read in two complete chunks.
Its SHA256 is 5d595f9487ce8895fbd1a687ad26e5d3d10941648c924aa8e78d251ba9707316.
No displayed chunk was truncated.

The source input manifest is cb1208eb45521373fb4a9571951034049c2bcbd8cae2627f14f6536202aeb8a2.
The public-tail manifest is 263f7ca1e79c4e529ad249f85a479c900e5d52fcb732443ed2d7c8215f4799c0.
Every supplied file was checked against its manifest before copying.
Root supplied the new source, original candidate, repair diff and exact old
definition cuts. The candidate is marked UNCOMPILED. No old whole or near-whole
proof source was acquired. No compiler, evaluator, native, Git, network,
board or production operation ran. No child was spawned.

## First four contracts

| Declaration | Actual gates and result |
| --- | --- |
| narrowAt_of_normal | Ordinary value, exact Normal in the given heap, and every root edge kept at this key imply exact value and heap replay at every supplied native fuel. |
| narrowAt_complete_control | Ready, Available and closed input imply an actual finite exposure and construction, completed filtering, Keeps, available closed ordinary Normal result, retained complete rows, larger-fuel stability from the original input, and every-fuel replay from the resulting value and heap at the same key. |
| narrowAt_ordinary_rows | Ready, Available, Ordinary root and actual successful filtering imply that every complete output edge is an input root edge retained by that key. |
| prepare_of_normal | Ordinary, Normal, every root edge kept at the actual hole key and the encode equation imply an unchanged value and heap, with rejection for Empty and the pure action for a nonempty ordinary node. |

Normal is the literal equation run(makeNode(nodeEdges value)) state=(value,state).
The first law does not replace Normal by Ready or Available. It also needs the
kept predicate at the exact same key. Changing the key can remove more rows.
The completion law derives Normal and kept for its actual output internally.
It does not ask the caller to supply a future result or its normalization.
Its replay is at the resulting heap. The original input stabilizes only from
the produced sufficient native fuel onward. Native reader fuel here is not
the enumeration worker's recursive depth.

The row-subset law has no separate recursive NodeDomain or closedness input.
It retains Ready, Available, Ordinary and the actual success equation.
Its result is complete-edge membership. It does not state a sublist law,
strict length decrease, finite physical ID carrier or identity preservation
through arbitrary later operations.

## Actual source path and Empty correction

The supplied narrowAt definition reads rows, filters them with keeps, and runs
makeNode on those selected complete rows. It performs no native recursive
intersection in that primitive. The proof derives retained-edge membership
through surviving and canonicalEdges. It does not create replacement child
records to establish its subset conclusion.

The entire first NativeView namespace, including the first three theorem
headers and proof bodies, is byte-identical between the original V3 candidate
and installed source. The identity is recorded with a SHA256.

The original fourth conclusion was too strong. It returned the pure action
for Empty. The actual Action.prepare definition selects some reject for an
Empty result before inspecting encodeNode. The corrected theorem preserves
that branch. Its nonempty node branch uses the actual encode equation and
the equality of the new and old handles to select pure().

Root reports that V4's unqualified reject became an implicit parameter.
The installed source qualifies EnumerationState.reject. The complete public
signature has no reject parameter and explicitly prints the Empty rejection.
Its printed dependent match also carries the ordinary, normal, kept and
encoded proof binders. Those binders are the existing stated premises.
They do not supply a new outcome or action oracle.

All four original expanded public signatures match the source. Their four
axiom reports list only propext, Classical.choice and Quot.sound.

## Two strict-loss contracts

The complete new SourcePruningNarrowLineage module has 81 lines and 4,629 bytes.
Its SHA256 is 2e4ba000e24b65d9d06e1af16964383c6ac6e83bb66f9685dbdd5e6e10cb4a53.
All 81 lines were read in two complete chunks. Its frozen input manifest is
a934b96f42e54a22952038691752014f2301d1c0f8b064de02cdacc207737191.

narrowAt_changed_loses_row retains Ready, Available, Ordinary and Normal.
It consumes the actual successful narrowAt equation, both actual encode
observations and unequal encoded handles. It proves that each output edge
belongs to the input root rows and that some input edge is absent from the
output. This is strict inclusion of complete root edge sets for that step.

The proof first obtains output membership and kept from the existing subset
law. If no input edge was lost, every input edge would occur in the output,
so every input edge would be kept. The existing Normal replay law would then
return the same value. The two encode observations would force equal handles,
contrary to the actual changed-handle premise. No future completion premise
or separately supplied strict-loss certificate is used.

narrowAt_constructed_changed_loses_row derives Normal, Available and Ordinary
at the current filter input. It consumes an actual earlier makeNode equation,
Ready and resident closed edges at that original state, then Keeps from the
constructed heap to the current heap. The existing makeNode_normal and
normal_grows supply the current Normal property internally. It retains the
actual current filter success, encode observations and changed handles.
The earlier value is the same literal value passed to this filter. These
premises are past constructor and heap-lineage facts. They do not establish
an arbitrary stored slot's entire history.

Both complete expanded statements match the source. Their axiom reports use
only the same three standard axioms. The supplied repair diff changes only
the unavailable by_contra tactic to explicit Classical.byContradiction.
No public statement changes in that repair.

## Final combined review

The Ordinary66--71 definition was supplied and read under manifest
4cc5d30c0257be416eaa569c2ffd6c1f444f6ef67a5d7b999329b106e73a795d.
It accepts only Empty and node root forms. It imposes no recursive child-domain
condition. Four old cuts cover 93 distinct lines in four modules.
There were zero old whole or near-whole source acquisitions.

The final public-tail manifest is
a221e5702da6bebd22804eeec2bf81cf188fbf1e57af8cbc5ff998d084a48235.
The final tail has 151 lines and 11,301 bytes. Its SHA256 is
14f8029075550e775144a94e1dde5eea69a5c60df43abcb642e148332351df2b.
The previously read 96-line tail is an exact byte prefix. All added 55 lines
and 3,969 bytes were read completely. Their SHA256 is
710d6dc6cf273a3362aa2f140ff4c02cfe42856cbda4aa14863ec6b2b1779b12.
All six final statements and all six standard-only axiom reports were read.
No source or contract defect was found in the final checked statements.

One review metadata error is retained. The final tail has a new filename.
The first extraction script guessed the earlier filename after verifying and
copying the bundle. It raised FileNotFoundError. The corrected extraction
uses the manifest filename. No proof or input changed. No compiler ran.

## Verification evidence and limits

Root reports final default and strict Audit at 4,748 jobs and 82,993 dependency
checks. Root reports public verification at 1,201 checks and the unchanged
116 definition prints. Fifteen compiler commands were retained: twelve pass
and three failed candidate probes were repaired. Thirty-two snapshots remain.
This review ran no compiler command. It independently read the complete new
source, tail and all six actual contracts.

The supplied prefix verification states that all previous 4,848,753 bytes
are an exact prefix of the new 4,860,054-byte output. The intermediate
4,856,085-byte public output is also an exact prefix. The final full SHA256 is
266872f154e91e3e67c6dc08fe733a61c72685c25d6031affdce74939ecfc622.
This review does not reread that old complete prefix or rerun its checks.

The six laws control this row-filter operation. The strict-loss laws cover
changed handles at an ordinary Normal input or the supplied past constructor
lineage. They do not state a numeric bound for a composed sequence, a bound
for every system handle change, or a global finite physical identity carrier.
Incoming and dispatch intersections remain separate. Prepared Mu and Union reconstruction remain
separate. Whole-caller neutrality, sufficient ORIGINAL recursive depth,
all earlier alternatives and staged children, global prefix coverage,
public adapters and Haskell correspondence remain open.

The Empty correction changes a proof statement. It identifies no Haskell
source defect or required runtime fix. No Haskell file was read, changed or
executed in this review. The full original objective remains incomplete.
