from pathlib import Path
import hashlib,json,sys

original=Path('/tmp/mcfta-narrowing-control-20261030')
r=Path(sys.argv[1]) if len(sys.argv)>1 else original
out=Path(sys.argv[2]) if len(sys.argv)>2 else r
out.mkdir(exist_ok=True)
repo=Path('/home/tritlo/Code/mcfta')
def sha(b):return hashlib.sha256(b).hexdigest()
def read(path):return path.read_bytes()
def owner(name,mh,ph):
    base=r/name
    assert sha(read(base/'MANIFEST.json'))==mh
    assert sha(read(base/'pins.json'))==ph
    manifest=json.loads((base/'MANIFEST.json').read_text())
    rows=manifest['files'] if 'files' in manifest else manifest['payloads']
    actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    self_files={'MANIFEST.json','pins.json'} if 'files' in manifest else {'MANIFEST.json','MANIFEST.sha256'}
    assert actual=={a['path'] for a in rows}|self_files
    if 'payloads' in manifest:assert (base/'MANIFEST.sha256').read_text().split()[0]==mh
    for a in rows:
        p=base/a['path'];b=read(p)
        assert not p.is_symlink() and not(p.stat().st_mode&0o222)
        assert len(b)==a['bytes'] and sha(b)==a['sha256'],p
    assert all(not(p.stat().st_mode&0o222) for p in base.rglob('*') if p.is_file())
    pin_data=json.loads((base/'pins.json').read_text())
    if isinstance(pin_data,dict):
        for path,h in pin_data['pins'].items():assert sha(read(base/path))==h
    return base,{'payloads':len(rows),'regular_files':len(actual),'readonly':True}

prep,prep_result=owner('preparation-review','013c69246cd33f1eaf77cf628fa90b7859ab368d39b5837879f74cc7fe6c3760','e30b8e50d526f53368776206f735a19db2102467dff479c2595cb71fbcfa0688')
lineage,lineage_result=owner('lineage-review','ad65d74d6f2fe0d7cdc8c71ee50a6bf10e93c7ede6bbac008b7f5c7e0913d638','08da5224fcfcff3340292e693392c97d786fdb012a260aabc53d0698f60ad4a8')
public,public_result=owner('public-review','3e198a346b82971255621e781ac3ebc81cec5e9cd669502cdce5ef2523631e9b','0d0d4322da2bc0cf72eb86ff6dd7b98b0d25d39a12d5f40e895c8e9fa5926028')
future,future_result=owner('next-stored-prefix-review','dd52932014e0e7a29016acf59ed47be663f77c7b77cea6bf745a73055f9315cd','a27d9f357e118033e06990477aa1897dd4a52245e8e8ecbd212257751a1f6389')
def current(path):
    p=Path(path)
    if not p.is_absolute():p=repo/p
    if p.is_relative_to(original):return r/p.relative_to(original)
    assert p.is_relative_to(repo),p
    return p
def source_cut(a,base):
    b=read(current(a.get('source_path',a.get('source'))))
    assert sha(b)==a['source_sha256'] and len(b.splitlines())==a['source_lines']
    if 'source_bytes' in a:assert len(b)==a['source_bytes']
    if 'actual_lines' in a:expected=b''.join(b.splitlines(keepends=True)[i-1] for i in a['actual_lines'])
    else:
        lo,hi=a['actual'];expected=b''.join(b.splitlines(keepends=True)[lo-1:hi])
    leaf=a.get('copy',a.get('cut'));h=a.get('copy_sha256',a.get('cut_sha256'))
    assert read(base/leaf)==expected and sha(expected)==h,(base,leaf)
for a in json.loads((prep/'pins.json').read_text()):source_cut(a,prep)
for name in ['source-unions.json','locator-pins.json']:
    for a in json.loads((prep/name).read_text()):
        b=read(current(a['source']));assert sha(b)==a['source_sha256'] and len(b.splitlines())==a['source_lines']
for a in json.loads((lineage/'acquisitions.json').read_text()):source_cut(a,lineage)
for a in json.loads((lineage/'reuse-ledger.json').read_text()):
    copied=read(lineage/a['copy']);assert len(copied)==a['bytes'] and sha(copied)==a['sha256']
    if 'repo_source' in a:
        b=read(current(a['repo_source']));assert sha(b)==a['source_sha256'] and len(b)==a['source_bytes']
        expected=b''.join(b.splitlines(keepends=True)[i-1] for i in a['actual_lines']);assert copied==expected
        encoded=read(prep/'MANIFEST.json');assert sha(encoded)==a['frozen_manifest_sha256']
        relative=Path(a['source']).relative_to('/tmp/mcfta-native-memo-stored-control-20261030/next-preparation-review')
        assert copied==read(prep/relative)
    else:assert copied==read(current(a['source']))
maps=json.loads((r/'frozen-manifest-map.json').read_text())
for a in json.loads((future/'acquisitions.json').read_text()):
    source_cut(a,future)
    if 'frozen_bundle' in a:
        encoded=read(r/maps[a['frozen_bundle']]);assert sha(encoded)==a['frozen_manifest_sha256']
        entry=next(e for e in json.loads(encoded)['files'] if e['path']==a['frozen_copy'])
        assert entry['sha256'] in {a['source_sha256'],a['copy_sha256']}
for a in json.loads((public/'reuse-ledger.json').read_text()):
    p=Path(a['source_path']);assert p.is_relative_to(original);p=r/p.relative_to(original)
    b=read(p);assert b==read(public/a['copy']) and len(b)==a['source_bytes']
    assert sha(b)==a['source_sha256']==a['copy_sha256'] and len(b.splitlines())==a['source_lines']
    assert sha(read(p.parent/'MANIFEST.json'))==a['frozen_manifest_sha256']
for a in json.loads((public/'old-source-cut-ledger.json').read_text()):source_cut(a,public)
future_result['status']='UNCOMPILED upcoming native prefix proof; no Root probe'
result={'status':'pass','preparation_review':prep_result,'lineage_review':lineage_result,'public_review':public_result,'next_stored_prefix_review':future_result,'root_and_independent_complete_six_contract_read':True,'historical_tmp_dependencies_retained':True}
(out/'owned-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
