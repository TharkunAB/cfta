import MicroCFTA.SourceEqualityAnnotationProjection
import MicroCFTA.SourceEqualityProjectionWorkerSound

/-!
# Annotation heaps through actual projection outcomes

Every result retains the input annotation predicate in its reached heap.
The initial semantic and residency gates remain explicit.
-/
namespace MicroCFTA.SourceEqualityAnnotationProjectionOutcome
open InternedConstructorTemplates InternedProbeProvenance
open InternedNestedProvenance (Values)
open MergedColdReaderClosedInputs (ClosedValues)
open SourceEqualityRequiredSemanticCache (SemanticReady)
open SourceEqualityRequiredWorker (Result)
open SourceEqualityAnnotationHeap (Heap)

/-- Every returned state retains the annotation heap, including blocked states. -/
def ResultHeap (annotation : Guard → Prop) : Result Symbol Guard A → Prop
  | .done _ after | .pending _ after | .unresolved _ after | .exhausted _ after =>
      Heap annotation after

private theorem append_heap (annotation : Guard → Prop)
    (earlier : List (EdgeValue Symbol Guard))
    (result : Result Symbol Guard (List (EdgeValue Symbol Guard)))
    (heap : ResultHeap annotation result) :
    ResultHeap annotation (result.bind fun more after => .done (earlier ++ more) after) := by
  cases result <;> exact heap

/-- Ordinary node construction does not require a new guard annotation. -/
theorem makeNode_heap (annotation : Guard → Prop) [DecidableEq (EdgeKey Symbol Guard)]
    (edges : List (EdgeValue Symbol Guard)) (before : State Symbol Guard)
    (heap : Heap annotation before) :
    ResultHeap annotation (SourceEqualityRequiredWorker.work (makeNode edges) before) := by
  change Heap annotation (InternedConstructorTemplates.run (makeNode edges) before).2
  exact SourceEqualityAnnotationHeap.run annotation _
    (SourceEqualityAnnotationHeap.makeNode annotation edges) before heap

/-- Actual head exposure preserves the heap at every returned outcome. -/
theorem head_heap (annotation : Guard → Prop) [DecidableEq (EdgeKey Symbol Guard)]
    (readFuel : Nat) (value : Value Symbol Guard) (before : State Symbol Guard)
    (semantic : SemanticReady before) (available : Available before value)
    (closed : value.free = []) (heap : Heap annotation before) :
    ResultHeap annotation (SourceEqualityRequiredWorker.head readFuel value before) := by
  have retained := SourceEqualityAnnotationExposure.nodeEdges_heap annotation readFuel value before
    semantic.ready.semantic semantic.ready.covered heap available closed
  cases observed : MergedFreshOrdinaryExposure.nodeEdges readFuel value before with
  | done edges after =>
      have afterHeap : Heap annotation after := by
        simpa only [observed, MergedSourceExposure.Result.state] using retained
      simpa only [SourceEqualityRequiredWorker.head, observed] using
        makeNode_heap annotation edges after afterHeap
  | pending key after =>
      simpa only [SourceEqualityRequiredWorker.head, observed, ResultHeap,
        MergedSourceExposure.Result.state] using retained
  | unresolved name after =>
      simpa only [SourceEqualityRequiredWorker.head, observed, ResultHeap,
        MergedSourceExposure.Result.state] using retained
  | exhausted after =>
      simpa only [SourceEqualityRequiredWorker.head, observed, ResultHeap,
        MergedSourceExposure.Result.state] using retained

/-- The literal ordered row reader preserves every retained result state. -/
theorem readAll_heap (annotation : Guard → Prop) [DecidableEq (EdgeKey Symbol Guard)]
    (readFuel : Nat) (values : List (Value Symbol Guard)) (before : State Symbol Guard)
    (semantic : SemanticReady before) (available : Values before values)
    (closed : ClosedValues values) (heap : Heap annotation before) :
    ResultHeap annotation (SourceEqualityProjectionWorker.readAll readFuel values before) := by
  induction values generalizing before with
  | nil => exact heap
  | cons value values ih =>
      have firstAvailable := available value List.mem_cons_self
      have firstClosed := closed value List.mem_cons_self
      have retained := SourceEqualityAnnotationExposure.nodeEdges_heap annotation readFuel value before
        semantic.ready.semantic semantic.ready.covered heap firstAvailable firstClosed
      cases observed : MergedFreshOrdinaryExposure.nodeEdges readFuel value before with
      | done edges middle =>
          have trace : SourceEqualityProjectionRead.Read value before edges middle := .done readFuel observed
          have checked := trace.verified semantic firstAvailable firstClosed
          have middleHeap : Heap annotation middle := by
            simpa only [observed, MergedSourceExposure.Result.state] using retained
          have restAvailable : Values middle values := fun child member =>
            checked.1.available child (available child (List.mem_cons_of_mem _ member))
          have restClosed : ClosedValues values := fun child member =>
            closed child (List.mem_cons_of_mem _ member)
          have rest := ih middle checked.2.1 restAvailable restClosed middleHeap
          simpa only [SourceEqualityProjectionWorker.readAll, observed] using
            append_heap annotation edges _ rest
      | pending key after =>
          simpa only [SourceEqualityProjectionWorker.readAll, observed, ResultHeap,
            MergedSourceExposure.Result.state] using retained
      | unresolved name after =>
          simpa only [SourceEqualityProjectionWorker.readAll, observed, ResultHeap,
            MergedSourceExposure.Result.state] using retained
      | exhausted after =>
          simpa only [SourceEqualityProjectionWorker.readAll, observed, ResultHeap,
            MergedSourceExposure.Result.state] using retained

/-- The actual union branch preserves the heap on success or a retained block. -/
theorem union_heap (annotation : Guard → Prop) [DecidableEq (EdgeKey Symbol Guard)]
    (readFuel : Nat) (values : List (Value Symbol Guard)) (before : State Symbol Guard)
    (semantic : SemanticReady before) (available : Values before values)
    (closed : ClosedValues values) (heap : Heap annotation before) :
    ResultHeap annotation (SourceEqualityProjectionWorker.union readFuel values before) := by
  have retained := readAll_heap annotation readFuel values before semantic available closed heap
  cases observed : SourceEqualityProjectionWorker.readAll readFuel values before with
  | done edges after =>
      have afterHeap : Heap annotation after := by simpa only [observed, ResultHeap] using retained
      simpa only [SourceEqualityProjectionWorker.union, observed, Result.bind] using
        makeNode_heap annotation edges after afterHeap
  | pending key after =>
      simpa only [SourceEqualityProjectionWorker.union, observed, Result.bind, ResultHeap] using retained
  | unresolved name after =>
      simpa only [SourceEqualityProjectionWorker.union, observed, Result.bind, ResultHeap] using retained
  | exhausted limit after =>
      simpa only [SourceEqualityProjectionWorker.union, observed, Result.bind, ResultHeap] using retained

/-- Forest root projection is the same actual union branch for all worker bounds. -/
theorem forest_root_heap (annotation : Guard → Prop) [DecidableEq (EdgeKey Symbol Guard)]
    (fuel readFuel : Nat) (values : List (Value Symbol Guard)) (before : State Symbol Guard)
    (semantic : SemanticReady before) (available : Values before values)
    (closed : ClosedValues values) (heap : Heap annotation before) :
    ResultHeap annotation (SourceEqualityProjectionWorker.forest fuel readFuel [] values before) := by
  exact union_heap annotation readFuel values before semantic available closed heap

end MicroCFTA.SourceEqualityAnnotationProjectionOutcome
