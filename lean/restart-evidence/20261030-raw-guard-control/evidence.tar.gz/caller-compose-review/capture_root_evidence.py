from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,re,difflib
area=Path('/tmp/mcfta-raw-guard-control-20261030/caller-compose-review');root=area.parent;repo=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA');sha=lambda d:hashlib.sha256(d).hexdigest()
modules=['SourcePruningEnumerationIncomingGuardHeap','SourcePruningEnumerationDispatchGuardHeap']
for mod in modules:
 for stage in ['build','strict']:
  if not (root/(mod+'-v1-'+stage)/'report.json').exists():print('pending',mod,stage);raise SystemExit(0)
entries=[]
def copy(p,rel):
 d=p.read_bytes();dest=area/'root-evidence'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(d);entries.append(dict(source=str(p),copy=str(dest.relative_to(area)),bytes=len(d),sha256=sha(d)));return d
versions=['incoming-v1','incoming-v2','incoming-v3','incoming-v4','dispatch-v1','dispatch-v2']
for v in versions:
 report=json.loads((root/(v+'-probe')/'report.json').read_text());d=copy(root/(v+'.lean'),Path('versions')/(v+'.lean'));assert report['source_sha256']==sha(d)
 for tail in ['report.json','raw.log','inputs.json','started-command.json']:copy(root/(v+'-probe')/tail,Path(v+'-probe')/tail)
 raw=(root/(v+'-probe')/'raw.log').read_bytes();assert len(raw)==report['bytes'] and sha(raw)==report['sha256']
 for tail in [v+'.json',v+'-probe-outer.log']:
  if (root/tail).exists():copy(root/tail,Path('versions')/tail)
 assert report['exit_code']==(0 if v in ['incoming-v4','dispatch-v2'] else 1)
results=[];headers=[]
for mod,v,name,ns in zip(modules,['incoming-v4','dispatch-v2'],['run_heap','dispatch_heap'],['MicroCFTA.SourcePruningEnumerationIncomingNode','MicroCFTA.SourcePruningEnumerationDispatch']):
 live=copy(repo/(mod+'.lean'),Path('production')/(mod+'.lean'));probe=(root/(v+'.lean')).read_bytes();prod=live.decode();probeText=probe.decode();start='namespace '+ns
 assert probeText[probeText.index(start):].rstrip()==prod[prod.index(start):].rstrip()
 owner=(area/('SourcePruningEnumerationIncomingGuardHeap-v1-UNTESTED.lean' if name=='run_heap' else 'SourcePruningEnumerationDispatchGuardHeap-v1-UNTESTED.lean')).read_text()
 def header(s):return 'theorem '+name+s.split('theorem '+name,1)[1].split(' := by',1)[0]
 assert header(owner)==header(prod);headers.append(dict(namespace=ns,name=name,header=header(prod),owner_header_preserved=True))
 result={'module':mod,'production_bytes':len(live),'production_sha256':sha(live),'final_probe_sha256':sha(probe)}
 for stage in ['build','strict']:
  folder=root/(mod+'-v1-'+stage);r=json.loads((folder/'report.json').read_text());raw=(folder/'raw.log').read_bytes();assert r['exit_code']==0 and len(raw)==r['bytes'] and sha(raw)==r['sha256']
  for tail in ['report.json','raw.log','inputs.json','started-command.json']:copy(folder/tail,Path(mod+'-v1-'+stage)/tail)
  snap=folder/'input-sources'/(mod+'.lean');assert snap.read_bytes()==live;copy(snap,Path(mod+'-v1-'+stage)/'input-sources'/(mod+'.lean'))
  if stage=='strict':
   checked=folder/'MicroCFTA'/(mod+'.lean');assert checked.read_bytes()==live;assert r['source_sha256']==sha(live);copy(checked,Path(mod+'-v1-'+stage)/'MicroCFTA'/(mod+'.lean'));result['strict_bytes']=len(raw)
  else:
   found=re.search(r'Build completed successfully \((\d+) jobs\)',raw.decode());result['build_jobs']=int(found.group(1)) if found else None
 results.append(result)
# Pin the checked check-law dependency without rereading its proof body.
dep='SourceCurrentConjunctionAnnotationOutcome';folder=root/(dep+'-v1-strict')
if (folder/'report.json').exists():
 r=json.loads((folder/'report.json').read_text());d=copy(repo/(dep+'.lean'),Path('dependency')/(dep+'.lean'));assert r['exit_code']==0 and r['source_sha256']==sha(d)
 assert (folder/'MicroCFTA'/(dep+'.lean')).read_bytes()==d
 for tail in ['report.json','raw.log','inputs.json','started-command.json']:copy(folder/tail,Path('dependency-strict')/tail)
raw=(root/'incoming-v1-probe'/'raw.log').read_text();parts=[p for p in re.split(r'(?=^/tmp/[^\n]+: error:)',raw,flags=re.M) if p];groups={};order=[]
for p in parts:
 h,_,b=p.partition('\n');key=sha(b.encode());groups.setdefault(key,dict(body=b,heads=[]));groups[key]['heads'].append(h);order.append({'body_sha256':key,'head':h})
recovered=''.join(r['head']+'\n'+groups[r['body_sha256']]['body'] for r in order);assert recovered==raw
(area/'incoming-v1-diagnostics-dedup.json').write_text(json.dumps({'raw_sha256':sha(raw.encode()),'raw_bytes':len(raw.encode()),'record_count':len(parts),'groups':groups,'order':order,'exact_reconstruction_verified':True},indent=2)+'\n')
for r in json.loads((area/'source-unions.json').read_text()):assert sha(Path(r['source']).read_bytes())==r['source_sha256']
summary={'captured_at':datetime.now(ZoneInfo('Europe/Stockholm')).isoformat(),'results':results,'entries':entries,'both_owner_public_headers_preserved':True,'production_namespaces_through_proof_equal_final_probe':True,'all_11_acquired_source_identities_match':True,'owner_compiler_evaluator_native_git_network_board':False,'global_audit_or_axiom_readback_claimed':False}
(area/'root-evidence.json').write_text(json.dumps(summary,indent=2)+'\n');(area/'public-headers.json').write_text(json.dumps(headers,indent=2)+'\n');print(json.dumps({'results':results,'evidence_files':len(entries),'diagnostic_records':len(parts),'diagnostic_unique_bodies':len(groups)}))
