local notation "InputsThrough" => SourceCurrentAllocatedNativePhysicalExecution.InputsThrough
variable {width bits : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
