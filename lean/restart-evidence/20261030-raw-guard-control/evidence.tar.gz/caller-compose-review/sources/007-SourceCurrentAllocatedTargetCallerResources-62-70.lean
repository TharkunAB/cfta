    (.code (requestNode IntersectionEmptyDomain.emptyDomain left right)) before.checked after value physical.done
  have sameFuel : fuel + 1 + (instructionBound profile.nodes profile.edges profile.mass - fuel) =
      instructionBound profile.nodes profile.edges profile.mass + 1 := by omega
  rw [sameFuel] at done
  have massBound := SourceCurrentAllocatedRecursiveMassMonotone.massAfter_count_mono larger profile.mass
  have credits := SourceCurrentAllocatedRecursiveMassMonotone.credit_count_mono larger profile.mass
  refine ⟨next, value, after, source, roots, receipt, post, done, ?_, Nat.le_trans mass massBound⟩
  exact ⟨Nat.le_trans nodes (Nat.add_le_add fits.nodes credits),
    Nat.le_trans edges (Nat.add_le_add fits.edges credits),
