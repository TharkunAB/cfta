
/-- Retain the optional node and reject its empty handle before writes. -/
def finishOptional (source target : Nat) (node : Option Nat)
    (sourceScs targetScs : List EnumerationState.Suspended) :
    EnumerateM Symbol EnumGuard Unit :=
  fun state =>
    if node = some 0 then [] else
      [.ok ((), assimilated state target source (.unenumerated node (sourceScs ++ targetScs)))]

/-- Keep the reached caller and query pair outside a missing encoded action. -/
noncomputable def afterQuery
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
    (checkEmpty : Bool) (p h : Nat) (source target : Nat)
    (sourceScs targetScs : List EnumerationState.Suspended)
    (query : Node) (queried : Checked width) (beforeCaller : Caller width) (queries : Queries) :
    (Except (SourceCurrentAllocatedConjunctionWorker.Outcome width)
      (Option (EnumerateM Symbol EnumGuard Unit))) × Caller width × Queries :=
  let phase : SourceCurrentAllocatedConjunctionWorker.Outcome width × Queries :=
    if checkEmpty then
