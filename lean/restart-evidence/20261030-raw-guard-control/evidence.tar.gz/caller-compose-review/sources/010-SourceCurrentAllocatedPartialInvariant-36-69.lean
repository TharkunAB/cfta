
/-- A returned caller retains its actual current context and completed table history. -/
structure Post (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (next : Inventory)
    (before after : Caller width) (final : Memos) : Prop where
  context : Context formulas solver next after final
  effects : SourceCurrentConjunctionRowsAllocation.Effects (physical before.checked) (physical after.checked)
  retained : Cache.Extends before.merge after.merge
  fourthRetained : SourceCurrentEmptinessMemo.Extends before.fourth after.fourth

variable {formulas : SourceGuards.Formulas FullSyntax.Formula} {solver : SourceGuards.Entailment FullSyntax.Formula}
  {inventory next : Inventory} {before middle after : Caller width} {memos final : Memos}

/-- Caller protocol changes retain the context when all checked and completed tables stay exact. -/
theorem Context.rebase (context : Context formulas solver inventory before memos)
    (checked : after.checked = before.checked) (merge : after.merge = before.merge)
    (fourth : after.fourth = before.fourth)
    (sound : SourceCurrentAllocatedPartialMemoSound.Sound formulas solver after) :
    Context formulas solver inventory after memos := by
  refine ⟨?_, ?_, sound, ?_, ?_, ?_, ?_, ?_⟩
  · simpa only [checked] using context.ready
  · simpa only [checked] using context.admitted
  · simpa only [checked, merge] using context.stored
  · simpa only [merge] using context.covered
  · simpa only [checked, fourth] using context.correct
  · simpa only [checked] using context.globals
  · simpa only [checked] using context.probes

/-- An unchanged current caller has an exact reflexive postcondition. -/
theorem Post.refl (context : Context formulas solver inventory before memos) :
    Post formulas solver inventory before before memos := by
  have ready := SourceCurrentAllocatedConjunctionMemo.ready before.checked context.ready.good
    context.ready.semantic context.ready.costs
  exact ⟨context, .refl _ ready, Cache.extends_refl _, fun _ _ found => found⟩
