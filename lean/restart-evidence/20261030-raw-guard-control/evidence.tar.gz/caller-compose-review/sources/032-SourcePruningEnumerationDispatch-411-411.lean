          phaseStable P H enoughP enoughH, Except.mapError, Id.run]; rfl
