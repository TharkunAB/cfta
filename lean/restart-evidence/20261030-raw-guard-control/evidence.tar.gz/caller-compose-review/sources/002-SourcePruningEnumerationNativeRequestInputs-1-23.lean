import MicroCFTA.SourceCurrentAllocatedTargetCallerResources

/-!
# Physical input plans from current caller resources

The caller admission constructs its own completed physical request trace.
That trace supplies every bounded input plan, including shorter prefixes.
No future successful trace is a premise of the public theorem.
-/
namespace MicroCFTA.SourcePruningEnumerationNativeRequestInputs
open InternedConstructorTemplates SourceRecursiveIntersectionCode SourceEqualityNativeDemand
open InternedProbeProvenance (Available)
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace)
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedNativeResourceForecast (Profile Room)
open SourceCurrentConstrainedCapGeneratedQueryResources (Fits)
open SourceCurrentAllocatedPartialInvariant (Context)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Guard
local notation "Checked" => SourceEqualityNativeDemand.State
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
