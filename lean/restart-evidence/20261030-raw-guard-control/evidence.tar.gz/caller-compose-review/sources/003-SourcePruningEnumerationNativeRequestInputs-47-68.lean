                simpa only [one] using ih tail nativeFuel⟩

/-- Current admission derives every bounded input plan for the literal request. -/
theorem inputs_of_resources (profile : Profile)
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (before : Caller (bits + 2)) (left right : Node) (memos : Memos)
    (initial : Context formulas solver inventory before memos)
    (fits : Fits profile before.checked) (room : Room bits profile)
    (leftAvailable : Available before.checked.native.machine.heap left)
    (rightAvailable : Available before.checked.native.machine.heap right)
    (leftClosed : left.free = []) (rightClosed : right.free = [])
    (nativeFuel : Nat) :
    InputsThrough nativeFuel
      (.code (requestNode IntersectionEmptyDomain.emptyDomain left right)) before.checked := by
  obtain ⟨_next, _value, _after, _source, _roots, receipt, _rest⟩ :=
    SourceCurrentAllocatedTargetQuery.finite_caller_resources profile formulas solver inventory
      before left right memos initial fits room leftAvailable rightAvailable leftClosed rightClosed
  cases receipt.actual with
  | run trace => exact trace_inputs trace nativeFuel

end MicroCFTA.SourcePruningEnumerationNativeRequestInputs
