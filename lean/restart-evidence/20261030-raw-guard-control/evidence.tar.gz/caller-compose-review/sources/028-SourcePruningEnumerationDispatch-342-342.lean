      simp only [dispatch, ite_eq_left same, Id.run]; rfl
