      simp only [dispatch, ite_eq_right same, sourceStored, targetStored]
