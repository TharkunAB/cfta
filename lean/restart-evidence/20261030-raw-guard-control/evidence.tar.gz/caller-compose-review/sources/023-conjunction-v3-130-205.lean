/-- Memo hits and every actual memo-miss outcome retain the same annotation predicate. -/
theorem call_heap (annotation : ConcreteGuard → Prop) (projectionFuel readFuel budget : Nat)
    (memo : Memo) (query : Value ConcreteSymbol ConcreteGuard)
    (before : Physical ConcreteSymbol FullSyntax.Formula)
    (ready : SourceCurrentConjunctionRowsAllocation.Ready before) (probes : ProbeHeap before.heap)
    (available : Available before.heap query) (heap : Heap annotation before.heap) :
    HeapOutcome annotation (call projectionFuel readFuel budget memo query before) := by
  cases observed : memo query.referenceOf with
  | none =>
      simp only [call, observed]
      exact map_heap annotation _ _
        (decision_heap annotation projectionFuel readFuel budget query before ready probes available heap)
  | some entry =>
      obtain ⟨stored, answer⟩ := entry
      simpa only [call, observed, HeapOutcome, Outcome.state] using heap

/-- Physical advancement retains the heap of every successful or failed raw call. -/
theorem allocated_call_heap {width : Nat} (annotation : ConcreteGuard → Prop)
    (projectionFuel readFuel budget : Nat) (query : Value ConcreteSymbol ConcreteGuard)
    (before : Checked width) (memo : Memo)
    (ready : SourceCurrentConjunctionRowsAllocation.Ready (SourceCurrentAllocatedNativeEffects.physical before))
    (probes : ProbeHeap before.native.machine.heap) (available : Available before.native.machine.heap query)
    (heap : Heap annotation before.native.machine.heap) :
    Heap annotation (SourceCurrentAllocatedConjunctionWorker.call projectionFuel readFuel budget
      query before memo).state.native.machine.heap := by
  have own := call_heap annotation projectionFuel readFuel budget memo query
    (SourceCurrentAllocatedNativeEffects.physical before) ready probes available heap
  cases observed : call projectionFuel readFuel budget memo query
      (SourceCurrentAllocatedNativeEffects.physical before) with
  | done output after =>
      obtain ⟨answer, saved⟩ := output
      have afterHeap : Heap annotation after.heap := by
        simpa only [observed, HeapOutcome, Outcome.state] using own
      have heapEq : (SourceCurrentAllocatedQueryMemo.advancePhysical before after).native.machine.heap = after.heap :=
        congrArg (fun state : Physical ConcreteSymbol FullSyntax.Formula => state.heap)
          (SourceCurrentAllocatedQueryMemo.physical_advance before after)
      simpa only [SourceCurrentAllocatedConjunctionWorker.call, observed,
        SourceCurrentAllocatedConjunctionWorker.Outcome.state, heapEq] using afterHeap
  | failed fault after =>
      have afterHeap : Heap annotation after.heap := by
        simpa only [observed, HeapOutcome, Outcome.state] using own
      have heapEq : (SourceCurrentAllocatedQueryMemo.advancePhysical before after).native.machine.heap = after.heap :=
        congrArg (fun state : Physical ConcreteSymbol FullSyntax.Formula => state.heap)
          (SourceCurrentAllocatedQueryMemo.physical_advance before after)
      simpa only [SourceCurrentAllocatedConjunctionWorker.call, observed,
        SourceCurrentAllocatedConjunctionWorker.Outcome.state, heapEq] using afterHeap

/-- Both endpoint-guard branches preserve annotations, including retained failed check states. -/
theorem enabled_check_heap {width : Nat} (annotation : ConcreteGuard → Prop)
    (projectionFuel readFuel : Nat) (query : Value ConcreteSymbol ConcreteGuard)
    (before : Checked width) (memo : Memo) (queries : SourceEndpointMemo.Memos)
    (ready : SourceCurrentConjunctionRowsAllocation.Ready (SourceCurrentAllocatedNativeEffects.physical before))
    (probes : ProbeHeap before.native.machine.heap) (available : Available before.native.machine.heap query)
    (heap : Heap annotation before.native.machine.heap) :
    Heap annotation (SourcePruningEnumerationEnabledEmpty.check projectionFuel readFuel query
      before memo queries).1.state.native.machine.heap := by
  unfold SourcePruningEnumerationEnabledEmpty.check
  dsimp only
  split
  · exact allocated_call_heap annotation projectionFuel readFuel 1000 query before memo ready probes available heap
  · exact heap

end Concrete
end MicroCFTA.SourceCurrentConjunctionAnnotationOutcome
