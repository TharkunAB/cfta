    Nat.le_trans edges (Nat.add_le_add fits.edges credits),
    Nat.le_trans domains (Nat.add_le_add fits.domains larger), stored.mono massBound⟩

/-- Every successful raw return has the same caller laws and resource bounds at its full state. -/
