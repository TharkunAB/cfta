and available inputs supply reached operations. It does not require a
successful check or a completed future operation.
-/
namespace MicroCFTA.SourceCurrentConjunctionAnnotationOutcome
open InternedConstructorTemplates InternedProbeProvenance
open InternedNestedProvenance (Values)
open SourceEqualityAnnotationHeap (Heap)
open SourceCurrentConjunctionWorker
variable {Symbol Formula Output : Type}
local notation "Guard" => SourceSymbolicIndex.Constraint Formula
local notation "ProbeHeap" => InternedFreshOrdinaryProbeHeap.Heap

/-- Completed and failed worklists retain annotations at their actual heap. -/
def HeapOutcome (annotation : Guard → Prop) (result : Outcome Symbol Formula Output) : Prop :=
  Heap annotation result.state.heap

private theorem bind_heap {Input Output : Type} (annotation : Guard → Prop)
    (first : Outcome Symbol Formula Input)
    (next : Input → Physical Symbol Formula → Outcome Symbol Formula Output)
    (safe : HeapOutcome annotation first)
    (continued : ∀ value after, first = .done value after → HeapOutcome annotation (next value after)) :
    HeapOutcome annotation (first.bind next) := by
  cases first with
  | done value after => exact continued value after rfl
  | failed => exact safe
