theorem enabled_check_heap {width : Nat} (annotation : ConcreteGuard → Prop)
    (projectionFuel readFuel : Nat) (query : Value ConcreteSymbol ConcreteGuard)
    (before : Checked width) (memo : Memo) (queries : SourceEndpointMemo.Memos)
    (ready : SourceCurrentConjunctionRowsAllocation.Ready (SourceCurrentAllocatedNativeEffects.physical before))
    (probes : ProbeHeap before.native.machine.heap) (available : Available before.native.machine.heap query)
    (heap : Heap annotation before.native.machine.heap) :
    Heap annotation (SourcePruningEnumerationEnabledEmpty.check projectionFuel readFuel query
      before memo queries).1.state.native.machine.heap := by
  unfold SourcePruningEnumerationEnabledEmpty.check
  dsimp only
  split
  · exact allocated_call_heap annotation projectionFuel readFuel 1000 query before memo ready probes available heap
  · exact heap

end Concrete
end MicroCFTA.SourceCurrentConjunctionAnnotationOutcome
