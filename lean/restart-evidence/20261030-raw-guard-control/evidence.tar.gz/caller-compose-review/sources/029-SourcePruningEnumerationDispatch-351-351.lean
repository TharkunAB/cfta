      simp only [dispatch, ite_eq_right same, eliminated, Id.run]; rfl
