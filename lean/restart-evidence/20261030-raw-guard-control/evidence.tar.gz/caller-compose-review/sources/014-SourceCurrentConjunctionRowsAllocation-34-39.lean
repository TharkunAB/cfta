structure Ready (state : State Symbol Formula) : Prop where
  semantic : SemanticReady state.heap
  costs : CostHeap state.heap
  valid : SourceEqualityConstraintMemoAllocation.Valid state.equality
  fields : Eq.Fields state.equality state.heap

