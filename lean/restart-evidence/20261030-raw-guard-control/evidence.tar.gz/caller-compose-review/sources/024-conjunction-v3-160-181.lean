      obtain ⟨answer, saved⟩ := output
      have afterHeap : Heap annotation after.heap := by
        simpa only [observed, HeapOutcome, Outcome.state] using own
      have heapEq : (SourceCurrentAllocatedQueryMemo.advancePhysical before after).native.machine.heap = after.heap :=
        congrArg (fun state : Physical ConcreteSymbol FullSyntax.Formula => state.heap)
          (SourceCurrentAllocatedQueryMemo.physical_advance before after)
      simpa only [SourceCurrentAllocatedConjunctionWorker.call, observed,
        SourceCurrentAllocatedConjunctionWorker.Outcome.state, heapEq] using afterHeap
  | failed fault after =>
      have afterHeap : Heap annotation after.heap := by
        simpa only [observed, HeapOutcome, Outcome.state] using own
      have heapEq : (SourceCurrentAllocatedQueryMemo.advancePhysical before after).native.machine.heap = after.heap :=
        congrArg (fun state : Physical ConcreteSymbol FullSyntax.Formula => state.heap)
          (SourceCurrentAllocatedQueryMemo.physical_advance before after)
      simpa only [SourceCurrentAllocatedConjunctionWorker.call, observed,
        SourceCurrentAllocatedConjunctionWorker.Outcome.state, heapEq] using afterHeap

/-- Both endpoint-guard branches preserve annotations, including retained failed check states. -/
theorem enabled_check_heap {width : Nat} (annotation : ConcreteGuard → Prop)
    (projectionFuel readFuel : Nat) (query : Value ConcreteSymbol ConcreteGuard)
    (before : Checked width) (memo : Memo) (queries : SourceEndpointMemo.Memos)
    (ready : SourceCurrentConjunctionRowsAllocation.Ready (SourceCurrentAllocatedNativeEffects.physical before))
