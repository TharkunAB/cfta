structure SemanticReady (state : State Symbol Guard) : Prop where
  ready : Ready state
  guarded : InternedGuardedProbeHeap.Heap state
  budget : InternedGuardedBudgetProbeHeap.Heap state

/-- Original closed source construction derives every semantic cache premise. -/
