                  ∃ (reachedPhysical : SourceCurrentConjunctionRowsAllocation.State Symbol FullSyntax.Formula),
                    afterCaller.checked = SourceCurrentAllocatedQueryMemo.advancePhysical queried reachedPhysical ∧
                    ∃ actual : SourceCurrentConjunctionMemo.Call 1000 beforeCaller.fourth query
                        (physical queried) answer reachedPhysical afterCaller.fourth,
                      SourceCurrentConjunctionGlobalMemos.CallReads actual {memos with query := guardSaved} final)))) := by
  have optionalPacket :
    ∀ (sourceNode targetNode merged : Option Nat) (sourceScs targetScs : List EnumerationState.Suspended),
      before.values[source]? = some (.unenumerated sourceNode sourceScs) →
      before.values[target]? = some (.unenumerated targetNode targetScs) →
      source ≠ target → (sourceNode = none ∨ targetNode = none) →
      merged = sourceNode.orElse (fun _ => targetNode) →
      ExceptT.run (finishOptional (EnumGuard := EnumGuard) source target merged sourceScs targetScs before) =
        (if merged = some 0 then [] else
          [.ok ((), assimilated before target source (.unenumerated merged (sourceScs ++ targetScs)))]) ∧
      (merged ≠ some 0 →
        (assimilated before target source (.unenumerated merged (sourceScs ++ targetScs))).values[target]? =
          some (.unenumerated merged (sourceScs ++ targetScs)) ∧
        (assimilated before target source (.unenumerated merged (sourceScs ++ targetScs))).values[source]? =
          some .eliminated ∧
        PendingRealized beforeCaller.checked.native.machine.heap
          (assimilated before target source (.unenumerated merged (sourceScs ++ targetScs)))) := by
    intro sourceNode targetNode merged sourceScs targetScs sourceStored targetStored different _missing carried
    have sourceInside : source < before.values.length := by
      exact (List.getElem?_eq_some_iff.mp sourceStored).elim (fun bound _storedValue => bound)
    have targetInside : target < before.values.length := by
      exact (List.getElem?_eq_some_iff.mp targetStored).elim (fun bound _storedValue => bound)
    have carriedRealized :
      ∀ (slot node : Nat) (scs : List EnumerationState.Suspended),
        (before.values.set target (.unenumerated merged (sourceScs ++ targetScs)))[slot]? =
          some (.unenumerated (some node) scs) →
