import MicroCFTA.SourceCurrentConjunctionTuplesCoverage
import MicroCFTA.SourceCurrentConjunctionEquality
import MicroCFTA.SourceCurrentConjunctionRequirements

/-!
# Allocated rows of the current conjunction check

Each tuple runs the actual equality accessor fold before any requirement
projection. Contradiction removes that tuple. Live tuples thread their
returned constructor heap and equality cache into the next tuple.
The completed exposure schedule has a separate lazy-runtime boundary.
-/
namespace MicroCFTA.SourceCurrentConjunctionRowsAllocation
open Language InternedConstructorTemplates InternedProbeProvenance
open InternedNestedProvenance (Values Edges)
open MergedColdReaderClosedInputs (ClosedValues ClosedEdges)
open SourceEqualityRequiredCache SourceEqualityRequiredSemanticCache
namespace Eq
export SourceCurrentConjunctionEquality (Fields FieldAvailable fold grows_trans)
end Eq
namespace Req
export SourceCurrentConjunctionRequirements (Requirements RowsReady SameArity arity)
end Req
variable {Symbol Formula : Type}
local notation "Guard" => SourceSymbolicIndex.Constraint Formula
local notation "CostHeap" => InternedFreshOrdinaryCostHeap.Heap

/-- Constructor reads and equality allocation retain their separate actual states. -/
structure State (Symbol Formula : Type) where
  heap : InternedConstructorTemplates.State Symbol (SourceSymbolicIndex.Constraint Formula)
  equality : SourceEqualityConstraintMemoAllocation.State

/-- Initial physical invariants supply each reached operation. -/
structure Ready (state : State Symbol Formula) : Prop where
  semantic : SemanticReady state.heap
