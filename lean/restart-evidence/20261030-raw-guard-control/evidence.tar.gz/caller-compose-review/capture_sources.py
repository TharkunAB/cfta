from pathlib import Path
from collections import defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json
area=Path('/tmp/mcfta-raw-guard-control-20261030/caller-compose-review');repo=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA');prior=Path('/tmp/mcfta-worker-control-20261030/enumeration-descent-review')
sha=lambda d:hashlib.sha256(d).hexdigest()
requests=[('SourcePruningEnumerationIncomingNode',1,94),('SourcePruningEnumerationNativeRequestInputs',1,23),('SourcePruningEnumerationNativeRequestInputs',47,68),('SourcePruningEnumerationNativeRequestInputs',24,26),('SourcePruningEnumerationNativeRequestGuardHeap',1,92),('SourceCurrentAllocatedTargetCallerResources',1,118),('SourceCurrentAllocatedTargetCallerResources',62,70),('SourceCurrentAllocatedTargetCallerResources',70,73),('SourceCurrentAllocatedPartialInvariant',13,38),('SourceCurrentAllocatedPartialInvariant',36,69),('SourceCurrentAllocatedPartialInvariant',38,46),('SourceCurrentAllocatedTargetQuery',58,77),('SourceCurrentConjunctionRowsAllocation',1,35),('SourceCurrentConjunctionRowsAllocation',34,39),('SourceEqualityRequiredSemanticCache',18,23),('SourceEqualityNativeDemand',40,53),('SourcePruningEnumerationDispatch',1,20),('SourcePruningEnumerationDispatch',20,38),('SourcePruningEnumerationDispatch',94,170),('SourcePruningEnumerationDispatch',171,200)]
rows=[]
def add(p,start,end,task_source=False,reuse=None):
 d=p.read_bytes();lines=d.splitlines(keepends=True);part=lines[start-1:end];data=b''.join(part);dest=area/'sources'/f'{len(rows)+1:03d}-{p.stem}-{start}-{end}.lean';dest.write_bytes(data)
 rows.append(dict(source=str(p),source_bytes=len(d),source_sha256=sha(d),source_lines=len(lines),requested_start=start,requested_end=end,actual_start=start if part else None,actual_end=min(end,len(lines)) if part else None,eof_clamped=end>len(lines),whole=start==1 and end>=len(lines),nearwhole=len(part)/len(lines)>=0.8,task_source=task_source,copy=str(dest.relative_to(area)),copy_bytes=len(data),copy_sha256=sha(data),reuse_origin=reuse))
for name,start,end in requests:add(repo/(name+'.lean'),start,end)
root=area.parent
for start,end in [(8,32),(116,130),(130,205),(160,181),(178,193)]:add(root/'conjunction-v3.lean',start,end,True)
for tail in ['actual-native-incoming-request.lean','actual-native-assimilation-request.lean']:
 old=next(x for x in json.loads((prior/'source-scope.json').read_text()) if str(x.get('copy','')).endswith(tail))
 p=Path(old['source']);assert sha(p.read_bytes())==old['source_sha256'];origin=prior/old['copy'];data=origin.read_bytes();assert sha(data)==old['copy_sha256']
 add(p,old['actual_start'],old['actual_end'],False,str(origin))
 assert (area/rows[-1]['copy']).read_bytes()==data
for point in [342,351,364,409,411]:add(repo/'SourcePruningEnumerationDispatch.lean',point,point)
(area/'source-scope.json').write_text(json.dumps(rows,indent=2)+'\n')
groups=defaultdict(list)
for r in rows:groups[r['source']].append(r)
unions=[]
for p,rs in sorted(groups.items()):
 covered=set()
 for r in rs:
  if r['actual_start'] is not None:covered.update(range(r['actual_start'],r['actual_end']+1))
 r=rs[0];unions.append(dict(source=p,source_bytes=r['source_bytes'],source_sha256=r['source_sha256'],source_lines=r['source_lines'],task_source=r['task_source'],union_lines=len(covered),union_fraction=len(covered)/r['source_lines'],aggregate_whole=len(covered)==r['source_lines'],aggregate_nearwhole=len(covered)/r['source_lines']>=0.8))
(area/'source-unions.json').write_text(json.dumps(unions,indent=2)+'\n')
wholes=[r for r in unions if not r['task_source'] and r['aggregate_whole']];assert len(wholes)==2
notes={'captured_at':datetime.now(ZoneInfo('Europe/Stockholm')).isoformat(),'old_whole_budget':2,'old_wholes':[r['source'] for r in wholes],'named_third_full_source_authorization':{'source':str(repo/'SourcePruningEnumerationDispatch.lean'),'authorized_by':'Root message 2026-10-30 05:21-05:22 CET','used_for_whole_or_nearwhole':False},'scope_policy':'requested actual source cuts are preserved even when a tool result was truncated; all relied-on interfaces were reacquired exactly; full-file hashing is metadata, not semantic acquisition','truncations':[{'tool':'478035','resolution':'Incoming1-94 and GuardHeap1-88 visible; NativeRequestInputs10-23 and47-68 reacquired'},{'tool':'dfca6c','resolution':'Inputs headers complete; enabled check178-193 reacquired exactly; declaration locators are navigation only'},{'tool':'31794d','resolution':'TargetCallerResources70-73 reacquired; the complete100L source is a WHOLE EOF-clamped acquisition, not partial'},{'tool':'d36635','resolution':'Context13-38,Post38-46 and PartialInvariant36-69 reacquired'},{'tool':'8847a4','resolution':'all28957B V1 diagnostics inspected through exact full-body grouping and complete unified differences; full raw remains pinned'},{'tool':'a4223c','resolution':'diagnostic excerpt truncation replaced by complete unique bodies/diffs in e820a7'},{'tool':'d44ed2','resolution':'Dispatch94-170 contains an unused successful-dispatch header; truncated middle is not relied on. Definitions1-93 were complete via live cuts and frozen20-93 reuse. Scope still includes the complete requested1-200 union.'}],'owner_execution':'source reads/text composition/hashes/owned files only; no compiler/evaluator/native/Git/network/board/repository writes'}
(area/'scope-notes.json').write_text(json.dumps(notes,indent=2)+'\n')
print(json.dumps({'cuts':len(rows),'sources':len(unions),'whole_old':[(Path(r['source']).name,r['source_lines']) for r in wholes],'dispatch_union':[(r['union_lines'],r['source_lines']) for r in unions if r['source'].endswith('SourcePruningEnumerationDispatch.lean')]}))
