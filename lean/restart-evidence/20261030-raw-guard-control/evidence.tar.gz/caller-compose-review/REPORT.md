Recorded 2026-10-30T05:29:21.088335+01:00

The complete literal IncomingNode.run and Dispatch.dispatch functions retain the original closed guard alphabet at every returned caller.

The owner produced two immutable source-only drafts. Root repaired local proof elaboration, installed the final production modules, and passed both builds and strict checks. The owner did not execute Lean, a compiler, an evaluator, native code, Git, network tools, or the board. All owner writes stayed in this assigned directory. The earlier frozen narrowing-review is unchanged.

The result applies to every nativeFuel, projection fuel p, and read fuel h. It includes invalid or missing slots, equal slots, eliminated slots, absent handles, failed lookups, empty rejection, missing encoded actions, all native outcomes, and both outcomes of the enabled check. The result is the predicate Heap (fun guard => guard ∈ alphabet) at the literal returned caller's checked.native.machine.heap. Both functions return that caller at tuple projection .2.1. Heap means that every physical edgeRecords key has its constraint in the SAME supplied alphabet.

The two new public laws are:

- SourcePruningEnumerationIncomingNode.run_heap. Inputs are initial PartialInvariant.Context, Fits profile beforeCaller.checked, Room bits profile, PendingRealized on the original heap and original enumeration state, Available for the incoming value on that heap, incoming.free = [], the original alphabet heap, and Closed alphabet. These accompany the actual operational arguments. The caller width is bits + 2.
- SourcePruningEnumerationDispatch.dispatch_heap. Inputs are the same original Context/Fits/Room/PendingRealized and closed-alphabet heap. Both operands derive from the original pending slots. No incoming operand facts, slot-validity condition, native word-range condition, future result, or completed receipt is a public premise.

public-headers.json retains both complete exact theorem headers. Full production source copies retain the namespace, notations, implicit variables, typeclass binders, imports, and bodies.

The proof first follows the actual stored-slot and lookup cases. IncomingNode.run compresses representatives but reads the original before.values at the actual found representative. PendingRealized at that ORIGINAL state gives a decoded value, its availability, and its closure. The actual lookup equation identifies that witness with the literal operand used by the native request. Dispatch.dispatch derives both operands in this way, at the actual source and target slots. Branches that make no native request return the original caller and its original heap.

For a native request, inputs_of_resources derives InputsThrough for ANY actual nativeFuel from the original Context, Fits, Room, and the two available closed operands. The caller context supplies initial.ready.good. The literal request has no allocated-edge or guard-instruction field obligation, as proved by the existing request_allocated and request_guards laws. NativeRequestGuardHeap.execute_heap then retains the closed alphabet at EVERY returned native state. This covers yielded, failed, constraintError, blocked, and done outcomes. Non-done branches return a caller advanced to that exact native state.

The .done branch has no remaining coupled gate under these original inputs. The proof applies existing TargetQuery.raw_done_caller_resources to the actual case equation. That producer calls finite_caller_resources internally. It constructs the full receipt from the original admission and identifies its value and entire returned checked state with the actual result through completed_unique. A future .done result, Receipt, Complete, or HeadReserved is not an input to either new public law.

The resulting receipt.effects.ready supplies the exact returned Alloc.Ready. receipt.available supplies the actual query's Available fact. post.context.probes supplies ProbeHeap at that SAME returned checked heap. execute_heap already supplies its alphabet heap. These facts satisfy SourceCurrentConjunctionAnnotationOutcome.enabled_check_heap for the literal query and check arguments. Both the enabled and disabled check branches retain the predicate at their actual outcome state. All check failures retain that changed heap in the returned caller. Incoming's finish action and Dispatch's afterQuery encoding do not change the native heap. No successful emitted value or accepted semantic assignment is used.

These two laws remove future native success and future receipt suppliers from this caller composition. They consume original Context/Fits/Room/PendingRealized and the original closed-alphabet heap. They do not derive those entry facts from the compiled public source. Incoming also consumes the original available closed incoming value. Public initial admission and its transport across a whole recursive execution remain open. The result does not assert final Context on every failed or yielded state. It does not prove recursive Native or Prepared worker coverage, a global neutral-work bound, termination, global language coverage, the public API theorem, or Lean/Haskell correspondence.

The immutable owner drafts are:

- SourcePruningEnumerationIncomingGuardHeap-v1-UNTESTED.lean: 110 lines, 7076 bytes, SHA256 e1cfe7326c7f9bf9dcd830a47d0d8cf7fcab6cbf93d3b9721f2af7bd563b3a56.
- SourcePruningEnumerationDispatchGuardHeap-v1-UNTESTED.lean: 131 lines, 8916 bytes, SHA256 7a9009765809aa43a259f7c695e2681185fb127c2f72ea179b3c21cab6fa327f.

The historical UNTESTED names are retained. Root's exact later checks and production repairs are separate pinned artifacts. Both owner public headers match their production headers byte for byte.

Root Incoming V1 failed with a 28957-byte strict log. Six type errors repeat the unresolved outer match; two differ only by encodeNode becoming none or some. Three later query-as-Control errors follow because the unresolved yielded case remained first. The final dsimp error follows that wrong case. All ten records were reviewed using complete unique bodies and complete differences. incoming-v1-diagnostics-dedup.json preserves seven unique bodies, all headers, and exact reconstruction of the complete raw log. Root Incoming V2 and V3 each failed with a 94-byte no-progress log. V4 adds dsimp only at the actual nested some found, unenumerated, some oldHandle, and some observedOld branches and removes the now-redundant dsimp before nativeEq. Its strict log is empty. The final probe source SHA256 is 4204b55ef92d957eea499e719a675ce2ff3a179530eaf037e99595defc5427ef.

Root Dispatch V1 failed with an 877-byte log. The only issues were deprecated if_pos/if_neg lemmas and reduction of the unchanged-caller Id.pure branch. V2 uses ite_eq_left/ite_eq_right and separates simplification from exact known. Its strict log is empty. The final probe source SHA256 is 1fa6d85ea8f1a609119eedd6188397439029d0a2c6973f522e6348b20dc3c7d4. Both complete repair diffs are saved. No public assumption or conclusion changed.

Final production inputs:

- SourcePruningEnumerationIncomingGuardHeap.lean: 7090 bytes, SHA256 9f0a5838ebe16a3e18632a0316a333758eb60d15e109a231107722b4dd734327. Build1494 passed. Strict passed with a 0-byte log.
- SourcePruningEnumerationDispatchGuardHeap.lean: 8869 bytes, SHA256 e1ad9b82f9c5e5b2c04f45e22a07689554fc49553aa64461518a58745751bbc5. Build1497 passed. Strict passed with a 0-byte log.

The production namespace-through-proof text matches each final passing probe exactly after trailing EOF whitespace is removed. Production installation changed module documentation and EOF text. root-evidence.json pins all six probe sources and their complete reports, raw logs, inputs and commands. It also pins both build and strict target snapshots and verifies identity against the current production sources and report source hashes. The checked enabled-check dependency is pinned separately. This bundle does not claim the later global Audit or public axiom readback for these new leaves. Root reported the prior pushed checkpoint 7dabc502d with Audit4710/82720 and public1120/92; that is context from Root, not an owner-run check.

The exact source budget is recorded in source-scope.json and source-unions.json. There are 32 cuts across 11 acquired sources. TWO old sources were acquired in full: NativeRequestGuardHeap88L and TargetCallerResources100L. The requests were respectively1-92 and1-118, so both are explicitly recorded as WHOLE EOF-clamped reads. They are not called bounded partial reads. Root explicitly authorized Dispatch as a named third whole or near-whole source if needed. That exception was unused. Dispatch remains partial:1-200 plus the five used one-line proof locators342,351,364,409,411, for205/435 lines. All other old sources remain below80 percent union coverage. Two frozen original cuts were reused only after their current complete source SHA256 matched. No prior frozen bundle was edited.

scope-notes.json records truncated tool outputs and the exact relied-on interfaces reacquired afterward. The truncated portion of the unused dispatch_complete header is not a proof dependency. Its complete requested range still counts in the recorded source union. All acquired source identities still matched when Root evidence was captured. Full-file hashing and exact checked-source copying do not represent additional semantic whole-source reviews.

No Haskell source was read or changed. No Haskell fix was identified. This addition is a formal caller-retention proof and should not be listed as a Haskell fix in FINDINGS. Any future runtime fix needs its own evidence and FINDINGS entry.

The payload is complete. pins.json covers its files. FROZEN.json records the measured write halt. The owner will make no further writes in this directory after that halt. The full global objective remains active with Root.
