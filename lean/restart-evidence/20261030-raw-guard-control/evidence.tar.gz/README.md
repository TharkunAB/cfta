# Raw pruning guard heaps and physical input plans

Full goal ACTIVE. Read final-documents/lean/notes-current-raw-guard-control.md.
Thirty-one new public laws in nine modules preserve actual returned heaps,
including raw projection, bounded emptiness, native requests and both complete
incoming/dispatch callers. Current Context/Fits/Room and closed available
operands construct every requested physical input plan. Complete callers derive
observed native receipts and exact check admission internally. No future success
or future receipt is a public premise. Original public admission and all earlier
alternative/staged-child transport of full coupled resources remain open.
Existing cold equality completion/preservation is already proved. Retain it.
Audit4712/82734 and public1122/92 pass. All31 new axiom reports are standard.
All nine leaves and Audit have matching current strict input copies. All prior
504 protected and835 native inputs remain exact; current protected513.
All51 commands remain:39pass/12failed repaired drafts and303 source snapshots.
The complete old public output and both intermediate readbacks are exact prefixes.
Five frozen reviews verify562 payload pins with exact file sets. Every report
was read. All failed/uncompiled versions, scope limits, truncation recoveries,
EOF clamps, named read exceptions and timestamp corrections remain explicit.
No Haskell source changed or new defect/fix was established. FINDINGS preserves
prior repairs, the conditional SCS candidate and exact caller/runtime boundaries.
Every regular payload is archived without filtering. Keep this area immutable.
The verifier runs no Lean or Haskell. Continue in a fresh writable evidence area.
