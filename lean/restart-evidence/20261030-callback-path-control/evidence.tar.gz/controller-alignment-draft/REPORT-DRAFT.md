# Callback input path transport

Status: SOURCE-ONLY COMPLETE DRAFT, awaiting Root feedback and checks. No freeze yet.

The 58-line SourcePruningEnumerationPathHookInvocation.lean has two complete proofs. Invocation.paths derives the actual hook input's StatePaths P from the original captured core, inherited bucket, suffix closure and the projected paths of every literal selected edge. Invocation.paths_of_forecast derives those projection premises from initial selected-guard membership in the same guards list and ProjectionPaths guards P.

The existing Invocation.selected theorem already gives an actual selected-edge complete equation at the exact hook input. The selected edge stays in the original list. The captured before cache is the same in all three Invocation constructors. Thus the proof needs neither a second existential producer nor a new worker-preservation premise. It does not use output membership. Invocation.here includes the current hook even if that hook stops before the controller adds its head to processed.

Root accepted this direct route in place of producer alignment. The separate paired resource-producer companions remain independent. The new route changes no existing controller header, clause, witness, receipt or bound. It can append the new fact at the exact original work value. INSTANTIATION.md records the initial Native and Prepared guard-membership derivations and the exact role of stage_ge.

The draft's public argument order and complete source statement cuts are in PUBLIC-HEADERS.json and contracts/. The source SHA256 is a4e6f1ec47f18ba25e0f96e70359c4a9b06f51e0084e2a9a90bca88840776103, 3583 bytes. Version1 is retained unchanged in versions/.

Source scope: ten exact reused cuts, four newly acquired bounded cuts, zero newly acquired whole or near-whole old sources out of a limit of two. Reused Native finite-head cuts are background for the rejected producer-alignment route, not premises of the new proof. Fresh HookInvocation cuts are lines10-24 and145-163 of163; the latter ends exactly at EOF without a clamp. Fresh reservation cuts are Prepared140-146 and Native145-151. No requested source endpoint exceeded its source. The earlier frozen design's conservative2/2 whole-source charge remains in that design; it is not reclassified here. Every source and literal copy hash is in the acquisition and reuse manifests.

This task executes no Lean, evaluator, native tests, Git, network or board operations and changes no repository source. No Haskell change or finding was established. The claim is about actual callback input cores. It is not an all-state global recursion, termination, unbounded API or Haskell correspondence theorem.

Recorded time: 2026-10-30T01:58:47.441157+01:00
