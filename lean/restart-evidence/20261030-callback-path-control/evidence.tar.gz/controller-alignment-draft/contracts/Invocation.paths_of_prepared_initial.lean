theorem Invocation.paths_of_prepared_initial
    {Typing : Type}
    {hook : Fragment → Caller width → Queries → Cached → HookResult Output Reason width}
    {checkEmpty : Bool} {r n p h k target handle depth : Nat} {scs : List Suspended} {before : Cached}
    {storedEdges edges : List (EdgeValue Symbol Constraint)} {caller reached : Caller width}
    {memos : EndpointMemoGateTrace.Memos} {saved : Queries} {fragment : Fragment} {after : Cached}
    {formulas : SourceGuards.Formulas FullSyntax.Formula} {solver : SourceGuards.Entailment FullSyntax.Formula}
    {inventory : SourceCurrentAllocatedNativeInventoryState.Inventory}
    {metadata : SourcePruningRecordTypes.Metadata Typing}
    {seed : SourcePruningEnumerationIncomingReservation.Seed}
    {parentEntry : Cache.Interned InternedBinderProtocol.NodeKey} {free : List InternedBinderProtocol.Reference}
    (invocation : Invocation hook checkEmpty r n p h k target scs before edges caller memos.query fragment reached saved after)
    (packet : SourcePruningEnumerationRecursive.Packet formulas solver inventory caller memos metadata before)
    (stored : before.core.values[target]? = some (.unenumerated (some handle) scs))
    (parentAvailable : InternedProbeProvenance.Available caller.checked.native.machine.heap
      (.node parentEntry storedEdges depth free))
    (selected : ∀ edge ∈ edges, edge ∈ storedEdges)
    (known : SourceEqualityAnnotationHeap.Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)
    (guards : List Constraint) (included : seed.1 ⊆ guards) (projected : ProjectionPaths guards P)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (paths : StatePaths P before.core) : StatePaths P after.core := by
