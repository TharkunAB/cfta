# Native and Prepared controller application

The new lemma quantifies over every actual Invocation, all five head fuel arguments, and any hook output and reason types. It selects the exact completed captured-edge equation already stored by Invocation.selected. It does not select a new head result or bound.

Keep the existing controller's witnesses and every result clause. For each original work = bound + extra, instantiate Invocation.paths_of_forecast with the actual old hook and r = n = p = h = k = work. Use the old captured before cache and the same selectedEdges list. The conclusion is independent of output membership and of the callback result. It therefore covers the current stopped callback head as well as completed-prefix heads.

Derive the known argument from the initial input, once:

1. Obtain the exact initial parent availability. Prepared uses its initial parentAvailable field. Native obtains PendingRealized from the initial packet.valid, applies it to the stored slot, and identifies the parent by the initial decoded equation. Do not use the Prepared fields in the Native proof.
2. For each edge in selectedEdges, selectionMembers puts the same literal edge in the original parent edges. resident_edges uses the initial linked heap and parent residency to establish edge residency. The original known heap predicate gives membership of edge.entry.key.constraint in seed.1.
3. In either reservation namespace, stage_ge recursiveFuel seed capturedMass inherited selectedEdges.length gives seed.1 inclusion in the existing final sibling stage guards. Compose it with the original forecast inclusion into guards. No per-event index or common larger bound is needed.
4. original supplies StatePaths P before.core. The original stored-slot equation supplies BucketPaths P scs. projected and tails are the same original forecast and suffix premises for all invocations.

The Native namespace is SourcePruningEnumerationFiniteReservation. The Prepared namespace is SourcePruningEnumerationPreparedReservation. Their stage_ge statements are retained in the new exact cuts. They do not identify narrowSeed with preparedSeed or assert a depth-uniform forecast.

The recording conjunct is separate. Root owns the direct recordTypes success-to-values/path preservation proof. It should apply to the actual recording Success equation at the callback input, then to the actual frame passed to resume. The invocation lemma does not assume that a later recursive worker preserves P or that a recording succeeds.
