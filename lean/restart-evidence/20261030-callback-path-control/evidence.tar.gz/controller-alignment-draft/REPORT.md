# Callback input path transport

Status: PASS for the exact final four-law module and Root's matching build and all-linter strict check. The owner performed source-only work and wrote only this owned area.

## Result and exact source

Every actual HookInvocation.Invocation receives a cache with the same original path predicate P, under the stated original storage, inherited bucket, suffix closure and guard-projection premises. This includes the callback for the current completed head when that callback stops before the controller adds the head to processed. No output-membership premise is used.

Final source: `SourcePruningEnumerationPathHookInvocation.lean`, 126 lines, 8782 bytes, SHA256 `6ad6cc57056459e7dc6154b3453e0b5a0696b6d5aa49930b675d212a7fce3375`. It matches the current repository module and the actual invocation-v3 strict checked copy. Four complete public statements are in contracts/. PUBLIC-HEADERS.json pins their exact source ranges and byte hashes. CONTRACT-MAP.json identifies each original premise, actual source equation, and conclusion.

The module imports the previously checked head path law and the existing HookInvocation definition. The original Invocation argument order is hook, checkEmpty, r, n, p, h, k, target, scs, before, edges, caller, queries, fragment, reached, saved, after. The same original captured before cache appears in every constructor. All four laws retain the exact existing Symbol, EdgeKey and Node equality context. Output and Reason remain arbitrary types.

## Direct proof and original clauses

Invocation.selected already returns a literal edge in the original list and the exact actual CapturedEdge.run complete equation at the hook input. Invocation.paths applies the checked CapturedEdge.complete_paths theorem to that equation. It uses the same P, original before core, inherited bucket, suffix closure, and projected guard paths. It does not infer the hook input from an output or a processed receipt.

Invocation.paths_of_forecast supplies the projection premise from the initial list's guard membership and ProjectionPaths guards P. It does not assume that later native heaps have a new guard carrier. The selected edge is literal data in the original list.

The proofs work at every r, n, p, h and k that appears in the actual invocation equation. They choose no new bound or receipt. Thus an existing Native or Prepared controller can retain every old witness, run equation, stopped-case equation, result clause and bound. At work = bound + extra, instantiate this same law with all five head fuel arguments equal to the old work. The new path fact is outside any accepting-model observer.

Invocation.here has an actual completed-head equation and no hook-result premise. A stopping current callback is therefore included. Invocation.completed and Invocation.other retain the same original captured cache for the suffix. The existing Invocation.selected proof follows those constructors. The current head need not belong to processed.

## Separate initial Native and Prepared wrappers

Invocation.paths_of_native_initial takes the actual original Native admission inputs. It derives BucketPaths P scs from StatePaths P before.core and the exact stored-slot equation. It obtains PendingRealized from the original packet.valid. Realization of that exact slot supplies a parent lookup and availability at the initial caller heap. The decoded source lookup identifies that parent with the original node. Initial linked-heap evidence and selected-edge membership give physical residency of each literal edge. The original known heap predicate and seed.1 inclusion into guards then supply initial guard membership.

Invocation.paths_of_prepared_initial takes the actual original Prepared inputs. It uses the same stored-slot path derivation. It obtains parent residency from the separately supplied parentAvailable and linked-heap evidence from packet.context. It uses the original selected membership, known heap predicate and seed inclusion. The packet is used; it is not an unused extra argument. This proof does not use the Native decoded-parent argument or borrow a Native source field.

Neither wrapper takes a CompletedHeadReceipt, recursive Complete argument, output-membership premise, chosen M, new validity packet, or future-worker path law. The input Packet remains the existing actual controller admission packet, with its existing validity and context fields. The path result does not assert that every admitted head completes.

## Initial stage forecast inclusion

Both reservation namespaces already have stage_ge depth seed capturedMass inherited count. Its second conclusion is seed.1 inclusion in the guard component of the corresponding stage. Compose that inclusion with the existing controller forecast inclusion into guards. This supplies the wrappers' included premise once for the original input.

The Native namespace is SourcePruningEnumerationFiniteReservation. The Prepared namespace is SourcePruningEnumerationPreparedReservation. Use each controller's actual starting seed. No equality between narrowSeed and preparedSeed is used. No per-event index, count_mono alignment, separate existential producer, or larger common bound is required. The exact stage_ge statements are retained in the two new bounded source cuts. INSTANTIATION.md records the concrete original admission derivations.

## Correction to the earlier design

The sealed next-callback-design report proposed retaining full head receipts or aligning two existential producers to prove the callback path fact. That approach is sufficient, but it is not necessary. The direct actual Invocation.selected equation makes the extra producer alignment unnecessary for this property. HANDOFF-CORRECTION.md records this distinction. The frozen prior bundle is unchanged.

ReceiptAt still does not retain a full CompletedHeadReceipt. The new proof does not need to recover that receipt. The separate paired resource-producer companions remain independent; no such producer is imported or used by the four new proofs.

## Recording composition boundary

Root independently implemented SourcePruningEnumerationPathCallbackInvariant.Invocation.recorded_paths_of_forecast using this module's generic invocation law and generic recordTypes path preservation. Root reported its build and strict checks passed and assigned its independent review elsewhere. This owned module adds no duplicate composition.

The generic recording result takes an actual Success equation and does not require representative totality, a completed receipt, or a semantic model. It can transport the same P to the exact framed core after any successful recording element at an actual invocation. The checks for that separate module are not included in this bundle's five-command verification denominator.

## Root checks and retained failure

| Root check | Exit | Log bytes | Log SHA256 |
| --- | ---: | ---: | --- |
| invocation-v1-build | 0 | 563 | `1dd9cfc14fb437803c52a9cfa51ca064a9ebb4fd2b016fac2a40464e4a324fe7` |
| invocation-v1-strict | 0 | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| invocation-v2-build | 1 | 10206 | `4db34cc9161d57853c7b72dc351a23ed32ef9e0571d10b824a60553850786f7e` |
| invocation-v3-build | 0 | 563 | `3997cdcb588e7a35c0f90fa2f174a1901c7e852df330ad27872a08ba0babc0b2` |
| invocation-v3-strict | 0 | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |

V1 contains the original two generic declarations, 58 lines and 3583 bytes, SHA256 `a4e6f1ec47f18ba25e0f96e70359c4a9b06f51e0084e2a9a90bca88840776103`. It passes Root build and strict checks. The two declarations' headers and bodies remain byte-identical in V2 and V3.

V2 adds the two initial wrappers. It has 126 lines and 8752 bytes, SHA256 `28846e73a3c1c6492494162f63aaf0ceabe6d809121b42edb5df732e16b9fbbe`. The Native header omitted the lookupNode namespace qualification. The failed build reported an unknown function and a resulting .node type error. The complete 10206-byte diagnostic and exact failed source are retained. No V2 strict check ran.

V3 changes that one function token to SourcePruningEnumerationNodes.lookupNode. The complete qualification patch is retained. It changes no proof or intended premise. Root's final build completes 1998 jobs. Its final strict check exits 0 with an empty log and the exact final source hash.

The strict commands use Lean 4.34.1, -DwarningAsError=true and -Dlinter.all=true. The five Root reports record memory.max and memory.high of 4294967296 bytes and memory.swap.max of 0. Lake replays the existing InternedFreshOrdinaryClosedCompletion warning. The final module strict log is empty.

ROOT-CHECKS.json records the actual commands and receipts. Each root-checks directory retains the report, started command, input manifest and full raw log. Both successful strict checked copies are retained. All 26 Root input snapshot rows match their recorded byte hashes. Their exact Root paths and bytes are in ROOT-CHECKS.json. These dependency snapshots were hashed for provenance rather than acquired as new proof-pattern sources. Root retains their full archive. This owner ran no Lean, evaluator, native test, Git, network or board command.

## Source limits and acquisition incidents

This task acquired 0 new whole or near-whole old sources out of its limit of 2. It reused 15 exact frozen scopes after checking current full-source identities and literal copy hashes. The Native finite-head cuts are background for the rejected producer-alignment strategy, not dependencies of the direct proof. Their earlier frozen design conservatively charged its own 2/2 source budget; that charge remains there.

Four new bounded cuts read HookInvocation lines 10-24 and 145-163, PreparedReservation lines 140-146, and FiniteReservation lines 145-151. The HookInvocation tail ends exactly at its line163 EOF. No endpoint overrun or clamp occurred. acquisitions.json records all requested and actual endpoints, full source bytes/hashes, and copied cut bytes/hashes. The reused-scope manifest retains the exact prior source provenance.

A broad initial-context rg query returned 174 matching source lines across four explicit files and exceeded its 3600-token display budget. The complete 6492-token query result is retained as locator-initial-context-full.txt. locator-scope.json records every matched line number, file size and hash. Per-file matching coverage is 52/498, 44/277, 39/226 and 39/256 lines. No file was acquired whole or near-whole. No proof depends on an omitted display entry. The complete retained query supplied the actual Heap alias and controller field names. The separate instance locator confirmed HookInvocation and CapturedEdge both declare the same three equality instances.

## Claim boundary

The proved scope is every actual callback input described by Invocation, under the exact original storage and forecast hypotheses. This includes the stopping current callback and requires no output filter. It does not establish a fixed forecast uniform over all recursion depths, all-state recursive control, global termination, unbounded API coverage, or Haskell correspondence. Stored path preservation is not a native-handle count bound. No Haskell source was changed or newly verified Haskell defect established.

The earlier REPORT-DRAFT.md is a historical V1 draft report. This final report supersedes it.

Final recorded time: 2026-10-30T02:08:30.546702+01:00
