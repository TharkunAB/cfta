# Correction to the sealed callback design

The prior `/tmp/mcfta-child-path-control-20261030/next-callback-design/REPORT.md` proposed retaining full CompletedHeadReceipt evidence or aligning separate existential head producers to transport paths through actual callback inputs. That is a sufficient approach. It is not a required obligation.

The existing HookInvocation.Invocation.selected theorem already supplies the exact CapturedEdge.run completion equation for each actual callback input. CapturedEdge.complete_paths applies directly to that equation. The captured before cache remains fixed across sibling calls. The literal selected edge remains a member of the original edge list. Its guard membership can be established at the initial caller once. No full head receipt, second producer, common larger bound, output membership, or new future-worker path law is required for this path result.

ReceiptAt still does not recover a full CompletedHeadReceipt. That observation remains correct. The direct invocation path proof does not need such a recovery. The two independent paired resource-producer companions retain their own useful exact-receipt statements, but they are not dependencies of this module.

The original frozen design remains unchanged. This correction records the implemented alternative and its exact source basis.
