          match outcome with
          | .complete _ actual queries =>
              ∃ (next : Inventory) (final : Memos),
                Post formulas solver next caller actual final ∧ final.query = queries ∧
                Packet formulas solver next actual final metadata before ∧
                Fits (finiteStep recursiveFuel seed capturedMass inherited).2 actual.checked ∧
                Heap (fun guard => guard ∈ (finiteStep recursiveFuel seed capturedMass inherited).1)
                  actual.checked.native.machine.heap
          | .stopped _ _ _ => True) := by
  obtain ⟨roots, paths, _storage, realized, counts, flags⟩ := packet.valid
  obtain ⟨value, lookup, available, _closed⟩ := realized uv handle scs stored
  have same : value = .node parentEntry storedEdges depth free := Option.some.inj (lookup.symm.trans decoded)
  subst value
  obtain ⟨children, own⟩ := SourcePruningEnumerationRecursiveReservation.edge_shape_from_packet
    seed formulas solver inventory caller memos metadata before packet bounded known
    parentEntry storedEdges depth free available edge selected
  have costBound := SourcePruningEnumerationRecursiveReservation.edge_cost_le seed inherited scs
    before.core.counter edge children own inheritedLength
  have pending := EnumerationReferences.pending_inputs before.core packet.pending uv (some handle) scs stored
  obtain ⟨r, n, p, h, k, receipt, middleCaller, saved, middleMemos, middleInventory,
    headRun, headPost, headQueries, admitted, headPending, history, shape, headFits, headKnown, cacheBounds⟩ :=
    SourcePruningEnumerationNativeBranchCompletion.head_complete_cache_bounds seed formulas solver inventory caller before
      checkEmpty uv handle scs parentEntry storedEdges depth free edge roots memos packet.context ready stored decoded
      realized selected paths counts flags pending bounded (reserved.edge costBound) known
      (scalar seed.2) (guardWidth seed.1) children own
  have padding := SourcePruningEnumerationRecursiveReservation.head_padding seed inherited
    (edgeCost scs before.core.counter edge) costBound
  have boundedHead := headFits.mono padding.1
  have knownHead : Heap (fun guard => guard ∈ (afterHead seed inherited).1)
      middleCaller.checked.native.machine.heap :=
