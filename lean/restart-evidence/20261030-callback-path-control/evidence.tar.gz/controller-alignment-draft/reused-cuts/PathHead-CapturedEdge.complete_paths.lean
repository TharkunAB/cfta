theorem complete_paths
    (checkEmpty : Bool) (r n p h k target : Nat) (scs : List Suspended)
    (edge : EdgeValue Symbol Constraint) (caller reached : Caller width)
    (before after : Cached) (queries saved : Queries) (fragment : Fragment)
    (paths : StatePaths P before.core) (inherited : BucketPaths P scs)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (projected : ∀ tries residual,
      SourcePruningEnumerationConstraint.project edge.entry.key.constraint = some (tries, residual) →
      ∀ trie ∈ tries, ∀ path ∈ EqualityTrie.fromPathTrie trie, P path)
    (completed : run checkEmpty r n p h k target scs edge caller before queries =
      some (.complete fragment reached saved after)) : StatePaths P after.core := by
