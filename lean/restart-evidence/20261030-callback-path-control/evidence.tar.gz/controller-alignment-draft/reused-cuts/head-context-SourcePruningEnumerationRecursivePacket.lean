local notation "Metadata" => SourcePruningRecordTypes.Metadata
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Core" => EnumerationState.State Symbol Constraint
local notation "Inventory" => SourceCurrentAllocatedNativeInventoryState.Inventory
variable {Typing : Type} {width : Nat}
variable [DecidableEq (EdgeKey Symbol Constraint)]

/-- A recursive restart retains the native context, cache invariants and allocated pending IDs. -/
structure Packet (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula) (inventory : Inventory)
    (caller : Caller width) (memos : Memos) (metadata : Metadata Typing) (before : Cached) : Prop where
  /-- The native caller satisfies the context at the full memo state. -/
  context : Context formulas solver inventory caller memos
  /-- The enumeration core has safe storage and live roots. -/
  safe : EnumerationSchedule.Safe before.core
  /-- Suspended references avoid every enumerated class. -/
  pending : EnumerationReferences.PendingReferences before.core
  /-- The captured cache retains native handles and both indexes. -/
  valid : CacheValid caller before
  /-- Stored fragments admit dependency levels below a finite frontier. -/
  ordered : ∃ level frontier, EnumerationOrder.Stratified before.core level frontier
  /-- Every pending template entry names an allocated variable. -/
  bounded : ∀ group ∈ metadata.pending, SourcePruningPartialMatch.PendingBound before.core.counter group

variable {formulas : SourceGuards.Formulas FullSyntax.Formula}
  {solver : SourceGuards.Entailment FullSyntax.Formula} {inventory next : Inventory}
  {caller nextCaller : Caller width} {memos final : Memos}
  {metadata : Metadata Typing} {before : Cached}

/-- Actual native effects preserve the same captured cache and enumeration metadata. -/
theorem captured_post (packet : Packet formulas solver inventory caller memos metadata before)
    (post : Post formulas solver next caller nextCaller final) :
    Packet formulas solver next nextCaller final metadata before :=
  ⟨post.context, packet.safe, packet.pending,
    SourcePruningEnumerationNativeBranchCompletion.cacheValid_post caller nextCaller before packet.valid post,
    packet.ordered, packet.bounded⟩

/-- Safe callback reads transport the packet to their returned core and metadata. -/
theorem callback_frame (packet : Packet formulas solver inventory caller memos metadata before)
    (updated : Metadata Typing) (after : Core) (safe : EnumerationSchedule.Safe after)
    (frame : EnumerationCompressionFrame.Frame before.core after)
    (ordered : ∃ level frontier, EnumerationOrder.Stratified after level frontier)
    (bounded : ∀ group ∈ updated.pending, SourcePruningPartialMatch.PendingBound after.counter group) :
