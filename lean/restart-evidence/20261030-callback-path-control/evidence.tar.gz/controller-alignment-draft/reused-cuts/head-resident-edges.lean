    ∀ edge ∈ nodeEdges value, EdgeResident state edge

/-- The initial source tables contain no unlinked edge payload. -/
theorem empty_linked : Linked (empty (Symbol := Symbol) (Guard := Guard)) := by
  intro key value impossible
  cases impossible

/-- Actual table growth retains complete edge payloads. -/
theorem edge_grows (before after : State Symbol Guard) (growth : Grows before after)
    (edge : EdgeValue Symbol Guard) (resident : EdgeResident before edge) : EdgeResident after edge :=
  growth.edgeRecords edge.entry.key edge resident

/-- Residency of the parent gives residency of every actual outgoing edge. -/
theorem resident_edges (state : State Symbol Guard) (linked : Linked state)
    (value : Value Symbol Guard) (resident : Resident state value) :
    ∀ edge ∈ nodeEdges value, EdgeResident state edge := by
  cases value <;> simp only [nodeEdges] <;> try simp
  case node entry edges depth free => exact linked entry.key _ (resident entry rfl)

/-- Adding an edge record preserves every link from an existing node. -/
theorem edgeStep_linked [DecidableEq (EdgeKey Symbol Guard)] (key : EdgeKey Symbol Guard)
    (identify : Interned (EdgeKey Symbol Guard) → EdgeValue Symbol Guard)
    (state : State Symbol Guard) (valid : InternedConstructorTemplates.Valid state) (linked : Linked state) :
    Linked (edgeStep key identify state).2 := by
  intro other value stored edge member
  have original : state.nodeRecords other = some value := stored
  exact edge_grows state _ (edgeStep_correct key identify state valid).2.1 edge
