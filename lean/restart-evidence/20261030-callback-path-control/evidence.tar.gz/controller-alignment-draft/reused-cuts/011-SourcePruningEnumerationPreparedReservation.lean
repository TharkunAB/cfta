          Le current.2 (step depth current ceiling ceiling).2 ∧
            current.1 ⊆ (step depth current ceiling ceiling).1 := by
        intro current
        have head := SourcePruningEnumerationRecursiveReservation.afterHead_ge current ceiling
        have callback := ih (afterHead current ceiling) (massCeil current ceiling ceiling)
        exact ⟨head.1.trans callback.1, fun _ member => callback.2 (head.2 member)⟩
      have later := iterate_ge (fun current => step depth current ceiling ceiling) growth
        (preparedSeed seed) (rows seed)
      have first := preparedSeed_ge seed
      rw [final_succ]
      exact ⟨first.1.trans later.1, fun _ member => later.2 (first.2 member)⟩

/-- The completed head fits the following smaller-depth callback forecast. -/
theorem afterHead_le_step (depth : Nat) (seed : Seed) (capturedMass inherited : Nat) :
    Le (afterHead seed inherited).2 (step depth seed capturedMass inherited).2 ∧
      (afterHead seed inherited).1 ⊆ (step depth seed capturedMass inherited).1 :=
  final_ge depth (afterHead seed inherited) (massCeil seed capturedMass inherited)

/-- Each paired stage retains its input seed. -/
theorem step_ge (depth : Nat) (seed : Seed) (capturedMass inherited : Nat) :
    Le seed.2 (step depth seed capturedMass inherited).2 ∧
      seed.1 ⊆ (step depth seed capturedMass inherited).1 := by
  have head := SourcePruningEnumerationRecursiveReservation.afterHead_ge seed inherited
  have callback := afterHead_le_step depth seed capturedMass inherited
  exact ⟨head.1.trans callback.1, fun _ member => callback.2 (head.2 member)⟩

/-- Every sibling schedule retains its original profile and guards. -/
theorem stage_ge (depth : Nat) (seed : Seed) (capturedMass inherited count : Nat) :
