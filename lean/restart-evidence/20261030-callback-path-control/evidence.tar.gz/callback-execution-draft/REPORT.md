# Actual callback execution bridge

The source-only draft ties each worker's actual constructor callback entry to its literal false-recording recur call. Both public laws carry the original stored path predicate to that call's exact cache input. Root build and strict checks pass for the exact production source.

## Public API

The module is `SourcePruningEnumerationPathCallbackExecution.lean`, namespace `MicroCFTA.SourcePruningEnumerationPathCallbackExecution`. The two public laws are `native_false_paths_of_forecast` and `prepared_false_paths_of_forecast`. Complete headers are saved separately. Production has 106 lines and 6579 bytes, SHA256 `50f76d4dc5f714518b236dfd2d6664cf71fe818d5a881640fb3ed3b4702d7dbf`. Owner draft v1 has 107 lines and 6625 bytes, SHA256 `560cc142ee07587bc2c940bcf48ba1976b6ef9b90f64b65363cbceb6a153376c`. Production removes only the source-only status line. All public headers and proof bodies remain exact. `public-context.lean` retains all local type aliases and binders used by the two complete header copies.

Each law fixes the Invocation hook to the worker's actual `continueWith recur graph templates stop order work metadata target` closure. It retains the exact original captured state, edge list, work parameters, target, suspended constraints, callers, queries, completed fragment, and completed cache. Its forecast gates are the original guard membership, projection paths, suffix closure, original StatePaths, and inherited BucketPaths.

The callback premise is the exact complete raw list equality:

`ExceptT.run (recordTypes graph templates work metadata target (.inl fragment) after.core) = [.ok ((false, updated), callbackCore)]`.

The first conclusion is `StatePaths P (frame callbackCore after).core`. The second conclusion is the literal equation:

`continueWith recur graph templates stop order work metadata target fragment reached saved after = recur updated reached saved (frame callbackCore after) (Restart.decision stop order updated (frame callbackCore after))`.

The same updated metadata, reached caller, saved queries, framed cache, and configured stop/order decision occur on both sides. No recursive result is supplied or constrained. The recursive function is uninterpreted.

## Native and Prepared remain separate

Both workers use `SourcePruningEnumerationRecursive.Output width Typing`. Their Failure types are different. Native uses `SourcePruningEnumerationRecursive.Failure width Typing`; Prepared uses `SourcePruningEnumerationPreparedRecursive.Failure width Typing`. Each recur has the corresponding actual HookResult family. The proof does not cast between or identify the Failure types.

## Proof route

`Success` means membership in the actual raw result list. Each exact raw singleton equality supplies that membership. The checked `Invocation.recorded_paths_of_forecast` then transfers P from the original captured state and guard projections to the recorded frame. Finally, simplification of the actual worker's `continueWith` definition with the same exact raw equality selects its false branch and reduces to the literal recur equation.

The raw equality supplies both the branch membership required by the invariant law and the full singleton pattern required by continueWith. A generic pointwise success alone would not select that pattern.

No completed head receipt, representative Total, new Validity, semantic model, recursive worker postcondition, or future resource supplier is added. The Invocation already describes an observed completed head entry. The law does not request a future head completion. It proves the cache input to the current continueWith recur application. It does not prove that recur preserves P, that recur returns, or that every other recursive dispatch site has this interface. It does not prove recording existence or a sufficient work bound.

The optional true-branch equation pair is not added. The already checked any-Bool invariant proves P for successful true recordings. The required false-branch bridge is kept to two public laws.

## Source scope

The continuation body cuts reuse frozen old lines 57–78 of Native and 49–70 of Prepared after full current-source hash checks. All source acquisitions have exact endpoints, source/copy hashes and byte counts in `source-scope.json`. `old-source-union.json` reports each union: Native 70/128 lines, Prepared 66/120, Restart 20/81, and Success definition 13/1276. The two broad worker unions are conservatively charged as both available nearwhole old-source acquisitions. No whole old source is acquired. No EOF-clamped read is relabelled whole. Proof-bearing displays are complete.

The checked callback invariant is reused from its frozen reviewed source. The unique production filename was absent at bootstrap. This owner changed only this owned draft directory. This owner ran no compiler, evaluator, native, Git, network, board, or repository source mutation. All earlier owned bundles remain frozen. Root owns compilation and repository integration. No Haskell change or Haskell fix was identified. The global formalization objective remains active.

## Exact Root validation

`execution-v1-build` exits 0 and passes 2001 build jobs. `execution-v1-strict` exits 0 with `warningAsError=true`, `linter.all=true`, and an empty log. Matching full reports, raw logs, started commands, input manifests, both input-source snapshots, and the strict checked source are retained under `root-evidence/`. Their log lengths and hashes match the reports. The build replays an existing warning from `InternedFreshOrdinaryClosedCompletion`; the strict target is clean.

The current repository source, Root production copy, both input-source snapshots, and strict checked source all match the production hash above. Both public headers are byte-exact with the owner draft. `final-identity.json` records those checks. All original source hashes and copied cuts were checked again before sealing. This module passed in its first Root production version; no failed compiler receipt was present or discarded.

This owner remains source-only. Root performed all compiler and strict runs. No additional proof work is included after the requested execution bridge. No new Audit or public sweep result is claimed. Both full worker termination and other recursive dispatch interfaces remain separate obligations. The global formalization goal remains active.

Measured completion: 2026-10-30T02:10:18+01:00
