import MicroCFTA.SourcePruningEnumerationPathCallbackInvariant
import MicroCFTA.SourcePruningEnumerationPreparedRecursive

/-!
# The actual recursive call retains the original stored paths

The recursive function remains uninterpreted.
-/

namespace MicroCFTA.SourcePruningEnumerationPathCallbackExecution
open EnumerationState EnumerationCorrectness InternedConstructorTemplates
open SourcePruningEnumerationPathTransport SourcePruningEnumerationHookInvocation
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Fragment" => Fragments.Fragment Symbol
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Metadata" => SourcePruningRecordTypes.Metadata
local notation "Core" => EnumerationState.State Symbol Constraint
local notation "HookResult" => SourcePruningEnumerationNativeContinuations.HookResult
variable {width : Nat} {Typing : Type} {P : EqualityTrie.Path → Prop}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
local notation "NativeResult" => HookResult (SourcePruningEnumerationRecursive.Output width Typing)
  (SourcePruningEnumerationRecursive.Failure width Typing) width
local notation "PreparedResult" => HookResult (SourcePruningEnumerationRecursive.Output width Typing)
  (SourcePruningEnumerationPreparedRecursive.Failure width Typing) width

