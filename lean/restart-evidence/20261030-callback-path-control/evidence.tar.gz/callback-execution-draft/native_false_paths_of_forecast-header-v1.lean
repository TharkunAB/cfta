theorem native_false_paths_of_forecast
    (recur : Metadata Typing → Caller width → Queries → Cached → Option Next → NativeResult)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat)
    (work : Nat) (metadata : Metadata Typing)
    {checkEmpty : Bool} {r n p h k target : Nat} {scs : List Suspended} {before : Cached}
    {edges : List (EdgeValue Symbol Constraint)} {caller reached : Caller width} {queries saved : Queries}
    {fragment : Fragment} {after : Cached}
    (invocation : Invocation
      (SourcePruningEnumerationRecursive.continueWith recur graph templates stop order work metadata target)
      checkEmpty r n p h k target scs before edges caller queries fragment reached saved after)
    (guards : List Constraint) (known : ∀ edge ∈ edges, edge.entry.key.constraint ∈ guards)
    (projected : ProjectionPaths guards P)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (paths : StatePaths P before.core) (inherited : BucketPaths P scs)
    (updated : Metadata Typing) (callbackCore : Core)
    (observed : ExceptT.run (SourcePruningRecordTypes.recordTypes
      graph templates work metadata target (.inl fragment) after.core) =
      [.ok ((false, updated), callbackCore)]) :
    StatePaths P (EnumerationExpandableIndex.frame callbackCore after).core ∧
      SourcePruningEnumerationRecursive.continueWith recur graph templates stop order work metadata target
        fragment reached saved after =
      recur updated reached saved (EnumerationExpandableIndex.frame callbackCore after)
        (SourcePruningEnumerationRestart.decision stop order updated
          (EnumerationExpandableIndex.frame callbackCore after))
