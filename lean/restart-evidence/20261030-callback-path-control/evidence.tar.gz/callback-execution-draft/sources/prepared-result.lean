  | callback (uv : Nat) (raw : CallbackRaw Typing)
  /-- Preparation retains its complete entry and native result, including a fault heap. -/
  | preparation (uv : Nat) (raw : Preparation)
  /-- Retain the processed alternatives and their exact edge or recursive stop. -/
  | alternatives (uv : Nat) (processed : List (Receipt width))
      (current : FoldStop (Failure width Typing) width)

variable {Typing Key : Type} {width : Nat}
local notation "Result" => HookResult (Output width Typing) (Failure width Typing) width

/-- Read only a native endpoint supplied by the actual stopped receipt. -/
def endpoint : FoldStop (Failure width Typing) width → Option (Caller width × Queries)
  | .edge current => current.bind SourcePruningEnumerationNativeBranches.advance
