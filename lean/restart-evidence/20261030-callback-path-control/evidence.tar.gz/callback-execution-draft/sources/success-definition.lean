  pure_seq := by intros; simp [Seq.seq, Functor.map, pure]
  bind_pure_comp := by intros; simp [bind, pure, Functor.map, ← List.map_eq_flatMap]
  bind_map := by intros; rfl
  pure_bind := by intros; simp [pure, bind]
  bind_assoc := by intros; exact List.flatMap_assoc

/-- A successful branch of an actual state action. Errors remain separate list entries. -/
def Success (action : EnumerateM Symbol Guard α) (before : State Symbol Guard)
    (value : α) (after : State Symbol Guard) : Prop :=
  Except.ok (value, after) ∈ ExceptT.run (action before)

/-- Binding runs each successful branch in its own stored state and retains error branches. -/
theorem run_bind (action : EnumerateM Symbol Guard α) (next : α → EnumerateM Symbol Guard β)
