namespace MicroCFTA.SourcePruningEnumerationRestart
open EnumerationState EnumerationSchedule EnumerationCorrectness
open SourcePruningRecordTypes SourcePruningEnumerationObservation SourcePruningEnumerationNodes
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
variable {Typing : Type} {width : Nat}

/-- Test the stop rule on every remaining candidate before selecting unblocked work. -/
def decision (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (metadata : Metadata Typing)
    (before : EnumerationExpandableIndex.Cached Symbol Constraint) : Option Next :=
  match stop with
  | none => some (EnumerationPureSelection.next (order metadata) before)
  | some rule =>
      let remaining := EnumerationIndexSelection.candidates before
      if !remaining.isEmpty && remaining.all (rule metadata) then none
      else some (EnumerationPureSelection.next (order metadata) before)

/-- Reject blocked work and otherwise retain the exact metadata and enumeration state. -/
def run (stop : Option (Metadata Typing → Nat → Bool))
