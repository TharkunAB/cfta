import MicroCFTA.SourcePruningEnumerationSelectedStep
import MicroCFTA.SourcePruningEnumerationSelectedContinuations
import MicroCFTA.SourcePruningEnumerationRecursive

namespace MicroCFTA.SourcePruningEnumerationPreparedRecursive
open EnumerationState InternedConstructorTemplates
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Fragment" => Fragments.Fragment Symbol
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Metadata" => SourcePruningRecordTypes.Metadata
local notation "Core" => EnumerationState.State Symbol Constraint
local notation "Receipt" => SourcePruningEnumerationSelectedEdge.Result
local notation "Fold" => SourcePruningEnumerationNativeContinuations.Result
local notation "FoldStop" => SourcePruningEnumerationNativeContinuations.Stop
local notation "HookResult" => SourcePruningEnumerationNativeContinuations.HookResult
local notation "EntryRaw" => List (Except EnumerationState.Error ((Nat × Nat × List Suspended × Node) × Core))
local notation "Output" => SourcePruningEnumerationRecursive.Output
local notation "Preparation" => EntryRaw × Option (MergedSourceComparison.Result Symbol Constraint Node)
local notation "CallbackRaw" => fun Typing => List (Except EnumerationState.Error ((Bool × Metadata Typing) × Core))

/-- Retain the exact bounded or unsupported observation that prevents continuation. -/
inductive Failure (width : Nat) (Typing : Type) : Type 1 where
  /-- The recursive budget does not permit the selected expansion. -/
  | exhausted (uv : Nat) (metadata : Metadata Typing) (before : Cached)
  /-- The actual selected prefix cannot supply a supported continuation. -/
  | selected (uv : Nat) (observed : SourcePruningEnumerationSelectedStep.Result width Typing)
  /-- The actual fragment callback does not return a singleton success. -/
  | callback (uv : Nat) (raw : CallbackRaw Typing)
