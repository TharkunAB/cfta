# Actual callback execution bridge

The source-only draft ties each worker's actual constructor callback entry to its literal false-recording recur call. Both public laws carry the original stored path predicate to that call's exact cache input. Root compilation is pending.

## Public API

The module is `SourcePruningEnumerationPathCallbackExecution.lean`, namespace `MicroCFTA.SourcePruningEnumerationPathCallbackExecution`. The two public laws are `native_false_paths_of_forecast` and `prepared_false_paths_of_forecast`. Complete headers are saved separately. Draft v1 has 107 lines, 6625 bytes, SHA256 `560cc142ee07587bc2c940bcf48ba1976b6ef9b90f64b65363cbceb6a153376c`.

Each law fixes the Invocation hook to the worker's actual `continueWith recur graph templates stop order work metadata target` closure. It retains the exact original captured state, edge list, work parameters, target, suspended constraints, callers, queries, completed fragment, and completed cache. Its forecast gates are the original guard membership, projection paths, suffix closure, original StatePaths, and inherited BucketPaths.

The callback premise is the exact complete raw list equality:

`ExceptT.run (recordTypes graph templates work metadata target (.inl fragment) after.core) = [.ok ((false, updated), callbackCore)]`.

The first conclusion is `StatePaths P (frame callbackCore after).core`. The second conclusion is the literal equation:

`continueWith recur graph templates stop order work metadata target fragment reached saved after = recur updated reached saved (frame callbackCore after) (Restart.decision stop order updated (frame callbackCore after))`.

The same updated metadata, reached caller, saved queries, framed cache, and configured stop/order decision occur on both sides. No recursive result is supplied or constrained. The recursive function is uninterpreted.

## Native and Prepared remain separate

Both workers use `SourcePruningEnumerationRecursive.Output width Typing`. Their Failure types are different. Native uses `SourcePruningEnumerationRecursive.Failure width Typing`; Prepared uses `SourcePruningEnumerationPreparedRecursive.Failure width Typing`. Each recur has the corresponding actual HookResult family. The proof does not cast between or identify the Failure types.

## Proof route

`Success` means membership in the actual raw result list. Each exact raw singleton equality supplies that membership. The checked `Invocation.recorded_paths_of_forecast` then transfers P from the original captured state and guard projections to the recorded frame. Finally, simplification of the actual worker's `continueWith` definition with the same exact raw equality selects its false branch and reduces to the literal recur equation.

The raw equality supplies both the branch membership required by the invariant law and the full singleton pattern required by continueWith. A generic pointwise success alone would not select that pattern.

No completed head receipt, representative Total, new Validity, semantic model, recursive worker postcondition, or future resource supplier is added. The Invocation already describes an observed completed head entry. The law does not request a future head completion. It proves the cache input to the current continueWith recur application. It does not prove that recur preserves P, that recur returns, or that every other recursive dispatch site has this interface. It does not prove recording existence or a sufficient work bound.

The optional true-branch equation pair is not added. The already checked any-Bool invariant proves P for successful true recordings. The required false-branch bridge is kept to two public laws.

## Scope and validation status

The continuation body cuts reuse frozen old lines 57–78 of Native and 49–70 of Prepared after full current-source hash checks. All source acquisitions have exact endpoints, source/copy hashes and byte counts in `source-scope.json`. `old-source-union.json` reports each union: Native 70/128 lines, Prepared 66/120, Restart 20/81, and Success definition 13/1276. The two broad worker unions are conservatively charged as both available nearwhole old-source acquisitions. No whole old source is acquired. No EOF-clamped read is relabelled whole. Proof-bearing displays are complete.

The checked callback invariant is reused from its frozen reviewed source. The unique production filename was absent at bootstrap. This owner changed only this owned draft directory. This owner ran no compiler, evaluator, native, Git, network, board, or repository source mutation. All earlier owned bundles remain frozen. Root owns compilation and repository integration. No Haskell change or Haskell fix was identified. The global formalization objective remains active.
