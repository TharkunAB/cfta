# Independent callback execution review

Status: accepted within the stated scope. Timestamp: 2026-10-30 02:11 CET.
Owner: `/root/earlier_stop_control`.

The review found no source or contract defect in `SourcePruningEnumerationPathCallbackExecution.lean`. The current production source has 106 lines and 6,579 bytes. Its SHA256 is `50f76d4dc5f714518b236dfd2d6664cf71fe818d5a881640fb3ed3b4702d7dbf`. The full source and both complete public headers are retained here.

## Exact contracts

Both public laws use namespace `MicroCFTA.SourcePruningEnumerationPathCallbackExecution`:

* `native_false_paths_of_forecast`, production lines 31–66.
* `prepared_false_paths_of_forecast`, production lines 69–104.

Both retain the full variable context at lines 23–28, including the three DecidableEq instances. Both use `SourcePruningEnumerationRecursive.Output width Typing`. The Native recur result uses `SourcePruningEnumerationRecursive.Failure width Typing`. The Prepared recur result uses `SourcePruningEnumerationPreparedRecursive.Failure width Typing`. The actual worker declarations confirm these separate Failure types. The proof makes no conversion between them.

The Invocation hook is the exact worker-specific closure:

```
continueWith recur graph templates stop order work metadata target
```

The law retains the captured starting cache, inherited bucket, actual edge list, caller and query endpoints, fragment, and completed cache. It takes the original projection-path predicate P, guard inclusion, suffix closure, `StatePaths P before.core`, and `BucketPaths P scs`. It does not assume P for the completed cache.

Each raw callback premise is the complete list equality:

```
ExceptT.run (recordTypes graph templates work metadata target (.inl fragment) after.core)
  = [.ok ((false, updated), callbackCore)]
```

This exact singleton supplies `Success` by unfolding its actual definition and using membership in the singleton. The proof does not replace full-list equality with a weaker existence or branch-membership premise. That distinction is required because the actual continuation matches a singleton list.

`Invocation.recorded_paths_of_forecast` then derives P for the exact framed callback state. Its checked source derives head paths from the actual Invocation and uses the existing recording-values path law. It requires no final output membership or recursive worker property.

Finally, each proof unfolds its own actual `continueWith` and substitutes the same raw singleton equation. The resulting literal call is:

```
recur updated reached saved (EnumerationExpandableIndex.frame callbackCore after)
  (SourcePruningEnumerationRestart.decision stop order updated
    (EnumerationExpandableIndex.frame callbackCore after))
```

Every argument agrees with the actual false branch: updated metadata; reached caller; saved queries; the recorded core framed into the completed cache; and the configured stop/order decision on that same metadata and frame. The graph, templates, callback work, original metadata, and target used for recording also agree with the continuation definition. Native and Prepared are checked separately.

The inspected Restart definition confirms that this remains the actual configured decision. It tests the supplied stop rule on remaining candidates and otherwise runs candidate selection with `order updated`. The new proofs do not replace that decision with another control policy.

## Scope

The conclusions establish P for the recursive call's input and an equation for that actual call. The recur function remains arbitrary. The laws assume no property of its output, and prove no property of its output, termination, fuel sufficiency, callback existence, or global coverage. The Invocation is an observed callback entry, not a supplier of future workers or future resource packets. The false singleton is an observed current recording, not an assumed future recursive result. No new model, Validity premise, or successful final-output premise occurs.

These two laws cover the specified continueWith false branches. They do not claim that all other recursive dispatch sites satisfy this interface. The true singleton and unsupported raw-list branches remain outside the new equation pair. Existing any-Bool recording path preservation is compatible with that boundary.

## Matching verification evidence

The Root execution-v1-build report records exit 0 and a successful 2,001-job build. Its full 651-byte log is retained. It contains a replayed pre-existing unused-variable warning from `InternedFreshOrdinaryClosedCompletion`; it reports no warning in this new module.

The Root execution-v1-strict report records exit 0 with `warningAsError=true` and `linter.all=true`. Its log is empty. The strict checked source, strict input snapshot, build input snapshot, current production source, and review source are byte-identical at the SHA256 above. Both reports and their raw-log hashes were independently checked. The seven recorded input-snapshot hashes in each run were also checked against the actual Root snapshots. The reports, commands, inputs, target snapshots, and strict checked source are retained under `root-evidence/`.

This reviewer ran no compiler or evaluator. The pass results are Root's matching receipts, plus independent source review.

## Acquisition and incidents

All proof-bearing displays were read in full without truncation. The old dependency cuts were reused from the execution owner's retained sources after full current-source and literal-cut checks. Their union is Native 70/128 lines, Prepared 66/120, Restart 20/81, and EnumerationCorrectness 13/1276. There are no new whole old-source acquisitions. Both broad worker unions are conservatively charged as the two available near-whole scopes. The 51-line checked CallbackInvariant and 106-line production module are whole new proof sources. They are identified separately from old dependency acquisitions.

The initial file-name discovery output was truncated: 91 lines and about 2,437 tokens at a 2,300-token limit. The discovery command was rerun to `discovery-file-list-full.txt`. It contains file names, not a proof display. No source claim depends on an omitted file name.

The first validation script incorrectly required numeric requested/actual endpoint equality for an owner entry with `requested_end: "all"` and actual end 106. The symbolic full-source request is satisfied. There was no endpoint clamp. A first status note incorrectly referred to requested end 107 by conflating the earlier 107-line draft with the 106-line production source. A correction was sent before sealing. The exact owner metadata is retained unchanged. All numerical old-source endpoints agree, and all source/copy hashes pass.

No repository source, prior frozen bundle, Git state, compiler state, network service, board, or subagent was changed. All writes are in this unique review directory. No Haskell fix or defect was found.
