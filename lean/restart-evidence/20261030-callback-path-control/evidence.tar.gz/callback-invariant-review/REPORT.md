# Actual invocation recording invariant review

The one public law composes the checked actual-invocation path law with the checked generic recording path law. The statement preserves every original head-law gate. It requires no completed receipt, representative totality, new Validity, semantic model, output-membership condition, or future worker supplier. The exact production source passes Root's build and strict checks.

## Exact statement and inputs

The public name is `MicroCFTA.SourcePruningEnumerationHookInvocation.Invocation.recorded_paths_of_forecast`. `public-header.lean` retains its complete header. Production is `SourcePruningEnumerationPathCallbackInvariant.lean`, 51 lines, 3084 bytes, SHA256 `d250a07b824de41e4a8905886889c479d433ab80430027150bdb060649dff63d`.

The theorem retains the same polymorphic hook and its Output/Reason types. It retains the exact work parameters r/n/p/h/k, target, inherited suspended constraints, captured starting cache, edge list, initial/reached callers, initial/saved queries, completed fragment, and completed cache.

Its original head-law gates are:

- An `Invocation` for those exact parameters.
- The original guard list and membership of every selected-list edge constraint in that list.
- `ProjectionPaths guards P` and suffix closure of P.
- `StatePaths P before.core` and `BucketPaths P scs`.

These inputs match `Invocation.paths_of_forecast` after only the theorem-name replacement and whitespace removal. `header-comparison.json` records the comparison. The additional inputs are an actual graph, template list, callback work, metadata, returned Bool/metadata pair, callback core, and the concrete `Success` observation for `recordTypes ... target (.inl fragment)` from `after.core`.

The conclusion is `StatePaths P (EnumerationExpandableIndex.frame callbackCore after).core`. The Bool is unrestricted. Metadata, graph, templates, and callback work need no semantic acceptance or safety gate. The result is valid for any matching successful recording configuration; no equation tying an arbitrary hook implementation to that configuration is needed for this preservation statement. A concrete worker supplies its own actual recording observation when it applies the law.

## Proof review

`invocation.paths_of_forecast guards known projected tails paths inherited` derives P at the actual completed head cache. The supporting module has SHA256 `a4e6f1ec47f18ba25e0f96e70359c4a9b06f51e0084e2a9a90bca88840776103`, 58 lines and 3583 bytes. It uses `invocation.selected` to recover the actual edge, list membership, head caller, head queries, and literal completed-head run. It then applies the existing `CapturedEdge.complete_paths` law. P comes from the original starting state, inherited suspended constraints, and original guard projections. No postpacket supplies P.

The reused frozen `Invocation` definition has a fixed `before` parameter. Its `completed` and `other` constructors pass that exact starting cache into the suffix. They can advance native caller and queries. The selected-head law permits those actual changed values. The `completed` constructor imposes no nonempty-output condition. Thus earlier unproductive completed hooks do not restrict this invariant to accepting or output-producing events.

The theorem then reduces the framed core to `callbackCore` and applies `SourcePruningEnumerationPathRecordingValues.recordTypes_paths` with `headPaths` and the actual observation. That supporting checked source has SHA256 `ca2eb71bc3c84f795e92990445f8267bc690a108c9c42b13281279239ac63f9d`. Its generic successful-recording values identity requires no total forest or completed receipt. Its source-only construction and Root failure/pass history remain in the separate frozen `recording-values-draft` bundle.

No path predicate on the recorded output is assumed. No recursive worker output, recursive completion, model, or future resource result is supplied as a premise. The law covers the successful recording stage before recursive continuation. It does not derive recording existence, a fuel bound, continuation path preservation, or global worker termination. It does not prove the guard/path gates for each initial public admission. The pending admission-wrapper additions are outside this review. The complete formalization objective remains active, including global control, both distinct recursive workers, public coverage, and Haskell correspondence.

## Root evidence and provenance

The leaf build passes 2000 jobs. The strict result exits 0 with `warningAsError=true`, `linter.all=true`, and an empty log. The production snapshot, current repository source, Root v1 production copy, both Root input-source snapshots, strict checked copy, and strict report source hash are exact. Log lengths and SHA256 values match the reports. The build replays an existing dependency warning from `InternedFreshOrdinaryClosedCompletion`; the strict target is clean. This module has no failed build result in the reviewed history.

The two supporting checked APIs are pinned. Their matching strict reports are copied. The actual invocation definition reuses the already frozen lines 38–69 of `SourcePruningEnumerationHookInvocation.lean`. Its complete current-source hash still matches that prior frozen manifest. No new old-source cut was acquired. All source endpoints, source/copy bytes and hashes, task-source status, and reuse origins are in `source-scope.json`. The whole 51-line law module and whole 58-line supporting new module are explicitly labelled new task sources.

A preliminary acquisition requested lines 10–69 of the 58-line new supporting module. The acquisition helper rejected that range before writing a cut. The subsequent acquisition explicitly requested the whole 58-line new module. No EOF-clamped cut was labelled whole. All proof-bearing displays in this review were complete.

This owner ran no compiler, evaluator, native, Git, network, or board command and changed no repository source. No Haskell change or Haskell fix was identified. No new Audit or public sweep result is claimed here. Every frozen prior owner bundle remains unchanged.

Measured completion: 2026-10-30T02:03:23+01:00
