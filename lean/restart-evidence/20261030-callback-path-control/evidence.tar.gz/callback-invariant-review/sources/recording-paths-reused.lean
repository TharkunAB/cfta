theorem recordTypes_paths {Guard Typing : Type} {P : EqualityTrie.Path → Prop}
    (graph : Graph Symbol Guard) (templates : List (Template.Pattern Symbol)) (fuel : Nat)
    (metadata : SourcePruningRecordTypes.Metadata Typing) (uv : Nat)
    (input : Sum (Fragment Symbol) Nat) (before after : State Symbol Guard)
    (result : Bool × SourcePruningRecordTypes.Metadata Typing)
    (paths : StatePaths P before)
    (success : Success (SourcePruningRecordTypes.recordTypes graph templates fuel metadata uv input)
      before result after) : StatePaths P after := by
  exact SourcePruningEnumerationPathStorage.values_paths paths
    (recordTypes_values graph templates fuel metadata uv input before after result success)
