theorem Invocation.recorded_paths_of_forecast
    {hook : Fragment → Caller width → Queries → Cached → HookResult Output Reason width}
    {checkEmpty : Bool} {r n p h k target : Nat} {scs : List Suspended} {before : Cached}
    {edges : List (EdgeValue Symbol Constraint)} {caller reached : Caller width} {queries saved : Queries}
    {fragment : Fragment} {after : Cached}
    (invocation : Invocation hook checkEmpty r n p h k target scs before edges caller queries fragment reached saved after)
    (guards : List Constraint) (known : ∀ edge ∈ edges, edge.entry.key.constraint ∈ guards)
    (projected : ProjectionPaths guards P)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (paths : StatePaths P before.core) (inherited : BucketPaths P scs)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (work : Nat) (metadata : SourcePruningRecordTypes.Metadata Typing)
    (recorded : Bool × SourcePruningRecordTypes.Metadata Typing)
    (callbackCore : EnumerationState.State Symbol Constraint)
    (observed : Success
      (SourcePruningRecordTypes.recordTypes graph templates work metadata target (.inl fragment))
      after.core recorded callbackCore) :
    StatePaths P (EnumerationExpandableIndex.frame callbackCore after).core
