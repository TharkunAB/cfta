# Original stored paths at recursive callback inputs

Full goal ACTIVE. Read final-documents/lean/notes-current-callback-path-control.md.
Audit4692/82532 and public1051/85 pass. Seven current strict sources match.
All487 prior protected and835 native/build inputs match. Baseline493 protected.
Six new modules prove13 public laws. Every actual head Invocation and successful
recording preserves the original P. Distinct Native/Prepared false continuations
receive P at the exact recur input with configured stop/order and updated metadata.
No recursive-output property is assumed. Producer alignment is unnecessary for
this path fact; Invocation.selected already supplies the actual completed run.
Original uniform bounds, sufficientD, full coverage/order/stops and Haskell
correspondence remain open. Original-path research and its62-line normalization
draft remain source-only and UNTESTED. No concrete native counterexample is claimed.
Retain all3 failed proof checks and explicit source/provenance incidents.
Every regular payload is archived without filtering. Keep this area immutable.
The archive verifier executes no Lean or Haskell code.
