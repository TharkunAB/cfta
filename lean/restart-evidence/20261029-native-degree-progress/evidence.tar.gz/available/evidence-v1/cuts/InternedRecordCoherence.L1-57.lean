import MicroCFTA.InternedConstructorTemplates

/-!
# Canonical record coherence from constructor traces

The two identity caches and the two payload tables start empty. Generated
constructor requests retain the same keys in both representations. Completed
records also retain the source child identities and metadata equations.
-/
namespace MicroCFTA.InternedRecordCoherence
open Cache InternedBinderProtocol InternedConstructorTemplates

/-- An edge payload retains its complete key and ordered child identities. -/
def EdgeFields (key : EdgeKey Symbol Guard) (edge : EdgeValue Symbol Guard) : Prop :=
  edge.entry.key = key ∧ edge.children.map Value.referenceOf = key.children

/-- Each node payload has the fields used to construct its actual cache key. -/
def NodeFields (key : NodeKey) (entry : Interned NodeKey) : Value Symbol Guard → Prop
  | .node actual edges depth free =>
      actual = entry ∧ key = .node (edges.map (fun edge => edge.entry.identity)) ∧
        depth = maximumDepth (edges.flatMap EdgeValue.children) ∧
        free = childFree (edges.flatMap EdgeValue.children)
  | .union actual members depth free =>
      actual = entry ∧ key = .union (members.map Value.referenceOf) ∧
        depth = maximumDepth members ∧ free = childFree members
  | .mu actual _ depthShape ordinaryShape =>
      actual = entry ∧ key = muKey depthShape ordinaryShape
  | .empty | .reference _ => False

/-- Stored payloads agree with canonical entries and their constructor fields. -/
structure Coherent (state : InternedConstructorTemplates.State Symbol Guard) : Prop where
  valid : InternedConstructorTemplates.Valid state
  edges : ∀ key value, state.edgeRecords key = some value →
    state.edges.table key = some value.entry ∧ EdgeFields key value
  nodes : ∀ key value, state.nodeRecords key = some value →
    ∃ entry, state.nodes.table key = some entry ∧ NodeFields key entry value

/-- Every completed identity request has a payload. Listed Mu keys may still be pending. -/
structure Covered (pending : List NodeKey) (state : InternedConstructorTemplates.State Symbol Guard) : Prop where
  edges : ∀ key entry, state.edges.table key = some entry → ∃ value, state.edgeRecords key = some value
  nodes : ∀ key entry, state.nodes.table key = some entry →
    key ∈ pending ∨ ∃ value, state.nodeRecords key = some value

/-- Both representations are coherent and complete in the empty state. -/
theorem empty_correct : Coherent (empty (Symbol := Symbol) (Guard := Guard)) ∧
    Covered [] (empty (Symbol := Symbol) (Guard := Guard)) := by
  constructor
  · refine ⟨empty_valid, ?_, ?_⟩ <;> intro key value impossible <;> cases impossible
  · constructor <;> intro key entry impossible <;> cases impossible

/-- An intern operation can only retain an old entry or install its requested entry. -/
theorem intern_cases [DecidableEq Key] (state : Cache.State Key) (key other : Key)
    (entry : Interned Key) (present : (Cache.intern state key).2.table other = some entry) :
    state.table other = some entry ∨ other = key ∧ entry = (Cache.intern state key).1 := by
  cases found : state.table key with
  | some value => exact Or.inl (by simpa [Cache.intern, found] using present)
  | none =>
