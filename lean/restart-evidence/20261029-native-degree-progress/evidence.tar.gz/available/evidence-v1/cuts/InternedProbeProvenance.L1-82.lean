import MicroCFTA.InternedFreshProbeKeys

/-!
# Probe provenance through actual constructor effects

Constructor inputs retain resident records and issued reference names.
Cache readback preserves these properties for the complete child records.
No probe-level provenance law is assumed.
-/
namespace MicroCFTA.InternedProbeProvenance
open Cache InternedBinderProtocol InternedConstructorTemplates InternedRecordCoherence InternedFreshProbeKeys

/-- All immediate records retained by a source node, including both stored Mu probes. -/
def children : Value Symbol Guard → List (Value Symbol Guard)
  | .empty | .reference _ => []
  | .node _ edges _ _ => edges.flatMap EdgeValue.children
  | .union _ members _ _ => members
  | .mu _ body depth ordinary => [body, depth, ordinary]

/-- Actual source inputs retain their resident records and earlier reference reservations recursively. -/
inductive Available (state : InternedConstructorTemplates.State Symbol Guard) : Value Symbol Guard → Prop where
  | intro (value : Value Symbol Guard) (resident : Resident state value)
      (issued : IssuedReferences state.nodes value)
      (children : ∀ child ∈ children value, Available state child) : Available state value

/-- A constructor's payload needs no independent assumption about its future parent entry. -/
def Contents (state : InternedConstructorTemplates.State Symbol Guard) (value : Value Symbol Guard) : Prop :=
  IssuedReferences state.nodes value ∧ ∀ child ∈ children value, Available state child

/-- Every complete stored record retains the same recursively available children. -/
structure Cached (state : InternedConstructorTemplates.State Symbol Guard) : Prop where
  edges : ∀ key edge, state.edgeRecords key = some edge → ∀ child ∈ edge.children, Available state child
  nodes : ∀ key value, state.nodeRecords key = some value → Available state value

/-- No cached input obligations remain in the empty constructor state. -/
theorem empty_cached : Cached (empty (Symbol := Symbol) (Guard := Guard)) := by
  constructor <;> intro key value impossible <;> cases impossible

/-- Availability exposes the exact residency needed by canonical probe-key separation. -/
theorem Available.resident (available : Available state value) : Resident state value := by
  cases available with | intro _ resident _ _ => exact resident

/-- Availability exposes actual issued-name provenance, including false or erased branches. -/
theorem Available.issued (available : Available state value) : IssuedReferences state.nodes value := by
  cases available with | intro _ _ issued _ => exact issued

/-- Each retained child is available independently of whether its parent later survives normalization. -/
theorem Available.children (available : Available state value) : ∀ child ∈ children value, Available state child := by
  cases available with | intro _ _ _ children => exact children

/-- Record growth and reservation growth preserve all recursively retained inputs. -/
theorem Available.grows (before after : InternedConstructorTemplates.State Symbol Guard)
    (growth : Grows before after) (issuedGrowth : Extends before.nodes.issued after.nodes.issued)
    (available : Available before value) : Available after value := by
  induction available with
  | intro value resident issued children ih =>
      refine .intro value (resident_grows before after growth value resident) ?_ ih
      intro identity member
      obtain ⟨key, present⟩ := issued identity member
      exact ⟨key, issuedGrowth identity key present⟩

/-- Constructor contents grow with the actual record and reservation histories. -/
theorem contents_grows (before after : InternedConstructorTemplates.State Symbol Guard)
    (growth : Grows before after) (issuedGrowth : Extends before.nodes.issued after.nodes.issued)
    (contents : Contents before value) : Contents after value := by
  constructor
  · intro identity member
    obtain ⟨key, present⟩ := contents.1 identity member
    exact ⟨key, issuedGrowth identity key present⟩
  · exact fun child member => (contents.2 child member).grows before after growth issuedGrowth

/-- Every actual generated effect preserves the node reference reservation history. -/
theorem run_issued_extends [DecidableEq (EdgeKey Symbol Guard)] (work : Work Symbol Guard Result)
    (state : InternedConstructorTemplates.State Symbol Guard) (valid : InternedConstructorTemplates.Valid state) :
    Extends state.nodes.issued (run work state).2.nodes.issued := by
  induction work generalizing state with
  | pure value => exact extends_refl _
  | edge key identify resume ih =>
      exact ih _ _ (edgeStep_correct key identify state valid).1
  | node key identify resume ih =>
      exact extends_trans (intern_issued_extends state.nodes key valid.2)
        (ih _ _ (nodeStep_correct key identify state valid).1)
