  obtain ⟨value, stored⟩ := correct.2.edges key entry present
  have record := correct.1.edges key value stored
  exact ⟨value, stored, Option.some.inj (record.1.symm.trans present), record.2⟩

/-- A finite inventory reads complete node records from the actual issued identity supply. -/
def nodeInventory (state : InternedConstructorTemplates.State Symbol Guard) : List (Value Symbol Guard) :=
  (List.range state.nodes.next).filterMap fun identity => (state.nodes.issued identity).bind state.nodeRecords

/-- Every completed node record belongs to the finite inventory derived from its actual counter. -/
theorem node_inventory_complete [DecidableEq (EdgeKey Symbol Guard)]
    (state : InternedConstructorTemplates.State Symbol Guard) (built : Constructed state)
    (key : NodeKey) (value : Value Symbol Guard) (stored : state.nodeRecords key = some value) :
    value ∈ nodeInventory state := by
