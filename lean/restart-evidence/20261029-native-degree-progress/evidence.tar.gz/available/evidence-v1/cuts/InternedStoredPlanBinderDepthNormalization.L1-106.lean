import MicroCFTA.InternedStoredPlanBinderDepthBounds

/-!
# Open stored-plan depth through actual ordinary normalization

Closed records have depth zero. Coherent ordinary nodes and unions have
the maximum open depth of their actual children. Source normalization
preserves an upper bound on this measure, including canonical cache hits.
This module does not assert progress at a recursive constructor.
-/
namespace MicroCFTA.InternedStoredPlanBinderDepth
open Cache InternedConstructorTemplates InternedRecordCoherence InternedProbeProvenance
open InternedNormalizationFree InternedEdgeResidency InternedLiveEdges
open InternedUnionSeparation InternedUnionDescendants InternedGateRank
open InternedFreshProbeKeys
open InternedBinderProtocol (NodeKey Reference)

/-- The ordered maximum is bounded exactly when every actual member is bounded. -/
theorem many_le_iff (values : List (Value Symbol Guard)) (bound : Nat) :
    manyDepth values ≤ bound ↔ ∀ value ∈ values, valueDepth value ≤ bound := by
  induction values with
  | nil => simp [manyDepth]
  | cons first rest ih => simp [manyDepth, Nat.max_le, ih]

/-- Edge depth is the ordered maximum of the original edge children. -/
theorem edges_eq_many (edges : List (EdgeValue Symbol Guard)) :
    edgesDepth edges = manyDepth (edges.flatMap EdgeValue.children) := by
  have append (first second : List (Value Symbol Guard)) :
      manyDepth (first ++ second) = max (manyDepth first) (manyDepth second) := by
    induction first with
    | nil => simp [manyDepth]
    | cons first rest ih => simp [manyDepth, ih, Nat.max_assoc]
  induction edges with
  | nil => simp [edgesDepth, manyDepth]
  | cons first rest ih => cases first; simp [edgesDepth, List.flatMap_cons, ih, append, EdgeValue.children]

/-- A closed child-free list has no open plan depth. -/
theorem many_zero_of_free (values : List (Value Symbol Guard)) (closed : childFree values = []) :
    manyDepth values = 0 := by
  apply Nat.eq_zero_of_le_zero
  apply (many_le_iff values 0).mpr
  intro value member
  have free : value.free = [] := by
    apply List.eq_nil_iff_forall_not_mem.mpr
    intro name included
    have present := (childFree_member values name).mpr ⟨value, member, included⟩
    simp [closed] at present
  rw [closed_zero value free]
  exact Nat.le_refl _

/-- A coherent ordinary record has exactly its maximum child open depth. -/
theorem node_depth (entry : Interned NodeKey) (edges : List (EdgeValue Symbol Guard))
    (depth : Nat) (free : List Reference) (state : State Symbol Guard)
    (coherent : Coherent state) (resident : Resident state (.node entry edges depth free)) :
    valueDepth (.node entry edges depth free) = edgesDepth edges := by
  rw [valueDepth.eq_def]
  split
  · rename_i closed
    have exactFree := node_free state coherent entry edges depth free resident
    rw [edges_eq_many, many_zero_of_free _ (exactFree.symm.trans (List.isEmpty_iff.mp closed))]
  · rfl

/-- A coherent union has exactly its maximum member open depth. -/
theorem union_depth (entry : Interned NodeKey) (members : List (Value Symbol Guard))
    (depth : Nat) (free : List Reference) (state : State Symbol Guard)
    (coherent : Coherent state) (resident : Resident state (.union entry members depth free)) :
    valueDepth (.union entry members depth free) = manyDepth members := by
  rw [valueDepth.eq_def]
  split
  · rename_i closed
    have exactFree := union_free state coherent entry members depth free resident
    rw [many_zero_of_free _ (exactFree.symm.trans (List.isEmpty_iff.mp closed))]
  · rfl

/-- Actual ordinary and union children inherit the parent's open-depth bound. -/
theorem ordinary_child_le (value child : Value Symbol Guard) (state : State Symbol Guard)
    (coherent : Coherent state) (available : Available state value)
    (ordinary : ∀ entry body depth probe, value ≠ .mu entry body depth probe)
    (member : child ∈ semanticChildren value) : valueDepth child ≤ valueDepth value := by
  cases value with
  | empty | reference => simp [semanticChildren] at member
  | mu entry body depth probe => exact False.elim (ordinary entry body depth probe rfl)
  | node entry edges depth free =>
      rw [node_depth entry edges depth free state coherent available.resident, edges_eq_many]
      exact (many_le_iff _ _).mp (Nat.le_refl _) child member
  | union entry members depth free =>
      rw [union_depth entry members depth free state coherent available.resident]
      exact (many_le_iff _ _).mp (Nat.le_refl _) child member

/-- Actual ordinary construction preserves the open-depth bound of its original children. -/
theorem makeNode_le [DecidableEq (EdgeKey Symbol Guard)] (edges : List (EdgeValue Symbol Guard))
    (state : State Symbol Guard) (coherent : Coherent state) (linked : Linked state)
    (resident : ∀ edge ∈ edges, EdgeResident state edge) (bound : Nat)
    (bounded : ∀ child ∈ edges.flatMap EdgeValue.children, valueDepth child ≤ bound) :
    valueDepth (run (makeNode edges) state).1 ≤ bound := by
  have selected : ∀ edge ∈ canonicalEdges (surviving edges), EdgeResident state edge :=
    fun edge member => resident edge (List.mem_filter.mp (canonicalEdges_member _ edge member)).1
  have selectedDepth : ∀ child ∈ (canonicalEdges (surviving edges)).flatMap EdgeValue.children,
      valueDepth child ≤ bound := by
    intro child member
    obtain ⟨edge, included, found⟩ := List.mem_flatMap.mp member
    exact bounded child (List.mem_flatMap.mpr
      ⟨edge, (List.mem_filter.mp (canonicalEdges_member _ edge included)).1, found⟩)
  unfold makeNode
  dsimp only
  split
