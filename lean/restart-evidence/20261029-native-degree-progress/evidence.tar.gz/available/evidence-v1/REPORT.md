# Original available operands below the native Mu degree limit

Status: UNTESTED SOURCE-ONLY CANDIDATE v1. Root owns compilation and repository changes.

One module: InternedMuDepthAvailableBounds.lean. Two theorems. No new predicate or definition.

## Result and exact inputs

InternedMuDepthAvailableBounds.value_le takes, in order:

1. state : InternedConstructorTemplates.State Symbol Guard.
2. limit : Nat.
3. bounded : InternedMuDepthInventory.Bounded state limit.
4. value : InternedConstructorTemplates.Value Symbol Guard.
5. available : InternedProbeProvenance.Available state value.

It concludes InternedStoredPlanBinderDepth.valueDepth value <= limit.
Symbol and Guard are arbitrary types. No DecidableEq instance is needed.
The theorem is stronger than the requested Facts/Coherent version: neither is needed once
actual recursive Available and the existing original-state Bounded are supplied.
No future result, future body bound or custom supplier is an input.

initial_value_le takes original state, InternedNestedFacts.Facts state, original value and
Available state value. It derives the concrete finite original limit:

valueDepth value <= maximumDepth (InternedRecordCoherence.nodeInventory state) + 1.

This corollary uses the existing InternedMuDepthInventory.initial_bounded. Facts supplies
that actual source inventory bound; it is not an assumption about a future result.
The two exact complete public signatures and their type context are retained in public/.

## Actual proof

Induction is on the existing Available evidence. Its constructor supplies exact Resident
storage and an induction hypothesis for each actual retained child. Closed values have
valueDepth zero. Empty and reference values also have zero depth.

An open node contributes edgesDepth. Existing edges_eq_many and many_le_iff propagate the
same limit from the actual edge children. An open union contributes manyDepth and uses
the same exact maximum lemma for its actual members. No coherence-based cached-depth
identity is needed for either upper bound.

For a Mu, actual Resident yields the literal nodeRecords entry.key lookup of that complete
Mu payload. Existing Bounded gives valueDepth body < limit at exactly this lookup. The open
Mu contributes 1 + valueDepth body, which is therefore <= limit. No induction hypothesis
about a later body is used. A closed Mu follows the zero case.

The proof preserves the meaning of Bounded: it bounds complete resident Mu BODY depths
strictly. It does not replace Bounded by a new all-values invariant. The conclusion concerns
the actual executable open-plan valueDepth, not cached Value.depth.

## Existing theorem check and scope

The source search found value_le_cached and value_le_ordinaryLevel. Those conclude a bound
by the operand's cached depth or ordinary level. They do not provide the common original
Mu-inventory limit. Existing normalization maxima lemmas are reused. No exact existing
Available plus InternedMuDepthInventory.Bounded to fixed-limit theorem was found.

This is the original-operand base requested for the joint return bound. It does not prove
joint return preservation, construction termination, source-depth completeness or an upper
bound for an arbitrary future result. The same state occurs in Available and Bounded.

## Evidence and validation

No compiler, Lean/lake evaluator, native evaluator, Git, network, board or repository edit ran.
No Haskell change or fix occurred. No axiom, sorry, admit, native_decide, budget change or
linter suppression was added. Candidate v1 remains immutable and untested here.
There is no failed local proof draft. Any later root-side failure or repair must retain v1.

Three whole Lean input sources were requested, below the limit of eight. Two were fully
reviewed. The Mu inventory output omitted part of an unrelated later count proof; its used
Bounded/initial_bounded region was read completely. All three whole input identities are
retained. Other inputs are preserved only as exact partial read cuts and hashes. This avoids
new whole-source reads just for evidence. Broad searches were line searches, not whole
source reviews. Their unrelated or truncated matches are not claimed as reviewed proofs.

Root reported main e2185ede7 merged at d53d37dfc, with only the HugeLists example changed.
The child did not run Git. manifest.json distinguishes that reported base from measured
source identities. All earlier evidence areas remain unchanged.
