import MicroCFTA.SourcePruningEnumerationPreparedDiagnosticSiblingResources
import MicroCFTA.SourcePruningEnumerationPreparedFiniteSiblingResources
import MicroCFTA.SourcePruningEnumerationPreparedOutcomeResources

/-!
# Diagnostic ancestry at the actual prepared fold finish

The actual scan retains every processed receipt.
Its exact finished outcome retains all stopped diagnostic caches.
-/
namespace MicroCFTA.SourcePruningEnumerationPreparedFiniteSiblingResources
open EnumerationState EnumerationSchedule InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes
open SourceCurrentAllocatedNativeInventoryState (Inventory)
open SourceCurrentAllocatedPartialInvariant (Post)
open SourceCurrentConstrainedCapGeneratedQueryResources (Fits)
open SourcePruningEnumerationIncomingReservation (Seed)
open SourcePruningEnumerationPreparedReservation (stage ScanReserved)
open SourcePruningEnumerationRecursive (Packet Output)
open SourcePruningEnumerationPreparedRecursive (Failure continueWith resume endpoint ReceiptAncestry OutcomeDiagnosticAncestry)
attribute [local irreducible] SourcePruningEnumerationPreparedReservation.step
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Receipt" => SourcePruningEnumerationSelectedEdge.Result
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
local notation "Result" => SourcePruningEnumerationNativeContinuations.Result
local notation "HookResult" => SourcePruningEnumerationNativeContinuations.HookResult
local notation "afterHead" => SourcePruningEnumerationRecursiveReservation.afterHead
local notation "afterHook" => SourcePruningEnumerationPreparedReservation.step
local notation "advance" => SourcePruningEnumerationNativeBranches.advance
local notation "suspendedBound" => SourcePruningEnumerationPrefixAdmission.suspendedBound
variable {Typing Key : Type} {bits : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

/-- Retain the complete sibling result and resources for its exact finished outcome. -/
theorem alternatives_finite_finish_resources_with_diagnostics
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (SourcePruningRecordTypes.Metadata Typing → Nat → Bool))
    (order : SourcePruningRecordTypes.Metadata Typing → List Nat → Option Nat)
    (metadata : SourcePruningRecordTypes.Metadata Typing)
    (recursiveFuel : Nat)
    (seed : Seed) (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    (recursive : SourcePruningEnumerationPreparedRecursive.CompleteWithDiagnosticAncestry (bits := bits) holeKey fits admits graph templates
      checkEmpty edgesOf stop order formulas solver recursiveFuel)
    (inventory : Inventory)
    (caller : Caller (bits + 2)) (memos : Memos) (before : Cached) (uv handle : Nat) (scs : List Suspended)
    (parentEntry : Cache.Interned InternedBinderProtocol.NodeKey)
    (storedEdges selectedEdges : List (EdgeValue Symbol Constraint))
    (depth : Nat) (free : List InternedBinderProtocol.Reference)
    (packet : Packet formulas solver inventory caller memos metadata before)
    (ready : EnumerationDriver.Ready uv before.core)
    (stored : before.core.values[uv]? = some (.unenumerated (some handle) scs))
    (parentAvailable : Available caller.checked.native.machine.heap (.node parentEntry storedEdges depth free))
    (parentClosed : free = [])
    (selected : ∀ edge ∈ selectedEdges, edge ∈ storedEdges)
    (incoming : EnumerationReferences.IncomingAvoid uv before.core)
    (bounded : Fits seed.2 caller.checked)
    (known : Heap (fun guard => guard ∈ seed.1) caller.checked.native.machine.heap)
    (selectionMembers : ∀ entry rows depth free, ∀ edge ∈ edgesOf (.node entry rows depth free), edge ∈ rows)
    (selectionLength : ∀ entry rows depth free, (edgesOf (.node entry rows depth free)).length ≤ rows.length)
    (capturedMass inherited : Nat) (initialMass : suspendedBound before.core ≤ capturedMass)
    (inheritedLength : scs.length ≤ inherited)
    (reserved : ScanReserved bits recursiveFuel seed capturedMass inherited selectedEdges.length) :
    ∃ (bound : Nat) (processed : List (Receipt (bits + 2))) (outputs : List (Output (bits + 2) Typing))
      (afterCaller : Caller (bits + 2)) (next : Inventory) (final : Memos)
      (result : Result (Output (bits + 2) Typing) (Failure (bits + 2) Typing) (bits + 2)),
      (∀ extra, SourcePruningEnumerationNativeContinuations.run
        (continueWith (resume holeKey fits admits graph templates checkEmpty edgesOf stop order (bound + extra) recursiveFuel)
          graph templates stop order (bound + extra) metadata uv)
        checkEmpty (bound + extra) (bound + extra) (bound + extra) (bound + extra) (bound + extra)
        uv scs before selectedEdges caller memos.query = result) ∧
      Post formulas solver next caller afterCaller final ∧
      Packet formulas solver next afterCaller final metadata before ∧
      Fits (stage recursiveFuel seed capturedMass inherited selectedEdges.length).2 afterCaller.checked ∧
      Heap (fun guard => guard ∈ (stage recursiveFuel seed capturedMass inherited selectedEdges.length).1)
        afterCaller.checked.native.machine.heap ∧
      processed.length ≤ selectedEdges.length ∧
      (∀ index receipt, processed[index]? = some receipt →
        ReceiptAt recursiveFuel formulas solver caller before uv seed scs capturedMass inherited index receipt) ∧
      (∀ output ∈ outputs, ∃ index, index < selectedEdges.length ∧
        OutputAt recursiveFuel formulas solver caller seed capturedMass inherited index output) ∧
      (result = .complete processed outputs afterCaller final.query ∨
        ∃ current, result = .stopped processed outputs current ∧
          (endpoint current = none ∨ endpoint current = some (afterCaller, final.query)) ∧
          StoppedAt recursiveFuel formulas solver caller before uv seed scs capturedMass inherited processed.length outputs current) ∧
      SourcePruningEnumerationPreparedRecursive.OutcomeResources formulas solver caller
        (stage recursiveFuel seed capturedMass inherited selectedEdges.length)
        (SourcePruningEnumerationPreparedRecursive.finish uv result) ∧
      (∀ receipt ∈ processed, ReceiptAncestry before.core receipt) ∧
      OutcomeDiagnosticAncestry before.core (SourcePruningEnumerationPreparedRecursive.finish uv result) := by
  obtain ⟨bound, processed, outputs, afterCaller, next, final, result,
    observed, post, captured, afterFits, afterKnown, processedLength, receipts, outputCertificates, shape, receiptRetention, diagnostics⟩ :=
    alternatives_finite_complete_resources_with_diagnostics holeKey fits admits graph templates checkEmpty edgesOf stop order metadata recursiveFuel
      seed formulas solver recursive inventory caller memos before uv handle scs parentEntry storedEdges selectedEdges depth free
      packet ready stored parentAvailable parentClosed selected incoming bounded known selectionMembers selectionLength
      capturedMass inherited initialMass inheritedLength reserved
  have outputResources : ∀ output ∈ outputs,
      SourcePruningEnumerationRecursive.OutputResources formulas solver caller
        (stage recursiveFuel seed capturedMass inherited selectedEdges.length) output := by
    intro output member
    obtain ⟨index, inside, certificate⟩ := outputCertificates output member
    have own : SourcePruningEnumerationRecursive.OutputResources formulas solver caller
        (stage recursiveFuel seed capturedMass inherited (index + 1)) output := certificate
    have growth := SourcePruningEnumerationPreparedReservation.count_mono recursiveFuel seed capturedMass inherited
      (by omega : index + 1 ≤ selectedEdges.length)
    exact own.mono growth.1 growth.2
  have actualShape : result = .complete processed outputs afterCaller final.query ∨
      ∃ current, result = .stopped processed outputs current ∧
        (endpoint current = none ∨ endpoint current = some (afterCaller, final.query)) := by
    rcases shape with completed | ⟨current, stopped, observedEndpoint, _certificate⟩
    · exact .inl completed
    · exact .inr ⟨current, stopped, observedEndpoint⟩
  have finished := SourcePruningEnumerationPreparedRecursive.finish_resources_general
    formulas solver caller uv (stage recursiveFuel seed capturedMass inherited selectedEdges.length)
    processed outputs afterCaller next final result post afterFits afterKnown outputResources actualShape
  have finishedDiagnostics : OutcomeDiagnosticAncestry before.core
      (SourcePruningEnumerationPreparedRecursive.finish uv result) := by
    cases result <;> exact diagnostics
  exact ⟨bound, processed, outputs, afterCaller, next, final, result,
    observed, post, captured, afterFits, afterKnown, processedLength, receipts, outputCertificates, shape, finished, receiptRetention, finishedDiagnostics⟩

end MicroCFTA.SourcePruningEnumerationPreparedFiniteSiblingResources
