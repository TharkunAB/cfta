# Exact next joint kernel induction statements

Status: COMPLETE PROPOSED STATEMENTS. UNPROVED and unelaborated.
These statements introduce no predicate or induction-supplier contract.

Open the namespaces already used in CompileNodeBounds:
Cache, InternedConstructorTemplates, InternedProbeProvenance,
SourceRecursiveIntersectionThunks, SourceRecursiveIntersectionCode,
SourceRecursiveIntersectionInputView, SourceRecursiveIntersectionNative,
IntersectSchedule, InternedStoredPlanBinderDepth.
Open SourceRecursiveIntersectionSemanticHeap (SemanticHeap).

```lean
-- PROPOSED; no proof/axiom declaration is installed.
theorem kernel_node_result_degree
    {Symbol Guard : Type}
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (source : InternedConstructorTemplates.State Symbol Guard)
    (facts : InternedNestedFacts.Facts source) (limit : Nat)
    (bounded : InternedMuDepthInventory.Bounded source limit)
    (holds : Guard → Language.Term Symbol → Bool)
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (request : NodeRequest Symbol Guard) (scope : NodeScope source request)
    (complete : Completes (view source holds) (nodeSemantic request))
    (state after : SourceRecursiveIntersectionKernel.Machine Symbol Guard)
    (valid : SourceRecursiveIntersectionKernel.Valid state)
    (ready : NodeReady state request)
    (growth : Grows source state.heap)
    (history : Extends source.nodes.issued state.heap.nodes.issued)
    (semantic : SemanticHeap state.heap)
    (opened : InternedOpenDepthReadback.Heap state.heap)
    (fuel : Nat) (value : Value Symbol Guard)
    (done : SourceRecursiveIntersectionKernel.execute emptyGuard conjoin fuel
      request.domain request.left request.right state = .done value after) :
    SemanticHeap after.heap ∧ InternedOpenDepthReadback.Heap after.heap ∧
      valueDepth value ≤ limit + requiredFuel (view source holds) (nodeSemantic request) complete

theorem kernel_edge_result_degree
    {Symbol Guard : Type}
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (source : InternedConstructorTemplates.State Symbol Guard)
    (facts : InternedNestedFacts.Facts source) (limit : Nat)
    (bounded : InternedMuDepthInventory.Bounded source limit)
    (holds : Guard → Language.Term Symbol → Bool)
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (request : EdgeRequest Symbol Guard) (scope : SourceRecursiveIntersectionCode.EdgeScope source request)
    (complete : Completes (view source holds) (edgeSemantic holds request))
    (state after : SourceRecursiveIntersectionKernel.Machine Symbol Guard)
    (valid : SourceRecursiveIntersectionKernel.Valid state)
    (ready : EdgeReady state request)
    (growth : Grows source state.heap)
    (history : Extends source.nodes.issued state.heap.nodes.issued)
    (semantic : SemanticHeap state.heap)
    (opened : InternedOpenDepthReadback.Heap state.heap)
    (fuel : Nat) (value : EdgeValue Symbol Guard)
    (done : SourceRecursiveIntersectionKernel.edge emptyGuard conjoin
      (SourceRecursiveIntersectionKernel.execute emptyGuard conjoin fuel request.domain)
      request.left request.right state = .done value after) :
    SemanticHeap after.heap ∧ InternedOpenDepthReadback.Heap after.heap ∧
      manyDepth value.children ≤ limit + requiredFuel (view source holds) (edgeSemantic holds request) complete
```

Use strong induction on the NATURAL VALUE of requiredFuel. Quantify BOTH node
and edge clauses at rank R, all runtime fuels, requests and current machines.
The original source, its Facts and Bounded limit remain fixed. Induction
hypotheses are strictly smaller semantic ranks, not future-return suppliers.
Runtime fuel zero contradicts node done. Runtime fuel successor reveals the
actual selected branch. Edge mismatch does not invoke the child call.

The returned OpenDepth heap is essential. Existing execute_scoped returns the
semantic heap but not that separate heap. Ordered earlier child completions
supply the next child's current opened input through THIS same joint induction.
Local OpenDepthEffects close actual edge/node/union and optionalBinder effects.
No separate assumed future-heap family is needed. Existing execute_checked and
edge_checked supply validity, availability and actual source/issued growth.

For the ready cases, do not substitute the original root's runtime fuel or demand
a memo result already below the desired degree. The existing replay theorem
provides SOME actual kernel fuel at the CURRENT machine and the exact value.
Apply the arbitrary-fuel clause above at that supplied fuel. Request identity
is already derived by the checked native keys; it is not a new premise equating
foreign source requests. Current heap Bounded limit is NEVER a premise.

Root is implementing MaybeMu.result_le under actual current Context/cached/open
heaps and Available generated body. It concludes returned degree ≤body degree+1.
The Mu child IH, with semantic F<R, then gives body degree ≤limit+F, hence body
<limit+R and optional result ≤limit+R. That local body inequality is DERIVED by
IH; it is not supplied to either public kernel statement above.
