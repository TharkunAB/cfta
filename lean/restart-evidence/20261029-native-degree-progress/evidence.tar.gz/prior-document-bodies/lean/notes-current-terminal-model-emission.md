# Verified output and diagnostic ancestry: 2026-10-29 02:30 CET

Source `49169700142d3f587e64ffe4398616e4aba33e90` is pushed on formalize.
The full goal remains ACTIVE. Read `lean/notes-current-diagnostic-ancestry-progress.md`.
Every earlier document byte follows unchanged as a dated checkpoint.

For every finite recursive capacity, the original resource contracts give a
sufficient work bound and a stable actual result. The SAME old bound/outcome
retains all resource fields and every admitted output history. Emitted outputs
and concrete Cached payloads in returned stop diagnostics retain all original
recursion keys at the SAME RAW SLOT. This includes nested failures and runs
with no output. No original gate or future-retention supplier is added.
This is membership retention, not a strict rank or sufficient recursive depth.

Fourteen additive modules contain 23 public theorems and five concrete Prop
definitions: 2,225 lines/153,422 bytes. All 15 final strict sources pass.
Audit checks 82,040 theorem dependencies in 4,613 jobs. Actual compiler matrix:
33 PASS/four retained failed drafts, all serial measured 4 GiB and zero swap.
Public readback: 856 theorem checks/axiom lists, 73 definition bodies,
3,609,022 bytes. The old 3,473,780 bytes are an exact prefix. All 135,242
new bytes and the separate 2,392-byte generated recursive body were read.
All 4,598 old non-Audit Lean, 447 stronger and 821 Haskell/Cabal identities
retain hashes. No old runtime/proof body changes. No linter suppression.

Strongest semantics remains conditional checked rendered soundness under the
semantic/resource contracts, fixed PCS and whole-Discharged. Greater recursive
capacity retains ordered output prefixes. DONE does not imply Discharged.
Configured stop can emit partial results. Whole-language completeness is open.

Next: prove an original-input bound for actual generated native returns,
ordered child returns, optionalBinder construction and memo provenance.
Semantic completion for original closed-root requests is ALREADY derived by
initial_complete. CodeBounds.Below does not bound generated callback syntax.
The source-only next-rank proposal is UNPROVED. Per-query bounds on growing
heaps do not establish a fixed global rank. Nonterminal chosen-model emission,
sufficient recursive depth, policy/origin/public API and Haskell correspondence
remain open. Preserve the exact scope of all earlier counterexamples.

No Haskell change/check/new defect here. FINDINGS retains serialization repair
`c15021ce706ef560b6c0ab335ceed1a4b67ba4aa` for external pickup. Both parser branches
now reject strict-prefix path classes before toPathTrie. Main `63aae675c` lacks
that repair. The current note includes the lawful codec and exact reproduction.
Board 725 has exact readback. Evidence:
`lean/restart-evidence/20261029-diagnostic-ancestry-progress/`.
Preserve all frozen areas. Use new writable paths. Refresh upstream.
Normal formalize pushes remain explicitly authorized. Continue the full goal.

---

# Verified recursive output ancestry: 2026-10-29 01:42 CET

Source `bd75ee348c17f4946fadb5c5a676bf7252180725` is pushed and verified on formalize.
The full goal remains ACTIVE. Read `lean/notes-current-recursive-ancestry-progress.md`.
Earlier document bodies follow unchanged as dated checkpoints.

For each finite recursive capacity, the original resource contracts give a
sufficient work bound and a stable actual result. Every emitted output retains
all original recursion keys at the SAME RAW SLOT, including outputs before a
stop. The theorem keeps all prior resources and admitted histories. It adds no
new input gate or future-retention supplier. Stopped diagnostic caches remain
outside this output theorem. It proves no sufficient recursive depth.

Four additive modules contain six public theorems and four private helpers:
587 lines/35,942 bytes. All five final strict sources pass. Audit checks 81,980
theorem dependencies in 4,599 jobs. All 11 compiler commands pass at serial
measured 4 GiB and zero swap. Public readback: 833 theorem checks/axiom lists,
68 definition bodies, 3,473,780 bytes. The prior 3,454,104 bytes are an exact
prefix. All 19,676 new bytes were read. All 4,594 old non-Audit Lean sources,
443 stronger sources and 821 integrated Haskell/Cabal identities retain hashes.

Strongest semantics remains conditional checked rendered soundness under the
semantic/resource contracts, fixed-PCS and whole-Discharged. Greater recursive
depth retains the ordered output prefix. Native generated-family/rank,
nonterminal chosen-model emission and original-input sufficient recursive depth
remain the main gaps. Complete policies/origin/public API and physical Haskell
correspondence remain open. DONE does not imply Discharged. Configured stop
can emit partial results.

No Haskell change, new Haskell defect or Haskell check occurred here. The parser
repair `c15021ce706ef560b6c0ab335ceed1a4b67ba4aa` and its exact reproduction remain
in FINDINGS for external pickup. Main remains `63aae675c` and lacks that repair.
Board 720 records this checked proof result with exact readback.
Evidence: `lean/restart-evidence/20261029-recursive-ancestry-progress/`.
Next: extend the closed finite-depth producer to actual stopped diagnostic
caches. Per-output ResourceHistory alone is insufficient when no output exists.
Preserve frozen evidence and counterexamples. Use a new writable area.
Refresh upstream. Normal formalize pushes remain explicitly authorized.
Continue the full objective without asking whether to continue.

---

# Verified prepared ancestry and serialization repair: 2026-10-29 01:15 CET

Source `5eb88a239b05ee6ede5acb296b64ee0fe8616f02` is pushed and verified on formalize. Full goal ACTIVE.
Read `lean/notes-current-prepared-ancestry-progress.md` for contracts and next work.
Every earlier document byte follows unchanged.

Actual storage, terminal assimilation, child traversal and prepared heads retain
every old recursion key at every SAME RAW SLOT. This includes stale keys at the
fresh counter. Exact expansion history stays equal where retained; captured
completion clears it. A fixed-slot, fixed-handle unused-shape budget cannot
increase. This does not compare different representatives or sibling inputs.
The whole recursive output and attached-stop composition remains open.

Strongest semantics remains conditional checked rendered soundness under the
semantic/resource contracts, fixed-PCS and whole-Discharged, with ordered output
prefix retention at greater depth. Native generated-family/rank, nonterminal
chosen-model emission and original-input sufficient depth remain the main gaps.
Complete policies/origin/public API and physical Haskell correspondence remain.
DONE does not imply Discharged. A configured stop can emit partial outputs.

Eleven modules: 33 public theorems, one retention predicate, six private helpers,
1,295 lines/70,783 bytes. All 12 final strict sources pass. Audit: 4,595 jobs and
81,958 theorem dependencies. Compiler: 28 commands, 25 PASS, three preserved
draft FAIL. Native: five commands, four PASS, one preserved linker environment
FAIL. One wrapper argument error ran no compiler. All jobs remain serial at
measured 4 GiB and zero swap. Public: 827 theorem checks/axiom lists, 68 definition
bodies, 3,454,104 bytes. Prior 3,408,116 bytes are an exact prefix; all 45,988 new
bytes were read. All 4,583 prior non-Audit Lean and 432 stronger sources retain
their hashes. All 817 inherited Haskell/Cabal identities retain their hashes.

Main PR188 is integrated at e216346905cfeb0b243799138b4c254a739de0aa.
Parser repair c15021ce706ef560b6c0ab335ceed1a4b67ba4aa is pushed on formalize.
Four strict-prefix equality inputs threw toPathTrie exceptions. They now return
Left. Four valid controls still return graphs. Existing suite: 19 examples,
zero failures with -Werror. Fourmolu, Cabal-gild, HLint and package metadata pass.
The repair changes two of 821 integrated Haskell/Cabal identities; 819 retain
their hashes. FINDINGS has the exact codec, input, cause and external pickup.

Next: all-tag valid-prefix ancestry, actual opaque-cache ancestry, Entry and
SelectedHistoryReceipt composition. ResourceHistory can then give output-only
retention. Attached stopped caches need an actual diagnostic-cache relation and
a stronger closed finite-depth proof. The source-only worker-next report gives
the exact route. Its proposed interfaces are not installed or checked theorems.

Evidence: `lean/restart-evidence/20261029-prepared-ancestry-progress/`.
Current note: `lean/notes-current-prepared-ancestry-progress.md`.
Board 718: `3298f7df-3880-44f5-ae98-fbe1bd4ff7fb`, exact verified readback.
Preserve frozen evidence and old counterexamples. Use a new writable area.
Refresh upstream. Normal formalize pushes remain explicitly authorized.
Continue the full objective without asking whether to continue.

---

# Verified actual boundary entry progress — 2026-10-29 00:31 CET

Source `c7da675e2afe3779d62d0b3b00467db2985cbdd6` is pushed and verified on formalize. Full goal ACTIVE.
Read `lean/notes-current-boundary-entry-progress.md` for exact contracts and next work.
Every earlier document byte follows unchanged.

The actual narrowed boundary prefix retains its checked handle, native caller,
metadata and both indexes. It derives the same fresh key and original Packet.
That Packet constructs completed Entry and native preparation at a local bound.
Entry inserts the checked key into expansionAncestry. Its unused original-model
shape budget strictly decreases from the ORIGINAL target recursion history.
Direct child allocation inherits this decrease at the SAME CHECKED handle.
Per-slot ancestry is unchanged by Entry. A child's own native handle may differ.
The original-packet producer derives prefix validity and its sufficient bound.
No future model, freshness, key membership or Entry success supplier is added.
The actual supported reached boundary observation remains explicit.

Strongest system semantics remains conditional checked rendered soundness under
fixed-PCS/whole-Discharged and ordered output-prefix retention at greater depth.
The previous actual terminal emission theorem remains. Native generated boundary
closure/rank, nonterminal chosen-model emission and original-source sufficient
recursive depth across earlier callbacks remain open. DONE does not imply
Discharged. Complete policy/origin/public API and Haskell correspondence remain.

Four modules/seven public theorems: 580 lines/37,367 bytes; no new definitions or
private proof helpers. All five final strict sources pass. Audit: 4,584 jobs and
81,886 theorem dependencies. Compiler matrix: 19 commands, 14 PASS, five preserved
FAIL; all final inputs pass at serial measured 4 GiB and zero swap. Public:
794 theorem checks/axiom lists,67 definition bodies,3,408,116 bytes SHA256
5fbeccbfcc8cbc35107512f25694593b0e38585c34b3ee4968f6afe30cf06216.
Prior 3,376,571 bytes are an exact prefix; all 31,545 new bytes were read.
All 4,579 old non-Audit Lean,428 stronger-source and817 Haskell/Cabal identities
remain. Three source-scope manifests verify 95 artifact identities.

No Haskell source changed. No Haskell check ran. No new Haskell defect/fix was
established. FINDINGS retains earlier external repair records. Source-only
native audit identifies the missing generated callback body degree bound.
Existing OpenBodyBoundary refutes first-order preparation at an actual native
site; native_returned observes NodeRef.mu 26 only. It is no divergence or original
ceiling counterexample. Existing NoNewMu/cached-depth counterexample remains.

Evidence: `lean/restart-evidence/20261029-boundary-entry-progress/`.
Board 716: `a7139029-491a-484d-a1ae-32b612ba728e`, exact verified author/content/metadata.
Keep frozen evidence immutable. Use a new writable area and refresh upstream.
Compiler/native jobs remain serial at 4 GiB. Normal formalize pushes remain
explicitly authorized. The full objective is incomplete and stays ACTIVE.

---

# Actual terminal callback emission and checked boundary budgets

Checked at 2026-10-29 00:03 CET. Source `5138ade52fc76ed80bb88ed15ef62d95b1695c83` on formalize.
The full formalization goal remains ACTIVE and incomplete.

## Current strongest claim

The Lean model of the optimized interned core has conditional checked rendered
soundness under its semantic/resource contracts, fixed-PCS and whole-Discharged.
Increasing recursive depth retains the existing ordered output prefix. The
finite prepared worker retains its actual resources and histories, canonical and
proper storage, arity and physical projection under its original input gates.
Those results do not assert that a chosen model is eventually emitted.

This checkpoint constructs an actual emitted cache for the terminal recording
case. It also derives actual local boundary retention and a finite shape budget
at one native handle. General recursive chosen-model emission, source-derived
sufficient depth and Haskell correspondence remain open. Configured stop can
emit a partial output. DONE does not imply Discharged.

## Actual terminal emission

`PreparedRecursive.callback_no_candidates_emits_models` starts with ORIGINAL
Packet, allocated fragment, empty original candidate list, original Satisfies,
fragment self-fill, pending Refutes and template/program policies. It constructs
one callback work bound, updated metadata and actual returned core. It retains
Packet, RenderStable, Frame, all original metadata equalities, the SAME assignment
model and pending refutation at the framed cache.

At every greater work fuel, the actual Left recordTypes call is exactly one
successful non-rejecting result. At EVERY recursive depth, the actual prepared
continueWith/resume call is exactly a complete singleton output with metadata
none, that framed cache, the original caller and original query memo. The proof
derives the actual done decision from the empty ORIGINAL candidate list and the
recording frame. It supplies no actual callback equation, future output/model,
recursive-success hypothesis or restart-decision supplier as an input.

The old core callback producer supplies actual recording and its bound. The
proof discards its nominal old continuation equation and reduces the actual
prepared worker. It does not cast an old worker into a new one. The result does
not establish Discharged, whole chosen-term rendering, or the nonterminal case.
It does not imply that an arbitrary accepted head leaves no candidates.

## Original Mu degree ceiling

`SelectedValue.run_mu_bounded` takes original SemanticReady, Available, closedness,
Bounded before limit and the literal completed selected-value observation. It
proves Bounded after with the SAME ORIGINAL limit. Actual Mu unfolding derives
Lower internally. Actual Union exposure retains the ceiling and its final
ordinary makeNode adds no Mu. Other completed value cases retain the heap.
No later bound, Lower or inventory membership is assumed.

The degree is the stored Mu body's structural degree. It differs from the
cached Value.depth. The existing initial_bounded theorem can derive an original
ceiling from an original heap. This local theorem does not prove that the same
ceiling survives all later native conjunction/query allocation. A degree ceiling
also does not bound the number of distinct lower-degree Mu identities.

## Actual boundary retention and finite shape budget

`RecursionOrder.checkRepeated_false_fresh` derives an actual representative
success and absence of the exact checked key in that returned representative's
recursion ancestry. Inputs are literal decoded boundary and successful false
check observations. Total, Ready, a model and key absence are not inputs.

`NativeView.narrowAt_done_ordinary` derives Ordinary for ANY literal successful
narrowAt observation from ORIGINAL Ready, Available and closedness. It lifts the
actual cold read and the original constructive producer to a common summed fuel.
Their actual result and heap identities agree. It does not assume a later heap
invariant or an ordinary-result supplier.

`OuterNarrow.narrow_boundary_retained` uses that observed theorem. Actual fallback
narrowing produces only empty or ordinary nodes. Therefore an ACTUAL Mu/Union
result must use the original retention branch. Its full value and heap equal
the original input. `Action.prepare_boundary_retained` then derives the identity
enumeration action from the ORIGINAL encoded handle. It does not assume equality
of a later handle. Generic old/new handle change alone is not an obstruction to
boundary insertions. The original Mu and raw type branches must be kept distinct
from ordinary fallback narrowing in the complete prefix proof.

`KeyShapeBudget.unused carrier handle history` filters a finite original carrier
for shapes whose exact handle key is absent. Its length is bounded by the
original carrier length. History inclusion cannot increase it. Inserting the
SAME fresh key, with its shape in the carrier, strictly decreases it, including
the actual eraseDups representation. Carrier duplicates are permitted. The
proof claims strict decrease, not an exact one-element length difference.
This pure module imports only EnumerationState.

`CheckedBoundaryBudget.checked_action_shape_budget` composes actual false-check,
actual prepared boundary and actual action-success observations. Original
model/origin/canonical/live stored-slot evidence derives actual key membership
in keyShapes whole. The same action leaves the enumeration core unchanged.
The checked key is absent at the returned representative, so its shape is in the
finite unused family. Inserting THAT EXACT checked key would strictly decrease
the remaining per-handle budget. Freshness and shape membership are conclusions,
not extra hypotheses. Actual check/action success remain explicit observations.

This last theorem does NOT execute or identify the complete indexed prefix and
later Entry. It does not yet show that every real insertion consumes this budget.
Full prefix/entry linkage is the next local operation. The baseline is the old
resolved target's recursionAncestry, not its former expansionAncestry. Allocation
inherits expansion keys and stale old fresh-counter slot ancestry; the earlier
all-slot KeyAncestry result remains necessary.

## Existing counterexamples and rejected measures

The unchanged SourceColdUnfoldNewMuBoundary constructs mu x. mu y. f(x,y) in an
empty Nat/Unit cache with the repaired constructor. It proves successful closed
construction and unfolding, endpoint semantic heaps, coverage, availability and
closedness. The returned Mu was absent from the source inventory and resident
in the final heap. Cached depth increases from 2 to 3, node count from 13 to 17.
The repaired cold reader still completes with one edge and count 18.

Thus complete startup Mu inventory and decreasing cached depth are false general
measures. This is an existing kernel-proved source witness. It is not whole
prepared Packet divergence, a Haskell defect or a counterexample to every finite
structural carrier. The new body degree ceiling is compatible with new lower-
degree Mu records. It does not restore NoNewMu or cached-depth decrease.

The old source note attributes the witness to 0534aad8 and records historical
aggregate validation. Its cited old /tmp audit/native logs are absent. The
source, historical attribution and missing-log limitation are retained in this
checkpoint. No historical native run was repeated or represented as recovered
raw evidence. The current aggregate Audit includes the unchanged witness.

## Main remaining work

1. Connect the derived boundary identity/action freshness through the COMPLETE
   indexed runPrefix, Right recording and actual Entry. Keep the exact handle,
   suspended bucket and representative. Derive the actual inserted-key budget
   decrease from those observations. Do not add freshness as a new supplier.
2. Derive a source-bound structural native boundary family or suitable handle
   cardinality bound across actual generated conjunction/query allocation. The
   original Mu body degree bound is one component. Per-current-heap inventory,
   Fits/Reserved at supplied depth and raw startup Nat lists do not solve this.
3. Prove nonterminal chosen-output/model induction through actual recursive
   emission. The original model must select an actual branch. Fresh assignments
   remain branch-specific because numeric fresh slots can be reused by siblings.
4. Prove sufficient depth from original source inputs, including all earlier
   allocating callbacks, or prove a valid same-target emission argument. An
   earlier stopped hook can prevent reaching a later selected row. Finite-output
   stability, local non-stuck and the new terminal case do not solve this.
5. Discharge remaining policy/solver/origin/public API contracts and prove
   optimized Haskell correspondence. Preserve older constructor/equality work.

## Validation and exact restart evidence

Eight additive modules: 518 lines/29,349 bytes; 10 public theorems, two private
proof helpers and one finite proof-domain function. Enumerator/native/Haskell
runtime definitions are unchanged. All eight plus Audit pass nine exact strict
Lean 4.34.1 checks with warningAsError=true and linter.all=true. Audit passes
4,580 jobs and checks 81,876 theorem dependencies. Only propext,
Classical.choice and Quot.sound are allowed. Counts are validation evidence.

29 serial compiler commands have 24 passes and five preserved failures. All
final inputs pass. The budget drafts had a list result type error, unavailable
sublist notation and an unavailable convenience tactic. Explicit core types and
Nat order proofs fixed them. The boundary action draft required qualified native
State types; its first strict check rejected a redundant simp argument. Removal
fixed it. No final semantic hypothesis changed. All failed inputs, full raw logs
and later repairs are retained. All commands have measured memory.max/high
4,294,967,296 and swap max zero. No budget increase, custom axiom, native_decide,
placeholder or linter suppression was added.

Public: 787 theorem checks/axiom lists and 67 definition bodies; 3,376,571 bytes,
SHA256 b966ceaf09c9ec31ed06c5a6c73bff9fa42205c2292ef0206dac5d92406c5dde.
The prior 3,357,308 bytes are an exact prefix. All 19,263 new bytes were read in
two complete contiguous ranges. No new public display cut remains. All 4,571 old
non-Audit Lean, 420 stronger-source and 817 Haskell/Cabal identities remain.
Audit keeps its complete prior body after eight imports. Twenty prior document
bodies remain exact suffixes. Twenty-one final documents are retained.
Three source-scope manifests verify 112 artifact identities. Historical Audit
source identity is checked against retained prior-Audit and its current exact
suffix. Literal source cuts remain literal cuts. Historical UNTESTED labels
remain; final source hashes identify the actual checked versions.

## External Haskell repair record

No Haskell source changed. No Haskell check ran. No new Haskell defect or fix
was established. The five failures concern new Lean proof elaboration or strict
linting. The old native measure witness and the remaining handle-family gap are
not new Haskell defects. FINDINGS.md retains all previous external repair records.
Record every later Haskell defect, proposed repair, actual fix and focused
reproduction there so another worker can act on it.

## Publication and restart

Four source commits end at `5138ade52fc76ed80bb88ed15ef62d95b1695c83`. Exact remote and tracking
heads match on git@github.com:TharkunAB/cfta.git refs/heads/formalize.
Origin/main d1ca06a1dd0c7488205feda613b529df21a08669 is an ancestor.
Normal formalize pushes remain explicitly authorized. Refresh upstream before
new work. Preserve all proofs, counterexamples, repairs, marked drafts and
unrelated work. Do not change remote or SSH configuration. The working SSH
route uses ssh.github.com port443 with the existing trusted github.com key.

Board 715, post `d19b0edb-4621-4612-b18c-387fc1147a16`, has exact verified
author/content/metadata. The shared project note uses the msg-board skill.
Complete unfiltered evidence: lean/restart-evidence/20261029-terminal-model-emission/.
Its README and standard-library verifier reconstruct every sealed regular file
from /tmp/mcfta-prepared-model-emission-20261028/. This includes failures,
candidates, full command input snapshots and logs, public bodies/types/axioms,
scopes, all prior/final documents, measurements, Git and board receipts. Use a
fresh extraction destination. Preserve reconstructed and frozen evidence.

Read this note and the front matter of NEXT-PROMPT.md, HANDOFF.md and FINDINGS.md.
Continue in a NEW writable directory. Compiler/native jobs stay serial under the
existing 4 GiB cap. Do not repeat passing source checks unless their inputs change.
The full goal stays ACTIVE. This checkpoint is not whole-system completion.
