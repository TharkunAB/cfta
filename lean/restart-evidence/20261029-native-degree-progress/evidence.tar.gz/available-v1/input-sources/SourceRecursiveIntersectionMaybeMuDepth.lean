import MicroCFTA.SourceRecursiveIntersectionMaybeMu
import MicroCFTA.InternedOpenDepthExecution
import MicroCFTA.InternedStoredLeafShape

/-!
# Open binder depth of an actual optional-binder result

The actual repaired constructor adds at most one open binder level.
Closed captures and literal references have zero open depth.
The result uses the actual body and completed constructor observation.
-/
namespace MicroCFTA.SourceRecursiveIntersectionMaybeMu
open InternedConstructorTemplates InternedProbeProvenance
open InternedStoredSubstitution InternedStoredPlanBinderDepth

variable {Symbol Guard : Type}

/-- An actual completed optional binder adds at most one open binder level. -/
theorem result_le [DecidableEq (EdgeKey Symbol Guard)] (key : Nat × Nat)
    (body : Value Symbol Guard) (state : State Symbol Guard)
    (context : InternedFreshOrdinaryContext.Context state [])
    (cached : InternedFreshOrdinaryDepthHeap.Heap state)
    (opened : InternedOpenDepthReadback.Heap state)
    (available : Available state body) (value : Value Symbol Guard)
    (after : State Symbol Guard) (done : maybeMu key body state = .done value after) :
    valueDepth value ≤ valueDepth body + 1 := by
  have inputs := leaves_available body state available
  have captured : InternedFreshOrdinaryContext.Context state (leaves body) :=
    ⟨context.normal, inputs, context.profiles, context.freeNames⟩
  have zero : ∀ leaf ∈ leaves body, valueDepth leaf ≤ 0 := by
    intro leaf member
    rcases InternedStoredLeafShape.leaves_shape body leaf member with closed | ⟨name, rfl⟩
    · simp only [valueDepth.eq_def, closed, List.isEmpty_nil, ↓reduceIte, Nat.le_refl]
    · simp [valueDepth]
  rw [maybeMu_eq key body state state context.normal.facts available] at done
  split at done
  · have bound := InternedOpenDepthExecution.build_bound
      (.binder true (encode (leaves body) [.intersection key.1 key.2] body))
      (leaves body) state captured cached opened 0 zero value after done
    simp only [syntaxDepth, encode_depth, Nat.add_zero] at bound
    omega
  · cases done
    omega

end MicroCFTA.SourceRecursiveIntersectionMaybeMu
