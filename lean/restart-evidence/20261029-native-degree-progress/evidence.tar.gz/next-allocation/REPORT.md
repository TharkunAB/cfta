# Next proof: all-outcome allocation bounds

Source-only root analysis. This is not a checked theorem.
The current successful-return theorem is closed and strictly checked.
This report identifies the next missing contract.

## Exact next kernel statement

Retain the original source, Facts, source ceiling L, original NodeScope,
semantic Completes, current Valid and NodeReady, source growth and issued
history, SemanticHeap and open-depth Heap. For every actual runtime fuel,
prove:

```text
Lower state.heap (L + requiredFuel originalView originalRequest complete)
  (Kernel.execute emptyGuard conjoin fuel domain left right state).state.heap
```

This statement covers done and failed results. A pending constructor appears
as an actual failed result. It classifies every complete Mu in the reached
heap as the exact old record or a body below the bound. It does not assume
that every current record was already below that bound.

## Lower algebra

InternedStoredPlanBinderDepthProgress.Lower has an explicit recordwise body.
The module has lower_refl and preserve for NoNewMu effects. It does not have
named general monotonicity or transitivity lemmas in the reviewed source.

The required lemmas follow directly by cases on the old-or-small alternative:

```text
low <= high -> Lower before low after -> Lower before high after
Lower before bound middle -> Lower middle bound after -> Lower before bound after
```

Monotonicity weakens only the small-body alternative. Transitivity substitutes
the first proof when the second proof identifies an exact middle record.
Neither lemma needs heap coherence or an allocation-count assumption.

## Actual Mu case

Use the exact entered domain and the smaller runtime-fuel hypothesis.
The entered machine has the same constructor heap. Existing mu_request_below
gives the strict semantic child inequality Rchild < Rparent.

The hypothesis bounds every body outcome at L + Rchild. Weaken it to
L + Rparent. A failed body returns that actual heap and runs no binder.

For a successful body, the already checked node_result_degree supplies its
actual returned SemanticHeap, open-depth Heap, and bodyDegree <= L + Rchild.
execute_checked supplies Available for that exact body in its reached heap.
MaybeMu.lower covers the entire subsequent constructor outcome, including
pending and records created by probes. Its threshold is bodyDegree + 1.
Strict semantic decrease proves bodyDegree + 1 <= L + Rparent.
Weaken that Lower proof and compose it with the earlier body Lower proof.
No bound on a future body is supplied as an external premise.

## Ordered walks and ordinary cases

Induct on the actual request list and split each actual Result.
WalkTrace alone covers successful walks and is insufficient for this target.
A failed first call retains its reached heap. A successful first call supplies
the exact state for the tail. Transport readiness and original inputs with
execute_checked or edge_checked. Transport SemanticHeap and open-depth Heap
with the closed successful-return theorems. Compose all earlier allocation
effects with the tail's bound, including a tail that fails.

For rows, derive each original EdgeBelow from rows_member_below.
For equal-arity edges, derive each original NodeBelow from EdgeScope.child
and immediate semantic decrease. Unequal-arity edges have no child call.
makeEdge changes no Mu record. makeNode and makeUnion have NoNewMu proofs.
These effects preserve the composed Lower statement.

Empty, self, repeated, unsupported and exhausted branches leave the heap.
Reset and swap use the actual smaller runtime-fuel call. Original reference
lookup uses OriginalBindings.read and the existing reference request bounds.
Missing lookup branches leave the heap and require no return-existence proof.

## Remaining native and global obligations

Existing native_node_correct and native_edge_correct give exact kernel
correspondence for successful native returns under WordRanges. The proposed
kernel allocation result would transfer to those successful returns.
Those theorems do not provide correspondence for every stopped native prefix.
An additional native prefix invariant or exact pending correspondence is
required. Keep actual constructor and memo states in that statement.

Lower relative to the current heap does not bound older records that were
already generated. A cold root starts at the original source and has a source
ceiling. A later query needs the accumulated original-source allocation
invariant. A new per-query bound does not establish one fixed global rank.
Generated query operands can lie outside the original source's NodeScope.
Their lineage and a uniform progress measure remain necessary.

A degree ceiling alone gives no bound on record cardinality, fresh handles,
guard syntax growth, or machine-word ranges. Keep those obligations separate.
Nonterminal value coverage, sufficient enumeration depth, the new language
and checkpoint APIs, and full Haskell correspondence also remain open.

The next proof must close its runtime induction. A public helper that leaves
the all-future Lower supplier as an original input does not close this gap.

## Reviewed basis

This analysis uses the literal Lower definition and lower_refl/preserve and
bind_lower statements in InternedStoredPlanBinderDepthProgress, lines 1-78;
the checked MaybeMuDepth, KernelReturnDegree, KernelClosedDegree and native
return sources; the actual Kernel walk/branch definitions; and the checked
ordered edge and row proof inputs. Existing source copies and compiler
readbacks are retained in this checkpoint. This report adds no compiler run.
The attempted bounded next-step delegation ended with a capacity error and
created no result. The analysis above is the root's source review.
