import MicroCFTA.SourceRecursiveIntersectionOpenBodyBoundary
import MicroCFTA.InternedMuDepthInventory

/-!
# Degree observations at the actual open-body native site

The input is the existing actual source construction and its 22-step site.
The observations compare open body degrees with the original startup limit.
A returned reference does not assert equality of stored payloads.
-/
namespace MicroCFTA.SourceRecursiveIntersectionOpenBodyDegreeObservation
open InternedConstructorTemplates InternedBinderProtocol
open InternedStoredPlanBinderDepth
local notation "Heap" => InternedConstructorTemplates.State Nat Nat
local notation "Node" => Value Nat Nat

/-- Read each actual canonical resident Mu identity and its open body degree. -/
def muRows (heap : Heap) : List (Nat × Nat) :=
  (List.range heap.nodes.next).filterMap fun identity =>
    (InternedMuDepthInventory.rankAt heap identity).map fun degree => (identity, degree)

/-- Read the maximum actual canonical Mu body degree in the supplied heap. -/
def muMaximum (heap : Heap) : Nat :=
  ((muRows heap).map Prod.snd).foldl Nat.max 0

/-- Use the exact existing startup ceiling from initial_bounded. -/
def startupLimit : Nat :=
  maximumDepth (InternedRecordCoherence.nodeInventory SourceRecursiveIntersectionOpenBodyBoundary.source) + 1

/-- Read the exact source plan that actual optional-binder construction compiles. -/
def wrapperDepth (pair : Nat × Nat) (body : Node) : Nat :=
  syntaxDepth (.binder true
    (InternedStoredSubstitution.encode (InternedStoredSubstitution.leaves body)
      [.intersection pair.1 pair.2] body))

/-- The wrapper adds one to the pending body's open stored-plan degree. -/
theorem wrapperDepth_exact (pair : Nat × Nat) (body : Node) :
    wrapperDepth pair body = 1 + valueDepth body := by
  unfold wrapperDepth
  rw [syntaxDepth, encode_depth]

/-- The actual original source satisfies that same startup limit. -/
theorem source_bounded :
    InternedMuDepthInventory.Bounded SourceRecursiveIntersectionOpenBodyBoundary.source startupLimit :=
  InternedMuDepthInventory.initial_bounded _ SourceRecursiveIntersectionOpenBodyBoundary.source_inputs.1

structure SourceObservation where
  operandReferences : NodeRef × NodeRef
  operandValueDegrees : Nat × Nat
  operandBodyDegrees : Nat × Nat
  canonicalMuBodyDegrees : List (Nat × Nat)
  muBodyMaximum : Nat
  cachedProfileMaximum : Nat
  startupLimit : Nat
  deriving Repr

/-- Keep the original operand and resident-body observations separate. -/
def sourceObservation : SourceObservation :=
  let operands := SourceRecursiveIntersectionOpenBodyBoundary.operands
  let heap := SourceRecursiveIntersectionOpenBodyBoundary.source
  ⟨(operands.1.referenceOf, operands.2.referenceOf),
    (valueDepth operands.1, valueDepth operands.2),
    (bodyDepth operands.1, bodyDepth operands.2), muRows heap, muMaximum heap,
    maximumDepth (InternedRecordCoherence.nodeInventory heap), startupLimit⟩

structure SiteObservation where
  pair : Nat × Nat
  pendingReference : NodeRef
  pendingFree : List Reference
  pendingValueDegree : Nat
  pendingOwnBodyDegree : Nat
  pendingCachedDepth : Nat
  existingPreparationCheck : Bool
  usesPair : Bool
  wrapperDegree : Nat
  pendingBelowStartup : Bool
  wrapperBelowStartup : Bool
  pendingBelowSourceBodyMaximumPlusOne : Bool
  currentMuBodyDegrees : List (Nat × Nat)
  currentAllBelowStartup : Bool
  optionalOutcome : String
  optionalReturnedReference : Option NodeRef
  optionalReturnedValueDegree : Option Nat
  optionalReturnedBodyDegree : Option Nat
  optionalPostMuBodyDegrees : List (Nat × Nat)
  optionalPostAllBelowStartup : Bool
  deriving Repr

/-- Observe the actual pending body and the actual optional-binder outcome. -/
def siteObservation : Option SiteObservation :=
  match SourceRecursiveIntersectionOpenBodyBoundary.site with
  | .yielded (.optionalBinder pair body _) before =>
      let constructed := SourceRecursiveIntersectionMaybeMu.maybeMu pair body before.machine.heap
      let after := constructed.state
      let result := match constructed with
        | .done value _ => ("done", some value.referenceOf, some (valueDepth value), some (bodyDepth value))
        | .pending _ _ => ("pending", none, none, none)
      some ⟨pair, body.referenceOf, body.free, valueDepth body, bodyDepth body, body.depth,
        InternedStoredPreparationCheck.check body,
        decide (Reference.intersection pair.1 pair.2 ∈ body.free), wrapperDepth pair body,
        decide (valueDepth body < startupLimit), decide (wrapperDepth pair body < startupLimit),
        decide (valueDepth body < muMaximum SourceRecursiveIntersectionOpenBodyBoundary.source + 1),
        muRows before.machine.heap,
        (muRows before.machine.heap).all (fun row => decide (row.2 < startupLimit)),
        result.1, result.2.1, result.2.2.1, result.2.2.2,
        muRows after, (muRows after).all (fun row => decide (row.2 < startupLimit))⟩
  | _ => none

#eval sourceObservation
#eval siteObservation

end MicroCFTA.SourceRecursiveIntersectionOpenBodyDegreeObservation
