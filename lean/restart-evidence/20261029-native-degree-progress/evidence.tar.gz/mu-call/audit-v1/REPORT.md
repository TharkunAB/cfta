# Actual Kernel Mu degree helper

2026-10-29, Europe/Stockholm. SOURCE-ONLY / UNTESTED. Root owns repository writes, compilation and evaluation. No compiler, evaluator, native program, Git, network or board operation was run. Seven whole Lean sources were read, below the maximum of eight; supporting reads use explicit cuts.

## Frozen candidate

Recommended: candidate-v2/MicroCFTA/SourceRecursiveIntersectionKernelMuDegree.lean. Public theorem: `SourceRecursiveIntersectionKernel.mu_degree`. Exact statement is retained in candidate-v2/PUBLIC-STATEMENT.txt. Candidate-v1 is preserved as an earlier draft. The candidate adds one theorem and no new predicate, axiom, termination supplier, body bound premise or future heap bound premise.

Fixed arguments: source, Facts source, limit, Bounded source limit, holds, emptyGuard, conjoin, runtime fuel. The source-bound proof is deliberately named _sourceBounded: this individual Mu case uses the smaller-runtime IH rather than consuming that baseline proof directly. It retains the original fixed-source gate used by the joint theorem.

The nodeIH argument has the exact uniform order root specified: request, original NodeScope, semantic Completes, state, after, Valid, NodeReady, original-source growth, issued-history extension, SemanticHeap, open-depth Heap, value, actual execute-fuel done. Its conclusion is SemanticHeap after.heap, open-depth Heap after.heap, and returned valueDepth <= limit + semantic requiredFuel child. It is the actual smaller-runtime induction hypothesis, not an original external hook-retention or completion oracle. Root must discharge it in the final natural induction on runtime fuel.

Then come the parent request, NodeScope, Completes, selected bothMu/leftMu/rightMu disjunction, actual current/after machines, Valid, NodeReady, original-source growth/history, SemanticHeap/open heap, value and the literal successful `Kernel.mu (Kernel.execute ... fuel)` observation.

The conclusion uses the SAME actual returned machine and value: both preserved heaps and valueDepth <= limit + requiredFuel of the original parent semantic request. No return existence is asserted.

## Actual proof path

1. Existing mu_identities derives both source operand identities from the selected native Mu branch.
2. The proof computes the ACTUAL entered domain using the current domains cache. Existing mu_request_below gives NodeBelow for that exact entered child, using fixed original Facts/NodeScope/Completes and current domain-cache validity. Destructing NodeBelow gives the actual child NodeScope, child Completes and strict F_child < F_parent.
3. Existing Kernel.entered derives current entered Valid and Domain. Domain entry changes only the domain cache, so original-source heap growth/history and both heap invariants pass to that actual child machine. body_available derives the actual child operands' availability. There is no source=current-heap cast.
4. The proof unfolds actual Kernel.mu and cases the literal body `Kernel.execute ... fuel` result. Failed cannot produce the supplied outer done. Done exposes its exact body value and body machine. No private bind helper was added: root confirmed literal Result case inversion is the intended interface.
5. execute_checked supplies Available of that ACTUAL returned body in its ACTUAL returned heap. The nodeIH supplies both returned heaps and bodyDegree <= limit + F_child.
6. The proof calls the actual MaybeMu primitive on that body/heap. It obtains semantic and open-depth preservation from the existing optionalBinder effect lemmas. A literal pending outcome contradicts outer done. A literal done outcome exposes the actual constructed heap; Result.done injection identifies the exact outer value and machine without comparing function-valued caches or guessing equality.
7. The checked root result_le theorem is applied with `bodySemantic.1`, `bodySemantic.2`, actual bodyOpened and actual bodyAvailable. It yields returnedDegree <= bodyDegree + 1. Strict F_child < F_parent then closes returnedDegree <= limit + F_parent with omega.

This is local arithmetic from an actual recursive body call and actual constructor output. It never assumes the desired parent's degree inequality or any degree bound on the future heap. It applies to all three selected Mu routes through the existing exact branch theorem.

## Version difference

V2 preserves V1's public gate/result structure. It changes the unused name of the nodeIH's NodeScope binder to _scope. It also replaces a bare equality `cases` on the final constructor result with explicit value/state injection and transport. This avoids dependence on which variable equality elimination retains. No compiler failure motivated this version; it is a source-only robustness change. Neither version is claimed checked.

## Scope and remaining work

This helper closes only the selected actual Mu branch CONDITIONAL on the smaller-runtime joint theorem. Root still owns the remaining branch composition and final natural induction, which discharges nodeIH. The helper does not prove that all runtime fuel values succeed, termination, a startup degree preserved without the semantic requiredFuel allowance, or arbitrary native pending results. It does not infer payload equality or divergence from a returned reference tag. No Haskell changes or source defect claim is made.

The manifest records source identities and exact retained input ranges. The seven whole sources are CompileMuBounds, KernelReadback, Kernel, MaybeMuDepth, KernelVerified, KernelSchedule and KernelEdgeDegree. Other sources are cuts. Where a combined supporting read was truncated, that limit is recorded rather than claiming a whole-file review. The actual result_le interface was reread before freezing evidence.
