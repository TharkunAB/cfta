# Edge walk degree candidate

Status: AUTHOR UNTESTED. Root owns compilation and repository integration.

## Result

`SourceRecursiveIntersectionKernelEdgeWalkDegree.lean` defines `Kernel.edge_result_degree`.
The candidate covers actual equal and unequal arities.
It returns the actual reached `SemanticHeap`, `OpenDepthReadback.Heap`, and the bound `manyDepth value.children ≤ limit + requiredFuel originalView edgeSemantic complete`.

The fixed node hypothesis uses the exact argument order requested by Root.
Its actual call is `Kernel.execute emptyGuard conjoin fuel`.
Root must supply that hypothesis from the smaller runtime-fuel case of its final node induction.
This helper does not independently establish the node hypothesis.
The source ceiling is captured by that induction hypothesis.
A separate `Bounded source limit` argument is not needed for this edge proof.

## Proof route

The equal-arity branch derives each original child `NodeScope` from `EdgeScope.child`.
It derives child completion and strict semantic rank with `Immediate.edge` and `immediate_requiredFuel`.
The local induction follows the actual `WalkTrace`.
Each completed node uses the fixed smaller-runtime-fuel hypothesis.
`execute_checked` supplies the actual intermediate validity and growth histories.
Those histories retain the current domain and the remaining original child operands.
The induction passes the reached semantic and open-depth heaps to the next actual child.
The ordered maximum is bounded by the parent semantic rank.

`children_checked` supplies availability of every actual returned child at the final walk state.
The proof then follows the literal `work (makeEdge ...)` endpoint.
The existing semantic and open-depth constructor lemmas retain both heaps.
`InternedShallowValues.makeEdge_children` identifies the exact requested child list, including a canonical cache hit.

The unequal-arity branch reuses the installed `edge_mismatched_degree` theorem.
It returns degree zero and both actual reached heaps without a recursive request.

## Premises and scope

The public signature is retained in `public-signature-v1.lean.txt`.
It retains a fixed original source and its `Facts`, original edge scope and semantic completion, current `Valid` and `EdgeReady`, original source growth and issued-history extension, and both current concrete heap invariants.
It also requires the literal successful edge observation.
The node hypothesis is an internal natural-induction hypothesis.
It must be discharged by the final node theorem.
There is no current-heap ceiling assumption, future body bound, future returned heap supplier, model or output existence premise.

This candidate does not establish global native closure, handle cardinality, enumeration depth, model coverage, or Haskell correspondence.
No Haskell defect or change is claimed.

## Evidence

The complete candidate was read back after writing.
The manifest records six whole source reviews and literal cuts for all additional source reads.
This is within the eight-whole-source limit.
Whole-source byte hashes are recorded for every cut source; only the named line ranges are credited as reviewed.
A grouped output truncated part of an early Thunks/RequestProgress read.
Only the separately visible retained ranges are credited for those files.
No compiler or evaluator was called.
No old source or frozen evidence was changed.

The candidate is frozen at version 1.
Any compiler repair must use a new version and retain the original bytes.
