# Actual optional-binder body degree

2026-10-29, Europe/Stockholm. SOURCE-ONLY / UNTESTED. Root owns all compiler and evaluator checks. No repository changes, Haskell changes, Git, native execution, network, or board operations were made. Six unique whole Lean text reads were requested, within the maximum of eight. Supporting reads use cuts. The manifest distinguishes whole source SHA identities from exact retained cuts and discloses truncated review output.

## Result

The existing OpenBodyBoundary witness does not establish a startup degree violation. It establishes an actual unprepared optional-binder body after 22 native steps from two completed closed original source roots. Unprepared means the structural check rejects an open nested Mu. It is not an inequality against the original degree ceiling.

The frozen candidate `candidate-v1/SourceRecursiveIntersectionOpenBodyDegreeObservation.lean` reuses that EXACT source construction, operands, initial native state and site. It contains two #eval inputs plus two direct kernel-shaped declarations. It does not assert guessed numeric observations or a guessed point inequality. Root must compile and run it to establish the numeric result.

The kernel-shaped declarations are:

- wrapperDepth_exact pair body: the actual optional-binder source plan has syntaxDepth equal to `1 + valueDepth body`. This follows directly from syntaxDepth and encode_depth.
- source_bounded: the actual original witness source satisfies the EXACT existing startup bound by initial_bounded and the witness's already-proved source facts.

## Exact quantities

The startup limit is `InternedConstructorTemplates.maximumDepth (InternedRecordCoherence.nodeInventory Witness.source) + 1`. These are the definitions used by initial_bounded. The inventory is the finite actual issued-identity/node-record lookup, not a hypothetical future heap.

valueDepth counts the open stored plan. It returns ZERO immediately on a closed value. bodyDepth of a Mu returns valueDepth of its BODY. Value.depth is the cached Mu nesting profile. These three readings must remain separate. Comparing the pending body with valueDepth of an original CLOSED root is an invalid substitute for the original Mu-body bound.

The tighter source observation enumerates actual canonical Mu rows using rankAt over the original finite issued range. Each row is `(canonical identity, valueDepth storedBody)`. muMaximum is the maximum of those body degrees. Facts/coherence and rankAt_record explain why this observes the actual resident canonical Mu bodies; it does not infer payload equality from a reference tag. No generic tighter-bound theorem is asserted here.

## How to read the evaluator output

sourceObservation prints both original operand reference tags, their valueDepths, their bodyDepths, actual canonical resident Mu body degrees, their maximum, the original cached-profile maximum, and its startup limit.

siteObservation is Some ONLY for the actual original 22-step site yielding an optionalBinder. It prints:

- Actual pair, pending body reference tag/free references, pending valueDepth, bodyDepth, and cached Value.depth.
- The existing preparation check and whether the exact pair reference is free.
- The actual binder wrapper syntaxDepth, its strict startup comparison, and the pending body's strict startup comparison.
- A separate comparison with the tighter original canonical-body maximum plus one.
- Actual current canonical Mu body rows and whether all lie below the startup limit.
- The actual SourceRecursiveIntersectionMaybeMu.maybeMu outcome at that exact site: done or pending.
- On done, the returned REFERENCE tag, valueDepth and bodyDepth as separate fields.
- Actual post-maybeMu canonical Mu body rows and their startup comparisons, including all resident rows rather than only identities above the old counter.

The optional-binder call is exactly the native step's construction primitive. The native runtime dispatch reads maybeMu; done yields the continuation at its returned heap and pending blocks at its returned heap. The candidate observes maybeMu directly without replacing it with a model callback.

No numeric values are claimed before root checks the input. `none` is a failed site-shape observation, not an accepted default body. A pending construction still exposes its actual post-probe heap and is printed as pending, not converted to done. The evaluator output is a point observation; it is not a universal theorem.

## Important strictness distinction

build_lower requires `syntaxDepth expression <= bound`, and it proves every new Mu BODY has valueDepth strictly BELOW bound. For the actual optional-binder wrapper, `valueDepth pendingBody < limit` implies `wrapperDepth <= limit`. It does NOT imply `wrapperDepth < limit`.

The candidate's wrapperBelowStartup field is an extra, STRONGER observation. False there alone is not a Bounded counterexample. The existing bounded_after helper asks `rank < limit`; when using a wrapper bound equal to limit, a direct old-or-small proof already suffices: old records satisfy initial Bounded, and new records have bodyDegree < limit from Lower before limit after. The strict wrapper premise can lose one degree unnecessarily.

This explains a useful next local interface without asserting its original-source gate:

    actual available maybeMu body + current construction Context/depth/open-depth heaps
    + Bounded current originalLimit
    + valueDepth pendingBody < originalLimit
    => Bounded actualMaybeMu.state originalLimit

The final inequality is the REAL pending-body gate still to derive from the original source/trace for a universal startup argument. It is not supplied by check=false, source closedness, or a returned Mu tag. This report does not add a theorem that assumes future completion, future keys or desired family closure.

## Present and missing gates

The reused witness already proves its original completed construction, Facts, both Available operands, Original payloads, empty free lists, complete original coverage, actual original Context, the 64-bit key check, initial native validity, and the actual 22-step trace with reached coverage. The point candidate also instantiates the original startup bound from those Facts.

The witness's unprepared theorem does not itself package the reached body's Available proof, full reached Context, depth heap or open-depth heap. Those are separate requirements for applying the generic lower-allocation machinery. Its original Context has normal, inputs, profiles and freeNames fields; do not silently read every other heap invariant out of that one record. Existing native transport may derive the required point facts, but no such derivation is claimed by this observer input.

A universal native-body ceiling needs a proof transporting the original ceiling to EVERY generated pending body, not just this point. The original-source-degree plus requiredFuel target remains unproved. No fixed numerical startup limit is assumed. No termination conclusion follows from the one-step observation.

## Reference and payload boundary

The existing native_returned theorem observes referenceOf = `.mu 26` at a later bounded native return. That statement does not assert equality of full stored payloads, and it does not prove divergence. This candidate reports reference and body-degree data separately for the actual optional-binder return. Equal degree data would also be weaker than full payload equality. No Haskell defect or admitted startup-ceiling counterexample was established.
