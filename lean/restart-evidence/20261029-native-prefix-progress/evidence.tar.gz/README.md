# Verified native intersection prefix body bounds

The full formalization goal remains ACTIVE.
The exact source result is for SourceRecursiveIntersectionNative.execute.
The actual checked generator interpreter remains the next proof boundary.
Read final-documents/lean/notes-current-native-prefix-progress.md first.
The proposed checked caller statement is UNPROVED and UNTESTED.

All regular files are sealed and archived without a filter. Historical
candidate labels, failed compiler attempts, raw logs and exact input copies
remain. final-check-map.json identifies the 13 exact strict final sources.
The standard verifier executes no archived Lean, Haskell or helper script.
The helper scripts record historical steps. Do not rerun them in this area.
Continue in a new writable area. Keep this tree and reconstructions immutable.
