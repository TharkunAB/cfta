# Native request prefix bounds

Status: AUTHOR UNTESTED. Root owns compilation and repository integration.

## Candidate

Module: `SourceRecursiveIntersectionNativeRequestPrefixLower`.
Public names: `node_prefix_from_body` and `edge_prefix_from_body`.
Each public argument order is `emptyGuard`, `conjoin`, `request`, `state`, strong `valid`, `ready`, `ranges`, `bound`, `bodyLower`, and `fuel`.
The complete signatures are retained in `public-signatures-v1.lean.txt`.

Each conclusion is the actual `Lower` relation from the original constructor heap to the heap in the returned native outcome.
There is no success, yield, or blocked-result assumption.
The result covers fuel exhaustion, ordinary completion, explicit failure, and blocking.

## Actual proof route

Fuel zero retains the original heap.

Direct node lookup derives the exact original request and complete original native state with `lookupNode_direct`.
The actual yielded step gives word ranges for the compiled body with its pure continuation.
`WordRanges.before_bind` gives ranges for the compiled body itself.
`execute_bind_lower` composes the supplied body bound with the actual pure continuation bound.
This avoids a new code identity lemma.

Memo evaluation derives checked request words at the original instruction.
The node case also obtains the actual successful key observation from `lookupNode_memoized`.
`node_started_source` or `edge_started_source` derives strong validity at the actual current state, exact request identity, and the unchanged source machine.
The proof uses the actual yielded step to derive ranges and then removes the finish continuation with `before_bind`.
`execute_bind_lower` composes the compiled-body bound with `finishNode_lower` or `finishEdge_lower` at each actual body completion.
Those finish lemmas require no extra endpoint validity or future preservation premise.

Ready demands use `pure_lower` at the actual returned current state.
Busy and absent demands retain the actual blocked state.
`lookup*_machine` and `demand*_machine` derive the unchanged source machine in all three cases.
The proof retains complete native states in every lookup, demand, and execute equation.
It rewrites only the exact source machine equality needed by `Lower`.

## Supplier boundary

`bodyLower` is an intermediate induction supplier.
It quantifies over actual current states with strong validity, the same original source machine, and the derived compiled-body word ranges.
It covers every finite execution bound and every returned native outcome.
Root must discharge it from the concrete compiled branch proof and semantic-rank induction.
These two generic wrappers do not derive that body bound from original input alone.
They must not become an extra original-input assumption in the final native theorem.

No semantic source facts, source ceiling, model, future body bound, future heap, or successful output is added to either wrapper.
No termination, global finite-handle universe, sufficient enumeration depth, model coverage, or Haskell correspondence is claimed.
No Haskell defect or fix is claimed.

## Evidence and ownership

The complete 149-line candidate was read back after writing.
The input manifest records eight whole source reviews.
All other semantic source reads were literal cuts.
Search results are recorded separately from reviewed source blocks.
The short LowerAlgebra read reached EOF and is counted as a whole source.
This stays within the eight-whole-source limit.

No compiler, evaluator, native execution, Git, network, or board command was called.
No repository file or old evidence area was changed.
This version is immutable.
Any compiler repair must preserve version 1 and use a new version.
