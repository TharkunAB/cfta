# Generator query frontier audit

Date: 2026-10-29 20:30 CET.
Status: source-only audit. The proposed statement is UNPROVED and UNTESTED.
Root reports that bare Native prefix bounds and Audit pass. This audit did not
run a compiler, evaluator, native job, Git, network, or the message board.
It did not change the repository or Haskell. No checked counterexample is claimed.

## Finding and next theorem

The first missing transfer is an all-outcome Mu-body bound for the ACTUAL
`SourceEqualityNativeDemand.execute` checked interpreter. The published bare
`SourceRecursiveIntersectionNative.execute` theorem cannot be substituted for
this call. A new global original-operand supplier is not the first missing step.
`NEXT-STATEMENT.txt` states the proposed caller-level theorem with existing
original entry gates. Its bound precedes every runtime native fuel. It targets
the literal checked outcome heap, including yielded, failed, constraintError,
and blocked observations. It has no successful-return or future-bound premise.

The checked proof can use source = beforeCaller.checked.native.machine.heap.
Good supplies Facts. Available + closed derive Original via
OriginalOutput.closed_original. RequestScope.initial_scope derives NodeScope
in THIS source. RequestProgress.initial_complete derives the semantic Completes
certificate; WarmQuery.query_complete lines 92-101 already uses this exact route.
Initial_bounded supplies the source Mu ceiling from the source node inventory.
The next proof must carry actual returned-value degree information while it
constructs fresh checked memo cells. It must derive that local invariant from
this entry heap and actual evaluation, not add it as a public future supplier.

## Exact runtime producer and caller

1. IncomingNode.run lines 48-69 resolves the actual enumeration representative,
reads its stored oldHandle, and calls lookupNode in the CURRENT native heap.
The request is literally emptyDomain/incoming/old. Lines 89-91 preserve the
reached checked state in the returned caller on every non-DONE native outcome.
This caller cannot be replaced by the original caller on failure.
2. Dispatch.dispatch lines 61-81 reads two stored enumeration handles and decodes
both in beforeCaller.checked.native.machine.heap. It calls the same checked
request with the literal left/right values. Lines 89-90 retain other.state.
3. TargetWorker.leaf and SeededWorker.leaf call that checked request too. Their
folds first obtain a head, then run the tail at its reached state, then call the
native intersection at the tail's later checked state. Thus the head's original
projection heap is not the entry source of the later native query.
4. SharedTargetWorker.step uses the literal target/input and before.checked.
Both the completed and stopped cases advance the same shared state with the
actual checked endpoint. These ordinary target and seeded paths share the same
checked-engine bridge; they are not separate bare-native calls.

These are the runtime definitions inspected here. The audit does not claim an
exhaustive whole-repository inventory of every syntactically similar helper.

## Why the bare-native theorem does not transfer

Demand.step delegates ordinary code instructions to Native.step with the actual
PCS top/conjoin functions. It handles .edge itself and introduces an .edgeBody
control. Demand.body lines 65-84 loads actual equality fields, runs the checked
constraint allocator, handles error/missing/rejected/mismatch cases, then emits
checked children or a sentinel. Equality operations may change while the native
heap does not. Subsequent child calls still run through Demand.execute.
There is no literal equality with a bare Native.execute observation.

There is also a distinct cache premise. NativePrefixLower requires
Thunks.Valid: a returned node/edge cell has an eager Kernel Produced receipt.
Good.native is PhysicalCache.Valid: returned cells require Available or
EdgeResident. It does not provide that eager receipt. Checked provenance stores
Demand.execute compileNode/edgeBody DONE observations plus independent semantic
facts. Its own source text explicitly separates these from eager Produced.
ClosedReceipts.node_produced constructs this checked receipt, not a bridge to
a bare-native exact-state run. ContextualCompletion.request_complete constructs
a checked successful return with a language law; it does not bound all earlier
stopped heaps or replay them in bare Native.execute.

Targeted searches found no Demand Lower export or prefix-heap replay in the
inspected checked correspondence modules. Exact patterns, files, outputs and
exit codes are saved in search-scope.json. This is a bounded source-search
finding, not a claim that a theorem could not exist under another name.

A direct checked extension of the semantic-rank proof must handle these cases:
- Entry-old warm hits are Available/EdgeResident in the literal entry source.
  Their degree comes from that source's finite inventory.
- New checked cells need actual degree facts from their originating execution.
  Physical availability or language equality alone is not such a degree fact
  against an older, smaller source. Preserve this distinction in the induction.
- Checked edge errors, blocked fields and sentinels add no Mu records. The ready
  branch executes the actual ordered child requests and constructs an edge.
  The child degree bounds and exact current-state invariants must be derived.
- OptionalBinder must receive its actual derived body bound. Existing bare
  constructor Lower helpers are useful locally; they do not prove the checked
  continuation's body bound by themselves.

## Gates already available at an actual caller

Context.ready.good supplies physical Good and source Facts. Ready.semantic.ready
supplies both SemanticHeap and OpenHeap (RequiredCache.Ready fields semantic and
depth). Context.admitted carries the inventory's contextual/covered cache facts,
original-record growth and issued-history retention. Ready also supplies the
existing scoped-cache and idle gates used by successful query completion.

IncomingNodeResources.initial_ranges reads PendingRealized to obtain the exact
old decoded value, current availability and closedness. Incoming's availability
and closedness are separate original arguments. DispatchResources.initial_ranges
gets both exact decoded operands from PendingRealized. In both proofs Fits.room
supplies the current node/edge counters and domain headroom. WarmInitialRanges
then derives checked WordRanges for the actual request. No all-future ranges
family is passed by the caller. IncomingQuery.complete_resources lines 115-127
uses exactly these current gates.

Inside one query, Current retains original-source growth/history and semantic
readiness at reached states. RecursivePrefixControl.Certified retains EdgeScope
and current EdgeReady at an actual .edgeBody. edge_data projects those exact
facts. RecursivePrefixScope.node_scope and NativeRequestSourceScope.node_prefix
already derive NodeScope for actual reached raw node instructions, fixed at
THIS query's entry heap. They do not establish a generator-wide initial source.
Semantic child certificates/ranks must still be carried through the actual
checked proof; mere syntactic scope does not itself assert Completes.

## Physical source and inventory rebase

Inventory.At.growth/history point from inventory.source to the current heap.
They allow old Available values to grow forward. They do not reflect a new
current Available value backward into inventory.source.

Inventory.query_complete returns next.source = state.native.machine.heap and
next.roots = inventory.roots ++ [left,right]. CoveredQuery.generated_complete
lines 119-160 explicitly builds this target, grows the old roots into it,
adds the actual operands, derives closed original syntax in that heap, and
rebases contextual/covered cache laws. TargetQuery.finite exposes these same
source and root equalities at the actual returned receipt. Thus generated
operands are admitted in the GROWN CURRENT entry heap. They are not generally
claimed Available in the previous inventory.source or generator startup heap.
At each new query they are original operands relative to the newly captured
physical source. The source changes between queries.

NativeOriginalRequestScope.optional has a stronger source-build equation:
build original [] empty = .done root before.native.machine.heap. Its original
writer conclusions are tied to that literal source. This equation cannot be
reused on a later grown generator heap without another actual build equation.
NativeRequestSourceScope.node_prefix does derive useful fixed-source scope
within one current query without that whole source-build premise.

Model AssignmentOrigins bounds semantic assigned terms by subtrees of a chosen
term. KeyAncestry bounds only key.tries; ModelKeyShapes.stored_recursion_key_mem
also concludes only tries membership. None of these conclusions bounds key.node,
returns NodeScope for physical native operands, or reflects current availability
into an older heap. They cannot replace the rebase or the checked-engine proof.

## Subsequent boundary after the checked bridge

The proposed theorem gives a finite bound for one actual query, chosen from its
current source before native fuel. Composing finite generator phases can then
rebase this bound at the next actual query entry. That is distinct from deriving
one ceiling from only the generator startup data for arbitrarily many future
queries. The existing inventory deliberately changes source, and this audit
found no theorem that bounds all such rebased source ceilings by one original
model/key-ancestry constant. A per-query theorem must not be advertised as that
global handle/depth, global coverage, or completion result.

## Read scope and provenance

Three whole Lean source acquisitions: TargetQuery (119 lines),
NativeInventoryState (110 lines), NativeClosedPrefixLower (83 lines).
All other source reviews are exact literal cuts. No whole source output was
truncated. Some broad search output was truncated and is not counted as a whole
source read or used as evidence of complete coverage. read-scope.json records
source bytes/SHA256, requested and actual line endpoints, exact cut bytes/SHA256,
and whole-versus-partial status. EOF-overrunning requested cut endpoints are
recorded separately from actual endpoints. The collector uses full bytes only
to record source identity; it prints and stores exactly the specified cut.
No Lean code candidate was authored. NEXT-STATEMENT.txt is a proposed interface.
