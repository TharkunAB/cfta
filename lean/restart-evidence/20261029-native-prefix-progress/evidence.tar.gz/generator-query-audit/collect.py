from pathlib import Path
import hashlib,json,sys
base=Path('/tmp/mcfta-native-prefix-progress-20261029/generator-query-audit/evidence-v1')
manifest=base/'read-scope.json'
records=json.loads(manifest.read_text()) if manifest.exists() else []
for arg in sys.argv[1:]:
 parts=arg.split(':'); source=Path(parts[0]); data=source.read_bytes(); lines=data.splitlines(keepends=True)
 start=int(parts[1]); end=len(lines) if parts[2]=='EOF' else int(parts[2]); cut=b''.join(lines[start-1:end])
 name=f'{len(records)+1:02d}-{source.stem}-L{start}-L{end}.lean.txt'; target=base/'inputs'/name; target.write_bytes(cut)
 record={'source':str(source.resolve()),'source_sha256':hashlib.sha256(data).hexdigest(),'source_bytes':len(data),'source_lines':len(lines),'start':start,'end':end,'whole':start==1 and end==len(lines),'copy':str(target),'cut_sha256':hashlib.sha256(cut).hexdigest(),'cut_bytes':len(cut)}
 records.append(record); print(json.dumps(record)); print(''.join(f'{n}: {line.decode()}' for n,line in enumerate(lines[start-1:end],start)),end='')
manifest.write_text(json.dumps(records,indent=2)+'\n')
