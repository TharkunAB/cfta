from pathlib import Path
import json,hashlib,subprocess
r=Path('/tmp/mcfta-native-prefix-progress-20261029');root=Path('/home/tritlo/Code/mcfta');records=[]
for v in json.loads((r/'prior-documents.json').read_text()):
 p=root/v['path'];assert p.read_bytes().endswith((r/v['copy']).read_bytes())
for path in json.loads((r/'document-paths.json').read_text()):
 p=root/path;data=p.read_bytes();target=r/'final-documents'/path;target.parent.mkdir(exist_ok=True,parents=True);target.write_bytes(data);records.append(dict(path=path,copy=str(target.relative_to(r)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(r/'final-documents.json').write_text(json.dumps(records,indent=2)+'\n')
for v in json.loads((r/'final-check-map.json').read_text()):assert hashlib.sha256((root/v['path']).read_bytes()).hexdigest()==v['sha256']
# Candidate authors retain their UNTESTED reports. Final check mapping is separate.
for name,candidate,h in [('bind','bind-split/candidate-v1/MicroCFTA/SourceRecursiveIntersectionNativeBindLower.lean','f71cfea266d778ce925e7f4ee97510baa63ee03a1aeffc2ebed77c94c8b3b4e1'),('walk','edge-prefix/candidate-v1/MicroCFTA/SourceRecursiveIntersectionNativeWalkLower.lean','e94e4ab238146a3430c7c026c48e8d591d77c6abfc5e2431537fb8f91588ffea'),('edge','edge-prefix/candidate-v1/MicroCFTA/SourceRecursiveIntersectionNativeEdgePrefixLower.lean','86b26d28dc5449f9319cdea95028727727445debdd248c7994e3c4027f53e142'),('request','request-prefix/candidate-v1/MicroCFTA/SourceRecursiveIntersectionNativeRequestPrefixLower.lean','24b518688647eaa3482de2ec290a70fe024ce0cf9c06ffaa8d701d0e0c8cf081')]:
 p=r/candidate;assert hashlib.sha256(p.read_bytes()).hexdigest()==h;assert (root/'lean/MicroCFTA'/p.name).read_bytes()==p.read_bytes()
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--',*[v['path'] for v in records]],check=True)
subprocess.run(['git','commit','-m','Record native prefix bounds and checked interpreter proof frontier'],check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();(r/'docs-commit.json').write_text(json.dumps({'head':head,'old_bodies_retained':27,'current_documents':28,'full_goal':'active'},indent=2)+'\n');print(json.dumps({'docs_head':head,'current_documents':len(records),'strict_sources_unchanged':13}))
