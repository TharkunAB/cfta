# Native ordered walk and compiled edge prefix bounds

Date: 2026-10-29 20:14:56 CET.
Status: UNTESTED source-only candidates. Root owns compilation and repository edits.

Two modules and two exports are frozen in candidate-v1. Their exact complete
statements and the exact nodeIH type are copied beside this report.

walk_prefix_lower has the requested argument order. It bounds the exact
Outcome.state heap of every runtime prefix of the actual Code.walk. Its limited
and preserved callbacks receive only the checked ranges of the actual call at
its current state. No separate family of future request ranges is required.
The proof uses before_bind for the first call. After a literal successful call,
after_body with evaluation_of_done derives its actual continuation ranges.
Another before_bind derives the remaining walk's ranges at that returned state.
List induction generalizes runtime fuel because execute_bind_lower supplies
independent inner and outer runtime witnesses. The final list pure step uses
pure_lower. Both uses of execute_bind_lower preserve every outcome's exact heap.

compiled_edge_prefix_lower retains the original source Facts and Bounded limit,
original EdgeScope and semantic Completes, strong current native Valid/EdgeReady,
original growth/history, both heap invariants, and the actual compiled-code
WordRanges. It concludes Lower at the actual returned heap for every native
fuel. There is no done/value/after premise. The nodeIH has the precise requested
strict semantic-child gate and ends in all native runtime fuels.

The equal-arity branch derives each original zipped child's scope and strict
semantic rank with scope.child and immediate_requiredFuel/Immediate.edge. Each
nodeIH result is weakened to the parent's edge bound. Actual successful children
use node_return_degree_facts to derive native Valid, the exact machine Extension,
and both heap invariants at their actual returned state. Every original input
pair remains Available through that same Extension. Original growth and issued
history compose. Thus successful-child preservation is proved and is not an
extra externally supplied heap or value condition.

The actual edge compiler uses the original zipped order. walk_prefix_lower
bounds all its prefixes. execute_bind_lower then composes the final actual
makeEdge job. Its no-new-Mu premise follows directly from unchanged nodeRecords;
the local proof is `intro ... present; exact present`. The mismatch branch
uses work_lower directly on the actual empty-child edge job. Both paths include
fuel exhaustion, failed/blocked child observations, constructor pending heaps,
and observations before or after final edge construction.

The remaining nodeIH is a local semantic-rank induction hypothesis. Root must
discharge it in the final native-prefix producer. No public final claim of
closed all-native-prefix bounds or completion existence is made by this task.
There is no new runtime definition, exported predicate, custom axiom, budget
change, linter suppression, source/prepared identity cast, or future body-bound
admission. The generic walk's local preservation callbacks are fully discharged
by the concrete edge producer's actual child-return theorem.

NativeWalkLower: 54 lines, 3477 bytes, SHA256
`e94e4ab238146a3430c7c026c48e8d591d77c6abfc5e2431537fb8f91588ffea`.
NativeEdgePrefixLower: 123 lines, 9496 bytes, SHA256
`86b26d28dc5449f9319cdea95028727727445debdd248c7994e3c4027f53e142`.
Both complete candidates were reviewed without truncation. One repository Lean
source was acquired and reviewed whole, below the limit of eight. Every other
read is an exact numbered cut with a retained snapshot and full source identity.
Input hashes identify versions and do not claim whole review of partial files.
No tool output was truncated. Only candidate-v1 exists. No compiler was run and
no compiler failure is claimed. Parent status reports for imported dependencies
are recorded separately from this task's untested candidates.

Candidate-v1 and evidence-v1 are frozen on delivery. No previous frozen subtree
or repository file was changed. No compiler, evaluator, native job, Git, network,
or board operation was performed. No Haskell change was made.
