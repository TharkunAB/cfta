    edgeStep key identify after = ((edgeStep key identify before).1, after) := by
  have entry := (Cache.intern_correct before.edges key valid.1).2.1
  have later := growth.edges key _ entry
  have record := growth.edgeRecords key _ (edgeStep_correct key identify before valid).2.2
  simp only [edgeStep, Cache.intern, later, keepFirst, record, Option.getD_some]

/-- Repeated node requests reuse the complete immutable metadata record. -/
theorem nodeStep_replay (key : NodeKey) (identify : Interned NodeKey → Value Symbol Guard)
    (before after : State Symbol Guard) (valid : Valid before) (growth : Grows (nodeStep key identify before).2 after) :
    nodeStep key identify after = ((nodeStep key identify before).1, after) := by
  have entry := (Cache.intern_correct before.nodes key valid.2).2.1
  have later := growth.nodes key _ entry
  have record := growth.nodeRecords key _ (nodeStep_correct key identify before valid).2.2
  simp only [nodeStep, Cache.intern, later, keepFirst, record, Option.getD_some]

/-- Completed generated computations replay with exactly the same values, metadata, and two counters. -/
theorem replay [DecidableEq (EdgeKey Symbol Guard)] (work : Work Symbol Guard Result)
    (before after : State Symbol Guard) (valid : Valid before) (growth : Grows (run work before).2 after) :
    run work after = ((run work before).1, after) := by
  induction work generalizing before after with
  | pure value => rfl
  | edge key identify resume ih =>
