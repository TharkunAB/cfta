/-- Bounds for every inner run and every actual returned continuation bound all appended outcomes. -/
theorem execute_bind_lower
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (fuel : Nat)
    (code : Code Symbol Guard A) (next : A → Code Symbol Guard B)
    (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) (bound : Nat)
    (first : ∀ inner, Lower state.machine.heap bound
      (execute emptyGuard conjoin inner code state).state.machine.heap)
    (later : ∀ inner value current,
      execute emptyGuard conjoin inner code state = .done value current →
      ∀ outer, Lower current.machine.heap bound
        (execute emptyGuard conjoin outer (next value) current).state.machine.heap) :
    Lower state.machine.heap bound
      (execute emptyGuard conjoin fuel (code.bind next) state).state.machine.heap := by
  rcases execute_bind_state_cases emptyGuard conjoin fuel code next state with
    ⟨inner, same⟩ | ⟨inner, value, current, outer, completed, same⟩
  · rw [same]
    exact first inner
  · have accumulated : Lower state.machine.heap bound current.machine.heap := by
      simpa only [completed, Outcome.state] using first inner
    rw [same]
    exact accumulated.trans (later inner value current completed outer)

