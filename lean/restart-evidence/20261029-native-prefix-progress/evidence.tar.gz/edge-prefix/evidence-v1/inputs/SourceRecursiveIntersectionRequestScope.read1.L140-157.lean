    facts.cached.edges request.left.entry.key request.left scope.leftResident children.1 inside.1,
    facts.cached.edges request.right.entry.key request.right scope.rightResident children.2 inside.2, scope.bindings⟩

/-- Actual later reads of bound original names retain the original complete Mu payload. -/
theorem OriginalBindings.read (source current : InternedConstructorTemplates.State Symbol Guard) (facts : Facts current)
    (growth : Grows source current) (history : Extends source.nodes.issued current.nodes.issued)
    (domain : DomainKey) (bindings : OriginalBindings source domain) (name : Nat)
    (member : name ∈ SourceRecursiveIntersectionDomain.names domain) :
    ∃ value, SourcePreparedSharedRows.read current name = some value ∧ Original value ∧ Available source value ∧ inputOf value = .mu name := by
  obtain ⟨value, original, available, complete⟩ := bindings name member
  cases original <;> simp only [Value.referenceOf, IntersectionFlatMemoKey.input, Option.some.injEq, reduceCtorEq] at complete <;> try contradiction
  case mu entry body depth ordinary original =>
    cases complete
    exact ⟨.mu entry body depth ordinary,
      SourcePreparedSharedRows.read_identity current facts _ (available.grows source current growth history) entry.identity rfl,
      .mu entry body depth ordinary original, available, rfl⟩

end MicroCFTA.SourceRecursiveIntersectionCode
