/-- A completed original body retains resource checks at its actual appended continuation. -/
theorem WordRanges.after_body [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (code : Code Symbol Guard A) (next : A → Code Symbol Guard B) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (ranges : WordRanges emptyGuard conjoin (code.bind next) state) (value : A)
    (evaluated : Evaluation width Symbol Guard emptyGuard conjoin code state value after) : WordRanges emptyGuard conjoin (next value) after := by
  obtain ⟨fuel, trace⟩ := evaluated.trace
  have appended := Steps.bind emptyGuard conjoin fuel code (.pure value) state after trace next
  exact ranges.after_trace emptyGuard conjoin (code.bind next) (next value) state after fuel appended

end MicroCFTA.SourceRecursiveIntersectionNative
