import MicroCFTA.SourceRecursiveIntersectionCompileEdgeBounds
import MicroCFTA.SourceRecursiveIntersectionKernelReadback
import MicroCFTA.SourceRecursiveIntersectionKernelEdgeDegree

/-!
# Actual kernel row degree from the smaller runtime-fuel node hypothesis

The node hypothesis applies at one fixed runtime fuel.
Ordered child requests retain their original scope and strict semantic rank.
The actual trace transports both heap invariants between child calls.
-/
namespace MicroCFTA.SourceRecursiveIntersectionKernel
open Cache Binding BinderLanguage InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
