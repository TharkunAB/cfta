      intro children member
      have inside := List.of_mem_zip member
      exact ⟨valid.1.cached.edges request.left.entry.key request.left ready.2.1 children.1 inside.1,
        valid.1.cached.edges request.right.entry.key request.right ready.2.2 children.2 inside.2⟩
    have checked := children_checked (execute emptyGuard conjoin fuel) (execute_checked emptyGuard conjoin fuel)
      request.domain (request.left.children.zip request.right.children) state valid ready.1 inputs
    simp only [edge, sameArity, ite_true] at done
    cases walked : walk (fun children => execute emptyGuard conjoin fuel request.domain children.1 children.2)
        (request.left.children.zip request.right.children) state with
    | failed reason middle => simp only [walked, Result.bind] at done; cases done
    | done children middle =>
        have available := checked.result children middle walked
        obtain ⟨middleSemantic, middleOpened, childrenDegree⟩ := traceBound _ state children middle
          ((walk_done_iff _ _ _ _ _).mp walked) childBound valid ready.1 inputs growth history semantic opened
