namespace MicroCFTA.SourceRecursiveIntersectionRequestProgress
open Cache Binding BinderLanguage InternedConstructorTemplates InternedProbeProvenance
open InternedFreshProbeKeys InternedBinderProtocol InternedNestedFacts IntersectSchedule
open SourceRecursiveIntersectionInputView SourceRecursiveIntersectionSchedule IntersectionFlatMemoKeyDomain

/-- Actual physical branch children inherit finite successful execution at the preceding parent bound. -/
theorem physical_child_success [DecidableEq Symbol] (state : InternedConstructorTemplates.State Symbol Guard) (facts : Facts state)
    (holds : Guard → Language.Term Symbol → Bool) (source : DomainKey) (left right : Value Symbol Guard)
    (leftOriginal : Original left) (rightOriginal : Original right)
    (leftAvailable : Available state left) (rightAvailable : Available state right)
    (fuel : Nat) (result : Shape (Payload Symbol))
    (done : run (view state holds) (fuel + 1) (domain source) (inputOf left) (inputOf right) = .ok result)
    (child : Call Symbol) (member : child ∈ branchCalls (view state holds) (domain source) (inputOf left) (inputOf right)
      (SourceRecursiveIntersectionControl.decision source left right)) :
    ∃ output, IntersectSchedule.execute (view state holds) fuel child = .ok output := by
  apply branch_child_success (view state holds) fuel (domain source) (inputOf left) (inputOf right) _ result ?_ child member
  rw [SourceRecursiveIntersectionInputView.physical_step state facts holds fuel source left right leftOriginal rightOriginal leftAvailable rightAvailable]
  exact congrArg some done

/-- Every request of the actual physical branch strictly decreases the request's least semantic bound. -/
theorem physical_child_requiredFuel [DecidableEq Symbol] (state : InternedConstructorTemplates.State Symbol Guard) (facts : Facts state)
    (holds : Guard → Language.Term Symbol → Bool) (source : DomainKey) (left right : Value Symbol Guard)
    (leftOriginal : Original left) (rightOriginal : Original right)
    (leftAvailable : Available state left) (rightAvailable : Available state right)
    (complete : Completes (view state holds) (.node (domain source) (inputOf left) (inputOf right)))
    (child : Call Symbol) (member : child ∈ branchCalls (view state holds) (domain source) (inputOf left) (inputOf right)
