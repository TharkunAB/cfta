          ((walk_done_iff _ _ _ _ _).mp walked) childBound valid ready.1 inputs growth history semantic opened
        simp only [walked, Result.bind] at done
        obtain ⟨sameValue, sameAfter⟩ := work_done _ middle value after done
        rw [sameAfter, sameValue]
        refine ⟨SourceRecursiveIntersectionSemanticHeap.edge request.left.entry.key.symbol
          (conjoin request.left.entry.key.constraint request.right.entry.key.constraint) children middle.heap middleSemantic available,
          SourceRecursiveIntersectionOpenDepthEffects.edge request.left.entry.key.symbol
            (conjoin request.left.entry.key.constraint request.right.entry.key.constraint) children middle.heap middleOpened, ?_⟩
        rw [InternedShallowValues.makeEdge_children request.left.entry.key.symbol
          (conjoin request.left.entry.key.constraint request.right.entry.key.constraint) children middle.heap
          middleSemantic.1.normal.facts.coherent middleSemantic.1.normal.facts.cached available]
        exact childrenDegree
  · obtain ⟨afterSemantic, afterOpened, zero⟩ := edge_mismatched_degree emptyGuard conjoin
      (execute emptyGuard conjoin fuel request.domain) request.left request.right state after value sameArity semantic opened done
