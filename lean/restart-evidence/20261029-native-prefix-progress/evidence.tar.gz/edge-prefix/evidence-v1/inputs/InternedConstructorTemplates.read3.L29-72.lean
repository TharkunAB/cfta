/-- Stored edge records retain the canonical key and complete immutable child records. -/
inductive EdgeValue (Symbol Guard : Type) where
  | mk (entry : Interned (EdgeKey Symbol Guard)) (children : List (Value Symbol Guard))
end

/-- Node equality observes only the constructor tag and its canonical identity. -/
def Value.referenceOf : Value Symbol Guard → NodeRef
  | .empty => .empty
  | .reference name => .ref name
  | .node entry _ _ _ => .node entry.identity
  | .union entry _ _ _ => .union entry.identity
  | .mu entry _ _ _ => .mu entry.identity

/-- Read the cached depth; only Mu adds one to its stored body's depth. -/
def Value.depth : Value Symbol Guard → Nat
  | .empty | .reference _ => 0
  | .node _ _ depth _ | .union _ _ depth _ => depth
  | .mu _ body _ _ => body.depth + 1

/-- Read cached free references and remove the local reference of a Mu. -/
def Value.free : Value Symbol Guard → List Reference
  | .empty => []
  | .reference name => [name]
  | .node _ _ _ free | .union _ _ _ free => free
  | .mu entry body _ _ => body.free.filter (· != .interned entry.identity)

def EdgeValue.entry : EdgeValue Symbol Guard → Interned (EdgeKey Symbol Guard)
  | .mk entry _ => entry

def EdgeValue.children : EdgeValue Symbol Guard → List (Value Symbol Guard)
  | .mk _ children => children

/-- Separate canonical counters plus immutable first-writer record payloads. -/
structure State (Symbol Guard : Type) where
  edges : Cache.State (EdgeKey Symbol Guard)
  nodes : Cache.State NodeKey
  edgeRecords : Table (EdgeKey Symbol Guard) (EdgeValue Symbol Guard)
  nodeRecords : Table NodeKey (Value Symbol Guard)

/-- Both source cache families and both record maps start empty. -/
def empty : State Symbol Guard := ⟨Cache.emptyState, Cache.emptyState, fun _ => none, fun _ => none⟩

/-- Every counter retains its own reservation and canonical-key invariant. -/
def Valid (state : State Symbol Guard) : Prop := Cache.Valid state.edges ∧ Cache.Valid state.nodes
