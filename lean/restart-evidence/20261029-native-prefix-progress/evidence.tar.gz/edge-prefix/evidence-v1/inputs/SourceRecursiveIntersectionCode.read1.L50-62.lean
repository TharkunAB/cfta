    simp only [Code.bind, ih]
  | finishNode handle value rest ih | finishEdge handle value rest ih => simp only [Code.bind, ih]

/-- Keep each list request before the next request and the final continuation. -/
def walk (call : A → Code Symbol Guard B) : List A → Code Symbol Guard (List B)
  | [] => .pure []
  | first :: rest => (call first).bind fun value => (walk call rest).bind fun values => .pure (value :: values)

/-- One physical node callback receives its complete captured request. -/
abbrev NodeCall (Symbol Guard : Type) := NodeRequest Symbol Guard → Machine Symbol Guard → Result Symbol Guard (Value Symbol Guard)

/-- One physical edge callback receives its complete captured row request. -/
abbrev EdgeCall (Symbol Guard : Type) := EdgeRequest Symbol Guard → Machine Symbol Guard → Result Symbol Guard (EdgeValue Symbol Guard)
