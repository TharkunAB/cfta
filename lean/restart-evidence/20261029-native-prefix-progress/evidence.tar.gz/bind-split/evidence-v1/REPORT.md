# Native bind state split and Lower composition

Date: 2026-10-29 20:08:30 CET.
Status: UNTESTED source-only candidate. Root owns compilation and repository operations.

The candidate exports execute_bind_state_cases and execute_bind_lower.
The first theorem gives exactly the requested disjunction. The actual bound-code
endpoint equals an actual inner-code endpoint, or it equals an actual continuation
endpoint after a literal completed inner call. Each equality retains the full
native state, including the machine, node memos, and edge memos. It applies to
yielded, done, failed, and every blocked reason. It requires no source safety,
request scope, semantic rank, returned result, or completed body premise.

The state split uses natural induction on fuel. Zero fuel chooses inner 0.
A yielded step uses step_bind/appendStep and the actual first-step equation,
then lifts the inner witness by one. Failed and blocked steps choose inner 1.
A done step uses step_done_iff to derive literal pure code and the same state;
it chooses an actual inner DONE at fuel 1 and continuation runtime fuel + 1.
The witnesses have no asserted fuel comparison. The pure-code case explains
why a same-runtime decomposition is unnecessary for the requested observer.

execute_bind_lower takes emptyGuard, conjoin, fuel, code, next, state, bound,
then the first and later hypotheses. first bounds every actual inner runtime.
later bounds every continuation runtime only after the supplied literal inner
DONE equation. In the first state case, full-state equality transfers first.
In the second case, the literal DONE equation identifies the inner endpoint,
and Lower.trans composes first with later at the same fixed bound.

These are local generic composition hypotheses. The final original-input
native-prefix theorem must discharge both by its induction. This candidate
does not assume or establish a global body-bound family, a model, a successful
completion, or the final stopped-prefix theorem. It adds no runtime definition
or predicate. It preserves the exact failed or blocked reached states.

The candidate has 69 lines and 4027 bytes. SHA256:
`f71cfea266d778ce925e7f4ee97510baa63ee03a1aeffc2ebed77c94c8b3b4e1`.
It was read whole without truncation. Both complete public statements are copied
as text artifacts beside this report. Zero repository Lean files were acquired
whole. All five input files were read only in the exact numbered cuts recorded
in manifest.json. The full input hashes identify their source versions; they
do not claim a whole-file review. No tool output was truncated.

Only candidate-v1 exists. No compiler was run and no compiler failure is claimed.
Candidate and evidence are frozen on delivery. No earlier frozen subtree or
repository file was changed. No compiler, evaluator, native job, Git, network,
or board operation was performed. No Haskell change, placeholder, axiom, budget
change, or linter suppression was added.
