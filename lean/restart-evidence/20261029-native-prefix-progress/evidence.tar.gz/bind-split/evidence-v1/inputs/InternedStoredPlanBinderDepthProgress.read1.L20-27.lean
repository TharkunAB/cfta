/-- Each complete Mu is an exact initial record or has body depth below the fixed source bound. -/
def Lower (initial : State Symbol Guard) (bound : Nat) (state : State Symbol Guard) : Prop :=
  ∀ key entry body depth ordinary, state.nodeRecords key = some (.mu entry body depth ordinary) →
    initial.nodeRecords key = some (.mu entry body depth ordinary) ∨ valueDepth body < bound

variable {initial : State Symbol Guard} {bound : Nat}

/-- Every initial record retains its own exact payload. -/
