import MicroCFTA.SourceRecursiveIntersectionNativeContinuation

/-!
# Finite native execution traces

Traces contain actual yielded steps and their exact intermediate source and
memo caches. They characterize bounded execution and compose with retained
continuations. A completed run reaches its returned pure value after a finite
trace. This does not prove that every request completes.
-/
namespace MicroCFTA.SourceRecursiveIntersectionNative
open Cache InternedConstructorTemplates InternedBinderProtocol IntersectionFlatMemoKeyDomain
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode

