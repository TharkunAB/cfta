from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/tritlo/Code/mcfta');r=Path('/tmp/mcfta-native-prefix-progress-20261029')
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='formalize'
checks={}
for label in ['lean','strong','haskell']:
 rows=json.loads((r/f'prior-{label}-sources.json').read_text())
 for v in rows:
  p=root/v['path'];data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==v['sha256'],p
  if 'bytes' in v:assert len(data)==v['bytes'],p
 checks[label+'_identities_unchanged']=len(rows)
modules=json.loads((r/'modules.json').read_text());records=[]
for module in modules+['Audit']:
 p=root/'lean/MicroCFTA'/(module+'.lean');data=p.read_bytes();h=hashlib.sha256(data).hexdigest();matches=[]
 for q in r.glob('*/report.json'):
  v=json.loads(q.read_text());cmd=v['command']
  if v.get('source_sha256')==h and v['exit_code']==0 and '-R' in cmd and Path(cmd[-1]).stem==module:matches.append(q.parent.name)
 assert matches,module
 target=r/'final-sources'/p.name;target.parent.mkdir(exist_ok=True);target.write_bytes(data)
 records.append(dict(module=module,path=str(p.relative_to(root)),copy=str(target.relative_to(r)),bytes=len(data),sha256=h,strict_checks=matches))
(r/'final-check-map.json').write_text(json.dumps(records,indent=2)+'\n')
snapshots=0
for q in r.glob('*/inputs.json'):
 for v in json.loads(q.read_text()):
  p=q.parent/'input-sources'/(v['module']+'.lean');assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'],p;snapshots+=1
checks['command_input_snapshots_match']=snapshots
reports=[json.loads(q.read_text()) for q in r.glob('*/report.json')];checks.update(compiler_commands=len(reports),pass_count=sum(v['exit_code']==0 for v in reports),fail_count=sum(v['exit_code']!=0 for v in reports),strict_sources=len(records))
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes().endswith((r/'prior-Audit.lean').read_bytes())
for old in ['/tmp/mcfta-native-degree-progress-20261029','/tmp/mcfta-kernel-lower-progress-20261029']:
 area=Path(old);seal=json.loads((area/'FROZEN.json').read_text())
 for v in seal['payloads']:
  p=area/v['path'];assert p.stat().st_size==v['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'],p
checks['old_sealed_areas_unchanged']=2
prior=json.loads(Path('/tmp/mcfta-kernel-lower-progress-20261029/final-documents.json').read_text());docs=[]
for v in prior:
 p=root/v['path'];data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==v['sha256'];target=r/'prior-document-bodies'/v['path'];target.parent.mkdir(exist_ok=True,parents=True);target.write_bytes(data);docs.append(dict(path=v['path'],copy=str(target.relative_to(r)),bytes=len(data),sha256=v['sha256']))
(r/'prior-documents.json').write_text(json.dumps(docs,indent=2)+'\n')
(r/'verification.json').write_text(json.dumps(checks,indent=2)+'\n')
review=json.loads((r/'public-review-ranges.json').read_text());review.update(all_new_bytes_read=True,output_truncated=False,total_public_checks=912,old_definition_bodies=73);(r/'public-review-verification.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(checks))
groups=[(['SourceRecursiveIntersectionNativeBindLower','SourceRecursiveIntersectionNativePrimitiveLower','SourceRecursiveIntersectionNativeReturnDegreeFacts','SourceRecursiveIntersectionNativeWalkLower'],'Bound native sequencing and primitive allocation observations'),(['SourceRecursiveIntersectionNativeMuPrefixLower','SourceRecursiveIntersectionNativeUnionPrefixLower','SourceRecursiveIntersectionNativeRowsPrefixLower','SourceRecursiveIntersectionNativeEdgePrefixLower'],'Derive native branch body bounds from original child ranks'),(['SourceRecursiveIntersectionNativeRequestPrefixLower','SourceRecursiveIntersectionNativeNodePrefixLower','SourceRecursiveIntersectionNativePrefixLower','SourceRecursiveIntersectionNativeClosedPrefixLower','Audit'],'Close original-input bounds for every native intersection outcome')]
commits=[]
subprocess.run(['git','diff','--check'],check=True)
for members,message in groups:
 subprocess.run(['git','add','--',*[str(Path('lean/MicroCFTA')/(m+'.lean')) for m in members]],check=True)
 subprocess.run(['git','commit','-m',message],check=True)
 commits.append({'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'message':message})
(r/'source-commits.json').write_text(json.dumps(commits,indent=2)+'\n');print(json.dumps(commits))
