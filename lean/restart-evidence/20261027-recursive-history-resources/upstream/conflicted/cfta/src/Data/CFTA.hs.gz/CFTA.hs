{-# LANGUAGE DeriveFunctor #-}

{- | Ordinary finite-state tree automata.

An FTA has a finite set of states and ranked transitions. Each transition has
an annotation of the type @constraint@. A 'PlainFTA' is an FTA with
'Constraint' annotations, and an interned automaton converts to and from one.
An ordinary FTA has 'noConstraint' on every transition. A layer can use another
annotation type for its own data, such as the refinement of a constructor.

Cycles are valid and describe infinite tree languages. Consumers that require
a finite language can inspect 'cycleState'. 'intersect' constructs the standard
reachable product; 'intersectWith' lets a constraint layer decide how matching
symbols and transition annotations combine.
-}
module Data.CFTA (
    FTA,
    PlainFTA,
    ProductState (..),
    Transition (..),
    FTAError (..),
    initialState,
    transitionTable,
    mkFTA,
    replaceRows,
    fromTerms,
    states,
    transitionsFrom,
    cyclicStates,
    cycleState,
    mapConstraints,
    mapSymbols,
    mapStates,
    trim,
    annotate,
    dropConstraints,
    boundDepth,
    intersect,
    intersectWith,
    accepts,
    acceptsM,
    statesAt,
    terms,
    termsUpToM,
    termsByCost,
    ViewPath,
    ViewStep (..),
    StateView (..),
    toTree,
) where

import Control.Monad (foldM_)
import qualified Control.Monad.State.Strict as State
import qualified Data.Bifunctor as Bifunctor
import Data.Functor.Identity (Identity (..))
import Data.Graph (SCC (CyclicSCC), stronglyConnComp)
import Data.Hashable (Hashable)
import Data.List ((!?))
import Data.Map.Strict (Map)
import qualified Data.Map.Strict as Map
import Data.Maybe (maybeToList)
import qualified Data.Set as Set
import qualified Data.Tree as Tree

import Data.CFTA.Constraint (Constraint, equalitiesHold, noConstraint)
import Data.CFTA.Index (Arity (..), Depth (..))
import Data.CFTA.Internal.Tree (
    StateView (..),
    ViewPath,
    ViewStep (..),
    acceptsBy,
    explore,
    termsBy,
    termsByCostBy,
    termsUpToBy,
    toTreeBy,
    trimRows,
 )
import Data.CFTA.Path (ChildIndex (..), Path (ConsPath, EmptyPath))
import Data.CFTA.Term (Term)
import qualified Data.CFTA.Term as Term

-- | One ranked transition from a parent state to child states.
data Transition state symbol constraint = Transition
    { transitionSymbol :: !symbol
    -- ^ Constructor at the root of this transition.
    , transitionChildren :: ![state]
    -- ^ States accepting the constructor arguments, from left to right.
    , transitionConstraint :: !constraint
    -- ^ The transition annotation; 'noConstraint' for an ordinary FTA.
    }
    deriving (Eq, Show, Functor)

-- | A validated finite-state tree automaton with one initial state.
data FTA state symbol constraint = FTA
    { initialState :: !state
    -- ^ State from which whole-term recognition starts.
    , transitionTable :: !(Map state [Transition state symbol constraint])
    -- ^ Complete outgoing-transition rows, keyed by parent state.
    }
    deriving (Eq, Show, Functor)

-- | An FTA whose annotations are 'Constraint's. An ordinary FTA has 'noConstraint' on every transition.
type PlainFTA state symbol = FTA state symbol Constraint

-- | A state in the product of two tree automata.
data ProductState left right = ProductState
    { productLeftState :: !left
    -- ^ State contributed by the left automaton.
    , productRightState :: !right
    -- ^ State contributed by the right automaton.
    }
    deriving (Eq, Ord, Show)

-- | A structural error found while constructing an FTA.
data FTAError state symbol
    = -- | The initial state has no row in the transition table.
      MissingInitialState !state
    | -- | A transition refers to a state with no row.
      DanglingState !state
    | -- | The same alphabet symbol occurs at two different arities.
      InconsistentArity
        -- | The symbol.
        !symbol
        -- | The arity found first.
        !Arity
        -- | The other arity.
        !Arity
    deriving (Eq, Show)

{- | Expose the reachable grammar as a finite tree of typed labels.

'Left' labels contain state definitions or references. 'Right' labels contain
the original transitions, including symbols, child states, and annotations.
Each 'Left' label also retains its 'viewPath' from the root of this view. A
'Right' label does not.
Use @fmap (either renderState renderTransition)@ to prepare a tree for
'Tree.drawTree'. Each state is expanded once, so sharing and recursion keep
the view finite. This operation does not enumerate terms or interpret constraints.
-}
toTree ::
    (Ord state) =>
    FTA state symbol constraint -> Tree.Tree (Either (StateView state) (Transition state symbol constraint))
toTree automaton = toTreeBy (transitionsFrom automaton) transitionChildren $ initialState automaton

-- | Validate and construct an FTA. Cyclic automata are accepted.
mkFTA ::
    (Ord state, Ord symbol) =>
    state ->
    [(state, [Transition state symbol constraint])] ->
    Either (FTAError state symbol) (FTA state symbol constraint)
mkFTA initial rows = validateFTA $ FTA initial $ Map.fromListWith (flip (<>)) rows

{- | Replace or remove rows in one batch. A 'Just' row adds or replaces its
state. 'Nothing' removes a state; removing a missing state has no effect.
An empty row retains its state. The initial state stays the same.

The result shares unchanged rows with the input. Validation checks the whole
result after all edits, so a batch can add a state and references to it
together. An invalid result returns the same errors as 'mkFTA'. The input
automaton stays unchanged. An edit can change the language and its ranks.
-}
replaceRows ::
    (Ord state, Ord symbol) =>
    Map state (Maybe [Transition state symbol constraint]) ->
    FTA state symbol constraint ->
    Either (FTAError state symbol) (FTA state symbol constraint)
replaceRows edits automaton
    | Map.null edits = Right automaton
    | otherwise = validateFTA automaton{transitionTable = Map.foldlWithKey' replace (transitionTable automaton) edits}
  where
    replace table state Nothing = Map.delete state table
    replace table state (Just row) = Map.insert state row table

-- | Check an explicit graph without rebuilding its row map.
validateFTA ::
    (Ord state, Ord symbol) =>
    FTA state symbol constraint -> Either (FTAError state symbol) (FTA state symbol constraint)
validateFTA automaton@FTA{initialState = initial, transitionTable = rows} = do
    ensureInitial rows
    ensureClosed rows
    ensureRanked rows
    pure automaton
  where
    ensureInitial table
        | Map.member initial table = Right ()
        | otherwise = Left (MissingInitialState initial)

    ensureClosed table =
        case [ child
             | outgoing <- Map.elems table
             , transition <- outgoing
             , child <- transitionChildren transition
             , Map.notMember child table
             ] of
            dangling : _ -> Left (DanglingState dangling)
            [] -> Right ()

    ensureRanked table = foldM_ rememberArity Map.empty (concat $ Map.elems table)
      where
        rememberArity arities transition =
            let symbol = transitionSymbol transition
                arity = Arity (length (transitionChildren transition))
             in case Map.lookup symbol arities of
                    Nothing -> Right (Map.insert symbol arity arities)
                    Just expected
                        | expected == arity -> Right arities
                        | otherwise -> Left (InconsistentArity symbol expected arity)

{- | Build the exact finite language of a list of terms.

Equal subterms share one state. The initial state contains the complete terms.
Duplicate terms are removed and alternatives use ascending term order.
-}
fromTerms ::
    (Ord symbol) =>
    [Term symbol] ->
    Either (FTAError (Maybe (Term symbol)) symbol) (PlainFTA (Maybe (Term symbol)) symbol)
fromTerms input =
    mkFTA Nothing $
        (Nothing, map transition distinct)
            : [(Just term, [transition term]) | term <- Set.toList $ Set.fromList $ concatMap subterms distinct]
  where
    distinct = Set.toList $ Set.fromList input
    transition (Term.Node symbol children) = Transition symbol (map Just children) noConstraint
    subterms term@(Term.Node _ children) = term : concatMap subterms children

-- | All states in ascending key order.
states :: FTA state symbol constraint -> [state]
states = Map.keys . transitionTable

-- | Outgoing alternatives of one state.
transitionsFrom :: (Ord state) => FTA state symbol constraint -> state -> [Transition state symbol constraint]
transitionsFrom automaton state =
    Map.findWithDefault [] state (transitionTable automaton)

-- | Find one state on a cycle, if the automaton is cyclic.
cycleState :: (Ord state) => FTA state symbol constraint -> Maybe state
cycleState = Set.lookupMin . cyclicStates

{- | All states that participate in a dependency cycle.

A singleton strongly connected component is cyclic only when it has a direct
self-edge. This is useful to consumers such as LTAs, which permit recursive
languages but restrict what constraints may inspect inside them.
-}
cyclicStates :: (Ord state) => FTA state symbol constraint -> Set.Set state
cyclicStates automaton =
    Set.fromList $ concat [component | CyclicSCC component <- components]
  where
    components = stronglyConnComp $ map dependencyNode (states automaton)
      where
        dependencyNode state =
            ( state
            , state
            , [ child
              | transition <- transitionsFrom automaton state
              , child <- transitionChildren transition
              ]
            )

-- | Change constructor labels and check that the result stays ranked.
mapSymbols ::
    (Ord state, Ord other) =>
    (symbol -> other) -> FTA state symbol constraint -> Either (FTAError state other) (FTA state other constraint)
mapSymbols transform FTA{initialState, transitionTable} =
    mkFTA initialState [(state, map transition outgoing) | (state, outgoing) <- Map.toList transitionTable]
  where
    transition Transition{transitionSymbol, transitionChildren, transitionConstraint} =
        Transition (transform transitionSymbol) transitionChildren transitionConstraint

{- | Rename states.

States that map to one name are merged, and the merged state has the
alternatives of all of them.
-}
mapStates :: (Ord other) => (state -> other) -> FTA state symbol constraint -> FTA other symbol constraint
mapStates rename automaton =
    FTA (rename $ initialState automaton) $
        Map.fromListWith
            (flip (<>))
            [ (rename state, [transition{transitionChildren = map rename $ transitionChildren transition} | transition <- outgoing])
            | (state, outgoing) <- Map.toList $ transitionTable automaton
            ]

{- | Remove states that accept nothing and states the initial state cannot reach.

Alternatives with a removed child state are removed with them. The initial
state keeps a row, which is empty when the language is empty.
-}
trim :: (Ord state) => FTA state symbol constraint -> FTA state symbol constraint
trim automaton =
    FTA initial
        $ Map.insertWith (\_ kept -> kept) initial []
        $ trimRows transitionChildren (Map.toList $ transitionTable automaton) initial
  where
    initial = initialState automaton

-- | Change transition annotations without changing the accepted tree shapes.
mapConstraints :: (constraint -> other) -> FTA state symbol constraint -> FTA state symbol other
mapConstraints = fmap

{- | Set transition annotations with access to their state and constructor.

The graph structure remains unchanged. Constraint layers can interpret the
result without defining its states and transitions again.
-}
annotate ::
    (state -> Transition state symbol constraint -> other) -> FTA state symbol constraint -> FTA state symbol other
annotate transform automaton =
    automaton{transitionTable = Map.mapWithKey (map . annotateTransition) (transitionTable automaton)}
  where
    annotateTransition state transition = transition{transitionConstraint = transform state transition}

-- | Forget transition annotations, yielding an ordinary FTA.
dropConstraints :: FTA state symbol constraint -> PlainFTA state symbol
dropConstraints = (noConstraint <$)

{- | Retain terms whose leaves are at most the given depth from the root.

A leaf has depth zero. A negative bound produces an empty initial state.
Equal state-depth pairs share one row. The result has consecutive integer
states. A state that has no transition within its remaining depth keeps an
empty row; the interned import removes such dead alternatives. Labels, constraints, and transition order remain unchanged.
-}
boundDepth :: (Ord state) => Depth -> FTA state symbol constraint -> FTA Int symbol constraint
boundDepth maximumDepth automaton
    | maximumDepth < 0 = FTA 0 $ Map.singleton 0 []
    | otherwise =
        let (initial, (_, rows)) = State.runState (buildState (initialState automaton, maximumDepth)) (Map.empty, Map.empty)
         in FTA initial rows
  where
    buildState key@(source, remaining) = do
        (names, _) <- State.get
        case Map.lookup key names of
            Just state -> pure state
            Nothing -> do
                let state = Map.size names
                State.modify' $ \(_, rows) -> (Map.insert key state names, rows)
                outgoing <-
                    traverse (buildTransition remaining)
                        $ filter (\transition -> remaining > 0 || null (transitionChildren transition))
                        $ transitionsFrom automaton source
                State.modify' $ Bifunctor.second (Map.insert state outgoing)
                pure state
    buildTransition remaining Transition{transitionSymbol, transitionChildren, transitionConstraint} = do
        children <- traverse (\child -> buildState (child, remaining - 1)) transitionChildren
        pure $ Transition transitionSymbol children transitionConstraint

{- | Intersect two automata with the same ranked alphabet.

Only reachable product states are constructed. Transition annotations from the
two operands are paired; use 'intersectWith' when the constraint theory has a
more useful way to combine them. Applying 'dropConstraints' to the result of two
plain FTAs recovers a 'PlainFTA'.
-}
intersect ::
    (Ord leftState, Ord rightState, Ord symbol) =>
    FTA leftState symbol leftConstraint ->
    FTA rightState symbol rightConstraint ->
    Either
        (FTAError (ProductState leftState rightState) symbol)
        (FTA (ProductState leftState rightState) symbol (leftConstraint, rightConstraint))
intersect = intersectWith sameSymbol (,)
  where
    sameSymbol left right
        | left == right = Just left
        | otherwise = Nothing

{- | Product intersection with explicit symbol matching and constraint composition.

The symbol callback returns the result label for compatible transitions and
'Nothing' for disjoint ones. Children are intersected position by position.
The result is validated because a callback may map differently ranked input
symbols to the same output symbol.
-}
intersectWith ::
    (Ord leftState, Ord rightState, Ord resultSymbol) =>
    (leftSymbol -> rightSymbol -> Maybe resultSymbol) ->
    (leftConstraint -> rightConstraint -> resultConstraint) ->
    FTA leftState leftSymbol leftConstraint ->
    FTA rightState rightSymbol rightConstraint ->
    Either
        (FTAError (ProductState leftState rightState) resultSymbol)
        (FTA (ProductState leftState rightState) resultSymbol resultConstraint)
intersectWith matchSymbol combineConstraint left right =
    mkFTA initial $ explore intersectState transitionChildren initial
  where
    initial = ProductState (initialState left) (initialState right)

    intersectState (ProductState leftState rightState) =
        [ Transition
            resultSymbol
            (zipWith ProductState leftChildren rightChildren)
            (combineConstraint leftConstraint rightConstraint)
        | Transition leftSymbol leftChildren leftConstraint <- transitionsFrom left leftState
        , Transition rightSymbol rightChildren rightConstraint <- transitionsFrom right rightState
        , length leftChildren == length rightChildren
        , Just resultSymbol <- [matchSymbol leftSymbol rightSymbol]
        ]

{- | Decide whether an automaton accepts a concrete term. The path equalities
of each constraint are checked, as 'Data.CFTA.Equality.accepts' checks them. A
residual guard beyond the equalities is not decided; use 'acceptsM' for it.
This is 'acceptsM' with 'equalitiesHold' as the check.
-}
accepts :: (Ord state, Eq symbol) => PlainFTA state symbol -> Term symbol -> Bool
accepts automaton = runIdentity . acceptsM check automaton
  where
    check _ transition term = Identity $ equalitiesHold (transitionConstraint transition) term

{- | Every accepted term, ordered by depth and produced lazily.

A leaf has depth zero, and all terms of one depth precede deeper terms. A
cyclic automaton gives an infinite list; an acyclic automaton gives a finite
one. Each term appears once, even when several runs accept it. Constraints are
not interpreted: the list describes the underlying ordinary automaton. Use
'termsUpToM' to decide constraints while enumerating.
-}
terms :: (Ord state, Ord symbol, Hashable symbol) => FTA state symbol constraint -> [Term symbol]
terms automaton =
    termsBy
        [ (state, [(transitionSymbol transition, transitionChildren transition) | transition <- outgoing])
        | (state, outgoing) <- Map.toList (transitionTable automaton)
        ]
        (initialState automaton)

{- | The terms of depth at most the bound that a check accepts.

The check sees each candidate term once, with the state and transition that
built it, so a constraint theory can decide a constraint as soon as the children
are complete. A rejected candidate is never used as a child. A leaf has
depth zero. Each state lists a term once per depth, so an ambiguous
automaton does not repeat terms.
-}
termsUpToM ::
    (Monad m, Ord state, Ord symbol, Hashable symbol) =>
    (state -> Transition state symbol constraint -> Term symbol -> m Bool) ->
    Depth ->
    FTA state symbol constraint ->
    m [Term symbol]
termsUpToM accept bound automaton =
    termsUpToBy
        transitionSymbol
        transitionChildren
        accept
        (Map.toList $ transitionTable automaton)
        bound
        (initialState automaton)

{- | The accepted terms in the order of a cost, cheapest first, each with its
cost, produced lazily.

The cost of a term comes from its symbol and the costs of its children, as
for an extraction, such as the size or a sum of weights. It must not decrease
when the cost of a child grows, and it must be at least the cost of each
child, so that each state has a least cost. Then the costs of the list never
decrease, also for a cyclic automaton, whose list is infinite. The terms of
one cost come in a fixed order. A transition with a constraint gives only the
terms that satisfy its path equalities. A term with two runs comes twice.

<<<<<<< HEAD
An infinite set of cheaper rejected candidates can prevent the next term from
being reached. A sufficient progress condition is that each cost bound admits
only finitely many generated partial terms.
=======
A search reaches each term when each cost bound admits only finitely many
partial terms, as for natural numbers and @1 + sum@. A cost type without
this condition, such as a lexicographic pair, can put an infinite number of
cheaper partial terms whose terms fail their constraints before a term that
satisfies them, and then the search does not reach that term.
>>>>>>> origin/main
-}
termsByCost :: (Ord state, Eq symbol, Ord c) => (symbol -> [c] -> c) -> PlainFTA state symbol -> [(c, Term symbol)]
termsByCost cost automaton =
    termsByCostBy
        (transitionsFrom automaton)
        transitionSymbol
        transitionChildren
        (equalitiesHold . transitionConstraint)
        (cost . transitionSymbol)
        (`Map.lookup` leastCosts cost automaton)
        (initialState automaton)

{- | The least cost of the terms of each state that has terms: the fixed point
of an evaluation from the leaves up, as Bellman and Ford relax the edges of a
graph. The constraints are not interpreted, so the cost of a state with a
constraint is a lower bound.
-}
leastCosts :: (Ord state, Ord c) => (symbol -> [c] -> c) -> FTA state symbol constraint -> Map state c
leastCosts cost automaton = go Map.empty
  where
    go known =
        let step =
                Map.fromListWith
                    min
                    [ (state, cost (transitionSymbol transition) children)
                    | (state, outgoing) <- Map.toList (transitionTable automaton)
                    , transition <- outgoing
                    , Just children <- [traverse (`Map.lookup` known) (transitionChildren transition)]
                    ]
            known' = Map.unionWith min known step
         in if known' == known then known else go known'

{- | Decide whether an automaton accepts a term, with a check on each matching transition.

The check sees the state, the transition, and the complete term at that
position, so a constraint theory can decide a constraint there. It runs only
after the children have been accepted, and only for transitions whose
symbol and arity match the term. The term is accepted when some transition
matches and passes the check. The transitions of a state are tried in order,
and the children from left to right. When the search comes to a subterm again
with the same state, it uses the first result. So the check runs at most once
for each state, transition, and position in the term.
-}
acceptsM ::
    (Monad m, Ord state, Eq symbol) =>
    (state -> Transition state symbol constraint -> Term symbol -> m Bool) ->
    FTA state symbol constraint ->
    Term symbol ->
    m Bool
acceptsM check automaton =
    acceptsBy (transitionsFrom automaton) transitionSymbol transitionChildren check (initialState automaton)

{- | The states at a child-index path below a transition of an explicit-state automaton.

The function gives the alternatives of a state: pass @'FTA.transitionsFrom'
automaton@ for an automaton, or a lookup in a bare transition table. The
first index selects a child state of the transition; each further index
selects that child of every alternative of the states reached so far. A
state is listed once per alternative that reaches it. An empty path gives
no states.
-}
statesAt :: (state -> [Transition state symbol constraint]) -> Transition state symbol constraint -> Path -> [state]
statesAt _ _ EmptyPath = []
statesAt alternatives transition (ConsPath (ChildIndex index) rest) = descend rest (maybeToList $ transitionChildren transition !? index)
  where
    descend EmptyPath current = current
    descend (ConsPath (ChildIndex next) further) current =
        descend
            further
            [ child
            | state <- current
            , outgoing <- alternatives state
            , Just child <- [transitionChildren outgoing !? next]
            ]
