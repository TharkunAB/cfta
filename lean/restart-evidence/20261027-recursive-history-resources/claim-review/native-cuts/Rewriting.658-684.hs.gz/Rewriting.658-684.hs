weight 1, and an application is the binary symbol app.
-}
weight :: Term -> Int
weight (Term "app" [_, f, v]) = 1 + weight f + weight v
weight _ = 1

{- | The number of leaves of a term, which is the size of a term in the
search.
-}
leaves :: Term -> Int
leaves (Term "app" [_, f, v]) = leaves f + leaves v
leaves _ = 1

-- | The sum of the weights of definition of the leaves of a term (see 'TermOrder').
definitionWeight :: Map Symbol Int -> Term -> Int
definitionWeight defined t
    | Map.null defined = 0
    | otherwise = go t
  where
    go (Term "app" [_, f, v]) = go f + go v
    go (Term s _) = Map.findWithDefault 0 s defined

-- | Compare the weights of two terms, then their weights of definition.
heavier :: Map Symbol Int -> Term -> Term -> Ordering
heavier defined s t =
    compare (weight s) (weight t) <> compare (definitionWeight defined s) (definitionWeight defined t)

