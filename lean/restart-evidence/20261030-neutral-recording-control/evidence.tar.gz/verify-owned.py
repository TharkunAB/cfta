from pathlib import Path
import hashlib
import json
import sys

r = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/tmp/mcfta-neutral-recording-control-20261030')
out = Path(sys.argv[2]) if len(sys.argv) > 2 else r
out.mkdir(exist_ok=True)
owner = r / 'capacity-review'
def sha(data):
    return hashlib.sha256(data).hexdigest()
assert sha((owner / 'MANIFEST.json').read_bytes()) == '6c6650efed971e970721573e6fb8bf43a6ac135173e104f0e13120eaf1f2d2ad'
assert sha((owner / 'pins.json').read_bytes()) == 'fce4b4b9fd90b8d9c5426467d75c77b2b931d2eca45608415729813f2d95810d'
manifest = json.loads((owner / 'MANIFEST.json').read_text())
rows = manifest['files']
actual = {str(p.relative_to(owner)) for p in owner.rglob('*') if p.is_file()}
assert actual == {a['path'] for a in rows} | {'MANIFEST.json', 'pins.json'}
for a in rows:
    p = owner / a['path']
    data = p.read_bytes()
    assert not p.is_symlink() and not (p.stat().st_mode & 0o222)
    assert len(data) == a['bytes'] and sha(data) == a['sha256']
assert all(not (p.stat().st_mode & 0o222) for p in owner.rglob('*') if p.is_file())
for leaf, expected in json.loads((owner / 'pins.json').read_text())['pins'].items():
    assert sha((owner / leaf).read_bytes()) == expected, leaf
count = 0
for ledger in ['acquisitions.json', 'bounded-acquisitions.json', 'reuse-ledger.json']:
    for a in json.loads((owner / ledger).read_text()):
        source = Path(a['source_path'])
        if not source.is_relative_to('/home/tritlo/Code/mcfta'):
            assert source.name == 'REPORT.md'
            source = r / 'prior-source-reports/ordinary-renewal.md'
        data = source.read_bytes()
        copy = (owner / a['copy']).read_bytes()
        assert len(data) == a['source_bytes'] and sha(data) == a['source_sha256']
        assert sha(copy) == a['copy_sha256']
        lines = data.splitlines(keepends=True)
        if 'actual' in a:
            start, end = a['actual']
            expected_copy = b''.join(lines[start - 1:end])
        else:
            expected_copy = b''.join(lines[index - 1] for index in a['actual_lines'])
        assert copy == expected_copy
        if 'frozen_bundle' in a:
            encoded = (r / 'prior-owner-manifests/expansion-MANIFEST.json').read_bytes()
            assert sha(encoded) == a['frozen_manifest_sha256']
            frozen = next(row for row in json.loads(encoded)['files'] if row['path'] == a['frozen_copy'])
            assert len(data) == frozen['bytes'] and sha(data) == frozen['sha256']
        count += 1
assert count == 42
result = {'status': 'pass', 'payloads': len(rows), 'regular_files': len(actual),
          'current_source_and_historical_copies': count, 'readonly': True,
          'root_full_report_and_candidate_read': True}
(out / 'owned-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
