from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json
import subprocess

r = Path('/tmp/mcfta-neutral-recording-control-20261030')
root = Path('/home/tritlo/Code/mcfta')
assert not (r / 'FROZEN.json').exists()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == '089ea3dc838a4ab901713caee5102e98ed59e0b6'
assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=root, text=True)
publication = json.loads((r / 'checkpoint-publication.json').read_text())
assert publication['head'] == head and publication['readback_exact'] and publication['tracking_exact']
summary = json.loads((r / 'verification-summary.json').read_text())
assert summary['commands'] == 6 and summary['passed'] == 6 and summary['failed'] == 0
assert summary['public_checks'] == 1189 and summary['all_new_axioms_standard']
assert json.loads((r / 'owned-verification.json').read_text())['status'] == 'pass'
for path in r.iterdir():
    if path.is_dir() and not path.name.startswith('prior-') and (path / 'started-command.json').exists():
        assert (path / 'report.json').exists(), path
rows = []
for path in sorted(r.rglob('*')):
    if path.is_file():
        assert not path.is_symlink(), path
        data = path.read_bytes()
        rows.append({'path': str(path.relative_to(r)), 'bytes': len(data),
                     'sha256': hashlib.sha256(data).hexdigest()})
seal = {'created_at': datetime.now(ZoneInfo('Europe/Stockholm')).isoformat(),
        'write_halt': True, 'goal_turn': 'progress', 'full_goal_complete': False,
        'goal_controller_observed_status': 'blocked', 'work_continues_under_user_instruction': True,
        'source_head': 'ea59a299ee215da7498f60eab8874df10223d495', 'docs_head': head,
        'main_head': 'bd5a406a6a3f84b7e3ae0906082783911509df83',
        'latest_prior_board_sequence': 782, 'compiler_commands': 6, 'passed_commands': 6,
        'repaired_failed_commands': 0, 'input_snapshots': 11, 'new_laws': 3,
        'public_checks': 1189, 'public_definitions': 116,
        'payload_count_excluding_seal': len(rows), 'payloads': rows}
(r / 'FROZEN.json').write_text(json.dumps(seal, indent=2) + '\n')
for path in r.rglob('*'):
    if path.is_file():
        path.chmod(path.stat().st_mode & ~0o222)
assert all(not (path.stat().st_mode & 0o222) for path in r.rglob('*') if path.is_file())
print(json.dumps({'sealed': True, 'payloads_excluding_seal': len(rows),
                  'raw_bytes_excluding_seal': sum(row['bytes'] for row in rows),
                  'source_head': seal['source_head'], 'docs_head': head}))
