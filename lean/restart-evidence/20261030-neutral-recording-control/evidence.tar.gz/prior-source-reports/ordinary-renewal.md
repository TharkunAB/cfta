[2026-10-30 07:10:19 CET] Ordinary renewal and degree-control assessment

Result

The named degree theorems and current ordinary-height contracts do not supply the missing original ordinary-control measure for complete enumeration. Degree here means the open binder depth of a stored plan. It is not ordinary constructor height, arity, record count or native handle count. The actual degree function is zero for every closed value.

There are useful existing positive height laws. Actual children and ordinary child-column unions decrease the height of an unchanged parent. Current native intersection also has an actual finite-return theorem with height bounded by both operands in the recursively finite ordinary-tree domain. These laws do not cover fresh reconstruction from Mu/union operands in the full input language.

The precise missing transport spans an actual selected child and the next native rewrite. Local descent after a rewrite does not imply descent from the previous parent. A uniform absolute height ceiling would also need a proof that native work cannot restore that ceiling repeatedly without consuming some finite original resource. The reviewed contracts do not supply that renewal charge.

No new Lean theorem is drafted. Each small proposed wrapper would retain an unproved height/progress/Path/shape supplier or restrict the full original language to finite ordinary trees. Existing theorems already establish the valid restricted cases. The task therefore ends with this source-grounded assessment and exact gate map, not an untested global proof.

Meaning of degree

InternedStoredPlanBinderDepth.valueDepth43–49 first tests value.free.isEmpty. It returns0 if the value is closed. Otherwise it descends ordinary/union children and counts open stored Mu binders. closed_zero111–113 explicitly proves valueDepth value=0 from value.free=[]. A long closed ordinary tree can therefore have degree0. The theorem does not relate that degree to MergedOrdinaryHeight.height.

InternedMuDepthInventory.Bounded68–69 bounds valueDepth of every stored Mu BODY in a fixed heap. It is not a bound on the number of Mu records or ordinary nodes. initial_bounded72–80 obtains this invariant from the fixed source's node inventory and maximumDepth. The theorem comment explicitly distinguishes this initial ceiling from future cached depth.

InternedOpenDepthReadback.Correct/Heap20–24 equate the valueDepth of each Mu body and its stored Depth probe. This extra postcondition in the degree theorems is also an open-plan equality. It does not state an ordinary-height or record-count bound.

Exact degree theorem gates

SourceRecursiveIntersectionKernel.node_result_degree23–37 takes a fixed source, Facts source, a source Mu-body degree limit, holds/emptyGuard/conjoin, a runtime fuel and an actual request scoped to that source. It takes Completes for the source semantic request, current machine Valid and NodeReady, growth/history from the same source, SemanticHeap, OpenDepth heap and an actual .done equation. Its conclusion preserves the two heap predicates and bounds only valueDepth of the actual returned value by limit+requiredFuel(source semantic request).

The theorem does not assert that every arbitrary pending execution returns. It does not bound all future callback syntax or all later request pairs. It does not bound ordinary height or the number of issued records.

Kernel.closed_roots_degree38–60 derives the semantic scope and Completes internally from the original, available, closed LEFT/RIGHT values in one fixed source heap. It chooses limit=maximumDepth(nodeInventory source)+1 and returns one bound for all valid successful kernel executions of that same root pair, regardless of their runtime fuel. This is a genuine original-input bound for that fixed request. Its Completes gate is not an outstanding cold-entry supplier.

Native.node_return_degree20–42 and edge_return_degree45–67 connect actual checked native .done returns to the kernel through the actual replay theorem. Their explicit native gates are Valid, Ready, source growth/history, SemanticHeap, OpenDepth and WordRanges. The node bound is valueDepth; the row bound is manyDepth of returned children. The98-line native source is retained in full.

Native.closed_roots_return_degree70–96 preserves the same fixed-source/fixed-root quantifiers, deriving request readiness from source availability and growth. It needs Valid, growth/history, both heap predicates, WordRanges and actual execute.done. It returns a degree bound independent of runtime fuel for that root pair. It is not a new all-future-request completion statement.

Native.node_return_degree_facts17–42 adds actual after-state validity, native extension and result availability to that same degree conclusion. It does not replace valueDepth with ordinary height.

To reuse a fixed-source bound for later generated requests, the later operands must satisfy that source's actual availability/scope gates. Availability in the current enlarged heap alone is different. Replacing source by the current heap recomputes the inventory limit and semantic requiredFuel, so it does not by itself give one ceiling from the original input. No conversion from those dynamically changing limits to an original ordinary-control quantity is proved by these named statements.

ColdRankCapacity/ColdRankSemantic constructed initial node-call completion is already proved. This task does not reopen or re-prove that cold entry. The remaining question is ordinary control across successive enumeration operations and fresh native rewrites.

Actual ordinary descent

MergedOrdinaryHeight.height16–18 counts ordinary .node layers and assigns0 to every other constructor. It stops at both Mu and explicit union boundaries. Its child_lt50–60 proves strict height decrease for an actual child in an actual edge of the same ordinary parent.

ordinaryUnion_bound134–151 bounds the result of ordinaryUnion values, which is makeNode of the complete operands' concatenated nodeEdges. It requires coherent/linked heap, resident operands and their existing height bound. column_union_lt154–169 then proves a retained column union lies below the same original parent when every operand is drawn from that parent's actual edge children.

These selection and operation gates matter. The ordinaryUnion primitive is the ordinary fast path. guarded_column_ordinary116–127 uses resident closed parent facts and values.any recursiveBoundary=false to establish that retained operands are ordinary or empty. The full mixed merge uses another path for Mu/union operands. One cannot substitute ordinaryUnion for that path merely because its mathematical height lemma holds.

These local laws compare immutable complete values. Cache growth can retain those same values and their heights. They do not say that a replacement returned by a native query is still a child of the old edge list. Nor do they say that the newly reconstructed parent's height is at most the old parent's height.

Existing restricted preservation

EqualityMergedTargetHeight.Tree18–21 recursively allows only empty and ordinary node constructors. It excludes every Mu, union and reference descendant. worker_height311–315 proves an actual HeightCall property for the standalone MergedColdMerge worker on that domain. merge_height351–358 proves height nonincrease for that module's Merge relation. This is a positive proved result, not merely a supplied HeightCall oracle. It still needs the Tree domain and the actual standalone worker/relation.

There is a stronger relevant CURRENT native API. SourceCurrentAllocatedFiniteOrdinaryDomain.Node21–33 recursively permits only empty and ordinary node records through all rows and children. It imposes no guard restriction but excludes Mu/union/reference descendants.

SourceCurrentAllocatedFiniteOrdinaryFinite.finite76–104 takes actual checked state Good, SemanticReady, Stored native memo invariant, Idle, available left/right, BOTH Node-domain premises, and actual request WordRanges. It internally derives a completed physical request Receipt. Its outputs include idle/semantic/stored, result Node domain, height(result)≤height(left), height(result)≤height(right), and result free=[]. No future successful trace, Completes or Receipt is an input to this theorem.

This theorem already provides the useful finite ordinary intersection law. A duplicate wrapper would remove no gate. The full original language permits nodes with Mu/union descendants, and general current admission does not assert both Node-domain premises for every request. Stored and WordRanges also remain exact caller gates in this API. This report does not silently derive them from generic current Context.

Mixed required-prefix reconstruction is outside those shape gates. Even a small intersection target can be installed beneath newly exposed ordinary prefix layers of a Mu operand. The needed full-language bound concerns that actual reconstruction and subsequent enumeration transition, not only the returned intersection target in isolation.

Preserved positive growth facts

The frozen SourceCurrentOuterParentHeightGrowth.supported_parent_growth178–203 was reused after matching the current full source SHA and exact retained cut bytes. It gives an actual original Syntax build, the exact initial checked heap, Scan.Ready, available closed input, its literal edge/child shapes, the supported primary.done false, and an actual SourceCurrentAllocatedParentWorker.edge.done equation.

The original input has height3. Its original edge height2 becomes returned edge height3. A returned child has height3, equal to the old parent height. The returned guard equals the original guard. Therefore Ready plus this actual parent operation cannot justify strict old-parent child descent or a claim that returned children are the old immutable child list. The witness includes a recursive operand, so it does not contradict the finite ordinary-domain theorems.

The same frozen area retains SourceCurrentOuterHeightBarrier.supported_required_growth58–74. Its actual constructed closed available input and both SemanticReady heaps support a required-prefix operation whose ordinary height changes0→1. This identifies Mu exposure as a concrete height-renewal operation under the stated lower/current required-operation gates.

Those facts were not re-evaluated or re-proved. They do not supply a complete enumeration Context/Fits/Room/Packet admission, an actual complete generator callback path, repeated unbounded renewal, or a Haskell runtime trace. No infinite execution or implementation defect is claimed. The prior source guards/equations are retained exactly rather than generalized beyond their gates.

Why the generic majorant is not the missing supplier

HeightOrderControlled.Path84–94 requires an actual strict HeightOrder.Below step at every transition, initial coordinate bounds and a controlled increase in the numerical control. Path.length_le182–188 then gives the finite majorant bound from an actual Path plus monotone/increasing control.

This is a valid numerical theorem. It does not construct a Path for the actual enumeration/native rewrite sequence. Adding a theorem that takes such a future Path or an equivalent whole-run progress premise would retain the missing obligation. This task adds no such wrapper.

A useful original-control supplier must connect each actual mixed writer and the next ordinary expansion to a common original well-founded quantity. It must explain how a height restoration is paid for by an original finite renewal resource, or show strict descent directly across the composed transition. The native query, parent/required reconstruction, actual current callback writes and earlier alternatives must all remain in that argument. A fixed-input native return bound is insufficient for this purpose.

An absolute uniform height ceiling by itself is weaker than that supplier. A sequence could stay within the ceiling while repeatedly resetting its local descent. Existing Entry KeyAncestry transport, reported by Root, addresses actual recursion-key ancestry. It does not change the non-boundary ordinary-height gates reviewed here. This report makes no claim that a boundary-key count alone charges every ordinary reconstruction.

Decision

No code candidate is announced. REJECTED-CANDIDATES.json records the precise discarded proof routes and failed gates. There is no omitted compiler failure and no uncompiled theorem presented as verified. The bounded review establishes the named-contract boundary; it is not an exhaustive absence claim over every module in the repository.

No Haskell file was inspected for a new defect, edited, executed or tested. No Haskell repair or new runtime defect is established, so this review supplies no Haskell fix for FINDINGS. Earlier documented height growth remains an explicitly scoped formal result.

Scope and provenance

Exactly two new whole old proof-bearing files were acquired: MergedOrdinaryHeight179 lines and NativeReturnDegree98 lines. Their1–10000 requests intentionally clamped to EOF. All other fresh proof-body acquisitions are bounded cuts with cumulative coverage unions. EqualityMergedTargetHeight351–369 clamped to360. HeightOrderControlled180–191 clamped to190. An initially misplaced HeightOrderControlled14–43 cut retained unrelated helper proofs; the actual Path definition82–96 was then acquired separately and retained. Nothing was discarded to hide that acquisition.

Three prior frozen cuts from equality-control-review were reused only after checking current full-source SHA256 and exact source-slice/copied bytes. They cover ParentHeightGrowth178–205 and43–64, and HeightBarrier58–76. No whole frozen proof source is falsely counted as reviewed here. Old bundles remain unchanged.

Each acquired source records requested/actual endpoints, full source lines/bytes/SHA256, computed Git blob SHA1, copied bytes/SHA256 and EOF behavior. These hashes identify current source bytes; this child did not use Git to verify a branch or commit. Navigation searches sometimes truncated; selected full contracts and proof scopes were recovered in the exact retained files. Incidents are recorded separately.

Memory notes on the earlier degree checkpoint were consulted as historical guidance. Every theorem meaning and gate claimed here was then checked against current source bytes. No historical build count, publication status or stale global gap list is treated as a current verification result.

The child ran no compiler, evaluator, native command, Git, network, board or subagent. It made no production edits and requested no Root compiler call because no new theorem is proposed. There are zero new verification executions in this owned scope. Final report, public contracts, gate map, acquisition unions, rejected routes and write-halt seal are pinned at completion.
