# Original recursive capacity: source review

This review isolates one local control step. It does not supply an original sufficient recursive depth.
Root reports that the preceding whole-worker and original-carrier checkpoint is published at `09f8a31a59abfc806cfcd86fb796868390aa99fd`. Root reports independent restore of449 archive payloads and passing checks. This reviewer did not run those checks.

## Result and check boundary

`RecordingControl-v2-UNCOMPILED.lean` contains three complete source proofs in the proposed namespace `MicroCFTA.SourcePruningEnumerationNeutralControl`. The owner did not run a compiler, evaluator, native program, Git, network, board, or child agent.
Root reported at21:27 CET that exact V2 SHA256 `7e23223ddd61778762ed3c626cdc4d8cf4f6a66a6e4bc283c8bca895dec42df6` passed a strict probe with empty output. Root is installing V3 outside this directory. V3 removes only the draft-status line. The filenames and embedded UNCOMPILED labels remain unchanged here to preserve source provenance. Production checks belong to Root's separate `/tmp/mcfta-neutral-recording-control-20261030` area.
The complete V1 is retained. V2 adds an explicit conversion of `Success` to actual row membership before the singleton rewrite. It changes no public statement. This precaution preceded compiler checking. No failed owner compiler run exists.

## Three exact local contracts

`PUBLIC-CONTRACTS.md` contains all three full statement headers and the source namespace, opens, local instance context and imports. It preserves the original `Symbol` name and all written implicit binders. There is no added equality instance, model, Packet, receipt, future trace or recursive-worker supplier.

1. `recordTypes_control` takes the literal successful `recordTypes graph templates fuel metadata uv input` row from `before` to `(result,after)`. It proves equality of `counter`, `values`, `recursionAncestry` and `expansionAncestry`.
2. `singleton_control` derives the same four equalities from the literal `ExceptT.run` equation `=[.ok (result,after)]`.
3. `recordTypes_pendingSize` proves equality of the old chosen-term pending cost for any fixed assignment. It requires the actual success row. It removes `UnionFind.Total before.representatives` from the old callback-progress contract.

The private proof follows every actual read, partial rendering, resume, oracle, mapM and recording branch in the existing values-preservation proof. Its invariant is the tuple of those four fields. Both result booleans are covered. The theorem makes no state claim for a failed row that has no returned state.

The old `SourcePruningEnumerationStorageCallbackProgress.recordTypes_pendingSize` uses totality to obtain a full compression frame. The new cost equality needs only unchanged stored values. `SourcePruningEnumerationPathRecordingValues.recordTypes_values` already supplies that equality without totality; the new tuple proof adds exact stored history and counter facts.
This removes a local premise. Packet-based resource callers can already supply totality. It does not remove a known original-input recursive-depth gate by itself.

## The observation is present at actual callback sites

The fully reused `SourcePruningEnumerationExecutionCallbackControl` has SHA256 `c0b8f8acc5ea4d5fe77402530885682d4f3491b016799ea0bd7945b6945bf7e8`. Both `native_left_of_singleton` and `prepared_left_of_singleton` take the exact singleton observation for `recordTypes ... (.inl fragment) before.core`. Their smaller-worker premise is separate and conditional on `result.1=false`. The new local control theorem does not need that premise.
The checked ReceiptBridge cuts122–158 and274–310 show the actual producers. Both reconstruct the current Packet with `receipt_packet`, call their respective `ExecutionCallbackBridge.*.callback_finite_complete_resources_with_execution_ih`, and obtain the observation as `(callback extra).2.1`. The generic local law can consume that equation directly before continuation. It does not posit a future successful whole trace. The producer's internal smaller-depth execution IH remains in the worker proof; the preceding whole-worker phase discharged that IH by induction.
The ReceiptBridge source SHA256 is `94a97a311d304ac5b3a143ee3a8ddd477b3e0b61070bee8904a4dbb89769245d`. Both frozen source identity and full current bytes were checked before reusing its two cuts.

## What control identity follows

Stored values equality preserves the literal node handle and raw SCS in each existing slot. The slot counter is unchanged. Both recursion-history functions/lists are unchanged.
This counter is the enumeration slot counter. It is not the native node-interner counter.
Representative reads can compress their forest. The new tuple excludes representatives. It does not claim resolved-root identity without the separate representative/frame gates. Recording metadata can change. The graph argument is fixed; this theorem does not compare two native heaps around an allocation.
The local pending cost is unchanged, not decreased. Neither cost equality nor control identity bounds the number of neutral callbacks or the intervening ordinary expansions.

## Fixed physical handle: an existing strict decrease

Current `SourcePruningEnumerationPathBoundaryBudget.checked_action_shape_budget` is pinned at SHA256 `80bc6f8d17096c163e98fe1544590ccec6f063a80694e5b33de9389dcae25c6d`. Its complete header and conclusion occur in the exact13–55 union: context13–24, law25–55.
Its gates include native Ready, the available closed value with decode/encode equations, the actual repeated-check success, an actual `Action.prepare.done`, a result with recursiveBoundary=true, the actual action success, StatePaths for the finite domain, Canonical, and the actual stored slot. The law concludes `result=value`, `afterHeap=heap`, `afterCore=checked`, and a successful representative read to that core. It puts the key's trie shape in the unused finite domain and strictly decreases that unused list after inserting the key for the same physical handle.
Thus this checked boundary action already preserves the physical handle and heap. The unresolved renewal link is an ordinary/native rewrite between boundary episodes. Do not describe handle renewal as a defect of this checked action.

`SourcePruningEnumerationKeyShapeBudget.unused` at15–17 filters a finite shape carrier by keys `⟨handle,shape⟩` absent from history. `unused_insert_lt` at49–53 proves the strict decrease for `key.node`. These facts do not sum over an unbounded set of fresh physical handles.
`SourcePruningEnumerationPathKeyAncestry.enter_key_ancestry` at20–40 transports supplied KeyAncestry through the actual Entry success with StatePaths, Canonical and boundedness. It does not derive an original bound on all handle renewals.

## Raw work and key cardinality are different

`EnumerationState.lean` SHA256 `83a898b883ec7b52469bccd87e8afa4f7abb320e3c935bf48f3d80ad77003cc4` defines RecursionKey at56–60 and recursionKey at62–65. The latter erases duplicate decoded trie shapes and sorts them. It retains the physical node handle. Raw SCS identifiers and duplicate shapes do not increase this canonical key list.
The actual writer cuts120–176 show allocation appending a new slot and inheriting active history. Intersection concatenates raw buckets `ls++rs` and can replace the stored node by `graph.intersect` of two handles. Assimilation joins source and target ancestry with duplicate erasure. It does not intersect the histories or clear them. The190–208 and270–326 cuts show the representative-only union and abstract enumeration entry/repeated-key control. They do not establish the complete native staged-caller correspondence.
The actual `RecursiveReservation.massCeil` at34–58 pays captured mass plus a term involving raw inherited length and guard width. Its `head_mass_le` at171–184 explicitly needs `scs.length≤inherited` and HeadCacheBounds. Repeating equal trie shapes can leave the key unchanged while increasing raw list work. A canonical key cardinality bound is not a raw multiplicity, slot, alternative or total-work bound.
A fixed-D forecast can pay this work for that D. It does not select sufficient original D.

## Remaining original-control obligation

The reviewed local laws support a control argument in which recording is neutral and fixed-handle recursive boundary insertion decreases a finite shape budget. The missing link must charge intervening ordinary/native rewrites against an original well-founded measure, or derive an original finite physical-handle carrier together with actual ordinary-segment control. It must cover earlier alternatives, staged children, and raw work. Merely assuming the desired future trace, worker completion or ordered-prefix coverage would not discharge this link.
The current review did not prove such a renewal bound. It did not exhaustively re-review native child writers. It does not claim an admitted infinite execution or Haskell nontermination.
The retained historical ordinary-renewal report distinguishes binder degree from ordinary height. Degree0 for a closed value does not bound its ordinary height or number of native records. Its local height-growth and required-Mu-exposure witnesses do not supply a full enumeration Packet/Fits/Room execution. Those boundaries remain. Completed intersection results were not reopened.
The historical report's older statement that whole-worker path induction was open is superseded by the Root-reported current checkpoint. Only its scoped degree/height interpretation is reused here.

## Acquisition and verification scope

The two named new old whole proof sources are exactly `SourcePruningEnumerationStorageCallbackProgress`42L and `SourcePruningEnumerationPathRecordingValues`178L. They were named before whole acquisition. Their copies happen to be under `reused/`; `acquisitions.json` explicitly classifies them as new acquisitions. No third old whole proof source was read.
`bounded-acquisitions.json`, `reuse-ledger.json` and `SOURCE-UNIONS.json` record full hashes, exact requested/actual endpoints, disjoint locator lines, copied bytes and cumulative unions. The initial140–186 request for PathRecordingValues clamped to EOF178; it was later promoted to the named whole source. The broad rg display was initially truncated and was recovered in full into `locator-progress-full.txt`, with exact per-source matching lines. Guessed nonexistent globs are recorded in INCIDENTS.
The full V1 and V2, all three V2 public headers, and this report were displayed. No Haskell source was read or changed. No Haskell fix or executable defect was established for FINDINGS.
The manifest binds every final payload. The pins bind the manifest and principal reports. All files, including manifests, pins and the seal, have no write bits. The owner stops writes after sealing. Root owns later compiler evidence and repairs outside this directory.
