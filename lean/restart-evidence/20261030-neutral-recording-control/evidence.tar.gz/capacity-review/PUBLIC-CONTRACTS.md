# Exact V2 public contracts

Source context, copied verbatim:

```lean
import MicroCFTA.SourcePruningEnumerationStorageCallbackProgress
import MicroCFTA.SourcePruningEnumerationPathRecordingValues

/-!
# Actual neutral recording control

UNCOMPILED source-only draft.
Recording retains the stored slot and recursion-history inputs to control.
The bound on the number of neutral transitions remains open.
-/
namespace MicroCFTA.SourcePruningEnumerationNeutralControl
open Language Fragments EnumerationState EnumerationCorrectness EnumerationSchedule
open SourcePruningPartialMatch SourcePruningTemplates SourcePruningEnumerationPathTransport
attribute [local instance] FormulaExecutable.formulaDecidableEq

local instance recordingControlMonadList : Monad List where
  pure value := [value]
  bind values continuation := values.flatMap continuation

```

```lean
theorem recordTypes_control {Guard Typing : Type}
    (graph : Graph Symbol Guard) (templates : List (Template.Pattern Symbol))
    (fuel : Nat) (metadata : SourcePruningRecordTypes.Metadata Typing) (uv : Nat)
    (input : Sum (Fragment Symbol) Nat) (before after : State Symbol Guard)
    (result : Bool × SourcePruningRecordTypes.Metadata Typing)
    (success : Success (SourcePruningRecordTypes.recordTypes graph templates fuel metadata uv input)
      before result after) :
    after.counter = before.counter ∧ after.values = before.values ∧
      after.recursionAncestry = before.recursionAncestry ∧
      after.expansionAncestry = before.expansionAncestry
```

```lean
theorem singleton_control {Guard Typing : Type}
    (graph : Graph Symbol Guard) (templates : List (Template.Pattern Symbol))
    (fuel : Nat) (metadata : SourcePruningRecordTypes.Metadata Typing) (uv : Nat)
    (input : Sum (Fragment Symbol) Nat) (before after : State Symbol Guard)
    (result : Bool × SourcePruningRecordTypes.Metadata Typing)
    (observed : ExceptT.run (SourcePruningRecordTypes.recordTypes
      graph templates fuel metadata uv input before) = [.ok (result, after)]) :
    after.counter = before.counter ∧ after.values = before.values ∧
      after.recursionAncestry = before.recursionAncestry ∧
      after.expansionAncestry = before.expansionAncestry
```

```lean
theorem recordTypes_pendingSize {Guard Typing : Type}
    (graph : Graph Symbol Guard) (templates : List (Template.Pattern Symbol))
    (fuel : Nat) (metadata : SourcePruningRecordTypes.Metadata Typing) (uv : Nat)
    (input : Sum (Fragment Symbol) Nat) (before after : State Symbol Guard)
    (result : Bool × SourcePruningRecordTypes.Metadata Typing)
    (assignment : Nat → Term Symbol)
    (success : Success (SourcePruningRecordTypes.recordTypes graph templates fuel metadata uv input)
      before result after) :
    EnumerationStorageProgress.pendingSize after assignment =
      EnumerationStorageProgress.pendingSize before assignment
```

