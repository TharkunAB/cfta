from pathlib import Path
import hashlib,json,re
r=Path('/tmp/mcfta-original-capacity-gap-review-20261030');old=(r/'reused/SourcePruningEnumerationPathRecordingValues.lean').read_text();ns='MicroCFTA.SourcePruningEnumerationNeutralControl';s=old[old.index('namespace MicroCFTA.'):old.index('/-- Every successful recording preserves the supplied stored path predicate. -/')];s=s.replace('SourcePruningEnumerationPathRecordingValues','SourcePruningEnumerationNeutralControl').replace('recordingValuesMonadList','recordingControlMonadList').replace('_values','_controlView').replace('recordTypes_controlView','recordTypes_controlView');s=re.sub(r'\b(before|after|middle|previous|next|state|resolved|last)\.values\b',r'(controlView \1)',s);s=s.replace('Values','Control');marker='private theorem pure_controlView';definition='''private def controlView {Symbol Guard : Type} (state : State Symbol Guard) :
    Nat × List (UVarValue Symbol) × (Nat → List RecursionKey) × List RecursionKey :=
  (state.counter, state.values, state.recursionAncestry, state.expansionAncestry)

''';assert marker in s;s=s.replace(marker,definition+marker,1);s=s.replace('/-- Every successful recording preserves the complete stored value list. -/\ntheorem recordTypes_controlView','private theorem recordTypes_controlView',1)
# The public statement uses explicit fields, so the private view stays internal.
common='''    (graph : Graph Symbol Guard) (templates : List (Template.Pattern Symbol))
    (fuel : Nat) (metadata : SourcePruningRecordTypes.Metadata Typing) (uv : Nat)
    (input : Sum (Fragment Symbol) Nat) (before after : State Symbol Guard)
    (result : Bool × SourcePruningRecordTypes.Metadata Typing)'''
conclusion='''    after.counter = before.counter ∧ after.values = before.values ∧
      after.recursionAncestry = before.recursionAncestry ∧
      after.expansionAncestry = before.expansionAncestry'''
public='''/-- Every successful recording retains stored slots, the counter and both recursion histories. -/
theorem recordTypes_control {Guard Typing : Type}
'''+common+'''
    (success : Success (SourcePruningRecordTypes.recordTypes graph templates fuel metadata uv input)
      before result after) :
'''+conclusion+''' := by
  have control := recordTypes_controlView graph templates fuel metadata uv input before after result success
  exact ⟨congrArg Prod.fst control,
    congrArg (fun view => view.2.1) control,
    congrArg (fun view => view.2.2.1) control,
    congrArg (fun view => view.2.2.2) control⟩

/-- The actual singleton callback retains the same stored control fields. -/
theorem singleton_control {Guard Typing : Type}
'''+common+'''
    (observed : ExceptT.run (SourcePruningRecordTypes.recordTypes
      graph templates fuel metadata uv input before) = [.ok (result, after)]) :
'''+conclusion+''' := by
  apply recordTypes_control graph templates fuel metadata uv input before after result
  rw [observed]
  exact List.mem_singleton_self _

/-- Every successful recording retains the chosen-term cost without a total forest premise. -/
theorem recordTypes_pendingSize {Guard Typing : Type}
'''+common+'''
    (assignment : Nat → Term Symbol)
    (success : Success (SourcePruningRecordTypes.recordTypes graph templates fuel metadata uv input)
      before result after) :
    EnumerationStorageProgress.pendingSize after assignment =
      EnumerationStorageProgress.pendingSize before assignment := by
  have values := (recordTypes_control graph templates fuel metadata uv input before after result success).2.1
  unfold EnumerationStorageProgress.pendingSize
  rw [values]

end '''+ns+'\n'
text='''import MicroCFTA.SourcePruningEnumerationStorageCallbackProgress
import MicroCFTA.SourcePruningEnumerationPathRecordingValues

/-!
# Actual neutral recording control

UNCOMPILED source-only draft.
Recording retains the stored slot and recursion-history inputs to control.
The bound on the number of neutral transitions remains open.
-/
'''+s+public
p=r/'RecordingControl-v1-UNCOMPILED.lean';assert not p.exists();assert not Path('/home/tritlo/Code/mcfta/lean/MicroCFTA/SourcePruningEnumerationNeutralControl.lean').exists();p.write_text(text);p.chmod(0o444);print(json.dumps(dict(path=str(p),lines=len(text.splitlines()),bytes=len(text.encode()),sha256=hashlib.sha256(text.encode()).hexdigest()),indent=2))
