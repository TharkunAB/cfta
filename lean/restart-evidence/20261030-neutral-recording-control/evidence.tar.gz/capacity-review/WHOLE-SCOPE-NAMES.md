# Named whole acquisitions

Before acquiring either complete body, select these exact immediate dependencies:
1. SourcePruningEnumerationStorageCallbackProgress.lean,42 lines. It states the existing neutral pendingSize law and its Totality gate.
2. SourcePruningEnumerationPathRecordingValues.lean,178 lines. Its actual recording/read/partial-term invariant proof may remove that gate and expose exact recursion-key inputs.
The prior acquired PathRecordingValues union was140–178 (39/178), including an explicit EOF clamp from requested186.
The allowance is TWO new OLD whole bodies. No third whole/near-whole source is acquired.
