# Incidents

The first broad progress locator output was truncated by its tool output cap. It will be recovered into a retained raw locator file, with actual matched lines pinned. No proof body was acquired by that locator.
A guessed EnumerationRecursionKey*.lean glob did not exist; RecursionKey and recursionKey are actually in EnumerationState.lean.

RecordingControlV1 is retained. Before any compiler check, V2 inserts an explicit Success-to-row-membership change at singleton_control. Every public header is unchanged. This is a source-level elaboration precaution, not a compiler diagnostic.

The broad progress locator was recovered in full into locator-progress-full.txt with empty stderr. Each matched line is retained as an exact disjoint cut with full source hash. The initial PathRecordingValues request140–186 clamped to EOF178; this is explicit before its later named whole acquisition. Two further guessed EnumerationNodes/EnumerationKeyAncestry glob paths did not exist; the actual ancestry writers are in EnumerationState.

Before sealing, earlier narrow locator lines were recovered into exact disjoint copies. They add two EnumerationFrame lines and bounded PathKeyShapes lines to the read ledger. The cumulative unions include these locator-only reads. No third whole source was acquired.
