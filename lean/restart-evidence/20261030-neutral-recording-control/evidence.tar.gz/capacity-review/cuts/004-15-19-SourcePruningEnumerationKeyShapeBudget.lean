def unused (carrier : List (List (List (List Nat)))) (handle : Nat)
    (history : List RecursionKey) : List (List (List (List Nat))) :=
  carrier.filter fun shape => decide ((⟨handle, shape⟩ : RecursionKey) ∉ history)

private theorem unused_filter
