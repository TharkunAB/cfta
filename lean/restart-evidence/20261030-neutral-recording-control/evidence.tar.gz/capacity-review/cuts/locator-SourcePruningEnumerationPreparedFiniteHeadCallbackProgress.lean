# Same-model progress through the actual prepared head callback
theorem head_finite_complete_resources_accepting_callback_progress
          ∃ (progressInventory : Inventory) (progressMemos : Memos),
            Post formulas solver progressInventory caller middleCaller progressMemos ∧
            progressMemos.query = saved ∧
            Packet formulas solver progressInventory middleCaller progressMemos metadata afterCache ∧
              SourcePruningEnumerationPreparedRecursive.CallbackProgressAt formulas solver progressInventory
                graph templates metadata uv fragment middleCaller progressMemos afterCache ambient extended
    head_finite_complete_resources_accepting_progress holeKey fits admits graph templates checkEmpty edgesOf stop order
      _proper, _decrease, _progress⟩ := accepting ambient assignment satisfied accepted
        afterProper, decrease, progressInventory, progressMemos, progressPost, progressQuery, progressPacket⟩ :=
        afterProper, decrease, progressInventory, progressMemos, progressPost, progressQuery, progressPacket, ?_⟩
      exact SourcePruningEnumerationPreparedRecursive.callback_progress_at_of_success
        formulas solver progressInventory graph templates metadata uv fragment middleCaller progressMemos afterCache
        (bound + extra) recorded callbackCore progressPacket allocated afterProper observed ambient extended afterSatisfied
