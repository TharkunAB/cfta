theorem checked_action_shape_budget [DecidableEq (EdgeKey Symbol NativeGuard)]
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool)
    (admits : Key → Value Symbol NativeGuard → Bool) (metadata : Metadata Typing)
    (checkFuel nativeFuel representativeFuel uv handle : Nat) (scs : List Suspended)
    (value result : Value Symbol NativeGuard)
    (heap afterHeap : InternedConstructorTemplates.State Symbol NativeGuard)
    (before checked afterCore : EnumerationState.State Symbol EnumGuard)
    (action : EnumerateM Symbol EnumGuard Unit)
    (ready : SourceEqualityRequiredCache.Ready heap)
    (available : Available heap value) (closed : value.free = [])
    (decoded : lookupNode heap handle = some value) (encoded : encodeNode value = some handle)
    (checking : Success (SourcePruningEnumerationRecursion.checkRepeated heap checkFuel uv handle scs)
      before false checked)
    (prepared : SourcePruningEnumerationAction.prepare holeKey fits admits metadata nativeFuel representativeFuel
      uv handle scs value heap = .done (result, some action) afterHeap)
    (boundary : MergedOrdinaryHeight.recursiveBoundary result = true)
    (executed : Success action checked () afterCore)
    (domain : List EqualityTrie.Path)
    (paths : StatePaths (fun path => path ∈ domain) before)
    (canonical : EnumerationValidity.Canonical before)
    (stored : before.values[uv]? = some (.unenumerated (some handle) scs)) :
    ∃ root, result = value ∧ afterHeap = heap ∧ afterCore = checked ∧
      Success (representative checkFuel uv) before root afterCore ∧
      (recursionKey handle scs).tries ∈ unused (keyShapes domain) handle (afterCore.recursionAncestry root) ∧
      (unused (keyShapes domain) handle
        (recursionKey handle scs :: afterCore.recursionAncestry root).eraseDups).length <
        (unused (keyShapes domain) handle (afterCore.recursionAncestry root)).length := by
  have retained := SourcePruningEnumerationAction.prepare_boundary_retained holeKey fits admits metadata
    nativeFuel representativeFuel uv handle scs value heap result (some action) afterHeap
    ready available closed encoded prepared boundary
  have actionSame : action = pure () := Option.some.inj retained.2.2
