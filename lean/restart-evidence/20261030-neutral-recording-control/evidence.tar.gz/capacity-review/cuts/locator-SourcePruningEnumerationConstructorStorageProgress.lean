Terminal assimilation and recursive callback progress remain separate.
