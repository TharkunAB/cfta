# Strict constructor progress in the actual prepared sibling scan
/-- The actual chosen head has strict progress or an exact earlier hook failure. -/
theorem alternatives_finite_complete_resources_accepting_progress
                    ∃ (progressInventory : Inventory) (progressMemos : Memos),
                      Post formulas solver progressInventory headCaller branchCaller progressMemos ∧
                      progressMemos.query = branchQueries ∧
                      Packet formulas solver progressInventory branchCaller progressMemos metadata afterCache) ∨
        SourcePruningEnumerationPreparedNativeHookResources.head_finite_complete_resources_accepting_progress
              obtain ⟨extended, fragment, afterCache, _agree, _original, impossible, _filled, _final, _proper, _decrease, _progress⟩ :=
                  obtain ⟨extended, fragment, afterCache, agree, originalSatisfied, completed, filled, afterSatisfied, afterProper, decrease, progressResources⟩ :=
                    .inl ⟨rfl, rfl, extended, agree, originalSatisfied, filled, afterSatisfied, afterProper, decrease, progressResources⟩⟩
                  · rcases terminal with ⟨sameIndex, sameEdge, extended, agree, oldSatisfied, filled, afterSatisfied, afterProper, decrease, progressResources⟩ |
                      exact .inl ⟨by omega, sameEdge, extended, agree, originalSatisfied, filled, afterSatisfied, afterProper, decrease, progressResources⟩
                    completed, filled, afterSatisfied, afterProper, decrease, progressResources⟩ := headAccepting ambient assignment satisfied accepted
                    simpa only [actualSame.1, actualSame.2] using progressResources⟩
