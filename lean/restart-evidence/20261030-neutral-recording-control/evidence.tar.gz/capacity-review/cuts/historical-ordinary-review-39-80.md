Actual ordinary descent

MergedOrdinaryHeight.height16–18 counts ordinary .node layers and assigns0 to every other constructor. It stops at both Mu and explicit union boundaries. Its child_lt50–60 proves strict height decrease for an actual child in an actual edge of the same ordinary parent.

ordinaryUnion_bound134–151 bounds the result of ordinaryUnion values, which is makeNode of the complete operands' concatenated nodeEdges. It requires coherent/linked heap, resident operands and their existing height bound. column_union_lt154–169 then proves a retained column union lies below the same original parent when every operand is drawn from that parent's actual edge children.

These selection and operation gates matter. The ordinaryUnion primitive is the ordinary fast path. guarded_column_ordinary116–127 uses resident closed parent facts and values.any recursiveBoundary=false to establish that retained operands are ordinary or empty. The full mixed merge uses another path for Mu/union operands. One cannot substitute ordinaryUnion for that path merely because its mathematical height lemma holds.

These local laws compare immutable complete values. Cache growth can retain those same values and their heights. They do not say that a replacement returned by a native query is still a child of the old edge list. Nor do they say that the newly reconstructed parent's height is at most the old parent's height.

Existing restricted preservation

EqualityMergedTargetHeight.Tree18–21 recursively allows only empty and ordinary node constructors. It excludes every Mu, union and reference descendant. worker_height311–315 proves an actual HeightCall property for the standalone MergedColdMerge worker on that domain. merge_height351–358 proves height nonincrease for that module's Merge relation. This is a positive proved result, not merely a supplied HeightCall oracle. It still needs the Tree domain and the actual standalone worker/relation.

There is a stronger relevant CURRENT native API. SourceCurrentAllocatedFiniteOrdinaryDomain.Node21–33 recursively permits only empty and ordinary node records through all rows and children. It imposes no guard restriction but excludes Mu/union/reference descendants.

SourceCurrentAllocatedFiniteOrdinaryFinite.finite76–104 takes actual checked state Good, SemanticReady, Stored native memo invariant, Idle, available left/right, BOTH Node-domain premises, and actual request WordRanges. It internally derives a completed physical request Receipt. Its outputs include idle/semantic/stored, result Node domain, height(result)≤height(left), height(result)≤height(right), and result free=[]. No future successful trace, Completes or Receipt is an input to this theorem.

This theorem already provides the useful finite ordinary intersection law. A duplicate wrapper would remove no gate. The full original language permits nodes with Mu/union descendants, and general current admission does not assert both Node-domain premises for every request. Stored and WordRanges also remain exact caller gates in this API. This report does not silently derive them from generic current Context.

Mixed required-prefix reconstruction is outside those shape gates. Even a small intersection target can be installed beneath newly exposed ordinary prefix layers of a Mu operand. The needed full-language bound concerns that actual reconstruction and subsequent enumeration transition, not only the returned intersection target in isolation.

Preserved positive growth facts

The frozen SourceCurrentOuterParentHeightGrowth.supported_parent_growth178–203 was reused after matching the current full source SHA and exact retained cut bytes. It gives an actual original Syntax build, the exact initial checked heap, Scan.Ready, available closed input, its literal edge/child shapes, the supported primary.done false, and an actual SourceCurrentAllocatedParentWorker.edge.done equation.

The original input has height3. Its original edge height2 becomes returned edge height3. A returned child has height3, equal to the old parent height. The returned guard equals the original guard. Therefore Ready plus this actual parent operation cannot justify strict old-parent child descent or a claim that returned children are the old immutable child list. The witness includes a recursive operand, so it does not contradict the finite ordinary-domain theorems.

The same frozen area retains SourceCurrentOuterHeightBarrier.supported_required_growth58–74. Its actual constructed closed available input and both SemanticReady heaps support a required-prefix operation whose ordinary height changes0→1. This identifies Mu exposure as a concrete height-renewal operation under the stated lower/current required-operation gates.

Those facts were not re-evaluated or re-proved. They do not supply a complete enumeration Context/Fits/Room/Packet admission, an actual complete generator callback path, repeated unbounded renewal, or a Haskell runtime trace. No infinite execution or implementation defect is claimed. The prior source guards/equations are retained exactly rather than generalized beyond their gates.

Why the generic majorant is not the missing supplier

HeightOrderControlled.Path84–94 requires an actual strict HeightOrder.Below step at every transition, initial coordinate bounds and a controlled increase in the numerical control. Path.length_le182–188 then gives the finite majorant bound from an actual Path plus monotone/increasing control.

This is a valid numerical theorem. It does not construct a Path for the actual enumeration/native rewrite sequence. Adding a theorem that takes such a future Path or an equivalent whole-run progress premise would retain the missing obligation. This task adds no such wrapper.

A useful original-control supplier must connect each actual mixed writer and the next ordinary expansion to a common original well-founded quantity. It must explain how a height restoration is paid for by an original finite renewal resource, or show strict descent directly across the composed transition. The native query, parent/required reconstruction, actual current callback writes and earlier alternatives must all remain in that argument. A fixed-input native return bound is insufficient for this purpose.

An absolute uniform height ceiling by itself is weaker than that supplier. A sequence could stay within the ceiling while repeatedly resetting its local descent. Existing Entry KeyAncestry transport, reported by Root, addresses actual recursion-key ancestry. It does not change the non-boundary ordinary-height gates reviewed here. This report makes no claim that a boundary-key count alone charges every ordinary reconstruction.

