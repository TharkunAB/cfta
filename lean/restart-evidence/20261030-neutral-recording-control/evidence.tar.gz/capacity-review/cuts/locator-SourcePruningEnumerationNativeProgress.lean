# Native restart progress from actual strict pending paths
