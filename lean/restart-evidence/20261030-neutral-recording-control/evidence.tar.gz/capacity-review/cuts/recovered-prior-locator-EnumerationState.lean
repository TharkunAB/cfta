structure RecursionKey where
def recursionKey (node : Nat) (scs : List Suspended) : RecursionKey :=
  recursionAncestry : Nat → List RecursionKey
  expansionAncestry : List RecursionKey
def inheritAncestry (uv : Nat) : EnumerateM Symbol Guard Unit :=
  modify fun state => {state with recursionAncestry := (fun other =>
            modify fun state => {state with recursionAncestry := (fun other =>
def unionVariables (fuel left right : Nat) : EnumerateM Symbol Guard Unit := do
      modify fun state => {state with expansionAncestry := (
        | .recursive _ => (recursionKey node scs :: ancestry).eraseDups
      modify fun state => {state with expansionAncestry := []}
                    if recursionKey node scs ∈ current.recursionAncestry root then
    recursionAncestry := (fun other =>
    recursionAncestry := (fun uv => if uv = 0 then [recursionKey 0 [pendingPath]] else [])}
