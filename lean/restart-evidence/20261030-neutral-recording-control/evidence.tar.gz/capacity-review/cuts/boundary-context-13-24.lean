namespace MicroCFTA.SourcePruningEnumerationPathBoundaryBudget
open EnumerationState EnumerationCorrectness EnumerationCompressionFrame
open InternedConstructorTemplates InternedProbeProvenance
open SourcePruningEnumerationNodes
open SourcePruningEnumerationPathKeyShapes SourcePruningEnumerationKeyShapeBudget
open SourcePruningEnumerationPathTransport
open SourcePruningRecordTypes (Metadata)
local notation "Symbol" => SourcePruningTemplates.Symbol
variable {EnumGuard NativeGuard Typing Key : Type}
attribute [local instance] SourcePruningEnumerationAction.actionMonadList

/-- Actual boundary observations consume a finite original path shape without a term model. -/
