# Native selection progress from an original pending slot
