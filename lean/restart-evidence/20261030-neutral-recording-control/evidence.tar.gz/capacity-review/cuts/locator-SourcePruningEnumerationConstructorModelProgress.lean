      ⟨EnumerationFrame.neutralize_satisfies _ meaning extended target recorded.core recordedModel, equation⟩
