# Native scheduler progress at the actual accepted captured endpoint
theorem complete_with_history_resources_progress
