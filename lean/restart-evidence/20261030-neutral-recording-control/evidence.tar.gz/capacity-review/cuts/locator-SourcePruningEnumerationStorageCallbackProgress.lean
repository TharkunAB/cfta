This is a neutral step and does not establish recursive progress.
