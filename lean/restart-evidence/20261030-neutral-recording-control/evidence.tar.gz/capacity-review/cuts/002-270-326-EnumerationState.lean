def pickNext (preference : List Nat → Option Nat) : Option (List Nat) → Next
  | none => .done
  | some [] => .stuck
  | some (first :: rest) =>
      match preference (first :: rest) with
      | some preferred => if preferred ∈ first :: rest then .expand preferred else .expand first
      | none => .expand first

/-- Expand one selected UVar and store its fragment. -/
def enumerateOut (graph : Graph Symbol Guard) (fuel uv : Nat) :
    EnumerateM Symbol Guard (Fragment Symbol) := do
  match ← getValue (fuel + 1) uv with
  | .unenumerated (some node) scs =>
      let root ← representative (fuel + 1) uv
      let ancestry := (← get).recursionAncestry root
      modify fun state => {state with expansionAncestry := (
        match graph.node node with
        | .recursive _ => (recursionKey node scs :: ancestry).eraseDups
        | _ => ancestry)}
      let fragment ← enumerateNode graph fuel scs
        (match graph.node node with | .recursive body => body | _ => node)
      modify fun state => {state with expansionAncestry := []}
      setValue root (.enumerated fragment)
      pure fragment
  | _ => reject

/-- The callback sees either the selected graph node or its completed fragment. -/
abbrev Oracle (Symbol Guard OracleState : Type) := OracleState → Nat →
  Sum (Fragment Symbol) Nat → EnumerateM Symbol Guard (Bool × OracleState)

/-- The complete caller loop, including pruning and repeated-recursion truncation. -/
def enumerateFully (graph : Graph Symbol Guard) (order : OracleState → List Nat → Option Nat)
    (oracle : Oracle Symbol Guard OracleState) : Nat → OracleState → EnumerateM Symbol Guard Unit
  | 0, _ => failure .fuelExhausted
  | fuel + 1, oracleState => do
      let next := pickNext (order oracleState) (← findExpandable graph (fuel + 1))
      match next with
      | .done => pure ()
      | .stuck => reject
      | .expand uv =>
          match ← getValue (fuel + 1) uv with
          | .unenumerated (some node) scs =>
              let repeated ← match graph.node node with
                | .recursive _ => do
                    let root ← representative (fuel + 1) uv
                    let current : State Symbol Guard ← get
                    if recursionKey node scs ∈ current.recursionAncestry root then
                      setValue root (.unenumerated (some node) [])
                      pure true
                    else pure false
                | _ => pure false
              if repeated then enumerateFully graph order oracle fuel oracleState
              else
                let (beforeReject, beforeState) ← oracle oracleState uv (.inr node)
                require (!beforeReject)
                let fragment ← enumerateOut graph (fuel + 1) uv
                let (afterReject, afterState) ← oracle beforeState uv (.inl fragment)
