  | alternatives : List (Edge Symbol Guard) → Node Symbol Guard
  | recursive : Nat → Node Symbol Guard
  | unresolved : Nat → Node Symbol Guard

/-- Graph primitives supplied by the interned-graph implementation. -/
structure Graph (Symbol Guard : Type) where
  node : Nat → Node Symbol Guard
  intersect : Nat → Nat → Nat

/-- Recursion keys omit equality-variable identities. -/
structure RecursionKey where
  node : Nat
  tries : List (List (List Nat))
  deriving DecidableEq

/-- Canonical path sets represent the source's set of suspended tries. -/
def recursionKey (node : Nat) (scs : List Suspended) : RecursionKey :=
  ⟨node, (scs.map fun sc => EqualityTrie.fromPathTrie sc.trie).eraseDups.mergeSort
    (fun left right => compare left right != .gt)⟩

/-- Mutable state copied separately for each nondeterministic branch. -/
structure State (Symbol Guard : Type) where
  counter : Nat
  representatives : UnionFind.Forest
  values : List (UVarValue Symbol)
  obligations : List (Guard × Fragment Symbol)
  recursionAncestry : Nat → List RecursionKey
  expansionAncestry : List RecursionKey

/-- The root starts in UVar zero. -/
def initial (root : Nat) : State Symbol Guard :=
