/-- A prepared constructor preserves the captured target and the complete progress result. -/
      ⟨EnumerationFrame.neutralize_satisfies _ _ extended target recorded.core recordedModel, parentEquation⟩
