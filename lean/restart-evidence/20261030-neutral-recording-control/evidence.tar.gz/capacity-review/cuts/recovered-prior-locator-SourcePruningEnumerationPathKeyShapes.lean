namespace MicroCFTA.SourcePruningEnumerationPathKeyShapes
variable {Symbol Guard : Type}
def trieShapes (domain : List EqualityTrie.Path) : List (List EqualityTrie.Path) :=
def keyShapes (domain : List EqualityTrie.Path) : List (List (List EqualityTrie.Path)) :=
theorem stored_recursion_key_paths
theorem stored_recursion_key_mem
