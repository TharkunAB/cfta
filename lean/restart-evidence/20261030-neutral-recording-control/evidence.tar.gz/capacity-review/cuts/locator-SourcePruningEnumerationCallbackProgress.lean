# Scheduler progress after the actual fragment callback
theorem callback_complete_progress (packet : Packet formulas solver inventory caller memos metadata before)
  -- Apply the actual native scheduler progress theorem at the returned packet.
