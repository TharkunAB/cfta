namespace MicroCFTA.SourcePruningEnumerationPathBoundaryBudget
variable {EnumGuard NativeGuard Typing Key : Type}
theorem checked_action_shape_budget [DecidableEq (EdgeKey Symbol NativeGuard)]
theorem checked_enter_shape_budget
