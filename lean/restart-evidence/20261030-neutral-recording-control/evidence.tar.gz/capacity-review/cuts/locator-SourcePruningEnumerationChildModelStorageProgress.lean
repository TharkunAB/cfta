# Original accepting child models with storage progress
