            | .recursive _ => (recursionKey node scs :: resolved.recursionAncestry uv).eraseDups
          let start := {resolved with expansionAncestry := ancestry}
