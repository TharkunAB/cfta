theorem enter_key_ancestry
    (heap : InternedConstructorTemplates.State Symbol NativeGuard) (fuel uv : Nat)
    (before after : EnumerationState.State Symbol EnumGuard) (target handle : Nat)
    (bucket : List Suspended) (decoded : Value Symbol NativeGuard)
    (domain : List EqualityTrie.Path) (paths : StatePaths (fun p => p ∈ domain) before)
    (canonical : Canonical before)
    (bounded : KeyAncestry (SourcePruningEnumerationPathKeyShapes.keyShapes domain) before)
    (success : Success (enter heap fuel uv) before (target, handle, bucket, decoded) after) :
    KeyAncestry (SourcePruningEnumerationPathKeyShapes.keyShapes domain) after := by
  unfold enter at success
  obtain ⟨value, read, reading, continued⟩ := (success_bind _ _ _ _ _).mp success
  obtain ⟨_readFound, _lookup, stored, readSame⟩ :=
    (getValue_success fuel uv before read value).mp reading
  have readBounded : KeyAncestry (SourcePruningEnumerationPathKeyShapes.keyShapes domain) read := by
    rw [readSame]
    exact bounded
  cases value with
  | enumerated fragment => exact (reject_unsuccessful read after _ continued).elim
  | eliminated => exact (reject_unsuccessful read after _ continued).elim
  | unenumerated node scs =>
      cases node with
