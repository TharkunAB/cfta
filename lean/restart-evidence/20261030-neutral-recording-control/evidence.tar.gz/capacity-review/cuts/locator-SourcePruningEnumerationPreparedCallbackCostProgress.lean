/-- An actual successful recording derives progress from original model, policy and cost facts. -/
theorem callback_progress_at_of_success
    callback_record_progress formulas solver inventory graph templates metadata uv fragment caller memos before
