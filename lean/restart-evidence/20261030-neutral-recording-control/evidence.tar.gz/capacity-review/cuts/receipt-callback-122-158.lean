  | complete fragment actual saved after =>
      have endpoints : (actual, saved) = (reached, final.query) := Option.some.inj advanced
      obtain ⟨callerSame, querySame⟩ := Prod.mk.inj endpoints
      subst actual
      subst saved
      obtain ⟨level, frontier, ordered⟩ := packet.ordered
      have current := SourcePruningEnumerationRecursive.receipt_packet before.core uv fragment after level frontier
        post.context admitted history pending ordered packet.bounded
      have currentPaths : StatePaths P after.core := receiptPaths.1
      obtain ⟨fuel, result, callbackCore, outcome, _returned, _stable, _frame, _types, _holes, _typing,
        callback, running, resources, _framedPaths, continuing⟩ :=
        SourcePruningEnumerationExecutionCallbackBridge.Native.callback_finite_complete_resources_with_execution_ih
          holeKey fits admits formulas solver next graph templates metadata uv fragment reached final after
          checkEmpty edgesOf stop order recursiveFuel recursive seed ceiling
          current admitted.2.2.1 bounded known selectionMembers selectionLength mass reserved
          P currentPaths projected
          (fun work updated actual saved cache =>
            SourcePruningEnumerationExecutionPaths.Native P holeKey fits admits graph templates checkEmpty edgesOf stop order
              work recursiveFuel updated actual saved cache)
          pathsIH
      have left : ∀ extra,
          LeftPaths P
            (ResumeNative P holeKey fits admits graph templates checkEmpty edgesOf stop order
              (fuel + extra) recursiveFuel)
            (NativeFailurePaths P)
            (continueWith
              (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
                (fuel + extra) recursiveFuel)
              graph templates stop order (fuel + extra) metadata uv)
            graph templates stop order (fuel + extra) metadata uv fragment reached final.query after := by
        intro extra
        have singleton := (callback extra).2.1
        have continuedPaths := continuing extra
        apply SourcePruningEnumerationExecutionCallbackControl.native_left_of_singleton
        all_goals assumption
      have outcomePaths : OutcomePaths P (NativeFailurePaths P) outcome := by
        have actualPaths := (left 0).2.2.1
