/-- The actual stable head preserves its resources and derives strict accepted-model progress. -/
theorem head_finite_complete_resources_accepting_progress
          ∃ (progressInventory : Inventory) (progressMemos : Memos),
            Post formulas solver progressInventory caller middleCaller progressMemos ∧
            progressMemos.query = saved ∧
            Packet formulas solver progressInventory middleCaller progressMemos metadata afterCache := by
  obtain ⟨r, n, p, h, k, fragment, actualCaller, recorded, afterCache, actualSaved, progressMemos,
    progressInventory, _afterRoots, extended, original, capturedRun, afterPacket, afterProper,
  rcases original with ⟨_selectedRun, _finalizeRun, progressPost, progressQueries, agree, originalSatisfied,
    decrease, progressInventory, progressMemos, ?_, ?_, ?_⟩
  · simpa only [sameCaller] using progressPost
  · exact progressQueries.trans sameQueries
