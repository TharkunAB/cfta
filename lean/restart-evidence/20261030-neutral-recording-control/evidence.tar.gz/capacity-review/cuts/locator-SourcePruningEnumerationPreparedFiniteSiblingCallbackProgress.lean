# Actual prepared callback progress in the ordered sibling scan
/-- The actual chosen head and callback preserve strict model progress or retain an earlier failure. -/
theorem alternatives_finite_complete_resources_accepting_callback_progress
                    ∃ (progressInventory : Inventory) (progressMemos : Memos),
                      Post formulas solver progressInventory headCaller branchCaller progressMemos ∧
                      progressMemos.query = branchQueries ∧
                      Packet formulas solver progressInventory branchCaller progressMemos metadata afterCache ∧
                      SourcePruningEnumerationPreparedRecursive.CallbackProgressAt formulas solver progressInventory
                        graph templates metadata uv fragment branchCaller progressMemos afterCache ambient extended
        SourcePruningEnumerationPreparedNativeHookResources.head_finite_complete_resources_accepting_callback_progress
              obtain ⟨extended, fragment, afterCache, _agree, _original, impossible, _filled, _final, _proper, _decrease, _progress⟩ :=
                  obtain ⟨extended, fragment, afterCache, agree, originalSatisfied, completed, filled, afterSatisfied, afterProper, decrease, progressResources⟩ :=
                      obtain ⟨progressInventory, progressMemos, progressPost, progressQuery, progressPacket, callbacks⟩ := progressResources
                      refine ⟨progressInventory, progressMemos, progressPost, progressQuery, progressPacket, ?_⟩
                  · rcases terminal with ⟨sameIndex, sameEdge, extended, agree, oldSatisfied, filled, afterSatisfied, afterProper, decrease, progressResources⟩ |
                      exact .inl ⟨by omega, sameEdge, extended, agree, originalSatisfied, filled, afterSatisfied, afterProper, decrease, progressResources⟩
                    completed, filled, afterSatisfied, afterProper, decrease, progressResources⟩ := headAccepting ambient assignment satisfied accepted
                    obtain ⟨progressInventory, progressMemos, progressPost, progressQuery, progressPacket, callbacks⟩ := progressResources
                    refine ⟨progressInventory, progressMemos, ?_, ?_, ?_, ?_⟩
                    · simpa only [actualSame.1] using progressPost
                    · simpa only [actualSame.2] using progressQuery
                    · simpa only [actualSame.1] using progressPacket
