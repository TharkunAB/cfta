def unionVariables (fuel left right : Nat) : EnumerateM Symbol Guard Unit := do
  let state ← get
  match UnionFind.union fuel fuel state.representatives left right with
  | none => failure .representativeFuel
  | some forest => set {state with representatives := forest}

/-- Every suspended nonempty path starts at an available child. -/
def arityAllows (arity : Nat) (scs : List Suspended) : Bool :=
  scs.all fun sc => (EqualityTrie.fromPathTrie sc.trie).all fun path =>
    match path with | [] => true | child :: _ => decide (child < arity)

mutual
  /-- Enumerate a node or merge the equality variables reached at its root. -/
  def enumerateNode (graph : Graph Symbol Guard) : Nat → List Suspended → Nat →
      EnumerateM Symbol Guard (Fragment Symbol)
    | 0, _, _ => failure .fuelExhausted
    | fuel + 1, scs, node => do
        match graph.node node with
        | .empty => reject
