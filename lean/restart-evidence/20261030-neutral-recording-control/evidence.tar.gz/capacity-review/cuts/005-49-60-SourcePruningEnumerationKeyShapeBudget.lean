theorem unused_insert_lt
    (carrier : List (List (List (List Nat)))) (key : RecursionKey) (history : List RecursionKey)
    (member : key.tries ∈ carrier) (fresh : key ∉ history) :
    (unused carrier key.node (key :: history).eraseDups).length <
      (unused carrier key.node history).length := by
  have included : ∀ old ∈ history, old ∈ (key :: history).eraseDups := by
    intro old present
    simp only [List.mem_eraseDups, List.mem_cons]
    exact Or.inr present
  have sublist : List.Sublist (unused carrier key.node (key :: history).eraseDups)
      (unused carrier key.node history) := by
    rw [unused_filter carrier key.node history (key :: history).eraseDups included]
