namespace MicroCFTA.SourcePruningEnumerationKeyShapeBudget
def unused (carrier : List (List (List (List Nat)))) (handle : Nat)
theorem unused_bounded
theorem unused_mono
theorem unused_insert_lt
