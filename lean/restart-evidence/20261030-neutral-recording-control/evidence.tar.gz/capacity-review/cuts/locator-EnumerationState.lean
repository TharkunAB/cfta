structure RecursionKey where
def recursionKey (node : Nat) (scs : List Suspended) : RecursionKey :=
