namespace MicroCFTA.SourcePruningEnumerationRecursiveReservation
def Reserved (bits : Nat) (seed : Seed) (capturedMass inherited : Nat) : Prop :=
theorem edgeCount_mono (seed : Seed) {first last : Nat} (lengths : first ≤ last) :
theorem massCeil_mono (seed : Seed) {firstMass lastMass firstLength lastLength : Nat}
theorem afterHead_ge (seed : Seed) (inherited : Nat) :
theorem afterHead_le_afterHook (seed : Seed) (capturedMass inherited : Nat) :
theorem afterHook_ge (seed : Seed) (capturedMass inherited : Nat) :
theorem head_padding (seed : Seed) (inherited actualCost : Nat)
theorem callback_count_le (seed : Seed) (capturedMass inherited : Nat) (receipt : Core)
theorem callback_padding (seed : Seed) (capturedMass inherited actualCost : Nat)
theorem Reserved.edge {bits inherited capturedMass actualCost : Nat} {seed : Seed}
theorem Reserved.callback {bits inherited capturedMass : Nat} {seed : Seed}
theorem reserved_of_final_room (bits : Nat) (seed : Seed) (capturedMass inherited : Nat)
theorem reserved_computed (seed : Seed) (capturedMass inherited : Nat) :
theorem edge_cost_le (seed : Seed) (inherited : Nat) (scs : List Suspended) (start : Nat)
theorem head_mass_le {width : Nat} (seed : Seed) (capturedMass inherited : Nat)
variable {Typing : Type} {width : Nat}
variable [DecidableEq (EdgeKey Symbol Constraint)]
theorem edge_shape_from_packet
