# Successful recording control

Retain the full objective and checked whole-worker boundary in the published
worker-execution checkpoint. Preserve original public inputs, sound outputs,
configured order and stops, both workers, optimized interned core, adapters,
Haskell correspondence, and the older constructor/equality/count/order work.
The full objective remains incomplete. Work continues.

This phase checks three concrete successful-recording laws. Recording must
retain the counter, complete stored values, recursion ancestry and expansion
ancestry. The existing actual singleton must supply those facts at callbacks.
The pendingSize companion must remove the old UnionFind.Total gate.
Do not claim resolved-root identity, a bound on neutral steps, fresh-handle
closure, sufficient original depth, or coverage from these local laws.
The owner report must distinguish raw bucket work from duplicate-erased key
cardinality, and boundary handle preservation from intervening rewrite renewal.

The source-only owner owns /tmp/mcfta-original-capacity-gap-review-20261030.
It has two named old whole-source acquisitions, with bounded cuts elsewhere.
Root owns this separate validation and production integration directory.
Root alone runs compiler, evaluator, native, Git, network, board and packaging.
All checks stay serial at 4 GiB, zero swap and five minutes in Lean 4.34.1.
No resource, heartbeat, queue or service change is authorized.
No Haskell defect, fix or candidate is established by the source draft.

The previous 449-file checkpoint is published at09f8a31a and independently
reconstructed. Its complete publication receipts are retained here.
The current branch received a fresh ff-only pull before this proof phase.
Keep every failed check, repair, source version and compiler input snapshot.
