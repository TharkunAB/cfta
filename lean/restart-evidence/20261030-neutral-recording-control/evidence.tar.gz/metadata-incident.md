The first ownership verifier assumed a contiguous actual range for every acquisition.
Recovered rg locators use explicit disjoint actual_lines.
The V1 verifier and verbatim tool-output transcription remain.
A verbose metadata preview was truncated. The full compact schema table is retained.
The repaired verifier checks each schema and every exact source byte range.
No frozen owner file or production source changed. No compiler check failed.
