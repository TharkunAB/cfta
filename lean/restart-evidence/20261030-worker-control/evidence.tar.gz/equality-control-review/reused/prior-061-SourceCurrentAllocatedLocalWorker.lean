local notation "Memo" => SourceCurrentMemoMergeGraph.Memo Symbol Guard
local notation "Record" => SourceEqualityClassOrder.Record
local notation "Heap" => InternedConstructorTemplates.State Symbol Guard
local notation "runPrefix" => SourceEqualityPartialPrecheckAllocation.run
local notation "advanceHeap" => SourceCurrentConjunctionClassScan.advanceHeap

