setChildren ::
    (Hashable symbol, Typeable symbol) =>
    Edge symbol -> [Node symbol] -> Edge symbol
setChildren e ns
    | length ns == length (edgeChildren e) = internEdge $ UninternedEdge (edgeSymbol e) ns (edgeConstraint e)
    | otherwise = mkEdge (edgeSymbol e) ns (edgeConstraint e)

-- Interning Nodes

-- | Non-canonical node description used before hash-consing.
data UninternedNode symbol
