inductive Descendants (budget : Nat) :
    EqValue → EdgeValue Symbol Guard → Caller width → EdgeValue Symbol Guard → Caller width → Prop where
  | run (combined : (SourceCurrentAllocatedInheritedPrefix.run edge.entry.key.constraint inherited before.checked.operations).1 = .ok (some payload))
      (children : Children budget payload edge.children (prefixState before edge inherited) results middle) :
      Descendants budget inherited edge before
        (SourceCurrentAllocatedRawRebuild.edge edge results middle.checked).1
        (advanceCaller middle (SourceCurrentAllocatedRawRebuild.edge edge results middle.checked).2 middle.fourth middle.merge)

/-- Contradiction skips every child request; a live payload starts the indexed walk. -/
inductive Children (budget : Nat) :
    EqValue → List (Value Symbol Guard) → Caller width → List (Value Symbol Guard) → Caller width → Prop where
  | contradiction : Children budget .contradiction values before (EqualityLeafProjectionRuntimeEmpty.erase values) before
  | live (actual : Walk budget (.live identity records) 0 values before results after) :
      Children budget (.live identity records) values before results after

/-- Each actual descended value is the next recursive request's stored inherited argument. -/
inductive Walk (budget : Nat) :
    EqValue → Nat → List (Value Symbol Guard) → Caller width → List (Value Symbol Guard) → Caller width → Prop where
  | nil : Walk budget combined index [] before [] before
  | cons (head : NodeCall budget ⟨(descend before combined index).1, value⟩
        (descend before combined index).2 result middle)
      (rest : Walk budget combined (index + 1) values middle results after) :
      Walk budget combined index (value :: values) before (result :: results) after
end

