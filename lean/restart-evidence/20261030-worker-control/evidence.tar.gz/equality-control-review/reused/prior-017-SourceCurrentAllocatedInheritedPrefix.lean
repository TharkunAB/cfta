noncomputable def run (original : Guard) (inherited : EqValue) (before : Operations) :
    Except String (Option EqValue) × Operations :=
  match inherited with
  | .contradiction => (.ok (some .contradiction), before)
  | .live _ _ =>
      let own := SourceCurrentConjunctionEquality.accessor original before
      match own.1 with
      | .error message => (.error message, own.2)
      | .ok none => (.ok none, own.2)
      | .ok (some value) =>
          let combined := SourceEqualityConstraintMemoAllocation.combine inherited value own.2
          (combined.1.map some, combined.2)

/-- Inherited contradiction has no accessor or allocation effect. -/
theorem run_contradiction (original : Guard) (before : Operations) :
    run original .contradiction before = (.ok (some .contradiction), before) := rfl

