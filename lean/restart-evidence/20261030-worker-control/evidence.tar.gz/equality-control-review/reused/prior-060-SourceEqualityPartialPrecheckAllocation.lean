noncomputable def run (stored : Value) (guard : SourceGuards.Guard Formula) (inherited : Value) (before : State) :
    Except String SourceEqualityPrecheck.Branch × State :=
  let own := SourceEqualityAccessorAllocation.equalities stored guard before
  match own.1 with
  | .error message => (.error message, own.2)
  | .ok value => SourceEqualityPrecheckAllocation.precheck value inherited own.2

/-- The full source prefix derives its literal own payload, exact branch, and complete allocation receipt. -/
