noncomputable def reduce (g s r e p h m c n budget : Nat) (loaded : Allocated) (inherited : EqValue)
    (values : List (Value Symbol Guard)) (before : Checked width) (fourth : Fourth) (memo : Memo) :
    Outcome (List (Value Symbol Guard)) width :=
  let observed := runPrefix loaded.stored loaded.guard inherited before.operations
  let middle := SourceCurrentAllocatedQueryMemo.advancePhysical before ⟨before.native.machine.heap, observed.2⟩
  match observed.1 with
  | .error message => .failed (.precheck message) middle fourth memo
  | .ok .unchanged => .done values middle fourth memo
  | .ok .emptyChildren => .done (EqualityLeafProjectionRuntimeEmpty.erase values) middle fourth memo
  | .ok (.classes records) => classes g s r e p h m c n budget records values middle fourth memo

