def rebuild [DecidableEq (EdgeKey Symbol Guard)] (entry : Interned NodeKey)
    (body depth ordinary : Value Symbol Guard) (state : State Symbol Guard) : Outcome Symbol Guard (Value Symbol Guard) :=
  (callback entry body depth ordinary .depth state).bind fun actualDepth afterDepth =>
  (callback entry body depth ordinary (.uninterned (ordinaryLevel actualDepth)) afterDepth).bind fun actualOrdinary afterOrdinary =>
    request true actualDepth actualOrdinary (callback entry body depth ordinary) afterOrdinary

/-- The actual Depth probe uses the cached record and leaves the cache unchanged. -/
