unconstrained :: forall symbol. (Typeable symbol) => Node symbol -> Bool
unconstrained = memoTypeableWith @symbol unconstrainedCache $ getAll . crush free
  where
    free (Node es) = All (all (\e -> equalities (edgeConstraint e) == EmptyConstraints && not (residual (edgeConstraint e))) es)
    free _ = All True

{- | Whether a closed node reaches a recursive node with constraints. A
recursive node without constraints reaches no constraint at all, so the walk
does not enter it.
-}
reachesConstrainedMu :: forall symbol. (Typeable symbol) => Node symbol -> Bool
reachesConstrainedMu = memoTypeableWith @symbol reachesConstrainedMuCache go
  where
    go n | numNestedMu n == 0 = False
    go n@(InternedMu _) = not (unconstrained n)
    go (InternedUnion alternatives) = any reachesConstrainedMu (internedUnionMembers alternatives)
    go (Node es) = any (any reachesConstrainedMu . edgeChildren) es
    go _ = False
{-# INLINEABLE reachesConstrainedMu #-}
{-# SPECIALIZE reachesConstrainedMu :: Node Symbol -> Bool #-}

-- | Table for 'reachesConstrainedMu'.
