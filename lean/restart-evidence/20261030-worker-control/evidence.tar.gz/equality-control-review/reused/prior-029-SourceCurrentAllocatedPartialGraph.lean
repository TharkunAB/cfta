inductive EdgeBody (budget : Nat) : EdgeReq → Caller width → EdgeValue Symbol Guard → Caller width → Prop where
  | parent (field : SourceEqualityMkEdgeAllocation.contradictory edge.entry.key.constraint = false →
        SourceEqualityConstraintFieldLookup.load edge.entry.key.constraint before.checked.operations.constraints = .ok (some loaded))
      (actual : SourceCurrentAllocatedParentEdge.Edge budget edge.entry.key.symbol edge.entry.key.constraint loaded inherited
        edge.children before.checked before.fourth before.merge result checked fourth merge) :
      EdgeBody budget ⟨inherited, edge⟩ before result (advanceCaller before checked fourth merge)

/-- Each ordered row runs its edge request, returned-edge descendants, and then its tail. -/
