noncomputable def edgeBody (_fuel g s r e p h m c n budget : Nat) (request : EdgeRequest)
    (before : Caller width) : Outcome Edge width :=
  match SourceCurrentAllocatedParentWorker.edge g s r e p h m c n budget
      request.value.entry.key.symbol request.value.entry.key.constraint request.inherited
      request.value.children before.checked before.fourth before.merge with
  | .done result checked fourth memo => .done result (advance before checked fourth memo)
  | .failed fault checked fourth memo => .failed (.parent fault) (advance before checked fourth memo)

/-- Each original row uses its returned parent edge for descendants before entering the suffix. -/
