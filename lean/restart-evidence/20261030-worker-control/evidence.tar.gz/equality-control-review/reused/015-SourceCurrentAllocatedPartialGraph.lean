inductive NodeCall (budget : Nat) : NodeReq → Caller width → Value Symbol Guard → Caller width → Prop where
  | hit (started : beginNode request before = (handle, (.ready result, running))) :
      NodeCall budget request before result running
  | evaluate (started : beginNode request before = (handle, (.evaluate original, running)))
      (body : NodeBody budget original running result middle) :
      NodeCall budget request before result (finishNode handle result middle)

/-- Source node bodies retain empty, union, binder reconstruction, and ordered ordinary rows. -/
inductive NodeBody (budget : Nat) : NodeReq → Caller width → Value Symbol Guard → Caller width → Prop where
  | empty : NodeBody budget ⟨inherited, .empty⟩ before .empty before
  | union : NodeBody budget ⟨inherited, .union entry members depth free⟩ before (.union entry members depth free) before
  | binder (actual : SourceEqualityMuReconstruction.rebuild entry body depth ordinary before.checked.native.machine.heap = .done result heap) :
      NodeBody budget ⟨inherited, .mu entry body depth ordinary⟩ before result
        (advanceCaller before
          (SourceCurrentAllocatedQueryMemo.advancePhysical before.checked ⟨heap, before.checked.operations⟩)
          before.fourth before.merge)
  | ordinary (rows : Rows budget inherited edges before results middle) :
      NodeBody budget ⟨inherited, .node entry edges depth free⟩ before
        (SourceCurrentAllocatedRawRebuild.modify (.node entry edges depth free) edges results middle.checked).1
        (advanceCaller middle
          (SourceCurrentAllocatedRawRebuild.modify (.node entry edges depth free) edges results middle.checked).2
          middle.fourth middle.merge)

/-- The edge result table is separate and retains its own published original edge. -/
