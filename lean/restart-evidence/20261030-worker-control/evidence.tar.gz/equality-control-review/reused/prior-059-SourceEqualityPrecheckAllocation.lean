noncomputable def precheck (own inherited : Value) (before : State) :
    Except String SourceEqualityPrecheck.Branch × State :=
  if SourceEqualityPrecheck.isEmpty own.payload && SourceEqualityPrecheck.isEmpty inherited.payload then
    (.ok .unchanged, before)
  else
    let combined := SourceEqualityConstraintMemoAllocation.combine own inherited before
    match combined.1 with
    | .error message => (.error message, combined.2)
    | .ok .contradiction => (.ok .emptyChildren, combined.2)
    | .ok (.live _ _) => ((SourceEqualityPrecheck.unsafeOrdered own.payload).map .classes, combined.2)

/-- Both physical empty inputs retain the complete state before combination and ordering. -/
