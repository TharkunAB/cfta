local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "NodeReq" => SourceCurrentAllocatedPartialState.NodeRequest
local notation "EdgeReq" => SourceCurrentAllocatedPartialState.EdgeRequest
local notation "EqValue" => SourceEqualityConstraintAllocation.Value
local notation "advanceCaller" => SourceCurrentAllocatedPartialState.advance
local notation "beginNode" => SourceCurrentAllocatedPartialState.beginNode
local notation "beginEdge" => SourceCurrentAllocatedPartialState.beginEdge
local notation "finishNode" => SourceCurrentAllocatedPartialState.finishNode
local notation "finishEdge" => SourceCurrentAllocatedPartialState.finishEdge
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] [DecidableEq (Value Symbol Guard)] {width : Nat}

/-- An indexed descent retains every other caller table at its literal operation return. -/
def descend (before : Caller width) (combined : EqValue) (index : Nat) : EqValue × Caller width :=
  let actual := SourceEqualityConstraintMemoAllocation.descend combined index before.checked.operations
  (actual.1, advanceCaller before
    (SourceCurrentAllocatedQueryMemo.advancePhysical before.checked ⟨before.checked.native.machine.heap, actual.2⟩)
    before.fourth before.merge)

/-- The single inherited prefix uses the actual returned edge field. -/
noncomputable def prefixState (before : Caller width) (edge : EdgeValue Symbol Guard) (inherited : EqValue) : Caller width :=
  advanceCaller before (SourceCurrentAllocatedInheritedPrefix.state before.checked edge.entry.key.constraint inherited)
