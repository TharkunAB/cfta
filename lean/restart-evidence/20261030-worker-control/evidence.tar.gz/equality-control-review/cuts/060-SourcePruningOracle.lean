def oracle (graph : Graph Symbol Guard) (templates : List (Template.Pattern Symbol))
    (fuel : Nat) : Oracle Symbol Guard (List (Pending Symbol)) := fun pending uv input =>
  match input with
  | .inr _ => pure (false, pending)
  | .inl fragment =>
      if rejectEarly templates fragment = true then pure (true, pending)
      else if idle pending fragment = true then pure (false, [])
      else observe graph templates fuel pending uv fragment

