theorem initial_node_call
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    {g s r e p h m c n budget : Nat} {inventory : Inventory} {memos : Memos}
    {request : NodeRequest} {before : Caller (bits + 2)}
    (seed : List Guard × Profile) :
    let output := envelope budget
      (SourceCurrentPositiveQuotientCount.count (request.inherited.payload.getD []) request.value)
      (InternedValueMass.value request.value) seed
    let first : Phase (bits + 2) := .node output.1 request before
    let need := phaseNeed budget first seed
    ∀ (_initial : Context formulas solver inventory before memos)
      (_frame : Frame formulas solver inventory before.checked)
      (_fits : Fits seed.2 before.checked)
      (_known : SourceEqualityAnnotationHeap.Heap (fun guard => guard ∈ seed.1)
        before.checked.native.machine.heap)
      (_inputs : SourceCurrentOuterPrefixInvariants.Inputs first)
      (_room : Room bits (SourceCurrentInitialSelectionForecast.cover [output.2.2.2]
        (SourceCurrentOuterInitialPrefix.forecast budget first seed).2))
      (_normal : SourceCurrentRequiredUnionNormal.UnionNormal before.checked.native.machine.heap)
      (_supported : SourceCurrentNativeRequestPositivePositions.Support
        before.checked.native.machine.heap before.checked.native)
      (_causal : SourceCurrentNativeMuPublication.History empty before.checked.native.machine.heap)
      (_merged : SourceCurrentConstrainedCapMemoMerge.Stored
        (fun guard : Guard => SourceMemoGate.plain guard = true) before.merge)
      (_positiveMemo : SourceCurrentMergePositivePosition.Support before.merge)
      (_origins : SourceCurrentResourceParentWriters.Origins formulas solver before)
      (_stored : SourceCurrentOuterClosedInputs.NodeStored before)
      (_closed : SourceCurrentOuterClosedInputs.InputsClosed first)
      (_initialNodeIdle : ∀ chosen owner, before.nodeResults.cells chosen ≠ some ⟨owner, .evaluating⟩)
      (_initialEdgeIdle : SourceCurrentOuterEdgeIdle.EdgeIdle before)
      (_gBound : need ≤ g) (_sBound : need ≤ s) (_rBound : need ≤ r)
      (_eBound : need ≤ e) (_pBound : need ≤ p) (_hBound : need ≤ h)
      (_mBound : need ≤ m) (_cBound : need ≤ c) (_nBound : need ≤ n),
    ∃ result after, ∀ fuel, output.1 ≤ fuel →
      nodeCall fuel g s r e p h m c n budget request before = .done result after
 := by
  dsimp only
  intro initial frame fits known inputs room normal supported causal merged positiveMemo origins stored closed
    initialNodeIdle initialEdgeIdle gBound sBound rBound eBound pBound hBound mBound cBound nBound
  let output := envelope budget (rankCount (request.inherited.payload.getD []) request.value) (massOf request.value) seed
  let first : Phase (bits+2) := .node output.1 request before
  have rootRoom : Room bits (SourceCurrentOuterInitialPrefix.forecast budget first seed).2 :=
    room.mono (cover_ge _ _)
  have outputRoom : Room bits output.2.2.2 := room.mono (cover_member _ List.mem_cons_self)
  have classified := SourceCurrentOuterDoneOrExhausted.done_or_exhausted formulas solver (first := first) seed initial frame fits known
    inputs rootRoom normal supported causal merged positiveMemo origins stored closed initialNodeIdle initialEdgeIdle
    gBound sBound rBound eBound pBound hBound mBound cBound nBound
  have resources {phase : Phase (bits+2)} (cut : Reached g s r e p h m c n budget first phase) :=
    SourceCurrentOuterInitialPrefix.reached formulas solver seed cut initial frame fits known inputs rootRoom
  have only_exhausted {phase : Phase (bits+2)} {fault : Fault (bits+2)} {after : Caller (bits+2)}
      (cut : Reached g s r e p h m c n budget first phase)
