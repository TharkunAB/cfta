theorem key_ne_top
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    {request : EdgeRequest} {returned : Edge}
    (written : SourceCurrentResourceParentWriters.Written (bits := bits) formulas solver request returned)
    {ownerEntry ownerDepth ownerFree} {ownerRows : List Edge} {index : Nat}
    (member : request.value ∈ ownerRows)
    (found : returned.children[index]? = some (.node ownerEntry ownerRows ownerDepth ownerFree))
    (prefixBefore : Operations) (valid : Valid prefixBefore)
    (ready : EqReady prefixBefore.constraints request.inherited)
    (field : SourceCurrentConjunctionEquality.FieldAvailable prefixBefore returned.entry.key.constraint)
    (combined : EqValue)
    (prefixActual : (SourceCurrentAllocatedInheritedPrefix.run returned.entry.key.constraint
      request.inherited prefixBefore).1 = .ok (some combined))
    (live : combined ≠ .contradiction)
    (later : Operations) (laterValid : Valid later)
    (laterGrowth : Grows (SourceCurrentAllocatedInheritedPrefix.run returned.entry.key.constraint
      request.inherited prefixBefore).2 later)
    (identity : Nat) (top : EqReady prefixBefore.constraints (.live identity [])) :
    let child := SourceEqualityConstraintMemoAllocation.descend combined index later
    returned.entry.key.constraint = request.value.entry.key.constraint ∧
      SourceMemoGate.plain request.value.entry.key.constraint = false ∧
      child.1.payload ≠ some [] ∧
      (NodeRequest.mk child.1 (.node ownerEntry ownerRows ownerDepth ownerFree)).key ≠
        (NodeRequest.mk (.live identity []) (.node ownerEntry ownerRows ownerDepth ownerFree)).key := by
  obtain ⟨g,s,r,e,p,h,m,c,n,budget,writerBefore,writerAfter,savedFourth,savedMerge,
      globals,inventory,profile,observed,context,frame,fits,inheritedReady,resident,
      liveInputs,reserved,normal,supported,⟨causal⟩,merged,positiveMemo⟩ := written
  have nativeGood := SourceCurrentNativeOperationHeap.Good.of_native
    (SourceCurrentNativeOperationInvariants.Good.of_checked context.ready.good) context.ready.semantic context.ready.costs
  obtain ⟨loaded,middle,records,kept,scanned,scanFourth,preparedValues,preparedHeap,
      noncontradictory,loadedAt,_reduced,_built,_accepted,precheck,scanCall,nonempty,
      requiredCall,passCall,_sameFourth,primary⟩ :=
    SourceCurrentActualOwnerSelection.selected observed nativeGood context.stored liveInputs member found
  obtain ⟨fieldAt,_inherited,_available⟩ := liveInputs noncontradictory
  have parentLive : SourceCurrentParentNumeric.LiveInputs request.value.entry.key.constraint loaded
      request.inherited request.value.children writerBefore :=
    fun _ => ⟨fieldAt.1,loadedAt,inheritedReady,_available⟩
  have parentReserved : SourceCurrentParentForecast.Reserved bits budget request.value.children.length
      request.value.entry.key.constraint loaded request.inherited writerBefore.checked profile := by
    simpa only [SourceCurrentParentForecast.residentReserved,noncontradictory,
      Bool.false_eq_true,ite_false,loadedAt] using reserved
  obtain ⟨next,final,own,preparedInventory,scanMemos,preparedMemos,numeric,trace,retained,
