  intro related
  rcases SourceCurrentNormalizedChildSeparation.single fixed related with same |
      ⟨paths, selected, a, aMember, b, bMember, suffix, firstSame, secondSame⟩
  · exact nonempty same.symm
  have empty := List.append_eq_nil_iff.mp firstSame.symm
  rcases empty with ⟨rfl, rfl⟩
  simp only [List.append_nil] at secondSame
  have different : [] ≠ b := by
    intro same
    apply nonempty
    exact secondSame.trans same.symm
  exact consistent_subsumption_irreflexive _ (consistent fixed) paths selected
    ⟨[], aMember, b, bMember, ⟨b, rfl⟩, different⟩

private def relationSetoid (classes : Constraints) : Setoid Path where
  r := Rel classes
  iseqv := ⟨Rel.refl, fun related => rel_symm related, fun first second => .trans first second⟩

/-- Count the inherited-relation classes represented by positive natural child paths. -/
noncomputable def count (inherited : List Record) (value : Node) : Nat := by
  classical
  exact (((positivePaths value).map (Quotient.mk (relationSetoid (inherited.map Record.paths)))).eraseDups).length

/-- Actual descended records bound every backwards-linked child and strictly count a nonplain row. -/
theorem child_count
    (parents inherited : List Record)
    (coherent : ∀ record ∈ parents, SourceEqualityClassOrder.Coherent record)
    (fixed : congruenceStep (parents.map Record.paths) = some (parents.map Record.paths))
