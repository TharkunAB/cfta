
private noncomputable def row (budget : Nat) (all : Seed → List Out)
    (acc : Out) (_index : Nat) : Out :=
  let post := SourceCurrentOuterInitialSchedule.parent budget acc.2.2
  let walked := (List.range post.2.mass).foldl (slot all) (0,0,post)
  (acc.1 + 1 + walked.1,
    max acc.2.1 (max (SourceCurrentParentUniformEnvelope.fuel budget acc.2.2.1 acc.2.2.2) walked.2.1),
    SourceCurrentOuterInitialSchedule.rebuild walked.2.2)

private noncomputable def recipe (budget : Nat) (rank : Nat × Nat)
    (recurse : ∀ child, Prod.Lex Nat.lt Nat.lt child rank → Seed → Out)
    (seed : Seed) : Out :=
  let completed := (List.range rank.2).foldl (row budget (images rank recurse)) (0,0,seed)
  (1 + completed.1, completed.2.1, SourceCurrentOuterInitialSchedule.rebuild completed.2.2)

/-- Compute finite work, lower fuel, and an output seed from the initial rank and seed. -/
