noncomputable def run [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (unconstrained : Value Symbol Guard → Bool) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (clear : Guard → Bool) (top : Guard)
    (g e p h c n : Nat) (edge : EdgeValue Symbol Guard) (inherited : SourceEqualityPrecheck.Constraint) (before : NativeState width Symbol Guard) : Result width Formula :=
  match SourceEqualityPhysicalPayload.own edge.entry.key.constraint with
  | .error message => .done (.error message) before
  | .ok payload => finish edge (SourceEqualityOnePassWorker.run unconstrained emptyGuard conjoin clear top g e p h c n payload inherited edge.children before)

