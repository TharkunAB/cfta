noncomputable def gate (belowEnd : Bool) (fuel : Nat) (values : List (Value Symbol Guard))
    (paths : Class) (before : Checked width) (memo : Memo) : Outcome Bool width :=
  match (if belowEnd then SourceCurrentAllocatedGateWorker.primary fuel values paths before
      else SourceCurrentAllocatedGateWorker.secondary fuel values paths before) with
  | .done answer after => .done answer after memo
  | .failed fault after => .failed (.gate paths fault) after memo

/-- A refused class projects without mergeAlternatives and retains the fourth memo. -/
noncomputable def query (p h n : Nat) (values : List (Value Symbol Guard)) (paths : Class)
    (before : Checked width) (memo : Memo) : Outcome (Value Symbol Guard) width :=
  match SourceCurrentAllocatedSeededWorker.seeded p h n values (paths.map (List.map Int.ofNat)) before with
  | .done value after => .done value after memo
  | .failed fault after => .failed (.query paths fault) after memo

/-- The current fourth memo installs only a completed literal conjunction answer. -/
noncomputable def decision (p h budget : Nat) (paths : Class) (value : Value Symbol Guard)
    (before : Checked width) (memo : Memo) : Outcome Bool width :=
  match SourceCurrentAllocatedConjunctionWorker.call p h budget value before memo with
  | .done answer after saved => .done answer after saved
  | .failed fault after saved => .failed (.decision paths fault) after saved

/-- Only reached branches execute; a true conjunction answer skips the remaining classes. -/
noncomputable def scan (g s p h n budget : Nat) (values : List (Value Symbol Guard)) :
    Constraints → Checked width → Memo → Outcome Result width
  | [], before, memo => .done (none, []) before memo
  | paths :: classes, before, memo =>
      (gate true g values paths before memo).bind fun primary middle current =>
        if primary then
          (gate false s values paths middle current).bind fun secondary later saved =>
            if secondary then scan g s p h n budget values classes later saved
            else (query p h n values paths later saved).bind fun value checked fourth =>
              (decision p h budget paths value checked fourth).bind fun answer after final =>
                if answer then .done (some paths, []) after final
                else scan g s p h n budget values classes after final
        else (scan g s p h n budget values classes middle current).select paths

/-- Empty input retains the complete checked state and fourth memo at every bound. -/
