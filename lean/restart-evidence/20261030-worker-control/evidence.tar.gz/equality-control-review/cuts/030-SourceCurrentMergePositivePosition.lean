theorem run (clear : Guard → Bool) (top : Guard) (topPlain : SourceMemoGate.plain top = true)
    {code : Code Symbol Guard Output} {before after : Heap}
    {memo saved : Memo Symbol Guard} {output : Output}
    (actual : Run clear top code before memo output after saved) :
    ∀ (post : Heap → Output → Prop), SemanticReady before → CostHeap before →
      Stored before memo → Support memo →
      Certified (fun input previous result current =>
        SourceCurrentMemoMergeEffects.Contract input previous result current ∧
          ∀ path, PositiveAt result path → PositiveAt input path) clear code before post →
      Effect before after ∧ Stored after saved ∧ Support saved ∧ post after output := by
  induction actual using Run.rec
      (motive_2 := fun input before memo output after saved _ =>
        SemanticReady before → CostHeap before → Stored before memo → Support memo →
          Available before input → Effect before after ∧ Stored after saved ∧ Support saved ∧
            RequestContract input before output after) with
  | pure value state memo =>
      intro post semantic costs stored support checked
      exact ⟨effect_refl _ semantic costs, stored, support, checked⟩
  | work job state memo =>
      intro post semantic costs stored support checked
      exact ⟨checked.1, stored.grows checked.1.keeps, support, checked.2⟩
  | select fuel done =>
      intro post semantic costs stored support checked
      have original := SourceCurrentMergedHeapEffects.select_effect (fun _ => True) _ fuel _ _
