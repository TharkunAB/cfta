def wrap (value : Syntax Symbol Guard) : Syntax Symbol Guard := .node [.mk ("w", .top) sourceTop [value]]

/-- The closed unconstrained binder accepts wrapped binary trees. -/
def plain : Syntax Symbol Guard := .binder true (.node [.mk ("a", .top) sourceTop [],
  .mk ("p", .top) sourceTop [wrap (.var 0),wrap (.var 0)]])

/-- One ordinary binary layer contains the fixed unconstrained binder. -/
def next : Syntax Symbol Guard := .node [.mk ("p", .top) sourceTop [wrap plain,wrap plain]]

/-- A productive binder repeats the root equality below its own wrapper. -/
def constrained : Syntax Symbol Guard := .binder true (.node [.mk ("a", .top) sourceTop [],
  .mk ("p", .top) equality [wrap (.var 0),wrap next]])

/-- Both selected endpoints are closed ordinary wrappers. -/
def expression : Syntax Symbol Guard := .node [.mk ("p", .top) equality [wrap constrained,wrap next]]
