noncomputable def envelope (budget count mass : Nat)
    (seed : List Guard × Profile) : Nat × Nat × (List Guard × Profile) :=
  WellFounded.fix (C := fun _ : Nat × Nat => Seed → Out)
    (Prod.lex Nat.lt_wfRel Nat.lt_wfRel).wf (recipe budget) (count,mass) seed

private theorem envelope_eq (budget count mass : Nat) (seed : Seed) :
    envelope budget count mass seed = recipe budget (count,mass)
      (fun child _ current => envelope budget child.1 child.2 current) seed := by
  unfold envelope
  rw [WellFounded.fix_eq]
  apply congrArg (fun recurse => recipe budget (count,mass) recurse seed)
  funext child smaller current
  cases child
  rfl

private theorem fold_retains (step : Out → Nat → Out)
    (growth : ∀ acc index, Le acc.2.2.2 (step acc index).2.2.2 ∧
      acc.2.2.1 ⊆ (step acc index).2.2.1)
    (values : List Nat) (initial : Out) :
    Le initial.2.2.2 (values.foldl step initial).2.2.2 ∧
      initial.2.2.1 ⊆ (values.foldl step initial).2.2.1 := by
  induction values generalizing initial with
  | nil => exact ⟨Le.refl _, fun _ member => member⟩
  | cons first rest ih =>
      have one := growth initial first
      have last := ih (step initial first)
      exact ⟨one.1.trans last.1, fun _ member => last.2 (one.2 member)⟩

private theorem fold_work (step : Out → Nat → Out)
    (growth : ∀ acc index, acc.1 + 1 ≤ (step acc index).1)
    (values : List Nat) (initial : Out) :
    initial.1 + values.length ≤ (values.foldl step initial).1 := by
  induction values generalizing initial with
