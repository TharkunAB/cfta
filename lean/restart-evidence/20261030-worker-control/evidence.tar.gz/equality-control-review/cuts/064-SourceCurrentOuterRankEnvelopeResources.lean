      SourceEqualityAnnotationHeap.Heap (fun guard => guard ∈ output.2.2.1)
        after.checked.native.machine.heap
 := by
  have resources {phase : Phase (bits+2)} (cut : Reached g s r e p h m c n budget first phase) :=
    SourceCurrentOuterInitialPrefix.reached formulas solver rootSeed cut initial frame fits known inputs rootRoom
  have widen {one two : Seed} {state : SourceEqualityNativeDemand.State (bits+2)}
      (below : Kept one two) (numeric : Fits one.2 state)
      (carrier : SourceEqualityAnnotationHeap.Heap (fun guard => guard ∈ one.1) state.native.machine.heap) :
      Fits two.2 state ∧ SourceEqualityAnnotationHeap.Heap (fun guard => guard ∈ two.1) state.native.machine.heap :=
