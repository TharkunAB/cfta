        (SourceCurrentPositiveQuotientCount.count (inherited.payload.getD [])
            (.node ownerEntry ownerRows ownerDepth ownerFree),
          InternedValueMass.value (.node ownerEntry ownerRows ownerDepth ownerFree : Node))

 := by
  obtain ⟨rowInventory,rowMemos,rowSeed,_rowTrace,rowPost,rowFrame,rowFits,rowKnown,
      rowInputs,_rowBelow,_rowAlphabet,rowRoom,_rowBounds,_rowCarrier,_rowNeed,
      rowSupport,⟨rowCausal⟩,rowMerged,rowPositive,rowNormal⟩ :=
    SourceCurrentOuterPrefixNativeStores.reached formulas solver seed past initial frame fits known inputs room
      normal supported causal merged positiveMemo
  have rowOrigins := SourceCurrentOuterResourceWriters.reached formulas solver seed past
    initial frame fits known inputs room normal supported causal merged positiveMemo origins
  have headRoom := rowRoom
  change Room bits (SourceCurrentOuterInitialSchedule.rows ((fuel + slot + 1) + 1) budget rowSeed).2 at headRoom
  rw [SourceCurrentOuterInitialSchedule.rows] at headRoom
  let parentSeed := SourceCurrentOuterInitialSchedule.parent budget rowSeed
  have parentRoom : Room bits parentSeed.2 := headRoom.mono
    ((SourceCurrentOuterInitialSchedule.descendants_ge (fuel + slot + 1) budget parentSeed).1.trans
      (SourceCurrentOuterInitialSchedule.rows_ge (fuel + slot + 1) budget
        (SourceCurrentOuterInitialSchedule.descendants (fuel + slot + 1) budget parentSeed)).1)
  have uniform := SourceCurrentOuterInitialSchedule.parent_reserved bits budget rowSeed parentRoom
  have reserved := reservation formulas solver (request := ⟨inherited,original⟩)
    rowPost.context rowFits rowKnown rowInputs.1 (rowInputs.2 _ List.mem_cons_self) uniform
  have written := (SourceCurrentResourceParentWriters.edge_call formulas solver rowInventory rowSeed.2 rowMemos
