                            [ keyNode $ joinGroupIndex group
                            , singletonNode $ outcomeTerm outcome
                            ]
                        | group <- groups
                        , outcome <- toList $ joinGroupRight group
                        ]
                joined =
                    reducePartially $
                        Node
                            [mkEdge Join [leftNode, rightNode] keysEqual]
                -- The private join labels flatten into the roots of the two sides.
                sideRootCount terms = commonRootCount $ map (RootCount . termRootCount) terms
                rootCount =
