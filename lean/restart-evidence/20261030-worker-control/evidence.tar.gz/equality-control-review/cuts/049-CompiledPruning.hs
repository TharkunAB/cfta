  where
    selected = filter eligible templates
    residual = residualTemplates selected templates
    prepared root = do
        compiled <- compileTemplates selected root
        (before, beforeOpaque) <- graph True (4096, 65536) compiled
        ( Map.size before
                + sum [length es | (_, es) <- Map.elems before]
                + Set.size beforeOpaque
            )
            `seq` pure ()
        let reduced = reducePartially compiled
        (after, afterOpaque) <- graph False (4096, 65536) reduced
        ( Map.size after
                + sum [length es | (_, es) <- Map.elems after]
                + Set.size afterOpaque
                + Set.size (afterOpaque `Set.difference` beforeOpaque)
            )
            `seq` pure (reduced, residual)

-- | Admit only application patterns whose annotation positions are holes.
eligible :: Template Symbol -> Bool
