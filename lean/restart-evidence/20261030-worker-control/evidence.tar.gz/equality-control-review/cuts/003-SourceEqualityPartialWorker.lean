noncomputable def step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (call : SourceEqualityPrecheck.Constraint → Value Symbol Guard → NativeState width Symbol Guard → Result width)
    (g e p h c n : Nat) (inherited : SourceEqualityPrecheck.Constraint) (value : Value Symbol Guard)
    (before : NativeState width Symbol Guard) : Result width :=
  match value with
  | .empty => .done (.ok .empty) before
  | .reference _ => .done (.error "reducePartially: unexpected Rec") before
  | .union .. => .done (.ok value) before
  | .mu entry body depth ordinary =>
      match SourceEqualityMuReconstruction.rebuild entry body depth ordinary before.machine.heap with
      | .done result heap => .done (.ok result) (advanceHeap before heap)
      | .pending key heap => .incomplete (.pending key (advanceHeap before heap))
  | .node entry edges depth free =>
      match SourceEqualityInheritedRows.walk call g e p h c n inherited edges before with
      | .done (.ok results) middle =>
          let built := SourceEqualityPartialNodeRebuild.modify (.node entry edges depth free) edges results middle
          .done (.ok built.1) built.2
      | .done (.error message) middle => .done (.error message) middle
      | observation => .incomplete (.rows observation)

/-- Bounded recursion preserves each exact incomplete observation of a smaller source call. -/
noncomputable def run [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (g e p h c n : Nat) : Nat → SourceEqualityPrecheck.Constraint → Value Symbol Guard → NativeState width Symbol Guard → Result width
  | 0, inherited, value, before => .incomplete (.exhausted inherited value before)
  | fuel + 1, inherited, value, before => step (run g e p h c n fuel) g e p h c n inherited value before

/-- A zero traversal bound records its input and full current native state. -/
theorem exhausted [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (g e p h c n : Nat) (inherited : SourceEqualityPrecheck.Constraint) (value : Value Symbol Guard) (before : NativeState width Symbol Guard) :
    run g e p h c n 0 inherited value before = .incomplete (.exhausted inherited value before) := rfl
