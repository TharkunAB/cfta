def dispatch [DecidableEq (EdgeKey Symbol Guard)] (belowEnd : Bool)
    (unconstrained reaches : Value Symbol Guard → Bool)
    (recur : Path → Value Symbol Guard → State Symbol Guard → Outcome Symbol Guard (Option Bool))
    (path : Path) (value : Value Symbol Guard) (state : State Symbol Guard) : Outcome Symbol Guard (Option Bool) :=
  match value with
  | .reference _ | .union .. => .done (some true) state
  | _ =>
      if value.depth == 0 && value.free.isEmpty then .done (some false) state
      else match value with
        | .mu .. =>
            if !unconstrained value then
              match path with
              | [] => if value.free.isEmpty then .done (some belowEnd) state else .done (some true) state
              | _ :: _ => .done (some true) state
            else if value.free.isEmpty then .done (some false) state
            else (InternedFreshOrdinaryStoredSubstitution.unfold value state).bind fun next after =>
              recur path next after
        | _ => match path with
            | [] => .done (some (!value.free.isEmpty || (belowEnd && reaches value))) state
            | index :: rest => match value with
                | .node _ edges _ _ => anyKnown (fun edge current => child recur edge.children index rest current) edges state
                | _ => .done (some false) state

