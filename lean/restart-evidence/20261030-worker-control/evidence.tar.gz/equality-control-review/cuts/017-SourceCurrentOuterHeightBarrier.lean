theorem supported_required_growth :
    ∃ (program : Syntax Symbol Guard) (input : Value Symbol Guard) (initial : Heap)
        (output : Value Symbol Guard) (final : Heap),
      InternedFreshOrdinaryConstruction.build program [] empty = .done input initial ∧
      SourceEqualityRequiredSemanticCache.SemanticReady initial ∧ Available initial input ∧ input.free = [] ∧
      source input = true ∧
      SourceCurrentMuEndpoint.classMeets true source reaches 1 [input, input] [[0, 0], [1, 0]] initial =
        .done (some false) initial ∧
      SourceEqualityRequiredHead.Head input initial output final ∧
      SourceEqualityRequiredGraph.RequireNode (.node [(0, .node [])]) input initial output final ∧
      SourceEqualityRequiredSemanticCache.SemanticReady final ∧ Available final output ∧ output.free = [] ∧
      height input = 0 ∧ height output = 1 := by
  have checked := head.verified semantic.ready available closed
  exact ⟨expression, original, before, result, after, built_done, semantic, available, closed,
    by cbv, primary, head, required,
    SourceEqualityRequiredSemanticCache.head head semantic available closed,
    checked.2.1, checked.2.2.1, by cbv, by cbv⟩

/-- Even closed, available, unconstrained inputs do not admit the old Required height bound. -/
