noncomputable def primary [DecidableEq (EdgeKey Symbol Guard)] (fuel : Nat)
    (values : List (Value Symbol Guard)) (paths : Class) (before : Checked width) : Outcome width :=
  lift .primary before (SourceCurrentMuEndpoint.classMeets true source reaches fuel
    values paths before.native.machine.heap)

/-- Execute the current secondary class gate with its closed constrained-Mu endpoint rule. -/
noncomputable def secondary [DecidableEq (EdgeKey Symbol Guard)] (fuel : Nat)
    (values : List (Value Symbol Guard)) (paths : Class) (before : Checked width) : Outcome width :=
  lift .secondary before (SourceCurrentMuEndpoint.classMeets false source reaches fuel
    values paths before.native.machine.heap)
