        [ Term.Node (ArgKey componentIndex position) []
        | position <- map ArgumentIndex [0 .. chainLength arguments - 1]
        ]
    unreduced = joinNode componentIndex (staticSupport operation) (chainSupports arguments)
    -- A bounded member of a recursive family keeps its recursive support.
    -- Propagating constraints through a recursive node is not sound, so
    -- such a join stays unreduced, as 'recursiveJoin' does.
    joined
        | numNestedMu unreduced > 0 = unreduced
        | otherwise = reducePartially unreduced
    operationOutcomes = staticOutcomes operation
    argumentsCardinality = chainCardinality arguments
    totalOutcomes = outcomeCardinality operationOutcomes * argumentsCardinality
