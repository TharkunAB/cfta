fixWithin :: (Eq a) => Int -> (a -> a) -> a -> a
fixWithin rounds f x
    | rounds <= 0 || x' == x = x
    | otherwise = fixWithin (rounds - 1) f x'
  where
    x' = f x

-- | Iterate until stable with no iteration bound.
fixUnbounded :: (Eq a) => (a -> a) -> a -> a
fixUnbounded f x
    | x' == x = x
    | otherwise = fixUnbounded f x'
  where
    x' = f x

