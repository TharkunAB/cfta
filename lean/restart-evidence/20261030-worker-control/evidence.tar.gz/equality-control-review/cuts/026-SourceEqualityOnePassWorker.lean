noncomputable def run [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (unconstrained : Value Symbol Guard → Bool) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (clear : Guard → Bool) (top : Guard)
    (g e p h c n : Nat) (own inherited : SourceEqualityPrecheck.Constraint) (values : List (Value Symbol Guard)) (before : NativeState width Symbol Guard) : Result width Symbol Guard :=
  runChecked unconstrained emptyGuard conjoin clear top g e p h c n (precheck own inherited) values before

