noncomputable def step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (call : SourceEqualityPrecheck.Constraint → Value Symbol Guard → State width → Result width (Value Symbol Guard))
    (g e p h c n : Nat) (request : Request) (before : State width) : Result width (Value Symbol Guard) :=
  match request.value with
  | .empty => .done (.ok .empty) before
  | .reference _ => .done (.error "reducePartially: unexpected Rec") before
  | .union .. => .done (.ok request.value) before
  | .mu entry body depth ordinary =>
      match SourceEqualityMuReconstruction.rebuild entry body depth ordinary before.native.machine.heap with
      | .done result heap => .done (.ok result) { before with native := advanceHeap before.native heap }
      | .pending key heap => .incomplete (.pending key { before with native := advanceHeap before.native heap })
  | .node entry edges depth free =>
      (rows call g e p h c n request.inherited edges before).bind fun results middle =>
        let built := SourceEqualityPartialNodeRebuild.modify (.node entry edges depth free) edges results middle.native
        .done (.ok built.1) { middle with native := built.2 }

