local notation "EqReady" => SourceEqualityConstraintAllocation.Ready
local notation "Resident" => InternedEdgeResidency.EdgeResident
local notation "Memos" => EndpointMemoGateTrace.Memos
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] [DecidableEq Node] {width : Nat}
variable (formulas : SourceGuards.Formulas FullSyntax.Formula) (solver : SourceGuards.Entailment FullSyntax.Formula)


/-- The literal completed nodeCall retains its full receipt and derives returned arity. -/
theorem nodeCall_verified
    {fuel g s r e p h m c n budget : Nat} {request : NodeRequest} {before after : Caller width} {result : Node}
    {inventory : Inventory} {memos : Memos}
    (initial : Context formulas solver inventory before memos)
    (inheritedReady : EqReady before.checked.operations.constraints request.inherited)
    (available : Available before.checked.native.machine.heap request.value)
    (ranges : SourceCurrentAllocatedPartialWorkerRanges.nodeCall fuel g s r e p h m c n budget request before)
    (done : nodeCall fuel g s r e p h m c n budget request before = .done result after)
    (heap : Heap before.checked.native.machine.heap) :
    ∃ next final, ∃ actual : NodeCall budget request before result after,
      NodeCallReads formulas solver actual memos final ∧ Checks (nodeCallTrace actual) ∧
      Post formulas solver next before after final ∧ Available after.checked.native.machine.heap result ∧ NodeLaw formulas solver request result ∧
      Heap after.checked.native.machine.heap := by
  obtain ⟨next, final, actual, reads, checks, post, output, law⟩ :=
    SourceCurrentAllocatedPartialWorkerActual.nodeCall_verified formulas solver initial inheritedReady available ranges done
  exact ⟨next, final, actual, reads, checks, post, output, law,
    SourcePruningEnumerationPartialActualArity.node_call_heap formulas solver reads inventory checks initial
      inheritedReady available heap⟩
