private abbrev Causal [DecidableEq (EdgeKey Symbol Guard)] (state : Machine Symbol Guard) :=
  Nonempty (SourceCurrentNativeMuPublication.History empty state.heap)
private abbrev Back (left right result : Node) :=
  ∀ path, PositiveAt result path → PositiveAt left path ∨ PositiveAt right path
private abbrev RowBack (left right result : Row) :=
  (SourceMemoGate.plain result.entry.key.constraint = false →
    SourceMemoGate.plain left.entry.key.constraint = false ∨ SourceMemoGate.plain right.entry.key.constraint = false) ∧
  ∀ (index : Nat) (child : Node), result.children[index]? = some child → ∀ path, PositiveAt child path →
    (∃ original, left.children[index]? = some original ∧ PositiveAt original path) ∨
    (∃ original, right.children[index]? = some original ∧ PositiveAt original path)
private def NodePos (source : Heap) (request : NodeRequest Symbol Guard) (result : Node) :=
  ∀ depth, OriginalBindings Plain source request.domain.key → NodeInputs source request →
    Cap Plain depth request.left → Cap Plain depth request.right → Back request.left request.right result
private def EdgePos (source : Heap) (request : EdgeRequest Symbol Guard) (result : Row) :=
  ∀ depth, OriginalBindings Plain source request.domain.key → EdgeInputs source request →
    Edge Plain depth request.left → Edge Plain depth request.right → RowBack request.left request.right result
/-- Returned native cells retain same-position support for their full captured requests. -/
def Support (source : Heap) (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) : Prop :=
  FlatMemoThunk.Valid (fun _ _ => True) (FlatMemoThunk.CellSpec (fun request result =>
    ∀ depth, OriginalBindings Plain source request.domain.key → NodeInputs source request →
      Cap Plain depth request.left → Cap Plain depth request.right → ∀ path, PositiveAt result path →
      PositiveAt request.left path ∨ PositiveAt request.right path)) state.nodes ∧
  FlatMemoThunk.Valid (fun _ _ => True) (FlatMemoThunk.CellSpec (fun request result =>
    ∀ depth, OriginalBindings Plain source request.domain.key → EdgeInputs source request →
      Edge Plain depth request.left → Edge Plain depth request.right →
      (SourceMemoGate.plain result.entry.key.constraint = false →
        SourceMemoGate.plain request.left.entry.key.constraint = false ∨ SourceMemoGate.plain request.right.entry.key.constraint = false) ∧
      ∀ (index : Nat) (child : Node), result.children[index]? = some child → ∀ path, PositiveAt child path →
        (∃ original, request.left.children[index]? = some original ∧ PositiveAt original path) ∨
        (∃ original, request.right.children[index]? = some original ∧ PositiveAt original path))) state.edges

private structure Stored (source : Heap) (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) : Prop where
  nodes : FlatMemoThunk.Valid (fun _ _ => True) (FlatMemoThunk.CellSpec (NodePos source)) state.nodes
