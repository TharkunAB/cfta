noncomputable def descendants [DecidableEq (EdgeKey Symbol Guard)]
    (call : SourceEqualityPrecheck.Constraint → Value Symbol Guard → State width → Result width (Value Symbol Guard))
    (edge : EdgeValue Symbol Guard) (inherited : SourceEqualityPrecheck.Constraint) (before : State width) : Result width (EdgeValue Symbol Guard) :=
  match SourceEqualityPhysicalPayload.own edge.entry.key.constraint with
  | .error message => .done (.error message) before
  | .ok own => match SourceEqualityInheritedPayload.combine inherited own with
    | .error message => .done (.error message) before
    | .ok payload => (children call payload edge.children before).bind fun values middle =>
        let built := run (makeEdge edge.entry.key.symbol edge.entry.key.constraint values) middle.native.machine.heap
        .done (.ok built.1) { middle with native := advanceHeap middle.native built.2 }

/-- The existing native narrowing worker precedes inherited recursive requests. -/
noncomputable def edge [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (call : SourceEqualityPrecheck.Constraint → Value Symbol Guard → State width → Result width (Value Symbol Guard))
    (g e p h c n : Nat) (value : EdgeValue Symbol Guard) (inherited : SourceEqualityPrecheck.Constraint) (before : State width) : Result width (EdgeValue Symbol Guard) :=
  match SourceEqualityGuardedEdgeWorker.run SourceMemoGate.unconstrained SourceEqualityConstraintConstructors.top
      SourceEqualityPCSNativeEdge.conjoin SourceMemoGate.plain SourceEqualityConstraintConstructors.top g e p h c n value inherited before.native with
  | .done (.ok narrowed) middle => descendants call narrowed inherited { before with native := middle }
  | .done (.error message) middle => .done (.error message) { before with native := middle }
  | observation => .incomplete (.guarded observation before.constraints before.memo)

/-- Ordered rows retain every completed row's full returned state. -/
