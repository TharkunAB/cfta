theorem request (width depth : Nat) (machine : Machine Symbol Guard) (operations : SourceEqualityConstraintMemoAllocation.State)
    (good : SourceCurrentAllocatedNativePhysicalCompletion.Good (⟨initial width machine,operations⟩ : Checked width))
    (semantic : SourceEqualityRequiredSemanticCache.SemanticReady machine.heap)
    (guards : SourceCurrentConstrainedCapGuardHeap.Heap Plain machine.heap)
    (causal : SourceCurrentNativeMuPublication.History empty machine.heap)
    (left right result : Node) (leftAvailable : Available machine.heap left) (rightAvailable : Available machine.heap right)
    (leftClosed : left.free = []) (rightClosed : right.free = [])
    (leftCap : Cap Plain depth left) (rightCap : Cap Plain depth right) (fuel : Nat) (after : Checked width)
    (actual : Trace fuel (.code (requestNode IntersectionEmptyDomain.emptyDomain left right))
      ⟨initial width machine,operations⟩ (.code (.pure result)) after) :
    Support machine.heap after.native ∧ (∀ path, PositiveAt result path → PositiveAt left path ∨ PositiveAt right path) ∧
    SourceCurrentConstrainedCapCheckedJointInduction.Return
      (source := machine.heap) (inventory := SourceRecursiveIntersectionSourceInventory.domains machine.heap) (initial := machine.domains)
      ⟨initial width machine,operations⟩ after result (fun final value => Available final.heap value)
      (fun _ value => NodeLaw Plain machine.heap ⟨IntersectionEmptyDomain.emptyDomain,left,right⟩ value) ∧
    Nonempty (SourceCurrentNativeMuPublication.History empty after.native.machine.heap) := by
  have known := SourceCurrentAllocatedRecursivePrefixState.initial machine.heap (SourceRecursiveIntersectionSourceInventory.domains machine.heap) (⟨initial width machine,operations⟩ : Checked width) good semantic rfl
  exact call machine.heap good.native.machine.1 depth _ after left right result fuel known
    ⟨good.native.machine,semantic.ready.semantic,guards,grows_refl _,extends_refl _⟩ causal
    (SourceCurrentConstrainedCapCheckedJointCache.initial_stored Plain machine.heap width machine)
    ⟨FlatMemoThunk.empty_valid _ _,FlatMemoThunk.empty_valid _ _⟩ leftAvailable rightAvailable leftClosed rightClosed leftCap rightCap actual

/-- An actual completed request retains conditional cell laws without root cap assumptions. -/
