open InternedFreshOrdinaryConstruction
open InternedFreshOrdinaryProbeFilter (Clean filter_fixed)
open InternedBinderProtocol (Reference NodeKey)

/-- Actual matcher fast paths precede the stored substitution fallback. -/
def matched [DecidableEq (EdgeKey Symbol Guard)] (entry : Interned NodeKey)
    (body depth ordinary : Value Symbol Guard) (name : Reference) (state : State Symbol Guard) :
    Outcome Symbol Guard (Value Symbol Guard) :=
  match probeReadback depth ordinary name with
  | some value => .done value state
  | none => InternedFreshOrdinaryStoredSubstitution.execute body
      (InternedStoredSubstitutionRebind.replacement (.interned entry.identity) (.reference name)) state

/-- Source createMu filters the matched body before using a probe or fresh body. -/
def callback [DecidableEq (EdgeKey Symbol Guard)] (entry : Interned NodeKey)
    (body depth ordinary : Value Symbol Guard) (name : Reference) (state : State Symbol Guard) :
    Outcome Symbol Guard (Value Symbol Guard) :=
  (matched entry body depth ordinary name state).bind fun value after => work (withoutSelfReference name value) after

