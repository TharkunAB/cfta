theorem dispatch
    (formulas : SourceGuards.Formulas FullSyntax.Formula)
    (solver : SourceGuards.Entailment FullSyntax.Formula)
    {g s r e p h m c n budget fuel slot : Nat}
    {inherited : EqValue}
    {first : Phase (bits + 2)} {inventory : Inventory} {memos : Memos}
    (seed : List Guard × Profile)
    (initial : Context formulas solver inventory (caller first) memos)
    (frame : Frame formulas solver inventory (caller first).checked)
    (fits : Fits seed.2 (caller first).checked)
    (known : SourceEqualityAnnotationHeap.Heap (fun guard => guard ∈ seed.1)
      (caller first).checked.native.machine.heap)
    (inputs : SourceCurrentOuterPrefixInvariants.Inputs first)
    (room : Room bits (SourceCurrentOuterInitialPrefix.forecast budget first seed).2)
    (normal : SourceCurrentRequiredUnionNormal.UnionNormal (caller first).checked.native.machine.heap)
    (supported : SourceCurrentNativeRequestPositivePositions.Support
      (caller first).checked.native.machine.heap (caller first).checked.native)
    (causal : SourceCurrentNativeMuPublication.History empty (caller first).checked.native.machine.heap)
    (merged : SourceCurrentConstrainedCapMemoMerge.Stored
      (fun guard : Guard => SourceMemoGate.plain guard = true) (caller first).merge)
    (positiveMemo : SourceCurrentMergePositivePosition.Support (caller first).merge)
    (origins : SourceCurrentResourceParentWriters.Origins formulas solver (caller first))
    {ownerEntry ownerDepth ownerFree} {ownerRows : List Edge}
    {original parented : Edge} {rest : List Edge}
    {before afterParent start : Caller (bits + 2)} {earlier : List Node}
    {combined : EqValue} {value : Node}
    (past : Reached g s r e p h m c n budget first
      (.rows (fuel + slot + 2) inherited (original :: rest) before))
    (member : original ∈ ownerRows)
    (parent : edgeCall (fuel + slot + 1) g s r e p h m c n budget
      ⟨inherited, original⟩ before = .done parented afterParent)
    (combinedAt : (SourceCurrentAllocatedInheritedPrefix.run parented.entry.key.constraint
      inherited afterParent.checked.operations).1 = .ok (some combined))
    (live : combined ≠ .contradiction)
    (earlierCalls : walk (fuel + slot + 1) g s r e p h m c n budget combined 0
      (parented.children.take slot) (prefixState afterParent parented inherited) =
        .done earlier start)
    (selected : parented.children[slot]? = some value) :
    let child := descend start combined slot
    Reached g s r e p h m c n budget first (.node fuel ⟨child.1,value⟩ child.2) ∧
      Prod.Lex Nat.lt Nat.lt
        (SourceCurrentPositiveQuotientCount.count (child.1.payload.getD []) value,
          InternedValueMass.value value)
