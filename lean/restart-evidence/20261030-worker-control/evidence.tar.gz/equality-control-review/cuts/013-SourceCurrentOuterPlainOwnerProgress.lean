theorem dispatch {g s r e p h m c n budget ownerFuel fuel slot handle : Nat}
    {owner : NodeRequest} {entry rows depth free} {running before afterParent start : Caller width}
    {original parented : Edge} {rest : List Edge} {combined : EqValue}
    {earlier : List Node} {value : Node}
    (ordinary : owner.value = .node entry rows depth free)
    (good : Good running) (ready : NodeReady running owner)
    (active : running.nodeResults.cells handle = some ⟨owner,.evaluating⟩)
    (origins : Origins running)
    (past : Reached g s r e p h m c n budget (.body ownerFuel owner running)
      (.rows (fuel + slot + 2) owner.inherited (original :: rest) before))
    (member : original ∈ rows)
    (plain : SourceCompactGuards.sourceEqualities original.entry.key.constraint = some [])
    (parent : edgeCall (fuel + slot + 1) g s r e p h m c n budget
      ⟨owner.inherited,original⟩ before = .done parented afterParent)
    (combinedAt : (SourceCurrentAllocatedInheritedPrefix.run parented.entry.key.constraint owner.inherited
      afterParent.checked.operations).1 = .ok (some combined))
    (live : combined ≠ .contradiction)
    (earlierCalls : walk (fuel + slot + 1) g s r e p h m c n budget combined 0
      (parented.children.take slot) (prefixState afterParent parented owner.inherited) = .done earlier start)
    (selected : parented.children[slot]? = some value) :
    Reached g s r e p h m c n budget (.body ownerFuel owner running)
      (.node fuel ⟨(descend start combined slot).1,value⟩ (descend start combined slot).2) ∧
    value.referenceOf ≠ owner.value.referenceOf ∧
      (NodeRequest.mk (descend start combined slot).1 value).key ≠ owner.key := by
  have current := SourceCurrentOuterPrefixInvariants.reached past good ready
  have retained := SourceCurrentOuterPlainRowShapes.reached past good ready origins
  have shape := (SourceCurrentOuterPlainRowShapes.edge_call parent current.1
    ⟨current.2.1,current.2.2 _ List.mem_cons_self⟩ retained).2 plain
  have different : value ≠ owner.value := by
