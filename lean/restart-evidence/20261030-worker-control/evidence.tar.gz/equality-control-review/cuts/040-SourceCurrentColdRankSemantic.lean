  obtain ⟨resultAvailable, law⟩ := SourceCurrentConstructedOuterInitial.node_call
    formulas solver expression value ⟨heap, Cache.emptyState⟩
    (SourceCurrentAllocatedPartialInitialization.operations finalCache)
    built before after inventory SourceCurrentAllocatedPartialInitialization.globals rfl
    (SourceCurrentAllocatedPartialInitialization.inventory_source expression value heap built)
    initial seed fits carrier request inherited inputAvailable
    output.1 need need need need need need need need need budget room result called
  refine ⟨result, after, stableSame, resultAvailable, ?_⟩
  intro ambient term
  apply ((law ambient term).2 ?_).symm
  simp [request, same, SourceEqualityConstraintAllocation.Value.payload,
    SourceEqualityPrecheck.Sat, EqualityNormalize.Satisfies]
