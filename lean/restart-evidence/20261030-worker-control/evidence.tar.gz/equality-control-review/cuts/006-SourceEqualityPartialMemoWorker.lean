noncomputable def request (body : Nat → Request → State width → Result width (Value Symbol Guard))
    (candidate : Request) (before : State width) : Result width (Value Symbol Guard) :=
  let prepared := prepare candidate before
  let published := FlatMemoThunk.lookupOrInsert prepared.1 candidate prepared.2.memo
  let demanded := FlatMemoThunk.demand published.1 published.2
  let running := { prepared.2 with memo := demanded.2 }
  match demanded.1 with
  | .absent => .incomplete (.absent prepared.1 published.1 running)
  | .busy => .incomplete (.busy prepared.1 published.1 running)
  | .ready value => .done (.ok value) running
  | .evaluate original => finish published.1 (body published.1 original running)

/-- Bounds limit new body evaluation. Existing completed hits require no body bound. -/
noncomputable def run [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (g e p h c n : Nat) : Nat → SourceEqualityPrecheck.Constraint → Value Symbol Guard → State width → Result width (Value Symbol Guard)
  | 0, inherited, value, before => request (fun handle original running =>
      .incomplete (.exhausted original handle running)) ⟨inherited, value⟩ before
  | fuel + 1, inherited, value, before => request (fun _ => step (run g e p h c n fuel) g e p h c n) ⟨inherited, value⟩ before

/-- A source error does not become a successful cached node. -/
theorem finish_error (handle : Nat) (message : String) (after : State width) :
