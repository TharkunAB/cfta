theorem edge_call
    (formulas : SourceGuards.Formulas FullSyntax.Formula) (solver : SourceGuards.Entailment FullSyntax.Formula)
    (inventory : Inventory) (profile : Profile) (globals : Memos)
    {fuel g s r e p h m c n budget : Nat} {request : EdgeRequest}
    {before after : Caller (bits + 2)} {result : Edge}
    (actual : SourceCurrentAllocatedPartialWorker.edgeCall fuel g s r e p h m c n budget request before = .done result after)
    (context : Context formulas solver inventory before globals)
    (frame : Frame formulas solver inventory before.checked) (fits : Fits profile before.checked)
    (inherited : EqReady before.checked.operations.constraints request.inherited)
    (resident : EdgeResident before.checked.native.machine.heap request.value)
    (reserved : SourceCurrentEdgeCallNumeric.Reserved bits budget request before profile)
    (origins : Origins formulas solver before)
    (normal : Normal before.checked.native.machine.heap)
    (supported : NativeSupport before.checked.native.machine.heap before.checked.native)
    (causal : History empty before.checked.native.machine.heap)
    (merged : MergeStored before.merge) (positiveMemo : MergePositive before.merge) :
    Origins formulas solver after ∧ Written (bits := bits) formulas solver request result := by
  rcases started : beginEdge request before with ⟨handle, action, running⟩
  have prior := begin_origins request origins
  rw [started] at prior
  have components := beginEdge_components request before
  rw [started] at components
  dsimp only at components
  obtain ⟨checked, merge, _fourth, _nodes⟩ := components
  have candidateReady : EqReady running.checked.operations.constraints request.inherited := by
    rw [checked]
    exact inherited
  have candidateResident : EdgeResident running.checked.native.machine.heap request.value := by
    rw [checked]
    exact resident
  cases action with
  | busy | absent =>
      simp only [SourceCurrentAllocatedPartialWorker.edgeCall, started] at actual
      cases actual
  | ready value =>
      simp only [SourceCurrentAllocatedPartialWorker.edgeCall, started] at actual
      cases actual
      let published := FlatMemoThunk.lookupOrInsert request.key request before.edgeResults
      have observed := congrArg (fun result => (result.2.1, result.2.2.edgeResults)) started
      change FlatMemoThunk.demand published.1 published.2 = (.ready result, after.edgeResults) at observed
