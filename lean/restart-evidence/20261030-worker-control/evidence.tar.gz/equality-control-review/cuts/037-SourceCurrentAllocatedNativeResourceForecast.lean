def Room (bits : Nat) (profile : Profile) : Prop :=
  profile.nodes < 2 ^ bits ∧ profile.edges ≤ 2 ^ (bits + 2) ∧
    profile.domains + 2 ^ (profile.nodes + profile.nodes * profile.nodes) < 2 ^ (bits + 1)

/-- Entry room for a larger profile gives entry room for a smaller profile. -/
theorem Room.mono {bits : Nat} {first last : Profile} (room : Room bits last)
    (below : Le first last) : Room bits first := by
  have exponent := Nat.add_le_add below.1 (Nat.mul_le_mul below.1 below.1)
