private def candidates (rank : Nat × Nat) (seed : Seed) : List (Nat × Nat) :=
  ((List.range (rank.1 + 1)).flatMap fun a =>
    (List.range (seed.2.mass + 1)).map fun b => (a,b)).filter
      (fun child => decide (child.1 < rank.1 ∨ (child.1 = rank.1 ∧ child.2 < rank.2)))

private theorem candidates_lt (rank : Nat × Nat) (seed : Seed) (child : Nat × Nat)
    (member : child ∈ candidates rank seed) : Prod.Lex Nat.lt Nat.lt child rank := by
  simp only [candidates, List.mem_filter, decide_eq_true_eq] at member
  exact Prod.lex_def.mpr member.2

private def images (rank : Nat × Nat)
    (recurse : ∀ child, Prod.Lex Nat.lt Nat.lt child rank → Seed → Out)
    (seed : Seed) : List Out :=
  (candidates rank seed).attach.map fun child =>
    recurse child.val (candidates_lt rank seed child.val child.property) seed

private def joinSeed (seed : Seed) (outputs : List Out) : Seed :=
  (seed.1 ++ outputs.flatMap (fun output => output.2.2.1),
    cover (outputs.map fun output => output.2.2.2) seed.2)

private def slot (all : Seed → List Out) (acc : Out) (_index : Nat) : Out :=
  let outputs := all acc.2.2
  (acc.1 + 1 + maximum (outputs.map fun output => output.1),
    max acc.2.1 (maximum (outputs.map fun output => output.2.1)),
    joinSeed acc.2.2 outputs)
