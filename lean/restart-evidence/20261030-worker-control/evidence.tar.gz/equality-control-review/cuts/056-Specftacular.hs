        (more, s'') <- considerAll limit lvl tc next (if parallelBuckets then s' else s'{pending_laws = []})
        return (laws ++ more, s'')

-- 2. The candidate terms.

-- | The reduced automaton of the terms of a size and a type, with merged type alternatives (see 'mergeTypeAlternatives').
searchSpace :: StEcta -> Int -> TypeSkeleton -> Node Symbol
searchSpace StEcta{..} lvl tc =
    let !ecta = filterType (union $ tk any_arg lvl) $ typeToFta tc
     in mergeTypeAlternatives (fixWithin 100 (withoutRedundantEdges . reducePartially) ecta)

{- | 'Compile.preparePruning', and then 'mergeTypeAlternatives' again,
because its reduction can make overlapping type alternatives.
-}
preparePruning :: [Template Symbol] -> Node Symbol -> (Node Symbol, [Template Symbol])
preparePruning templates = let prepare = Compile.preparePruning templates in Bi.first mergeTypeAlternatives . prepare

-- | 'searchSpace' in disjoint parts, one for each shape of the left spine (see 'spineParts').
searchSpaceParts :: Int -> StEcta -> Int -> TypeSkeleton -> [Node Symbol]
searchSpaceParts splitDepth StEcta{..} lvl tc =
    [ mergeTypeAlternatives (fixWithin 100 (withoutRedundantEdges . reducePartially) (filterType part (typeToFta tc)))
    | part <- spineParts splitDepth any_arg lvl
    ]

