def live [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (unconstrained : Value Symbol Guard → Bool) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (clear : Guard → Bool) (top : Guard)
    (g e p h c n : Nat) (records : List SourceEqualityClassOrder.Record) (values : List (Value Symbol Guard)) (before : NativeState width Symbol Guard) :
    Result width Symbol Guard :=
  match SourceEqualityRecordSelectionWorker.queries unconstrained g values records before.machine.heap with
  | .pending key heap => .selection (.pending key heap) (advanceHeap before heap)
  | .done none heap => .selection (.done none heap) (advanceHeap before heap)
  | .done (some queries) middle =>
      match SourceEqualityRequiredExecution.requireAll p h (SourceEqualitySelectedRequired.paths (InternedSourceClassSelection.selected queries)) values middle with
      | .done required heap => finish (SourceEqualityClassFoldWorker.pass emptyGuard conjoin clear top e p h c n
          (SourceEqualitySelectedRecords.keep records queries) required (advanceHeap before heap))
      | .pending key heap => .required (.pending key heap) (advanceHeap before heap)
      | .unresolved name heap => .required (.unresolved name heap) (advanceHeap before heap)
      | .exhausted limit heap => .required (.exhausted limit heap) (advanceHeap before heap)

