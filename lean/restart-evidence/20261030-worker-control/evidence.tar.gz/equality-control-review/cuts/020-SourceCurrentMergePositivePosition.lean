def Support (memo : Memo Symbol Guard) : Prop :=
  ∀ key entry, memo key = some entry → ∀ path, PositiveAt entry.result path → PositiveAt entry.original path

/-- The empty table contains no unsupported result. -/
theorem support_empty : Support (empty : Memo Symbol Guard) := by
  intro key entry found
  cases found

private theorem support_remember {memo : Memo Symbol Guard} (support : Support memo)
    (input output : Node) (law : ∀ path, PositiveAt output path → PositiveAt input path) :
    Support (remember memo input output) := by
  intro key entry found
  rcases remember_cases memo input output key entry found with old | ⟨_, same⟩
  · exact support key entry old
  · subst entry
    exact law

