    edgeSymbol,
    nodeIdentity,
    setChildren,
 )
import Data.CFTA.Symbol (Symbol)
import Data.CFTA.Template (Template (..), exclude)
import Data.Either (fromRight)
import qualified Data.Map.Strict as Map
import qualified Data.Set as Set

{- | Select a graph and the remaining templates for the existing oracle.
Unsupported input or a rejected result keeps the original graph and full list.
A local traversal table shares rebuilt program nodes. The remaining templates
depend on the templates only, so a partial application computes them once for
all its graphs.
-}
preparePruning :: [Template Symbol] -> Node Symbol -> (Node Symbol, [Template Symbol])
preparePruning templates = \root -> fromRight (root, templates) (prepared root)
