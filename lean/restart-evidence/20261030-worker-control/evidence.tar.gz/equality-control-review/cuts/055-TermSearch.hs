constFunc :: Symbol -> Node Symbol -> Edge Symbol
constFunc symbol typ = Edge symbol [typ]

-- | Keep the terms of a node whose type child equals a type node.
filterType :: Node Symbol -> Node Symbol -> Node Symbol
filterType n t =
    Node [mkEdge "filter" [t, n] (equalityConstraint $ mkEqConstraints [[path [0], path [1, 0]]])]

-- | Propagate the constraints and remove the redundant edges until nothing changes.
reduceFully :: Node Symbol -> Node Symbol
reduceFully = fixUnbounded (withoutRedundantEdges . reducePartially)
