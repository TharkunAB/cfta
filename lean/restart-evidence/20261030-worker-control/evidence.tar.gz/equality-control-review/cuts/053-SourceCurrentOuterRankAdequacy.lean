                    childrenFit childrenKnown sourceResident childAvailable childGraph.length
                  let rebuilt := SourceCurrentAllocatedRawRebuild.edge parented childrenResult childEnd.checked
                  let afterEdge := advance childEnd rebuilt.2 childEnd.fourth childEnd.merge
                  simp only [SourceCurrentAllocatedPartialGraph.prefixState,
                    SourceCurrentAllocatedInheritedPrefix.state] at childDone
                  have descDone : descendants rowFuel g s r e p h m c n budget inherited parented afterParent =
                      .done rebuilt.1 afterEdge := by
                    simp only [descendants,combinedAt,childDone,Outcome.bind,rebuilt,afterEdge]
                  have nextFits : Fits (rowSeed (j+1)).2 afterEdge.checked := by
                    simpa only [afterEdge,rebuilt,rowSeed,fold_succ,rowStep,row,prior,fullSlots,slotSeed,slots,parentSeed,
                      SourceCurrentAllocatedPartialState.advance,SourceCurrentOuterInitialSchedule.rebuild] using builtFits
                  have nextKnown : SourceEqualityAnnotationHeap.Heap (fun guard => guard ∈ (rowSeed (j+1)).1)
                      afterEdge.checked.native.machine.heap := by
                    simpa only [afterEdge,rebuilt,rowSeed,fold_succ,rowStep,row,prior,fullSlots,slotSeed,slots,parentSeed,
                      SourceCurrentAllocatedPartialState.advance,SourceCurrentOuterInitialSchedule.rebuild] using builtKnown
                  obtain ⟨restResults,finish,tailDone⟩ := tailRows rowFuel (j+1) afterEdge (by omega)
                    (by simp only [List.length_cons] at bound; omega)
                    (inside.snoc (.rows_tail parentDone descDone)) nextFits nextKnown
                  exact ⟨rebuilt.1::restResults,finish,by simp only [rows,parentDone,descDone,tailDone,Outcome.bind]⟩
            have rowInside : Reached g s r e p h m c n budget
                (.body (bodyFuel+1) ⟨inherited,.node entry originals depth free⟩ running)
                (.rows bodyFuel inherited originals running) := (Reached.refl _).snoc (.body_rows rfl)
            obtain ⟨results,rowEnd,rowsDone⟩ := rowsProgress bodyFuel 0 originals running (by omega)
              (by simpa only [Nat.zero_add] using rowLength) rowInside runningFits runningKnown
            let rebuilt := SourceCurrentAllocatedRawRebuild.modify (.node entry originals depth free) originals results rowEnd.checked
            exact ⟨rebuilt.1,advance rowEnd rebuilt.2 rowEnd.fourth rowEnd.merge,by simp only [nodeBody,rowsDone,Outcome.bind,rebuilt]⟩
      obtain ⟨result,after,bodyDone⟩ := bodyProgress
      exact ⟨result,finishNode handle result after,by simp only [nodeCall,started,bodyDone,Outcome.bind]⟩
  obtain ⟨result,after,done⟩ := progress
    (rankCount (request.inherited.payload.getD []) request.value,massOf request.value)
    output.1 request before seed rfl (Reached.refl first) fits known outputRoom (Nat.le_refl _)
  refine ⟨result,after,?_⟩
  intro fuel enough
  exact SourceCurrentAllocatedPartialWorkerStability.nodeCall_done_stable done enough
    (Nat.le_refl _) (Nat.le_refl _) (Nat.le_refl _) (Nat.le_refl _) (Nat.le_refl _)
    (Nat.le_refl _) (Nat.le_refl _) (Nat.le_refl _) (Nat.le_refl _)

end MicroCFTA.SourceCurrentOuterRankAdequacy
