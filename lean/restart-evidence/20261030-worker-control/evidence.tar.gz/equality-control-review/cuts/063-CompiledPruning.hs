compileTemplates :: [Template Symbol] -> Node Symbol -> Either String (Node Symbol)
compileTemplates templates root
    | null templates = Left "SKIP no eligible templates"
    | not (all eligible templates) = Left "SKIP template needs annotation matching"
    | otherwise = do
        (source, originalOpaque) <- graph True (256, 4096) root
        let result = fst (State.evalState (build source root) Map.empty)
        (finished, finalOpaque) <- graph True (4096, 65536) result
        if not (finalOpaque `Set.isSubsetOf` originalOpaque)
            then Left "UNKNOWN an opaque node changed"
            else
                if Map.size finished > 4096
                    then Left "UNKNOWN output graph cap"
                    else Right result
  where
    -- A fixed ordered subset shares one template catalog across all nodes.
    sizedTemplates = [(minimumLeaves template, template) | template <- templates]
    exclusions =
        Map.fromList
            [ (bound, exclude [template | (needed, template) <- sizedTemplates, needed <= bound])
