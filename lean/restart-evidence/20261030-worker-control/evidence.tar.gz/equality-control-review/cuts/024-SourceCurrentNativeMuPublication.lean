noncomputable def closed_history [DecidableEq (EdgeKey Symbol Guard)] (expression : Syntax Symbol Guard) :
    History empty (build expression [] empty).state :=
  Classical.choice (build_history expression [] empty SourceCurrentConstrainedCapSourceHistory.empty_context)

