# Scope and tooling incidents

No compiler, proof evaluator, native runtime, Git, network, board, or subagent command ran in this child task. No production file was edited. There is no new Lean draft.

1. Several locator searches produced more output than the display limit. The cycle dependency locator was retained in full as `discovery-cycle-dependencies.txt`. Other truncated locators were used only to find later bounded cuts. A locator display is not full proof coverage.
2. Guessed source names `SourceEqualityClassFold.lean`, `SourceCurrentClassScan.lean`, `SourceEqualityPartialEdgeWorker.lean`, `SourceEqualityPartialRows.lean`, `SourcePruningEnumerationGraph.lean`, and `SourcePruningEnumerationPhysicalArity.lean` did not exist. Search commands reported missing files. No claim depends on a missing file. One metadata script stopped after the absent EnumerationGraph file and did not write its intended summary.
3. A locator used the wrong generator path `cfta/src/Data/CFTA/Gen/Internal/Table.hs`. The generator is a separate `cfta-generator` subtree. No Table source was acquired. This task did not review the sized/count API.
4. An initial search in `cfta` found no `recordTypes`. The actual Haskell callback is in `specftacular/src/Specftacular/Pruning.hs`. Its current source cut and the corresponding Lean definition are retained.
5. There are exactly two EOF clamps: OuterPrefixNativeStores requested160–199, actual160–198; TermSearch requested45–62, actual45–55. The acquisition registry records requested and actual endpoints.
6. The final source-copy verification rechecks full-source identity and every retained slice. It does not run a compiler or evaluate any theorem or Haskell function. No pass receipt is manufactured from source inspection. Root performs independent compiler checks.
