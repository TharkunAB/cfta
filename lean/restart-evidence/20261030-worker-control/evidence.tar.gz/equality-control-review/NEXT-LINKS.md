# Next proof links

No new Lean proof is proposed in this bundle. Existing capacity and semantic producers already supply cold equality completion.

## One compiled equality pass

The source call is `CompiledPruning.preparePruning` → `compileTemplates selected root` → one `reducePartially compiled` → graph inspection → returned graph and residual templates. The Haskell default returns the original pair when preparation fails. The useful bridge must establish the initializer's original allocation History, guard coverage, closed constructed source representation, and graph invariants for the actual compiled root. It must then identify the returned formal current worker with the source operation. The captured arity theorem can transport arity after an actual completed worker receipt. Cold completion does not by itself instantiate that source/encoding/cache bridge.

## Composite finite callers

`Specftacular.searchSpace` runs at most100 rounds. `Gen.Synthesis.reduceFully` runs at most30 rounds. Each round includes `withoutRedundantEdges` after equality reduction. A useful companion must preserve the warm-entry assumptions across that actual intervening operation. Equality-only `ColdFiniteWarmCalls` is not already that companion.

## Actual callback control

The `recordTypes` source callback invokes the pruning oracle, not the equality reducer. Its actual fragment branch can enter `observe`; the native/prepared enumeration controller must complete that actual branch and every earlier alternative. A future-success predicate assumed as a premise does not supply this control theorem. Existing path preservation after an actual Success remains a separate preservation fact.

## Unbounded identity fixpoint

`TermSearch.reduceFully = fixUnbounded (withoutRedundantEdges . reducePartially)` needs a finite stabilization result for that composite and node identity. Fixed finite-round completion and semantic language equivalence do not imply identity stabilization. No counterexample or current runtime defect was established here.
