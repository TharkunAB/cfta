# Equality control review

[2026-10-30 04:21 CET]

## Result and correction

The current formal equality reducer already has a cold completion theorem. It also has a semantic theorem for the same completed execution. The missing equality control suppliers are not the four store predicates that first appeared in `ActualChildRank.dispatch`.

`SourceCurrentColdRankCapacity.constructed_initial_node_call` proves completion of the actual `SourceCurrentAllocatedPartialWorker.nodeCall` for a graph built from closed finite syntax, after a valid original equality-cache allocation history covers its guards. It chooses finite room and fuel from the input. Every larger outer fuel returns the same result and state. The theorem assumes no future worker completion or successful future callback.

`SourceCurrentColdRankSemantic.constructed_initial_node_call` adds result availability and exact language equivalence for every ambient interpretation and term. These are claims about the formal core with its supplied guard services. This review does not establish source correspondence for Haskell or complete public enumeration.

Any earlier handoff that described completion of this cold equality entry as still open must be corrected. The old caller-cycle modules remain valid statements about their named older workers. They are not evidence that the current worker or Haskell still has that cycle.

## Exact entry and assumptions

The complete 139-line capacity source is retained. Its SHA256 is `ad020024e9f5afe21ea188229fbc3c2e0801c94998c1a792fe2364f4006b7b4b`. Its line11 explicitly opens `SourceCurrentAllocatedPartialWorker (nodeCall)`. The target is not a renamed abstract callback.

The public input gates are:

- Formal `formulas` and `solver`, with the source instance context for Symbol, EdgeKey, and Node equality.
- `SourceEqualityOriginalAllocationHistory.History initial finalCache originals` and `Cache.Valid initial`.
- A finite `InternedNestedConstruction.Syntax` expression. The builder uses an empty external environment and empty physical heap.
- Every guard from `SourceEqualityConstraintOrigins.guards expression` occurs in `originals`.
- An arbitrary natural `budget`.

The conclusion chooses `value` and `heap` with the literal completed construction equation. Its inherited request is `emptyValue finalCache`. The inherited request is not arbitrary in this cold theorem.

The theorem computes a seed from the original guard list, physical node and edge counters, zero domains, and `InternedValueMassHeap.initialBound heap`. It computes the positive quotient count and value mass of the initial request. The noncomputable rank envelope returns work, lower fuel, and an output seed. `roomBits` is chosen for the joined output and outer schedule profile. The initializer uses width `bits + 2`. `phaseNeed` supplies all nine lower worker fuel arguments.

Its final quantifier is exact:

```lean
∃ (result : Node) (after : Caller (bits + 2)), ∀ fuel, output.1 ≤ fuel →
  nodeCall fuel need need need need need need need need need budget request before = .done result after
```

This is a completion statement. It is stronger than totality of the fuel-indexed Lean definition. It rules out returned faults and exhaustion at the supplied bounds. It also states stability of the complete returned state as outer fuel increases. It does not give a measured practical bound or prove correctness of machine integer encodings.

The full exact headers are in `PUBLIC-CONTRACTS.json`. Body coverage for dependencies is bounded and recorded. The entire 517-line adequacy proof was not independently reread here.

## Why the four suppliers are available

The complete capacity proof constructs the following facts before calling `OuterRankAdequacy.initial_node_call`:

| Fact | Actual producer in this proof |
| --- | --- |
| Initial Context and empty inherited allocation | `AllocatedPartialInitialization.constructed`, using original History and covered syntax |
| Query-resource Frame | `ConstructedOuterInitial.frame` |
| Fits and source guard carrier | Closed construction facts, initial mass bound, and `AnnotationConstruction.closed` |
| Entry Inputs | The constructed inherited Ready proof and source value availability |
| Numeric Room | `ParentInitialRoom.room_computed` for the computed joined profile |
| UnionNormal | `RequiredUnionNormal.source expression` |
| Native positive-position Support | The literal pair of `FlatMemoThunk.empty_valid` proofs for initial empty tables |
| Causal Mu History | `NativeMuPublication.closed_history expression` |
| Stored merge law | `ConstrainedCapMemoMerge.stored_empty` |
| Merge positive-position Support | `MergePositivePosition.support_empty` |
| Edge-result writer Origins | `ResourceParentWriters.initial` |
| Stored closed node requests | `OuterClosedInputs.initial` |
| Initial closed request | The constructed input has empty free variables |
| Initial idle node and edge tables | Empty node cells and `OuterEdgeIdle.initial` |
| All nine lower fuel bounds | Reflexivity after choosing `need` |

There is no missing cold producer for native Support, causal History, merge Support, or Origins in this entry. The proof does not borrow these facts from a completed future worker.

The four predicates have concrete meanings. Native Support is a conditional same-position law on every returned captured node and edge request. Causal History retains actual source Mu publications. Merge Support maps every positive position of a memoized result back to its original node. Origins is valid captured edge-result storage with an existential actual successful ParentWorker writer and its admitted resources. Origins is vacuous for an empty edge table.

`OuterPrefixNativeStores.reached` retains native Support, causal History, merge storage, merge Support, and UnionNormal along the actual `Reached` relation. `OuterResourceWriters.reached` retains Origins along the same relation. Both use the initial Context, Frame, Fits, known guards, Inputs, and Room. Those are supplied in the cold capacity proof, not left as open global hypotheses there.

## Actual recursive equations

The Haskell entry is exactly:

```haskell
reducePartially = reducePartially' EmptyConstraints
reducePartially' constraints node =
    memo2TypeableWith @symbol genericReducePartiallyCache go constraints node
```

For an ordinary node, `go` maps `reduceChildren inherited . reduceEdgeIntersection inherited` over its original edges. The parent operation reads the edge's own equalities and inherited equalities. The descendant operation uses the returned edge and computes:

```haskell
inheritedEcs `combineEqConstraints` equalities (edgeConstraint e)
```

It then dispatches child index `i` with `eqConstraintsDescend combined i`. Contradiction erases the children. A successful returned edge keeps its original constraint field. Thus normalized inherited values can feed another ordinary descendant request. This route is real. It does not imply that every algebraic normalize/descend recurrence is an admitted runtime path.

The current formal worker has the same explicit control order:

1. `nodeCall` demands its captured memo entry. Ready returns the stored result. Evaluate calls `nodeBody` on the stored original request. Busy and absent return faults.
2. Ordinary `nodeBody` runs `rows`, then raw-rebuilds the original node after all rows return.
3. Each original row runs `edgeCall`, then `descendants` on the returned parent edge, then the remaining original rows.
4. `descendants` calls `AllocatedInheritedPrefix.run` once. Its actual operation state becomes the child state. Missing inherited and error are distinct faults.
5. Contradiction erases children. A live combined value enters `walk`.
6. `walk` descends at the actual index and current operation state, invokes `nodeCall` on that exact child request, and continues at the next index.

`CurrentAllocatedPartialWorker`62–105 and111–172 contain these equations. The report does not replace their sequential operation states with one fixed pre-state.

## Mu, union, and exposure

Haskell `go _ (Mu n) = Mu n` and `go _ n@(InternedUnion _) = n` terminate this outer recursive branch. They do not invoke the reducer on the Mu body with inherited constraints.

Current formal `nodeBody` returns a union directly. Its Mu branch invokes `SourceEqualityMuReconstruction.rebuild` with the original entry, body, and cached probes. It supplies no inherited constraint argument. Rebuild uses matched substitution and the smart binder protocol. `nodeBody` returns its result without launching another `nodeCall` on it. The result need not be described as an unchanged Mu constructor in every smart reconstruction case.

These branches cut a direct inherited feedback traversal through the original Mu or union. They do not alone prove termination of the ordinary caller. Parent `requireAll` and `editAll` can expose Mu or union nodes before a later outer child request reaches these branches. The actual current rank proof covers ordinary child dispatch after those parent effects.

The primary current class gate is `MuEndpoint.classMeets true source reaches`. Its ordinary empty-path case tests free variables and `reachesConstrainedMu`. Its secondary form uses `belowEnd = false`. A class refused by the primary gate can enter only the separate endpoint emptiness route when the secondary test allows it. A retained class goes through required-path preparation and the class fold. The source does not justify removing these distinctions.

## Decreasing quantity and old witnesses

`ActualChildRank.dispatch` supplies the actual child transition and a strict `Prod.Lex Nat.lt Nat.lt` decrease in:

```lean
(PositiveQuotientCount.count (inherited.payload.getD []) value,
 InternedValueMass.value value)
```

The first component counts positive natural child positions modulo the inherited equality relation. The second is ordinary value mass. The full rank contract includes the actual parent success, actual combined inherited result, completed earlier child prefix, and selected child. It does not assume completion of the selected child.

`OuterRankEnvelope` defines finite candidate ranks from the current count and current seed mass bound. Its `WellFounded.fix` uses the lexicographic natural relation. The row recipe threads parent forecasts, child slots, and rebuild forecasts. Thus the proof does not rely on the inherited payload having a fixed finite algebraic carrier. The finite envelope and the initial room choice discharge the capacity requirement for this one admitted call.

Plain cached height does not suffice. The current `OuterParentHeightGrowth.supported_parent_growth` theorem has a closed built input, current primary gate returning false, and actual ParentWorker success, but edge height increases2→3 and a returned child has the same height3 as its parent input. `OuterHeightBarrier.supported_required_growth` admits a closed unconstrained Required input with height0→1. These are precise existing formal obstructions to a proposed simple height proof. They are not evidence that current completion is false.

The two old whole sources have a narrower meaning:

- `OuterCallerWorkerCycle.actual_cycle` computes two exact invocations of `SourceEqualityPartialWorker.run` on a constructed fixture. It returns an exhausted descendant callback, a repeated root reference, a distinct ordinary wrapper, and inherited `some []` on both requests. It does not exhibit a growing inherited payload or a completed successful recursive caller.
- `OuterMemoWorkerCycle.actual_pending` computes the old `SourceEqualityPartialMemoWorker.run` with empty initial memo tables. It returns a busy root key with two active cells and empty inherited payloads. This is an actual older model result, not merely an abstract thunk diagram.

Both use the old guarded/selection route. Current allocation-aware local reduction uses the primary/secondary endpoint scan. The Haskell source explicitly documents the endpoint-above-constrained-Mu rule that blocks the historical ancestor case. This review did not evaluate the old fixture under the current worker and makes no new current-Haskell bug claim.

## Exact public caller scopes

| Production caller | Exact behavior | Formal coverage established here |
| --- | --- | --- |
| `CompiledPruning.preparePruning` | `compileTemplates selected root`, one explicit `reducePartially compiled`, bounded graph inspection, then `(reduced,residual)`; failure returns original root/templates | The corresponding one-pass current equality entry has completion and semantics. Admission/source correspondence for this compiled root remains a separate adapter obligation. |
| `Specftacular.searchSpace` and `searchSpaceParts` | `fixWithin 100 (withoutRedundantEdges . reducePartially)` | Finite source loop. The composite includes an intervening edge-pruning step. Equality-only warm repetition does not automatically cover it. |
| `Gen.Synthesis.reduceFully` | `last . reductions`; at most30 composite rounds | Finite source loop. This name does not denote the unbounded TermSearch function. |
| `TermSearch.reduceFully` | `fixUnbounded (withoutRedundantEdges . reducePartially)` | Unbounded identity-fixpoint convergence is not proved by the fixed-round theorem. |
| `Gen.Internal.Join` | A single explicit equality pass on one join; a separate recursive-family route skips it when nested Mu is present | Source call scope only; no generator API correspondence was established. |
| `Equality.termsMatching` | Identity for Hole/empty AnyPrefix; otherwise `reducePartially . restrict template` | One pass after restriction, with a separate source admission obligation. |

`fixWithin` decreases its rounds counter. `fixUnbounded` repeats while `f x /= x` and has no counter. This distinction is present in `Interned.Operations`775–788.

`ColdFiniteWarmCalls.constructed_node_calls` proves any fixed finite number of equality-only warm requests on successive returned values. It chooses width and fuel using that finite round count. It preserves language through the final result. It neither proves an unbounded identity fixpoint nor covers an arbitrary interleaving of external callers or edge-pruning operations in a shared Haskell memo cache.

## Actual enumeration and callback boundary

Haskell `Specftacular.Pruning.recordTypes`107–112 updates type positions, calls the template oracle when templates are present, and returns updated metadata. `SourcePruningRecordTypes.recordTypes`45–56 has the corresponding operation. Its oracle handles an actual fragment by early rejection, idle success, or `observe`. It does not invoke the equality `nodeCall`.

Therefore equality completion is not the missing recursive oracle/DFS callback completion theorem. It can support preprocessing and equality service admission, but does not alone prove that every native/prepared enumeration callback, all earlier alternatives, and all staged children complete.

The existing `SourcePruningEnumerationPartialWorkerArity.nodeCall_verified` is a real conditional connection. It takes the current worker's success, Context, inherited readiness, input availability, ranges, and physical arity heap. It derives a captured receipt, read trace, checks, postconditions, language law, result availability, and output arity heap. It does not itself create success or establish the public compiled root's initial admission. Its exact header is retained.

The smallest useful next proof should connect the public compiled preparation result to the existing equality initializer and then transport its returned state into the enumeration view. It must establish the actual compiled-root/source representation and original cache history, preserve arity and other needed graph invariants, and account for the actual Haskell cache protocol. The existing totality theorem can then be used directly. A second useful target is actual oracle/enumeration control from admitted initial inputs. That target must produce future successes from the actual control transitions, not assume a law saying that every future callback succeeds.

For the separate unbounded TermSearch API, the missing statement is existence of a finite round at which the composite reducer returns the same node identity. Language equivalence at every finite round does not prove that statement.

## Guard and payload boundaries

Original native own-guard alphabet closure and physical inherited equality storage remain distinct. The retained inherited-writers review maps actual combine/normalize/descend storage writes. The raw binary and alternate payload recurrences were algebraic source targets, not admitted public runs or defects.

Cold equality completion now supplies finite control for one admitted formal pass, despite possible intermediate inherited growth. It does not establish one fixed carrier for every unconstrained algebraic cache writer sequence. It also does not supply a uniform bound for unbounded outer iteration or for every future enumeration invocation.

The field-pool/SCS admission route from the earlier public fixture is a separate issue. That fixture's default ordinary route did not install its fork SCS into Loop. Its observed callback behavior cannot be used as equality-worker admission evidence. This task did not rerun that fixture or inspect sized/count APIs.

## Evidence and verification limits

The original two whole-source allowances were used on the two requested old witness modules. Root explicitly authorized a third named complete source, ColdRankCapacity, after its completion contract was found. There are no further whole sources. Exact scopes, overlaps, and current full-source SHA256 values are in `acquisitions.json`, `reused-scopes.json`, and `coverage-unions.json`. Current Git blob SHA1 values were computed from bytes only; this child made no Git-ref claim for them.

There are64 fresh acquisition records and18 exact frozen-scope reuses across55 unique sources. Reused bytes came from the immutable inherited-writers bundle. Every retained copy matched the current full-source identity and exact line slice at verification. Two requested ranges were clamped at EOF and are recorded honestly.

This was a source-only review. No compiler, evaluator, native runtime, Git, network, board, repository mutation, or subagent was used. No Lean draft was added. Root owns compilation and current audit receipts. No source defect or Haskell fix was established by this review. `INCIDENTS.md` records missing locator guesses and truncated locator displays.
