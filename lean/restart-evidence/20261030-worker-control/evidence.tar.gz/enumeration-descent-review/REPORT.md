# Enumeration descent and caller review

Measured review time: 2026-10-30 04:29 CET. Root reports baseline `efc339921` and unchanged main `bd5a406`. The owner does not run Git.

## Result

Enumeration does not combine-normalize incoming suspended constraints with an edge's own constraints. Its SCS operations allocate a supplied trie, descend a trie, append buckets, or discard a bucket. They do not feed a descended SCS trie back into an own guard.

The useful fixed target is the suffix carrier of the **closed original guard alphabet**, together with the initial stored SCS paths. Suffixes of raw original literal paths alone are too small for a structural proof: native intersection conjoins guards, and normalization can add paths. The original closed alphabet already accounts for those conjunctions. A separate proof is still required to retain that same alphabet through every actual caller transition.

This review adds one useful native bridge. The exact source-only draft passes Root's strict direct check. The production copy passes its build and strict check. The theorem preserves a closed guard alphabet through every bounded native interpreter outcome. It does not require a completed query, accepting model, physical completion trace, or future-worker result. Its physical input and initial field premises remain explicit.

## Exact SCS data flow

The Haskell SCS is `SuspendedConstraint PathTrie UVar`. The formal SCS is `EqualityTrie.Suspended Nat`. An unenumerated value stores an optional native node and a bucket of these constraints.

| Operation | Actual effect on SCS |
| --- | --- |
| Initial state and fresh node/equality variable allocation | Install an empty bucket. |
| `pecToSuspendedConstraint` / formal `suspend` | Keep the supplied own-class trie unchanged and allocate a pure target variable. |
| `descendScs` | Select the trie child at the requested index. Keep the target variable. Terminal or absent branches add no child obligation. |
| `intersectUVarValue` / formal `intersectValues` | Append the two buckets. The optional native nodes can intersect, but this does not merge the SCS tries. |
| `assimilateUvarVal` / actual formal dispatcher | Write sourceScs followed by targetScs into the target. Eliminate the source. Representative and ancestry changes do not change trie contents. |
| `mergeNodeIntoUVarVal` / actual `IncomingNode.finish` | Append incomingScs to the stored oldScs. The native intersection and emptiness query are separate operations. |
| Terminal equality endpoints | Merge target variables, then retain descendant constraints through the incoming write. |
| Ordinary child deferral | Store the supplied bucket unchanged through `setUVarValue` and the waiting-count write. |
| Mu/union child with no terminal endpoint | Ordinary preparation allocates an empty bucket and drops descendant SCS. The shallow helper falls back to the same Mu path. |
| Completed expansion | Replace the pending value with an expanded fragment. Its pending bucket disappears. |
| Repeated recursive key | Clear that slot's bucket before restart. |
| Waiting-count maintenance | Update counts at target representatives. It does not create a trie. |
| Residual obligation | Append a `(guard, fragment)` pair to a different state field. It does not become an SCS trie. |
| Actual successful `recordTypes` | Preserve `values` exactly, for either Bool result. Metadata changes do not create stored SCS. |

The Haskell edge equation is:

```
inherited = descendScs emptyMap scs
newScs   = mapM pecToSuspendedConstraint edge.equalities
children = descendScs inherited newScs
```

The formal raw edge equation uses `descendScs index (scs ++ added)`. Actual cached preparation proves the corresponding two descended buckets have their common path predicate, then appends them. Neither equation calls equality normalization on the union of inherited and own classes.

`intersectEdgeSameSymbol` in Haskell instead builds the native edge with recursively intersected child nodes and `conjoinConstraints` on its two **own guards**. This is the boundary at which the original guard alphabet must be closed. It is distinct from SCS descent.

The Mu/Node correction remains explicit. `InternedNode` and `InternedMu` are different constructors. The `Node` view matches only `InternedNode`. Changing only from the ordinary entry to `termsPruneUntil` does not cause a Mu child to retain nonterminal SCS. The prior shared-child fixture supplied terminal alias endpoints to use the actual retaining branch. It entered Loop work but still reached G fourth. That frozen runtime result is not a starvation counterexample.

The recursion key records the native node and sorted distinct lists of represented trie paths. It omits target-variable identities. Bucket append can increase multiplicity and waiting counts without changing the set of trie signatures. A finite path carrier alone is therefore not a strict step measure.

## Fixed original invariant

Keep `literals` and `initialCore` fixed. Let `A = originalAlphabet literals` and `C = ForecastPathDomain.carrier A initialCore`. The existing carrier is a finite list of suffixes of initial stored paths and all projected paths of guards in A. Existing `initial_paths`, `projected_paths`, and `tail_closed` derive its three basic properties.

The intended caller invariant is:

```
AnnotationHeap.Heap (fun guard => guard ∈ A) caller.checked.native.machine.heap
StatePaths (fun path => path ∈ C) core
```

Initial causal guard origins and normalized literals supply the first line. The original enumeration state supplies the second line. A native request must retain the first line. Actual resident own-row projection then supplies new tries in C. The existing path transport laws preserve the second line through writes, descent, rejection, and successful recording.

`NativeGuardPathCarrier.native_prefix_projected_paths` already gives the same original finite carrier after an actual physical native trace, with its Good, allocated, original guard-origin, and control-field premises. `HeadAdmission.prepare_paths_of_forecast` supplies actual row and child-bucket preservation once the original guard inclusion and current StatePaths facts are established. The other owner is deriving the fixed-original seed gate through the real resource producers. This review does not add a wrapper that recomputes a carrier from the current seed or current state.

An exact subtrie-origin invariant is a possible stronger route if raw signature shape becomes an issue: each SCS trie is an original projected trie or initial stored trie followed by child lookups. Appending or relinking a bucket does not alter an individual trie. This would avoid inferring structural trie finiteness from path membership alone. No new theorem for this alternative is asserted here.

## Actual native requests and failure state

`IncomingNode.run` calls `NativeDemand.execute nativeFuel` on `requestNode emptyDomain incoming old`. `Dispatch.dispatch` uses the same interpreter on `requestNode emptyDomain left right`. Each done query can then invoke `EnabledEmpty.check`. Each failed native request still advances Caller with `other.state`. A failed enabled check also retains its reached checked state. Thus accepted-output-only provenance does not suffice.

The exact native interpreter is `SourceEqualityNativeDemand.execute`. Fuel zero returns `.yielded control state`. Positive fuel executes one `step`, recurses only on `.yielded`, and otherwise returns `.done`, `.failed`, `.constraintError`, or `.blocked` with that outcome's state. `resume` also resumes only `.yielded`.

There are raw heap paths as well:

- `SelectedStep.runPrefix` runs `Action.prepare → OuterNarrow.narrow → NativeView.narrowAt`. Mu is retained unchanged. The ordinary path uses `MergedFreshOrdinaryExposure.nodeEdges`, filters existing rows, then calls `makeNode`. Caller advances from the reached heap even if preparation fails.
- `EnabledEmpty.check` calls `AllocatedConjunctionWorker.call`, then `ConjunctionWorker.call/decision/explore`, then `RowsWorker.rows/tuple/classes/projections`, then `EqualityProjectionWorker.forest/project/union`.
- `RowsWorker.tuple` reads normalized inherited payload classes to choose projection jobs. The projection worker follows existing row children and makes unions. It does not write an SCS trie into an own guard. Raw exposure and projection still need their own all-outcome annotation-heap preservation link.

Existing `AnnotationHeap.makeNode` and `makeUnion` are SafeWork for any guard predicate. Current heap membership, link/residency facts, and captured field facts must justify the rows these raw workers expose. This remains separate from the new bounded NativeDemand theorem.

## Checked bounded native bridge

`SourceCurrentNativeClosedGuardExecute-UNTESTED.lean` is the immutable 57-line owner draft, 3327 bytes, SHA256 `e5f15780e39017741da0b0ab4d1bd52cea7786e57ea31cf11e5635d9cf70cd15`. The owner does not compile it. Root strictly checks those exact bytes with an empty log.

The theorem is `SourceCurrentNativeClosedGuardAlphabet.execute_guard_heap`. Its complete inputs are a closed alphabet, finite fuel, actual control/state, Good, `InputsThrough`, allocated Fields, initial heap membership, and initial guard Fields. Its conclusion is heap membership in the same alphabet at the state of **every** returned outcome.

The proof is one fuel induction. It uses `NativeGuardStep.step_heap` for the one-step heap. On yielded work, `PhysicalCompletion.step_invariants` supplies current Good and allocated fields. `NativeGuardStep.yielded_fields` gives fields in one alphabet extension; `step_subset` and `fields_mono` return them to the same closed alphabet. The induction continues. The other four outcomes use the one-step heap fact directly.

`PhysicalCompletion.execute_invariants` already preserves Good, machine Extension, RequiredCache.Keeps, operation-cache Grows, and OutcomeFields for arbitrary outcomes under its physical inputs. OutcomeFields retains the operation-field heap for every outcome and allocated continuation fields only for yielded work. This review does not assert blocked-continuation fields.

The new theorem does not use `code_complete`. That existing completion theorem requires Safe, Operands, Below, Active, ranges, source growth, and other successful-query premises. Those premises would be inappropriate replacements for an all-outcome guard invariant.

Root's production source is 3338 bytes, SHA256 `e75abd1942bc658d851c297d90e06de2651c7cc6076ddcb5649fb0cd81a8a846`. The complete namespace text, including the theorem header and proof, is byte-identical to the owner draft. Only the module documentation differs. Production matches the strict snapshot exactly. Root's build passes 1150 jobs. Production strict and the exact owner probe both pass with empty logs. The build log replays one existing warning about `InternedFreshOrdinaryClosedCompletion.inputs`; it is not a warning from the new leaf. All matching inputs, reports, and full logs are retained under `root-native-execute-evidence/`.

## Remaining gates and scope

The new bridge does not derive the caller premises from arbitrary original input. Each actual request still needs `InputsThrough`, allocated fields, and original-alphabet guard Fields. `InputsThrough` follows the actual step recurrence and includes only reached continuations, but it remains an explicit physical gate. Raw narrowing, exposure, and enabled-emptiness projection need their corresponding all-outcome heap/field retention. Initial operands and generated query fields must come from the same original literal alphabet, including original supplied templates or domain fields.

After those caller links, an induction through both actual recursive workers can keep the SAME literals and initialCore. It must cover earlier alternatives, rejected rows, missing receipts, and stopped native calls. No accepting-model hypothesis is needed for the intended guard/SCS support invariant. This review does not claim that complete induction, a bound on neutral work, full termination, public coverage, or Haskell correspondence.

No Haskell source is changed. The known descendant-SCS drop behavior and its conditional preservation fix remain in the prior frozen report for Root's FINDINGS handoff. No new runtime defect is claimed.

The owner writes only this directory. It runs no compiler, evaluator, native probe, Git, network, board, or subagent command. Root provides all compilation evidence. Current source identities and cut identities are rechecked before the seal.

`source-scope.json` records full source sizes/hashes, requested and actual line endpoints, copy sizes/hashes, reuse origins, and scope flags. Two old modules are acquired completely: the 44-line existing NativeGuardPathCarrier, and ClosedGuardAlphabet at 112/112 lines through the union of exact cuts. The last eight-line cut supplies the exact original-entry heap gate. Individual partial and EOF-clamped cuts are not relabeled as whole reads. Other substantial partial unions include PathTransport at 150/240 and RowsWorker at 75/119. No EOF-clamped cut is called whole. Three requested display ranges run past EOF; their actual endpoints are recorded. Truncated displays, locator mistakes, and corrected source interpretations are recorded separately. No broad mutual proof is drafted.
