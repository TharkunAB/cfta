def initial (checked : Checked width) (merge : MergeMemo) (fourth : Fourth) : State width :=
  ⟨checked, merge, fourth, FlatMemoThunk.empty, FlatMemoThunk.empty⟩

/-- Current checked operations retain both caller result tables. -/
def advance (before : State width) (checked : Checked width) (fourth : Fourth) (merge : MergeMemo) : State width :=
  { before with checked := checked, merge := merge, fourth := fourth }

/-- Publish and demand the actual outer request in its own table. -/
