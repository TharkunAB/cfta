
/-- Allocate a slot and inherit the current recursion ancestry. -/
def allocate (node : Option Nat) : EnumerateM Symbol Guard Nat := do
  let state ← get
  let uv := state.counter
  set {state with counter := uv + 1, values := state.values ++ [UVarValue.unenumerated node []]}
  inheritAncestry uv
  pure uv

/-- A new equality class starts with a pure equality variable. -/
def suspend (trie : EqualityTrie.Trie) : EnumerateM Symbol Guard Suspended := do
  pure ⟨trie, ← allocate none⟩

/-- Only two unenumerated slots can be intersected. -/
def intersectValues (graph : Graph Symbol Guard) :
    UVarValue Symbol → UVarValue Symbol → Option (UVarValue Symbol)
  | .unenumerated left ls, .unenumerated right rs =>
      some (.unenumerated (match left, right with
        | none, node => node
        | node, none => node
        | some a, some b => some (graph.intersect a b)) (ls ++ rs))
  | _, _ => none

/-- Structural emptiness rejects an intersection branch. -/
def hasEmptyContents (graph : Graph Symbol Guard) : UVarValue Symbol → Bool
  | .unenumerated (some node) _ => match graph.node node with | .empty => true | _ => false
  | _ => false

/-- Move an old representative's contents into the current representative. -/
def assimilate (graph : Graph Symbol Guard) (target source : Nat) : EnumerateM Symbol Guard Unit := do
  if target = source then pure () else
    let sourceValue ← rawValue source
    match sourceValue with
    | .eliminated => pure ()
    | _ =>
        let targetValue ← rawValue target
        match intersectValues graph sourceValue targetValue with
        | none => failure .invalidIntersection
        | some merged =>
            require (!hasEmptyContents graph merged)
            setValue target merged
            setValue source .eliminated
            modify fun state => {state with recursionAncestry := (fun other =>
              if other = target then
                (state.recursionAncestry source ++ state.recursionAncestry target).eraseDups
              else state.recursionAncestry other)}

/-- Add a reached node and its inherited suspended constraints. -/
def mergeNode (graph : Graph Symbol Guard) (fuel uv node : Nat) (scs : List Suspended) :
    EnumerateM Symbol Guard Unit := do
  let root ← representative fuel uv
  let previous ← rawValue root
  match intersectValues graph (.unenumerated (some node) scs) previous with
  | none => failure .invalidIntersection
  | some merged =>
      setValue root merged
      inheritAncestry root
