theorem code_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (source : InternedConstructorTemplates.State Symbol Guard) (facts : InternedNestedFacts.Facts source)
    (holds : Guard → Language.Term Symbol → Bool) (bound : Nat) (code : Code Symbol Guard A)
    (state : Checked width) (post : Machine Symbol Guard → A → Prop)
    (safe : Safe code state.native.machine post)
    (operands : SourceCurrentAllocatedNativeCodeProgress.Operands code state.native.machine)
    (below : Below source holds bound code state.native.machine) (valid : Good state)
    (fields : CodeFields state.operations code)
    (growth : Grows source state.native.machine.heap) (history : Extends source.nodes.issued state.native.machine.heap.nodes.issued)
    (active : ActiveAbove (view source holds) holds bound state.native) (ranges : WordRanges (.code code) state) :
    Returned (.code code) state post :=
  code_of_bodies source holds bound (all_bodies source facts holds bound) code state post
    safe operands below valid fields growth history active ranges

/-- An actual original node body has a complete physical trace at its independent request bound. -/
theorem node_complete [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
