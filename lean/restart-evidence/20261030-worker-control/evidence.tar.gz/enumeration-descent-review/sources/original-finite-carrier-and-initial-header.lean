noncomputable def projectedPaths (guards : List Constraint) : List EqualityTrie.Path :=
  guards.flatMap fun guard =>
    match SourcePruningEnumerationConstraint.project guard with
    | none => []
    | some (tries, _) => tries.flatMap EqualityTrie.fromPathTrie

/-- Form a finite suffix carrier from the original state and guard forecast. -/
noncomputable def carrier (guards : List Constraint) (initial : Core) : List EqualityTrie.Path :=
  (initial.values.flatMap (fun value =>
    (EnumerationSchedule.references value).flatMap (fun sc => EqualityTrie.fromPathTrie sc.trie)) ++
    projectedPaths guards).flatMap suffixes

/-- Every original stored path belongs to the finite carrier. -/
theorem initial_paths (guards : List Constraint) (initial : Core) :
    StatePaths (fun path => path ∈ carrier guards initial) initial := by
  intro value stored sc suspended path represented
  apply List.mem_flatMap.mpr
  refine ⟨path, List.mem_append.mpr (.inl ?_), suffixes_self path⟩
