namespace MicroCFTA.SourcePruningEnumerationPathTransport
open EnumerationState EnumerationSchedule

/-- Every represented path in the bucket satisfies the predicate. -/
def BucketPaths (P : EqualityTrie.Path → Prop) (scs : List Suspended) : Prop :=
  ∀ sc ∈ scs, ∀ path ∈ EqualityTrie.fromPathTrie sc.trie, P path

/-- Every stored pending bucket satisfies the path predicate. -/
def StatePaths {Symbol Guard : Type} (P : EqualityTrie.Path → Prop)
    (state : EnumerationState.State Symbol Guard) : Prop :=
  ∀ value ∈ state.values, BucketPaths P (references value)

/-- Each actual guard projection satisfies the path predicate. -/
def ProjectionPaths
    (guards : List (SourceSymbolicIndex.Constraint FullSyntax.Formula))
    (P : EqualityTrie.Path → Prop) : Prop :=
  ∀ guard ∈ guards, ∀ tries residual,
    SourcePruningEnumerationConstraint.project guard = some (tries, residual) →
    ∀ trie ∈ tries, ∀ path ∈ EqualityTrie.fromPathTrie trie, P path

/-- A represented child path comes from its indexed parent path. -/
theorem descended_path_original (trie : EqualityTrie.Trie)
    (index : Nat) (suffix : EqualityTrie.Path)
    (member : suffix ∈ EqualityTrie.fromPathTrie (EqualityTrie.pathTrieDescend trie index)) :
    index :: suffix ∈ EqualityTrie.fromPathTrie trie := by
  cases trie with
  | empty | terminal =>
      simp [EqualityTrie.pathTrieDescend, EqualityTrie.fromPathTrie] at member
  | branch children =>
      cases found : EqualityTrie.lookup index children with
      | none =>
          simp [EqualityTrie.pathTrieDescend, found, EqualityTrie.fromPathTrie] at member
      | some child =>
          have present : suffix ∈ EqualityTrie.fromPathTrie child := by
            simpa [EqualityTrie.pathTrieDescend, found] using member
          exact (EqualityTrie.mem_fromChildren children _).mpr
            ⟨index, child, suffix, EqualityTrie.lookup_mem _ _ _ found, present, rfl⟩

/-- Appending two buckets preserves their common path predicate. -/
theorem BucketPaths.append {P : EqualityTrie.Path → Prop} {first second : List Suspended}
    (left : BucketPaths P first) (right : BucketPaths P second) :
    BucketPaths P (first ++ second) := by
  intro sc member
  rcases List.mem_append.mp member with old | added
  · exact left sc old
  · exact right sc added

/-- Every retained child bucket satisfies the tail-closed path predicate. -/
theorem BucketPaths.descend {P : EqualityTrie.Path → Prop} {scs : List Suspended}
    (paths : BucketPaths P scs)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix) (index : Nat) :
    BucketPaths P (descendScs index scs) := by
  intro sc member suffix represented
  change sc ∈ EqualityTrie.descendScs index scs at member
  unfold EqualityTrie.descendScs at member
  obtain ⟨mapped, _⟩ := List.mem_filter.mp member
  obtain ⟨original, originalMember, rfl⟩ := List.mem_map.mp mapped
  exact tails index suffix (paths original originalMember (index :: suffix)
    (descended_path_original original.trie index suffix represented))

/-- A fresh empty pending bucket adds no represented path. -/
