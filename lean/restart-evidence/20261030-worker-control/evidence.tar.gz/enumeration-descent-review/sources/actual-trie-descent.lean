def descendScs (index : Nat) (constraints : List (Suspended Variable)) : List (Suspended Variable) :=
  (constraints.map (fun constraint => ⟨pathTrieDescend constraint.trie index, constraint.var⟩)).filter
    (fun constraint => !isEmpty constraint.trie)

/-- Suspended descent retains exactly the requested suffixes and their original variables. -/
