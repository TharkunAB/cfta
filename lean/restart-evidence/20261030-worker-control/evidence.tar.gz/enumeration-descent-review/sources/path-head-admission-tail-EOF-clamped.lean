    {rows : List _}
    (observed : SourcePruningEnumerationCachedOwn.prepare
      caller.checked.native.machine.heap scs edge before = some rows) :
    ∀ row ∈ rows,
      StatePaths P row.2.core ∧ ∀ child ∈ row.1.2.1, BucketPaths P child.2.1 := by
  have inherited : BucketPaths P scs :=
    original (.unenumerated (some handle) scs) (List.mem_of_getElem? admission.stored)
  have resident : InternedEdgeResidency.EdgeResident caller.checked.native.machine.heap edge :=
    InternedEdgeResidency.resident_edges caller.checked.native.machine.heap
      admission.packet.context.ready.semantic.ready.semantic.1.normal.facts.linked
      _ admission.parentAvailable.resident edge admission.selected
  have guardIncluded : edge.entry.key.constraint ∈ guards :=
    included (admission.known edge.entry.key edge resident)
  apply prepare_paths original inherited tails ?_ observed
  intro tries residual projection
  exact projected edge.entry.key.constraint guardIncluded tries residual projection

end MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources
