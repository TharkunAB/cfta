/-- Canonical path sets represent the source's set of suspended tries. -/
def recursionKey (node : Nat) (scs : List Suspended) : RecursionKey :=
  ⟨node, (scs.map fun sc => EqualityTrie.fromPathTrie sc.trie).eraseDups.mergeSort
    (fun left right => compare left right != .gt)⟩

/-- Mutable state copied separately for each nondeterministic branch. -/
structure State (Symbol Guard : Type) where
  counter : Nat
  representatives : UnionFind.Forest
  values : List (UVarValue Symbol)
  obligations : List (Guard × Fragment Symbol)
  recursionAncestry : Nat → List RecursionKey
  expansionAncestry : List RecursionKey

/-- The root starts in UVar zero. -/
def initial (root : Nat) : State Symbol Guard :=
  ⟨1, UnionFind.withInitialValues [0], [.unenumerated (some root) []], [], fun _ => [], []⟩

/-- Source invariant failures and explicit finite execution bounds. -/
inductive Error where
  | fuelExhausted | representativeFuel | invalidSlot | invalidIntersection
  | unresolvedReference | unfinishedFragment
  deriving DecidableEq, Repr

