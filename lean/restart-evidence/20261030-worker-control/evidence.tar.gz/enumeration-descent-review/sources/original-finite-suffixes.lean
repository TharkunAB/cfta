def suffixes : EqualityTrie.Path → List EqualityTrie.Path
  | [] => [[]]
  | index :: rest => (index :: rest) :: suffixes rest

