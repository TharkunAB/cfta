                      exact ⟨retained, (currentValid.edges.checked handle _ running).1, fields⟩

/-- One actual checked transition derives both physical and same-cache field invariants. -/
theorem step_invariants [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (control : Control Output) (state : CheckedState width) (valid : Good state)
    (inputs : SourceCurrentAllocatedNativePhysicalExecution.Inputs control state) (fields : Fields control state) :
    Good (step control state).state ∧
      Extension state.native.machine (step control state).state.native.machine ∧
      SourceEqualityRequiredCache.Keeps state.native.machine.heap (step control state).state.native.machine.heap ∧
      SourceEqualityConstraintMemoAllocation.Grows state.operations (step control state).state.operations ∧
      OutcomeFields (step control state) := by
  have physical := SourceCurrentAllocatedNativePhysicalExecution.step_invariants control state valid.native valid.heap inputs
  have operationFields := SourceCurrentAllocatedNativeFieldClosure.operation_fields control state valid.fields fields
  have operations := SourceEqualityNativeDemandOperations.step_operations control state valid.operations operationFields
  have annotations := step_fields control state valid valid.fields inputs fields
  exact ⟨⟨physical.1, physical.2.2.ready, operations.1, annotations.1⟩,
    physical.2.1, physical.2.2, operations.2, annotations⟩

private theorem operations_trans {before middle after : Operations}
    (first : SourceEqualityConstraintMemoAllocation.Grows before middle)
    (second : SourceEqualityConstraintMemoAllocation.Grows middle after) :
    SourceEqualityConstraintMemoAllocation.Grows before after :=
  ⟨SourceEqualityConstraintAllocation.steps_trans first.constraints second.constraints,
    Cache.extends_trans first.combinations second.combinations, Cache.extends_trans first.descents second.descents⟩

/-- Physical reached checks derive all cache invariants and actual continuation fields from the initial state. -/
theorem execute_invariants [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (fuel : Nat) (control : Control Output) (state : CheckedState width) (valid : Good state)
    (inputs : SourceCurrentAllocatedNativePhysicalExecution.InputsThrough fuel control state) (fields : Fields control state) :
    Good (SourceEqualityNativeDemand.execute fuel control state).state ∧
      Extension state.native.machine (SourceEqualityNativeDemand.execute fuel control state).state.native.machine ∧
      SourceEqualityRequiredCache.Keeps state.native.machine.heap (SourceEqualityNativeDemand.execute fuel control state).state.native.machine.heap ∧
      SourceEqualityConstraintMemoAllocation.Grows state.operations (SourceEqualityNativeDemand.execute fuel control state).state.operations ∧
      OutcomeFields (SourceEqualityNativeDemand.execute fuel control state) := by
  induction fuel generalizing control state with
  | zero => exact ⟨valid, .refl _, SourceEqualityRequiredCache.pure_keeps _ valid.heap,
      SourceEqualityConstraintMemoAllocation.grows_refl _, valid.fields, fields⟩
  | succ fuel ih =>
      have one := step_invariants control state valid inputs.1 fields
      cases actual : step control state with
      | yielded next after =>
          have current : Good after ∧ Extension state.native.machine after.native.machine ∧
              SourceEqualityRequiredCache.Keeps state.native.machine.heap after.native.machine.heap ∧
              SourceEqualityConstraintMemoAllocation.Grows state.operations after.operations ∧ OutcomeFields (.yielded next after) := by
            simpa only [actual, Outcome.state] using one
          have rest := ih next after current.1
            (by simpa only [SourceCurrentAllocatedNativePhysicalExecution.InputsThrough, actual] using inputs.2)
            current.2.2.2.2.2
          simpa only [SourceEqualityNativeDemand.execute, actual] using And.intro rest.1
            ⟨current.2.1.trans rest.2.1, current.2.2.1.trans rest.2.2.1,
              operations_trans current.2.2.2.1 rest.2.2.2.1, rest.2.2.2.2⟩
      | done | failed | constraintError | blocked =>
          simpa only [SourceEqualityNativeDemand.execute, actual, Outcome.state] using one

private theorem yielded_invariants [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (control next : Control Output) (state after : CheckedState width) (valid : Good state)
    (inputs : SourceCurrentAllocatedNativePhysicalExecution.Inputs control state) (fields : Fields control state)
    (actual : step control state = .yielded next after) :
    Good after ∧ Extension state.native.machine after.native.machine ∧
      SourceEqualityRequiredCache.Keeps state.native.machine.heap after.native.machine.heap ∧
      SourceEqualityConstraintMemoAllocation.Grows state.operations after.operations ∧ Fields next after := by
  have checked := step_invariants control state valid inputs fields
  have current : Good after ∧ Extension state.native.machine after.native.machine ∧
      SourceEqualityRequiredCache.Keeps state.native.machine.heap after.native.machine.heap ∧
