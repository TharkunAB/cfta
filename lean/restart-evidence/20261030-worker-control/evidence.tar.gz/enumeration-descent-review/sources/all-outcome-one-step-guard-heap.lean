theorem step_heap (alphabet : List Guard) (control : Control A) (before : Checked width)
    (good : SourceCurrentAllocatedNativePhysicalCompletion.Good before)
    (inputs : SourceCurrentAllocatedNativePhysicalExecution.Inputs control before)
    (known : Heap (fun guard => guard ∈ alphabet) before.native.machine.heap)
    (fields : Fields alphabet control) :
    Heap (fun guard => guard ∈ alphabet) (SourceEqualityNativeDemand.step control before).state.native.machine.heap := by
  cases control with
  | edgeBody request next =>
      rw [SourceEqualityNativeDemand.step, SourceEqualityNativeDemandOperations.body_native]
      exact known
  | code code =>
      cases code with
      | pure | fail | enter | read | finishNode | finishEdge => exact known
      | work job next => exact SourceEqualityAnnotationHeap.run _ job fields.1 before.native.machine.heap known
      | optionalBinder pair body next =>
