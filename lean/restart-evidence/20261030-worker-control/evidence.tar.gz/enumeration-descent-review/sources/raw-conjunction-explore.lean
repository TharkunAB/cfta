noncomputable def explore [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (p h budget : Nat) (table : Table Symbol Formula)
    (pending : List (List (Value Symbol Guard))) (before : Physical Symbol Formula) :
    Outcome Symbol Formula (Table Symbol Formula) :=
  match pending with
  | [] => .done table before
  | nodes :: rest =>
      if nodes.any isEmpty then explore p h budget table rest before
      else if SourceCurrentConjunctionEmptinessTable.skip key closed budget table nodes then
        explore p h budget table rest before
      else
        match SourceCurrentConjunctionRowsWorker.rows p h nodes before with
        | .done requirements middle =>
            explore p h (budget - 1) (⟨nodes, requirements⟩ :: table) (requirements.flatten ++ rest) middle
        | .failed fault after => .failed (.rows fault table (nodes :: rest)) after
termination_by (budget, pending.length)
decreasing_by
  · exact Prod.Lex.right _ (by simp)
  · exact Prod.Lex.right _ (by simp)
  · apply Prod.Lex.left
    have positive := (SourceCurrentConjunctionEmptinessTable.admitted SourceCurrentConjunctionRequirements.key
      SourceCurrentConjunctionWorklist.closed budget table nodes
      (Bool.eq_false_iff.mpr (by assumption))).1
    omega

