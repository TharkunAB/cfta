noncomputable def decision [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    [DecidableEq (Value Symbol Guard)] (p h budget : Nat) (start : Value Symbol Guard)
    (before : Physical Symbol Formula) : Outcome Symbol Formula Bool :=
  if closed start then
    (explore p h budget [] [[start]] before).bind fun table after =>
      match SourceCurrentConjunctionEmptinessTable.grow .empty key closed table (budget + 1) (fun _ => false) with
      | some known => .done (SourceCurrentConjunctionEmptinessTable.answer .empty key closed table known start) after
      | none => .failed (.grow table) after
  else .done false before

local notation "ConcreteSymbol" => SourceObservations.Label FullSyntax.Formula
local notation "ConcreteGuard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Memo" => SourceCurrentEmptinessMemo.Memo

/-- Lookup precedes the body guard. Only a completed miss inserts its original query and answer. -/
noncomputable def call [DecidableEq ConcreteSymbol] [DecidableEq (EdgeKey ConcreteSymbol ConcreteGuard)]
    [DecidableEq (Value ConcreteSymbol ConcreteGuard)] (p h budget : Nat) (memo : Memo)
    (query : Value ConcreteSymbol ConcreteGuard) (before : Physical ConcreteSymbol FullSyntax.Formula) :
    Outcome ConcreteSymbol FullSyntax.Formula (Bool × Memo) :=
  match memo query.referenceOf with
  | some (_, answer) => .done (answer, memo) before
  | none => (decision p h budget query before).bind fun answer after =>
      .done (answer, SourceCurrentEmptinessMemo.insert memo query answer) after

/-- A failed memo miss retains its literal physical failure and inserts no completed answer. -/
theorem call_failed [DecidableEq ConcreteSymbol] [DecidableEq (EdgeKey ConcreteSymbol ConcreteGuard)]
    [DecidableEq (Value ConcreteSymbol ConcreteGuard)]
    (p h budget : Nat) (memo : Memo) (query : Value ConcreteSymbol ConcreteGuard)
    (before after : Physical ConcreteSymbol FullSyntax.Formula) (fault : Fault ConcreteSymbol FullSyntax.Formula)
    (absent : memo query.referenceOf = none) (failed : decision p h budget query before = .failed fault after) :
    call p h budget memo query before = .failed fault after := by
  simp only [call, absent, failed, Outcome.bind]

end MicroCFTA.SourceCurrentConjunctionWorker
