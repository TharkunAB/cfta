assimilateUvarVal ::
    (Hashable symbol, Typeable symbol) => UVar -> UVar -> EnumerateM symbol ()
assimilateUvarVal uvTarg uvSrc
    | uvTarg == uvSrc = return ()
    | otherwise = do
        values <- gets _uvarValues
        let srcVal = values IntMap.! uvarToInt uvSrc
        let targVal = values IntMap.! uvarToInt uvTarg
        case srcVal of
            UVarEliminated -> return () -- Happens from duplicate constraints
            _ -> do
                checkEmpty <- gets _constrainedRecursion
                let v = intersectUVarValue checkEmpty srcVal targVal
                guard $ not $ hasEmptyContents v
                -- The suspended constraints of the source move to the
                -- target, in the same class, so no count changes.
                writeUVarValue Sequence.Empty Sequence.Empty uvTarg v
                writeUVarValue Sequence.Empty Sequence.Empty uvSrc UVarEliminated
                modify' $ \s -> case IntMap.lookup (uvarToInt uvSrc) (_recursionAncestry s) of
                    Nothing -> s
                    Just ancestry -> s{_recursionAncestry = IntMap.insertWith HashSet.union (uvarToInt uvTarg) ancestry (_recursionAncestry s)}

-- | Intersect a node and inherited constraints into the value for a UVar.
mergeNodeIntoUVarVal ::
    (Hashable symbol, Typeable symbol) =>
    UVar -> Node symbol -> Seq SuspendedConstraint -> EnumerateM symbol ()
mergeNodeIntoUVarVal uv n scs = do
    uv' <- getUVarRepresentative uv
    let idx = uvarToInt uv'
    values <- gets _uvarValues
    checkEmpty <- gets _constrainedRecursion
    let new = intersectUVarValue checkEmpty (UVarUnenumerated (Just n) scs) (values IntMap.! idx)
    -- The slot keeps its suspended constraints and gains these.
    writeUVarValue scs Sequence.Empty uv' new
    inheritAncestry idx
    guard $ not $ hasEmptyContents new

-- | Whether an unenumerated variable has already reduced to the empty node.
hasEmptyContents :: UVarValue symbol -> Bool
hasEmptyContents (UVarUnenumerated (Just EmptyNode) _) = True
hasEmptyContents _ = False

---------------------
-------- Core enumeration algorithm
---------------------

-- | Table for 'unconstrained'.
unconstrainedCache :: TypeableMemoCache
unconstrainedCache = unsafePerformIO newTypeableMemoCache
{-# NOINLINE unconstrainedCache #-}

{- | Whether no edge reachable from the node carries a constraint: no path
equality and no residual. Such an automaton is an ordinary tree automaton,
recursive or not.
-}
unconstrained :: forall symbol. (Typeable symbol) => Node symbol -> Bool
unconstrained = memoTypeableWith @symbol unconstrainedCache $ getAll . crush free
  where
    free (Node es) = All (all (\e -> equalities (edgeConstraint e) == EmptyConstraints && not (residual (edgeConstraint e))) es)
