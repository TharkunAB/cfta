enumerateUntil' ::
    forall symbol a.
    (Hashable symbol, Typeable symbol) =>
    Maybe (a -> UVar -> Bool) ->
    (a -> UVar -> Node symbol -> Node symbol) ->
    (Seq SuspendedConstraint -> Node symbol -> EnumerateM symbol (TermFragment symbol)) ->
    a ->
    ExpansionOrder a ->
    (a -> UVar -> Either (TermFragment symbol) (Node symbol) -> EnumerateM symbol (Bool, a)) ->
    EnumerateM symbol (Maybe a)
enumerateUntil' stop narrow expandNode ost order oracle = case stop of
    Just rule -> do
        remaining <- gets _expandableUVars
        if not (IntSet.null remaining) && all (rule ost . intToUVar) (IntSet.toList remaining)
            then return (Just ost)
            else step
    Nothing -> step
  where
    step = do
        muv <- nextExpandableUVar (order ost)
        case muv of
            ExpansionStuck -> mzero
            ExpansionDone -> return Nothing
            ExpansionNext uv -> expandNext uv
    expandNext uv =
        let continue ost' = do
                tf <- enumerateOutUVarWith expandNode uv
                (should_prune, ost'') <- oracle ost' uv (Left tf)
                if should_prune
                    then mzero
                    else enumerateUntil' stop narrow expandNode ost'' order oracle
            expand n scs = do
                let narrowed = narrow ost uv n
