theorem projected_paths (guards : List Constraint) (initial : Core) :
    ProjectionPaths guards (fun path => path ∈ carrier guards initial) := by
  intro guard included tries residual projected trie chosen path represented
  apply List.mem_flatMap.mpr
  refine ⟨path, List.mem_append.mpr (.inr ?_), suffixes_self path⟩
  apply List.mem_flatMap.mpr
  refine ⟨guard, included, ?_⟩
  simp only [projected]
  exact List.mem_flatMap.mpr ⟨trie, chosen, represented⟩

/-- Delete one leading child index without leaving the original finite carrier. -/
theorem tail_closed (guards : List Constraint) (initial : Core)
    (index : Nat) (suffix : EqualityTrie.Path)
    (member : index :: suffix ∈ carrier guards initial) :
    suffix ∈ carrier guards initial := by
