import MicroCFTA.SourceCurrentNativeGuardCode
import MicroCFTA.SourceCurrentNativeGuardAlphabet
import MicroCFTA.SourceCurrentAllocatedRecursiveRequestStep
import MicroCFTA.SourceCurrentAllocatedNativePhysicalCompletion

/-!
# Finite guard alphabets through actual native instructions

One alphabet extension covers each checked instruction. Actual row
residency supplies each conjunction operand. Captured code retains its
literal guard checks at the larger alphabet.
-/
namespace MicroCFTA.SourceCurrentNativeGuardStep
open InternedConstructorTemplates InternedProbeProvenance
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand
open SourceCurrentNativeGuardAlphabet (step mem_step_of_mem top_mem_step conjoin_mem_step)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Checked" => SourceEqualityNativeDemand.State
local notation "CodeFields" => SourceCurrentNativeGuardCode.Fields
local notation "Heap" => SourceEqualityAnnotationHeap.Heap
variable {A : Type} {width : Nat}

/-- Both checked control forms retain the static checks in their captured code. -/
def Fields (alphabet : List Guard) : Control A → Prop
  | .code code => CodeFields (fun guard => guard ∈ alphabet) code
  | .edgeBody _ next => ∀ value, CodeFields (fun guard => guard ∈ alphabet) (next value)

