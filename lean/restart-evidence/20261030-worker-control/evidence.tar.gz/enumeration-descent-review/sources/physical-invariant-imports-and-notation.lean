import MicroCFTA.SourceCurrentAllocatedNativePhysicalExecution
import MicroCFTA.SourceCurrentAllocatedNativeRunning

/-!
# Physical checked transitions for recursive completion

Physical memo validity suffices to retain loaded annotation fields.
Actual node and edge demands yield under strict independent request bounds.
The checked edge prefix derives its actual child code and field allocation.
These transition theorems do not assume a completed recursive body.
-/
namespace MicroCFTA.SourceCurrentAllocatedNativePhysicalCompletion
open Cache InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceRecursiveIntersectionInputView IntersectSchedule SourceEqualityNativeDemand
open SourceCurrentAllocatedNativeFieldClosure (Fields OutcomeFields body_fields)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "CheckedState" => SourceEqualityNativeDemand.State
local notation "CodeFields" => SourceCurrentAllocatedNativeCodeFields.Fields
local notation "Heap" => SourceCurrentConjunctionEquality.Fields
local notation "Operations" => SourceEqualityConstraintMemoAllocation.State
local instance : DecidableEq (SourceGuards.Guard FullSyntax.Formula) :=
  SourceEqualityPCSNativeEdge.guardDecidableEq

