theorem prepare_paths {P : EqualityTrie.Path → Prop}
    {heap : InternedConstructorTemplates.State SourceSymbol SourceConstraint}
    {scs : List Suspended}
    {edge : InternedConstructorTemplates.EdgeValue SourceSymbol SourceConstraint}
    {before : EnumerationExpandableIndex.Cached SourceSymbol SourceConstraint}
    (original : StatePaths P before.core) (inherited : BucketPaths P scs)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (projectedPaths : ∀ tries residual,
      SourcePruningEnumerationConstraint.project edge.entry.key.constraint = some (tries, residual) →
      ∀ trie ∈ tries, ∀ path ∈ EqualityTrie.fromPathTrie trie, P path)
    {rows : List _}
    (observed : SourcePruningEnumerationCachedOwn.prepare heap scs edge before = some rows) :
    ∀ row ∈ rows,
      StatePaths P row.2.core ∧ ∀ child ∈ row.1.2.1, BucketPaths P child.2.1 := by
  unfold SourcePruningEnumerationCachedOwn.prepare at observed
  split at observed
  · cases projected : SourcePruningEnumerationConstraint.project edge.entry.key.constraint with
    | none =>
        simp only [projected] at observed
        cases observed
    | some projection =>
        obtain ⟨tries, residual⟩ := projection
        simp only [projected] at observed
        obtain ⟨result, suspended, same⟩ := Option.map_eq_some_iff.mp observed
        have ownPaths := suspendMany_paths heap tries before result.1 result.2
          (projectedPaths tries residual projected) original suspended
        intro row member
        rw [← same] at member
        have rowSame := List.mem_singleton.mp member
        cases rowSame
        refine ⟨ownPaths.2, ?_⟩
        intro child member
        obtain ⟨indexed, _chosen, childSame⟩ := List.mem_map.mp member
        cases childSame
        exact (inherited.descend tails indexed.2).append (ownPaths.1.descend tails indexed.2)
  · have rowsSame : [] = rows := Option.some.inj observed
    rw [← rowsSame]
    intro row member
    cases member

end MicroCFTA.SourcePruningEnumerationPathTransport

namespace MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources
