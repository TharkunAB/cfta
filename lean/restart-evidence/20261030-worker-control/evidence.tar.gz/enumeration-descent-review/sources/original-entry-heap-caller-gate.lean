theorem original_heap (literals : List Guard)
    (normalized : ∀ literal ∈ literals, SourceEqualityGuardReadback.Cached literal.equalities)
    (heap : InternedConstructorTemplates.State Symbol Guard)
    (origins : Heap (Derived literals top conjoin) heap) :
    Heap (fun guard => guard ∈ originalAlphabet literals) heap :=
  fun key edge present => (mem_originalAlphabet literals normalized key.constraint).mpr (origins key edge present)

/-- Actual current native prefixes retain a finite original carrier without an instruction-count ceiling. -/
