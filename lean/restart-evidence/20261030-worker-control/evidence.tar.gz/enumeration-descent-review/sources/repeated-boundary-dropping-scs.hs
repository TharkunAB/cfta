         in do
                UVarUnenumerated (Just n) scs <- getUVarValue uv
                case n of
                    _ | recursiveBoundary n -> do
                        uv' <- getUVarRepresentative uv
                        ancestry <- gets $ IntMap.findWithDefault HashSet.empty (uvarToInt uv') . _recursionAncestry
                        if HashSet.member (recursionKey n scs) ancestry
                            then do
                                -- The expansion of this node with these paths led to it
                                -- again, so each further expansion repeats the last one.
                                -- Enumeration stops here, as at an unconstrained 'Mu'.
                                setUVarValue uv' (UVarUnenumerated (Just n) Sequence.Empty)
                                enumerateUntil' stop narrow expandNode ost order oracle
                            else expand n scs
                    _ -> expand n scs

---------------------
-------- Expanding an enumerated term fragment into a term
---------------------

{- | The fragment the root UVar holds, or the root hole itself.

An automaton that is a bare 'Mu' is never expanded, because an unconstrained
'Mu' is where enumeration stops. Its root stays a hole, exactly as a nested one
does.
-}
rootTermFrag :: EnumerateM symbol (TermFragment symbol)
rootTermFrag = do
    value <- getUVarValue root
    return $ case value of
        UVarEnumerated fragment -> fragment
        _ -> TermFragmentUVar root
  where
