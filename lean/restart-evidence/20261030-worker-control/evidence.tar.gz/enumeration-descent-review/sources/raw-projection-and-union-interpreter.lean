def union [DecidableEq (EdgeKey Symbol Guard)] (readFuel : Nat) (values : List (Value Symbol Guard))
    (state : State Symbol Guard) : Result Symbol Guard (Value Symbol Guard) :=
  (readAll readFuel values state).bind fun edges after => work (makeNode edges) after

/-- Map only existing row children, in the original source row order. -/
def rows (recur : Value Symbol Guard → State Symbol Guard → Result Symbol Guard (Value Symbol Guard))
    (index : Int) : List (EdgeValue Symbol Guard) → State Symbol Guard → Result Symbol Guard (List (Value Symbol Guard))
  | [], state => .done [] state
  | edge :: edges, state => match select edge.children index with
    | none => rows recur index edges state
    | some child => (recur child state).bind fun value middle =>
        (rows recur index edges middle).bind fun values after => .done (value :: values) after

/-- Execute the actual source branches with separate worker and row-read proof bounds. -/
def project [DecidableEq (EdgeKey Symbol Guard)] : Nat → Nat → List Int → Value Symbol Guard →
    State Symbol Guard → Result Symbol Guard (Value Symbol Guard)
  | 0, _, _, _, state => .exhausted .worker state
  | _ + 1, _, [], value, state => .done value state
  | fuel + 1, readFuel, index :: path, value, state => match value with
    | .empty => .done .empty state
    | .reference name => .unresolved name state
    | .node _ edges _ _ => (rows (project fuel readFuel path) index edges state).bind fun values after => union readFuel values after
    | .mu .. | .union .. => (head readFuel value state).bind fun exposed after => project fuel readFuel (index :: path) exposed after

/-- Forest root projection executes union; an absent signed child returns EmptyNode. -/
def forest [DecidableEq (EdgeKey Symbol Guard)] (fuel readFuel : Nat) (path : List Int)
    (values : List (Value Symbol Guard)) (state : State Symbol Guard) : Result Symbol Guard (Value Symbol Guard) :=
  match path with
  | [] => union readFuel values state
  | index :: path => match select values index with
    | none => .done .empty state
    | some value => project fuel readFuel path value state
