data SuspendedConstraint = SuspendedConstraint !PathTrie !UVar
    deriving (Eq, Show)

-- | Remaining paths for a suspended equality obligation.
scGetPathTrie :: SuspendedConstraint -> PathTrie
scGetPathTrie (SuspendedConstraint pt _) = pt

-- | UVar that must be merged when the suspended obligation is reached.
scGetUVar :: SuspendedConstraint -> UVar
scGetUVar (SuspendedConstraint _ uv) = uv

{- | Push suspended obligations into the children they reach, by child index.

Each child gets its obligations in the order of the input. An obligation that
reaches no child, because its paths end here, goes to no child.
-}
descendScs ::
    (Foldable f) =>
    IntMap.IntMap (Seq SuspendedConstraint) -> f SuspendedConstraint -> IntMap.IntMap (Seq SuspendedConstraint)
descendScs = Foldable.foldl' descend
  where
    descend children (SuspendedConstraint (PathTrie tries) uv) =
        IntMap.foldlWithKey'
            (\m i pt -> IntMap.insertWith (flip (<>)) i (Sequence.singleton (SuspendedConstraint pt uv)) m)
            children
            tries
    descend children _ = children

-----------------------
------- UVarValue
-----------------------

-- | Enumeration status for one UVar.
data UVarValue symbol
    = -- | UVar still has a node to expand.
      UVarUnenumerated
        -- | Node still to enumerate, or 'Nothing' for pure constraint variables.
        !(Maybe (Node symbol))
        -- | Constraints that should be carried while enumerating this value.
        !(Seq SuspendedConstraint)
    | -- | UVar has been expanded to a fragment.
      UVarEnumerated !(TermFragment symbol)
    | -- | UVar was merged into another representative and should no longer be used.
      UVarEliminated
    deriving (Eq, Show)

{- | Intersect two UVar values. With the first argument true, an intersection
that provably accepts no term becomes 'EmptyNode' (see '_constrainedRecursion').
-}
intersectUVarValue ::
    (Hashable symbol, Typeable symbol) =>
    Bool -> UVarValue symbol -> UVarValue symbol -> UVarValue symbol
intersectUVarValue checkEmpty (UVarUnenumerated mn1 scs1) (UVarUnenumerated mn2 scs2) =
    let newContents = case (mn1, mn2) of
            (Nothing, x) -> x
            (x, Nothing) -> x
            (Just n1, Just n2) -> Just (emptyIfProvably (n1 `intersect` n2))
        newConstraints = scs1 <> scs2
     in UVarUnenumerated newContents newConstraints
  where
    -- An intersection can unfold a recursive node with constraints into a
    -- node that needs itself again with no base case. Enumeration of such a
    -- node would not end, so the merge makes it 'EmptyNode', and the caller
    -- ends the branch.
    emptyIfProvably n
        | checkEmpty, reachesConstrainedMu n, provablyEmpty n = EmptyNode
        | otherwise = n
intersectUVarValue _ UVarEliminated _ = error "intersectUVarValue: Unexpected UVarEliminated"
intersectUVarValue _ _ UVarEliminated = error "intersectUVarValue: Unexpected UVarEliminated"
intersectUVarValue _ _ _ = error "intersectUVarValue: Intersecting with enumerated value not implemented"
