theorem original_retained [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (literals : List Guard)
    (normalized : ∀ literal ∈ literals, SourceEqualityGuardReadback.Cached literal.equalities)
    {A : Type} {width fuel : Nat} {control rest : Control A}
    {before after : SourceEqualityNativeDemand.State width}
    (trace : Trace fuel control before rest after) (good : Good before)
    (allocated : Allocated control before)
    (origins : Heap (Derived literals top conjoin) before.native.machine.heap)
    (fields : Fields (originalAlphabet literals) control) :
    Heap (fun guard => guard ∈ originalAlphabet literals) after.native.machine.heap ∧
      Fields (originalAlphabet literals) rest :=
  retained _ (original_closed literals normalized) trace good allocated
    (original_heap literals normalized _ origins) fields

end MicroCFTA.SourceCurrentNativeClosedGuardAlphabet
