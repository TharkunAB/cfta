theorem yielded_fields (alphabet : List Guard) (control rest : Control A) (before after : Checked width)
    (good : SourceCurrentAllocatedNativePhysicalCompletion.Good before)
    (inputs : SourceCurrentAllocatedNativePhysicalExecution.Inputs control before)
    (allocated : SourceCurrentAllocatedNativeFieldClosure.Fields control before)
    (known : Heap (fun guard => guard ∈ alphabet) before.native.machine.heap)
    (fields : Fields alphabet control)
    (one : SourceEqualityNativeDemand.step control before = .yielded rest after) :
    Fields (step alphabet) rest := by
  have widened := fields_mono (fun _ member => mem_step_of_mem member) control fields
  cases control with
  | edgeBody request next =>
      have ready := allocated.1
      have cached : SourceEqualityNativeDemandOperations.Fields (.edgeBody request next) :=
        ⟨(good.fields _ _ ready.2.1).1, (good.fields _ _ ready.2.2).1⟩
      obtain ⟨code, rfl, retained⟩ := SourceCurrentNativeGuardCode.body_fields
