theorem recordTypes_values {Guard Typing : Type} (graph : Graph Symbol Guard)
    (templates : List (Template.Pattern Symbol)) (fuel : Nat)
    (metadata : SourcePruningRecordTypes.Metadata Typing) (uv : Nat)
    (input : Sum (Fragment Symbol) Nat) (before after : State Symbol Guard)
    (result : Bool × SourcePruningRecordTypes.Metadata Typing)
    (success : Success (SourcePruningRecordTypes.recordTypes graph templates fuel metadata uv input)
      before result after) : after.values = before.values := by
  cases templates with
  | nil =>
      rw [SourcePruningRecordTypes.recordTypes_empty] at success
      exact pure_values _ result before after success
  | cons first rest =>
      change Success (SourcePruningOracle.oracle graph (first :: rest) fuel metadata.pending uv input >>=
        fun observed => pure (observed.1, {metadata with pending := observed.2, types := SourcePruningRecordTypes.updatedTypes metadata uv input}))
        before result after at success
      obtain ⟨observed, middle, read, finished⟩ := (success_bind _ _ _ _ _).mp success
      exact (pure_values _ result middle after finished).trans
        (oracle_values graph (first :: rest) fuel metadata.pending uv input before middle observed read)

/-- Every successful recording preserves the supplied stored path predicate. -/
theorem recordTypes_paths {Guard Typing : Type} {P : EqualityTrie.Path → Prop}
    (graph : Graph Symbol Guard) (templates : List (Template.Pattern Symbol)) (fuel : Nat)
    (metadata : SourcePruningRecordTypes.Metadata Typing) (uv : Nat)
    (input : Sum (Fragment Symbol) Nat) (before after : State Symbol Guard)
    (result : Bool × SourcePruningRecordTypes.Metadata Typing)
    (paths : StatePaths P before)
    (success : Success (SourcePruningRecordTypes.recordTypes graph templates fuel metadata uv input)
      before result after) : StatePaths P after := by
  exact SourcePruningEnumerationPathStorage.values_paths paths
    (recordTypes_values graph templates fuel metadata uv input before after result success)

end MicroCFTA.SourcePruningEnumerationPathRecordingValues
