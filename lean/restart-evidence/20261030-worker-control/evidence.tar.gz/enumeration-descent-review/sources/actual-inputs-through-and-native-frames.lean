
/-- Physical checks follow only the controls and states actually reached. -/
noncomputable def InputsThrough [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] :
    Nat → Control Output → CheckedState width → Prop
  | 0, control, state => Inputs control state
  | fuel + 1, control, state => Inputs control state ∧ match step control state with
      | .yielded next after => InputsThrough fuel next after
      | .done _ _ | .failed _ _ | .constraintError _ _ | .blocked _ _ _ => True

/-- The physical execution plan supplies the current heap checks used by cost and semantic preservation. -/
theorem through_heap [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (fuel : Nat) (control : Control Output) (state : CheckedState width)
    (inputs : InputsThrough fuel control state) :
    SourceEqualityNativeDemandHeap.InputsThrough fuel control state := by
  induction fuel generalizing control state with
  | zero => exact inputs_heap control state inputs
  | succ fuel ih =>
      refine ⟨inputs_heap control state inputs.1, ?_⟩
      cases actual : step control state with
      | yielded next after =>
          exact ih next after (by simpa only [InputsThrough, actual] using inputs.2)
      | done | failed | constraintError | blocked => trivial

/-- One checked step retains physical memo validity, domains, records, and identities. -/
theorem step_invariants [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (control : Control Output) (state : CheckedState width)
    (valid : SourceCurrentAllocatedNativePhysicalCache.Valid state.native)
    (ready : SourceEqualityRequiredCache.Ready state.native.machine.heap) (inputs : Inputs control state) :
    SourceCurrentAllocatedNativePhysicalCache.Valid (step control state).state.native ∧
      Extension state.native.machine (step control state).state.native.machine ∧
      SourceEqualityRequiredCache.Keeps state.native.machine.heap (step control state).state.native.machine.heap :=
  ⟨step_valid control state valid inputs, step_extension control state valid.machine inputs,
    SourceEqualityNativeDemandHeap.step_keeps control state ready (inputs_heap control state inputs)⟩

/-- Every finite actual outcome retains the physical caches and both machine histories. -/
theorem execute_invariants [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
