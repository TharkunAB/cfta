namespace MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources
open EnumerationState InternedConstructorTemplates SourcePruningEnumerationPathTransport
open SourcePruningEnumerationIncomingReservation (Seed)
open SourceCurrentAllocatedNativeInventoryState (Inventory)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Memos" => EndpointMemoGateTrace.Memos
variable {Typing : Type} {bits : Nat}
variable [DecidableEq (EdgeKey Symbol Constraint)]

/-- Current head admission supplies paths for every actual own row and staged child. -/
theorem HeadAdmission.prepare_paths_of_forecast
    {seed : Seed}
    {formulas : SourceGuards.Formulas FullSyntax.Formula}
    {solver : SourceGuards.Entailment FullSyntax.Formula} {inventory : Inventory}
    {caller : Caller (bits + 2)} {memos : Memos}
    {metadata : SourcePruningRecordTypes.Metadata Typing} {before : Cached}
    {uv handle : Nat} {scs : List Suspended}
    {parentEntry : Cache.Interned InternedBinderProtocol.NodeKey}
    {storedEdges : List (EdgeValue Symbol Constraint)} {depth : Nat}
    {free : List InternedBinderProtocol.Reference} {edge : EdgeValue Symbol Constraint}
    (admission : HeadAdmission seed formulas solver inventory caller memos metadata
      before uv handle scs parentEntry storedEdges depth free edge)
    (guards : List Constraint) (P : EqualityTrie.Path → Prop)
    (included : seed.1 ⊆ guards) (projected : ProjectionPaths guards P)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (original : StatePaths P before.core)
    {rows : List _}
    (observed : SourcePruningEnumerationCachedOwn.prepare
      caller.checked.native.machine.heap scs edge before = some rows) :
    ∀ row ∈ rows,
      StatePaths P row.2.core ∧ ∀ child ∈ row.1.2.1, BucketPaths P child.2.1 := by
  have inherited : BucketPaths P scs :=
    original (.unenumerated (some handle) scs) (List.mem_of_getElem? admission.stored)
  have resident : InternedEdgeResidency.EdgeResident caller.checked.native.machine.heap edge :=
    InternedEdgeResidency.resident_edges caller.checked.native.machine.heap
      admission.packet.context.ready.semantic.ready.semantic.1.normal.facts.linked
