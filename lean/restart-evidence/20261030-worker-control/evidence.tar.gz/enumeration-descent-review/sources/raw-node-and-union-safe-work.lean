theorem makeNode (valid : Guard → Prop) (edges : List (EdgeValue Symbol Guard)) :
    SafeWork valid (InternedConstructorTemplates.makeNode edges) := by
  unfold InternedConstructorTemplates.makeNode
  dsimp only
  split <;> simp only [SafeWork, implies_true]

/-- Actual union construction reuses existing edge records in every normalization branch. -/
theorem makeUnion (valid : Guard → Prop) (values : List (Value Symbol Guard)) :
    SafeWork valid (InternedConstructorTemplates.makeUnion values) := by
  unfold InternedConstructorTemplates.makeUnion
  split
  · trivial
  · trivial
  · split
    · exact makeNode valid _
    · exact fun _ => trivial

/-- Source bare-self removal constructs only nodes and unions of existing edges. -/
