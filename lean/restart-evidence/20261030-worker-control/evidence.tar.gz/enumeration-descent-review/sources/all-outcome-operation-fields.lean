    SourceCurrentConjunctionEquality.Fields.grows heap current.2,
    body_fields request next state {state with operations := after} (.code code) heap ready valid fields actual⟩

/-- Every outcome retains successful field loads; yielded continuations retain their current checks. -/
def OutcomeFields (outcome : Outcome width Output) : Prop :=
  Heap outcome.state.operations outcome.state.native.machine.heap ∧ match outcome with
    | .yielded control state => Fields control state
    | _ => True

private theorem lift_native (operations : SourceEqualityConstraintMemoAllocation.State)
    (outcome : SourceRecursiveIntersectionNative.Outcome width Symbol Guard Output) :
    (lift operations outcome).state.native = outcome.state := by cases outcome <;> rfl

/-- Actual source instructions retain field loads in the returned operation cache. -/
