import MicroCFTA.SourcePruningEnumerationPathTransport
import MicroCFTA.SourcePruningEnumerationDispatch

/-!
# Stored path preservation through actual native assimilation

The actual writes append the two stored pending buckets.
The path predicate does not depend on their optional native handles.
-/
namespace MicroCFTA.SourcePruningEnumerationDispatch
open EnumerationState EnumerationCorrectness EnumerationSchedule
open InternedConstructorTemplates SourcePruningEnumerationPathTransport
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => InternedConstructorTemplates.Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
variable {EnumGuard : Type} {width : Nat} {P : EqualityTrie.Path → Prop}

/-- The actual target write and source elimination preserve both original path buckets. -/
theorem assimilated_paths
    (before : EnumerationState.State Symbol EnumGuard) (source target : Nat)
    (sourceNode targetNode merged : Option Nat) (sourceScs targetScs : List Suspended)
    (paths : StatePaths P before)
    (sourceStored : before.values[source]? = some (.unenumerated sourceNode sourceScs))
    (targetStored : before.values[target]? = some (.unenumerated targetNode targetScs)) :
    StatePaths P (assimilated before target source (.unenumerated merged (sourceScs ++ targetScs))) := by
  have sourcePaths : BucketPaths P sourceScs :=
    paths (.unenumerated sourceNode sourceScs) (List.mem_of_getElem? sourceStored)
  have targetPaths : BucketPaths P targetScs :=
    paths (.unenumerated targetNode targetScs) (List.mem_of_getElem? targetStored)
  have payload := sourcePaths.append targetPaths
  intro value member
  change value ∈ (before.values.set target
    (.unenumerated merged (sourceScs ++ targetScs))).set source .eliminated at member
  rcases List.mem_or_eq_of_mem_set member with retained | eliminated
  · rcases List.mem_or_eq_of_mem_set retained with old | replacement
    · exact paths value old
    · simpa only [replacement, references] using payload
  · simp [eliminated, references, BucketPaths]

/-- Every actual successful dispatcher singleton preserves its original path predicate. -/
theorem dispatch_paths
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
    (checkEmpty : Bool) (nativeFuel p h : Nat)
    (beforeCaller : Caller width) (before : EnumerationState.State Symbol EnumGuard)
    (source target : Nat) (queries : Queries) (action : EnumerateM Symbol EnumGuard Unit)
    (afterCaller : Caller width) (savedQueries : Queries)
    (after : EnumerationState.State Symbol EnumGuard)
    (paths : StatePaths P before)
    (selected : SourcePruningEnumerationDispatch.dispatch checkEmpty nativeFuel p h
      beforeCaller before source target queries = (.ok (some action), afterCaller, savedQueries))
    (completed : ExceptT.run (action before) = [.ok ((), after)]) :
    StatePaths P after := by
  by_cases same : source = target
  · simp only [SourcePruningEnumerationDispatch.dispatch, ite_eq_left same, Id.run, pure,
      Prod.mk.injEq, Except.ok.injEq, Option.some.injEq] at selected
    rcases selected with ⟨rfl, rfl, rfl⟩
    change [Except.ok ((), before)] = [Except.ok ((), after)] at completed
    simp only [List.cons.injEq, and_true, Except.ok.injEq, Prod.mk.injEq, true_and] at completed
    subst after
    exact paths
  · cases sourceStored : before.values[source]? with
    | none => simp [SourcePruningEnumerationDispatch.dispatch, same, sourceStored] at selected
    | some sourceValue =>
      cases sourceValue with
