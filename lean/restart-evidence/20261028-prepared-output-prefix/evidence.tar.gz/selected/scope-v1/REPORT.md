# Selected continuation output-prefix candidate

One additive source candidate is sealed in candidate-v1/SourcePruningEnumerationSelectedContinuationOutputPrefix.lean. It has 126 lines and 7109 bytes. SHA256: c0e689d29bb754af2b97a4942c434d1ed04770c47fa63fe247141cf101e1a883.

The candidate was read whole without truncation. It was not compiled by this agent. Root reported default build PASS for the exact installed native prefix helper. The new candidate is initially untested. Compiler validation belongs to Root.

## Exact interfaces

ReceiptContinuation.run_outputs_prefix takes first and second hooks, agreement on each actual completed first-hook result, per-invocation hookOutputs prefix, and one identical actual optional native receipt. It concludes List.IsPrefix of foldOutputs of the two actual single-receipt dispatch results. This includes complete and stopped results.

SelectedContinuations.run_outputs_prefix takes first and second hooks, identical checkEmpty, entry/native/r/n/p/h/k fuels, selected target, edgesOf, caller, captured cache, and query state. The same completed-result and per-invocation output-prefix premises follow those original inputs. It concludes List.IsPrefix of the two literal optional-fold output observations:

    ((run hook ...).2.map HookInvocation.foldOutputs).getD []

The observer uses the existing foldOutputs function. No new observer, definition, custom invariant, model, resource contract, or prepared/source identity cast was added. Missing native preparation or a missing supported singleton contributes the empty output observation.

## Composition and binding

A completed first hook remains exactly complete with the same output list, aggregate caller, and query state. This exact endpoint condition permits the native sibling proof to continue from the same captured suffix input. A stopped first hook needs only an output prefix in its replacement hook. The replacement may stop again or complete and let later work run. NativeContinuationOutputPrefix supplies the ordered sibling proof at those exact native inputs.

The receipt proof handles all receipt tags. A completed native receipt invokes both hooks at the same fragment, reached caller, saved queries, and returned cache. Other tags do not invoke a hook and keep the same observed output list.

The selected proof unfolds the actual run once and generalizes the one hook-free SelectedPreparation.run observation shared by both calls. It uses the actual terminal gate and prepared value constructor. The ordinary node arm calls the installed native prefix theorem. Terminal and opaque arms call the single-receipt prefix theorem. Failed, absent, malformed, and error observations are covered with the identical empty observation. No successful-row premise is imposed, and no claim about changing native fuel follows from these fixed-fuel cases.

## Limits

The conclusion preserves ordered output payloads as a list prefix. It does not identify stopped reasons or stopped aggregate endpoints. It does not assert existence of a complete run, existence of any output, coverage of an original model, or Discharged rendering. The hook premises are the requested local composition conditions. The separate recursive-depth consumer must derive them from its induction and complete-depth stability theorem.

The depth owner received the exact signature and immutable candidate hash. Its announced call order matches this candidate.

## Scope and evidence

The manifest preserves exact whole dependency snapshots and precise read scopes. The selected run source is byte-identical to its prior whole-read snapshot. The current receipt source and installed native prefix helper were read whole. HookInvocation lines 1 through 35 contain both existing output observers. The candidate was read whole after writing and sealed read-only.

No repository file or prior sealed evidence was edited. No compiler, native proof evaluation, Git, network, or board call was made. No Haskell file changed and no new Haskell finding was established.
