# Prepared recursive output prefix candidate

Status: UNTESTED by this child. Root owns compilation and repository changes.

The one candidate module exports three additive theorems in
`MicroCFTA.SourcePruningEnumerationPreparedRecursive`:

- `continueWith_outputs_prefix` preserves pointwise recursive output prefixes through the same actual `recordTypes` callback observation.
- `resume_outputs_moreDepth` preserves the actual output list as a `List.IsPrefix` when only recursive depth increases.
- `run_outputs_moreDepth` lifts that result through the actual initial restart decision.

The depth statements keep every original argument fixed. This includes `workFuel`, graph, templates, native/child functions, selected edges, metadata, caller, full query memos, enumeration cache, stop policy, and selection order. The only new comparison premise is `recursiveFuel <= larger`. The resume theorem also keeps the supplied next decision fixed. Both complete and stopped results use the actual `HookInvocation.hookOutputs` observer. Equality of output objects preserves every output field.

## Proof route

The induction follows the checked `PreparedRecursiveDepth` proof and the actual action-priority cases in `PreparedRecursive.resume`.

1. At zero recursive depth, a selected expansion emits an empty list. That list is a prefix of every later output list. Non-expansion results are unchanged.
2. A stopped prefix, rejected callback, unsupported branch, or failed preparation emits the same list at both depths.
3. An actual parked restart applies the depth induction hypothesis to its exact updated metadata, framed cache, and next decision.
4. An actual ordinary continuation supplies two callback facts. Existing `resume_complete_moreDepth` and `continueWith_complete_congr` preserve the exact complete callback outputs and endpoint. The induction hypothesis and `continueWith_outputs_prefix` preserve all callback output prefixes, including stopped callbacks.
5. The peer `SelectedContinuations.run_outputs_prefix` composes those facts through the actual prepared scan. Its observer is the literal optional-fold `map foldOutputs |>.getD []`. Cases on both observed options and folds identify that observer with the output list of the actual `finish` or empty preparation stop.

No state, Packet, Ready, model, resource, arity, future heap, future endpoint, source/prepared identity, or output-existence premise is added to either depth theorem. The callback helper has its stated pointwise prefix premise. The depth proof discharges that premise by induction.

## Scope

This is ordered output preservation at fixed work fuel. A larger depth can extend an earlier stopped output list and visit later siblings. This module does not prove output existence, accepted-term coverage, eventual completion, global depth bounds, or monotonicity in work fuel. It does not change or establish correspondence with Haskell.

## Read and preservation record

`evidence-v1/manifest.json` binds seven whole installed source files (65,954 bytes; 1,003 lines), the whole candidate readback, and two literal standard-library cuts from the current Lean 4.34.1 toolchain. Whole source copies are retained. `dependency-read-v1.json` binds the whole peer selected-prefix candidate and confirms the exact consumer interface. The first manifest records the dependency as pending at creation; the dependency sidecar resolves that read/interface item without changing the first manifest.

No compiler, native execution, Git, repository write, network, board, compiler limit, linter suppression, custom axiom, admitted proof, or earlier-area mutation was used. Candidate and evidence bytes are frozen after this report. Root may repair installed code after compilation; those changes must not overwrite this candidate.
