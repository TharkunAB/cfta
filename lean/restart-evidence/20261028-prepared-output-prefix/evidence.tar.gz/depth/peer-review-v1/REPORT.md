# Native and selected output-prefix peer review

Result: PASS. No concrete correction is required.

Root reported a default build PASS for the unchanged candidates. This review is read-only and did not run a compiler. Root owns the pending strict checks.

## Exact declarations and gates

- `NativeContinuations.run_outputs_prefix` proves an ordered `List.IsPrefix` between the actual complete-or-stopped scan output lists. It keeps every native scan input fixed. Its `same` premise quantifies over all actual hook inputs and requires exact outputs, caller, and full query memos whenever the first hook completes. Its `prefixHooks` premise quantifies over all hook inputs and retains hook output prefixes for either result tag.
- `ReceiptContinuation.run_outputs_prefix` proves the same ordered observation through one fixed actual optional receipt. It retains both global hook premises. It adds no state or native equality premise.
- `SelectedContinuations.run_outputs_prefix` proves the literal optional-fold observation `((run ...).2.map foldOutputs).getD []` is an ordered prefix. It keeps entry, native and branch fuels, selection function, caller, query memos, and cache fixed. It retains both global hook premises.

These are conditional hook-composition statements. They do not assert that arbitrary replacement hooks satisfy the premises. The prepared depth consumer supplies complete-result agreement from the existing exact completed-depth theorem and supplies hook-prefix preservation by induction.

## Actual execution and synchronization

The native proof preserves output order through the same left-to-right source list. At an earlier completed hook, `same` supplies the exact next caller and query memos. Both scans then evaluate the suffix at identical native inputs. The captured enumeration cache remains fixed. The induction generalizes the caller and query memos rather than substituting the original caller for a reached caller.

At an earlier stopped hook, the old scan has no evaluated suffix. If the new hook also stops, `prefixHooks` is the required prefix directly. If it completes, the new head contains the old outputs as a prefix and its actual suffix is appended. `prefix_append_of_prefix` preserves that prefix. No future endpoint equality is required in this branch. Rejected and advanceable stopped edge receipts transport the exact same actual `advance` endpoint in both scans.

The selected preparation is independent of the hook. A missing native result, native failure, or malformed raw entry yields `none`, whose observer is `[]`. This means no observed outputs; it does not mean successful preparation. A successful terminal entry uses the actual opaque receipt continuation. A successful nonterminal ordinary node uses the actual native sibling scan. Other native value tags use the actual opaque receipt continuation. All successful preparation paths retain the actual advanced caller and framed enumeration core.

## Types and scope

All three statements keep independent `Output : Type u` and `Reason : Type v`. They require no equality decision for either type. A prefix preserves each exact output object, including duplicates and order. The conclusion does not equate processed receipts, stop reasons, or final endpoints of arbitrary stopped scans.

No Packet, Ready, model, arity, future heap, future caller, source/prepared identity, output-existence, accepted-term coverage, global termination, or Haskell correspondence premise or conclusion is introduced. The two hook premises are explicit and match the actual synchronization needed by the scan proof.

## Preserved read scope

`manifest.json` binds seven whole installed files and three literal source cuts. The cuts cover actual native receipt advancement and the two standard ordered-prefix append lemmas. Every whole file and cut is copied under this directory. The selected-prefix installed file is identical to peer candidate SHA256 `c0e689d29bb754af2b97a4942c434d1ed04770c47fa63fe247141cf101e1a883`.

No compiler, native execution, Git, repository edit, network, board, or earlier sealed-area mutation was used. This review is frozen.
