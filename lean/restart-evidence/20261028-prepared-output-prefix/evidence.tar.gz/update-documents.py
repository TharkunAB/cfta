"""Prepend the current verified result and retain every previous document byte."""
from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path('/home/tritlo/Code/mcfta')
AREA = Path('/tmp/mcfta-prepared-output-prefix-20261028')
now = datetime.datetime.now().astimezone().strftime('%Y-%m-%d %H:%M %Z')
records = json.loads((AREA / 'prior-documents.json').read_text())
for record in records:
    path = ROOT / record['path']
    old = (AREA / 'prior-document-bodies' / record['path']).read_bytes()
    assert path.read_bytes() == old
    prefix = f'''# Verified prepared output-prefix update: {now}

Current proof: `4fcfb5d6a514ec9aa4b94d453085f8e06b4a6cc1` on `formalize`.
Read `lean/notes-current-prepared-output-prefix.md` from the repository root.
All earlier document bytes follow this update unchanged.

At fixed work fuel and original inputs, increasing recursive depth preserves
every earlier full output record in order, including stopped-run outputs.
For two originally admitted resource depths, the producer derives stable actual
results at their own work bounds and proves the same exact prefix relation.
Both reservations remain explicit. Neither theorem proves an output exists.
Conditional original rendered soundness and intended partial outputs remain.

Four new modules add eight public theorems and no definitions. All ten compiler
commands pass. Five final strict sources pass. Audit: 4,513 jobs and 81,615
dependencies. Public readback: 695 theorems, 60 definitions, 3,080,208 bytes.
The prior 3,052,362 bytes remain an exact prefix. All 4,508 prior non-Audit Lean,
357 stronger and 817 Haskell/Cabal sources retain their hashes.

Largest gap: actual model-preserving output emission and one original finite
depth for every earlier ordered allocating callback and the continuation.
Selector/policy/projectability lineage, public adapters and physical optimized
Haskell correspondence remain open. DONE does not imply Discharged.
No Haskell source changed, no Haskell check ran, and no new Haskell defect or fix
was established. Earlier external repair records remain intact in FINDINGS.md.

Complete evidence: `lean/restart-evidence/20261028-prepared-output-prefix/`.
Board sequence 704 was read back with exact content and metadata.
Keep the full goal active. Normal pushes to the authorized formalize branch
remain authorized. Preserve all proofs, counterexamples, repairs and drafts.
Continue in a new writable area. Do not edit frozen or reconstructed evidence.

'''
    path.write_bytes(prefix.encode() + old)
paths = [record['path'] for record in records] + ['lean/notes-current-prepared-output-prefix.md']
final = []
for relative in paths:
    data = (ROOT / relative).read_bytes()
    final.append(dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    target = AREA / 'final-document-bodies' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
for record in records:
    assert (ROOT / record['path']).read_bytes().endswith(
        (AREA / 'prior-document-bodies' / record['path']).read_bytes())
(AREA / 'final-documents.json').write_text(json.dumps(final, indent=2) + '\n')
print(json.dumps(dict(prior_exact_suffixes=len(records), final_documents=len(final))))
