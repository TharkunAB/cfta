import json,os,subprocess,sys
from pathlib import Path
area=Path('/tmp/mcfta-prepared-output-prefix-20261028')
for number,module in enumerate(json.loads((area/'modules.json').read_text()),1):
 command=['/home/tritlo/Code/heavy-management/bin/capped','--mem','4G','--time','5m',sys.executable,str(area/'check-installed.py'),'strict',f'strict-first-{number}',module]
 result=subprocess.run(command,env=os.environ.copy())
 if result.returncode:raise SystemExit(result.returncode)
