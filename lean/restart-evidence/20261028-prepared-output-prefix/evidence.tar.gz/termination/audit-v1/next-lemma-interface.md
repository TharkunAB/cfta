Proposed next local interface; unproved

Use the existing actual prepared CompletedHeadReceipt. Its admission retains the original stored slot handle and bucket, plus separate parentAvailable/parentClosed for the prepared ordinary parent. Its running field is an actual CapturedEdge.run observation at every larger common work bound. All old fields must remain available.

The suggested theorem is a point preservation statement with all original receipt indices implicit:

  namespace MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources

  theorem CompletedHeadReceipt.fresh_pending_ancestry
      (receipt : CompletedHeadReceipt seed inherited formulas solver inventory
        caller memos metadata before checkEmpty uv handle scs parentEntry
        storedEdges depth free edge bound fragment reached saved after
        returnedInventory returnedMemos)
      (slot : Nat)
      (fresh : before.core.counter <= slot)
      (inside : slot < after.core.counter)
      (pending : exists nativeHandle bucket,
        after.core.values[slot]? =
          some (.unenumerated (some nativeHandle) bucket)) :
      forall key, key in before.core.expansionAncestry ->
        key in after.core.recursionAncestry slot

The ASCII text above specifies the indexed mathematical interface. It is not a Lean candidate and has not been elaborated. In a Lean declaration use the normal forall/exists/membership/Nat-order notation and the original local aliases/instances.

Why this statement is useful:

- It connects the original selected expansion ancestry to actual newly allocated pending outputs of one completed head.
- It includes earlier child allocations, even when a later child uses an old equality class.
- It does not add a model, a desired language equivalence, a final Heap supplied from the future or future completion to the original producer admission.
- It is conditional only on the actual completed receipt already yielded by the existing finite producer. A producer wrapper would preserve its full old existential/result tuple and append this certificate in the actual completed branch. It would not assume such a completion for all branches.
- It does not identify the original source handle with the prepared parent.

Proof dependencies to inspect/compose:

1. EnumerationState.allocate/allocated: new slot copies expansion ancestry into its per-slot recursion ancestry.
2. SourcePruningEnumerationShallowChild.prepareChild and its actual completion: the pending native allocation uses that operation.
3. Own-class allocation in the actual selected-edge preparation: preserve the same inherited expansion ancestry.
4. Terminal prefix/fold and IncomingNode.finish: preserve existing per-slot ancestry; incoming target inherits the expansion ancestry.
5. Actual assimilation: union target/source per-slot ancestry without loss at the live representative.
6. CapturedEdge and Finalize.run: finalization clears expansion ancestry but retains per-slot ancestry of fresh pending slots.

The original native caller may grow during these operations. The theorem must follow the actual prepared/native receipt and keep its full Packet/Post/memo state. There is no need to infer an original-source native-node identity from the prepared ordinary parent.

Limits:

This proposed certificate alone does not decrease a rank. It does not handle every already-existing pending target as a numerical frontier step. Extending it to actual reactivated old representatives requires following class assimilation and the precise changed pending slot. An original finite key or inventory universe still needs a source-grounded proof through native terminal merge and own-trie normalization. Native query completion for a chosen finite input and reservations indexed by recursion depth do not supply that global proof.

A numerical route must additionally derive the canonical inherited equivalence relation and positive-position backward map needed by SourceCurrentPositiveQuotientCount.child_count for the ACTUAL terminal merge/prepared child. Those relations must be constructed from the input checked source and producer history. They cannot be new assumptions that encode the desired future rank decrease.
