Bounded callback termination audit

Snapshot: 2026-10-28 19:32:43 CET. This is a read-only route audit. No compiler, native replay, Git, network, board or repository write was used. The evidence directory is new. Prior evidence remains unchanged.

Result

The inspected statements do not yet give one original well-founded measure for every prepared recursive callback. The suggested rule “the counter increases, or the same-counter candidate count decreases” needs a new proof and has a concrete source-grounded test case against it. A direct ordinary-height measure also needs a native-merge preservation theorem. Neither test case below is a checked full Context/Trace counterexample. Neither establishes a Haskell defect.

Closed Mu unfolding already has a useful strict progress theorem. The missing step is broader: prove an original budget or source-ranked frontier is preserved through the actual terminal native merges, equality-class allocations and later prepared callbacks. A reservation that grows with the requested recursion depth cannot supply that original budget.

Strongest existing local facts

- SourcePruningEnumerationParkedProgress.selected_complete_with_parking_progress proves same-counter strict candidate loss for an actual repeated-key park. This applies to its parked step. It does not cover a completed allocating head or all later callbacks.
- MergedOrdinaryHeight.child_lt, ordinaryUnion_bound and column_union_lt bound the indicated ordinary child or column constructions. The height function assigns zero to Union and Mu. These statements do not bound a native intersection that exposes an ordinary branch from a Union, or preparation that unfolds a Mu.
- SourcePruningEnumerationBucketSumBounds.child_bucket_le gives child bucket length at most inherited bucket length plus the fresh own-trie count. children_bucket_sum_le gives the corresponding sum bound. Neither is strict descent.
- SourcePruningEnumerationIncomingMass.observed_cache_bounds gives exact incoming suspended-mass addition while the counter is unchanged. Thus suspended bucket length alone is not a global decreasing measure.
- InternedStoredPlanBinderDepthProgress.unfold_new_lower applies to an available CLOSED value in the original stored-substitution context. New Mu records have strictly lower body depth; earlier records may remain. The exact cut is preserved. The open-Mu-only FreshOrdinaryUnfoldRank and StoredUnfoldingRank results are insufficient for selected closed values, but this closed result avoids that problem.
- MergedFreshOrdinaryColdTermination.collect_complete combines the actual issued-Mu inventory count vector with pending-work weight. Its nodeEdges_complete derives the initial degree bound from the original actual issued inventory. This proves finite work for that actual closed cold collection, including its lower-degree Mu allocations. It does not state that arbitrary later terminal native intersections preserve the same original inventory budget.
- SourceCurrentActualChildRank.dispatch proves strict lexicographic native child descent using positive-position quotient count and value mass under its actual source/causal support, room, normalization, memo and origin gates. SourceCurrentPositiveQuotientCount.child_count needs the canonical inherited relation and actual positive-position backward relation. These are native pruning dispatch results. No inspected statement identifies an arbitrary enumeration suspended bucket with that canonical inherited representation.
- EnumerationTermination.enumerateFully_complete uses the term-height histogram of a satisfying assignment, BoundedWork and CompleteGraph. It obtains a model-preserving expansion. It does not prove termination of every earlier allocating native callback in the prepared worker. CapturedEdgeProgress and CallbackProgress likewise use their original model/properness gates. Their legacy worker types are not the prepared worker types.

Actual operational details that the measure must preserve

EdgeInputs.children appends descended fresh own tries to descended inherited buckets. Fresh own constraints can replace the path mass removed from the inherited part. The actual child bound counts both sources.

An empty-bucket Mu or Union is not a native candidate. A nonterminal ShallowChild allocation stores the descended bucket only for an ordinary node. A fresh nonterminal Mu or Union stays at an empty bucket. This is the partial-output boundary. A selected nonempty boundary can instead arise when terminal/incoming processing writes into an existing equality slot.

The repeat key contains the native handle and the canonical path-trie shapes. It omits suspended equality variable IDs. Fresh equality IDs therefore do not by themselves avoid a repeated key. Entry records boundary keys in expansion ancestry. Allocation inherits expansion ancestry. IncomingNode.finish inherits it into the target, and assimilation transfers class ancestry. Finalize clears expansion ancestry and replaces the captured raw slot; it does not itself erase the per-slot recursion ancestry.

These facts support a lineage argument. They do not yet prove a finite ORIGINAL set of native handles and path-shape keys across arbitrary later native intersections. Such finiteness must be proved from the original admitted checked source and actual native producer history. It must not be added as a future-completion certificate.

Test cases and replay limits

The separate test-cases.md records two focused inputs. The first replaces one ordinary parent candidate by two ordinary child candidates at existing equality slots, with no fresh allocation. A term-height multiset could still decrease in that example. The second asks whether a terminal native intersection can expose an ordinary D from mixed Mu/Union inputs whose raw ordinary height is zero. A structural maximum over Union members can account for that second issue, while Mu needs its closed-unfold and merge treatment.

The second input has an additional important replay gate: actual selection/preparation or pruning may simplify the mixed inputs before the proposed terminal merge. The test is not a claim that the raw parent survives those operations. An exact replay must determine that fact and the actual resulting native caller.

Recommended next bounded statement

The exact proposed local preservation interface is in next-lemma-interface.md. It attaches fresh pending-slot recursion-ancestry retention to the existing actual PreparedNativeHookResources.CompletedHeadReceipt. It keeps the original stored source handle separate from the prepared ordinary parent. It consumes the original receipt, not a new model or a future output oracle.

This is a necessary preservation step for the lineage route, not a sufficient termination measure. The larger next obligation is to derive a source-ranked frontier/backward-positive relation through actual terminal native merges. That obligation must cover newly created Mu and normalized own equality classes. The existing local Native child rank cannot be imported by a source/prepared cast or by assuming the desired relation.

No candidate Lean file is included. The required composition spans fresh allocation, terminal prefix/fold, incoming writes, class assimilation and captured finalization. A direct small proof was not established in this bounded audit. The proposed local interface is explicitly unproved.

Read scope and identities

source-manifest.json records every source identity, full byte count, SHA256 and exact read scope. Whole-read inputs are copied under sources/. Literal cuts are copied under cuts/. Truncated exploratory reads have no whole-file review claim. PruneTerminationGrowth is historical and is not used as evidence of a defect in the current runtime. RecursiveCallbackTermination concerns recipe/rank-query callbacks; its name is not evidence of enumeration callback termination.
