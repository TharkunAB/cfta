# Open internal fixed-original-D induction

This is a specification for missing proof work. It is not a Lean declaration or a proved admission rule.

Fix the original configuration, primitive workFuel D, common cap B, original seed/profile, and original resource conditions.
Use the actual worker expression with recursiveFuel k.
Do not replace D by k, a current node height, or a new state-dependent forecast.
Generalize the actual reached metadata, Caller, query state, cache, and next decision inside the induction on k.

## Required induction result

For every internally derived current state at recursive fuel k:

1. Evaluate the literal Native or Prepared resume with workFuel D and recursiveFuel k.
2. For each complete endpoint, derive the actual Caller/query endpoint effects.
   When the current context admits the actual operations, derive the corresponding Post and reached Context.
   Preserve the physical lookups and availability needed by any old captured cache.
   Derive the actual memo identity, current Fits, annotations, and remaining reservation facts.
3. Derive Known at each actual output cache's own recorded Caller.
   Keep each output metadata field and Caller/query field aligned with its literal record.
4. For each stopped result with an exposed endpoint, derive that endpoint's physical facts under the actual current admissions.
   Leave an unsupported endpoint case explicit until its producer is proved.
   Do not infer a hidden endpoint or its Context from none.
5. Derive the successor current-state admission and every next primitive budget requirement from the original conditions and actual history.
   Do not accept a future per-step function, final Post, Trace, or universal returned-cache certificate as the public input.

The original current-state family needed for items 2–5 is still missing.
It must be defined and produced from original input conditions.
Giving it an arbitrary public predicate name would not close this obligation.

## Exact sibling consumer

At NativeContinuations.run44–72, let beforeCaptured be the cache captured when the head list starts.
Let metadataCaptured be the metadata captured by the source hook closure.
The actual head produces fragment, reached, saved, and candidateAfter.
The actual hook is continueWith (resume ... D k) ... D metadataCaptured target.
It runs on candidateAfter at reached/saved.
On complete outputs middleCaller middleQueries, the next sibling uses:

    SAME beforeCaptured
    SAME metadataCaptured in the hook closure
    ACTUAL middleCaller
    ACTUAL middleQueries

The needed IH application begins at candidateAfter, after the actual recordTypes callback.
Its resulting physical retention must also cover beforeCaptured.
Packet.captured_post can then restore the captured Packet.
The actual old-cache Known law needs the same physical transport.
The original selected children must remain Available and closed at the actual middle heap.
Current head domain, grade, slot, constraint, and reservation admissions must still be derived there.

## Callback step

Use actual recordTypes output and RecursiveCallback.callback_complete.
The false singleton branch produces updated metadata, Frame, and a framed cache.
The IH at k starts from that produced cache and metadata with the SAME Caller/query pair.
The true singleton branch returns no outputs and the current Caller/query pair.
Other callback observations stop with the current exposed endpoint.
The callback producer has a local sufficient fuel.
Show its requirement is met by fixed D from the original resource lineage.
Do not reset primitive workFuel at this point.

## Prepared additional step

First derive the actual preparation heap transition.
On done, use the actual SelectedValueCaller.advance and produced entered cache.
Retain the terminal and Mu/Union/opaque fallback branches.
On absent continuation, the outer endpoint is none.
Treat any heap retained inside the raw MergedSourceComparison result as a separate inner state.
Do not substitute the pre-preparation Caller or fabricate an outer endpoint.

## Missing proof boundary

Current local producer laws give sufficient bounds for one current prefix or callback.
Current completed-query history laws consume a supplied completed-query history.
Current output-prefix laws compare actual results at fixed workFuel.
They do not derive this whole-worker invariant or a single original sufficient D.
No whole-worker theorem is drafted in this bundle.
