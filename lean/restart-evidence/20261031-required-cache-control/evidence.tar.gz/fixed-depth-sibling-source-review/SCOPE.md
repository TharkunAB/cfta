SOURCE-ONLY fixed-original-D captured-sibling task. Before acquisition named exactly two OLD whole ORIGINAL worker paths:
/home/tritlo/Code/mcfta/lean/MicroCFTA/SourcePruningEnumerationRecursive.lean
/home/tritlo/Code/mcfta/lean/MicroCFTA/SourcePruningEnumerationPreparedRecursive.lean
All other source uses named bounded runtime/header cuts and cumulative ORIGINAL-path vectors. No compiler/evaluator/native/Haskell/Git/network/board/production/spawn. Keep workFuel D fixed through recursive-fuel k induction. No public future callback or per-step invariant supplier may stand in for the original-D theorem. Any candidate remains UNCOMPILED. Both workers/generic/default-Haskell/original-resource/public full goal stays open.
