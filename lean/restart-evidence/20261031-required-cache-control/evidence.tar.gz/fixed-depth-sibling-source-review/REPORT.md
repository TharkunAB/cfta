# Fixed original-D captured-sibling review

## Result

The exact remaining worker induction is identified. No new Lean theorem is supplied or claimed.
The source has the required fixed-fuel recursive calls. It does not yet provide their full physical and current-state certificate.
This review does not prove that the desired certificate is false.

## Actual worker transition

Both workers pass the original workFuel D unchanged to every recursive call.
Only recursiveFuel k decreases.
They use D for the selected prefix, callback, and head budgets.
The initial call with both fuels D is a later specialization of that induction.
A common ordinary height cap B is a separate structural bound.
It does not supply any primitive work budget.

The actual head continuation is in NativeContinuations.run44–72.
A completed head calls the hook on its actual candidate after cache and reached Caller/query pair.
After the hook completes, the next sibling uses the SAME captured before cache and SAME hook closure metadata.
It uses the hook's actual middleCaller and middleQueries.
It does not use an output cache or the pre-hook Caller as a substitute.
Each output retains its own metadata, cache, Caller, and query fields.
The producer must certify each recorded output at its own Caller.

Packet.captured_post43–48 is an existing exact local restoration law.
It preserves the captured cache and metadata from a current Packet and an actual Post.
Its input Post is a premise. It does not derive that Post from either recursive worker.
Known for a returned cache alone does not prove CacheValid or Known for the old captured cache at middleCaller.

## Exact missing producer

NEXT-CONTRACT.md states the internal induction obligation and the consumer application.
The recursive IH must produce the actual endpoint effects for resume D k.
It must also produce the current admissions needed by the next head.
It must preserve the original profile and reservation lineage.
It must derive every fixed-D primitive budget requirement from original conditions and actual transitions.
It must not obtain a fresh workFuel from a per-state existence theorem.

The current callback producer is concrete and useful.
RecursiveCallback.callback_complete29–45 derives Frame, RenderStable, the new Packet, and exact metadata updates from the current Packet and FragmentBound.
It derives a local sufficient callback fuel.
RecursiveCallbackCanonical and RecursiveCallbackLanguage add canonical and semantic conclusions at that sufficient fuel.
They do not show that the already fixed D is large enough at every reached callback.

RecursivePrefix.packet_prefix_complete64–71 derives a local bound for the actual selected prefix from the current Packet.
Prepared SelectedPreparationResources.complete_resources28–67 derives the actual done heap, current Packet, Post, availability, closedness, and normalized profile at a local sufficient bound.
SelectedContinuations.complete_resources137–193 gives the exact subsequent continuation expression for any hook.
Its hook quantifier is an expression identity. It does not certify that hook's effects.
None of these statements closes the original-D induction by itself.

## Prepared and failure boundaries

PreparedRecursive.resume retains workFuel D when it recurses with smaller k.
SelectedContinuations.run36–63 first executes actual preparation.
On a done result it advances the outer Caller to the returned heap with SelectedValueCaller.advance27–29.
It dispatches ordinary nonterminal nodes to NativeContinuations.
It sends terminal or other value cases to SelectedOpaqueDispatch and ReceiptContinuation.
This fallback remains part of the worker.

If preparation does not produce the required continuation result, PreparedRecursive returns a stopped preparation failure with endpoint none.
Its raw preparation observation still contains the actual merged native result.
No exposed final Caller follows from that none.
The heap inside that raw result must be treated separately from the outer endpoint option.
NativeRecursive instead returns the reached Caller/query pair for its ordinary failure case.
A stopped result with an exposed endpoint needs an actual endpoint certificate.
A stopped result without an endpoint gives no hidden Caller preservation fact.

RecursiveResources.QueryHistory54–68 records completed native query steps only.
The worker does not supply that history in its result.
That datatype does not by itself cover yielded or failed queries, preparation heaps, callbacks, or complete sibling iteration.
RecursiveReservation33–58 describes head and callback reservations at changed profiles.
It does not derive an original whole-worker history or all future reservations.

## Existing depth laws

PreparedRecursiveDepth.resume_complete_moreDepth70–83 keeps workFuel fixed and preserves an observed complete result exactly.
PreparedRecursiveOutputPrefix.resume_outputs_moreDepth73–87 also keeps workFuel fixed and proves List.IsPrefix for actual output lists.
These are useful operational stability laws.
They do not derive worker Post, captured-cache admissions, initial resource sufficiency, or termination.
They are not the separate exact bounded reference Prefix contract.

## Retained full scope

The previous 101-line original-child incoming-input candidate and its complete 60-file owner are unchanged.
Its copied NEXT-CONTRACT is the input obligation for this review.
This review acquires no new proof candidate and performs no compiler, evaluator, native, Haskell, Git, network, board, or production operation.
Both workers, generic Mu/Union/opaque cases, terminal and alias paths, original resources, and public ordered outputs remain in the full goal.
The fixed interned getter remains distinct from default and weighted Haskell getter correspondence.
No Haskell defect, edit, or fix is established.

## Provenance and limitations

All 248 lines of the two named OLD whole workers were read.
All retained bounded cuts and locators were read in full as copied.
There are 41 source acquisitions from 21 original paths and 840 unique semantic source lines.
Exactly two original paths are whole acquisitions. Every other original-path union is below half of its source.
The full source hashes, copy hashes, exact line vectors, unions, and metadata pins are retained.
Source hashing and offline metadata replay do not execute the modeled program.
The prior complete provider remains frozen in its original owner and is already retained whole by Root.
This bundle retains that provider's exact manifest, pins, and consulted NEXT-CONTRACT.
No source acquisition or helper failure occurred in this bounded task.
