from pathlib import Path
import hashlib
import json
import re
import shlex
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
work = base / '20261117-authentic-auxiliary-key-recovery-work'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this candidate into the active Work directory'
prior_run = base / '20261117-next-warm-query-publication'
prior_archive = base / '20261117-next-warm-query-checkpoint'
runtime = base / '20261117-authentic-auxiliary-key-publication'
prior_commit = '4b28f2f1e19751f4c6116fe0cc04a2fce70d6e74'
sha = lambda data: hashlib.sha256(data).hexdigest()
audit_name = 'lean/MicroCFTA/Audit.lean'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
module = 'SourceCurrentNativeAuxiliaryBaseKeyRecovery'
source_name = 'lean/MicroCFTA/' + module + '.lean'
source_sha = 'ee0c04dc54667b6b55698e3774e1955c61cd5660f79b6f1a2d37adb06b17eff9'
public_names = ['auxiliary_key_eq_recovers_singleton_base',
    'source_parent_pair_avoids_auxiliary', 'source_auxiliary_key_eq_recovers_full_pattern']
private_names = ['pair_fixed_owner_injective', 'ordinary_reference']
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage = json.loads(stage_path.read_text())
assert stage['prior_checkpoint'] == prior_commit
assert stage['new_module'] == module and stage['source_path'] == source_name
assert stage['raw_sha256'] == source_sha and stage['raw_bytes'] == 12329
assert stage['selected_packet'] == '20261117-authentic-auxiliary-key-unnecessary-simpa-repair'
assert stage['selected_manifest_sha256'] == '8703cbde2232455aaf47d477c4758ae900d00cc94b3772a3265b07ba4ecdf249'
assert stage['names'] == ['MicroCFTA.' + module + '.' + name for name in public_names]
assert stage['private_helper_names'] == private_names
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6252, 5252, 679, 274)
assert (stage['new_modules'], stage['new_public_theorems'], stage['new_private_helpers'], stage['new_private_predicates']) == (1, 3, 2, 0)
assert stage['new_theorem_declarations'] == 5 and stage['fresh_explicit_axiom_reports'] == 3
assert stage['private_helpers_covered_transitively']
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (3, 470, 473)
assert stage['old_non_audit_source_files_byte_exact'] == 6250
assert stage['old_audit_bytes'] == 424863 and stage['old_audit_exact_offset'] == 61
assert stage['old_audit_contiguous_bytes_preserved']
assert stage['audit_new_import_bytes'] == 61 and stage['new_ordinary_audit_imports'] == 1
assert stage['first_failed_linter_check_and_exact_header_repair_preserved']
assert stage['all_old_proof_bodies_and_limits_unchanged']
assert stage['actual_source_auxiliary_key_full_pattern_recovery_proved']
for name in ['warm_query_no_new_mu_proved', 'every_warm_worker_call_qualification_proved',
             'joint_finite_completion_proved', 'haskell_changed']:
    assert not stage[name], name
prior = json.loads((prior_run / 'checked.json').read_text())
assert len(prior['checks']) == 5 and all(c['exit'] == 0 and not c['nonstandard_axioms']
    and not c['diagnostics'] and not c['sorryAx'] for c in prior['checks'])
assert (prior['source_files'], prior['independent_reports'], prior['resource_and_component_probes']) == (6251, 271, 470)
assert prior['owner_resource_probes'] == 264
assert prior['whole_worker_program_slots_proved'] and prior['whole_worker_roles_proved']
baseline = json.loads((work / 'baseline-source-pins.json').read_text())
assert len(baseline) == 6251 and source_name not in baseline
assert {str(p.relative_to(root)) for p in (root / 'lean/MicroCFTA').glob('*.lean')} == set(baseline) | {source_name}
old_audit = (work / 'Audit-BEFORE.lean.txt').read_bytes()
assert len(old_audit) == stage['old_audit_bytes']
assert sha(old_audit) == stage['old_audit_sha256']
assert old_audit.count(b'#print axioms ') == 676
for name, digest in baseline.items():
    data = old_audit if name == audit_name else (root / name).read_bytes()
    assert sha(data) == digest, name
assert len(set(baseline) - {audit_name}) == 6250
assert sha((root / owner_name).read_bytes()) == owner_sha
packet = base / '20261117-authentic-auxiliary-key-unnecessary-simpa-repair'
normal = (root / source_name).read_bytes()
assert normal == (packet / (module + '.lean')).read_bytes() and sha(normal) == source_sha
assert sha((packet / 'MANIFEST.sha256').read_bytes()) == stage['selected_manifest_sha256']
assert re.findall(r'^private theorem ([A-Za-z0-9_]+)', normal.decode(), re.M) == private_names
assert re.findall(r'^theorem ([A-Za-z0-9_]+)', normal.decode(), re.M) == public_names
assert not re.findall(r'^private def ', normal.decode(), re.M)
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
qnames = ['MicroCFTA.' + module + '.' + name for name in public_names]
assert public == ''.join('#check ' + q + '\n#print axioms ' + q + '\n' for q in qnames).encode()
new_import = (work / 'IMPORTS.lean.txt').read_bytes()
assert new_import == ('import MicroCFTA.' + module + '\n').encode() and len(new_import) == 61
audit = (root / audit_name).read_bytes()
assert audit == new_import + old_audit + b'\n' + public
assert audit[len(new_import):len(new_import) + len(old_audit)] == old_audit
assert sum(line.startswith(b'import ') for line in audit.splitlines()) == 5252
assert audit.count(b'#print axioms ') == 679
header_paths = [packet / name for name in ['PURE-FIRST-HEADER.lean.txt',
    'SOURCE-GUARD-FIRST-HEADER.lean.txt', 'SOURCE-RECOVERY-FIRST-HEADER.lean.txt']]
for header_path in header_paths:
    header = header_path.read_text()
    declaration = header.split('\n')[0]
    text = normal.decode()
    start = text.index(declaration)
    assert text[start:text.index(' := by', start)].rstrip() == header.rstrip()
verified_path = work / 'REPAIR-CHECK-VERIFIED.json'
verified = json.loads(verified_path.read_text())
assert verified['actual_terminal'] and verified['actual_terminal_exit'] == 0
assert verified['actual_session'] == 37074 and verified['original_first_headers_byte_exact']
assert verified['first_failed_check_and_one_line_repair_preserved']
assert (verified['new_public_reports'], verified['new_public_theorems'], verified['new_private_helpers']) == (3, 3, 2)
normal_check = base / stage['private_run']
assert verified['run'] == stage['private_run']
assert stage['private_receipt'] == 'REPAIR-CHECK-VERIFIED.json'
checked = json.loads((normal_check / 'checked.json').read_text())
assert checked['normal_module_checked'] and all(checked['passed']) and checked['source_pins_unchanged']
assert verified['checks'] == checked['checks']
assert checked['checks'][1]['total_axiom_reports'] == 3
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx'] for c in checked['checks'])
checked_source = normal_check / 'source/MicroCFTA' / (module + '.lean')
assert checked_source.read_bytes().startswith(normal)
assert json.loads((normal_check / 'selection.json').read_text())['sha256'] == source_sha
checked_inputs = [normal_check / name for name in ['checked.json', 'selection.json', 'normal-module.txt', 'source-pins.json']]
checked_inputs += [checked_source, verified_path]

# Validation above is read-only. Only Root may create the publication run.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-auxiliary-key-publication-'))
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
(runtime / 'PUBLIC-PROBES.lean.txt').write_bytes(public)
probes = ''.join('#check @MicroCFTA.' + module + '.' + name + '\n#print axioms MicroCFTA.'
                 + module + '.' + name + '\n' for name in public_names)
assert probes.count('#print axioms ') == 3
strict_source = runtime / 'source/MicroCFTA' / (module + '.lean')
strict_source.parent.mkdir(parents=True, exist_ok=True)
strict_source.write_bytes(normal + b'\n' + probes.encode())
(runtime / (module + '-PROBES.lean.txt')).write_text(probes)
commands = [['lake', 'env', 'lean', '-j1', '-DwarningAsError=true', '-R',
    str(strict_source.parent.parent), '-o', str(objects / (module + '.olean')), str(strict_source)]]
independent = runtime / 'IndependentProbes.lean'
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 271 and new_import not in prior_independent
independent.write_bytes(new_import + prior_independent + b'\n' + public)
assert independent.read_bytes().count(b'#print axioms ') == 274
selection = {'prior_checkpoint': prior_commit,
    'prior_archive_manifest_sha256': sha((prior_archive / 'manifest.json').read_bytes()),
    'prior_checked_sha256': sha((prior_run / 'checked.json').read_bytes()),
    'prior_pins_sha256': sha((prior_run / 'source-pins.json').read_bytes()),
    'baseline_sha256': sha((work / 'baseline-source-pins.json').read_bytes()),
    'stage_sha256': sha(stage_path.read_bytes()), 'old_audit_sha256': sha(old_audit),
    'unchanged_resource_owner_sha256': owner_sha,
    'prior_source_files': 6251, 'prior_combined_reports': 470,
    'replaced_old_reports': 0, 'inherited_reports': 470, 'fresh_reports': 3, 'combined_reports': 473,
    'new_theorem_declarations': 5, 'new_public_theorems': 3, 'new_private_theorems': 2,
    'new_private_explicit_reports': 0, 'private_helpers_counted_as_explicit_fresh_reports': False,
    'old_normal_sources_byte_exact_except_audit': 6250,
    'old_audit_bytes_retained_contiguously_after_one_import': True,
    'old_audit_offset': len(new_import), 'new_audit_imports': 1,
    'owner_preflight_reports_fresh_this_batch': 0, 'owner_reports_inherited': 264,
    'old_toolchain_and_proof_inputs_reverified': True, 'axiom_strings_replayed': False}
(runtime / 'INHERITANCE-SELECTION.json').write_text(json.dumps(selection, indent=2) + '\n')
STRICT_BINDING_TEMPLATE = '''from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/home/tritlo/Code/mcfta')
runtime = Path(__file__).parent
prior = root / 'lean/restart-evidence/20261117-next-warm-query-publication'
archive = root / 'lean/restart-evidence/20261117-next-warm-query-checkpoint'
work = root / 'lean/restart-evidence/20261117-authentic-auxiliary-key-recovery-work'
sha = lambda data: hashlib.sha256(data).hexdigest()
selection = json.loads((runtime / 'INHERITANCE-SELECTION.json').read_text())
assert sha((archive / 'manifest.json').read_bytes()) == selection['prior_archive_manifest_sha256']
committed = subprocess.check_output(['git', 'show', selection['prior_checkpoint'] + ':'
    + str((archive / 'manifest.json').relative_to(root))], cwd=root)
assert committed == (archive / 'manifest.json').read_bytes()
subprocess.run(['python3', str(archive / 'verify.py')], check=True)
records = json.loads((archive / 'archived-inputs.json').read_text())
for name in ['checked.json', 'source-pins.json']:
    path = prior / name
    record = next(item for item in records if item['original'] == str(path))
    archived = (archive / record['archived']).read_bytes()
    if record['gzip']:
        archived = gzip.decompress(archived)
    assert archived == path.read_bytes()
assert sha((prior / 'checked.json').read_bytes()) == selection['prior_checked_sha256']
assert sha((prior / 'source-pins.json').read_bytes()) == selection['prior_pins_sha256']
assert sha((work / 'baseline-source-pins.json').read_bytes()) == selection['baseline_sha256']
assert sha((work / 'SOURCES-NORMAL-STAGING.json').read_bytes()) == selection['stage_sha256']
assert sha((work / 'Audit-BEFORE.lean.txt').read_bytes()) == selection['old_audit_sha256']
for name, digest in json.loads((prior / 'source-pins.json').read_text()).items():
    data = (work / 'Audit-BEFORE.lean.txt').read_bytes() if name == 'lean/MicroCFTA/Audit.lean' else (root / name).read_bytes()
    assert sha(data) == digest, name
assert sha((root / 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean').read_bytes()) == selection['unchanged_resource_owner_sha256']
print(json.dumps({'inherited_component_reports_verified': 470,
                  'fresh_public_reports_expected': 3,
                  'new_private_helper_declarations': 2,
                  'new_private_explicit_reports': 0,
                  'fresh_owner_preflight_reports': 0,
                  'unchanged_owner_reports_inherited': 264,
                  'old_sources_and_toolchain_byte_exact': True}), flush=True)
'''
strict = runtime / 'strict-new-and-bind.py'
strict.write_text(STRICT_BINDING_TEMPLATE + '\ncommands = ' + repr(commands)
    + '\nfor command in commands:\n    subprocess.run(command, check=True)\n')
template = (prior_run / 'check.py').read_text()
driver = template[:template.index('\njobs =')]
jobs = [('public-build', 'exec lake build', 0),
    ('strict-new-components-and-prior-bindings', 'exec python3 ' + shlex.quote(str(strict)), 3),
    ('independent-imports', 'exec lake env lean -j1 -DwarningAsError=true ' + shlex.quote(str(independent)), 274),
    ('audit-build', 'exec lake build MicroCFTA.Audit', 0),
    ('audit-strict', 'exec lake env lean -j1 -DwarningAsError=true MicroCFTA/Audit.lean', 679)]
driver += '\njobs = ' + repr(jobs) + '''
for name, command, count in jobs:
    run(name, command, count)
assert len(checks) == 5
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx']
           and (not job[2] or c['total_axiom_reports'] == job[2]) for c, job in zip(checks, jobs))
assert checks[1]['axiom_groups'] == 3 and checks[1]['axiom_free_reports'] == 0
assert checks[2]['axiom_groups'] == 271 and checks[2]['axiom_free_reports'] == 3
assert checks[4]['axiom_groups'] == 673 and checks[4]['axiom_free_reports'] == 6
match = re.search(r'Checked axiom dependencies of (\\d+) MicroCFTA theorems\\.', (runtime / 'audit-strict.txt').read_text())
assert match
'''
report = dict(prior)
for name in ['checks', 'limits', 'at', 'audited_theorems', 'checked_code', 'owner_preflight_evidence',
             'legacy_new_private_reports', 'legacy_new_private_reports_caveat', 'new_owner_export_maxHeartbeats',
             'old_native_entire_bytes_preserved', 'old_native_exact_offset',
             'old_gamma_entire_bytes_preserved_as_prefix', 'old_gamma_exact_offset',
             'new_ordinary_imports_to_changed_owners', 'new_ordinary_import_bytes',
             'old_audit_bytes_preserved_as_prefix']:
    report.pop(name, None)
for name in list(report):
    if name.startswith('old_non_audit_'):
        report.pop(name)
report.update(source_files=6252, direct_audit_imports=5252, individual_reports=679,
    independent_reports=274, resource_and_component_probes=473,
    inherited_resource_component_reports=470, fresh_resource_component_reports=3,
    replaced_old_reports=0, fresh_owner_preflight_reports=0,
    fresh_strict_normal_reports=3, actual_publication_strict_reports=3,
    resource_component_evidence='3 actual fresh public strict reports plus470 inherited reports;2 private helpers are checked transitively and add no explicit report; no replacement, fresh resource-owner preflight or axiom-string replay',
    new_component_reports=3, new_theorem_reports=3, new_theorem_declarations=5,
    new_modules=1, new_public_theorems=3, new_private_theorems=2,
    new_private_component_reports=0, new_public_component_reports=3, new_private_predicates=0,
    new_private_helpers=2, private_helpers_checked_transitively=True,
    private_helpers_counted_as_explicit_fresh_reports=False,
    new_relation_declaration_checks=0, new_relation_declaration_reports=0,
    owner_resource_probes=264, previous_owner_resource_probes=264,
    owner_recompiled_in_publication_strict_gate=False, fresh_owner_preflight_evidence=None,
    inherited_owner_preflight_evidence={'prior_run': str(prior_run), 'reports': 264,
        'normal_owner_sha256': owner_sha, 'fresh_this_batch': False, 'included_in_inherited_470': True},
    old_non_audit_source_files_byte_exact=6250, entire_previous_resource_owner_byte_exact=True,
    old_resource_owner_sha256=owner_sha, changed_existing_owners=0,
    old_audit_bytes_preserved_contiguously_after_one_import=True,
    old_audit_exact_offset=len(new_import), new_audit_imports=1,
    all_old_proof_bodies_and_limits_unchanged=True,
    actual_source_auxiliary_key_full_pattern_recovery_proved=True,
    auxiliary_singleton_base_key_recovery_proved=True,
    source_parent_pair_avoids_auxiliary_proved=True,
    source_auxiliary_base_key_full_pattern_recovery_proved=True,
    all_three_original_first_headers_byte_exact=True,
    arbitrary_domain_extension_cancellation_claimed=False,
    future_Profile_or_Gamma_or_model_supplier=False,
    every_warm_worker_call_qualification_proved=False, warm_query_no_new_mu_proved=False,
    all_warm_cells_source_qualification_proved=False,
    earlier_source_family_semantic_IH_discharged=False,
    every_cell_joint_query_attachment_proved=False, inherited_cell_semantic_chronology_proved=False,
    mixed_qualified_profile_height_orientation_derived=False,
    independent_query_inherited_warm_tables_proved=False, warm_across_independent_queries_proved=False,
    joint_finite_completion_proved=False, all_native_inhabitance_proved=False,
    source_terminal_marker_native_inhabitance_proved=False, source_type_marker_class_consistency_proved=False,
    compiled_haskell_correspondence_proved=False, haskell_changed=False,
    same_original_runtime_fuels=True, whole_worker_roles_proved=True,
    whole_worker_program_slots_proved=True, whole_worker_program_slots_fixed_marks_proved=True,
    proof_limits='unchanged defaults; unchanged owner proof settings inherited',
    prior_checkpoint=prior_commit, prior_immutable_archive=prior_archive.name, public_run=str(runtime))
driver += 'report = ' + repr(report) + '\n'
driver += '''report.update(checks=checks, limits=limits, at=datetime.datetime.now().astimezone().isoformat(),
              audited_theorems=int(match.group(1)))
(runtime / 'checked.json').write_text(json.dumps(report, indent=2) + '\\n')
print(json.dumps(report), flush=True)
'''
(runtime / 'check.py').write_text(driver)
files = list((root / 'lean/MicroCFTA').glob('*.lean'))
files += [root / name for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']]
files += [p for p in runtime.iterdir() if p.is_file()] + [strict_source]
files += [Path(__file__), stage_path, work / 'baseline-source-pins.json', work / 'PUBLIC-PROBES.lean.txt',
    work / 'IMPORTS.lean.txt', work / 'Audit-BEFORE.lean.txt'] + header_paths + checked_inputs
files += [packet / name for name in ['MANIFEST.sha256', 'LAYOUT.json', 'PROBES.lean.txt']]
(runtime / 'source-pins.json').write_text(json.dumps(
    {str(p.relative_to(root)): sha(p.read_bytes()) for p in files}, indent=2) + '\n')
print(json.dumps({'run': str(runtime), 'gates': 5, 'fresh_component_reports': 3,
    'inherited_component_reports': 470, 'combined_component_reports': 473,
    'new_theorem_declarations': 5, 'new_private_explicit_reports': 0,
    'replaced_old_reports': 0, 'fresh_owner_preflight_reports': 0,
    'inherited_owner_reports': 264, 'independent_reports': 274,
    'audit_reports': 679, 'objects': str(objects)}))
