from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/tritlo/Code/mcfta')
BASE = ROOT / 'lean/restart-evidence'
WORK = Path(__file__).resolve().parent
assert WORK == BASE / '20261117-authentic-auxiliary-key-recovery-work'
PUBLIC = BASE / '20261117-authentic-auxiliary-key-publication'
ARCHIVE = '20261117-authentic-auxiliary-key-checkpoint'
BOARD_PREFIX = 'current-board-authentic-auxiliary-key-'
SHA = lambda data: hashlib.sha256(data).hexdigest()
GIT = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
read = lambda path: json.loads(path.read_text())
bindings = read(WORK / 'prior-bindings.json')
prior = bindings['prior_checkpoint']
commit = read(WORK / 'SOURCE-COMMIT.json')
code = commit['source_commit']
assert re.fullmatch(r'[0-9a-f]{40}', code)
assert commit['parent'] == prior
assert GIT('rev-parse', 'HEAD').decode().strip() == code
assert GIT('rev-parse', code + '^').decode().strip() == prior
assert GIT('branch', '--show-current').decode().strip() == 'formalize'
assert not GIT('status', '--porcelain', '--untracked-files=no')
report = read(PUBLIC / 'checked.json')
verified = read(WORK / 'PUBLICATION-VERIFIED.json')
assert verified['actual_terminal'] and verified['pins_unchanged']
assert verified['checks'] == report['checks']
assert len(report['checks']) == 5
assert [item['total_axiom_reports'] for item in report['checks']] == [679, 3, 274, 679, 679]
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['nonstandard_axioms']
           and not item['sorryAx'] for item in report['checks'])
for key, expected in {'source_files': 6252, 'direct_audit_imports': 5252,
                      'individual_reports': 679, 'independent_reports': 274,
                      'fresh_resource_component_reports': 3,
                      'inherited_resource_component_reports': 470,
                      'resource_and_component_probes': 473,
                      'fresh_owner_preflight_reports': 0,
                      'actual_publication_strict_reports': 3,
                      'new_modules': 1, 'new_public_theorems': 3,
                      'new_private_component_reports': 0, 'new_private_predicates': 0,
                      'new_theorem_reports': 3, 'replaced_old_reports': 0}.items():
    assert report[key] == expected, key
assert [(item['axiom_groups'], item['axiom_free_reports']) for item in report['checks']] == [
    (673, 6), (3, 0), (271, 3), (673, 6), (673, 6)]
assert not report['owner_recompiled_in_publication_strict_gate']
assert report['fresh_owner_preflight_evidence'] is None
assert report['inherited_owner_preflight_evidence']['reports'] == 264
assert not report['inherited_owner_preflight_evidence']['fresh_this_batch']
assert report['inherited_owner_preflight_evidence']['included_in_inherited_470']
assert report['new_theorem_declarations'] == 5
assert report['new_private_helpers'] == report['new_private_theorems'] == 2
assert report['private_helpers_checked_transitively']
assert not report['private_helpers_counted_as_explicit_fresh_reports']
for key in ['auxiliary_singleton_base_key_recovery_proved',
            'source_parent_pair_avoids_auxiliary_proved',
            'source_auxiliary_base_key_full_pattern_recovery_proved',
            'actual_source_auxiliary_key_full_pattern_recovery_proved',
            'all_three_original_first_headers_byte_exact',
            'whole_worker_program_slots_fixed_marks_proved']:
    assert report[key], key
for key in ['arbitrary_domain_extension_cancellation_claimed', 'future_Profile_or_Gamma_or_model_supplier',
            'every_warm_worker_call_qualification_proved', 'warm_query_no_new_mu_proved',
            'all_warm_cells_source_qualification_proved',
            'earlier_source_family_semantic_IH_discharged', 'every_cell_joint_query_attachment_proved',
            'inherited_cell_semantic_chronology_proved', 'mixed_qualified_profile_height_orientation_derived',
            'independent_query_inherited_warm_tables_proved', 'warm_across_independent_queries_proved',
            'all_native_inhabitance_proved', 'source_type_marker_class_consistency_proved',
            'joint_finite_completion_proved', 'compiled_haskell_correspondence_proved', 'haskell_changed']:
    assert not report[key], key
pins = read(PUBLIC / 'source-pins.json')
for name, digest in pins.items():
    assert SHA((ROOT / name).read_bytes()) == digest, name
source_pins = {name: digest for name, digest in pins.items()
               if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
actual = {str(path.relative_to(ROOT)) for path in (ROOT / 'lean/MicroCFTA').glob('*.lean')}
assert len(source_pins) == 6252 and actual == set(source_pins)
assert verified['reverified_pins'] == len(pins)
for name in commit['files']:
    assert GIT('show', code + ':' + name) == (ROOT / name).read_bytes(), name
module = 'SourceCurrentNativeAuxiliaryBaseKeyRecovery'
module_path = 'lean/MicroCFTA/' + module + '.lean'
audit = 'lean/MicroCFTA/Audit.lean'
changed = {module_path, audit}
stage = read(WORK / 'SOURCES-NORMAL-STAGING.json')
assert stage['new_module'] == module and stage['source_path'] == module_path
assert stage['new_theorem_declarations'] == 5 and stage['fresh_explicit_axiom_reports'] == 3
assert stage['new_public_theorems'] == 3 and stage['new_private_helpers'] == 2
assert stage['private_helpers_covered_transitively']
assert set(commit['files']) == changed
assert set(GIT('diff', '--name-only', prior, code).decode().splitlines()) == changed
baseline = read(WORK / 'baseline-source-pins.json')
assert len(baseline) == 6251 and module_path not in baseline
assert actual == set(baseline) | {module_path}
for name, digest in baseline.items():
    if name != audit:
        assert source_pins[name] == digest, name
assert len(set(baseline) - {audit}) == 6250
old_audit = (WORK / 'Audit-BEFORE.lean.txt').read_bytes()
assert GIT('show', prior + ':' + audit) == old_audit
assert len(old_audit) == stage['old_audit_bytes'] == 424863
assert SHA(old_audit) == stage['old_audit_sha256']
assert old_audit.count(b'#print axioms ') == 676
packet = BASE / '20261117-authentic-auxiliary-key-unnecessary-simpa-repair'
assert (ROOT / module_path).read_bytes() == (packet / (module + '.lean')).read_bytes()
assert source_pins[module_path] == stage['raw_sha256'] == 'ee0c04dc54667b6b55698e3774e1955c61cd5660f79b6f1a2d37adb06b17eff9'
assert SHA((packet / 'MANIFEST.sha256').read_bytes()) == stage['selected_manifest_sha256']
new_import = (WORK / 'IMPORTS.lean.txt').read_bytes()
assert new_import == ('import MicroCFTA.' + module + '\n').encode()
assert len(new_import) == stage['old_audit_exact_offset'] == 61
assert stage['old_audit_contiguous_bytes_preserved']
public = (WORK / 'PUBLIC-PROBES.lean.txt').read_bytes()
assert public == ''.join('#check ' + name + '\n#print axioms ' + name + '\n' for name in stage['names']).encode()
assert (ROOT / audit).read_bytes() == new_import + old_audit + b'\n' + public
owner = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
assert source_pins[owner] == baseline[owner] == report['old_resource_owner_sha256']
prior_archive = BASE / bindings['prior_archive']
for name, key in [('manifest.json', 'prior_manifest_sha256'),
                  ('checkpoint.json', 'prior_checkpoint_json_sha256')]:
    data = (prior_archive / name).read_bytes()
    assert SHA(data) == bindings[key]
    assert GIT('show', prior + ':' + str((prior_archive / name).relative_to(ROOT))) == data
old_checkpoint = read(prior_archive / 'checkpoint.json')
assert old_checkpoint['resource_and_component_probes'] == 470
assert report['inherited_resource_component_reports'] == old_checkpoint['resource_and_component_probes']
assert old_checkpoint['checked_code'] == GIT('rev-parse', prior + '^').decode().strip()
prior_files = {item['path']: item for item in read(prior_archive / 'manifest.json')['files']}
for name in ['source-pins.json.gz', 'verification.json', 'archived-inputs.json']:
    data = (prior_archive / name).read_bytes()
    assert len(data) == prior_files[name]['bytes']
    assert SHA(data) == prior_files[name]['sha256']
    assert GIT('show', prior + ':' + str((prior_archive / name).relative_to(ROOT))) == data
old_verification = read(prior_archive / 'verification.json')
assert old_verification['checked_code'] == old_checkpoint['checked_code']
assert old_verification['source_tree_sha256'] == old_checkpoint['source_tree_sha256']
assert old_verification['prior_document_bytes_preserved']
old_pins = json.loads(gzip.decompress((prior_archive / 'source-pins.json.gz').read_bytes()))
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    assert old_pins[name] == pins[name], name
assert baseline == {name: digest for name, digest in old_pins.items()
                    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
request = read(WORK / (BOARD_PREFIX + 'request.json'))
canonical = read(WORK / (BOARD_PREFIX + 'canonical.json'))
assert canonical.get('verified', True)
post = canonical.get('post', canonical)
assert post['id'] == request['request_id']
assert type(post['sequence']) is int and post['sequence'] > 0
for key, expected in [('author', request['username']), ('thread_id', request['thread_id']),
                      ('post_type', request['post_type']), ('content', request['content']),
                      ('metadata', request['metadata'])]:
    assert post[key] == expected, key
assert post['metadata']['source'] == code
receipt = read(WORK / 'REPAIR-CHECK-VERIFIED.json')
assert receipt['actual_session'] == 37074 and receipt['actual_terminal_exit'] == 0
assert receipt['original_first_headers_byte_exact']
assert receipt['first_failed_check_and_one_line_repair_preserved']
assert receipt['new_public_reports'] == 3 and receipt['new_private_helpers'] == 2
checked = read(BASE / receipt['run'] / 'checked.json')
assert receipt['checks'] == checked['checks']
assert checked['normal_module_checked'] and checked['source_pins_unchanged']
assert checked['checks'][-1]['total_axiom_reports'] == 3
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['nonstandard_axioms']
           and not item['sorryAx'] for item in checked['checks'])
failed = read(WORK / 'FIRST-CHECK-FAILED.json')
assert failed['actual_session'] == 63069 and failed['actual_terminal_exit'] == 1
assert failed['original_packets_preserved']
failed_run = BASE / failed['run']
failed_result = read(failed_run / ('checked.json' if (failed_run / 'checked.json').exists() else 'results.json'))
assert failed_result['checks'] == failed['checks']
assert failed_result['checks'][-1]['exit'] == 1 and failed_result['checks'][-1]['diagnostics'] == 1
assert not failed_result['checks'][-1]['nonstandard_axioms'] and not failed_result['checks'][-1]['sorryAx']
review_failure = read(WORK / 'FIRST-REVIEW-PREFLIGHT-FAILED.json')
assert not review_failure['compiler_started'] and not review_failure['run_or_object_created']
assert not review_failure['source_or_packet_mutations']
staging_failure = read(WORK / 'FIRST-STAGING-PREFLIGHT-FAILED.json')
assert not staging_failure['compiler_started'] and not staging_failure['normal_source_changed']
cleanup = read(WORK / 'combined-terminal-cleanup-result.json')
assert cleanup['no_double_counting'] and cleanup['all_terminal_directories_distinct']
cleanup_paths = [item.get('directory', item.get('path')) for item in cleanup['targets']]
assert all(isinstance(path, str) and path for path in cleanup_paths)
assert len(set(cleanup_paths)) == len(cleanup_paths)
assert cleanup['all_targets_absent']
assert cleanup['sources_logs_live_jobs_normal_lake_unknown_entries_preserved']
assert cleanup['removed_bytes'] == sum(item['bytes'] for item in cleanup['targets'])
assert cleanup['cumulative_removed_bytes'] >= cleanup['removed_bytes']
assert all(item['terminal_exit'] in [0, 1] for item in cleanup['targets'])
usage = read(WORK / 'USAGE.json')
assert 0 <= usage['rate_limits']['primary']['used_percent'] <= 80
roots = read(WORK / 'selection-roots.json')
additional_path = WORK / 'archive-additional-roots.json'
additional = read(additional_path) if additional_path.exists() else []
for item in additional:
    assert re.fullmatch(r'20261117-[a-z0-9-]+', item['root'])
    assert item['manifest'] in ['MANIFEST.json', 'manifest.json', 'MANIFEST.sha256']
    assert SHA((BASE / item['root'] / item['manifest']).read_bytes()) == item['sha256']
    roots.append(item['root'])
assert len(roots) == len(set(roots))
assert all((BASE / name).is_dir() and not (BASE / name).is_symlink() for name in roots)
# Each selected compiler run must have an actual terminal result.
for name in roots:
    run = BASE / name
    if (run / 'PREPARATION-FAILED.json').exists():
        failure = read(run / 'PREPARATION-FAILED.json')
        assert not failure['compiler_started']
        assert not failure['source_or_object_output_created']
    elif (run / 'check.py').exists():
        result = read(run / ('checked.json' if (run / 'checked.json').exists() else 'results.json'))
        assert result['checks'] and all(type(item['exit']) is int for item in result['checks']), name
for item in read(WORK / 'original-header-files.json'):
    assert SHA((ROOT / item['path']).read_bytes()) == item['sha256'], item['path']
    assert SHA((ROOT / item['original']).read_bytes()) == item['sha256'], item['original']
selected = sorted(str((BASE / name).relative_to(ROOT)) for name in roots)
assert not (BASE / ARCHIVE).exists()
config = dict(report)
tree = hashlib.sha256()
for name, digest in sorted(source_pins.items()):
    tree.update(name.encode() + b'\0' + digest.encode() + b'\n')
config.update(checked_code=code, prior_checkpoint=prior, public_run=str(PUBLIC), public_gates=5,
    explicit_reports=report['individual_reports'], board_prefix=BOARD_PREFIX,
    board_post_id=post['id'], board_sequence=post['sequence'],
    source_tree_sha256=tree.hexdigest(),
    old_non_audit_source_files_byte_exact=6250,
    old_audit_contiguous_bytes_preserved=424863, old_audit_exact_offset=61,
    ordinary_audit_import_bytes=61, new_audit_imports=1, old_audit_is_prefix=False,
    old_owner_proof_bodies_unchanged=True, old_owner_proof_limits_unchanged=True,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],
    cleanup_receipt='combined-terminal-cleanup-result.json',
    primary_usage_percent=usage['rate_limits']['primary']['used_percent'],
    primary_usage_checked_at=usage['event_timestamp'],
    prior_immutable_archive=bindings['prior_archive'],
    prior_manifest_sha256=bindings['prior_manifest_sha256'],
    new_theorem_declarations=5, fresh_strict_reports=3,
    inherited_component_reports=470, replaced_old_reports=0,
    all_new_formal_proof_checks_first_pass=False,
    first_unnecessarySimpa_failure_and_exact_header_repair_preserved=True,
    header_newline_review_preflight_before_compiler_preserved=True,
    public_probe_staging_preflight_before_source_change_preserved=True,
    private_helpers_add_no_explicit_report_credit=True,
    additional_uncompiled_candidates_add_no_theorem_credit=True,
    additional_frozen_roots=additional,
    joint_finite_completion_proved=False,
    compiled_haskell_correspondence_proved=False, haskell_changed=False, goal_active=True)
skipped = sorted(str(path.relative_to(ROOT)) for path in BASE.iterdir()
    if path.is_dir() and path.name.startswith('20261117-') and str(path.relative_to(ROOT)) not in selected)
review = {
    'prior_checkpoint': prior, 'prior_immutable_archive': bindings['prior_archive'],
    'prior_manifest_sha256': bindings['prior_manifest_sha256'], 'selected_roots': len(selected),
    'base_roots': len(read(WORK / 'selection-roots.json')), 'additional_frozen_roots': additional,
    'policy': 'Keep the original auxiliary headers and first candidate, layout packet, failed unnecessarySimpa compiler check and exact-header repair, successful actual check, precompiler header-review and public-probe staging failures, publication controls/runtime, and current full target. Additional frozen candidates add no theorem credit.',
    'new_public_theorem_reports': 3, 'new_private_component_reports': 0,
    'new_private_helpers': 2, 'new_private_predicates': 0, 'new_theorem_declarations': 5,
    'fresh_owner_preflight_reports': 0, 'actual_publication_strict_reports': 3,
    'fresh_reports_this_batch': 3, 'inherited_bound_reports': 470,
    'prior_component_reports': 470, 'replaced_old_reports': 0,
    'inherited_owner_reports_included': 264,
    'all_new_formal_proof_checks_first_pass': False,
    'failed_unnecessarySimpa_and_exact_header_repair_preserved': True,
    'header_review_and_probe_staging_failures_before_compiler_preserved': True,
    'private_helpers_counted_as_explicit_reports': False,
    'actual_source_auxiliary_key_full_pattern_recovery_proved': True,
    'arbitrary_domain_extension_cancellation_claimed': False,
    'all_warm_worker_call_qualifications_proved': False,
    'warm_query_no_new_mu_proved': False,
    'earlier_source_family_semantic_IH_discharged': False,
    'every_cell_joint_query_attachment_proved': False,
    'inherited_cell_semantic_chronology_proved': False,
    'warm_across_independent_queries_proved': False, 'all_native_inhabitance_proved': False,
    'type_marker_class_consistency_proved': False, 'joint_finite_completion_proved': False,
    'haskell_changed': False, 'no_axiom_string_replay': True,
    'no_compiled_objects_or_import_overlays': True,
}
note = (WORK / 'checkpoint-note.md').read_text()
for key, value in {'THEOREMS': report['audited_theorems'], 'REMOVED': cleanup['removed_bytes'],
                   'CLEANUP': cleanup['cumulative_removed_bytes'],
                   'USAGE': config['primary_usage_percent']}.items():
    note = note.replace('{{' + key + '}}', str(value))
assert set(re.findall(r'\{\{(.*?)\}\}', note)) == {'TIME', 'TREE', 'CODE'}
outputs = {'checkpoint-config.json': config, 'archive-roots.json': selected,
           'skipped-published-roots.json': skipped, 'selection-review.json': review}
assert all(not (WORK / name).exists() for name in outputs)
for name, value in outputs.items():
    (WORK / name).write_text(json.dumps(value, indent=2) + '\n')
(WORK / 'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code': code, 'packet': ARCHIVE,
                  'roots': len(selected), 'board_sequence': post['sequence'],
                  'new_theorem_declarations': 5, 'fresh_strict_reports': 3, 'inherited_reports': 470}))
