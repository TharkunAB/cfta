from pathlib import Path
import hashlib,json
r=Path('/home/tritlo/Code/mcfta');a=Path('/tmp/mcfta-prepared-composition-20261028')
head=(a/'source-head.txt').read_text().strip();public=json.loads((a/'public-validation.json').read_text());source=json.loads((a/'source-validation.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
common=f'''
## Prepared prefix, parent and restart origin composition

Source checkpoint: {head}.
Conditional finite-pruning language preservation and the prepared finite-depth
resource induction remain. New proofs preserve original subtree paths through
the actual selected prefix and the SAME native preparation witnesses. The
accepted prepared parent and the original selector permutation derive an actual
selected occurrence. The ordered scan reaches that accepted event with one
satisfying assignment and all allocated origins OR reports an exact earlier
hook stop. Full Caller, Memos and resource packets remain at the actual events.
The actual completed receipt retains those paths through recording and the
SAME resource-certified recursive restart under original subtree policies.

Checked constructor receipts now derive successful equality projection.
An actual raw makeEdge counterexample proves that native Ready plus a Cached
annotation Heap does not imply projection support. It is not a full admitted
Context/Packet or a Haskell counterexample. The parent scan still requires
all-selected projection support. Derive it from original checked construction
provenance; native normalization then preserves the stronger guard property.
The three original annotation-admission policies remain explicit and separate
from OriginPolicies. No new Haskell defect or required repair was established.

Whole-driver output soundness and original accepted-output coverage remain open.
The main gap is semantic composition through full recursive histories, with
sufficient depth for ALL earlier reachable callbacks. A chosen term's height
does not bound earlier callbacks. Preserve the actual earlier-stop alternative.
Public APIs, ranking, sampling and physical Haskell correspondence remain open.
Whole-CFTA goal ACTIVE; checkpoint PROGRESS.

Six modules add 11 public theorems. Seven final strict checks pass. Full Audit
passes 4401 jobs and checks 80977 theorem dependencies. Public readback has
482 theorem blocks and 44 definitions. Its complete prior 2015663-byte output
is an exact prefix. All 4394 prior non-Audit Lean, 243 strong and 810 Haskell
source/evidence files retain bytes. Details: lean/notes-current-prepared-composition.md.

'''
findings=common+'''### Haskell comparison and external integration handoff

No Haskell or Cabal file changed. No Haskell test or benchmark ran.
No new required Haskell fix was established. Keep the integrated LPO and KBO
Natural-weight repairs and their evidence below. This checkpoint requests no
Haskell patch.

Haskell mkEdge rejects contradictory constraints and equality constraints that
fail fitsArity. It returns the empty-edge sentinel. mkNode removes edges with
empty children. setChildren can skip checks when the child count is unchanged;
its documented contract relies on the original checked edge provenance.
The new Receipt.projectable laws extract the formal projection fact from the
actual checked MkEdge, rejected sentinel and Parent construction receipts.
They do not infer that fact from native readiness alone.

The raw counterexample uses the actual raw interner from the empty native heap
with a contradictory equality accessor. It proves Ready, Cached annotations,
edge residency and an allowed zero-child arity, while projection returns none.
Cached is vacuous at none. The example does not prove a full allocated
Context/Packet, an accepted term, checked construction, selector reachability,
or a public Haskell defect. Preserve these scope limits.

The parent theorem applies the existing selected_accepting_of_perm law to the
actual prepared parent. It does not replace the original stored handle with
that parent. Its explicit all-selected support premise also covers empty
unsupported rows before the accepted occurrence, since an actual unhandled
row can stop the whole scan. Constructor-origin support for every resident
row remains to be derived. SelectedValue.run_heaps/run_invariants already
preserve an arbitrary original guard property through native preparation.
Use that law after deriving the genuine initial projectability Heap.

The actual prefix and preparation keep the allocation counter. Their origin
facts use the same assignment and the SAME actual prepared witnesses, not a
second run. The original unary, app and filter annotation-admission policies
remain. OriginPolicies gives template avoidance and program encoding at
structural subtrees; it does not imply those external typing/admission gates.
The receipt corollary retains the complete old model/resource packet inside
the SAME recorded metadata and callback-core witnesses. It adds origins and
local policies. It supplies no recursive output model or future success gate.

'''
(a/'document-insertions').mkdir(exist_ok=True)
(a/'document-insertions/common.md').write_text(common);(a/'document-insertions/findings.md').write_text(findings)
records={}
for p in sorted((a/'prior-documents').rglob('*.md')):
 rel=p.relative_to(a/'prior-documents');old=p.read_bytes();insert=(findings if str(rel)=='FINDINGS.md' else common).encode();first,rest=old.split(b'\n',1);new=first+b'\n'+insert+rest
 assert new.replace(insert,b'',1)==old
 (r/rel).write_bytes(new);records[str(rel)]=dict(before_sha256=sha(old),after_sha256=sha(new),inserted_bytes=len(insert))
(a/'document-inverse.json').write_text(json.dumps(records,indent=2)+'\n')
mods=json.loads((a/'modules.json').read_text())
note=f'''# Prepared prefix, parent and restart origin composition

Source checkpoint: {head}. Whole-CFTA goal ACTIVE. Checkpoint PROGRESS.
The three source commits are published on formalize. The evidence commit follows.

## Strongest current statement

Under the original admission, resource, selector and policy conditions, finite
pruning preserves the represented language. Prepared enumeration at every
finite recursive depth stabilizes at one resource-certified actual outcome
when its work fuel is sufficient. Stops and exhaustion remain permitted.
Constructive semantic proofs now preserve one original satisfying assignment
and every allocated variable's original subtree path through the proved
startup, narrowing, preparation, branch, sibling-event and recording stages.
These are component results. Whole-driver output soundness and accepted-output
existence remain open.

## New proof contracts

The actual PrefixValid cache retains its counter in both parked and narrowed
cases. AssignmentOrigins therefore holds at that cache exactly when it holds
at the original cache. The prefix corollary calls the old model/resource
producer once and retains its complete packet. The prepared-prefix corollary
also calls its old producer once. It retains every original full-Memos,
resource, model and admission field. The entered counter equals the original
counter at the SAME native preparation witnesses. The prefix fuel bound is
uniform. Preparation witnesses remain local to each actual prefix observation;
there is no new joint preparation bound for every prefix extra fuel.

The ordered sibling proof uses the actual finite prepared head origin law.
At the captured before-cache it carries the same original model and origins
to the actual chosen event, or records a strictly earlier stopped hook.
The complete original resource prefix is retained. The unrestricted older
semantic observer remains in its unchanged older theorem. The new observer
requires origins and constructs one extension that has them. It does not
claim that arbitrary older existential assignments have original paths.
Sibling tails receive the actual previous Caller effects and full Memos.

The parent corollary retains the ENTIRE new sibling packet and its uniform
indexed observer. It uses the existing selected_accepting_of_perm law at the
actual prepared parent. Original permutation and parent acceptance derive a
real selected index and accepting row. The index is fixed before extra fuel.
All-selected projection support supplies the earlier-prefix support premise.
The result remains chosen accepted event OR exact earlier hook stop.
The original stored handle is never identified with the prepared parent.

The completed-receipt corollary calls the original receipt model producer
once. It retains the exact fuel/outcome and the SAME recorded metadata and
callback-core witnesses. Every old model and resource field remains.
Frame.counter gives the allocation-origin equivalence. Original OriginPolicies
at the concrete selected subtree supply the callback Avoids and ProgramEncoding
conditions. The retained model law then gives false recording, pending
refutation and the SAME certified resume outcome. No recursive output model,
future hook completion or new Complete premise is supplied.

Projection support now follows from actual checked MkEdge, rejected sentinel
and Parent construction receipts. The accepted constructor test gives a
successful equality accessor. The rejected sentinel has the empty successful
projection. A separate actual raw makeEdge result proves native Ready, Cached
annotations, resident edge and allowed zero-child arity with project=None.
This is a raw-native boundary example. It supplies no full Context/Packet,
accepted term, checked constructor receipt or Haskell API counterexample.

New modules:

'''+''.join('- MicroCFTA.'+m+'\n' for m in mods)+f'''
## Remaining work and rejected shortcuts

Compose these witnesses through full prepared recursive histories. Derive an
original sufficient depth condition for ALL earlier reachable callbacks, not
only the chosen accepted model. Actual stopped hooks omit the sibling suffix.
At depth zero an expand request is exhausted for every work fuel. A chosen
term's subtree-height bound alone cannot remove earlier depth stops.
No admitted all-depth counterexample has been established. The earlier
A=f(A)|a proposal remains rejected: a fresh Mu child with no bucket is not
expandable, and repeated native keys clear the bucket or park the work.

Derive projection support for every relevant original and prepared resident
row from genuine checked construction provenance. Native Ready, Cached Heap
and arity-origin Fits cannot supply it alone. SelectedValue already preserves
arbitrary guard properties through preparation. Apply that law after proving
the stronger original Heap; do not rename the desired global premise.

The three original unary/app/filter annotation-admission conditions remain.
OriginPolicies quantifies over structural original subtrees and gives template
avoidance and ProgramEncoding. It does not imply external holeKey/fits/admits
typing policies. Root-only ProgramAt policies are also insufficient because
ProgramAt skips annotation and marker children.

Whole-driver output soundness, original accepted-output coverage, public APIs,
ranking, sampling and physical Haskell correspondence remain open. Preserve
all older constructor/equality proofs, counterexamples and marked drafts.

## Validation and preservation

Six modules add 11 public theorems and no definitions. Seven final strict
checks pass with warningAsError=true and linter.all=true. Full Audit passes
4401 jobs and checks 80977 theorem dependencies. Seventeen current actual
compiler/build/public commands and one inherited public receipt are retained.
Five current strict attempts failed and are retained in full. One separate
runner error occurred before compiler launch; it is not a failed Lean check.
Every actual command ran serially under measured memory.max=memory.high=
4294967296 and memory.swap.max=0. No proof limit was raised and no linter
was disabled. No sorry, admit, custom axiom or native_decide is in new proof code.
The build replays one unchanged old unused-variable warning. Final new-module
strict outputs are empty. The strict Audit reports only its checked count.

Public output has 482 complete theorem signatures and axiom lists, and
44 printed definitions. Only propext, Classical.choice and Quot.sound occur.
The complete old 2015663-byte output is an exact prefix. No elision occurs.
Full output: {public['bytes']} bytes, SHA256 {public['sha256']}.
New appendix: {public['new_bytes']} bytes, SHA256 {public['new_sha256']}.
Named owners read the complete assigned public blocks. Root read every new
source and final corrective diff, all failed compiler logs, and the Haskell
constructor cuts. Do not infer a whole-public-appendix Root read.

All 4394 prior non-Audit Lean, 243 strong and 810 Haskell source/evidence files
retain their exact bytes. Audit adds imports before its complete previous body.
Nine documents retain their complete old bodies after the recorded insertion
is removed. No Haskell/Cabal file changed. No Haskell test or benchmark ran.
No new Haskell defect or required repair was established. FINDINGS preserves
the integrated LPO and KBO Natural fixes and records the constructor boundary.

Failed proof avenues are retained. Projection-v1 needed the actual empty-build
equation, rather than rfl. Projection-v2 then exposed a proof-only DecidableEq
binder; term-scoped Classical removes that unnecessary binder. Prefix-v1
exposed proof-dependent match generalization. Prefix-v2 needed an explicit
reduced goal before rewriting the retained counter equality. Prepared-prefix-v1
changed the association of an old conjunction; v2 restores its exact grouped
packet and proof nesting. Early literal-recovery review missed that grouping
change. Final recovery preserves the old parentheses and checked public type.
No old admission was weakened to repair these errors. Parent-v1 passed a
qualified module name to a runner that expects an unqualified name. Its full
launch error is retained separately from actual compiler failures.

## Evidence and restart

Raw evidence: /tmp/mcfta-prepared-composition-20261028.
Archive: lean/restart-evidence/20261028-prepared-composition.
Every actual command retains exact tested source inputs, raw output, exit code,
hashes and measured limits. Reviews retain whole source snapshots, literal
source cuts, old-contract recoveries and complete assigned public blocks.
The manifest records every frozen payload and both stored and raw hashes.
Large or whitespace-sensitive payloads use deterministic gzip.
The verifier checks exact sets, source/public preservation, document inverse
bodies, command limits, reconstruction and committed archive bytes.
All older areas remain frozen. Use a FRESH area after this checkpoint.
Whole-CFTA goal remains ACTIVE. The full formalization is not complete.
'''
(r/'lean/notes-current-prepared-composition.md').write_text(note)
(a/'root-review/notes-current-prepared-composition.md').write_text(note)
print(json.dumps(dict(documents=len(records),note_bytes=len(note.encode()),common_bytes=len(common.encode()),findings_bytes=len(findings.encode()))))
