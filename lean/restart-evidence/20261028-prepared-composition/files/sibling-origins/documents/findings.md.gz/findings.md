
## Prepared prefix, parent and restart origin composition

Source checkpoint: 96d98b104c7dc44b168c73dd370c0f46398c9407.
Conditional finite-pruning language preservation and the prepared finite-depth
resource induction remain. New proofs preserve original subtree paths through
the actual selected prefix and the SAME native preparation witnesses. The
accepted prepared parent and the original selector permutation derive an actual
selected occurrence. The ordered scan reaches that accepted event with one
satisfying assignment and all allocated origins OR reports an exact earlier
hook stop. Full Caller, Memos and resource packets remain at the actual events.
The actual completed receipt retains those paths through recording and the
SAME resource-certified recursive restart under original subtree policies.

Checked constructor receipts now derive successful equality projection.
An actual raw makeEdge counterexample proves that native Ready plus a Cached
annotation Heap does not imply projection support. It is not a full admitted
Context/Packet or a Haskell counterexample. The parent scan still requires
all-selected projection support. Derive it from original checked construction
provenance; native normalization then preserves the stronger guard property.
The three original annotation-admission policies remain explicit and separate
from OriginPolicies. No new Haskell defect or required repair was established.

Whole-driver output soundness and original accepted-output coverage remain open.
The main gap is semantic composition through full recursive histories, with
sufficient depth for ALL earlier reachable callbacks. A chosen term's height
does not bound earlier callbacks. Preserve the actual earlier-stop alternative.
Public APIs, ranking, sampling and physical Haskell correspondence remain open.
Whole-CFTA goal ACTIVE; checkpoint PROGRESS.

Six modules add 11 public theorems. Seven final strict checks pass. Full Audit
passes 4401 jobs and checks 80977 theorem dependencies. Public readback has
482 theorem blocks and 44 definitions. Its complete prior 2015663-byte output
is an exact prefix. All 4394 prior non-Audit Lean, 243 strong and 810 Haskell
source/evidence files retain bytes. Details: lean/notes-current-prepared-composition.md.

### Haskell comparison and external integration handoff

No Haskell or Cabal file changed. No Haskell test or benchmark ran.
No new required Haskell fix was established. Keep the integrated LPO and KBO
Natural-weight repairs and their evidence below. This checkpoint requests no
Haskell patch.

Haskell mkEdge rejects contradictory constraints and equality constraints that
fail fitsArity. It returns the empty-edge sentinel. mkNode removes edges with
empty children. setChildren can skip checks when the child count is unchanged;
its documented contract relies on the original checked edge provenance.
The new Receipt.projectable laws extract the formal projection fact from the
actual checked MkEdge, rejected sentinel and Parent construction receipts.
They do not infer that fact from native readiness alone.

The raw counterexample uses the actual raw interner from the empty native heap
with a contradictory equality accessor. It proves Ready, Cached annotations,
edge residency and an allowed zero-child arity, while projection returns none.
Cached is vacuous at none. The example does not prove a full allocated
Context/Packet, an accepted term, checked construction, selector reachability,
or a public Haskell defect. Preserve these scope limits.

The parent theorem applies the existing selected_accepting_of_perm law to the
actual prepared parent. It does not replace the original stored handle with
that parent. Its explicit all-selected support premise also covers empty
unsupported rows before the accepted occurrence, since an actual unhandled
row can stop the whole scan. Constructor-origin support for every resident
row remains to be derived. SelectedValue.run_heaps/run_invariants already
preserve an arbitrary original guard property through native preparation.
Use that law after deriving the genuine initial projectability Heap.

The actual prefix and preparation keep the allocation counter. Their origin
facts use the same assignment and the SAME actual prepared witnesses, not a
second run. The original unary, app and filter annotation-admission policies
remain. OriginPolicies gives template avoidance and program encoding at
structural subtrees; it does not imply those external typing/admission gates.
The receipt corollary retains the complete old model/resource packet inside
the SAME recorded metadata and callback-core witnesses. It adds origins and
local policies. It supplies no recursive output model or future success gate.

