import MicroCFTA.SourceCurrentEnumerationOrder
import MicroCFTA.SourceEqualityRequiredCache
import MicroCFTA.InternedGuardedLanguage

/-!
# Accepting selected edges of an actual ordinary parent

A permutation retains each accepting resident edge.
Raw interned order selects the actual stored rows.
The canonical closure also retains acceptance when its actual map or fallback
contains a permutation of those rows. Constructing that map remains separate.
-/
namespace MicroCFTA.SourcePruningEnumerationSelectorLanguage
open InternedConstructorTemplates InternedProbeProvenance Language

/-- A permutation of an available parent's rows retains an accepting resident edge. -/
theorem selected_accepting_of_perm
    (heap : State Symbol Guard) (ready : SourceEqualityRequiredCache.Ready heap)
    (entry : Cache.Interned InternedBinderProtocol.NodeKey)
    (edges selectedEdges : List (EdgeValue Symbol Guard)) (depth : Nat)
    (free : List InternedBinderProtocol.Reference)
    (available : Available heap (.node entry edges depth free))
    (sameRows : selectedEdges.Perm edges)
    (holds : Guard → Term Symbol → Bool) (ambient : InternedGuardedLanguage.Env Symbol)
    (term : Term Symbol)
    (accepted : InternedGuardedLanguage.meaning holds ambient (.node entry edges depth free) term) :
    ∃ edge, edge ∈ selectedEdges ∧ edge ∈ edges ∧
      InternedEdgeResidency.EdgeResident heap edge ∧
      InternedGuardedLanguage.edgeMeaning holds ambient edge term := by
  rw [InternedGuardedLanguage.meaning] at accepted
  obtain ⟨⟨edge, member⟩, edgeAccepted⟩ := accepted
  refine ⟨edge, sameRows.mem_iff.mpr member, member, ?_, edgeAccepted⟩
  exact InternedEdgeResidency.resident_edges heap ready.semantic.1.normal.facts.linked
    (.node entry edges depth free) available.resident edge member

