              cases index with
              | zero =>
                  have chosenSame : edge = chosen := Option.some.inj found
                  subst chosen
                  obtain ⟨extended, fragment, afterCache, agree, originalSatisfied, completed, filled, afterSatisfied, afterOrigins⟩ :=
                    headOrigins ambient assignment whole satisfied accepted origins
                  have observed : SourcePruningEnumerationCapturedEdge.run checkEmpty w w w w w
                      uv scs edge caller before memos.query =
                      some (.complete fragment middleCaller saved afterCache) := by
                    rw [completed] at first
                    exact first
                  refine ⟨0, edge, inventory, caller, memos, [], [], fragment, middleCaller, saved,
                    afterCache, middleInventory, middleMemos, Nat.le_refl _, rfl, rfl,
                    Post.refl packet.context, packet, bounded, known, reserved.head, rfl,
                    headPost, headQueries, observed, .here observed, ?_,
                    .inl ⟨rfl, rfl, extended, agree, originalSatisfied, filled, afterSatisfied, afterOrigins⟩⟩
                  simpa only [completed] using receiptCertificate
              | succ index =>
                  have tailFound : rest[index]? = some chosen := by
                    simpa only [List.getElem?_cons_succ] using found
                  have tailSupported : ∀ earlier ∈ rest.take index,
                      arityAllows earlier.children.length scs = true →
                      SourcePruningEnumerationConstraint.project earlier.entry.key.constraint ≠ none := by
                    intro earlier member allowed
                    exact supported earlier (by
                      simp only [List.take_succ_cons, List.mem_cons]
                      exact .inr member) allowed
                  have realized : SourcePruningEnumerationObservation.PendingRealized
                      caller.checked.native.machine.heap before.core := by
                    obtain ⟨_roots, _paths, _storage, realized, _counts, _flags⟩ := packet.valid
                    exact realized
                  have middleSatisfied :=
                    (SourcePruningEnumerationNativeLanguage.satisfies_keeps
                      (SourceEqualityPCSGuard.holds formulas solver) ambient
                      caller.checked.native.machine.heap hookCaller.checked.native.machine.heap before.core
                      (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
                      assignment realized hookPost.effects.keeps).mpr satisfied
                  have later := tailAccepting (headBound + extra) index chosen tailFound tailSupported
                    ambient assignment whole middleSatisfied accepted origins
                  have common : tailBound + (headBound + extra) = w := by dsimp [w, bound]; omega
                  rw [common] at later
                  obtain ⟨eventIndex, eventEdge, headInventory, headCaller, headMemos,
                    prefixReceipts, prefixOutputs, fragment, branchCaller, branchQueries, afterCache,
                    branchInventory, branchMemos, within, atIndex, prefixLength, inputPost, inputPacket,
                    inputFits, inputKnown, inputReserved, prefixRun, branchPost, branchQuery, observed,
                    _invocation, certificate, terminal⟩ := later
                  have liftedPrefix : SourcePruningEnumerationNativeContinuations.run hook
                      checkEmpty w w w w w uv scs before ((edge :: rest).take (eventIndex + 1))
                      caller memos.query = .complete (receipt :: prefixReceipts)
                        (headOutputs ++ prefixOutputs) headCaller headMemos.query := by
                    have running := SourcePruningEnumerationNativeContinuations.continued_head hook
                      checkEmpty w w w w w uv scs before edge (rest.take eventIndex) caller hookCaller
                      memos.query hookQueries receipt headOutputs first (by cases receipt <;> exact continued)
                    rw [←hookQuery, prefixRun] at running
                    simpa only [List.take_succ_cons] using running
                  have newAt : (edge :: rest)[eventIndex + 1]? = some eventEdge := by
                    simpa only [List.getElem?_cons_succ] using atIndex
                  have split : (edge :: rest) = (edge :: rest).take (eventIndex + 1) ++
                      eventEdge :: (edge :: rest).drop (eventIndex + 2) := by
                    obtain ⟨inside, selectedAt⟩ := List.getElem?_eq_some_iff.mp newAt
                    have dropped := List.drop_eq_getElem_cons inside
                    rw [selectedAt] at dropped
                    rw [←dropped]
                    exact (List.take_append_drop (eventIndex + 1) (edge :: rest)).symm
                  have actualInvocation := SourcePruningEnumerationNativeContinuations.complete_prefix_invocation
                    hook checkEmpty w w w w w uv scs before ((edge :: rest).take (eventIndex + 1))
                    caller memos.query liftedPrefix eventEdge ((edge :: rest).drop (eventIndex + 2))
                    fragment branchCaller branchQueries afterCache observed
                  rw [←split] at actualInvocation
                  refine ⟨eventIndex + 1, eventEdge, headInventory, headCaller, headMemos,
                    receipt :: prefixReceipts, headOutputs ++ prefixOutputs, fragment, branchCaller,
                    branchQueries, afterCache, branchInventory, branchMemos, by omega, newAt,
                    by simpa only [List.length_cons] using congrArg (fun n => n + 1) prefixLength,
                    hookPost.trans inputPost, inputPacket, ?_, ?_, ?_, liftedPrefix,
                    branchPost, branchQuery, observed, actualInvocation, certificate.prepend hookPost, ?_⟩
                  · simpa only [SourcePruningEnumerationPreparedReservation.stage_succ] using inputFits
                  · simpa only [SourcePruningEnumerationPreparedReservation.stage_succ] using inputKnown
                  · simpa only [SourcePruningEnumerationPreparedReservation.stage_succ] using inputReserved
                  · rcases terminal with ⟨sameIndex, sameEdge, extended, agree, oldSatisfied, filled, afterSatisfied, afterOrigins⟩ |
                        ⟨earlier, hookOutputs, reason, endpoint, stoppedHook, stoppedResult, stoppedResources⟩
                    · have originalSatisfied :=
                        (SourcePruningEnumerationNativeLanguage.satisfies_keeps
                          (SourceEqualityPCSGuard.holds formulas solver) ambient
                          caller.checked.native.machine.heap hookCaller.checked.native.machine.heap before.core
                          (fun guard term => SourceEqualityPCSGuard.holds formulas solver guard term = true)
                          extended realized hookPost.effects.keeps).mp oldSatisfied
                      exact .inl ⟨by omega, sameEdge, extended, agree, originalSatisfied, filled, afterSatisfied, afterOrigins⟩
                    · refine .inr ⟨by omega, hookOutputs, reason, endpoint, stoppedHook, ?_, ?_⟩
                      · simp only [result, stoppedResult, List.append_assoc]
                      · simpa only [SourcePruningEnumerationPreparedReservation.stage_succ] using
                          stoppedResources.post hookPost
        | stopped headOutputs reason reached =>
            have currentResources := resources
            obtain ⟨afterCaller, next, final, post, returnedFits, returnedKnown, observed, outputsValid⟩ := resources
            have completed : ∃ fragment actual queries after, receipt = .complete fragment actual queries after := by
              cases receipt with
              | complete fragment actual queries after => exact ⟨fragment, actual, queries, after, rfl⟩
              | unhandled => cases advanced
              | rejected actual queries after | stopped fragments observation candidate =>
                  have impossible := callbackRun 0
                  cases impossible
            obtain ⟨fragment, actual, queries, after, same⟩ := completed
            subst receipt
            refine ⟨headBound, [], headOutputs, afterCaller, next, final,
              .stopped [] headOutputs (.continuation (.complete fragment actual queries after) reason reached),
              ?_, post, SourcePruningEnumerationRecursive.captured_post packet post,
              returnedFits.mono laterGrowth.1, ?_, by simp, ?_, ?_, ?_, ?_⟩
            · intro extra
              simp only [SourcePruningEnumerationNativeContinuations.run, headRun extra, callbackRun extra]
            · intro key resident found
              exact laterGrowth.2 (returnedKnown key resident found)
            · intro index current found
              cases found
            · intro output member
              exact ⟨0, by simp, outputsValid output member⟩
            · exact .inr ⟨_, rfl, observed, .inr ⟨_, reason, reached, headOutputs, [], rfl, rfl,
                receiptCertificate, currentResources⟩⟩
            · intro extra
              dsimp only
              intro index chosen found supported ambient assignment whole satisfied accepted origins
              let w := headBound + extra
              have observed := headRun extra
              have invoked : SourcePruningEnumerationHookInvocation.Invocation
                  (continueWith
                    (resume holeKey fits admits graph templates checkEmpty edgesOf stop order w recursiveFuel)
                    graph templates stop order w metadata uv)
                  checkEmpty w w w w w uv scs before (edge :: rest) caller memos.query
                  fragment actual queries after := .here observed
              have inputPrefix : SourcePruningEnumerationNativeContinuations.run
                  (continueWith
                    (resume holeKey fits admits graph templates checkEmpty edgesOf stop order w recursiveFuel)
                    graph templates stop order w metadata uv)
                  checkEmpty w w w w w uv scs before ((edge :: rest).take 0) caller memos.query =
                  .complete [] [] caller memos.query := rfl
              have actualSame : actual = middleCaller ∧ queries = saved := by
                simp only [SourcePruningEnumerationNativeBranches.advance, Option.some.injEq, Prod.mk.injEq] at advanced
                exact ⟨advanced.1, advanced.2.trans headQueries⟩
              have localPost : Post formulas solver middleInventory caller actual middleMemos := by
                simpa only [actualSame.1] using headPost
              have localQuery : middleMemos.query = queries := headQueries.trans actualSame.2.symm
              refine ⟨0, edge, inventory, caller, memos, [], [], fragment, actual, queries, after,
                middleInventory, middleMemos, by omega, rfl, rfl, Post.refl packet.context,
                packet, bounded, known, reserved.head, inputPrefix, localPost, localQuery,
                observed, invoked, receiptCertificate, ?_⟩
              cases index with
              | zero =>
                  have chosenSame : edge = chosen := Option.some.inj found
                  subst chosen
                  obtain ⟨extended, chosenFragment, chosenCache, agree, originalSatisfied,
                    completed, filled, afterSatisfied, afterOrigins⟩ :=
                    headOrigins ambient assignment whole satisfied accepted origins
                  have equality := SourcePruningEnumerationSelectedEdge.Result.complete.inj completed
                  obtain ⟨rfl, _sameCaller, _sameQueries, rfl⟩ := equality
                  exact .inl ⟨rfl, rfl, extended, agree, originalSatisfied, filled, (by
                    simpa only [actualSame.1] using afterSatisfied), afterOrigins⟩
              | succ index =>
                  refine .inr ⟨by omega, headOutputs, reason, reached, callbackRun extra, ?_, ?_⟩
                  · rfl
                  · exact currentResources

end MicroCFTA.SourcePruningEnumerationPreparedFiniteSiblingResources
