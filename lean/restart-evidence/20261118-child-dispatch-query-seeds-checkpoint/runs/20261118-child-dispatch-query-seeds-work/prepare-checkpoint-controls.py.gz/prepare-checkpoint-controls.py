from pathlib import Path
import ast
import gzip
import hashlib
import json
import re
import subprocess

root = Path('/home/tritlo/Code/mcfta')
base = root/'lean/restart-evidence'
archive_control = base/'20261118-child-dispatch-query-seeds-checkpoint-control-draft'
work = base/'20261118-child-dispatch-query-seeds-work'
runtime = base/'20261118-child-dispatch-query-seeds-publication'
archive = base/'20261118-child-dispatch-query-seeds-checkpoint'
prior_archive = base/'20261118-fold-and-terminal-query-seeds-checkpoint'
board_prefix = 'current-board-child-dispatch-query-seeds-'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
git = lambda *args: subprocess.check_output(['git', *args], cwd=root)
assert Path(__file__).resolve().parent == work.resolve()
assert Path(__file__).read_bytes() == (archive_control/'prepare-checkpoint-controls.py').read_bytes()


def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    return data


def records(value):
    if isinstance(value, list):
        return [(item.get('file', item.get('path')), item) for item in value]
    return records(value['files']) if 'files' in value else value.items()


def packet(path, digest=None):
    if digest is not None:
        verify(path/'MANIFEST.json', digest)
    for name, record in records(read(path/'MANIFEST.json')):
        verify(path/name, record)


assert read(archive_control/'MANIFEST.json')['status'] == 'FROZEN CANDIDATE / NOT EXECUTED'
packet(archive_control)
for name, record in records(read(archive_control/'SOURCE-PINS.json')):
    verify(root/name, record)
stage = read(work/'SOURCES-NORMAL-STAGING.json')
overrides = stage['baseline_overrides']
assert stage['status'] == 'SOURCE_NORMAL_STAGING_COMPLETED' and stage['normal_Source_changed']
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6285, 5285, 743, 338)
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (2, 535, 537)
assert stage['new_public_theorems'] == 2 and stage['new_private_helpers_transitive'] == 0 and stage['new_definitions'] == 1
assert stage['new_modules'] == 1 and stage['existing_owners_changed'] == 0 and set(overrides) == {'lean/MicroCFTA/Audit.lean'}


def historical(name, record):
    digest = record['sha256'] if isinstance(record, dict) else record
    for path in [root/name, root/overrides.get(name, name)]:
        if path.is_file() and sha(path.read_bytes()) == digest:
            return verify(path, record)
    raise AssertionError(name)


source_receipt = read(work/'SOURCE-COMMIT.json')
provenance = read(work/'SOURCE-COMMIT-ACTUAL-RUN.json')
code = source_receipt['source_commit']
assert code == provenance['source_commit'] and re.fullmatch(r'[0-9a-f]{40}',code)
assert source_receipt['parent'] == stage['prior_checkpoint'] == '4d2d85d821e12563226c89aed1b10f24fa1fa5ea'
assert type(provenance['actual_session']) is int and provenance['actual_session'] > 0 and provenance['actual_terminal'] and provenance['actual_terminal_exit'] == 0
assert provenance['control_manifest_sha256'] == 'ccfde3c1266d8dc260db2989570a45063e456b0a9f78b103655d61dd71832468'
assert provenance['script_sha256'] == '5c48dabe2afb7eeab6bbb6b08ed210c6f108ca97a01c317bbd6befdec1012147'
commit_control = base/provenance['controller']
packet(commit_control, provenance['control_manifest_sha256'])
assert (work/'commit-source.py').read_bytes() == verify(commit_control/'commit-source.py', provenance['script_sha256'])
assert read(commit_control/'MANIFEST.json')['all_final_receipts_bound_before_freeze']
assert provenance['actual_session'] == 73556
assert source_receipt['private_actual_session'] == 80865 and source_receipt['rejected_private_actual_session'] == 60181
assert source_receipt['rejected_private_credit'] == 0
assert (source_receipt['new_public_theorems'],source_receipt['new_private_theorems'],source_receipt['new_definitions']) == (2,0,1)
assert source_receipt['explicit_definition_checks'] == 1 and source_receipt['definition_axiom_credit'] == 0
assert git('branch','--show-current').decode().strip() == 'formalize'
assert git('rev-parse','HEAD').decode().strip() == code
assert git('rev-parse',code+'^').decode().strip() == stage['prior_checkpoint']
assert not git('status','--porcelain','--untracked-files=no')
assert set(git('diff','--name-only',stage['prior_checkpoint'],code).decode().splitlines()) == set(stage['exact_Source_write_paths'])
for name in stage['exact_Source_write_paths']:
    assert git('show',code+':'+name) == (root/name).read_bytes()
    if name in overrides:
        assert git('show',stage['prior_checkpoint']+':'+name) == (root/overrides[name]).read_bytes()
    else:
        assert not git('ls-tree','--name-only',stage['prior_checkpoint'],'--',name)
for name in ['NEXT-PROMPT.md','HANDOFF.md','FINDINGS.md']:
    assert (root/name).read_bytes() == git('show',code+':'+name),name
report = read(runtime/'checked.json')
publication = read(work/'PUBLICATION-VERIFIED.json')
actual = read(work/'PUBLICATION-ACTUAL-RUN.json')
assert publication['actual_session'] == actual['actual_session'] == source_receipt['publication_actual_session'] == 72804
assert publication['actual_terminal'] and actual['actual_terminal'] and publication['actual_terminal_exit'] == actual['actual_terminal_exit'] == 0
assert actual['preparer_actual_session'] == 1550 and actual['preparer_terminal_exit'] == 0
assert report == read(runtime/'results.json') and report['checks'] == publication['checks']
assert [item['total_axiom_reports'] for item in report['checks']] == [743,2,338,743,743]
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['sorryAx'] and not item['nonstandard_axioms'] for item in report['checks'])
assert report['all_five_gates_passed'] and report['source_pins_unchanged']
assert [item['declaration_checks'] for item in report['checks']] == [0,1,0,0,0]
assert report['definition_checks'] == 1 and report['definition_axiom_credit'] == 0
assert report['audited_theorems'] == publication['audited_theorems'] == source_receipt['audited_theorems'] == 100250
assert (report['new_public_theorems'],report['new_private_theorems'],report['new_theorem_declarations'],report['new_prop_definitions']) == (2,0,2,0)
for field in ['all_original_eager_worker_query_admissions_proved','original_eager_worker_all_calls_Seeds_propagation_proved','complete_eager_worker_query_log_proved','native_inhabitance_proved','guard_truth_proved','joint_finite_completion_proved','haskell_changed']:
    assert not report[field],field
public_pins = json.loads(verify(runtime/'source-pins.json',publication['source_pins_sha256']))
verify(runtime/'checked.json',publication['checked_sha256'])
verify(runtime/'results.json',publication['results_sha256'])
assert len(public_pins) == publication['pins_independently_reverified'] == 9183
for name,record in public_pins.items():
    verify(root/name,record)
for entry in stage['private_subsets']+stage['rejected_checks']:
    receipt_path = entry.get('verified_receipt',entry.get('receipt'))
    receipt = read(root/receipt_path)
    private_actual = read(root/entry['actual_receipt'])
    private_run = base/entry['runtime']
    assert receipt['actual_session'] == private_actual['actual_session'] == entry['actual_session']
    result = json.loads(verify(private_run/'results.json',receipt['results_sha256']))
    assert result['checks'] == receipt['checks']
    if entry['actual_session'] == 80865:
        assert receipt['actual_terminal_exit'] == private_actual['actual_terminal_exit'] == 0
        assert receipt['proof_credit'] and result == read(private_run/'checked.json')
        assert result['checks'][0]['axiom_groups'] == 2 and result['checks'][0]['declaration_checks'] == 1
        assert receipt['selected_control_manifest_sha256'] == '99435771d6d05503a01a8cb1963c37682c9daecfbb5f8f8b1a4c8466a38681e1'
    else:
        assert entry['actual_session'] == 60181 and receipt['actual_terminal_exit'] == private_actual['actual_terminal_exit'] == 1
        assert not receipt['proof_credit'] and receipt['credited_public_reports'] == 0 and result['checks'][0]['sorryAx']
        assert not (private_run/'checked.json').exists()
    private_pins = json.loads(verify(private_run/'source-pins.json',receipt['source_pins_sha256']))
    assert len(private_pins) == receipt['pins_independently_reverified'] == entry['pins']
    for name,record in private_pins.items():
        historical(name,record)
baseline = read(root/stage['source_baseline_path'])
assert len(baseline['sources']) == 6284 and len(baseline['toolchain']) == 4
assert len(set(baseline['sources'])-set(overrides)) == stage['old_other_Source_files_byte_exact'] == 6283
for name,record in {**baseline['sources'],**baseline['toolchain']}.items():
    historical(name,record)
components = stage['components']
for item in components:
    packet(base/item['packet'],item['manifest_sha256'])
    current = verify(root/item['source_path'],{'sha256':item['raw_sha256'],'bytes':item['raw_bytes']})
    assert current == (base/item['packet']/item['source']).read_bytes()
    for filename,digest in item['headers'].items():
        data = verify(base/item['packet']/filename,digest).rstrip()
        assert current.count(data) == 1 and re.match(rb'\s*:=',current[current.index(data)+len(data):])
        if b'def observe' not in data:
            assert re.match(rb'\s*:= by',current[current.index(data)+len(data):])
assert len(components) == 1
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes() == (work/'IMPORTS.lean.txt').read_bytes()+(root/overrides['lean/MicroCFTA/Audit.lean']).read_bytes()+b'\n'+(work/'PUBLIC-PROBES.lean.txt').read_bytes()
assert len((work/'IMPORTS.lean.txt').read_bytes()) == 72 and len((root/overrides['lean/MicroCFTA/Audit.lean']).read_bytes()) == 436254
bindings = read(archive_control/'prior-bindings.json')
for filename,key in [('manifest.json','prior_manifest_sha256'),('checkpoint.json','prior_checkpoint_json_sha256')]:
    data = verify(prior_archive/filename,bindings[key])
    assert git('show',stage['prior_checkpoint']+':'+str((prior_archive/filename).relative_to(root))) == data
old_pins = json.loads(gzip.decompress((prior_archive/'source-pins.json.gz').read_bytes()))
assert {n:v['sha256'] for n,v in baseline['sources'].items()} == {n:v for n,v in old_pins.items() if n.startswith('lean/MicroCFTA/') and n.endswith('.lean')}
for name,record in old_pins.items():
    historical(name,record)
request = read(work/(board_prefix+'request.json'))
canonical = read(work/(board_prefix+'canonical.json'))
assert canonical['verified']
post = canonical.get('post',canonical)
assert post['id'] == request['request_id'] == '99e6ddde-00c7-4cf4-9f47-9a455b92b37a' and post['sequence'] == 1541
for key,expected in [('author',request['username']),('thread_id',request['thread_id']),('post_type',request['post_type']),('content',request['content']),('metadata',request['metadata'])]:
    assert post[key] == expected,key
assert post['metadata']['source'] == code and not post['metadata']['joint_finite_completion_proved']
cleanup = read(work/'COMBINED-TMP-CLEANUP.json')
assert cleanup['all_targets_removed'] and cleanup['normal_cache_preserved'] and cleanup['unknown_tmp_entries_preserved'] and cleanup['no_cache_data_copied']
assert len(cleanup['runs']) == cleanup['owned_terminal_directories'] == 3
cumulative = 6617217957
for entry,pair in zip(cleanup['runs'],[(60181,'20261118-child-dispatch-query-seeds-check'),(80865,'20261118-child-dispatch-query-seeds-repair-check'),(72804,runtime.name)]):
    assert (entry['actual_session'],entry['runtime']) == pair
    assert entry['path'] == read(base/entry['runtime']/'objects.json')['path']
    assert entry['owned_terminal_only'] and entry['normal_cache_preserved'] and entry['all_targets_removed'] and entry['no_cache_data_copied']
    assert not entry['live_process_references'] and not entry['process_scan_errors']
    assert not Path(entry['path']).exists() and not Path(entry['path']).is_symlink()
    assert entry['prior_cumulative_removed_bytes'] == cumulative
    cumulative += entry['regular_bytes_removed']
    assert entry['cumulative_removed_bytes'] == cumulative
assert cumulative == cleanup['cumulative_removed_bytes'] == 6618729861
assert cleanup['regular_bytes_removed_this_batch'] == sum(e['regular_bytes_removed'] for e in cleanup['runs']) == 1511904
assert cleanup['symlinks_removed_this_batch'] == sum(e['symlinks_removed'] for e in cleanup['runs']) == 18954
assert cleanup['normal_cache_targets'] == 6319 and cleanup['normal_target_stat_sha256'] == 'f47b8ed2d753b032cd6c3fb36ac7592b4bffce5bf69b84d037d73d666e47229f'
start = read(work/'START.json')
assert start['expected_public_reports'] == 2
assert start['new_private_helpers'] == 0 and start['new_definitions'] == 1 and start['full_goal_remains_open']
resume = read(work/'RESUME-AUTHORIZATION.json')
assert resume['manual_work_explicitly_authorized'] and resume['earlier_usage_pause_lifted'] and not resume['goal_operation_performed'] and not resume['goal_completion_claimed']
usage = read(work/'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int,float] and 0 <= percent <= 100 and usage['current_usage_not_measured']
assert code in (work/'LIVE-HANDOFF.md').read_text()
future = read(work/'FUTURE-NATIVE-PROJECTION-ROOT-REVIEW.json')
assert future['source62_credit'] == 0 and future['outside_source62_batch']
roots = read(archive_control/'selection-roots.json')
additional = read(archive_control/'archive-additional-roots.json')
assert len(roots) == len(set(roots)) == 12 and len(additional) == 2
for extra in additional:
    assert extra['current_batch_theorem_credit'] == 0 and not extra['private_runtime_selected']
    packet(base/extra['root'],extra['sha256'])
    roots.append(extra['root'])
assert len(roots) == len(set(roots)) == 14 and prior_archive.name not in roots
assert all((base/name).is_dir() and not (base/name).is_symlink() for name in roots)
for header in read(archive_control/'original-header-files.json'):
    assert sha((root/header['path']).read_bytes()) == sha((root/header['original']).read_bytes()) == header['sha256']
for name in ['assemble.py','finalize.py','verify.py','commit-checkpoint.py']:
    ast.parse((archive_control/name).read_text())
source_pins = {n:v for n,v in public_pins.items() if n.startswith('lean/MicroCFTA/') and n.endswith('.lean')}
assert len(source_pins) == 6285
selected = sorted(str((base/name).relative_to(root)) for name in roots)
tree = hashlib.sha256()
for name,digest in sorted(source_pins.items()):
    tree.update(name.encode()+b'\0'+digest.encode()+b'\n')
config = dict(report)
config.update(checked_code=code,prior_checkpoint=stage['prior_checkpoint'],public_run=str(runtime),public_gates=5,
    explicit_reports=743,board_prefix=board_prefix,board_post_id=post['id'],board_sequence=post['sequence'],
    source_tree_sha256=tree.hexdigest(),old_other_Source_files_byte_exact=6283,
    known_cumulative_tmp_removed_bytes=cumulative,cleanup_receipt='COMBINED-TMP-CLEANUP.json',removed_regular_bytes=1511904,removed_symlinks=18954,
    historical_primary_usage_percent=percent,historical_primary_usage_checked_at=usage['checked_at'],current_usage_not_measured=True,
    prior_immutable_archive=prior_archive.name,prior_manifest_sha256=bindings['prior_manifest_sha256'],
    actual_failed_private_session=60181,actual_selected_private_session=80865,actual_publication_session=72804,actual_source_commit_session=provenance['actual_session'],
    executed_source_commit_control=commit_control.name,source_commit_control_bound_after_final_publication=True,
    old_usage_pause_reintroduced=False,persistent_goal_control_status=resume['persistent_goal_control_status'],work_authorized_by_explicit_user_resume=True,
    goal_active=False,goal_completion_claimed=False,additional_frozen_roots=additional,additional_frozen_roots_theorem_credit=0,future_Source63_runtime_selected=False)
skipped = sorted(str(p.relative_to(root)) for p in base.iterdir() if p.is_dir() and p.name.startswith(('20261117-','20261118-')) and str(p.relative_to(root)) not in selected)
review = dict(selected_roots=14,base_roots=12,additional_frozen_roots=additional,fresh_public_reports=2,inherited_reports=535,combined_reports=537,
    new_public_theorems=2,new_private_theorems=0,new_definitions=1,resource_owner_reports_inherited=264,current_batch_compiler_failures=[60181],
    failed_compiler_credit=0,successful_private_and_public_runs_preserved=[80865,72804],
    all_root_documents_preserved_as_suffix=True,future_Source63_theorem_credit=0,future_Source63_runtime_selected=False,joint_finite_completion_proved=False)
note = (archive_control/'checkpoint-note.md').read_text()
for key,value in {'THEOREMS':report['audited_theorems'],'PINS':publication['pins_independently_reverified'],'REMOVED':1511904,'SYMLINKS':18954,'CLEANUP':cumulative,'USAGE':percent,'BOARD':post['sequence']}.items():
    note = note.replace('{{'+key+'}}',str(value))
assert set(re.findall(r'\{\{(.*?)\}\}',note)) == {'TIME','TREE','CODE'}
outputs = {'checkpoint-config.json':config,'archive-roots.json':selected,'skipped-published-roots.json':skipped,'selection-review.json':review}
assert not archive.exists() and all(not (work/name).exists() for name in outputs)
# Root writes Work outputs only after every read-only gate passes.
for name,value in outputs.items():
    (work/name).write_text(json.dumps(value,indent=2)+'\n')
(work/'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code':code,'archive':archive.name,'roots':14,'board_sequence':post['sequence'],'fresh_public_reports':2,'inherited_reports':535,'combined_reports':537,'current_usage_not_measured':True}))
