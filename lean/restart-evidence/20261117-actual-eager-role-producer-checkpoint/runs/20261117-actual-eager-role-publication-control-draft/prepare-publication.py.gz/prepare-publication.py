from pathlib import Path
import hashlib
import json
import re
import shlex
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
work = Path(__file__).parent
assert work.name == '20261117-actual-eager-role-producer-work'
prior_run = base / '20261117-shared-child-and-root-gate-publication'
prior_archive = base / '20261117-shared-child-and-root-gate-checkpoint'
runtime = base / '20261117-actual-eager-role-producer-publication'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
audit_name = 'lean/MicroCFTA/Audit.lean'
sha = lambda data: hashlib.sha256(data).hexdigest()
stage = json.loads((work / 'SOURCES-NORMAL-STAGING.json').read_text())
components = stage['components']
assert len(components) == 2
assert {c['module'] for c in components} == {
    'SourceSynthesisObservedChildProgramSlots',
    'SourceSynthesisActualEagerProgramFragmentRoles'}
assert {c['module']: c['raw_sha256'] for c in components} == {
    'SourceSynthesisObservedChildProgramSlots':
        'c4d32ba0d724ef610d8f9a3d4c80d5ee6753e8cbb2c10772f5d85d8318ded949',
    'SourceSynthesisActualEagerProgramFragmentRoles':
        'd0f62da80fcbf4db41c056ad98ecca1cd63b17a3bb4f1c0e1fe394d888706fd1'}
assert stage['owner_normal_installed'] is True
owner_check_name = stage.get('owner_check', stage.get('owner_normal_check',
    '20261117-actual-eager-return-joint-program-roles-check'))
assert re.fullmatch(r'2026[0-9]{4}-[a-z0-9-]+', owner_check_name)
owner_check = base / owner_check_name
owner_selection = json.loads((owner_check / 'selection.json').read_text())
owner_report = json.loads((owner_check / 'checked.json').read_text())
assert owner_report['owner_append_checked'] and all(owner_report['passed'])
assert len(owner_report['checks']) == 2
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics']
    and not c['sorryAx'] for c in owner_report['checks'])
assert owner_report['checks'][1]['name'] == 'owner-and-appends'
assert owner_report['checks'][1]['total_axiom_reports'] == 252
assert owner_report['limits'] == {
    'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
assert owner_report['old_owner_entire_exact_contiguous_block']
assert owner_report['old_owner_proof_bodies_and_limits_unchanged']
assert owner_report['new_proof_maxHeartbeats'] == 200000
assert owner_selection['owner'] == owner_name
assert owner_selection['reports'] == 252
assert owner_selection['previous_owner_reports'] == 250
assert owner_selection['new_private_reports'] == 2
assert owner_selection['runtime_fuels_unchanged']
assert owner_selection['old_owner_entire_exact_contiguous_block']
assert owner_selection['all_new_proofs_maxHeartbeats'] == 200000
before_owner = (work / 'OWNER-BEFORE.lean.txt').read_bytes()
before_audit = (work / 'AUDIT-BEFORE.lean.txt').read_bytes()
assert len(before_owner) == owner_selection['old_owner_bytes'] == 2432670
assert sha(before_owner) == owner_selection['old_owner_sha256'] == stage['owner_base_sha256']
owner = (root / owner_name).read_bytes()
assert sha(owner) == owner_selection['assembled_sha256']
offset = owner_selection['old_owner_offset']
assert owner[offset:offset + len(before_owner)] == before_owner
assert sha(owner[:offset]) == owner_selection['import_prefix_sha256']
assert owner[:offset] == b'import MicroCFTA.SourceSynthesisActualEagerProgramFragmentRoles\n'
assert sha(owner[offset + len(before_owner):]) == owner_selection['append_sha256']
old_probes = (work / 'PreviousOwnerProbes250.lean.txt').read_bytes()
assert old_probes.count(b'#print axioms ') == 250
proof_source = owner_check / 'source/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
proof = proof_source.read_bytes()
assert proof.startswith(owner + b'\n' + old_probes)
new_owner_probes = proof[len(owner) + 1 + len(old_probes):]
assert new_owner_probes.count(b'#print axioms ') == 2
assert re.findall(rb'^#print axioms ([A-Za-z0-9_.]+)$', new_owner_probes, re.M) == [
    b'MicroCFTA.SourcePruningEnumerationSharedEagerReservation.actual_eager_child_return_program_slots',
    b'MicroCFTA.SourcePruningEnumerationSharedEagerReservation.actual_eager_child_return_program_roles']
assert proof.count(b'#print axioms ') == 252
owner_log = owner_check / 'owner-and-appends.txt'
owner_output = owner_log.read_text()
owner_groups = [set(x.strip() for x in group.split(',') if x.strip())
    for group in re.findall(r'depends on axioms:\s*\[([^]]*)\]', owner_output, re.S)]
owner_free = len(re.findall(r'does not depend on any axioms', owner_output))
assert len(owner_groups) + owner_free == 252
assert not (set().union(*owner_groups) - {'propext', 'Classical.choice', 'Quot.sound'})
assert 'sorryAx' not in owner_output and not re.search(r': error(?:\(|:)', owner_output)
owner_pins = json.loads((owner_check / 'source-pins.json').read_text())
assert owner_pins[owner_name] == sha(before_owner)
assert owner_pins[audit_name] == sha((root / audit_name).read_bytes())
for name, digest in owner_pins.items():
    data = before_owner if name == owner_name else (root / name).read_bytes()
    assert sha(data) == digest, name

prior = json.loads((prior_run / 'checked.json').read_text())
assert len(prior['checks']) == 5 and all(c['exit'] == 0 and not c['nonstandard_axioms']
    and not c['diagnostics'] and not c['sorryAx'] for c in prior['checks'])
assert prior['source_files'] == 6246 and prior['owner_resource_probes'] == 250
assert prior['resource_and_component_probes'] == 377
assert prior['independent_reports'] == 247 and prior['individual_reports'] == 652
baseline = json.loads((work / 'baseline-source-pins.json').read_text())
assert len(baseline) == 6246
assert {str(p.relative_to(root)) for p in (root / 'lean/MicroCFTA').glob('*.lean')} == (
    set(baseline) | {c['source_path'] for c in components})
assert len(list((root / 'lean/MicroCFTA').glob('*.lean'))) == 6248
for name, digest in baseline.items():
    data = before_audit if name == audit_name else before_owner if name == owner_name else (root / name).read_bytes()
    assert sha(data) == digest, name
assert len(baseline) - 2 == 6244
imports = ''.join('import MicroCFTA.' + c['module'] + '\n' for c in components).encode()
public = (work / 'PUBLIC-PROBES.lean.txt').read_bytes()
assert public.count(b'#print axioms ') == 2
audit = (root / audit_name).read_bytes()
assert audit.startswith(imports + before_audit)
assert audit[len(imports) + len(before_audit):].strip() == public.strip()
assert sum(line.startswith(b'import ') for line in audit.splitlines()) == 5248
assert audit.count(b'#print axioms ') == 654

runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-eager-role-publication-'))
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
(runtime / 'PUBLIC-PROBES.lean.txt').write_bytes(public)
commands = []
strict_sources = []
normal_count = 0
for component in components:
    normal = root / component['source_path']
    assert sha(normal.read_bytes()) == component['raw_sha256']
    helpers = re.findall(r'^private theorem ([A-Za-z0-9_]+)', normal.read_text(), re.M)
    namespace = component.get('namespace', component['module'])
    probes = ''
    for name in helpers + [component['theorem']]:
        qname = 'MicroCFTA.' + namespace + '.' + name
        probes += '#check @' + qname + '\n#print axioms ' + qname + '\n'
    normal_count += len(helpers) + 1
    source = runtime / 'source/MicroCFTA' / normal.name
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_bytes(normal.read_bytes() + b'\n' + probes.encode())
    (runtime / (component['module'] + '-PROBES.lean.txt')).write_text(probes)
    strict_sources.append(source)
    commands.append(['lake', 'env', 'lean', '-j1', '-DwarningAsError=true', '-R',
        str(source.parent.parent), '-o', str(objects / (component['module'] + '.olean')), str(source)])
assert normal_count == 13
independent = runtime / 'IndependentProbes.lean'
independent.write_bytes(imports + (prior_run / 'IndependentProbes.lean').read_bytes() + b'\n' + public)
assert independent.read_bytes().count(b'#print axioms ') == 249
binding = {
    'prior_checkpoint': '1cd951d8db17fb030f1f382dff7177ce4ef5369b',
    'prior_archive_manifest_sha256': sha((prior_archive / 'manifest.json').read_bytes()),
    'prior_checked_sha256': sha((prior_run / 'checked.json').read_bytes()),
    'prior_pins_sha256': sha((prior_run / 'source-pins.json').read_bytes()),
    'prior_source_files': 6246, 'prior_resource_reports': 377,
    'prior_owner_reports_replaced_by_fresh_preflight': 250,
    'inherited_reports': 127, 'fresh_owner_preflight_reports': 252,
    'fresh_strict_normal_reports': 13, 'fresh_reports_this_batch': 265,
    'combined_resource_and_component_reports': 392,
    'strict_gate_actual_reports': 13,
    'old_non_audit_non_owner_sources_byte_exact': 6244,
    'old_owner_bytes_retained_contiguously': 2432670,
    'old_audit_retained_after_two_imports': True,
    'old_toolchain_and_proof_inputs_reverified': True}
assert binding['inherited_reports'] == prior['resource_and_component_probes'] - prior['owner_resource_probes']
assert binding['fresh_reports_this_batch'] == 252 + normal_count
assert binding['combined_resource_and_component_reports'] == 127 + 252 + normal_count
(runtime / 'INHERITANCE-SELECTION.json').write_text(json.dumps(binding, indent=2) + '\n')
preflight_files = [owner_check / name for name in [
    'checked.json', 'checks.json', 'selection.json', 'source-pins.json', 'check.py', 'owner-and-appends.txt']]
preflight_files += [proof_source, work / 'OWNER-BEFORE.lean.txt', work / 'PreviousOwnerProbes250.lean.txt']
preflight = {
    'check': owner_check_name,
    'artifacts': {str(p.relative_to(root)): sha(p.read_bytes()) for p in preflight_files},
    'normal_owner_sha256': sha(owner), 'assembled_sha256': owner_selection['assembled_sha256'],
    'proof_source_sha256': sha(proof), 'old_owner_sha256': sha(before_owner),
    'preflight_audit_sha256': owner_pins[audit_name], 'old_owner_offset': offset,
    'reports': 252, 'fresh_this_batch_before_publication': True,
    'recompiled_in_publication_strict_gate': False,
    'axiom_strings_replayed': False}
(runtime / 'OWNER-FRESH-PREFLIGHT.json').write_text(json.dumps(preflight, indent=2) + '\n')
strict = runtime / 'strict-new-and-bind.py'
strict.write_text('''from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

root = Path('/home/tritlo/Code/mcfta')
runtime = Path(__file__).parent
prior = root / 'lean/restart-evidence/20261117-shared-child-and-root-gate-publication'
archive = root / 'lean/restart-evidence/20261117-shared-child-and-root-gate-checkpoint'
work = root / 'lean/restart-evidence/20261117-actual-eager-role-producer-work'
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
audit_name = 'lean/MicroCFTA/Audit.lean'
sha = lambda data: hashlib.sha256(data).hexdigest()
selection = json.loads((runtime / 'INHERITANCE-SELECTION.json').read_text())
preflight = json.loads((runtime / 'OWNER-FRESH-PREFLIGHT.json').read_text())
before_owner = (work / 'OWNER-BEFORE.lean.txt').read_bytes()
before_audit = (work / 'AUDIT-BEFORE.lean.txt').read_bytes()
assert sha((archive / 'manifest.json').read_bytes()) == selection['prior_archive_manifest_sha256']
committed = subprocess.check_output(['git', 'show', selection['prior_checkpoint'] + ':'
    + str((archive / 'manifest.json').relative_to(root))], cwd=root)
assert committed == (archive / 'manifest.json').read_bytes()
subprocess.run(['python3', str(archive / 'verify.py')], check=True)
records = json.loads((archive / 'archived-inputs.json').read_text())
for name in ['checked.json', 'source-pins.json']:
    path = prior / name
    record = next(item for item in records if item['original'] == str(path))
    archived = (archive / record['archived']).read_bytes()
    if record['gzip']:
        archived = gzip.decompress(archived)
    assert archived == path.read_bytes()
assert sha((prior / 'checked.json').read_bytes()) == selection['prior_checked_sha256']
assert sha((prior / 'source-pins.json').read_bytes()) == selection['prior_pins_sha256']
for name, digest in json.loads((prior / 'source-pins.json').read_text()).items():
    data = before_audit if name == audit_name else before_owner if name == owner_name else (root / name).read_bytes()
    assert sha(data) == digest, name
for name, digest in preflight['artifacts'].items():
    assert sha((root / name).read_bytes()) == digest, name
check = root / 'lean/restart-evidence' / preflight['check']
result = json.loads((check / 'checked.json').read_text())
assert result['owner_append_checked'] and all(result['passed'])
assert len(result['checks']) == 2 and result['checks'][1]['total_axiom_reports'] == 252
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics']
    and not c['sorryAx'] for c in result['checks'])
assert sha(before_owner) == preflight['old_owner_sha256']
owner = (root / owner_name).read_bytes()
assert sha(owner) == preflight['normal_owner_sha256'] == preflight['assembled_sha256']
offset = preflight['old_owner_offset']
assert owner[offset:offset + len(before_owner)] == before_owner
owner_selection = json.loads((check / 'selection.json').read_text())
assert owner_selection['assembled_sha256'] == sha(owner)
assert owner_selection['old_owner_sha256'] == sha(before_owner)
assert owner_selection['old_owner_bytes'] == len(before_owner) == 2432670
assert owner_selection['reports'] == 252 and owner_selection['new_private_reports'] == 2
old_probes = (work / 'PreviousOwnerProbes250.lean.txt').read_bytes()
proof = (check / 'source/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean').read_bytes()
assert sha(proof) == preflight['proof_source_sha256']
assert proof.startswith(owner + b'\\n' + old_probes)
assert old_probes.count(b'#print axioms ') == 250 and proof.count(b'#print axioms ') == 252
for name, digest in json.loads((check / 'source-pins.json').read_text()).items():
    data = before_owner if name == owner_name else (root / name).read_bytes()
    assert sha(data) == digest, name
assert sha((root / audit_name).read_bytes()) == preflight['preflight_audit_sha256']
output = (check / 'owner-and-appends.txt').read_text()
groups = [set(x.strip() for x in group.split(',') if x.strip())
    for group in re.findall(r'depends on axioms:\\s*\\[([^]]*)\\]', output, re.S)]
free = len(re.findall(r'does not depend on any axioms', output))
assert len(groups) + free == 252
assert not (set().union(*groups) - {'propext', 'Classical.choice', 'Quot.sound'})
assert 'sorryAx' not in output and not re.search(r': error(?:\\(|:)', output)
assert selection['inherited_reports'] == 127
assert selection['fresh_owner_preflight_reports'] == 252
assert selection['fresh_strict_normal_reports'] == 13
print(json.dumps({'inherited_reports_verified': 127,
                  'fresh_owner_reports_verified_this_batch': 252,
                  'actual_fresh_strict_reports_expected': 13,
                  'owner_recompiled_here': False}), flush=True)
''' + 'commands = ' + repr(commands) + '\nfor command in commands:\n    subprocess.run(command, check=True)\n')
template = (prior_run / 'check.py').read_text()
driver = template[:template.index('\njobs =')]
jobs = [('public-build', 'exec lake build', 0),
    ('strict-new-components-and-prior-bindings', 'exec python3 ' + shlex.quote(str(strict)), 13),
    ('independent-imports', 'exec lake env lean -j1 -DwarningAsError=true ' + shlex.quote(str(independent)), 249),
    ('audit-build', 'exec lake build MicroCFTA.Audit', 0),
    ('audit-strict', 'exec lake env lean -j1 -DwarningAsError=true MicroCFTA/Audit.lean', 654)]
driver += '\njobs = ' + repr(jobs) + '''
for name, command, count in jobs:
    run(name, command, count)
assert len(checks) == 5
assert all(c['exit'] == 0 and not c['nonstandard_axioms'] and not c['diagnostics'] and not c['sorryAx']
           and (not job[2] or c['total_axiom_reports'] == job[2]) for c, job in zip(checks, jobs))
match = re.search(r'Checked axiom dependencies of (\\d+) MicroCFTA theorems\\.', (runtime / 'audit-strict.txt').read_text())
assert match
'''
report = dict(prior)
for name in ['checks', 'limits', 'at', 'audited_theorems']:
    report.pop(name, None)
report.update(source_files=6248, direct_audit_imports=5248, individual_reports=654,
    independent_reports=249, resource_and_component_probes=392,
    fresh_resource_component_reports=265, inherited_resource_component_reports=127,
    fresh_owner_preflight_reports=252, fresh_strict_normal_reports=13,
    actual_publication_strict_reports=13,
    resource_component_evidence='252 fresh owner reports checked in this batch before publication, 13 fresh normal-module strict reports, and 127 prior reports with archive/source/toolchain bindings',
    owner_preflight_evidence=preflight, owner_recompiled_in_publication_strict_gate=False,
    new_component_reports=15, new_theorem_reports=15, new_modules=2, new_public_theorems=2,
    new_private_component_reports=13, new_public_component_reports=2,
    new_relation_declaration_checks=0, owner_resource_probes=252, previous_owner_resource_probes=250,
    old_non_audit_non_owner_source_files_byte_exact=6244,
    old_non_audit_source_files_byte_exact=6244,
    entire_previous_resource_owner_byte_exact=False,
    old_owner_bytes_preserved_contiguously=2432670, old_owner_offset=offset,
    old_owner_proof_bodies_unchanged=True, old_owner_proof_limits_unchanged=True,
    actual_five_fuel_annotation_old_program_slots_observer_proved=True,
    actual_eager_fragment_roles_at_supplied_fuels_proved=True,
    source_frame_actual_return_old_program_slots_proved=True,
    source_frame_joint_actual_eager_return_program_roles_proved=True,
    generic_packet_only_2c6_closed=False,
    whole_history_program_mark_production_proved=False,
    source_to_arbitrary_current_row_fields_proved=False,
    source_type_marker_class_consistency_proved=False, joint_finite_completion_proved=False,
    haskell_refolded_root_outer_gate_correspondence_proved=False,
    haskell_changed=False, proof_limits='unchanged defaults; original owner proof settings retained')
driver += 'report = ' + repr(report) + '\n'
driver += '''report.update(checks=checks, limits=limits, at=datetime.datetime.now().astimezone().isoformat(),
              audited_theorems=int(match.group(1)))
(runtime / 'checked.json').write_text(json.dumps(report, indent=2) + '\\n')
print(json.dumps(report), flush=True)
'''
(runtime / 'check.py').write_text(driver)
files = list((root / 'lean/MicroCFTA').glob('*.lean'))
files += [root / name for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']]
files += [p for p in runtime.iterdir() if p.is_file()] + strict_sources
files += [Path(__file__), work / 'SOURCES-NORMAL-STAGING.json', work / 'baseline-source-pins.json',
    work / 'AUDIT-BEFORE.lean.txt', work / 'OWNER-BEFORE.lean.txt', work / 'PUBLIC-PROBES.lean.txt',
    prior_run / 'checked.json', prior_run / 'source-pins.json', prior_archive / 'manifest.json']
files += preflight_files
(runtime / 'source-pins.json').write_text(json.dumps({str(p.relative_to(root)): sha(p.read_bytes()) for p in files}, indent=2) + '\n')
print(json.dumps({'run': str(runtime), 'gates': 5, 'fresh_owner_preflight_reports': 252,
    'actual_strict_reports': 13, 'fresh_reports_this_batch': 265, 'inherited_reports': 127,
    'combined_resource_and_component_reports': 392, 'independent_reports': 249,
    'audit_reports': 654, 'owner_recompiled_in_strict_gate': False, 'objects': str(objects)}))
