from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root/'lean/restart-evidence'
control = base/'20261118-fold-and-terminal-query-seeds-publication-control-draft'
stage_control = base/'20261118-fold-and-terminal-query-seeds-staging-control-draft'
work = base/'20261118-fold-query-seeds-work'
runtime = base/'20261118-fold-and-terminal-query-seeds-publication'
prior_work = base/'20261118-terminal-query-resources-work'
prior_run = base/'20261118-terminal-and-query-seeds-publication'
prior_archive = base/'20261118-terminal-and-query-seeds-checkpoint'
source_commit = '530a41528e91526e978a954539a81b12fb8d7a60'
assert Path(__file__).resolve().parent == work.resolve()
assert Path(__file__).read_bytes() == (control/'prepare-publication.py').read_bytes()
assert not runtime.exists(), 'Preserve every previous runtime.'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
bound = set()


def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256']if isinstance(record,dict)else record),str(path)
    if isinstance(record,dict)and 'bytes'in record:
        assert len(data) == record['bytes'],str(path)
    bound.add(path)
    return data


def records(value):
    if isinstance(value,list):
        return [(entry.get('file',entry.get('path')),entry)for entry in value]
    if 'files'in value:
        return records(value['files'])
    if 'pins'in value:
        return records(value['pins'])
    return value.items()


for name,record in records(read(control/'MANIFEST.json')['files']):
    verify(control/name,record)
bound.add(control/'MANIFEST.json')
for name,record in records(read(control/'ACTUAL-INPUT-PINS.json')):
    verify(root/name,record)
for name,record in records(read(stage_control/'MANIFEST.json')['files']):
    verify(stage_control/name,record)
bound.add(stage_control/'MANIFEST.json')
stage_bytes = (work/'SOURCES-NORMAL-STAGING.json').read_bytes()
assert stage_bytes == (control/'EXPECTED-STAGE.json').read_bytes()
stage = json.loads(stage_bytes)
assert stage['status'] == 'SOURCE_NORMAL_STAGING_COMPLETED'
assert stage['source_baseline'] == source_commit and stage['normal_Source_changed']and not stage['published']
assert (stage['source_files'],stage['audit_imports'],stage['audit_reports'],stage['independent_reports']) == (6284,5284,741,336)
assert (stage['fresh_reports'],stage['inherited_reports'],stage['combined_reports']) == (3,532,535)
assert stage['new_public_theorems'] == 3 and stage['new_private_helpers_transitive'] == 0
assert stage['new_Prop_definitions'] == stage['definition_checks'] == stage['explicit_private_reports'] == 0
assert stage['resource_owner_reports_inherited'] == 264 and stage['fresh_credit_for_old_owner_theorems'] == 0
stage_actual = read(work/'STAGING-ACTUAL-RUN.json')
assert stage_actual['actual_session'] == 30889 and stage_actual['actual_terminal']and stage_actual['actual_terminal_exit'] == 0
assert stage_actual['control_manifest_sha256'] == sha((stage_control/'MANIFEST.json').read_bytes())
assert stage_actual['script_sha256'] == sha((stage_control/'stage-normal-sources.py').read_bytes())
assert stage_actual['normal_source_pins_sha256'] == stage['normal_source_pins_sha256']
assert stage_actual['exact_Source_write_paths'] == stage['exact_Source_write_paths']and stage_actual['git_index_empty']
bound.update([work/'SOURCES-NORMAL-STAGING.json',work/'STAGING-ACTUAL-RUN.json'])
overrides = stage['baseline_overrides']
components = stage['components']
assert len(components) == 2
assert set(overrides) == {item['source_path']for item in components}|{'lean/MicroCFTA/Audit.lean'}


def historical(name, record):
    digest = record['sha256']if isinstance(record,dict)else record
    for path in [root/name,root/overrides.get(name,name)]:
        if path.is_file()and sha(path.read_bytes()) == digest:
            return verify(path,record)
    raise AssertionError(name)


all_checks = stage['private_subsets']+stage['prerequisite_checks']
assert [(entry['actual_session'],entry['expected_reports'],entry['pins'],entry['fresh_public_reports'])for entry in all_checks] == [(15679,3,8926,3),(3921,2,8866,0)]
chosen = {}
for entry in all_checks:
    private_control = base/entry['control']
    verify(private_control/'MANIFEST.json',entry['control_manifest_sha256'])
    for name,record in records(read(private_control/'MANIFEST.json')['files']):
        verify(private_control/name,record)
    run = base/entry['runtime']
    receipt_path,actual_path = root/entry['verified_receipt'],root/entry['actual_receipt']
    receipt,actual = read(receipt_path),read(actual_path)
    assert receipt['actual_session'] == actual['actual_session'] == entry['actual_session']
    assert receipt['actual_terminal']and actual['actual_terminal']
    assert receipt['actual_terminal_exit'] == actual['actual_terminal_exit'] == 0
    assert receipt['runtime'] == actual['runtime'] == run.name
    checked = json.loads(verify(run/'checked.json',receipt['checked_sha256']))
    assert checked == json.loads(verify(run/'results.json',receipt['results_sha256']))
    assert checked['checks'] == receipt['checks']and checked['proof_credit']and checked['source_pins_unchanged']
    assert sum(item['total_axiom_reports']for item in checked['checks']) == entry['expected_reports']
    assert all(item['exit'] == 0 and not item['diagnostics']and not item['sorryAx']and not item['nonstandard_axioms']
        and item['axiom_free_reports'] == item['declaration_checks'] == 0 for item in checked['checks'])
    assert checked['limits'] == {'memory.max':'8589934592','memory.high':'8589934592','memory.swap.max':'0'}
    pins = json.loads(verify(run/'source-pins.json',receipt['source_pins_sha256']))
    assert len(pins) == receipt['pins_independently_reverified'] == entry['pins']
    for name,record in pins.items():
        historical(name,record)
    bound.update([receipt_path,actual_path])
    for item in checked['checks']:
        bound.add(run/(item['name']+'.txt'))
    if entry['name'] == 'combined':
        assert receipt['executed_control'] == actual['executed_control'] == entry['control']
        assert receipt['executed_control_manifest_sha256'] == actual['executed_control_manifest_sha256'] == entry['control_manifest_sha256']
        assert receipt['previously_checked_fold_reports_rebuilt'] == 2 and receipt['additive_credit_for_rebuilt_fold_reports'] == 0
        chosen = {item['module']:item for item in read(private_control/'SELECTION.json')['components']}
assert len(chosen) == 2 and set(stage['compile_order']) == set(chosen)
# The original combined preparer failed before runtime or compiler creation.
preflight_path = root/stage['rejected_preparer_receipt']
preflight = read(preflight_path)
assert preflight['actual_terminal']and preflight['actual_terminal_exit'] == 1
assert not preflight['compiler_started']and not preflight['runtime_or_tmp_created']and preflight['proof_credit'] == 0
assert preflight['actual_tool_chunk'] == 'a1bbf9'
rejected_control = base/preflight['original_control']
verify(rejected_control/'MANIFEST.json',preflight['original_control_manifest_sha256'])
for name,record in records(read(rejected_control/'MANIFEST.json')['files']):
    verify(rejected_control/name,record)
bound.add(preflight_path)
baseline_path = root/stage['source_baseline_path']
baseline_wrapper = read(baseline_path)
assert baseline_wrapper['source_commit'] == source_commit and baseline_wrapper['source_files'] == 6284
baseline = {name:record['sha256']for name,record in baseline_wrapper['sources'].items()}
for name,record in {**baseline_wrapper['sources'],**baseline_wrapper['toolchain']}.items():
    historical(name,record)
current = sorted((root/'lean/MicroCFTA').glob('*.lean'))
assert len(current) == 6284 and {str(path.relative_to(root))for path in current} == set(baseline)
assert len(set(baseline)-set(overrides)) == 6281
normal_pins_path = work/'NORMAL-SOURCE-PINS.json'
normal_pins = json.loads(verify(normal_pins_path,stage['normal_source_pins_sha256']))
assert len(normal_pins) == 6288
for name,record in normal_pins.items():
    verify(root/name,record)
push = read(prior_work/'PUSH-VERIFIED.json')
prior_source = read(prior_work/'SOURCE-COMMIT.json')
prior_publication = read(prior_work/'PUBLICATION-VERIFIED.json')
assert push['source_commit'] == prior_source['source_commit'] == source_commit
assert push['checkpoint_commit'] == push['remote_commit'] == '862d4879e201a8ace8b42b42398be7a5cfa37533'
assert push['actual_push_terminal']and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal']and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
assert prior_publication['actual_session'] == prior_source['publication_actual_session'] == 88140
assert prior_publication['actual_terminal']and prior_publication['actual_terminal_exit'] == 0
assert prior_publication['combined_reports'] == 532 and prior_publication['resource_reports_inherited'] == 264
verify(prior_archive/'manifest.json',push['archive_manifest_sha256'])
subprocess.run(['git','merge-base','--is-ancestor',push['checkpoint_commit'],'HEAD'],cwd=root,check=True)
prior_checked = read(prior_run/'checked.json')
assert prior_checked['all_five_gates_passed']and prior_checked['source_pins_unchanged']
assert (prior_checked['source_files'],prior_checked['independent_reports'],prior_checked['resource_and_component_probes']) == (6284,333,532)
for name,record in read(prior_run/'source-pins.json').items():
    historical(name,record)
bound.update([prior_work/'PUSH-VERIFIED.json',prior_work/'SOURCE-COMMIT.json',prior_work/'PUBLICATION-VERIFIED.json',
    prior_work/'PUBLICATION-ACTUAL-RUN.json',prior_run/'checked.json',prior_run/'source-pins.json',prior_run/'IndependentProbes.lean',
    prior_archive/'manifest.json',prior_archive/'verify.py',prior_archive/'archived-inputs.json'])
raw_sources = {}
public = b''
for item in components:
    original = chosen[item['module']]
    for key in ['module','packet','manifest_sha256','source','raw_sha256','raw_bytes','probe','probe_sha256',
            'public_qnames','expected_axiom_reports','expected_declaration_checks']:
        assert item[key] == original[key],(item['module'],key)
    packet = base/item['packet']
    verify(packet/'MANIFEST.json',item['manifest_sha256'])
    for name,record in records(read(packet/'MANIFEST.json')['files']):
        verify(packet/name,record)
    for filename in ['SOURCE-PINS.json','ADDITIONAL-SOURCE-PINS.json','DEPENDENCY-PINS.json']:
        if (packet/filename).exists():
            for name,record in records(read(packet/filename)):
                historical(name,record)
    raw = verify(root/item['source_path'],{'sha256':item['raw_sha256'],'bytes':item['raw_bytes']})
    assert raw == (packet/item['source']).read_bytes()
    old = verify(root/item['old_snapshot'],{'sha256':item['owner_sha256'],'bytes':item['owner_bytes']})
    assert raw[66:66+len(old)] == old
    appended = [verify(packet/item['append'],item['append_sha256'])]
    if item['module'].endswith('TerminalFoldQueryEvents'):
        parent = base/item['raw_base_packet']
        verify(parent/'MANIFEST.json',item['raw_base_manifest_sha256'])
        for name,record in records(read(parent/'MANIFEST.json')['files']):
            verify(parent/name,record)
        raw_base = verify(parent/item['source'],{'sha256':item['raw_base_sha256'],'bytes':47686})
        appended.insert(0,(parent/'APPEND.lean.txt').read_bytes())
        assert raw_base == (parent/'IMPORTS.lean.txt').read_bytes()+old+appended[0]
        assert raw == raw_base+appended[1]
    else:
        assert raw == (packet/'IMPORTS.lean.txt').read_bytes()+old+appended[0]
    for declarations in appended:
        assert not re.search(rb'set_option\s+(maxHeartbeats|maxRecDepth|warningAsError|linter\.)',declarations)
        assert not re.findall(rb'^private theorem |^(?:private )?(?:def|inductive|structure) ',declarations,re.M)
        assert len(re.findall(rb'^theorem ',declarations,re.M)) == 1
    for header in item['all_headers']:
        full = verify(root/header['file'],header['sha256']).rstrip()
        assert raw.count(full) == 1 and raw[raw.index(full)+len(full):].lstrip().startswith(b':= by')
    assert b'#print axioms 'not in raw and b'#check 'not in raw
    probe = verify(packet/item['probe'],item['probe_sha256'])
    assert re.findall(r'^#print axioms (\S+)',probe.decode(),re.M) == item['public_qnames']
    assert probe.count(b'#print axioms ') == item['expected_axiom_reports']and b'#check 'not in probe
    fixture = base/stage['private_subsets'][0]['runtime']/'source/MicroCFTA'/item['source']
    assert fixture.read_bytes() == raw+b'\n'+probe
    bound.add(fixture)
    raw_sources[item['module']] = raw
    public += probe
assert public.count(b'#print axioms ') == 3 and public == (control/'EXPECTED-PUBLIC-PROBES.lean.txt').read_bytes()
old_audit = verify(root/overrides['lean/MicroCFTA/Audit.lean'],{'sha256':stage['old_audit_sha256'],'bytes':435886})
assert (stage_control/'IMPORTS.lean.txt').read_bytes() == b''
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes() == old_audit+b'\n'+public
assert old_audit.count(b'#print axioms ') == 738
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes().count(b'#print axioms ') == 741
assert sum(line.startswith(b'import ')for line in (root/'lean/MicroCFTA/Audit.lean').read_bytes().splitlines()) == 5284
prior_independent = (prior_run/'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 333
for item in components:
    assert ('import MicroCFTA.'+item['module']+'\n').encode()in prior_independent.splitlines(keepends=True)
resource_owner = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = sha((root/resource_owner).read_bytes())
assert owner_sha == baseline[resource_owner]
normal_objects = root/'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()
edges,active,visited,ordered = {},set(),set(),[]


def walk(module):
    if module in visited:
        return
    assert module not in active,('import cycle',module)
    active.add(module)
    edges[module] = re.findall(r'^import MicroCFTA\.([A-Za-z0-9_]+)\s*$',(root/'lean/MicroCFTA'/(module+'.lean')).read_text(),re.M)
    if module not in chosen:
        assert (normal_objects/(module+'.olean')).is_file(),module
    for child in edges[module]:
        walk(child)
    active.remove(module)
    visited.add(module)
    ordered.append(module)


for module in stage['compile_order']:
    walk(module)
dag = read(control/'TOPOLOGICAL-ORDER.json')
assert edges == dag['direct_imports']and ordered == dag['full_transitive_order']
assert [module for module in ordered if module in chosen] == stage['compile_order']
for name in ['strict-bind.py.txt','publication-driver.py.txt','shadow-compile.py.txt']:
    ast.parse((control/name).read_text())
# Root materializes a fresh publication namespace after every read-only gate passes.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-fold-terminal-seeds-publication-'))
(objects/'MicroCFTA').mkdir()
for obj in normal_objects.glob('*.olean'):
    if obj.stem not in chosen:
        (objects/'MicroCFTA'/obj.name).symlink_to(obj)
for module in chosen:
    assert not (objects/'MicroCFTA'/(module+'.olean')).exists()
(runtime/'objects.json').write_text(json.dumps({'path':str(objects)},indent=2)+'\n')
for module,raw in raw_sources.items():
    fixture = runtime/'source/MicroCFTA'/(module+'.lean')
    fixture.parent.mkdir(parents=True,exist_ok=True)
    fixture.write_bytes(raw)
    bound.add(fixture)
fresh_imports = ''.join('import MicroCFTA.'+module+'\n'for module in stage['compile_order']).encode()
(runtime/'FreshPublicProbes.lean').write_bytes(fresh_imports+public)
(runtime/'IndependentProbes.lean').write_bytes(prior_independent+b'\n'+public)
for src,dst in [('strict-bind.py.txt','strict-new-and-bind.py'),('publication-driver.py.txt','check.py'),('shadow-compile.py.txt','shadow-compile.py')]:
    (runtime/dst).write_bytes((control/src).read_bytes())
(runtime/'REPORT-BASE.json').write_bytes((control/'REPORT-BASE.json').read_bytes())
inheritance = {'compile_order':stage['compile_order'],'definition_names':[],'prior_checkpoint':push['checkpoint_commit'],
    'prior_archive_manifest_sha256':push['archive_manifest_sha256'],'prior_checked_sha256':sha((prior_run/'checked.json').read_bytes()),
    'prior_pins_sha256':sha((prior_run/'source-pins.json').read_bytes()),'stage_sha256':sha(stage_bytes),
    'baseline_sha256':sha(baseline_path.read_bytes()),'baseline_path':str(baseline_path.relative_to(root)),
    'baseline_overrides':overrides,'override_digests':{name:sha((root/path).read_bytes())for name,path in overrides.items()},
    'inherited_reports':532,'fresh_reports':3,'combined_reports':535,'resource_owner_sha256':owner_sha,
    'resource_owner_reports_inherited':264,'owner_preflight_reports_fresh_this_batch':0,'new_private_helpers':0,
    'Prop_declaration_checks':0,'Prop_axiom_credit':0,'actual_private_sessions':[3921,15679],
    'fold_recheck_not_double_counted':True,'fresh_owner_theorem_credit':0,'cache_data_copied':False}
(runtime/'INHERITANCE-SELECTION.json').write_text(json.dumps(inheritance,indent=2)+'\n')
bound.update([Path(__file__),baseline_path,control/'TOPOLOGICAL-ORDER.json'])
bound.update(current)
bound.update(path for path in runtime.iterdir()if path.is_file())
(runtime/'source-pins.json').write_text(json.dumps({str(path.relative_to(root)):sha(path.read_bytes())for path in sorted(bound)},indent=2,sort_keys=True)+'\n')
print(json.dumps({'runtime':str(runtime),'gates':5,'fresh_modules':2,'fresh_reports':3,'inherited_reports':532,
    'combined_reports':535,'source_files':6284,'audit_imports':5284,'audit_reports':741,'independent_reports':336,'normal_Source_changed':False}))
