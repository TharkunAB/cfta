{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE TypeApplications #-}

module Data.CFTASpec (spec) where

import Control.Monad (forM_)
import Data.Functor.Identity (runIdentity)
import Data.Monoid (Sum (..))
import Data.Proxy (Proxy (Proxy))
import qualified Data.Tree as Tree
import Data.Typeable (typeRep)
import GHC.Generics (Generic)
import System.Timeout (timeout)
import Test.Hspec (Spec, describe, expectationFailure, it, shouldBe, shouldMatchList, shouldNotBe, shouldSatisfy)

import Data.CFTA (Transition (Transition), statesAt)
import qualified Data.CFTA as Automaton
import Data.CFTA.Constraint (Guard (..), equalitiesHold, equalityConstraint, noConstraint, residual, semanticConstraint)
import qualified Data.CFTA.Enumeration as Enumeration
import Data.CFTA.Equality.Constraint (mkEqConstraints)
import qualified Data.CFTA.Generic as Datatype
import Data.CFTA.Index (Depth (..))
import Data.CFTA.Interned (pathsMatching, requirePath)
import qualified Data.CFTA.Interned as Common
import Data.CFTA.Path (getPath, path)
import qualified Data.CFTA.Simple as Simple
import Data.CFTA.Template (
    Template (..),
    exclude,
    excludeAnywhere,
    excludeAnywhereFTA,
    excludeFTA,
    matchesNone,
    matchesNowhere,
    matchesTemplate,
    restrict,
    restrictFTA,
 )
import Data.CFTA.Term (Term)
import qualified Data.CFTA.Term as Term
import qualified Data.Map.Strict as Map

data State = Expression
    deriving (Eq, Ord, Show)

spec :: Spec
spec = do
    describe "explicit-state automata" $ do
        it "builds an ordinary recursive FTA" $
            case Automaton.mkFTA
                Expression
                [(Expression, [Transition "zero" [] noConstraint, Transition "add" [Expression, Expression] noConstraint])] of
                Left err -> expectationFailure $ show err
                Right automaton -> do
                    Automaton.accepts automaton (Term.Node "zero" []) `shouldBe` True
                    Automaton.accepts
                        automaton
                        (Term.Node "add" [Term.Node "zero" [], Term.Node "zero" []])
                        `shouldBe` True
                    Automaton.toTree automaton
                        `shouldBe` Tree.Node
                            (Left $ Automaton.Expanded [] Expression)
                            [ Tree.Node (Right $ Automaton.Transition "zero" [] noConstraint) []
                            , Tree.Node
                                (Right $ Automaton.Transition "add" [Expression, Expression] noConstraint)
                                [ Tree.Node (Left $ Automaton.Recursive [Common.ViewStep 1 0] Expression) []
                                , Tree.Node (Left $ Automaton.Recursive [Common.ViewStep 1 1] Expression) []
                                ]
                            ]
                    let functionLabels = Tree.flatten $ Automaton.toTree $ Automaton.mapConstraints (const not) automaton
                    [Automaton.transitionConstraint edge True | Right edge <- functionLabels] `shouldBe` [False, False]

        it "checks the path equalities of each constraint" $
            case Automaton.mkFTA
                (0 :: Int)
                [ (0, [Transition "p" [1, 1] (equalityConstraint $ mkEqConstraints [[path [0], path [1]]])])
                , (1, [Transition "a" [] noConstraint, Transition "b" [] noConstraint])
                ] of
                Left err -> expectationFailure $ show err
                Right pairs ->
                    map (Automaton.accepts pairs) [leafPair "a" "a", leafPair "a" "b"] `shouldBe` [True, False]

        it "constructs the ordinary product intersection" $ do
            let left = Automaton.mkFTA Expression [(Expression, [Transition "left" [] noConstraint, Transition "shared" [] noConstraint])]
                right = Automaton.mkFTA Expression [(Expression, [Transition "shared" [] noConstraint, Transition "right" [] noConstraint])]
            case (left, right) of
                (Right leftAutomaton, Right rightAutomaton) -> do
                    let ordinary = Automaton.dropConstraints $ Automaton.intersect leftAutomaton rightAutomaton
                    Automaton.accepts ordinary (Term.Node "shared" []) `shouldBe` True
                    Automaton.accepts ordinary (Term.Node "left" []) `shouldBe` False
                    Automaton.accepts ordinary (Term.Node "right" []) `shouldBe` False
                (Left err, _) -> expectationFailure $ show err
                (_, Left err) -> expectationFailure $ show err

        it "lists accepted terms by depth" $
            case Automaton.mkFTA
                Expression
                [(Expression, [Transition "zero" [] noConstraint, Transition "add" [Expression, Expression] noConstraint])] of
                Left err -> expectationFailure $ show err
                Right expressions -> do
                    let zero = Term.Node "zero" []
                        add left right = Term.Node "add" [left, right]
                        pair = add zero zero
                    take 5 (Automaton.terms expressions)
                        `shouldBe` [zero, pair, add pair pair, add pair zero, add zero pair]
                    Automaton.terms (Automaton.boundDepth 2 expressions) `shouldBe` take 5 (Automaton.terms expressions)
                    Automaton.states (Automaton.mapStates show expressions) `shouldBe` ["Expression"]
                    -- A second "add" over a sub-language accepts the same terms by more runs.
                    case Automaton.mkFTA
                        (0 :: Int)
                        [ (0, [Transition "zero" [] noConstraint, Transition "add" [0, 0] noConstraint, Transition "add" [1, 1] noConstraint])
                        , (1, [Transition "zero" [] noConstraint])
                        ] of
                        Left err -> expectationFailure $ show err
                        Right ambiguous -> Automaton.terms (Automaton.boundDepth 2 ambiguous) `shouldMatchList` take 5 (Automaton.terms expressions)

        it "lists accepted terms by cost, cheapest first" $
            case ( Automaton.mkFTA
                    Expression
                    [(Expression, [Transition "zero" [] noConstraint, Transition "add" [Expression, Expression] noConstraint])]
                 , Automaton.mkFTA
                    Expression
                    [
                        ( Expression
                        ,
                            [ Transition "zero" [] noConstraint
                            , Transition "add" [Expression, Expression] (equalityConstraint (mkEqConstraints [[path [0], path [1]]]))
                            ]
                        )
                    ]
                 ) of
                (Right expressions, Right balanced) -> do
                    let size _ children = 1 + sum children :: Int
                        nodes = length . Term.flatten
                        upToSeven = takeWhile ((<= 7) . fst) (Automaton.termsByCost size expressions)
                        zero = Term.Node "zero" []
                        twice t = Term.Node "add" [t, t]
                    -- The cyclic language is infinite; its terms of at most 7 nodes come first.
                    and (zipWith (<=) (map fst upToSeven) (drop 1 (map fst upToSeven))) `shouldBe` True
                    [(k, t) | (k, t) <- upToSeven, k /= nodes t] `shouldBe` []
                    map snd upToSeven `shouldMatchList` filter ((<= 7) . nodes) (Automaton.terms (Automaton.boundDepth 3 expressions))
                    -- The constraint keeps the sums of two equal terms.
                    take 4 (Automaton.termsByCost size balanced)
                        `shouldBe` [(1, zero), (3, twice zero), (7, twice (twice zero)), (15, twice (twice (twice zero)))]
                _ -> expectationFailure "no automaton"

        it "trims dead and unreachable states" $
            case Automaton.mkFTA
                (0 :: Int)
                [ (0, [Transition "f" [1, 2] noConstraint, Transition "leaf" [] noConstraint])
                , (1, [Transition "s" [1] noConstraint])
                , (2, [Transition "z" [] noConstraint])
                , (3, [Transition "loop" [3] noConstraint])
                ] of
                Left err -> expectationFailure $ show err
                Right automaton -> do
                    let trimmed = Automaton.trim automaton
                    Automaton.states trimmed `shouldBe` [0]
                    Automaton.transitionsFrom trimmed 0 `shouldBe` [Transition "leaf" [] noConstraint]
                    Automaton.terms automaton `shouldBe` [Term.Node "leaf" []]
                    acceptPlain (Common.fromFTA automaton) (Term.Node "leaf" []) `shouldBe` True

    describe "common interned automaton engine" $ do
        it "recognizes and intersects unit-constrained languages" $ do
            let choices = Common.Node [Common.Edge "a" [], Common.Edge "b" []] :: Common.Node String
                other = Common.Node [Common.Edge "b" [], Common.Edge "c" []] :: Common.Node String
                shared = Common.intersect choices other
            map (acceptPlain shared) [Term.Node "a" [], Term.Node "b" [], Term.Node "c" []]
                `shouldBe` [False, True, False]
            Common.intersect choices choices `shouldBe` choices

        it "imports a recursive explicit automaton as a Mu node" $ do
            case Automaton.mkFTA "nat" [("nat", [Transition "z" [] noConstraint, Transition "s" ["nat"] noConstraint])] of
                Left err -> expectationFailure $ show err
                Right nat -> do
                    let imported = Common.fromFTA nat :: Common.Node String
                    imported `shouldBe` Common.createMu (\self -> Common.Node [Common.Edge "z" [], Common.Edge "s" [self]])
                    Common.numNestedMu (Common.fromFTA (Automaton.boundDepth 2 nat) :: Common.Node String) `shouldBe` 0
                    forM_ [0 .. 3] $ \depth -> do
                        Enumeration.terms (Common.boundDepth depth imported)
                            `shouldMatchList` Automaton.terms (Automaton.boundDepth depth nat)
                        Enumeration.plainTermsAtMost depth imported
                            `shouldBe` Automaton.terms (Automaton.boundDepth depth nat)
                    take 3 (Enumeration.plainTermsAtMost (Depth maxBound) imported) `shouldBe` take 3 (Enumeration.plainTerms imported)

        it "substitutes the variable of each Mu by itself as the identity" $ do
            let nested =
                    Common.createMu $ \outer ->
                        Common.Node
                            [Common.Edge "f" [Common.createMu $ \inner -> Common.Node [Common.Edge "g" [outer, inner], Common.Edge "a" []]]]
                pair = Common.createMu $ \self -> Common.Node [Common.Edge "p" [self, nested], Common.Edge "b" []]
                mus node = case node of
                    Common.InternedMu mu -> mu : mus (Common.internedMuBody mu)
                    Common.InternedNode inner -> concat [mus child | edge <- Common.internedNodeEdges inner, child <- Common.edgeChildren edge]
                    _ -> []
            forM_ [nested, pair :: Common.Node String] $ \node -> do
                null (mus node) `shouldBe` False
                forM_ (mus node) $ \mu -> do
                    let self = Common.RecInt (Common.internedMuId mu)
                    Common.substFree self (Common.Rec self) (Common.internedMuBody mu) `shouldBe` Common.internedMuBody mu

        it "imports mutually recursive states with nested binders" $ do
            let rows =
                    [ ("a", [Transition "leaf" [] noConstraint, Transition "f" ["b"] noConstraint])
                    , ("b", [Transition "g" ["a", "b"] noConstraint, Transition "h" ["a"] noConstraint])
                    ]
            case Automaton.mkFTA "a" rows of
                Left err -> expectationFailure $ show err
                Right graph -> do
                    let imported = Common.fromFTA graph :: Common.Node String
                    Common.freeVars imported `shouldBe` mempty
                    forM_ [0 .. 4] $ \depth ->
                        Enumeration.terms (Common.boundDepth depth imported)
                            `shouldMatchList` Automaton.terms (Automaton.boundDepth depth graph)

        it "builds one node for each set of bound states of a strongly connected component" $
            forM_ [1 .. 4] $ \size -> do
                -- Every state has a leaf and an edge to every state.
                let rows =
                        [ ( state
                          , Transition "leaf" [] noConstraint : [Transition ("to" <> show next) [next] noConstraint | next <- [0 .. size - 1]]
                          )
                        | state <- [0 .. size - 1 :: Int]
                        ]
                case Automaton.mkFTA 0 rows of
                    Left err -> expectationFailure $ show err
                    Right graph -> do
                        let imported = Common.fromFTA graph :: Common.Node String
                        -- One binder, with one body, for each state and set of
                        -- the states before it that contains the root: 2^(size - 1).
                        -- Binders that nest in the order of each path gave the sum
                        -- of (size - 1)! / (size - d)!: 1, 2, 5, 16.
                        Common.nodeCount imported `shouldBe` 2 ^ (size - 1)
                        forM_ [0 .. 2] $ \depth ->
                            Enumeration.terms (Common.boundDepth depth imported)
                                `shouldMatchList` Automaton.terms (Automaton.boundDepth depth graph)

        it "imports a long cycle with one binder" $ do
            -- Each state has its own leaf and an edge to the next state. Only the
            -- first state needs a binder: every other state is on a cycle only
            -- through the first state.
            let size = 32 :: Int
                rows =
                    [ ( state
                      ,
                          [ Transition ("leaf" <> show state) [] noConstraint
                          , Transition "next" [(state + 1) `mod` size] noConstraint
                          ]
                      )
                    | state <- [0 .. size - 1]
                    ]
            case Automaton.mkFTA 0 rows of
                Left err -> expectationFailure $ show err
                Right graph -> do
                    let imported = Common.fromFTA graph :: Common.Node String
                    finished <- timeout 10000000 $ Common.nodeCount imported `shouldBe` size
                    finished `shouldBe` Just ()
                    Common.numNestedMu imported `shouldBe` 1
                    forM_ [0 .. 3] $ \depth ->
                        Enumeration.terms (Common.boundDepth depth imported)
                            `shouldMatchList` Automaton.terms (Automaton.boundDepth depth graph)

        it "imports and unfolds a two-way chain in time polynomial in its length" $ do
            -- Each state has its own leaf and edges to both neighbours, so each
            -- state gets a binder inside the binder of the state before it.
            -- Building or unfolding each binder again for each application of
            -- its body took time exponential in the length.
            let size = 40 :: Int
                rows =
                    [ ( state
                      , Transition ("leaf" <> show state) [] noConstraint
                            : [Transition "next" [state + 1] noConstraint | state < size - 1]
                                <> [Transition "prev" [state - 1] noConstraint | state > 0]
                      )
                    | state <- [0 .. size - 1]
                    ]
            case Automaton.mkFTA 0 rows of
                Left err -> expectationFailure $ show err
                Right graph -> do
                    let imported = Common.fromFTA graph :: Common.Node String
                    finished <- timeout 10000000 $ do
                        Common.nodeCount imported `shouldBe` size
                        Common.nodeCount (Common.unfoldOuterRec imported) `shouldBe` 2 * size
                    finished `shouldBe` Just ()
                    forM_ [0 .. 3] $ \depth ->
                        Enumeration.terms (Common.boundDepth depth imported)
                            `shouldMatchList` Automaton.terms (Automaton.boundDepth depth graph)

        it "preserves recursive intersections and the explicit graph view" $ do
            let naturals = Common.createMu $ \rec ->
                    Common.Node
                        [Common.Edge "zero" [], Common.Edge "succ" [rec]]
                evens = Common.createMu $ \rec ->
                    Common.Node
                        [Common.Edge "zero" [], Common.Edge "succ" [Common.Node [Common.Edge "succ" [rec]]]]
                shared = Common.intersect naturals evens :: Common.Node String
                terms = take 9 $ iterate (\term -> Term.Node "succ" [term]) (Term.Node "zero" [])
            map (acceptPlain shared) terms `shouldBe` map even [0 :: Int .. 8]
            let recursiveNodes = Common.crush (\case Common.InternedMu _ -> Sum (1 :: Int); _ -> Sum 0)
            getSum (recursiveNodes $ Common.Node [Common.Edge "pair" [naturals, naturals]]) `shouldBe` 1
            case Common.toFTA shared of
                Left err -> expectationFailure $ show err
                Right graph -> map (Automaton.accepts graph) terms `shouldBe` map even [0 :: Int .. 8]

        it "keeps a large shared graph compact through traversal" $ do
            let leaf = Common.Node [Common.Edge "leaf" []] :: Common.Node String
                graph = iterate (\child -> Common.Node [Common.Edge "pair" [child, child]]) leaf !! 24
            Common.nodeCount graph `shouldBe` 25
            Common.edgeCount graph `shouldBe` 25
            Common.mapNodes id graph `shouldBe` graph
            Common.union [graph, graph] `shouldBe` graph
            fmap (length . Tree.flatten) (Common.toTree graph) `shouldBe` Right 74

        it "keeps different constraint values distinct in the caches" $ do
            let plain = Common.Node [Common.Edge "a" []] :: Common.Node String
                guarded guard = Common.Node [Common.mkEdge "a" [] (semanticConstraint guard)] :: Common.Node String
                same = guarded $ Same (path []) (path [])
                entails = guarded $ Entails (path []) (path [])
            Common.nodeIdentity plain `shouldNotBe` Common.nodeIdentity same
            same `shouldNotBe` entails
            Common.acceptsWith (\constraint _ -> not $ residual constraint) same (Term.Node "a" []) `shouldBe` False
            Common.acceptsWith (\constraint _ -> not $ residual constraint) plain (Term.Node "a" []) `shouldBe` True
            Common.intersect plain same `shouldBe` same
            guarded Bottom `shouldBe` Common.EmptyNode

        it "retains constraints in the explicit graph view" $ do
            let constraint = semanticConstraint $ Same (path []) (path [])
                graph = Common.Node [Common.mkEdge "a" [] constraint] :: Common.Node String
            case Common.toFTA graph of
                Left err -> expectationFailure $ show err
                Right view ->
                    map Automaton.transitionConstraint (Automaton.transitionsFrom view $ Automaton.initialState view)
                        `shouldBe` [constraint]

        it "does not intersect constructors with different arities" $ do
            let leaf = Common.Node [Common.Edge "same" []] :: Common.Node String
                unary = Common.Node [Common.Edge "same" [leaf]]
            Common.intersect leaf unary `shouldBe` Common.EmptyNode
            fmap (length . Tree.flatten) (Common.toTree $ Common.union [leaf, unary]) `shouldBe` Right 5

        it "keeps a symbol at two arities in an explicit graph" $ do
            let leaf = Common.Node [Common.Edge "same" []] :: Common.Node String
                both = Common.union [leaf, Common.Node [Common.Edge "same" [leaf]]]
            fmap Automaton.mixedArity (Common.toFTA both)
                `shouldSatisfy` (`elem` [Right (Just ("same", 0, 1)), Right (Just ("same", 1, 0))])
            fmap Automaton.mixedArity (Common.toFTA leaf) `shouldBe` Right Nothing

        it "gives one canonical graph for two nodes with the same language, built apart" $ do
            let naturals = Common.createMu $ \rec ->
                    Common.Node [Common.Edge "zero" [], Common.Edge "succ" [rec]] :: Common.Node String
                unrolled = Common.Node [Common.Edge "succ" [naturals], Common.Edge "zero" []]
                canonical = either (error . show) id . Common.canonicalFTA
                explicit = either (error . show) id . Common.toFTA
            fmap (Map.size . Automaton.transitionTable) [explicit naturals, explicit unrolled] `shouldBe` [1, 2]
            canonical unrolled `shouldBe` canonical naturals
            take 5 (Automaton.terms $ canonical naturals) `shouldBe` take 5 (Automaton.terms $ explicit naturals)
            fmap Automaton.transitionTable (Common.canonicalFTA (Common.Node [] :: Common.Node String))
                `shouldBe` Right (Map.singleton 0 [])
            Common.canonicalFTA (Common.Rec (Common.RecUnint 0) :: Common.Node String) `shouldBe` Left Common.OpenNode

        it "rejects an open recursive node in an explicit graph view" $ do
            let open = Common.Rec (Common.RecUnint 0) :: Common.Node String
            Common.toFTA open `shouldBe` Left Common.OpenNode
            Common.toTree open `shouldBe` Left Common.OpenNode

        it "unfolds a recursive node a bounded number of times and refolds it" $ do
            let naturals = Common.createMu $ \rec ->
                    Common.Node [Common.Edge "zero" [], Common.Edge "succ" [rec]] :: Common.Node String
                terms = take 4 $ iterate (\term -> Term.Node "succ" [term]) (Term.Node "zero" [])
                bounded = Common.unfoldBounded 2 naturals
            map (acceptPlain bounded) terms `shouldBe` [True, True, False, False]
            Common.refold (Common.unfoldOuterRec naturals) `shouldBe` naturals
            take 3 (Enumeration.plainTerms naturals) `shouldBe` take 3 terms
            Enumeration.plainTerms bounded `shouldBe` take 2 terms

        it "imports an acyclic explicit graph and exposes it again unchanged" $ do
            let rows =
                    [ (0 :: Int, [Transition "pair" [1, 1] noConstraint, Transition "leaf" [] noConstraint])
                    , (1, [Transition "leaf" [] noConstraint])
                    ]
            case Automaton.mkFTA 0 rows of
                Left err -> expectationFailure $ show err
                Right graph -> do
                    Tree.flatten (Automaton.toTree graph)
                        `shouldBe` [ Left $ Automaton.Expanded [] 0
                                   , Right $ Automaton.Transition "pair" [1, 1] noConstraint
                                   , Left $ Automaton.Expanded [Common.ViewStep 0 0] 1
                                   , Right $ Automaton.Transition "leaf" [] noConstraint
                                   , Left $ Automaton.Shared [Common.ViewStep 0 1] 1
                                   , Right $ Automaton.Transition "leaf" [] noConstraint
                                   ]
                    let node = Common.fromFTA graph
                    acceptPlain node (Term.Node "pair" [Term.Node "leaf" [], Term.Node "leaf" []]) `shouldBe` True
                    acceptPlain node (Term.Node "pair" [Term.Node "pair" [], Term.Node "leaf" []]) `shouldBe` False
                    case Common.toFTA node of
                        Left err -> expectationFailure $ show err
                        Right view -> length (Automaton.states view) `shouldBe` 2

        it "reads, requires, and finds child-index paths" $ do
            let a = Common.Node [Common.Edge "a" []] :: Common.Node String
                b = Common.Node [Common.Edge "b" []]
                graph = Common.Node [Common.Edge "leaf" [], Common.Edge "pair" [a, b]]
            getPath (path [1]) graph `shouldBe` b
            getPath (path [0]) (Common.union [graph, Common.Node [Common.Edge "pair" [b, a]]]) `shouldBe` Common.union [a, b]
            requirePath (path [0]) graph `shouldBe` Common.Node [Common.Edge "pair" [a, b]]
            requirePath (path [-1]) graph `shouldBe` Common.EmptyNode
            pathsMatching (== b) graph `shouldBe` [path [1]]
            case Automaton.mkFTA
                (0 :: Int)
                [ (0, [Transition "pair" [1, 2] noConstraint])
                , (1, [Transition "leaf" [] noConstraint, Transition "pair" [2, 1] noConstraint])
                , (2, [Transition "leaf" [] noConstraint])
                ] of
                Left err -> expectationFailure $ show err
                Right explicit -> do
                    let root = Transition "pair" [1, 2] noConstraint
                    let below = statesAt (Automaton.transitionsFrom explicit)
                    below root (path [0]) `shouldBe` [1]
                    below root (path [0, 1]) `shouldBe` [1]
                    below root (path [1, 0]) `shouldBe` []

        it "removes an alternative that another alternative already accepts" $ do
            let leaf = Common.Node [Common.Edge "a" []] :: Common.Node String
                both = Common.Node [Common.Edge "a" [], Common.Edge "b" []]
                redundant = Common.Node [Common.Edge "f" [leaf], Common.Edge "f" [both]]
            Common.edgeCount (Common.withoutRedundantEdges redundant) `shouldBe` 3
            acceptPlain (Common.withoutRedundantEdges redundant) (Term.Node "f" [Term.Node "a" []]) `shouldBe` True

        it "removes a subsumed alternative of a recursive node and keeps its language" $ do
            let leaf = Common.Node [Common.Edge "a" []] :: Common.Node String
                -- The last pair accepts a subset of the terms of the first pair.
                subsumed = Common.createMu $ \self ->
                    Common.Node [Common.Edge "a" [], Common.Edge "pair" [self, self], Common.Edge "pair" [self, leaf]]
                -- The two pairs share only some terms, so both stay.
                overlapping = Common.createMu $ \self ->
                    Common.Node [Common.Edge "a" [], Common.Edge "pair" [leaf, self], Common.Edge "pair" [self, leaf]]
                reduced = Common.withoutRedundantEdges subsumed
            reduced `shouldBe` Common.createMu (\self -> Common.Node [Common.Edge "a" [], Common.Edge "pair" [self, self]])
            Common.withoutRedundantEdges overlapping `shouldBe` overlapping
            forM_ [0 .. 4] $ \depth ->
                Enumeration.terms (Common.boundDepth depth reduced)
                    `shouldMatchList` Enumeration.terms (Common.boundDepth depth subsumed)

    describe "templates" $ do
        it "restricts an automaton and an interned graph to the matching terms" $
            case Automaton.mkFTA
                Expression
                [(Expression, [Transition "zero" [] noConstraint, Transition "add" [Expression, Expression] noConstraint])] of
                Left err -> expectationFailure $ show err
                Right expressions -> do
                    let template = TemplateNode "add" [TemplateNode "zero" [], Hole]
                        bounded = Automaton.boundDepth 2 expressions
                        expected = filter (matchesTemplate template) (Automaton.terms bounded)
                    length expected `shouldBe` 2
                    Automaton.terms (restrictFTA template bounded) `shouldMatchList` expected
                    Enumeration.plainTerms (restrict template (Common.fromFTA bounded)) `shouldBe` expected
                    -- The check constrains every "add" node, and the root "zero" passes it.
                    let accept _ transition term = pure (Automaton.transitionSymbol transition /= "add" || matchesTemplate template term)
                        zero = Term.Node "zero" []
                        add left right = Term.Node "add" [left, right]
                    runIdentity (Automaton.termsUpToM accept 2 expressions)
                        `shouldMatchList` [zero, add zero zero, add zero (add zero zero)]
                    runIdentity (Automaton.termsUpToM (\_ _ _ -> pure True) 2 expressions) `shouldBe` Automaton.terms bounded
                    -- The same check decides membership one term at a time.
                    map (runIdentity . Automaton.acceptsM accept expressions) [zero, add zero zero, add (add zero zero) zero]
                        `shouldBe` [True, True, False]
                    runIdentity (Automaton.acceptsM accept expressions (Term.Node "mul" [zero, zero])) `shouldBe` False

        it "excludes the matching terms from an automaton and an interned graph" $
            case Automaton.mkFTA
                Expression
                [(Expression, [Transition "zero" [] noConstraint, Transition "add" [Expression, Expression] noConstraint])] of
                Left err -> expectationFailure $ show err
                Right expressions -> do
                    let templates = [TemplateNode "add" [TemplateNode "zero" [], Hole], TemplateNode "add" [Hole, TemplateNode "zero" []]]
                        bounded = Automaton.boundDepth 2 expressions
                        expected = filter (matchesNone templates) (Automaton.terms bounded)
                    length expected `shouldBe` 2
                    Automaton.terms (excludeFTA templates bounded) `shouldMatchList` expected
                    Enumeration.plainTerms (exclude templates (Common.fromFTA bounded)) `shouldMatchList` expected

        it "excludes the terms with a matching subterm from a recursive automaton and interned graph" $
            case Automaton.mkFTA
                Expression
                [(Expression, [Transition "zero" [] noConstraint, Transition "add" [Expression, Expression] noConstraint])] of
                Left err -> expectationFailure $ show err
                Right expressions -> do
                    -- No "add" has an "add" as its right child.
                    let templates = [TemplateNode "add" [Hole, TemplateNode "add" [Hole, Hole]]]
                        zero = Term.Node "zero" []
                        add left right = Term.Node "add" [left, right]
                        expected = filter (matchesNowhere templates) (Automaton.terms (Automaton.boundDepth 2 expressions))
                    expected `shouldMatchList` [zero, add zero zero, add (add zero zero) zero]
                    Automaton.terms (Automaton.boundDepth 2 (excludeAnywhereFTA templates expressions)) `shouldMatchList` expected
                    Enumeration.plainTerms (Common.boundDepth 2 (excludeAnywhere templates (Common.fromFTA expressions)))
                        `shouldMatchList` expected

    describe "explicit-state recognition" $ do
        it "rejects a transition whose guard is Bottom, as the interned view does" $ do
            let bottom = case Automaton.mkFTA ("q" :: String) [("q", [Transition "a" [] (semanticConstraint Bottom)])] of
                    Right fta -> fta
                    Left err -> error $ show err
                leaf = Term.Node "a" [] :: Term String
            (Automaton.accepts bottom leaf, Common.acceptsWith equalitiesHold (Common.fromFTA bottom) leaf)
                `shouldBe` (False, False)

        it "decides a deep term in linear time when a state has two transitions with one symbol" $ do
            -- A search with no table tries both "f" transitions again at each
            -- level of a rejected term, so its time is exponential in the depth.
            let a = Transition "a" [] noConstraint
                f child = Transition "f" [child] noConstraint
                ambiguous =
                    either (error . show) id $
                        Automaton.mkFTA ("q" :: String) [("q", [a, f "q", f "r"]), ("r", [a, f "q"])]
                node = Common.fromFTA ambiguous
                chain depth leaf = iterate (\term -> Term.Node "f" [term]) (Term.Node leaf []) !! depth
                decide term = [Automaton.accepts ambiguous term, Common.acceptsWith equalitiesHold node term]
            forM_ [chain depth leaf | depth <- [0 .. 10], leaf <- ["a", "b"]] $ \term ->
                (term, map Just (decide term)) `shouldBe` (term, replicate 2 (Simple.accepts ambiguous term))
            finished <- timeout 10000000 $ map (decide . chain 60) ["a", "b"] `shouldBe` [[True, True], [False, False]]
            finished `shouldBe` Just ()

    describe "derived datatype grammars" $ do
        it "accepts a type argument that grows and then stops" $
            -- From Grows Int the states are Grows Int, Int, Stop, Grows (Maybe Int),
            -- and Maybe Int: Stop always leads back to Grows (Maybe Int).
            fmap (Automaton.states . Datatype.datatypeFTA) (Datatype.deriveFTAWith @(Grows Int) (Datatype.domain @Int [0]))
                `shouldSatisfy` either (const False) ((== 5) . length)

        it "rejects a growth that the growth limit does not allow" $
            fmap
                (Automaton.states . Datatype.datatypeFTA)
                (Datatype.deriveFTAWithGrowthLimit @(Grows Int) 0 (Datatype.domain @Int [0]))
                `shouldBe` Left (Datatype.NonRegularRecursion 0 (typeRep $ Proxy @(Grows Int)) (typeRep $ Proxy @(Grows (Maybe Int))))

        it "counts a growth only against the nearest type with the same constructor" $
            -- Maybe Chain2, Maybe Chain3, and Maybe (Maybe Bool) are on one path.
            -- Only the last is larger than the one before it.
            fmap
                (Automaton.states . Datatype.datatypeFTA)
                (Datatype.deriveFTAWithGrowthLimit @Chain1 1 mempty)
                `shouldSatisfy` either (const False) (not . null)

        it "rejects a type argument that grows without end" $
            case Datatype.deriveFTAWith @(Nested Int) (Datatype.domain @Int [0]) of
                Left (Datatype.NonRegularRecursion limit _ _) -> limit `shouldBe` Datatype.defaultGrowthLimit
                other -> expectationFailure $ "expected NonRegularRecursion, got " <> either show (const "a grammar") other

        it "accepts exactly the encodings of the datatype's values" $ do
            case Datatype.deriveFTAWith @(Maybe Shape) (Datatype.domain @Int [0, 1]) of
                Left err -> expectationFailure $ show err
                Right datatype -> do
                    let grammar = Datatype.datatypeFTA datatype
                        values = [Nothing, Just (Dot 0), Just (Box 1 (Dot 1))]
                    map (Automaton.accepts grammar . Datatype.encodeTerm) values `shouldBe` [True, True, True]
                    map (Datatype.decodeTerm . Datatype.encodeTerm) values `shouldBe` map Just values
                    Automaton.accepts grammar (Datatype.encodeTerm (Just (Dot 7))) `shouldBe` False
                    Automaton.cycleState grammar `shouldSatisfy` (/= Nothing)
                    -- No junk: every term of the grammar is the encoding of a value.
                    let roundTrips term = fmap Datatype.encodeTerm (Datatype.decodeTerm term :: Maybe (Maybe Shape)) == Just term
                    case Simple.termsUpTo 3 grammar of
                        Nothing -> expectationFailure "the grammar has a constraint"
                        Just grammarTerms -> do
                            length grammarTerms `shouldSatisfy` (> 3)
                            filter (not . roundTrips) grammarTerms `shouldBe` []

-- | A type argument that grows once: 'Stop' leads back to a fixed larger type.
data Grows a = Grows a Stop | Stopped
    deriving (Eq, Show, Generic)

instance (Datatype.HasFTA a) => Datatype.HasFTA (Grows a)

-- | The fixed type that 'Grows' reaches.
newtype Stop = Stop (Grows (Maybe Int))
    deriving (Eq, Show, Generic)

instance Datatype.HasFTA Stop

-- | A chain of distinct types under 'Maybe' that ends in a larger 'Maybe'.
newtype Chain1 = Chain1 (Maybe Chain2)
    deriving (Eq, Show, Generic)

instance Datatype.HasFTA Chain1

newtype Chain2 = Chain2 (Maybe Chain3)
    deriving (Eq, Show, Generic)

instance Datatype.HasFTA Chain2

newtype Chain3 = Chain3 (Maybe (Maybe Bool))
    deriving (Eq, Show, Generic)

instance Datatype.HasFTA Chain3

-- | A nested datatype: every level grows the type argument.
data Nested a = Nested a (Nested (Maybe a)) | Flat
    deriving (Eq, Show, Generic)

instance (Datatype.HasFTA a) => Datatype.HasFTA (Nested a)

-- | A small recursive datatype for the derivation checks.
data Shape = Dot Int | Box Int Shape
    deriving (Eq, Show, Generic)

instance Datatype.HasFTA Shape

-- | Recognize an ordinary interned automaton.
acceptPlain :: Common.Node String -> Term String -> Bool
acceptPlain = Common.acceptsWith (\_ _ -> True)

-- | The term p(left, right) over two leaves.
leafPair :: String -> String -> Term String
leafPair left right = Term.Node "p" [Term.Node left [], Term.Node right []]
