{-# LANGUAGE OverloadedStrings #-}

module Data.CFTA.Refinement.PruneSpec (spec) where

import Data.CFTA.Constraint (equalities, equalityConstraint)
import Data.CFTA.Equality.Constraint (mkEqConstraints)
import Data.CFTA.Formula (Sort (..))
import Data.CFTA.Interned (createMu, createUnion)
import Data.CFTA.Refinement (
    Automaton,
    Constraint (constraintGuard),
    DenotationError,
    Entailment (Entailment),
    Guard (And, Entails, Not, Or, Same, Satisfies, Substitute, Top),
    Node (EmptyNode, Node),
    PruneError (PruneUnknown),
    Substitution (Substitution),
    Symbol (RefinedSymbol),
    Transition,
    Verdict (No, Unknown, Yes),
    accepts,
    denotationAtMost,
    edgeConstraint,
    noConstraint,
    nodeEdges,
    path,
    prune,
    semanticConstraint,
    transitionSymbol,
    transitionsAt,
    validate,
    pattern Transition,
 )
import Data.CFTA.Refinement.Expression (refinementFormula, true, variable, (.==), (.>=))
import qualified Data.CFTA.Refinement.Guard as Guard
import Data.CFTA.Refinement.LiquidFixpoint (withZ3)
import Data.CFTA.Refinement.TestSupport (declarations)
import Data.CFTA.Term (Term)
import qualified Data.CFTA.Term as Term
import Data.List (permutations)
import System.Timeout (timeout)
import Test.Hspec (Spec, describe, expectationFailure, it, shouldBe, shouldMatchList)

spec :: Spec
spec =
    describe "semantic pruning" $ do
        it "keeps the language when it prunes heterogeneous nodes at semantic guard positions" $
            withZ3 declarations $ \solver ->
                checkPrunedLanguage solver semanticPairs pairTerms 5

        it "computes Figure 12's bounded denotation directly" $
            withZ3 declarations $ \solver -> do
                terms <- denotationAtMost solver 1 semanticPairs
                fmap length terms `shouldBe` Right 5
                case nodeEdges semanticPairs of
                    [root] -> length (transitionsAt root $ path [0]) `shouldBe` 3
                    roots -> expectationFailure $ "unexpected Figure 12 roots: " <> show roots

        it "keeps the language when it prunes nested semantic positions" $
            withZ3 declarations $ \solver ->
                checkPrunedLanguage solver nestedPairs nestedPairTerms 5

        it "retains guards through an open nested binder with an enclosing union reference" $ do
            let solver = Entailment $ \_ _ -> pure Yes
                original = createMu $ \outer ->
                    Node
                        [ Transition "base" true [] noConstraint
                        , Transition
                            "outer"
                            true
                            [ atomA
                            , createMu $ \inner ->
                                createUnion
                                    [ outer
                                    , Node [Transition "inner" true [atomA, inner] noConstraint]
                                    ]
                            ]
                            (semanticConstraint $ Satisfies (path [1, 0]) true)
                        ]
                wanted =
                    Term.Node
                        (RefinedSymbol "outer" true)
                        [ Term.Node (RefinedSymbol "a" true) []
                        , Term.Node
                            (RefinedSymbol "inner" true)
                            [Term.Node (RefinedSymbol "a" true) [], Term.Node (RefinedSymbol "base" true) []]
                        ]
            validate original `shouldBe` Right ()
            checkPrunedLanguage solver original [wanted] 1

        it "preserves terms with an absent path under negation" $
            withZ3 declarations $ \solver ->
                checkPrunedLanguage
                    solver
                    (optionalDescendant $ Not $ Satisfies (path [0, 0]) true)
                    optionalDescendantTerms
                    1

        it "preserves terms with an absent path in a satisfied disjunction" $
            withZ3 declarations $ \solver ->
                checkPrunedLanguage
                    solver
                    (optionalDescendant $ Or [Top, Satisfies (path [0, 0]) true])
                    optionalDescendantTerms
                    2

        it "retains optional reflexive equality until complete paths can be checked" $ do
            let solver = Entailment $ \_ _ -> pure Unknown
                guard = Same (path [0, 0]) (path [0, 0])
                original = optionalDescendant guard
            traverse (accepts solver original) optionalDescendantTerms >>= (`shouldBe` [No, Yes])
            checkPrunedLanguage solver original optionalDescendantTerms 1
            reduced <- prune solver original
            fmap (map (constraintGuard . edgeConstraint) . nodeEdges) reduced `shouldBe` Right [guard]

        it "keeps reflexive equality on an always-present path as a residual guard" $ do
            let solver = Entailment $ \_ _ -> pure Unknown
            reduced <- prune solver $ optionalDescendant $ Same (path [0]) (path [0])
            case reduced of
                Left err -> expectationFailure $ show err
                Right pruned ->
                    traverse (accepts solver pruned) optionalDescendantTerms >>= (`shouldBe` [Yes, Yes])

        it "removes a transition whose equalities need an absent descendant" $ do
            let solver = Entailment $ \_ _ -> pure Unknown
                constraint = semanticConstraint $ And [Same (path [0]) (path [1]), Same (path [0, 0]) (path [1, 0])]
                leaf = Term.Node (RefinedSymbol "a" true) []
                original = Node [Transition "pair" true [atomA, atomA] constraint]
            accepts solver original (Term.Node (RefinedSymbol "pair" true) [leaf, leaf]) >>= (`shouldBe` No)
            prune solver original >>= (`shouldBe` Right EmptyNode)

        it "keeps semantic and syntactic splits apart" $
            withZ3 declarations $ \solver -> do
                let zero = refinementFormula (\v -> v .== 0)
                    one = refinementFormula (\v -> v .== 1)
                    atoms =
                        Node
                            [ Transition "a" zero [] noConstraint
                            , Transition "b" one [] noConstraint
                            ]
                    leafA = Term.Node (RefinedSymbol "a" zero) []
                    leafB = Term.Node (RefinedSymbol "b" one) []
                    semantic =
                        Node [Transition "f" true [atoms] $ semanticConstraint $ Satisfies (path [0]) zero]
                    syntactic =
                        Node [Transition "pair" true [atoms, atoms] $ semanticConstraint $ Same (path [0]) (path [1])]
                checkPrunedLanguage
                    solver
                    semantic
                    [ Term.Node (RefinedSymbol "f" true) [child]
                    | child <- [leafA, leafB, Term.Node (RefinedSymbol "sentinel" true) []]
                    ]
                    1
                checkPrunedLanguage
                    solver
                    syntactic
                    [Term.Node (RefinedSymbol "pair" true) [left, right] | left <- [leafA, leafB], right <- [leafA, leafB]]
                    2

        it "partitions substitution positions by their value-naming symbol" $
            withZ3 declarations $ \solver ->
                checkPrunedLanguage solver substitutedOutputs substitutionTerms 2

        it "preserves scoped syntactic equality and its Boolean forms as residual LTA guards" $ do
            let solver = Entailment $ \_ _ -> fail "syntactic equality queried the solver"
                same = Same (path [2]) (path [3])
                scope = Substitute [Substitution (path [0]) (path [1])]
                allPairs = [(left, right) | left <- ["x", "y", "z"], right <- ["x", "y", "z"]]
                equalPairs = [("x", "x"), ("x", "y"), ("y", "x"), ("y", "y"), ("z", "z")]
                differentPairs = filter (`notElem` equalPairs) allPairs
                term (left, right) =
                    Term.Node
                        (RefinedSymbol "scoped" true)
                        [Term.Node (RefinedSymbol symbol true) [] | symbol <- ["x", "y", left, right]]
                automaton guard =
                    Node
                        [ Transition
                            "scoped"
                            true
                            [leafNode "x", leafNode "y", xyz, xyz]
                            (semanticConstraint guard)
                        ]
                xyz = Node [Transition symbol true [] noConstraint | symbol <- ["x", "y", "z"]]
                check (guard, acceptedPairs) = do
                    let original = automaton guard
                    denotationAtMost solver 1 original
                        >>= either (expectationFailure . show) (`shouldMatchList` map term acceptedPairs)
                    checkPrunedLanguage solver original (map term allPairs) (length acceptedPairs)
                    result <- prune solver original
                    case result of
                        Left err -> expectationFailure $ show err
                        Right reduced -> do
                            denotationAtMost solver 1 reduced
                                >>= either (expectationFailure . show) (`shouldMatchList` map term acceptedPairs)
                            map (constraintGuard . edgeConstraint) (nodeEdges reduced) `shouldBe` [guard]
            mapM_
                check
                [ (scope same, equalPairs)
                , (scope $ Not same, differentPairs)
                , (scope $ Or [same, Not same], allPairs)
                ]

        it "retains guards whose compound actual identities need complete terms" $
            withZ3 ([(name, IntSort) | name <- ["app", "known"]] <> declarations) $ \solver -> do
                before <- denotationAtMost solver 2 compoundActuals
                fmap length before `shouldBe` Right 3
                result <- prune solver compoundActuals
                case result of
                    Left err -> expectationFailure $ show err
                    Right reduced -> do
                        after <- denotationAtMost solver 2 reduced
                        equivalentTermSets before after `shouldBe` True
                        reduced `shouldBe` compoundActuals

        it "retains scopes when complete actual identities change substitution precedence" $
            withZ3 [] $ \solver -> do
                let zero = refinementFormula (\v -> v .== 0)
                    actual = Node [Transition "a" zero [leafNode "z"] noConstraint]
                    scope =
                        Substitute [Substitution (path [2]) (path [0])]
                            $ Substitute [Substitution (path [0]) (path [3]), Substitution (path [1]) (path [4])]
                            $ Satisfies (path [5]) (refinementFormula $ \_ -> variable "x" .== 0)
                    repeated =
                        Substitute [Substitution (path [0]) (path [0]), Substitution (path [1]) (path [4]), Substitution (path [2]) (path [0])] $
                            Satisfies (path [5]) (refinementFormula $ \_ -> variable "a" .== 0)
                    original guard =
                        Node
                            [ Transition
                                "root"
                                true
                                [actual, actual, leafNode "b", leafNode "x", leafNode "y", leafNode "target"]
                                (semanticConstraint guard)
                            ]
                    leaf name = Term.Node (RefinedSymbol name true) []
                    actualTerm = Term.Node (RefinedSymbol "a" zero) [leaf "z"]
                    rejected = Term.Node (RefinedSymbol "root" true) [actualTerm, actualTerm, leaf "b", leaf "x", leaf "y", leaf "target"]
                    check guard = do
                        accepts solver (original guard) rejected >>= (`shouldBe` No)
                        checkPrunedLanguage solver (original guard) [rejected] 0
                        prune solver (original guard) >>= (`shouldBe` Right (original guard))
                mapM_ check [scope, repeated]

        it "reports solver uncertainty when actual identities are known" $ do
            result <- prune (Entailment $ \_ _ -> pure Unknown) $ optionalDescendant $ Satisfies (path [0]) true
            case result of
                Left (PruneUnknown _) -> pure ()
                other -> expectationFailure $ "expected an undecided guard, got " <> show other

        it "narrows syntactic equality to the intersection of the equal positions" $
            withZ3 declarations $ \solver -> do
                result <- prune solver syntacticPairs
                case result of
                    Left err -> expectationFailure $ show err
                    Right reduced -> case nodeEdges reduced of
                        [root] -> do
                            equalities (edgeConstraint root) `shouldBe` mkEqConstraints [[path [0], path [1]]]
                            map transitionSymbol (transitionsAt root $ path [0]) `shouldBe` ["shared"]
                            map transitionSymbol (transitionsAt root $ path [1]) `shouldBe` ["shared"]
                            traverse (accepts solver reduced) syntacticPairTerms >>= (`shouldBe` [Yes, No, No])
                        roots -> expectationFailure $ "unexpected root alternatives: " <> show roots

        it "applies syntactic intersection below a nested position" $
            withZ3 declarations $ \solver -> do
                result <- prune solver nestedSyntacticPairs
                case result of
                    Left err -> expectationFailure $ show err
                    Right reduced -> case nodeEdges reduced of
                        [root] -> do
                            map transitionSymbol (transitionsAt root $ path [0]) `shouldBe` ["box"]
                            map transitionSymbol (transitionsAt root $ path [0, 0]) `shouldBe` ["shared"]
                            map transitionSymbol (transitionsAt root $ path [1]) `shouldBe` ["shared"]
                        roots -> expectationFailure $ "unexpected root alternatives: " <> show roots

        it "stops narrowing three equal leaves with distinct residual guards" $ do
            let solver = Entailment $ \_ _ -> pure Yes
                reflexive = Same (path []) (path [])
                atom guard = Node [Transition "a" true [] (semanticConstraint guard)]
                children = map atom [reflexive, And [reflexive, reflexive], Or [reflexive, reflexive]]
                original = Node [Transition "triple" true children (equalityConstraint $ mkEqConstraints [[path [0], path [1], path [2]]])]
                a = Term.Node (RefinedSymbol "a" true) []
                term = Term.Node (RefinedSymbol "triple" true) [a, a, a]
            validate original `shouldBe` Right ()
            accepts solver original term >>= (`shouldBe` Yes)
            result <- timeout 10000000 $ prune solver original
            case result of
                Just (Right reduced) -> do
                    accepts solver reduced term >>= (`shouldBe` Yes)
                    prune solver reduced >>= (`shouldBe` Right reduced)
                other -> expectationFailure $ "expected completed pruning, got " <> show other

        it "retains branch correlations when narrowing a nested equality class" $ do
            let solver = Entailment $ \_ _ -> pure Yes
                a = Node [Transition "a" true [] noConstraint]
                b = Node [Transition "b" true [] noConstraint]
                alternatives = Node [Transition "f" true [a] noConstraint, Transition "g" true [b] noConstraint]
                other = Node [Transition "a" true [] noConstraint, Transition "b" true [] noConstraint]
                original = Node [Transition "pair" true [alternatives, other] (equalityConstraint $ mkEqConstraints [[path [0, 0], path [1]]])]
                leaf name = Term.Node (RefinedSymbol name true) []
                term outer inner = Term.Node (RefinedSymbol "pair" true) [Term.Node (RefinedSymbol outer true) [leaf inner], leaf inner]
                terms = [term "f" "a", term "g" "b", term "f" "b", term "g" "a"]
            validate original `shouldBe` Right ()
            traverse (accepts solver original) terms >>= (`shouldBe` [Yes, Yes, No, No])
            checkPrunedLanguage solver original terms 2

        it "keeps Boolean syntactic constraints in the LTA when equality classes cannot express them" $
            withZ3 declarations $ \solver -> do
                reduced <- prune solver negativeSyntacticPairs
                case reduced of
                    Left err -> expectationFailure $ show err
                    Right lta -> do
                        traverse (accepts solver lta) syntacticPairTerms >>= (`shouldBe` [No, Yes, Yes])
                        map (constraintGuard . edgeConstraint) (nodeEdges lta) `shouldBe` [negativeEquality]

        it "solves nested positive conjunctions in every requirement order" $
            withZ3 declarations $ \solver -> do
                let requirements =
                        [ Guard.isSameTermAs (Guard.argument 0) (Guard.argument 1)
                        , Guard.isSameTermAs (Guard.argument 1) (Guard.argument 2)
                        , Guard.requires (Guard.argument 0) (const true)
                        ]
                    check order = do
                        let original = equalTriples $ Guard.allOf order
                        before <- denotationAtMost solver 1 original
                        result <- prune solver original
                        case result of
                            Left err -> expectationFailure $ show err
                            Right reduced -> do
                                after <- denotationAtMost solver 1 reduced
                                equivalentTermSets before after `shouldBe` True
                                fmap length after `shouldBe` Right 2
                mapM_ check $ permutations requirements

-- | Compare recognition before and after pruning, including the expected accepted count.
checkPrunedLanguage :: Entailment -> Automaton -> [Term Symbol] -> Int -> IO ()
checkPrunedLanguage solver original terms expected = do
    result <- prune solver original
    case result of
        Left err -> expectationFailure $ show err
        Right reduced -> do
            before <- traverse (accepts solver original) terms
            after <- traverse (accepts solver reduced) terms
            after `shouldBe` before
            length (filter (== Yes) after) `shouldBe` expected
            beforeDenotation <- denotationAtMost solver 3 original
            afterDenotation <- denotationAtMost solver 3 reduced
            equivalentTermSets beforeDenotation afterDenotation `shouldBe` True

-- | Compare denotations as sets without requiring an ordering for formulas.
equivalentTermSets ::
    Either DenotationError [Term Symbol] ->
    Either DenotationError [Term Symbol] ->
    Bool
equivalentTermSets (Right left) (Right right) =
    all (`elem` right) left && all (`elem` left) right
equivalentTermSets _ _ = False

-- | A node with one unrefined, unconstrained leaf.
leafNode :: Symbol -> Automaton
leafNode symbol = Node [Transition symbol true [] noConstraint]

-- | The leaf @a@.
atomA :: Automaton
atomA = leafNode "a"

-- | The leaves @a@ and @b@.
atomsAB :: Automaton
atomsAB =
    Node
        [ Transition "a" true [] noConstraint
        , Transition "b" true [] noConstraint
        ]

-- | A descendant exists in only one alternative of the child node.
optionalDescendant :: Guard -> Automaton
optionalDescendant guard =
    Node [Transition "f" true [choice] $ semanticConstraint guard]
  where
    choice =
        Node
            [ Transition "a" true [] noConstraint
            , Transition "b" true [atomA] noConstraint
            ]

-- | Both finite terms of 'optionalDescendant' before its guard is checked.
optionalDescendantTerms :: [Term Symbol]
optionalDescendantTerms =
    [ Term.Node (RefinedSymbol "f" true) [leaf]
    , Term.Node (RefinedSymbol "f" true) [Term.Node (RefinedSymbol "b" true) [leaf]]
    ]
  where
    leaf = Term.Node (RefinedSymbol "a" true) []

-- | Three independent choices constrained by positive equalities and entailment.
equalTriples :: Constraint -> Automaton
equalTriples constraint =
    Node [Transition "triple" true [atomsAB, atomsAB, atomsAB] constraint]

-- | Compare the values of two complete compound actual terms.
compoundEqualityGuard :: Guard
compoundEqualityGuard =
    Substitute
        [Substitution (path [0]) (path [2]), Substitution (path [1]) (path [3])]
        (Satisfies (path []) $ variable "x" .== variable "y")

-- | Root observations do not distinguish equal and unequal actual subtrees.
compoundActuals :: Automaton
compoundActuals =
    Node
        [ Transition "pair" true [known, known, leafNode "x", leafNode "y"] $
            semanticConstraint compoundEqualityGuard
        ]
  where
    known =
        Node
            [ Transition "known" (refinementFormula (\v -> v .== 0)) [] noConstraint
            , Transition "app" true [atomsAB] noConstraint
            ]

{- | Figure 12's LTA: @f(phi1, phi2)@ where @phi1 => phi2@.

Every formula is an ordinary nullary ranked-alphabet symbol. The implementation
encodes that symbol as @RefinedSymbol "predicate" formula@; it is not metadata
outside the automaton.
-}
semanticPairs :: Automaton
semanticPairs = Node [Transition "pair" true [predicateNode, predicateNode] pairEntailment]

-- | The same relation, with its left observation one constructor below the root.
nestedPairs :: Automaton
nestedPairs = Node [Transition "pair" true [box, predicateNode] nestedEntailment]
  where
    box = Node [Transition "box" true [predicateNode] noConstraint]

-- | A substitution guard whose actual names select matching output refinements.
substitutedOutputs :: Automaton
substitutedOutputs =
    Node
        [ Transition
            "application"
            true
            [actuals, leafNode "n", outputs]
            substitutedRequirement
        ]
  where
    actuals =
        Node
            [ Transition "x" (refinementFormula (\v -> v .== 0)) [] noConstraint
            , Transition "y" (refinementFormula (\v -> v .== 1)) [] noConstraint
            ]
    outputs =
        Node
            [ Transition "output-x" (refinementFormula (\v -> v .== variable "x")) [] noConstraint
            , Transition "output-y" (refinementFormula (\v -> v .== variable "y")) [] noConstraint
            ]

-- | The leaves @left@ and @shared@.
leftOrShared :: Automaton
leftOrShared =
    Node
        [ Transition "left" true [] noConstraint
        , Transition "shared" true [] noConstraint
        ]

-- | The leaves @shared@ and @right@.
sharedOrRight :: Automaton
sharedOrRight =
    Node
        [ Transition "shared" true [] noConstraint
        , Transition "right" true [] noConstraint
        ]

-- | Two overlapping structural languages tied by syntactic equality.
syntacticPairs :: Automaton
syntacticPairs =
    Node [Transition "pair" true [leftOrShared, sharedOrRight] $ semanticConstraint $ Same (path [0]) (path [1])]

-- | One accepted equal pair followed by two rejected unequal pairs.
syntacticPairTerms :: [Term Symbol]
syntacticPairTerms =
    [ pair "shared" "shared"
    , pair "left" "shared"
    , pair "shared" "right"
    ]
  where
    pair left right =
        Term.Node
            (RefinedSymbol "pair" true)
            [Term.Node (RefinedSymbol left true) [], Term.Node (RefinedSymbol right true) []]

-- | The same structural overlap reached below a wrapper on the left.
nestedSyntacticPairs :: Automaton
nestedSyntacticPairs =
    Node [Transition "pair" true [boxOrEmpty, sharedOrRight] $ semanticConstraint $ Same (path [0, 0]) (path [1])]
  where
    boxOrEmpty =
        Node
            [ Transition "box" true [leftOrShared] noConstraint
            , Transition "empty" true [] noConstraint
            ]

-- | Negated equality is a valid LTA constraint but is not an equality class.
negativeSyntacticPairs :: Automaton
negativeSyntacticPairs =
    Node [Transition "pair" true [leftOrShared, sharedOrRight] $ semanticConstraint negativeEquality]

negativeEquality :: Guard
negativeEquality = Not $ Same (path [0]) (path [1])

-- | All concrete pairs from the heterogeneous atom node.
pairTerms :: [Term Symbol]
pairTerms = [Term.Node (RefinedSymbol "pair" true) [left, right] | left <- predicates, right <- predicates]

-- | All concrete pairs with the left atom below a box constructor.
nestedPairTerms :: [Term Symbol]
nestedPairTerms =
    [ Term.Node
        (RefinedSymbol "pair" true)
        [Term.Node (RefinedSymbol "box" true) [left], right]
    | left <- predicates
    , right <- predicates
    ]

-- | Every actual-name and output-refinement combination.
substitutionTerms :: [Term Symbol]
substitutionTerms =
    [ Term.Node
        (RefinedSymbol "application" true)
        [actual, Term.Node (RefinedSymbol "n" true) [], output]
    | actual <- namedActuals
    , output <-
        [ Term.Node (RefinedSymbol "output-x" (refinementFormula (\v -> v .== variable "x"))) []
        , Term.Node (RefinedSymbol "output-y" (refinementFormula (\v -> v .== variable "y"))) []
        ]
    ]

-- | Three representative refinement transitions.
predicateTransitions :: [Transition]
predicateTransitions =
    [ Transition "predicate" (refinementFormula (\v -> v .== 0)) [] noConstraint
    , Transition "predicate" (refinementFormula (\v -> v .== 1)) [] noConstraint
    , Transition "predicate" (refinementFormula (\v -> v .>= 0)) [] noConstraint
    ]

-- | The node of the three predicate transitions.
predicateNode :: Automaton
predicateNode = Node predicateTransitions

-- | Concrete formula terms matching 'predicateTransitions'.
predicates :: [Term Symbol]
predicates =
    [ Term.Node (RefinedSymbol "predicate" (refinementFormula (\v -> v .== 0))) []
    , Term.Node (RefinedSymbol "predicate" (refinementFormula (\v -> v .== 1))) []
    , Term.Node (RefinedSymbol "predicate" (refinementFormula (\v -> v .>= 0))) []
    ]

-- | Variable leaves used by the substitution example.
namedActuals :: [Term Symbol]
namedActuals =
    [ Term.Node (RefinedSymbol "x" (refinementFormula (\v -> v .== 0))) []
    , Term.Node (RefinedSymbol "y" (refinementFormula (\v -> v .== 1))) []
    ]

-- | Direct semantic relation between sibling positions.
pairEntailment :: Constraint
pairEntailment = semanticConstraint $ Entails (path [0]) (path [1])

-- | Semantic relation whose antecedent is below a wrapper.
nestedEntailment :: Constraint
nestedEntailment = semanticConstraint $ Entails (path [0, 0]) (path [1])

-- | Substitute the actual value name for the formal before checking the output.
substitutedRequirement :: Constraint
substitutedRequirement =
    semanticConstraint $
        Substitute
            [Substitution (path [0]) (path [1])]
            (Satisfies (path [2]) $ refinementFormula (\v -> v .== variable "n"))
