{-# LANGUAGE DerivingVia #-}
{-# LANGUAGE FunctionalDependencies #-}

{- | Child-index paths into terms and graphs.

A 'Path' names a position by the child index taken at each level. 'Pathable'
reads and edits the value at a path. The instances for interned graphs are in
"Data.CFTA.Interned.Operations". They follow every alternative, so reading a
path from a node gives the union of the languages at that position. Constraint
theories build their constraints over these paths.
-}
module Data.CFTA.Path (
    Path (.., EmptyPath, ConsPath),
    ChildIndex (..),
    unPath,
    path,
    isStrictSubpath,
    Pathable (..),
    adjustAt,
) where

import Data.Coerce (coerce)
import Data.Hashable (Hashable (..))
import Data.Maybe (maybeToList)

import Data.CFTA.Index (ChildIndex (..))
import Data.CFTA.Internal.Tree (adjustAt)
import Data.CFTA.Term (Term)
import qualified Data.CFTA.Term as Term

{- | Path into an edge's children, represented as child indexes.

A path compares and hashes as its list of 'Int'. The base library specializes
the list instances for 'Int' but not for 'ChildIndex', and paths are compared
in every set and map of paths.
-}
newtype Path = Path [ChildIndex]
    deriving (Show)
    deriving (Eq, Ord) via [Int]

-- | Concatenation of paths, as the notation @p.q@ of tree automata.
instance Semigroup Path where
    Path left <> Path right = Path (left <> right)

instance Monoid Path where
    mempty = EmptyPath

instance Hashable Path where
    hashWithSalt salt (Path components) = salt `hashWithSalt` (coerce components :: [Int])

-- | Extract the raw child-index list from a 'Path'.
unPath :: Path -> [ChildIndex]
unPath (Path p) = p

-- | Build a 'Path' from child indexes.
path :: [ChildIndex] -> Path
path = Path

{-# COMPLETE EmptyPath, ConsPath #-}

pattern EmptyPath :: Path
pattern EmptyPath = Path []

pattern ConsPath :: ChildIndex -> Path -> Path
pattern ConsPath p ps <- Path (p : (Path -> ps))
  where
    ConsPath p (Path ps) = Path (p : ps)

-- | Whether the first path is a strict prefix of the second path.
isStrictSubpath :: Path -> Path -> Bool
isStrictSubpath EmptyPath EmptyPath = False
isStrictSubpath EmptyPath _ = True
isStrictSubpath (ConsPath p1 ps1) (ConsPath p2 ps2)
    | p1 == p2 = isStrictSubpath ps1 ps2
isStrictSubpath _ _ = False

-- | Things that can be inspected or edited by child-index paths.
class Pathable t t' | t -> t' where
    -- | Result type used when a path is absent.
    type Emptyable t'

    -- | Read the value at a path, returning the empty value when absent.
    getPath :: Path -> t -> Emptyable t'

    -- | Read all values reachable at a path.
    getAllAtPath :: Path -> t -> [t']

    -- | Apply a local edit at a path.
    modifyAtPath :: (t' -> t') -> Path -> t -> t

-- | Each child index is one index into the children.
instance Pathable (Term symbol) (Term symbol) where
    type Emptyable (Term symbol) = Maybe (Term symbol)

    getPath EmptyPath t = Just t
    getPath (ConsPath (ChildIndex p) ps) t = getPath ps =<< Term.child p t

    getAllAtPath p t = maybeToList $ getPath p t

    modifyAtPath f EmptyPath t = f t
    modifyAtPath f (ConsPath (ChildIndex p) ps) t = Term.adjustChild (modifyAtPath f ps) p t
