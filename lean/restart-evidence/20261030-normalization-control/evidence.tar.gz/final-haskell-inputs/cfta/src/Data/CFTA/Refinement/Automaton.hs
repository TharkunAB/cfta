{-# LANGUAGE PatternSynonyms #-}

{- | Transitions, automata, and the structural validation of an LTA.

An LTA is an interned graph from "Data.CFTA.Interned" whose symbols carry
refinements and whose edges carry liquid constraints. Build it with 'Node',
'Edge', 'mkEdge', and 'Mu', or with "Data.CFTA.Refinement.Guard" when a guard
names the constructor arguments. 'validate' checks the paper's restriction
that no guard inspects a position whose node is recursive, and that each
ranked symbol keeps one arity.
-}
module Data.CFTA.Refinement.Automaton (
    Automaton,
    Transition,
    pattern Transition,
    transitionSymbol,
    transitionRefinement,
    AutomatonError (..),
    validate,
    explicitView,
    fromViewError,
    located,
    automatonAlphabet,
    transitionsAt,
) where

import Data.Bifunctor (first)
import Data.Containers.ListUtils (nubOrdOn)
import qualified Data.IntMap.Strict as IntMap
import Data.List ((!?))
import qualified Data.Map.Strict as Map
import qualified Data.Set as Set

import qualified Data.CFTA as FTA
import Data.CFTA.Index (Arity (..))
import Data.CFTA.Interned (
    Edge (InternedEdge),
    FTAViewError (..),
    InternedState (..),
    Node (..),
    NodeId (..),
    UninternedEdge (..),
    edgeChildren,
    edgeConstraint,
    edgeSymbol,
    mkEdge,
    nodeEdges,
    nodeIdentity,
    toFTA,
 )
import Data.CFTA.Path (ChildIndex (..), Path, unPath)

import Data.CFTA.Constraint (Constraint, constraintPaths)
import Data.CFTA.Symbol (Formula, Symbol (RefinedSymbol))

-- | A liquid tree automaton: an interned graph with refined symbols and liquid constraints.
type Automaton = Node Symbol

-- | One refinement-labelled, constrained alternative of an LTA node.
type Transition = Edge Symbol

-- | Construct or match an LTA transition.
pattern Transition :: Symbol -> Formula -> [Automaton] -> Constraint -> Transition
pattern Transition symbol refinement children constraint <-
    InternedEdge _ (UninternedEdge (RefinedSymbol symbol refinement) children constraint)
  where
    Transition symbol refinement children constraint =
        mkEdge (RefinedSymbol symbol refinement) children constraint

{-# COMPLETE Transition #-}

-- | Symbol at the root of a transition.
transitionSymbol :: Transition -> Symbol
transitionSymbol (Transition symbol _ _ _) = symbol

-- | Refinement formula at the root of a transition.
transitionRefinement :: Transition -> Formula
transitionRefinement (Transition _ refinement _ _) = refinement

-- | A structural error found while validating an automaton.
data AutomatonError
    = -- | A recursive reference is free in the root.
      OpenAutomaton
    | {- | A guard position reaches a recursive node, which would produce an
      unbounded logical obligation during semantic operations.
      -}
      CyclicGuardReference !Transition !Path
    | -- | The same symbol occurs at two different arities: the arity found first, then the other arity.
      InconsistentArity
        -- | The symbol.
        !Symbol
        -- | The arity found first.
        !Arity
        -- | The other arity.
        !Arity
    | {- | A named guard, a contract, or a result names a number of children
      other than the constructor's child count.
      -}
      GuardArityMismatch
        -- | The symbol.
        !Symbol
        -- | The child count of the constructor.
        !Arity
        -- | The count that the guard, contract, or result names.
        !Arity
    deriving (Eq, Show)

{- | Check the structure of an LTA.

The graph must be closed, each ranked symbol must keep one arity, and no
guard may inspect a position whose node is recursive. The check does not
enumerate terms or call a solver.
-}
validate :: Automaton -> Either AutomatonError ()
validate root = do
    view <- explicitView root
    consistentArity Map.empty [edge | (_, edges) <- alternativesOf, edge <- edges]
    let cyclic = FTA.cyclicStates view
        recursive node = Set.member (InternedState (nodeIdentity node)) cyclic
        offending =
            [ (edge, target)
            | (node, edges) <- alternativesOf
            , edge <- edges
            , target <- Set.toList $ constraintPaths (edgeConstraint edge)
            , reached <- if null (unPath target) then [node] else nodesAt edge target
            , recursive reached
            ]
    case offending of
        (edge, target) : _ -> Left $ CyclicGuardReference edge target
        [] -> Right ()
  where
    alternativesOf = located root

    consistentArity _ [] = Right ()
    consistentArity known (Transition symbol _ children _ : rest) =
        case Map.lookup symbol known of
            Nothing -> consistentArity (Map.insert symbol (Arity (length children)) known) rest
            Just expected
                | expected == Arity (length children) -> consistentArity known rest
                | otherwise -> Left $ InconsistentArity symbol expected (Arity (length children))

-- | 'toFTA' with the LTA error vocabulary: one state per reachable node.
explicitView :: Automaton -> Either AutomatonError (FTA.FTA InternedState Symbol Constraint)
explicitView = first viewError . toFTA
  where
    viewError OpenNode = OpenAutomaton

{- | Report a structural error of an explicit view as a bug. The explicit view
of a closed interned graph has a row for each state that it reaches.
-}
fromViewError :: FTA.FTAError InternedState -> AutomatonError
fromViewError err =
    error $
        "cfta bug in Data.CFTA.Refinement.Automaton: the explicit view of an interned graph is malformed: " <> show err

{- | Every reachable node with its alternatives, in identity order.

A recursive node lists its unfolded alternatives, so the children of every
listed transition are again listed nodes.
-}
located :: Automaton -> [(Automaton, [Transition])]
located EmptyNode = []
located root = IntMap.elems $ collect IntMap.empty [root]
  where
    collect seen [] = seen
    collect seen (Rec _ : pending) = collect seen pending
    collect seen (node : pending)
        | IntMap.member ident seen = collect seen pending
        | otherwise = collect (IntMap.insert ident (node, edges) seen) (concatMap edgeChildren edges <> pending)
      where
        NodeId ident = nodeIdentity node
        edges = nodeEdges node

-- | Finite ranked alphabet used by an automaton.
automatonAlphabet :: Automaton -> Set.Set Symbol
automatonAlphabet root = Set.fromList [edgeSymbol edge | (_, edges) <- located root, edge <- edges]

{- | The nodes at a child-index path below a transition.

The first index selects a child of the transition; each further index selects
that child of every alternative of the nodes reached so far. The empty path
gives no nodes.
-}
nodesAt :: Transition -> Path -> [Automaton]
nodesAt edge target = case unPath target of
    [] -> []
    ChildIndex index : rest -> maybe [] (descend rest) (edgeChildren edge !? index)
  where
    descend [] node = [node]
    descend (ChildIndex index : rest) node =
        nubOrdOn nodeIdentity $
            concat
                [ descend rest child
                | alternative <- nodeEdges node
                , Just child <- [edgeChildren alternative !? index]
                ]

{- | Transitions reachable at a position below one transition (Definition 5,
"Transitions at a position", of Mishra and Jagannathan, /Liquid Tree Automata/,
arXiv:2605.13456).

The empty position denotes the supplied transition. A non-empty position
selects the alternatives of every node at that position.
-}
transitionsAt :: Transition -> Path -> [Transition]
transitionsAt edge target
    | null (unPath target) = [edge]
    | otherwise = concatMap nodeEdges $ nodesAt edge target
