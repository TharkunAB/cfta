{-# LANGUAGE PatternSynonyms #-}

{- | Liquid tree automata over refinements.

An LTA is an interned graph whose symbols carry refinements. A transition has
a ranked symbol, child nodes, and the paper's Boolean constraint language
over paths into the candidate term. 'Same' is syntactic equality and 'Entails'
is semantic refinement implication. 'Satisfies' compares a path with a literal
requirement, avoiding phantom constant children.
'Holds' states a formula about the terms at several paths, and assumes each
term's refinement for its name. 'Substitute' applies the paper's
actual-for-formal position substitutions before semantic checks and syntactic
comparison. A stored refinement is a 'Formula' about the value variable
'Data.CFTA.Symbol.valueName'.
"Data.CFTA.Refinement.Expression" writes refinements as Haskell functions of
the value.

Recursive automata are accepted. As required by the LTA construction, a guard
may only inspect positions whose nodes are acyclic; recursive nodes can still
occur elsewhere in the generated term.

"Data.CFTA.Refinement.Guard" provides higher-level guard syntax in terms of
constructor arguments. This module also exposes the underlying constructors
for tools that need arbitrary paths.
-}
module Data.CFTA.Refinement (
    -- * Terms and refinements
    Symbol (..),
    module Data.CFTA.Path,
    Formula,
    eraseRefinements,

    -- * Guards
    Substitution (..),
    Guard (..),
    Constraint (..),
    Verdict (..),
    Entailment (Entailment, entails),
    entailmentWithBindings,
    entailsWithBindings,
    RefinementRelation (..),
    refinementRelation,
    SemanticIntersection (..),
    semanticIntersection,
    evaluateGuard,
    evaluateGuardWithShape,
    Observed (..),
    Leafness (..),
    Observations,
    leafnessOf,
    evaluateConstraint,

    -- * Automata
    module Data.CFTA.Interned,
    module Data.CFTA.Enumeration,
    module Data.CFTA.Template,
    Automaton,
    Transition,
    pattern Transition,
    transitionSymbol,
    transitionRefinement,
    AutomatonError (..),
    validate,
    explicitView,
    automatonAlphabet,
    transitionsAt,

    -- * Pruning and denotation
    PruneError (..),
    prune,
    DenotationError (..),
    accepts,
    denotationAtMost,

    -- * Similarity and minimization
    TransitionId (..),
    Subtyping (..),
    refinementSubtypingOn,
    Similarity,
    SimilarityPair (..),
    SimilarityError (..),
    similarity,
    similarityWithin,
    similarityPairs,
    MinimizeError (..),
    minimize,
    ReductionError (..),
    reduce,
) where

import Data.CFTA.Enumeration
import Data.CFTA.Interned
import Data.CFTA.Path
import Data.CFTA.Template

import Data.CFTA.Refinement.Automaton
import Data.CFTA.Refinement.Denotation
import Data.CFTA.Refinement.Evaluate
import Data.CFTA.Refinement.Minimize
import Data.CFTA.Refinement.Prune
import Data.CFTA.Refinement.Verdict
import Data.CFTA.Symbol
