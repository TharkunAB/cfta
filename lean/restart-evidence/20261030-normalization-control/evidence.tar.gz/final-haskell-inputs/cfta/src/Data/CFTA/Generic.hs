{-# LANGUAGE AllowAmbiguousTypes #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE DefaultSignatures #-}
{-# LANGUAGE DerivingVia #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE KindSignatures #-}

{- | Derive a regular tree grammar and term codecs from an algebraic datatype.

Derive 'Generic', then declare an empty 'HasFTA' instance. Recursive fields
refer to the same type state. Atomic fields need an explicit finite domain.
The grammar describes constructor structure. Constraint layers add invariants.

Atomic types have no constructors in the grammar; their values are literals.
'Int', 'Integer', 'Char', and 'Text' are atomic. Make another type atomic
with @deriving via@, or with 'atomic' and handwritten codecs:

@
deriving via (Atomic Double) instance HasFTA Double
@

A literal is a 'Constructor' whose name is the 'Show' text of its value.
'domain' shows each value once, when the grammar is built, and 'encodeTerm'
shows a value when it encodes it, for example to rank the value. 'decodeTerm'
reads each literal of a term back with 'Read'. A generator decodes the term
of a sample when the program demands the value, so 'Read' runs once for each
atomic leaf of each demanded sample.

A grammar symbol must be a first-order value with
'Eq' and 'Ord', so a literal keeps its value as text. The codec is a method
of the type, and it does not see the domain, so the text is all that it can
decode. 'Show' and 'Read' are the text codec that @base@ gives every atomic
type. A 'Show' instance that 'Read' does not invert gives literals that do
not decode. The generators of @cfta-generator@ decode one term for each
constructor when they are built, and report @UndecodableConstructor@ for such
a literal.
-}
module Data.CFTA.Generic (
    HasFTA (..),
    Description (..),
    atomic,
    Atomic (..),
    TypedFTA,
    datatypeFTA,
    datatypeDecode,
    decodeLabelledTerm,
    annotateDatatype,
    annotateConstructors,
    deriveFTA,
    deriveFTAWith,
    deriveFTAWithGrowthLimit,
    defaultGrowthLimit,
    Domains,
    domain,
    DeriveError (..),
    Constructor (..),
    Field (..),
    fieldNamed,
    constructorLabel,
) where

import Control.Applicative ((<|>))
import Control.Monad (foldM, (<=<))
import Data.Bifunctor (first)
import Data.Char (digitToInt, isDigit)
import Data.Containers.ListUtils (nubOrd)
import Data.Kind (Type)
import Data.List (find)
import qualified Data.Map.Strict as Map
import Data.Proxy (Proxy (Proxy))
import qualified Data.Set as Set
import Data.Text (Text)
import Data.Type.Equality ((:~:) (Refl))
import Data.Typeable (TypeRep, Typeable, eqT, splitTyConApp, tyConModule, tyConName, tyConPackage, typeRep)
import GHC.Generics hiding (Constructor)
import qualified GHC.Generics as Generic
import Text.Read (readMaybe)

import qualified Data.CFTA as FTA
import Data.CFTA.Constraint (Constraint, noConstraint)
import Data.CFTA.Term (Term)
import qualified Data.CFTA.Term as Term

-- | One constructor field, including its zero-based child position.
data Field = Field
    { fieldPosition :: !Int
    , fieldName :: !(Maybe String)
    , fieldType :: !TypeRep
    }
    deriving (Eq, Ord, Show)

-- | A constructor in one fully applied datatype, or one primitive literal.
data Constructor = Constructor
    { constructorType :: !TypeRep
    , constructorName :: !String
    , constructorFields :: ![Field]
    }
    deriving (Eq, Ord, Show)

-- | Find a named record field. Positional fields have no selector name.
fieldNamed :: String -> Constructor -> Maybe Field
fieldNamed name = find ((== Just name) . fieldName) . constructorFields

{- | A label that distinguishes constructor types and primitive values.

Type constructors include package, module, and type names, so the label is
unique within one build. The package component is the unit identifier, which
can change between builds; do not persist labels across builds. Length
prefixes keep names and type arguments distinct without depending on a
delimiter convention.
-}
constructorLabel :: Constructor -> String
constructorLabel constructor = encodeName (typeLabel $ constructorType constructor) <> encodeName (constructorName constructor)
  where
    encodeName name = show (length name) <> ":" <> name
    typeLabel typ =
        let (con, arguments) = splitTyConApp typ
         in concatMap encodeName [tyConPackage con, tyConModule con, tyConName con]
                <> show (length arguments)
                <> ":"
                <> concatMap (encodeName . typeLabel) arguments

-- | A checked datatype grammar with the matching typed decoder.
data TypedFTA constraint a = TypedFTA
    { datatypeFTA :: !(FTA.FTA TypeRep Constructor constraint)
    -- ^ The finite grammar, including any caller-supplied annotations.
    , datatypeDecode :: Term Constructor -> Maybe a
    -- ^ Decode a value. The codec does not interpret transition annotations.
    }

-- | Annotate constructors while retaining the grammar and its typed codecs.
annotateDatatype :: (Constructor -> constraint) -> TypedFTA old a -> TypedFTA constraint a
annotateDatatype annotate datatype =
    datatype{datatypeFTA = FTA.annotate (\_ -> annotate . FTA.transitionSymbol) $ datatypeFTA datatype}

{- | Annotate constructors by name, and give each other constructor a default.

A name that no constructor of the grammar has gives 'UnknownConstructors', so a
misspelt name cannot fall back to the default. Constructors of different types
that have the same name get the same annotation.
-}
annotateConstructors ::
    constraint -> [(String, constraint)] -> TypedFTA old a -> Either DeriveError (TypedFTA constraint a)
annotateConstructors fallback named datatype
    | null unknown = Right $ annotateDatatype annotate datatype
    | otherwise = Left $ UnknownConstructors unknown
  where
    table = Map.fromList named
    unknown = nubOrd [name | (name, _) <- named, not $ Set.member name known]
      where
        known =
            Set.fromList
                [ constructorName $ FTA.transitionSymbol transition
                | transitions <- Map.elems $ FTA.transitionTable $ datatypeFTA datatype
                , transition <- transitions
                ]
    annotate constructor = Map.findWithDefault fallback (constructorName constructor) table

{- | Decode labels produced by 'constructorLabel'. Reject unknown labels.

Constraint layers can use their own interned string alphabet. The lookup table
is shared by all calls through one partially applied decoder, if GHC keeps the
partial application. A call that applies the decoder in full can build the
table again.
-}
decodeLabelledTerm :: TypedFTA constraint a -> Term String -> Maybe a
decodeLabelledTerm datatype = datatypeDecode datatype <=< restore
  where
    restore = traverse (`Map.lookup` constructors)
      where
        constructors =
            Map.fromList
                [ (constructorLabel constructor, constructor)
                | transitions <- Map.elems $ FTA.transitionTable $ datatypeFTA datatype
                , transition <- transitions
                , let constructor = FTA.transitionSymbol transition
                ]

-- | Finite literal alternatives for primitive field types.
newtype Domains = Domains (Map.Map TypeRep [Constructor])

instance Semigroup Domains where
    Domains left <> Domains right = Domains $ Map.union right left

instance Monoid Domains where
    mempty = Domains Map.empty

{- | Supply a finite domain for an atomic field type.

Built-in atomic types are 'Int', 'Integer', 'Char', and 'Text'. Repeated values
are removed in their first-occurrence order. An empty domain accepts nothing.
When domains are combined, the rightmost domain for a type takes precedence.
-}
domain :: forall a. (Typeable a, Show a) => [a] -> Domains
domain values = Domains $ Map.singleton typ $ nubOrd [Constructor typ (show value) [] | value <- values]
  where
    typ = typeRep (Proxy @a)

-- | Failure while deriving a finite grammar.
data DeriveError
    = -- | An atomic field type has no domain.
      MissingDomain !TypeRep
    | -- | A domain was supplied for a type that has constructors.
      NonAtomicDomain !TypeRep
    | {- | A type constructor grows its argument more often along one path than the
      growth limit allows, as every infinite state set does. The fields are the
      growth limit and the first growth step on that path. A finite type that
      grows more often needs a higher limit, see 'deriveFTAWithGrowthLimit'.
      -}
      NonRegularRecursion !Int !TypeRep !TypeRep
    | -- | The derived transition table is not a valid ranked grammar.
      InvalidDerivedFTA !(FTA.FTAError TypeRep)
    | -- | Annotation names that no constructor of the grammar has.
      UnknownConstructors ![String]
    deriving (Eq, Show)

-- | Structural alternatives for one type. Child descriptions remain lazy.
data Description
    = AtomicType TypeRep
    | AlgebraicType TypeRep [(Constructor, [Description])]

-- | Describe a type whose values are literals from a finite domain.
atomic :: forall a. (Typeable a) => Proxy a -> Description
atomic = AtomicType . typeRep

{- | Make a type atomic through @deriving via@.

Literals are written with 'Show' and read back with 'Read'. The grammar and
the codecs use the type inside the wrapper, so the wrapper does not appear in
labels or domains.
-}
newtype Atomic a = Atomic a

instance (Typeable a, Show a, Read a) => HasFTA (Atomic a) where
    describeType _ = atomic (Proxy @a)
    encodeTerm (Atomic value) = encodeAtomic value
    decodeTerm = fmap Atomic . decodeAtomic

{- | Datatypes whose finite constructor structure has a regular tree grammar.

The default methods use 'Generic'. Declare an empty instance for each user
datatype in a recursive family. Codecs use the complete datatype; a finite
primitive domain restricts the derived grammar, not the codec itself.

A handwritten codec must keep 'decodeTerm' total on the terms of the derived
grammar, which are the terms 'encodeTerm' produces. The generators decode
generated terms without a fallback.
-}
class (Typeable a) => HasFTA a where
    -- | Describe the type as atomic, or as its constructors and their fields.
    describeType :: Proxy a -> Description
    default describeType :: (GConstructors (Rep a)) => Proxy a -> Description
    describeType proxy = AlgebraicType (typeRep proxy) $ gConstructors (typeRep proxy) (Proxy @(Rep a))

    -- | Encode a datatype value as a constructor term.
    encodeTerm :: a -> Term Constructor
    default encodeTerm :: (Generic a, GConstructors (Rep a)) => a -> Term Constructor
    encodeTerm = gEncode (typeRep $ Proxy @a) . from

    -- | Decode a constructor term. Reject wrong types, labels, and arities.
    decodeTerm :: Term Constructor -> Maybe a
    default decodeTerm :: (Generic a, GConstructors (Rep a)) => Term Constructor -> Maybe a
    decodeTerm = fmap to . gDecode (typeRep $ Proxy @a)

-- | Derive a grammar whose fields need no explicit atomic domains.
deriveFTA :: forall a. (HasFTA a) => Either DeriveError (TypedFTA Constraint a)
deriveFTA = deriveFTAWith mempty

{- | Derive the reachable grammar without enumerating datatype values.

States are fully applied types. A repeated type reuses its row. A type
constructor may grow its argument along a path, for example from @T Int@ to
@T (Maybe Int)@, when the growth stops. The growth limit is
'defaultGrowthLimit'; 'deriveFTAWithGrowthLimit' sets another limit.
-}
deriveFTAWith :: forall a. (HasFTA a) => Domains -> Either DeriveError (TypedFTA Constraint a)
deriveFTAWith = deriveFTAWithGrowthLimit defaultGrowthLimit

-- | The growth limit of 'deriveFTA' and 'deriveFTAWith': eight.
defaultGrowthLimit :: Int
defaultGrowthLimit = 8

{- | 'deriveFTAWith' with a growth limit: the number of times that one type
constructor may grow its argument along one path.

A type constructor grows where a type is larger than the nearest ancestor with
the same type constructor on its path. A path where one type constructor grows
more than that many times gives 'NonRegularRecursion'. Every grammar with an
infinite state set has such a path: it reaches types of every size, and there
are finitely many type constructors, so the sizes of one type constructor grow
without bound along it. So the check rejects every infinite state set, whatever
the limit. It rejects a finite one only when one type constructor grows more
often than the limit along one path. A limit of zero rejects every growth.
-}
deriveFTAWithGrowthLimit :: forall a. (HasFTA a) => Int -> Domains -> Either DeriveError (TypedFTA Constraint a)
deriveFTAWithGrowthLimit growthLimit (Domains domains) = do
    rows <- visit [] Map.empty (describeType $ Proxy @a)
    graph <- first InvalidDerivedFTA $ FTA.mkFTA (typeRep $ Proxy @a) (Map.toList rows)
    pure $ TypedFTA graph decodeTerm
  where
    visit ancestors rows description
        | Map.member typ rows = Right rows
        -- The ancestors come nearest first. The chain lists the types with the
        -- type constructor of this type from the root down to this type.
        | chain <- reverse (filter (sameConstructor typ) ancestors) <> [typ]
        , grown <- [(outer, next) | (outer, next) <- zip chain (drop 1 chain), typeSize next > typeSize outer]
        , length grown > growthLimit
        , (outer, next) : _ <- grown =
            Left $ NonRegularRecursion growthLimit outer next
        | otherwise = case description of
            AtomicType _ -> case Map.lookup typ domains of
                Nothing -> Left $ MissingDomain typ
                Just constructors -> Right $ Map.insert typ [FTA.Transition constructor [] noConstraint | constructor <- constructors] rows
            AlgebraicType _ constructors
                | Map.member typ domains -> Left $ NonAtomicDomain typ
                | otherwise ->
                    let transitions = [FTA.Transition constructor (map descriptionType children) noConstraint | (constructor, children) <- constructors]
                        allocated = Map.insert typ transitions rows
                     in foldM (visit $ typ : ancestors) allocated (concatMap snd constructors)
      where
        typ = descriptionType description
    sameConstructor typ ancestor = fst (splitTyConApp typ) == fst (splitTyConApp ancestor)
    typeSize typ = 1 + sum (map typeSize $ snd $ splitTyConApp typ) :: Integer

-- | Read the type identity without inspecting a recursive description.
descriptionType :: Description -> TypeRep
descriptionType (AtomicType typ) = typ
descriptionType (AlgebraicType typ _) = typ

-- | Generic sums retain constructor alternatives and their codecs.
class GConstructors (f :: Type -> Type) where
    gConstructors :: TypeRep -> Proxy f -> [(Constructor, [Description])]
    gEncode :: TypeRep -> f p -> Term Constructor
    gDecode :: TypeRep -> Term Constructor -> Maybe (f p)

instance (GConstructors f) => GConstructors (M1 D metadata f) where
    gConstructors typ _ = gConstructors typ (Proxy @f)
    gEncode typ (M1 value) = gEncode typ value
    gDecode typ = fmap M1 . gDecode typ

instance (GConstructors left, GConstructors right) => GConstructors (left :+: right) where
    gConstructors typ _ = gConstructors typ (Proxy @left) <> gConstructors typ (Proxy @right)
    gEncode typ (L1 value) = gEncode typ value
    gEncode typ (R1 value) = gEncode typ value
    gDecode typ term = (L1 <$> gDecode typ term) <|> (R1 <$> gDecode typ term)

instance (Generic.Constructor metadata, GFields fields) => GConstructors (M1 C metadata fields) where
    gConstructors typ _ = [(genericConstructor @metadata @fields typ, map snd $ gFields $ Proxy @fields)]
    gEncode typ (M1 fields) = Term.Node (genericConstructor @metadata @fields typ) (gEncodeFields fields)

    -- The type and the name identify a constructor, and the fields check the
    -- arity, so the decoder does not build the constructor to compare it.
    gDecode typ (Term.Node constructor children)
        | constructorType constructor == typ
        , constructorName constructor == conName (undefined :: M1 C metadata fields ()) = do
            (fields, rest) <- gDecodeFields children
            if null rest then Just $ M1 fields else Nothing
        | otherwise = Nothing

instance GConstructors V1 where
    gConstructors _ _ = []
    gEncode _ value = case value of {}
    gDecode _ _ = Nothing

-- | Construct metadata without evaluating any field value.
genericConstructor ::
    forall (metadata :: Meta) fields. (Generic.Constructor metadata, GFields fields) => TypeRep -> Constructor
genericConstructor typ =
    Constructor typ (conName (undefined :: M1 C metadata fields ())) $
        zipWith (\index (name, description) -> Field index name (descriptionType description)) [0 ..] (gFields $ Proxy @fields)

-- | Generic products retain field order and consume one term per field.
class GFields (f :: Type -> Type) where
    gFields :: Proxy f -> [(Maybe String, Description)]
    gEncodeFields :: f p -> [Term Constructor]
    gDecodeFields :: [Term Constructor] -> Maybe (f p, [Term Constructor])

instance GFields U1 where
    gFields _ = []
    gEncodeFields U1 = []
    gDecodeFields terms = Just (U1, terms)

instance (HasFTA a) => GFields (K1 index a) where
    gFields _ = [(Nothing, describeType $ Proxy @a)]
    gEncodeFields (K1 value) = [encodeTerm value]
    gDecodeFields [] = Nothing
    gDecodeFields (term : rest) = (\value -> (K1 value, rest)) <$> decodeTerm term

instance (Selector metadata, GFields fields) => GFields (M1 S metadata fields) where
    gFields _ = [(name, description) | (_, description) <- gFields (Proxy @fields)]
      where
        name = case selName (undefined :: M1 S metadata fields ()) of
            "" -> Nothing
            selector -> Just selector
    gEncodeFields (M1 fields) = gEncodeFields fields
    gDecodeFields terms = do
        (fields, rest) <- gDecodeFields terms
        pure (M1 fields, rest)

instance (GFields left, GFields right) => GFields (left :*: right) where
    gFields _ = gFields (Proxy @left) <> gFields (Proxy @right)
    gEncodeFields (left :*: right) = gEncodeFields left <> gEncodeFields right
    gDecodeFields terms = do
        (left, remaining) <- gDecodeFields terms
        (right, rest) <- gDecodeFields remaining
        pure (left :*: right, rest)

-- | Encode one atomic value. Atomic constructor labels contain its literal.
encodeAtomic :: forall a. (Typeable a, Show a) => a -> Term Constructor
encodeAtomic value = Term.Node (Constructor (typeRep $ Proxy @a) (show value) []) []

-- | Decode a literal only when its type and nullary shape match.
decodeAtomic :: forall a. (Typeable a, Read a) => Term Constructor -> Maybe a
decodeAtomic (Term.Node (Constructor typ literal []) [])
    | typ == typeRep (Proxy @a) = case (eqT @a @Integer, eqT @a @Int) of
        (Just Refl, _) -> decimal literal
        (_, Just Refl) -> fromInteger <$> decimal literal
        _ -> readMaybe literal
decodeAtomic _ = Nothing

{- | Read the 'Show' text of an integer: an optional minus sign and decimal
digits. It is 'readMaybe' on that text, without the lexer of 'Read'.
-}
decimal :: String -> Maybe Integer
decimal ('-' : digits@(_ : _)) = negate <$> natural digits
decimal digits@(_ : _) = natural digits
decimal [] = Nothing

-- | Read decimal digits.
natural :: String -> Maybe Integer
natural = go 0
  where
    go !value [] = Just value
    go !value (character : rest)
        | isDigit character = go (value * 10 + toInteger (digitToInt character)) rest
        | otherwise = Nothing

deriving via (Atomic Int) instance HasFTA Int
deriving via (Atomic Integer) instance HasFTA Integer
deriving via (Atomic Char) instance HasFTA Char
deriving via (Atomic Text) instance HasFTA Text

instance HasFTA Bool
instance HasFTA ()
instance (HasFTA a) => HasFTA [a]
instance (HasFTA a) => HasFTA (Maybe a)
instance (HasFTA a, HasFTA b) => HasFTA (Either a b)
instance (HasFTA a, HasFTA b) => HasFTA (a, b)
instance (HasFTA a, HasFTA b, HasFTA c) => HasFTA (a, b, c)
