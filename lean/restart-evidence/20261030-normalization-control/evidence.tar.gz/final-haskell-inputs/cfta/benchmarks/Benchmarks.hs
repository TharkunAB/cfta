{-# LANGUAGE OverloadedStrings #-}

module Main (main) where

import Control.Exception (evaluate)
import Data.List (sort, sortBy)
import Data.Ord (comparing)
import qualified Data.Set as Set
import qualified Data.Text as Text
import System.CPUTime (getCPUTime)
import System.Environment (getArgs)
import Text.Printf (printf)

import Data.CFTA.Equality
import Data.CFTA.Symbol (Symbol (Symbol))
import Data.CFTA.TermSearch (constFunc, filterType, reduceFully, theArrowNode, typeNode)

data Bench = Bench
    { benchName :: String
    , benchRepeats :: Int
    , benchAction :: Int -> IO Int
    }

main :: IO ()
main = do
    preparePathOrderInputs
    multiplier <- parseMultiplier <$> getArgs
    putStrLn "benchmark,cpu_seconds,repeats,checksum"
    mapM_ (runBench multiplier) benchmarks

parseMultiplier :: [String] -> Int
parseMultiplier [] = 1
parseMultiplier (x : _) =
    case reads x of
        [(n, "")] -> max 1 n
        _ -> 1

runBench :: Int -> Bench -> IO ()
runBench multiplier Bench{benchName, benchRepeats, benchAction} = do
    start <- getCPUTime
    checksum <- loop totalRepeats 0
    end <- getCPUTime
    let seconds = fromIntegral (end - start) / (10 ^ (12 :: Int) :: Double)
    printf "%s,%.6f,%d,%d\n" benchName seconds totalRepeats checksum
  where
    totalRepeats = benchRepeats * multiplier

    loop 0 !acc = return acc
    loop n !acc = do
        x <- benchAction n
        loop (n - 1) (acc + x)

benchmarks :: [Bench]
benchmarks =
    [ Bench "getPath/type-search-node" 2000 $ \i ->
        forceNode $ getPath (path [2, 0, if i >= 0 then 2 else 1]) typeSearchNode
    , Bench "mkEqConstraints/congruence" 600 $ \i ->
        forceEqConstraints $ mkEqConstraints (congruencePathSets i)
    , Bench "mkEqConstraints/congruence-chain-64" 200 $ \i ->
        forceEqConstraints $ mkEqConstraints (congruenceChain 64 i)
    , Bench "eqConstraintsDescend/wide-sparse" 4000 $ \i ->
        forceEqConstraints $ eqConstraintsDescend wideSparseConstraints (ChildIndex (i `rem` 16))
    , Bench "intersect/finite-constrained" 800 $ \i ->
        forceNode $ finiteChoiceNode i `intersect` constrainedChoiceNode i
    , Bench "intersect/recursive-types" 300 $ \i ->
        forceNode $ recursiveTypeA i `intersect` recursiveTypeB i
    , Bench "reduce/recursive-paths" 120 $ \i ->
        forceNodes $ reduceEqConstraints recursivePathConstraints EmptyConstraints (recursivePathNodes i)
    , Bench "reduce/filter-maybe-int-size-2" 80 $ \i ->
        forceNode $ reduceFully (filterMaybeIntSize2 i)
    , Bench "reduce/filter-list-int-size-3" 20 $ \i ->
        forceNode $ reduceFully (filterListIntSize3 i)
    , Bench "enumerate/reduced-filter-maybe-int-size-2" 80 $ \i ->
        forceInt $ length (take 64 (terms (reduceFully (filterMaybeIntSize2 i))))
    , Bench "sort/path-eclasses/cached/small" 120 $ \i ->
        forcePathEClasses $
            sort (selectPathOrderInput smallPathOrderInputs i)
    , Bench "sort/path-eclasses/cached/shared-prefix" 40 $ \i ->
        forcePathEClasses $
            sort (selectPathOrderInput sharedPrefixPathOrderInputs i)
    , Bench "sort/path-eclasses/cached/divergent-branch" 120 $ \i ->
        forcePathEClasses $
            sort (selectPathOrderInput divergentBranchPathOrderInputs i)
    ]

forceNode :: Node Symbol -> IO Int
forceNode n = forceInt (nodeCount n + edgeCount n)

forceNodes :: [Node Symbol] -> IO Int
forceNodes = forceInt . sum . map (\n -> nodeCount n + edgeCount n)

forceEqConstraints :: EqConstraints -> IO Int
forceEqConstraints =
    forceInt
        . sum
        . map (sum . map (length . unPath) . Set.toList . unPathEClass)
        . unsafeGetEclasses

-- | Force a sorted equality-class result through its path sets.
forcePathEClasses :: [PathEClass] -> IO Int
forcePathEClasses =
    forceInt
        . foldl' (\acc pec -> acc * 33 + pathEClassFingerprint (unPathEClass pec)) 5381
  where
    pathEClassFingerprint =
        foldl' (\acc p -> acc * 33 + foldl' (\n (ChildIndex i) -> n * 33 + i) 5381 (unPath p)) 5381

forceInt :: Int -> IO Int
forceInt = evaluate

-- | Force both views before timing so the benchmark measures comparison.
preparePathOrderInputs :: IO ()
preparePathOrderInputs = do
    mapM_ forcePathEClasses allInputs
    mapM_ forcePathTries allInputs
  where
    allInputs =
        smallPathOrderInputs
            ++ sharedPrefixPathOrderInputs
            ++ divergentBranchPathOrderInputs

    forcePathTries =
        forceInt
            . sum
            . map (sum . map (sum . map (\(ChildIndex i) -> i) . unPath) . fromPathTrie . getPathTrie)

-- | Select one of several deterministic input permutations.
selectPathOrderInput :: [[PathEClass]] -> Int -> [PathEClass]
selectPathOrderInput inputs salt = inputs !! (salt `rem` length inputs)

-- | Small equality classes with one common leading path.
smallPathOrderInputs :: [[PathEClass]]
smallPathOrderInputs = pathOrderInputs smallPathSets
  where
    smallPathSets =
        [ [ path [0, 0, 0]
          , path $ map ChildIndex [1, n `div` 32, n `rem` 32]
          , path $ map ChildIndex [2, n `rem` 17, n `div` 17]
          ]
        | n <- [0 .. 255]
        ]

-- | Larger equality classes whose comparisons share sixteen paths.
sharedPrefixPathOrderInputs :: [[PathEClass]]
sharedPrefixPathOrderInputs = pathOrderInputs sharedPrefixPathSets
  where
    sharedPrefixPathSets =
        [ [path [0, k, 0, 0] | k <- [0 .. 15]]
            ++ [path $ map ChildIndex [1, n `div` 16, n `rem` 16, 0]]
        | n <- [0 .. 127]
        ]

-- | Equality classes with a divergent branching shape.
divergentBranchPathOrderInputs :: [[PathEClass]]
divergentBranchPathOrderInputs = pathOrderInputs divergentBranchPathSets
  where
    divergentBranchPathSets =
        concat
            [ [ [path [0, k], path [0, k + 1]]
              , [path [0, k], path [1, k]]
              ]
            | k <- [1, 3 .. 255]
            ]

-- | Build and deterministically permute equality classes outside timed work.
pathOrderInputs :: [[Path]] -> [[PathEClass]]
pathOrderInputs pathSets =
    [ map snd
        $ sortBy (comparing fst)
        $ [ ((index * 73 + salt * 37) `rem` 257, pec)
          | (index, pec) <- zip [(0 :: Int) ..] corpus
          ]
    | salt <- [0 .. 7]
    ]
  where
    corpus = concatMap (unsafeGetEclasses . mkEqConstraints . (: [])) pathSets

typeSearchNode :: Node Symbol
typeSearchNode =
    appNode
        (appNode (monoFunctionScope 0) (monoArgumentScope 0))
        (monoTermsOfSize 0 2)

filterMaybeIntSize2 :: Int -> Node Symbol
filterMaybeIntSize2 i =
    filterType
        (monoTermsOfSize i 2)
        (typeNode @(Maybe Int))

filterListIntSize3 :: Int -> Node Symbol
filterListIntSize3 i =
    filterType
        (monoTermsOfSize i 3)
        (typeNode @[Int])

monoTermsOfSize :: Int -> Int -> Node Symbol
monoTermsOfSize salt size = union (go size)
  where
    go 0 = []
    go 1 = [monoArgumentScope salt, monoFunctionScope salt]
    go n =
        [ appNode (union (go i)) (union (go (n - i)))
        | i <- [1 .. n - 1]
        ]

appNode :: Node Symbol -> Node Symbol -> Node Symbol
appNode f x =
    Node
        [ mkEdge
            "app"
            [getPath (path [0, 2]) f, theArrowNode, f, x]
            ( equalityConstraint $
                mkEqConstraints
                    [ [path [1], path [2, 0, 0]]
                    , [path [3, 0], path [2, 0, 1]]
                    , [path [0], path [2, 0, 2]]
                    ]
            )
        ]

monoArgumentScope :: Int -> Node Symbol
monoArgumentScope salt =
    Node
        [ constFunc (named "x" salt) (typeNode @Int)
        , constFunc (named "y" salt) (typeNode @Int)
        , constFunc (named "xs" salt) (typeNode @[Int])
        ]

monoFunctionScope :: Int -> Node Symbol
monoFunctionScope salt =
    Node
        [ constFunc (named "idInt" salt) (typeNode @(Int -> Int))
        , constFunc (named "JustInt" salt) (typeNode @(Int -> Maybe Int))
        , constFunc (named "headInt" salt) (typeNode @([Int] -> Int))
        , constFunc (named "nilInt" salt) (typeNode @[Int])
        , constFunc (named "consInt" salt) (typeNode @(Int -> [Int] -> [Int]))
        ]

named :: String -> Int -> Symbol
named prefix salt = Symbol $ Text.pack (prefix ++ show salt)

{- | The congruence input at a chosen size: a chain of equal root paths, each
with two children in one class. Every root forces classes over the children
of all roots, so a pairwise congruence scan grows quadratically with the size.
The size counts links: @congruenceChain 64@ gives 65 root pairs over 66 roots.
-}
congruenceChain :: Int -> Int -> [[Path]]
congruenceChain size salt =
    [[path [ChildIndex i], path [ChildIndex (i + 1)]] | i <- [base .. base + size]]
        ++ [[path [ChildIndex i, 0], path [ChildIndex i, 1]] | i <- [base .. base + size]]
  where
    base = salt `rem` 3

congruencePathSets :: Int -> [[Path]]
congruencePathSets salt =
    [ [path [ChildIndex i], path [ChildIndex (i + 1)]]
    | i <- [base .. base + 5]
    ]
        ++ [ [path [ChildIndex i, 0], path [ChildIndex i, 1]]
           | i <- [base .. base + 5]
           ]
  where
    base = salt `rem` 3

wideSparseConstraints :: EqConstraints
wideSparseConstraints =
    mkEqConstraints
        [ [path [i, 0], path [i, 1]]
        | i <- [0 .. 15]
        ]

finiteChoiceNode :: Int -> Node Symbol
finiteChoiceNode salt =
    Node
        [ Edge (named "f" salt) [choiceAB salt, choiceAB salt]
        , Edge (named "g" salt) [choiceAB salt, choiceAB salt]
        ]

constrainedChoiceNode :: Int -> Node Symbol
constrainedChoiceNode salt =
    Node
        [ mkEdge (named "f" salt) [choiceAB salt, choiceAB salt] (equalityConstraint $ mkEqConstraints [[path [0], path [1]]])
        , Edge (named "g" salt) [choiceAB salt, choiceAB salt]
        ]

choiceAB :: Int -> Node Symbol
choiceAB salt = Node [Edge (named "a" salt) [], Edge (named "b" salt) []]

recursivePathConstraints :: EqConstraints
recursivePathConstraints = mkEqConstraints [[path [0, 0, 0, 0], path [1, 0, 0]]]

recursivePathNodes :: Int -> [Node Symbol]
recursivePathNodes salt = [infiniteFNode salt, infiniteFNode salt]

infiniteFNode :: Int -> Node Symbol
infiniteFNode salt = createMu $ \r -> Node [Edge (named "f" salt) [r]]

recursiveTypeA :: Int -> Node Symbol
recursiveTypeA salt =
    createMu $ \r ->
        Node
            [ Edge (named "baseType" salt) []
            , Edge "->" [theArrowNode, r, r]
            , Edge "Maybe" [r]
            , Edge "List" [r]
            ]

recursiveTypeB :: Int -> Node Symbol
recursiveTypeB salt =
    createMu $ \r ->
        Node
            [ Edge (named "baseType" salt) []
            , Edge "->" [theArrowNode, Node [Edge "List" [r]], r]
            , Edge "List" [r]
            ]
