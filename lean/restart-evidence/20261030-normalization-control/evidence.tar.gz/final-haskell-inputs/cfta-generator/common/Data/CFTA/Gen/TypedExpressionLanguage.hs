{-# LANGUAGE ApplicativeDo #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE QualifiedDo #-}

{- | A small well-typed expression language, shared by the specs and the
sampling benchmark.

This is example code. It is exposed so the LTA benchmarks can compare against
it, and it is not a stable interface.

Expressions use unary, binary, and ternary applications over integer and
Boolean literals. Every layer is grouped by result type, so an application
matches each operation signature with child groups of the right types instead
of generating values and rejecting ill-typed combinations. Naive rejection
and a handwritten type-directed generator provide like-for-like baselines.
-}
module Data.CFTA.Gen.TypedExpressionLanguage (
    -- * Language
    Type (..),
    Function (..),
    BinaryFunctionInstance (..),
    Expression (..),
    TypedExpression (..),
    UnarySignature,
    BinarySignature,
    ConditionalSignature,
    allTypes,
    binaryFunctionInstances,
    literals,
    unarySignature,
    binarySignature,
    conditionalSignature,
    compileNot,
    compileBinary,
    compileConditional,

    -- * Generators
    unaryFunctionsBySignature,
    binaryFunctionsBySignature,
    conditionalFunctionsBySignature,
    literalsByType,
    unaryLayer,
    binaryLayer,
    conditionalLayer,
    applicationLayer,
    depthByType,
    expressionGenAtDepth,
    upToDepthByType,
    recursiveExpressions,

    -- * Exact counts
    expressionCount,
    expressionCountUpTo,
    upToDepthCount,

    -- * Reference generators
    naiveExpressionGen,
    handwrittenExpressionOfType,
    handwrittenExpressionGen,
    frequencyInteger,

    -- * Benchmark checksums
    typedExpressionScore,
    expressionScore,
) where

import qualified Data.Text as Text
import qualified Test.QuickCheck as QC

import Data.CFTA.Gen.Equality.QuickCheck (ECTAGen, Grouped, Sig ((:*), (:->)))
import qualified Data.CFTA.Gen.Equality.QuickCheck as ECTAGen

-- | Ground types in the expression language.
data Type = TInt | TBool
    deriving (Bounded, Enum, Eq, Ord, Show)

-- | Polymorphic and monomorphic binary functions available to expressions.
data Function
    = Equal
    | Add
    | Multiply
    | Or
    | And
    deriving (Bounded, Enum, Eq, Ord, Show)

-- | One ground instantiation of a binary function.
data BinaryFunctionInstance = BinaryFunctionInstance
    { binaryFunction :: !Function
    , firstArgumentType :: !Type
    , secondArgumentType :: !Type
    , binaryResultType :: !Type
    }
    deriving (Eq, Ord, Show)

-- | Untyped expression syntax.
data Expression
    = IntLiteral !Int
    | BoolLiteral !Bool
    | Not !Expression
    | ApplyBinary !Function !Expression !Expression
    | IfExpression !Expression !Expression !Expression
    deriving (Eq, Ord, Show)

-- | An expression paired with its inferred ground type.
data TypedExpression = TypedExpression
    { expressionType :: !Type
    , expression :: !Expression
    }
    deriving (Eq, Ord, Show)

-- | The dependency information needed to apply 'Not'.
type UnarySignature = ECTAGen.Sig '[Type] Type

{- | The dependency information needed to apply one binary function.

The first two types select child result-type groups whose paths are equated; the
third is retained as the completed application's result-type key.
-}
type BinarySignature = ECTAGen.Sig '[Type, Type] Type

-- | The dependency information needed to build an 'IfExpression'.
type ConditionalSignature = ECTAGen.Sig '[Type, Type, Type] Type

-- | All ground types.
allTypes :: [Type]
allTypes = [minBound .. maxBound]

-- | Every valid ground instantiation of the available functions.
binaryFunctionInstances :: [BinaryFunctionInstance]
binaryFunctionInstances =
    [ BinaryFunctionInstance Equal argument argument TBool
    | argument <- allTypes
    ]
        <> [ BinaryFunctionInstance function_ TInt TInt TInt
           | function_ <- [Add, Multiply]
           ]
        <> [ BinaryFunctionInstance function_ TBool TBool TBool
           | function_ <- [Or, And]
           ]

-- | Two literals of each ground type.
literals :: [TypedExpression]
literals =
    [ TypedExpression TInt (IntLiteral 0)
    , TypedExpression TInt (IntLiteral 1)
    , TypedExpression TBool (BoolLiteral False)
    , TypedExpression TBool (BoolLiteral True)
    ]

-- | The complete ground signature of 'Not'.
unarySignature :: UnarySignature
unarySignature = TBool :-> TBool

-- | Extract the complete ground signature of a function instance.
binarySignature :: BinaryFunctionInstance -> BinarySignature
binarySignature instance_ =
    firstArgumentType instance_
        :* secondArgumentType instance_
        :-> binaryResultType instance_

-- | The ground signature of one conditional result type.
conditionalSignature :: Type -> ConditionalSignature
conditionalSignature result =
    TBool :* result :* result :-> result

-- | Build one well-typed unary expression.
compileNot :: TypedExpression -> TypedExpression
compileNot value =
    TypedExpression TBool $ Not $ expression value

-- | Build one well-typed ternary conditional expression.
compileConditional ::
    Type -> TypedExpression -> TypedExpression -> TypedExpression -> TypedExpression
compileConditional result condition ifTrue ifFalse =
    TypedExpression result $
        IfExpression
            (expression condition)
            (expression ifTrue)
            (expression ifFalse)

-- | The unary operation grouped by its ground signature.
unaryFunctionsBySignature ::
    Grouped UnarySignature (TypedExpression -> TypedExpression)
unaryFunctionsBySignature =
    ECTAGen.nameGroups (Text.pack . show) $
        compileNot
            <$ ECTAGen.keyed unarySignature (ECTAGen.namedElements [("Not :: Bool -> Bool", ())])

{- | Function instances grouped by their complete ground signature.

The signature is the key of a group, not part of the value. 'ECTAGen.groupOn'
puts each function in the group of its signature. A join reads the keys to find
the groups whose paths it equates. So the result is a map from each signature
to the language of the functions with that signature.
-}
binaryFunctionsBySignature :: Grouped BinarySignature BinaryFunctionInstance
binaryFunctionsBySignature =
    ECTAGen.nameGroups (Text.pack . show)
        $ ECTAGen.groupOn binarySignature
        $ ECTAGen.namedElements
            [ ( Text.pack (show $ binaryFunction instance_)
                    <> " :: "
                    <> typeName (firstArgumentType instance_)
                    <> " -> "
                    <> typeName (secondArgumentType instance_)
                    <> " -> "
                    <> typeName (binaryResultType instance_)
              , instance_
              )
            | instance_ <- binaryFunctionInstances
            ]

-- | One conditional builder per possible branch and result type.
conditionalFunctionsBySignature ::
    Grouped
        ConditionalSignature
        (TypedExpression -> TypedExpression -> TypedExpression -> TypedExpression)
conditionalFunctionsBySignature =
    ECTAGen.nameGroups (Text.pack . show) $
        compileConditional
            <$> ECTAGen.groupOn
                conditionalSignature
                ( ECTAGen.namedElements
                    [ ("If :: Bool -> " <> Text.intercalate " -> " (replicate 3 $ typeName result), result)
                    | result <- allTypes
                    ]
                )

{- | Literals grouped by their ground type.

Each projected @Type@ classifies literals into a group. Those keys let later
applications match compatible children and equate their ECTA paths without
enumerating or inspecting every expression.
-}
literalsByType :: Grouped Type TypedExpression
literalsByType =
    ECTAGen.nameGroups typeName
        $ ECTAGen.groupOn expressionType
        $ ECTAGen.namedElements
            [ (Text.pack (show $ expression literal) <> " :: " <> typeName (expressionType literal), literal)
            | literal <- literals
            ]

-- | Use domain type names in diagnostic groups and source signatures.
typeName :: Type -> Text.Text
typeName TInt = "Int"
typeName TBool = "Bool"

-- | Add one unary application layer.
unaryLayer :: Grouped Type TypedExpression -> Grouped Type TypedExpression
unaryLayer children = ECTAGen.node "not" $ ECTAGen.do
    build <- unaryFunctionsBySignature
    value <- children
    ECTAGen.pure (build value)

-- | Add one binary application layer.
binaryLayer :: Grouped Type TypedExpression -> Grouped Type TypedExpression
binaryLayer children = ECTAGen.node "binary-application" $ ECTAGen.do
    operation <- binaryFunctionsBySignature
    left <- children
    right <- children
    ECTAGen.pure (compileBinary operation left right)

-- | Add one ternary conditional layer.
conditionalLayer :: Grouped Type TypedExpression -> Grouped Type TypedExpression
conditionalLayer children = ECTAGen.node "if" $ ECTAGen.do
    build <- conditionalFunctionsBySignature
    condition <- children
    ifTrue <- children
    ifFalse <- children
    ECTAGen.pure (build condition ifTrue ifFalse)

{- | Add one application layer and retain its result type for the next layer.

Each of the three qualified do-blocks builds one 'ECTAGen.apply' join. The
signatures have one, two, or three argument keys. Each join matches these keys
with the child groups of the same result type and keeps the result key of the
operation. 'ECTAGen.uniformlyGrouped' weights each finite branch by its
cardinality, so all expressions of one exact depth are equally likely. In a
recursive family, the alternatives have equal weights.

The next layer reads the result key, so the layers compose.
-}
applicationLayer :: Grouped Type TypedExpression -> Grouped Type TypedExpression
applicationLayer children =
    ECTAGen.nameGroups typeName $
        ECTAGen.uniformlyGrouped
            [ unaryLayer children
            , binaryLayer children
            , conditionalLayer children
            ]

{- | Exact-depth expressions grouped by result type.

Each layer keeps its groups by result type, which an ordinary 'ECTAGen' does
not have. So the next application layer can use the layer as its typed
children, and the join equates the paths of the groups whose result types
match.
-}
depthByType :: Int -> Grouped Type TypedExpression
depthByType 0 = literalsByType
depthByType depth
    | depth > 0 = applicationLayer $ depthByType $ depth - 1
    | otherwise = error $ "negative expression depth: " <> show depth

{- | Return an ordinary ECTA generator after composing the requested depth.

'ECTAGen.ungroup' makes an ordinary generator from the grouped language. It
removes the keys and merges the groups with their exact masses. The values are
'TypedExpression' values.
-}
expressionGenAtDepth :: Int -> ECTAGen TypedExpression
expressionGenAtDepth = ECTAGen.ungroup . depthByType

{- | Expressions of depth at most the bound, grouped by result type.

'ECTAGen.uniformlyGrouped' merges the literal layer and the application
layer group by group, weighting each by its exact cardinality, so every
expression of every admitted depth is equally likely and no count is
computed by hand.
-}
upToDepthByType :: Int -> Grouped Type TypedExpression
upToDepthByType 0 = literalsByType
upToDepthByType depth =
    ECTAGen.uniformlyGrouped [literalsByType, applicationLayer $ upToDepthByType $ depth - 1]

{- | Every well-typed expression, as one recursive family.

The same application forms as 'upToDepthByType', but referring to themselves
instead of to a hand-unrolled tower: no depth bound, no hand-computed weights,
and members counted by size rather than by depth. Both result types share one
recursive automaton whose cycle carries the application layers' equality
constraints.
-}
recursiveExpressions :: Grouped Type TypedExpression
recursiveExpressions = ECTAGen.recurGrouped $ \self ->
    ECTAGen.oneofGrouped [literalsByType, applicationLayer self]

-- | Erase the ground instantiation after constructing a typed expression.
compileBinary ::
    BinaryFunctionInstance -> TypedExpression -> TypedExpression -> TypedExpression
compileBinary instance_ first second =
    TypedExpression
        (binaryResultType instance_)
        (ApplyBinary (binaryFunction instance_) (expression first) (expression second))

-- | Number of exact-depth expressions with the requested result type.
expressionCount :: Int -> Type -> Integer
expressionCount 0 result =
    toInteger $ length $ filter ((== result) . expressionType) literals
expressionCount depth result =
    applicationCount (expressionCount childDepth) result
  where
    childDepth = depth - 1

-- | Number of expressions of depth at most the bound with the result type.
expressionCountUpTo :: Int -> Type -> Integer
expressionCountUpTo 0 result = expressionCount 0 result
expressionCountUpTo depth result =
    expressionCount 0 result
        + applicationCount (expressionCountUpTo childDepth) result
  where
    childDepth = depth - 1

-- | Count every unary, binary, and conditional application for one result.
applicationCount :: (Type -> Integer) -> Type -> Integer
applicationCount childCount result =
    notCount + binaryCount + conditionalCount
  where
    notCount
        | result == TBool = childCount TBool
        | otherwise = 0
    binaryCount =
        sum
            [ childCount (firstArgumentType instance_)
                * childCount (secondArgumentType instance_)
            | instance_ <- binaryFunctionInstances
            , binaryResultType instance_ == result
            ]
    conditionalCount =
        childCount TBool * childCount result * childCount result

-- | Number of expressions of depth at most the bound across all result types.
upToDepthCount :: Int -> Integer
upToDepthCount depth = sum $ map (expressionCountUpTo depth) allTypes

{- | Generate raw applications and reject those that fail independent type
inference.

Accepted children are sampled uniformly at the preceding exact depth. The raw
root alternatives are weighted by their candidate counts, so rejection leaves
a uniform distribution over all accepted expressions rather than biasing
smaller constructor families.
-}
naiveExpressionGen :: Int -> QC.Gen TypedExpression
naiveExpressionGen depth
    | depth <= 0 = QC.elements literals
    | otherwise =
        QC.suchThatMap rawApplication inferTypedExpression
  where
    childDepth = depth - 1
    child = expression <$> naiveExpressionGen childDepth
    childCount = sum $ map (expressionCount childDepth) allTypes
    rawApplication =
        frequencyInteger
            [ (childCount, Not <$> child)
            ,
                ( 5 * childCount * childCount
                , ApplyBinary <$> QC.elements [minBound .. maxBound] <*> child <*> child
                )
            ,
                ( childCount * childCount * childCount
                , IfExpression <$> child <*> child <*> child
                )
            ]

-- | Independently infer and attach the type of one raw expression.
inferTypedExpression :: Expression -> Maybe TypedExpression
inferTypedExpression expression_ =
    TypedExpression <$> inferExpressionType expression_ <*> pure expression_

-- | Infer the ground type of one expression without using an ECTA group.
inferExpressionType :: Expression -> Maybe Type
inferExpressionType (IntLiteral _) = Just TInt
inferExpressionType (BoolLiteral _) = Just TBool
inferExpressionType (Not argument) = do
    argumentType <- inferExpressionType argument
    if argumentType == TBool then Just TBool else Nothing
inferExpressionType (ApplyBinary function_ first second) = do
    firstType <- inferExpressionType first
    secondType <- inferExpressionType second
    case function_ of
        Equal
            | firstType == secondType -> Just TBool
            | otherwise -> Nothing
        Add -> homogeneous TInt firstType secondType
        Multiply -> homogeneous TInt firstType secondType
        Or -> homogeneous TBool firstType secondType
        And -> homogeneous TBool firstType secondType
  where
    homogeneous expected firstType secondType
        | firstType == expected && secondType == expected = Just expected
        | otherwise = Nothing
inferExpressionType (IfExpression condition ifTrue ifFalse) = do
    conditionType <- inferExpressionType condition
    trueType <- inferExpressionType ifTrue
    falseType <- inferExpressionType ifFalse
    if conditionType == TBool && trueType == falseType
        then Just trueType
        else Nothing

{- | The handwritten generator makes the dependency explicit by accepting the
desired result type and selecting only compatible function instances. Its
weights make every expression of a given exact depth equally likely.
-}
handwrittenExpressionOfType :: Int -> Type -> QC.Gen TypedExpression
handwrittenExpressionOfType 0 result =
    QC.elements $ filter ((== result) . expressionType) literals
handwrittenExpressionOfType depth result =
    frequencyInteger $ notAlternatives <> binaryAlternatives <> conditionalAlternatives
  where
    childDepth = depth - 1
    count = expressionCount childDepth
    notAlternatives =
        [ ( count TBool
          , compileNot <$> handwrittenExpressionOfType childDepth TBool
          )
        | result == TBool
        ]
    binaryAlternatives =
        [ ( count (firstArgumentType instance_)
                * count (secondArgumentType instance_)
          , do
                first <-
                    handwrittenExpressionOfType
                        childDepth
                        (firstArgumentType instance_)
                second <-
                    handwrittenExpressionOfType
                        childDepth
                        (secondArgumentType instance_)
                pure $ compileBinary instance_ first second
          )
        | instance_ <- binaryFunctionInstances
        , binaryResultType instance_ == result
        ]
    conditionalAlternatives =
        [
            ( count TBool * count result * count result
            , do
                condition <- handwrittenExpressionOfType childDepth TBool
                ifTrue <- handwrittenExpressionOfType childDepth result
                ifFalse <- handwrittenExpressionOfType childDepth result
                pure $ compileConditional result condition ifTrue ifFalse
            )
        ]

-- | Generate uniformly from all well-typed expressions at one exact depth.
handwrittenExpressionGen :: Int -> QC.Gen TypedExpression
handwrittenExpressionGen depth =
    frequencyInteger
        [ (expressionCount depth result, handwrittenExpressionOfType depth result)
        | result <- allTypes
        ]

-- | Preserve exact relative weights, using an Integer draw when needed.
frequencyInteger :: [(Integer, QC.Gen a)] -> QC.Gen a
frequencyInteger [] = error "frequencyInteger: empty alternatives"
frequencyInteger alternatives
    | totalWeight <= toInteger (maxBound :: Int) =
        QC.frequency
            [ (fromInteger weight, generator)
            | (weight, generator) <- reduced
            ]
    | otherwise = do
        selected <- QC.chooseInteger (1, totalWeight)
        pick selected reduced
  where
    commonFactor = foldl' gcd 0 $ map fst alternatives
    reduced = [(weight `div` commonFactor, generator) | (weight, generator) <- alternatives]
    totalWeight = sum $ map fst reduced

    pick _ [] = error "frequencyInteger: selected past the alternatives"
    pick selected ((weight, generator) : remaining)
        | selected <= weight = generator
        | otherwise = pick (selected - weight) remaining

-- | Force and score every field of one typed expression.
typedExpressionScore :: TypedExpression -> Int
typedExpressionScore (TypedExpression type_ expression_) =
    fromEnum type_ + expressionScore expression_

-- | Force the complete expression tree and return a stable checksum component.
expressionScore :: Expression -> Int
expressionScore (IntLiteral value) = 2 * value + 1
expressionScore (BoolLiteral value) = if value then 4 else 3
expressionScore (Not argument) = 5 + expressionScore argument
expressionScore (ApplyBinary function_ first second) =
    7 + fromEnum function_ + expressionScore first + expressionScore second
expressionScore (IfExpression condition ifTrue ifFalse) =
    13 + expressionScore condition + expressionScore ifTrue + expressionScore ifFalse
