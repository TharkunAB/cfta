-- | Helpers shared by the refinement specs.
module Data.CFTA.Gen.Refinement.TestSupport (
    compileOrFail,
    rightOrFail,
    ranks,
    values,
    termsOf,
    termOf,
    massesByRank,
) where

import Test.Hspec (expectationFailure)

import qualified Data.CFTA.Gen.Refinement as LTAGen
import Data.CFTA.Index (Rank, everyRank)
import Data.CFTA.Ranked.Internal.Sampler (Exact (..))
import Data.CFTA.Refinement (Entailment, Symbol)
import Data.CFTA.Term (Term)

-- | Compile a fixture, reporting a compilation error as an Hspec failure.
compileOrFail :: Entailment -> LTAGen.LTAGen a -> IO (LTAGen.LTAGen a)
compileOrFail solver generator = LTAGen.compileWith solver generator >>= rightOrFail

-- | Report a construction or compilation error as an Hspec failure.
rightOrFail :: (Show err) => Either err a -> IO a
rightOrFail result =
    case result of
        Left err -> expectationFailure (show err) >> fail "unreachable"
        Right compiled -> pure compiled

-- | Every rank of a finite generator; none when it failed.
ranks :: LTAGen.LTAGen a -> [Rank]
ranks generator = either (const []) everyRank $ LTAGen.cardinality generator

-- | Enumerate one small compiled language in stable rank order.
values :: LTAGen.LTAGen a -> [a]
values generator = [value | rank <- ranks generator, Right value <- [LTAGen.unrank generator rank]]

-- | The accepted liquid term of every rank, in rank order.
termsOf :: LTAGen.LTAGen a -> [Term Symbol]
termsOf generator = [term | rank <- ranks generator, Right term <- [termOf generator rank]]

-- | The accepted liquid term of one rank: the user's part of the engine's term.
termOf :: LTAGen.LTAGen a -> Rank -> Either LTAGen.GenError (Term Symbol)
termOf generator rank = do
    labelled <- LTAGen.termAt generator rank
    case LTAGen.surface labelled of
        [term] -> Right term
        _ -> Left LTAGen.CannotInspectOpaqueGenerator

-- | The exact sampling mass of every rank.
massesByRank :: LTAGen.LTAGen a -> [(Rank, Rational)]
massesByRank generator =
    [(rank, mass) | (mass, Right (LTAGen.RankedValue rank _)) <- runExact $ LTAGen.lowerWithRankVia generator]
