{-# LANGUAGE ApplicativeDo #-}
{-# LANGUAGE QualifiedDo #-}

module Data.CFTA.Gen.Equality.GenSpec (spec) where

import Control.Monad ((>=>))
import qualified Data.Bifunctor as Bifunctor
import Data.IORef (modifyIORef', newIORef, readIORef)
import Data.List (sort)
import qualified Data.Map.Strict as Map
import Data.Ratio ((%))
import qualified Data.Sequence as Sequence
import Data.String (fromString)
import Data.Text (Text)
import Data.Tree (flatten)
import Test.Hspec (Spec, describe, expectationFailure, it, shouldBe, shouldNotBe, shouldReturn, shouldSatisfy)
import Test.Hspec.QuickCheck (modifyMaxSuccess)
import qualified Test.QuickCheck as QC
import qualified Test.QuickCheck.Gen as QCGen
import qualified Test.QuickCheck.Random as QCRandom

import Data.CFTA.Constraint (Constraint, equalityConstraint)
import Data.CFTA.Equality (Node (Node), accepts, edgeChildren, edgeConstraint, edgeSymbol, termsWith)
import qualified Data.CFTA.Equality as ECTA
import Data.CFTA.Equality.Constraint (mkEqConstraints)
import Data.CFTA.Gen.Equality.QuickCheck (Args (..), ECTAGen, On (..), Sig ((:*), (:->)))
import qualified Data.CFTA.Gen.Equality.QuickCheck as ECTAGen
import Data.CFTA.Gen.TestSupport (ranksBack, ranksEveryMemberBack, renameSymbols)
import Data.CFTA.Index (Cardinality (..), Rank (..), everyRank)
import qualified Data.CFTA.Path as Path
import Data.CFTA.Ranked.Internal.Sampler (Exact (..))
import Data.CFTA.Symbol (Symbol)
import Data.CFTA.Term (Term)
import qualified Data.CFTA.Term as Term

data UserId = Alice | Bob | Carol | Dave
    deriving (Bounded, Enum, Eq, Ord, Show)

data AuthenticationMethod = Password | Token
    deriving (Bounded, Enum, Eq, Ord, Show)

data AuthenticationFixture = AuthenticationFixture
    { authenticatedUser :: UserId
    , authenticationMethod :: AuthenticationMethod
    }
    deriving (Eq, Ord, Show)

data Path = HomeFile | ConfigFile | CacheFile
    deriving (Bounded, Enum, Eq, Ord, Show)

data FilesystemFixture = FilesystemFixture
    { fileOwner :: UserId
    , filePath :: Path
    }
    deriving (Eq, Ord, Show)

-- | Access roles used by the independent relation reference language.
data Role = Admin | Member
    deriving (Eq, Ord, Show)

-- | Resource classes used by the independent relation reference language.
data Classification = Public | Secret
    deriving (Eq, Ord, Show)

-- | Keys used to test a caller-declared group independently of its values.
data UserFamily = DeclaredUsers | OtherUsers
    deriving (Eq, Ord, Show)

-- | The permission relation exercised by 'relatedAccess'.
canRead :: Role -> Classification -> Bool
canRead Admin _ = True
canRead Member Public = True
canRead Member Secret = False

-- | All users shared by the independently authored fixture generators.
allUsers :: [UserId]
allUsers = [minBound .. maxBound]

-- | Transparent ECTA user generator.
generatedUserId :: ECTAGen UserId
generatedUserId = ECTAGen.elements allUsers

-- These are ordinary, closed generators. Neither accepts shared input.
authenticationFixture :: ECTAGen AuthenticationFixture
authenticationFixture = ECTAGen.node (fromString "authentication") $ ECTAGen.do
    user <- generatedUserId
    method <- ECTAGen.elements [Password, Token]
    ECTAGen.pure $ AuthenticationFixture user method

filesystemFixture :: ECTAGen FilesystemFixture
filesystemFixture = ECTAGen.node (fromString "filesystem") $ ECTAGen.do
    owner <- generatedUserId
    path <- ECTAGen.elements [HomeFile, ConfigFile, CacheFile]
    ECTAGen.pure $ FilesystemFixture owner path

-- ECTA composes the closed fixtures by matching their existing user fields.
matchedFixture :: ECTAGen (AuthenticationFixture, FilesystemFixture)
matchedFixture =
    ECTAGen.match
        (authenticatedUser :==: fileOwner)
        authenticationFixture
        filesystemFixture

-- | The constraint of a join support: the keys of the two sides are equal.
keysEqual :: Constraint
keysEqual = equalityConstraint $ mkEqConstraints [[Path.path [0, 0], Path.path [1, 0]]]

-- | Access pairs generated through the relation under test.
relatedAccess :: ECTAGen ((Role, String), (Classification, String))
relatedAccess =
    ECTAGen.relate
        fst
        fst
        canRead
        (ECTAGen.elements [(Admin, "Ada"), (Admin, "Alex"), (Member, "Morgan")])
        (ECTAGen.elements [(Public, "guide"), (Secret, "keys")])

-- | Independently listed accepted pairs and their conditioned mass.
expectedAccessPmf :: [(((Role, String), (Classification, String)), Rational)]
expectedAccessPmf =
    [ (((Admin, "Ada"), (Public, "guide")), 1 % 5)
    , (((Admin, "Ada"), (Secret, "keys")), 1 % 5)
    , (((Admin, "Alex"), (Public, "guide")), 1 % 5)
    , (((Admin, "Alex"), (Secret, "keys")), 1 % 5)
    , (((Member, "Morgan"), (Public, "guide")), 1 % 5)
    ]

rawFixture :: ECTAGen (AuthenticationFixture, FilesystemFixture)
rawFixture = (,) <$> authenticationFixture <*> filesystemFixture

matchingUsers :: (AuthenticationFixture, FilesystemFixture) -> Bool
matchingUsers (authentication, filesystem) =
    authenticatedUser authentication == fileOwner filesystem

expectedPmf :: [((AuthenticationFixture, FilesystemFixture), Rational)]
expectedPmf =
    [ ( (AuthenticationFixture user method, FilesystemFixture user path)
      , 1 % 24
      )
    | user <- allUsers
    , method <- [minBound .. maxBound]
    , path <- [minBound .. maxBound]
    ]

-- | A constructor without children.
leaf :: String -> ECTA.Edge Symbol
leaf name = ECTA.Edge (fromString name) []

-- | A constructor over the given children, with the given equality classes.
constructor :: String -> [Node Symbol] -> [[[Path.ChildIndex]]] -> ECTA.Edge Symbol
constructor name children classes = ECTA.mkEdge (fromString name) children $ equalityConstraint $ mkEqConstraints $ map (map Path.path) classes

-- | The two leaves a and b.
twoLeaves :: Node Symbol
twoLeaves = Node [leaf "a", leaf "b"]

-- | Equal direct children: the compact plan ranks the pair by one child.
equalChildren :: Node Symbol
equalChildren = Node [leaf "a", constructor "pair" [children, children] [[[0], [1]]]]
  where
    children = Node [leaf "a", leaf "b", constructor "f" [twoLeaves] []]

-- | Two alternatives that share the symbol f and the term f(a).
overlapping :: Node Symbol
overlapping = Node [leaf "a", constructor "f" [twoLeaves] [], constructor "f" [Node [leaf "a", leaf "c"]] []]

{- | An equality below the direct children. The position of u holds one term
only, so the symbolic ranks skip it.
-}
nestedEquality :: Node Symbol
nestedEquality = Node [constructor "pair" [boxes, boxes] [[[0, 0], [1, 0]]]]
  where
    boxes = Node [leaf "c", constructor "box" [twoLeaves, Node [leaf "u"]] [], constructor "wrap" [twoLeaves] []]

-- | A compact node over two symbolic children.
mixedPlans :: Node Symbol
mixedPlans = Node [leaf "z", constructor "g" [overlapping, nestedEquality] []]

{- | A random acyclic automaton of the given depth. Few symbols for each
arity make alternatives overlap. A binary edge has no equality, a direct
equality, or an equality below its children.
-}
randomAutomaton :: Int -> QC.Gen (Node Symbol)
randomAutomaton 0 = Node . map leaf <$> QC.sublistOf ["a", "b", "c"] `QC.suchThat` (not . null)
randomAutomaton depth = do
    edges <- QC.chooseInt (2, 3)
    Node <$> QC.vectorOf edges randomEdge
  where
    randomEdge = do
        arity <- QC.frequency [(1, pure 0), (2, pure 1), (3, pure 2)]
        name <- QC.elements $ case arity of
            0 -> ["a", "b", "c"]
            1 -> ["f", "g"]
            _ -> ["p", "q"]
        children <- QC.vectorOf arity $ randomAutomaton $ depth - 1
        classes <- if arity == 2 then QC.elements [[], [], [[[0], [1]]], [[[0, 0], [1, 0]]], [[[0, 0], [1]]]] else pure []
        pure $ constructor name children classes

{- | Require that a finite import ranks exactly the terms that the automaton
accepts, each to the rank that decodes to it.
-}
ranksExactlyAccepted :: Node Symbol -> [Term Symbol] -> IO ()
ranksExactlyAccepted root candidates =
    map (ECTAGen.rankOfTerm generator >=> ECTAGen.unrank generator) candidates
        `shouldBe` [if accepts root term then Right term else Left ECTAGen.TermNotInLanguage | term <- candidates]
  where
    generator = ECTAGen.fromAutomaton root

-- | Read source and key names through the public typed graph view.
inspectionLabels :: ECTAGen value -> Either String [Text]
inspectionLabels generator = do
    inspection <- Bifunctor.first show $ ECTAGen.inspect generator
    tree <- Bifunctor.first show $ ECTA.toTree $ ECTAGen.inspectionGraph inspection
    pure
        [ label
        | Right edge <- flatten tree
        , Just label <- [ECTAGen.displayLabel $ edgeSymbol edge]
        ]

spec :: Spec
spec = do
    describe "ECTAGen joins" $ do
        it "closes qualified do with one visible n-ary node" $
            case ECTAGen.support authenticationFixture of
                Right (Node [edge]) ->
                    (edgeSymbol edge, length $ edgeChildren edge)
                        `shouldBe` (ECTAGen.Label $ fromString "authentication", 2)
                result -> expectationFailure $ "unexpected node support: " <> show result

        it "keeps relabelled recursive witnesses inside their support" $ do
            let recursive = ECTAGen.recur $ \self ->
                    ECTAGen.oneof [pure (0 :: Int), ECTAGen.pay $ pure (+ 1) <*> self]
            case ECTAGen.support recursive of
                Left err -> expectationFailure $ show err
                Right original -> do
                    let label = ECTAGen.node $ fromString "closed"
                        -- Read the support back as an automaton over plain
                        -- symbols, private labels included.
                        surface (ECTAGen.Label symbol) = symbol
                        surface private = fromString $ show private
                        fromAutomaton = ECTAGen.fromAutomaton $ renameSymbols surface original
                        check labelled =
                            case ( ECTAGen.support labelled
                                 , ECTAGen.support $ ECTAGen.ungroup $ ECTAGen.groupOn (const ()) labelled
                                 ) of
                                (Right support, Right regrouped) -> do
                                    let witnesses = termsWith (ECTAGen.Label $ fromString "Mu") regrouped
                                    ECTAGen.cardinality labelled `shouldBe` Right 2
                                    length witnesses `shouldBe` 2
                                    witnesses `shouldSatisfy` all (accepts support)
                                (Left err, _) -> expectationFailure $ show err
                                (_, Left err) -> expectationFailure $ show err
                    inspectionLabels fromAutomaton `shouldBe` Right []
                    -- The import counts private recursion roots as ordinary nodes.
                    check $ ECTAGen.upToSize 8 $ label fromAutomaton
                    check $ label $ ECTAGen.upToSize 8 fromAutomaton
                    ranksBack ECTAGen.rankOfTerm fromAutomaton [0 .. 5]

        it "retains matching keys in key and source order with the conditioned product PMF" $ do
            ECTAGen.pmf matchedFixture `shouldBe` Right expectedPmf
            let ranks = everyRank $ toEnum $ length expectedPmf
            traverse (ECTAGen.unrank matchedFixture) ranks
                `shouldBe` Right (map fst expectedPmf)

        it "relates different key types against the declared predicate" $ do
            ECTAGen.cardinality relatedAccess `shouldBe` Right 5
            ECTAGen.pmf relatedAccess `shouldBe` Right expectedAccessPmf

        it "evaluates an effectful relation once per live key pair" $ do
            calls <- newIORef (0 :: Int)
            related <-
                ECTAGen.relateM
                    even
                    even
                    ( \leftKey rightKey -> do
                        modifyIORef' calls (+ 1)
                        pure (Right (leftKey == rightKey) :: Either () Bool)
                    )
                    (ECTAGen.elements [0 .. 3] :: ECTAGen Int)
                    (ECTAGen.elements [10 .. 13 :: Int])
            readIORef calls `shouldReturn` 4
            fmap ECTAGen.cardinality related `shouldBe` Right (Right 8)

        it "evaluates an n-ary relation once per live key tuple" $ do
            calls <- newIORef (0 :: Int)
            related <-
                ECTAGen.relateN
                    ( \keys -> do
                        modifyIORef' calls (+ 1)
                        pure (Right (and $ Sequence.zipWith (==) keys $ Sequence.drop 1 keys) :: Either () Bool)
                    )
                    [ ECTAGen.groupOn even (ECTAGen.elements [0 .. 3] :: ECTAGen Int)
                    , ECTAGen.groupOn even $ ECTAGen.elements [10 .. 13 :: Int]
                    , ECTAGen.groupOn even $ ECTAGen.elements [20 .. 23 :: Int]
                    ]
            readIORef calls `shouldReturn` 8
            fmap (ECTAGen.cardinality . ECTAGen.ungroup) related
                `shouldBe` Right (Right 16)

        it "preserves and conditions source weights across related groups" $
            ECTAGen.pmf
                ( ECTAGen.relate
                    id
                    id
                    canRead
                    (ECTAGen.frequency [(3, ECTAGen.elements [Admin]), (1, ECTAGen.elements [Member])] :: ECTAGen Role)
                    (ECTAGen.elements [Public, Secret])
                )
                `shouldBe` Right
                    [ ((Admin, Public), 3 % 7)
                    , ((Admin, Secret), 3 % 7)
                    , ((Member, Public), 1 % 7)
                    ]

        it "counts the pairs that rejection of the plain product discards" $ do
            fmap length (ECTAGen.pmf authenticationFixture) `shouldBe` Right 8
            fmap length (ECTAGen.pmf filesystemFixture) `shouldBe` Right 12
            case ECTAGen.pmf rawFixture of
                Left err -> expectationFailure $ show err
                Right rawPmf -> do
                    length rawPmf `shouldBe` 96
                    length (filter (not . matchingUsers . fst) rawPmf) `shouldBe` 72
                    sum
                        [ probability
                        | (pair, probability) <- rawPmf
                        , not $ matchingUsers pair
                        ]
                        `shouldBe` 3 % 4

        it "represents the join with an ECTA equality constraint" $
            case ECTAGen.support matchedFixture of
                Right (Node [edge]) -> edgeConstraint edge `shouldBe` keysEqual
                result -> expectationFailure $ "unexpected join support: " <> show result

        it "reports an empty join" $
            ECTAGen.pmf
                ( ECTAGen.match
                    (id :==: id)
                    (ECTAGen.elements [Alice] :: ECTAGen UserId)
                    (ECTAGen.elements [Bob])
                )
                `shouldBe` Left ECTAGen.EmptyGenerator

        it "reports a relation with no accepted live keys" $
            ECTAGen.pmf
                ( ECTAGen.relate
                    id
                    id
                    (\_ _ -> False)
                    (ECTAGen.elements [Admin] :: ECTAGen Role)
                    (ECTAGen.elements [Public])
                )
                `shouldBe` Left ECTAGen.EmptyGenerator

        it "represents a relation with an ECTA equality witness" $
            case ECTAGen.support relatedAccess of
                Right (Node [edge]) -> edgeConstraint edge `shouldBe` keysEqual
                result -> expectationFailure $ "unexpected relation support: " <> show result

        it "preserves frequency weights around already-conditioned generators" $
            let rare =
                    Password
                        <$ ECTAGen.match
                            (id :==: id)
                            generatedUserId
                            (ECTAGen.elements [Carol])
                common =
                    Token
                        <$ ECTAGen.match
                            (id :==: id)
                            generatedUserId
                            (ECTAGen.elements [Alice])
             in ECTAGen.pmf (ECTAGen.frequency [(1, rare), (1, common)])
                    `shouldBe` Right [(Password, 1 % 2), (Token, 1 % 2)]

        it "conjoins every declared key equality" $ do
            let left :: ECTAGen.ECTAGen _
                left = ECTAGen.elements [(0 :: Int, 0 :: Int, "left-00"), (0, 1, "left-01")]
                right :: ECTAGen.ECTAGen _
                right =
                    ECTAGen.elements
                        [ (0 :: Int, 0 :: Int, "right-00")
                        , (0, 1, "right-01")
                        , (1, 0, "right-10")
                        ]
                firstKey (first, _, _) = first
                secondKey (_, second, _) = second
            traverse
                (ECTAGen.unrank $ ECTAGen.match ((firstKey :==: firstKey) :&&: (secondKey :==: secondKey)) left right)
                [0, 1]
                `shouldBe` Right
                    [ ((0, 0, "left-00"), (0, 0, "right-00"))
                    , ((0, 1, "left-01"), (0, 1, "right-01"))
                    ]

        it "samples a non-uniform join with exactly its inspected PMF" $ do
            let left :: ECTAGen.ECTAGen UserId
                left =
                    ECTAGen.frequency
                        [ (4, ECTAGen.elements [Alice])
                        , (1, ECTAGen.elements [Bob, Carol])
                        ]
                right :: ECTAGen.ECTAGen UserId
                right =
                    ECTAGen.frequency
                        [ (1, ECTAGen.elements [Alice])
                        , (3, ECTAGen.elements [Bob, Carol])
                        ]
                generator = ECTAGen.match (id ECTAGen.:==: id) left right
                sampled = runExact $ ECTAGen.lowerVia generator
                sampledErrors = [err | (_, Left err) <- sampled]
                sampledPmf =
                    Map.toAscList $
                        Map.fromListWith
                            (+)
                            [(value, mass) | (mass, Right value) <- sampled]
            sampledErrors `shouldBe` []
            Right sampledPmf `shouldBe` ECTAGen.pmf generator

        it "matches a brute-force grouped apply with weighted multiplicities" $ do
            let centers :: [((Char, Int, Int, Int), String)]
                centers =
                    [ (('a', 0, 0, 0), "common")
                    , (('b', 0, 0, 0), "common")
                    , (('c', 1, 0, 1), "rare")
                    ]
                lefts :: [(Int, String)]
                lefts = [(0, "left-a"), (0, "left-b"), (1, "left-c")]
                rights :: [(Int, String)]
                rights = [(0, "right-a"), (0, "right-a"), (1, "right-b")]
                signature (_, leftKey, rightKey, resultKey) =
                    leftKey :* rightKey :-> resultKey
                operations =
                    ECTAGen.regroupOn signature
                        $ ECTAGen.groupOn fst
                        $ ECTAGen.namedElements [(fromString $ snd center, center) | center <- centers]
                grouped =
                    ECTAGen.ungroup $
                        ECTAGen.apply
                            ((,,) <$> operations)
                            ( ECTAGen.nameGroups
                                (fromString . show)
                                (ECTAGen.groupOn fst $ ECTAGen.namedElements [(fromString $ snd value, value) | value <- lefts])
                                :& ECTAGen.nameGroups
                                    (fromString . show)
                                    (ECTAGen.groupOn fst $ ECTAGen.namedElements [(fromString $ snd value, value) | value <- rights])
                                :& ANil
                            )
                accepted =
                    [ (center, left, right)
                    | center <- centers
                    , let (_, expectedLeft, expectedRight, _) = fst center
                    , left <- lefts
                    , expectedLeft == fst left
                    , right <- rights
                    , expectedRight == fst right
                    ]
                acceptedCount = toInteger $ length accepted
                expected =
                    Map.toAscList
                        $ fmap (% acceptedCount)
                        $ Map.fromListWith
                            (+)
                            [(value, 1) | value <- accepted]
            ECTAGen.cardinalities operations
                `shouldBe` Right (Map.fromList [(0 :* 0 :-> 0, 2), (1 :* 0 :-> 1, 1)])
            ECTAGen.pmf (ECTAGen.atKey (0 :* 0 :-> 0) operations)
                `shouldBe` Right (zip (take 2 centers) [1 % 2, 1 % 2])
            ECTAGen.pmf grouped `shouldBe` Right expected
            case inspectionLabels grouped of
                Left err -> expectationFailure err
                Right labels ->
                    labels `shouldSatisfy` \found ->
                        all
                            ((`elem` found) . fromString)
                            ["common", "rare", "left-a", "left-b", "left-c", "right-a", "0", "1"]

    describe "indexed and opaque sources" $ do
        it "decodes a transparent source from stable indices" $ do
            let users :: ECTAGen UserId
                users =
                    ECTAGen.fromIndexed $
                        ECTAGen.Indexed 3 $ \case
                            0 -> Alice
                            1 -> Bob
                            2 -> Carol
                            index -> error $ "unexpected index: " <> show index
            ECTAGen.pmf users `shouldBe` Right [(Alice, 1 % 3), (Bob, 1 % 3), (Carol, 1 % 3)]

        it "freezes native draws as transparent ranks, including duplicates" $ do
            let native = QC.chooseInteger (0, 3)
                seed = QCRandom.mkQCGen 20260818
                expected = QCGen.unGen (QC.vectorOf 8 native) seed 30
                pooled :: ECTAGen.ECTAGen _
                pooled = QCGen.unGen (ECTAGen.samplePool 8 native) seed 30
            ECTAGen.cardinality pooled `shouldBe` Right 8
            traverse (ECTAGen.unrank pooled) [0 .. 7] `shouldBe` Right expected
            ECTAGen.countOn id pooled
                `shouldBe` Right (Map.fromListWith (+) [(value, 1) | value <- expected])

        it "uses one frozen pool on both sides of a constrained join" $ do
            let native = QC.chooseInteger (0, 3)
                seed = QCRandom.mkQCGen 20260818
                values = QCGen.unGen (QC.vectorOf 8 native) seed 30
                pooled :: ECTAGen.ECTAGen _
                pooled = QCGen.unGen (ECTAGen.samplePool 8 native) seed 30
                equalPairs :: ECTAGen.ECTAGen _
                equalPairs = ECTAGen.match (id :==: id) pooled pooled
                accepted = [(left, right) | left <- values, right <- values, left == right]
                acceptedCount = toInteger $ length accepted
                pooledExpectedPmf =
                    Map.toAscList
                        $ fmap (% acceptedCount)
                        $ Map.fromListWith (+) [(pair, 1) | pair <- accepted]
            ECTAGen.cardinality equalPairs `shouldBe` Right (Cardinality acceptedCount)
            ECTAGen.pmf equalPairs `shouldBe` Right pooledExpectedPmf

        it "turns a non-positive pool size into an empty generator" $ do
            let freeze :: Int -> ECTAGen UserId
                freeze sampleCount =
                    QCGen.unGen
                        (ECTAGen.samplePool sampleCount (pure Alice))
                        (QCRandom.mkQCGen 20260818)
                        30
            ECTAGen.cardinality (freeze 0) `shouldBe` Left ECTAGen.EmptyGenerator
            ECTAGen.cardinality (freeze (-1)) `shouldBe` Left ECTAGen.EmptyGenerator

        it "reuses one indexed choice through fmap" $ do
            ECTAGen.pmf
                ( do
                    user <- ECTAGen.elements [Alice, Bob] :: ECTAGen UserId
                    pure (user, user)
                )
                `shouldBe` Right [((Alice, Alice), 1 % 2), ((Bob, Bob), 1 % 2)]
            let integers = ECTAGen.namedElements [(fromString "zero", 0), (fromString "one", 1)] :: ECTAGen Int
                booleans = ECTAGen.namedElements [(fromString "false", False), (fromString "true", True)]
                shifted = (+ 10) <$> integers
                paired = (,) <$> integers <*> booleans
                applied = ECTAGen.namedElements [(fromString "increment", (+ 1))] <*> integers
            ECTAGen.support shifted `shouldBe` ECTAGen.support integers
            traverse (ECTAGen.unrank shifted) [0, 1] `shouldBe` Right [10, 11]
            inspectionLabels shifted `shouldBe` inspectionLabels integers
            traverse (ECTAGen.unrank paired) [0 .. 3]
                `shouldBe` Right [(0, False), (0, True), (1, False), (1, True)]
            case ECTAGen.support paired of
                Right (Node [edge]) -> case edgeChildren edge of
                    [left, right] -> left `shouldBe` right
                    children -> expectationFailure $ "unexpected source children: " <> show children
                result -> expectationFailure $ "unexpected source support: " <> show result
            case ECTAGen.inspect paired of
                Right inspection -> case ECTAGen.inspectionGraph inspection of
                    Node [edge] -> case edgeChildren edge of
                        [left, right] -> left `shouldNotBe` right
                        children -> expectationFailure $ "unexpected inspection children: " <> show children
                    graph -> expectationFailure $ "unexpected inspection graph: " <> show graph
                Left err -> expectationFailure $ show err
            fmap sort (inspectionLabels paired)
                `shouldBe` Right (map fromString ["false", "one", "true", "zero"])
            traverse (ECTAGen.unrank applied) [0, 1] `shouldBe` Right [1, 2]
            fmap sort (inspectionLabels applied)
                `shouldBe` Right (map fromString ["increment", "one", "zero"])

        it "exposes exact cardinality and deterministic unranking" $ do
            let users = ECTAGen.elements [Alice, Bob, Carol]
            ECTAGen.cardinality users `shouldBe` Right 3
            traverse (ECTAGen.unrank users) [0, 1, 2]
                `shouldBe` Right [Alice, Bob, Carol]
            ECTAGen.unrank users 3
                `shouldBe` Left (ECTAGen.SelectionOutOfRange 3 3)
            let named = ECTAGen.namedElements [(fromString $ show user, user) | user <- [Alice, Bob, Carol]]
                lazyNames = ECTAGen.namedElements [(error "source name evaluated", user) | user <- [Alice, Bob, Carol]]
                lazyGroups = ECTAGen.nameGroups (\_ -> error "group name evaluated") $ ECTAGen.keyed DeclaredUsers lazyNames
                selected = ECTAGen.atKey DeclaredUsers lazyGroups
            ECTAGen.support named `shouldBe` ECTAGen.support users
            traverse (ECTAGen.unrank named) [0 .. 2] `shouldBe` Right [Alice, Bob, Carol]
            fmap sort (inspectionLabels named)
                `shouldBe` Right (map fromString ["Alice", "Bob", "Carol"])
            ECTAGen.support selected `shouldBe` ECTAGen.support users
            ECTAGen.cardinality selected `shouldBe` Right 3
            traverse (ECTAGen.unrank selected) [0 .. 2] `shouldBe` Right [Alice, Bob, Carol]

        it "finds a finite structural minimum beyond rank zero" $ do
            let larger :: ECTAGen.ECTAGen _
                larger = (,) <$> ECTAGen.elements [0 :: Int] <*> ECTAGen.elements [0 :: Int]
                smaller :: ECTAGen.ECTAGen _
                smaller = ECTAGen.elements [(1, 1)]
                generator :: ECTAGen.ECTAGen _
                generator = ECTAGen.oneof [larger, smaller]
            ECTAGen.unrank generator 0 `shouldBe` Right (0, 0)
            ECTAGen.sizeOfRank generator 0 `shouldBe` Just 2
            ECTAGen.sizeOfRank generator 1 `shouldBe` Just 1
            ECTAGen.smallest generator `shouldBe` Right (Just (1, 1))

        it "returns a sampled rank that deterministically replays its value" $
            QC.property $
                QC.forAll (ECTAGen.toGenWithRank matchedFixture) $ \(ECTAGen.RankedValue rank value) ->
                    ECTAGen.unrank matchedFixture rank QC.=== Right value

        modifyMaxSuccess (const 200)
            $ it "replays weighted samples even when sampling reorders branches"
            $ let weighted :: ECTAGen UserId
                  weighted =
                    ECTAGen.frequency
                        [ (1, pure Alice)
                        , (3, ECTAGen.elements [Bob, Carol])
                        ]
               in QC.forAll (ECTAGen.toGenWithRank weighted) $ \(ECTAGen.RankedValue rank value) ->
                    ECTAGen.unrank weighted rank QC.=== Right value

        it "returns construction errors through the explicit sampling API" $ do
            let sample generator =
                    QCGen.unGen
                        (ECTAGen.toGenEither generator)
                        (QCRandom.mkQCGen 20260821)
                        30
            sample (ECTAGen.frequency [] :: ECTAGen UserId)
                `shouldBe` Left ECTAGen.EmptyGenerator
            sample (ECTAGen.frequency [(0, pure Alice)] :: ECTAGen UserId)
                `shouldBe` Left (ECTAGen.NonPositiveWeight 0)
            sample (ECTAGen.frequency [(-1, pure Alice)] :: ECTAGen UserId)
                `shouldBe` Left (ECTAGen.NonPositiveWeight (-1))

        it "samples a directly indexed source whose cardinality exceeds Int" $ do
            let total = toInteger (maxBound :: Int) + 17
                source :: ECTAGen.ECTAGen _
                source = ECTAGen.fromIndexed $ ECTAGen.Indexed (Cardinality total) id
                ECTAGen.RankedValue rank value =
                    QCGen.unGen
                        (ECTAGen.toGenWithRank source)
                        (QCRandom.mkQCGen 20260821)
                        30
            value `shouldBe` rank
            rank `shouldSatisfy` (\(Rank selected) -> selected >= 0 && selected < total)

        it "keeps fromGen opaque" $ do
            let opaque = ECTAGen.fromGen $ QC.elements [Alice, Bob]
                opaqueJoin :: ECTAGen.ECTAGen _
                opaqueJoin =
                    ECTAGen.match (id :==: id) opaque (ECTAGen.elements [Bob])
            ECTAGen.pmf opaqueJoin
                `shouldBe` Left ECTAGen.CannotInspectOpaqueGenerator
            ECTAGen.cardinality opaque
                `shouldBe` Left ECTAGen.CannotInspectOpaqueGenerator
            ECTAGen.unrank opaque 0
                `shouldBe` Left ECTAGen.CannotInspectOpaqueGenerator

        it "allows an opaque source to participate in a join" $
            let opaque = ECTAGen.fromGen $ QC.elements [Alice, Bob]
                opaqueJoin :: ECTAGen.ECTAGen _
                opaqueJoin =
                    ECTAGen.match (id :==: id) opaque (ECTAGen.elements [Bob])
             in QC.property
                    (QC.forAll (ECTAGen.toGen opaqueJoin) $ uncurry (QC.===))

        it "allows an opaque source to participate in a relation" $
            let opaque = ECTAGen.fromGen $ QC.elements [Admin, Member]
                related :: ECTAGen.ECTAGen _
                related =
                    ECTAGen.relate
                        id
                        id
                        canRead
                        opaque
                        (ECTAGen.elements [Secret])
             in QC.property
                    ( QC.forAll (ECTAGen.toGen related) $ \pair ->
                        pair QC.=== (Admin, Secret)
                    )

    describe "declared groups" $ do
        it "retains source-rank order inside each computed group" $ do
            let values = [("b", 0 :: Int), ("a", 1), ("b", 2), ("a", 3)]
                source = ECTAGen.elements values
                selected = ECTAGen.atKey "a" $ ECTAGen.groupOn fst source
                namedSource = ECTAGen.namedElements [(fromString $ key <> show value, (key, value)) | (key, value) <- values]
                namedGroups = ECTAGen.nameGroups fromString $ ECTAGen.groupOn fst namedSource
                namedSelected = ECTAGen.atKey "a" namedGroups
                regrouped = ECTAGen.atKey True $ ECTAGen.regroupOn (== "a") namedGroups
            traverse (ECTAGen.unrank selected) [0, 1]
                `shouldBe` Right [("a", 1), ("a", 3)]
            ECTAGen.support namedSelected `shouldBe` ECTAGen.support selected
            fmap ECTAGen.inspectionName (ECTAGen.inspect namedSelected)
                `shouldBe` Right (Just $ fromString "a")
            fmap sort (inspectionLabels namedSelected) `shouldBe` Right (map fromString ["a1", "a3"])
            fmap sort (inspectionLabels regrouped) `shouldBe` Right (map fromString ["a1", "a3"])
            fmap ECTAGen.inspectionName (ECTAGen.inspect regrouped) `shouldBe` Right Nothing
            traverse (ECTAGen.unrank regrouped) [0, 1] `shouldBe` Right [("a", 1), ("a", 3)]

        it "preserves a finite source's support, ranks, and distribution" $ do
            let source :: ECTAGen.ECTAGen _
                source =
                    ECTAGen.frequency
                        [ (3, ECTAGen.elements [Alice])
                        , (1, ECTAGen.elements [Bob, Carol])
                        ]
                family = ECTAGen.keyed DeclaredUsers source
                selected = ECTAGen.atKey DeclaredUsers family
            ECTAGen.cardinalities family
                `shouldBe` Right (Map.singleton DeclaredUsers 3)
            ECTAGen.support selected `shouldBe` ECTAGen.support source
            traverse (ECTAGen.unrank selected) [0 .. 2]
                `shouldBe` traverse (ECTAGen.unrank source) [0 .. 2]
            ECTAGen.pmf selected `shouldBe` ECTAGen.pmf source
            ECTAGen.pmf (ECTAGen.atKey OtherUsers family)
                `shouldBe` Left ECTAGen.EmptyGenerator
            ECTAGen.smallest (ECTAGen.atKey OtherUsers family)
                `shouldBe` Right Nothing

        it "combines declared languages with the grouped choice weights" $ do
            let family :: ECTAGen.Grouped _ _
                family =
                    ECTAGen.oneofGrouped
                        [ ECTAGen.keyed DeclaredUsers $ ECTAGen.elements [Alice, Bob]
                        , ECTAGen.keyed OtherUsers $ ECTAGen.elements [Carol]
                        ]
            ECTAGen.cardinalities family
                `shouldBe` Right (Map.fromList [(DeclaredUsers, 2), (OtherUsers, 1)])
            ECTAGen.pmf (ECTAGen.ungroup family)
                `shouldBe` Right [(Alice, 1 % 4), (Bob, 1 % 4), (Carol, 1 % 2)]

        it "preserves construction failures and rejects opaque sources" $ do
            let empty = ECTAGen.elements [] :: ECTAGen UserId
                opaque = ECTAGen.fromGen $ pure Alice
            ECTAGen.cardinalities (ECTAGen.keyed DeclaredUsers empty)
                `shouldBe` Left ECTAGen.EmptyGenerator
            ECTAGen.smallest empty `shouldBe` Right Nothing
            ECTAGen.countsAtSize (ECTAGen.keyed DeclaredUsers empty) (-1)
                `shouldBe` Left ECTAGen.EmptyGenerator
            ECTAGen.massesAtSize (ECTAGen.keyed DeclaredUsers empty) (-1)
                `shouldBe` Left ECTAGen.EmptyGenerator
            ECTAGen.pmfAtSize empty (-1)
                `shouldBe` Left ECTAGen.EmptyGenerator
            ECTAGen.cardinalities (ECTAGen.keyed DeclaredUsers opaque)
                `shouldBe` Left ECTAGen.CannotInspectOpaqueGenerator
            ECTAGen.smallest opaque
                `shouldBe` Left ECTAGen.CannotInspectOpaqueGenerator
            ECTAGen.pmfAtSize opaque (-1)
                `shouldBe` Left ECTAGen.CannotInspectOpaqueGenerator

        it "merges atomic groups under a constructor at their size" $ do
            -- Each group of an atomic language is an atom of size one, and the
            -- node pays one, so the merged group is an atom of size two.
            let weighted = ECTAGen.atomic $ ECTAGen.frequency [(3, ECTAGen.elements [1, 2]), (1, ECTAGen.elements [3, 4 :: Int])]
                labelled :: ECTAGen.Grouped Bool Int
                labelled = ECTAGen.nodeWithKey (const $ fromString "n") $ ECTAGen.groupOn even weighted
                merged = ECTAGen.regroupOn (const ()) labelled
            ECTAGen.countsAtSize merged 2 `shouldBe` Right (Map.fromList [((), 4)])
            ECTAGen.pmfAtSize (ECTAGen.ungroup merged) 2 `shouldBe` Right [(1, 3 % 8), (2, 3 % 8), (3, 1 % 8), (4, 1 % 8)]

        it "reports finite retained-key masses conditional on size" $ do
            let family :: ECTAGen.Grouped _ _
                family =
                    ECTAGen.frequencies
                        [ (3, ECTAGen.keyed DeclaredUsers $ pure Alice)
                        , (1, ECTAGen.keyed OtherUsers $ pure Bob)
                        ]
            -- A pure member has size zero.
            ECTAGen.massesAtSize family (-1) `shouldBe` Right mempty
            ECTAGen.countsAtSize family 0
                `shouldBe` Right
                    ( Map.fromList
                        [ (DeclaredUsers, 1)
                        , (OtherUsers, 1)
                        ]
                    )
            ECTAGen.massesAtSize family 0
                `shouldBe` Right
                    ( Map.fromList
                        [ (DeclaredUsers, 3 % 4)
                        , (OtherUsers, 1 % 4)
                        ]
                    )
            ECTAGen.massesAtSize family 1 `shouldBe` Right mempty

    describe "ranks of imported automata" $ do
        it "ranks every term of compact, overlapping, nested, and mixed plans" $ do
            let term name children = Term.Node (fromString name) children
                a = term "a" []
                b = term "b" []
                boxed value = term "box" [value, term "u" []]
            mapM_
                (ranksEveryMemberBack ECTAGen.rankOfTerm . ECTAGen.fromAutomaton)
                [equalChildren, overlapping, nestedEquality, mixedPlans]
            map
                (uncurry $ ECTAGen.rankOfTerm . ECTAGen.fromAutomaton)
                [ (equalChildren, term "pair" [a, b])
                , (overlapping, term "f" [term "u" []])
                , (nestedEquality, term "pair" [boxed a, term "wrap" [b]])
                , (nestedEquality, term "pair" [term "c" [], term "c" []])
                , (nestedEquality, term "pair" [term "box" [a, b], boxed a])
                , (mixedPlans, term "g" [term "f" [a], term "pair" [boxed a, boxed b]])
                ]
                `shouldBe` replicate 6 (Left ECTAGen.TermNotInLanguage)

        it "ranks every term of small random acyclic automata" $ do
            let automata =
                    QCGen.unGen (QC.vectorOf 60 $ randomAutomaton =<< QC.chooseInt (1, 3)) (QCRandom.mkQCGen 20260928) 30
                counted = [(root, ECTAGen.values $ ECTAGen.fromAutomaton root) | root <- automata]
                small = [(root, terms) | (root, Right terms) <- counted, length terms <= 150]
            length small `shouldSatisfy` (>= 50)
            sequence_
                [ ECTAGen.rankOfTerm (ECTAGen.fromAutomaton root) (Term.Node (fromString "a") []) `shouldBe` Left err
                | (root, Left err) <- counted
                ]
            sequence_
                [ traverse (ECTAGen.rankOfTerm $ ECTAGen.fromAutomaton root) terms `shouldBe` Right (everyRank $ toEnum $ length terms)
                | (root, terms) <- small
                ]
            -- The terms of the next automaton are a mix of accepted and rejected terms.
            sequence_ [ranksExactlyAccepted root terms | ((root, _), (_, terms)) <- zip small (drop 1 small)]
