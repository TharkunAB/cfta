module Data.CFTA.Gen.Equality.TypedExpressionGenSpec (spec) where

import Data.Either (lefts, rights)
import Data.List (isSuffixOf)
import qualified Data.Map.Strict as Map
import Data.Maybe (listToMaybe)
import qualified Data.Set as Set
import Data.String (fromString)
import qualified Data.Tree as Tree
import Test.Hspec (Spec, describe, expectationFailure, it, shouldBe, shouldSatisfy)
import Test.Hspec.QuickCheck (modifyMaxSuccess)
import qualified Test.QuickCheck as QC
import qualified Test.QuickCheck.Random as QCRandom

import Data.CFTA.Equality (
    Edge,
    Node,
    edgeChildren,
    edgeConstraint,
    edgeSymbol,
    nodeEdges,
    numNestedMu,
    termsWith,
    unfoldBounded,
 )
import qualified Data.CFTA.Equality as ECTA
import Data.CFTA.Equality.Constraint (unsafeGetEclasses)
import qualified Data.CFTA.Gen.Equality.QuickCheck as ECTAGen
import Data.CFTA.Gen.TypedExpressionLanguage
import Data.CFTA.Index (Cardinality (..), ChildIndex (..), Rank (..), TransitionIndex (..), everyRank)
import Data.CFTA.Symbol (Symbol)

-- | Infer a ground type independently of either generator.
inferType :: Expression -> Maybe Type
inferType (IntLiteral _) = Just TInt
inferType (BoolLiteral _) = Just TBool
inferType (Not value) = do
    valueType <- inferType value
    if valueType == TBool then Just TBool else Nothing
inferType (ApplyBinary function_ first second) = do
    firstType <- inferType first
    secondType <- inferType second
    case function_ of
        Equal
            | firstType == secondType -> Just TBool
            | otherwise -> Nothing
        Add -> homogeneous TInt firstType secondType
        Multiply -> homogeneous TInt firstType secondType
        Or -> homogeneous TBool firstType secondType
        And -> homogeneous TBool firstType secondType
  where
    homogeneous expected firstType secondType
        | firstType == expected && secondType == expected = Just expected
        | otherwise = Nothing
inferType (IfExpression condition ifTrue ifFalse) = do
    conditionType <- inferType condition
    trueType <- inferType ifTrue
    falseType <- inferType ifFalse
    if conditionType == TBool && trueType == falseType
        then Just trueType
        else Nothing

-- | Number of application layers in an expression.
expressionDepth :: Expression -> Int
expressionDepth (Not value) = 1 + expressionDepth value
expressionDepth (ApplyBinary _ first second) =
    1 + max (expressionDepth first) (expressionDepth second)
expressionDepth (IfExpression condition ifTrue ifFalse) =
    1 + maximum [expressionDepth condition, expressionDepth ifTrue, expressionDepth ifFalse]
expressionDepth _ = 0

-- | Check the generated annotation against independent inference.
isWellTyped :: TypedExpression -> Bool
isWellTyped typed =
    inferType (expression typed) == Just (expressionType typed)

-- | Find a joined edge that retains the requested argument constraints.
hasArgumentConstraints :: Int -> Node (ECTAGen.Label Symbol) -> Bool
hasArgumentConstraints count node = any edgeMatches $ nodeEdges node
  where
    edgeMatches edge =
        length (unsafeGetEclasses $ ECTA.equalities $ edgeConstraint edge) == count
            || any (hasArgumentConstraints count) (edgeChildren edge)

-- | Collect the constructor symbols from one finite support graph.
supportSymbols :: Node (ECTAGen.Label Symbol) -> [ECTAGen.Label Symbol]
supportSymbols = map edgeSymbol . supportEdges

-- | Collect the edges from one finite support graph.
supportEdges :: Node (ECTAGen.Label Symbol) -> [Edge (ECTAGen.Label Symbol)]
supportEdges node =
    edges <> concatMap supportEdges (concatMap edgeChildren edges)
  where
    edges = nodeEdges node

-- | Independently enumerate the exact-depth reference language.
referenceExpressions :: Int -> Type -> [Expression]
referenceExpressions 0 TInt = [IntLiteral 0, IntLiteral 1]
referenceExpressions 0 TBool = [BoolLiteral False, BoolLiteral True]
referenceExpressions depth TInt =
    [ ApplyBinary function_ first second
    | function_ <- [Add, Multiply]
    , first <- integers
    , second <- integers
    ]
        <> [ IfExpression condition ifTrue ifFalse
           | condition <- booleans
           , ifTrue <- integers
           , ifFalse <- integers
           ]
  where
    integers = referenceExpressions (depth - 1) TInt
    booleans = referenceExpressions (depth - 1) TBool
referenceExpressions depth TBool =
    [Not value | value <- booleans]
        <> [ ApplyBinary Equal first second
           | values <- [integers, booleans]
           , first <- values
           , second <- values
           ]
        <> [ ApplyBinary function_ first second
           | function_ <- [Or, And]
           , first <- booleans
           , second <- booleans
           ]
        <> [ IfExpression condition ifTrue ifFalse
           | condition <- booleans
           , ifTrue <- booleans
           , ifFalse <- booleans
           ]
  where
    integers = referenceExpressions (depth - 1) TInt
    booleans = referenceExpressions (depth - 1) TBool

-- | The typed-expression generators against independent type inference.
spec :: Spec
spec =
    describe "typed expression generation" $ do
        it "matches the independent uniform 27,054-expression depth-two language" $ do
            let depthTwoCount = sum $ map (expressionCount 2) allTypes
                expectedMass = 1 / fromIntegral depthTwoCount
                depthTwoGenerator = expressionGenAtDepth 2
                expectedLanguage =
                    Set.fromList
                        [ TypedExpression result value
                        | result <- allTypes
                        , value <- referenceExpressions 2 result
                        ]
            depthTwoCount `shouldBe` 27054
            case ECTAGen.pmf depthTwoGenerator of
                Left err -> expectationFailure $ show err
                Right outcomes -> do
                    toInteger (length outcomes) `shouldBe` depthTwoCount
                    all ((== expectedMass) . snd) outcomes `shouldBe` True
                    Set.fromList (map fst outcomes) `shouldBe` expectedLanguage
            case ECTAGen.support depthTwoGenerator of
                Left err -> expectationFailure $ show err
                Right node -> length (termsWith (ECTAGen.Label $ fromString "Mu") node) `shouldBe` 27054

        it "represents unary, binary, and ternary dependencies in ECTA edges" $
            case ECTAGen.support (expressionGenAtDepth 1) of
                Right node -> do
                    map (`hasArgumentConstraints` node) [1, 2, 3]
                        `shouldBe` [True, True, True]
                    case ECTA.toTree node of
                        Left err -> expectationFailure $ show err
                        Right tree -> do
                            Tree.rootLabel tree `shouldBe` Left (ECTA.Expanded [] node)
                            length (rights $ Tree.flatten tree) `shouldBe` ECTA.edgeCount node
                            let views = lefts $ Tree.flatten tree
                                follow current [] = Just current
                                follow current (ECTA.ViewStep (TransitionIndex alternative) (ChildIndex child) : rest) = do
                                    edge <- listToMaybe $ drop alternative $ nodeEdges current
                                    next <- listToMaybe $ drop child $ edgeChildren edge
                                    follow next rest
                            map (follow node . ECTA.viewPath) views `shouldBe` map (Just . ECTA.viewNode) views
                Left err -> expectationFailure $ show err

        it "keeps the domain labels that close grouped do-blocks" $
            case ECTAGen.support (expressionGenAtDepth 1) of
                Right node ->
                    Set.fromList (supportSymbols node)
                        `shouldSatisfy` \symbols ->
                            Set.fromList (map (ECTAGen.Label . fromString) ["not", "binary-application", "if"])
                                `Set.isSubsetOf` symbols
                Left err -> expectationFailure $ show err

        it "keeps grouped constraints on the domain-labelled edge" $
            case ECTAGen.support (ECTAGen.ungroup $ binaryLayer literalsByType) of
                Right node -> do
                    let constrained =
                            [ edge
                            | edge <- supportEdges node
                            , not $ null $ unsafeGetEclasses $ ECTA.equalities $ edgeConstraint edge
                            ]
                    Set.fromList (map edgeSymbol constrained)
                        `shouldBe` Set.singleton (ECTAGen.Label $ fromString "binary-application")
                    map (length . unsafeGetEclasses . ECTA.equalities . edgeConstraint) constrained
                        `shouldSatisfy` \counts -> not (null counts) && all (== 2) counts
                Left err -> expectationFailure $ show err

        it "counts the exact depth-three language without enumerating it" $
            ECTAGen.cardinality (expressionGenAtDepth 3)
                `shouldBe` Right 8887065932466

        it "constructs the exact depth-four language from compact groups" $ do
            let depthFourCount = sum $ map (expressionCount 4) allTypes
            depthFourCount
                `shouldBe` 494767711145600737617026761045287855174
            ECTAGen.cardinality (expressionGenAtDepth 4)
                `shouldBe` Right (Cardinality depthFourCount)

        it "retains the exact depth-four result-type groups" $ do
            let intCount = 8212679320301537966337327308329713664 :: Integer
                boolCount = 486555031825299199650689433736958141510
                total = intCount + boolCount
                boundaries =
                    [ (Rank 0, TInt)
                    , (Rank $ intCount - 1, TInt)
                    , (Rank intCount, TBool)
                    , (Rank $ total - 1, TBool)
                    ]
            ECTAGen.cardinalities (depthByType 4)
                `shouldBe` Right
                    ( Map.fromList
                        [ (TInt, Cardinality intCount)
                        , (TBool, Cardinality boolCount)
                        ]
                    )
            traverse
                (\(rank, _) -> expressionType <$> ECTAGen.unrank (expressionGenAtDepth 4) rank)
                boundaries
                `shouldBe` Right (map snd boundaries)

        it "unranks representative depth-four expressions" $ do
            let total = 494767711145600737617026761045287855174
            traverse
                (ECTAGen.unrank (expressionGenAtDepth 4) . Rank)
                [0, total `div` 2, total - 1]
                `shouldSatisfy` either (const False) (all isWellTyped)

        it "counts exact depth-one coverage by result type" $
            ECTAGen.countOn expressionType (expressionGenAtDepth 1)
                `shouldBe` Right
                    ( Map.fromList
                        [ (TInt, 16)
                        , (TBool, 26)
                        ]
                    )

        it "builds the uniform depth-at-most-two language with frequencies" $ do
            let expectedMass = 1 / fromIntegral (upToDepthCount 2)
                generator = ECTAGen.ungroup $ upToDepthByType 2
            upToDepthCount 2 `shouldBe` 34380
            ECTAGen.cardinalities (upToDepthByType 2)
                `shouldBe` Right
                    ( Map.fromList
                        [ (TInt, 9722)
                        , (TBool, 24658)
                        ]
                    )
            case ECTAGen.pmf generator of
                Left err -> expectationFailure $ show err
                Right outcomes -> do
                    toInteger (length outcomes) `shouldBe` upToDepthCount 2
                    all ((== expectedMass) . snd) outcomes `shouldBe` True

        it "counts the depth-at-most-four language without enumerating it" $
            ECTAGen.cardinality (ECTAGen.ungroup $ upToDepthByType 4)
                `shouldBe` Right (Cardinality $ upToDepthCount 4)

        it "shrinks any failing expression to the minimal application" $ do
            let generator = ECTAGen.ungroup $ upToDepthByType 2
                minimal =
                    TypedExpression TBool $
                        Not (BoolLiteral False)
            result <-
                QC.quickCheckWithResult
                    QC.stdArgs{QC.replay = Just (QCRandom.mkQCGen 20260912, 0), QC.chatty = False, QC.maxSuccess = 300}
                    $ ECTAGen.forAll generator
                    $ \typed ->
                        expressionDepth (expression typed) == 0
            case result of
                QC.Failure{QC.failingTestCase = [shown]} ->
                    shown `shouldSatisfy` (show minimal `isSuffixOf`)
                _ -> expectationFailure "expected the depth property to fail"

        it "shrinks to the globally smallest failing member" $ do
            let generator = ECTAGen.ungroup $ upToDepthByType 2
                containsAdd (ApplyBinary function_ first second) =
                    function_ == Add || containsAdd first || containsAdd second
                containsAdd (Not value) = containsAdd value
                containsAdd (IfExpression condition ifTrue ifFalse) =
                    any containsAdd [condition, ifTrue, ifFalse]
                containsAdd _ = False
                nodes :: Expression -> Int
                nodes (Not value) = 1 + nodes value
                nodes (ApplyBinary _ first second) = 1 + nodes first + nodes second
                nodes (IfExpression condition ifTrue ifFalse) =
                    1 + nodes condition + nodes ifTrue + nodes ifFalse
                nodes _ = 1
                failing typed =
                    containsAdd (expression typed)
                        && expressionDepth (expression typed) >= 2
                minimalFailingNodes = case ECTAGen.pmf generator of
                    Right outcomes ->
                        minimum [nodes (expression typed) | (typed, _) <- outcomes, failing typed]
                    Left err -> error $ show err
            result <-
                QC.quickCheckWithResult
                    QC.stdArgs{QC.replay = Just (QCRandom.mkQCGen 20260912, 0), QC.chatty = False, QC.maxSuccess = 500}
                    $ ECTAGen.forAll generator
                    $ \typed ->
                        not (failing typed)
            case result of
                QC.Failure{QC.failingTestCase = [shown]} -> do
                    let rank = Rank $ read (takeWhile (/= ':') (drop 5 shown))
                    case ECTAGen.unrank generator rank of
                        Right shrunk -> do
                            failing shrunk `shouldBe` True
                            nodes (expression shrunk) `shouldBe` minimalFailingNodes
                        Left err -> expectationFailure $ show err
                _ -> expectationFailure "expected the property to fail"

        it "counts the recursive family by structural size" $ do
            -- A literal has size one. An application pays one for its node and
            -- one for its operation: not of a literal has size three, and a
            -- binary application of two literals size four.
            let flat = ECTAGen.ungroup recursiveExpressions
            traverse (ECTAGen.countAtSize flat) [1 .. 4]
                `shouldBe` Right
                    [4, 0, 2, 24]
            traverse
                ( \result ->
                    traverse
                        (ECTAGen.countAtSize $ ECTAGen.atKey result recursiveExpressions)
                        [1 .. 4]
                )
                allTypes
                `shouldBe` Right [[2, 0, 0, 8], [2, 0, 2, 16]]

        it "generates exactly the first four finite size classes" $ do
            let bounded = ECTAGen.upToSize 4 $ ECTAGen.ungroup recursiveExpressions
                members generator = case ECTAGen.cardinality generator of
                    Right total ->
                        traverse (ECTAGen.unrank generator) $ everyRank total
                    Left err -> Left err
            ECTAGen.cardinality bounded `shouldBe` Right 30
            members bounded `shouldSatisfy` either (const False) (all isWellTyped)

        it "retains one recursive automaton whose cycle carries the constraints" $
            case ECTAGen.support (ECTAGen.ungroup recursiveExpressions) of
                Left err -> expectationFailure $ show err
                Right node -> do
                    numNestedMu node `shouldBe` 1
                    -- Unfolding the recursion twice admits the literals and one
                    -- application layer, and nothing ill-typed: 46 members.
                    length (termsWith (ECTAGen.Label $ fromString "Mu") $ unfoldBounded 2 node) `shouldBe` 46

        it "keeps every recursive group at its own result type" $ do
            let groupHasType result = do
                    let bounded = ECTAGen.upToSize 5 $ ECTAGen.atKey result recursiveExpressions
                    total <- ECTAGen.cardinality bounded
                    generatedTypes <-
                        traverse
                            (fmap expressionType . ECTAGen.unrank bounded)
                            (everyRank total)
                    pure $ all (== result) generatedTypes
            traverse groupHasType allTypes `shouldBe` Right [True, True]

        it "ranks the term of every depth-at-most-two rank and of recursive ranks back to the rank" $ do
            let unranked generator ranks =
                    [rank | rank <- ranks, (ECTAGen.rankOf generator =<< ECTAGen.termAt generator rank) /= Right rank]
            unranked (ECTAGen.ungroup $ upToDepthByType 2) (everyRank $ Cardinality $ upToDepthCount 2) `shouldBe` []
            unranked (ECTAGen.ungroup recursiveExpressions) ([0 .. 2999] <> [10 ^ (6 :: Int), 10 ^ (12 :: Int) + 7])
                `shouldBe` []

        modifyMaxSuccess (const 500) $
            it "samples only well-typed expressions from the recursive family" $
                QC.forAll (QC.resize 7 $ ECTAGen.toGen $ ECTAGen.ungroup recursiveExpressions) $
                    \typed -> QC.counterexample (show typed) $ QC.property $ isWellTyped typed

        modifyMaxSuccess (const 1000) $
            it "samples only well-typed depth-at-most-four expressions" $
                QC.forAll (ECTAGen.toGen $ ECTAGen.ungroup $ upToDepthByType 4) $ \typed ->
                    QC.counterexample (show typed) $ QC.property $ isWellTyped typed

        modifyMaxSuccess (const 1000) $
            it "samples only well-typed depth-four expressions through ECTA" $
                QC.forAll (ECTAGen.toGen $ expressionGenAtDepth 4) $ \typed ->
                    QC.counterexample (show typed) $ QC.property $ isWellTyped typed

        modifyMaxSuccess (const 500) $
            it "samples only well-typed exact-depth expressions through rejection" $
                QC.forAll (naiveExpressionGen 4) $ \typed ->
                    QC.counterexample (show typed) $
                        QC.conjoin
                            [ QC.property $ isWellTyped typed
                            , expressionDepth (expression typed) QC.=== 4
                            ]

        modifyMaxSuccess (const 1000) $
            it "samples only well-typed depth-four expressions through handwritten sharing" $
                QC.forAll (handwrittenExpressionGen 4) $ \typed ->
                    QC.counterexample (show typed) $ QC.property $ isWellTyped typed
