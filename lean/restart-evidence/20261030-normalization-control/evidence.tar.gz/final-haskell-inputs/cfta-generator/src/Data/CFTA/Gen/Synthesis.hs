{-# LANGUAGE OverloadedStrings #-}

{- | Type-directed component synthesis on equality-constrained automata.

This is Hectare, the synthesizer of Koppel, Guo, de Vries, Solar-Lezama, and
Polikarpova, /Searching Entangled Program Spaces/ (ICFP 2022), on the engine
of cfta. A query gives typed arguments and a goal type. The synthesizer
builds one automaton of the well-typed programs of a size that apply library
components and use every argument, keeps the programs of the goal type,
reduces the automaton, and lists its programs.

The encoding follows the paper. A type is a term: a type constructor with
its arguments as children, and a function type as the symbol @->@ with an
arrow marker and the argument and result types. A program term has its type
as its first child. A component has its type as its only child: each type
variable of a component becomes the node of all types, and equality
constraints tie its occurrences, so that each use of the component chooses
its own instance. An application has four children: the result type, the
arrow marker, the function, and the argument, and three equalities say that
the function has an arrow type from the type of the argument to the result
type. The type variables of a query are rigid: they are leaves that only the
node of all types and the query's own arguments contain.

Components of the same type form one group, and the automaton has one symbol
for each group, its representative. A program of representatives stands for
every program that replaces each representative by a member of its group
('expand').

'programsOfSize' reads the reduced automaton as a generator: the
well-typed programs of a size get exact counts, ranks, uniform sampling,
and shrinking. A type variable that the goal does not fix keeps the node of
all types, so a program can have many typed terms, and the import cannot
count them. 'programsOfSizeUpToDepth' bounds the typed terms by a depth.
-}
module Data.CFTA.Gen.Synthesis (
    -- * Types
    Type (..),
    (~>),
    typeVariables,
    parseType,
    typeParser,
    renderType,

    -- * Libraries and queries
    Library (..),
    Encoding (..),
    Defaulting (..),
    Domain (..),
    library,
    Query (..),

    -- * Programs
    Program (..),
    parseProgram,
    renderProgram,
    expand,
    representative,

    -- * Search
    typeNode,
    rawSearchSpace,
    Saturation (..),
    rawSaturatedSearchSpace,
    reduceFully,
    reductionRounds,
    searchSpace,
    Space (..),
    reduceWithOrder,
    orderedSpace,
    programsIn,
    distinctProgramsIn,
    programRuns,
    solutionsOfSize,
    distinctSolutionsOfSize,
    distinctSaturatedSolutionsOfSize,
    synthesize,

    -- * Generators
    programsOfSize,
    programsOfSizeUpToDepth,
) where

import Control.Monad (guard)
import Data.Bifunctor (first)
import Data.Char (isAlphaNum, isLower, isSpace, isUpper)
import Data.Containers.ListUtils (nubOrd)
import Data.Hashable (Hashable)
import qualified Data.IntMap.Strict as IntMap
import qualified Data.IntSet as IntSet
import Data.List (intercalate, permutations, subsequences)
import qualified Data.Map.Lazy as LazyMap
import qualified Data.Map.Strict as Map
import Data.Maybe (catMaybes, fromMaybe, isJust)
import qualified Data.Set as Set
import Data.Text (Text)
import qualified Data.Text as Text
import GHC.Generics (Generic)
import Text.ParserCombinators.ReadP (
    ReadP,
    between,
    char,
    choice,
    many,
    many1,
    munch,
    munch1,
    option,
    satisfy,
    sepBy1,
    (+++),
    (<++),
 )

import Data.CFTA.Equality
import Data.CFTA.Gen.Equality (ECTAGen)
import qualified Data.CFTA.Gen.Equality as ECTAGen
import Data.CFTA.Gen.Synthesis.Internal.Syntax (lexeme, parseWhole, token)
import Data.CFTA.Index (Depth)
import Data.CFTA.Symbol (Symbol (Symbol), symbolText)
import Data.CFTA.Term (Term)
import qualified Data.CFTA.Term as Term

-- Types

{- | A type: a type variable, a function type, or a type constructor with its
arguments. The constructor @Fun@ with two arguments is a function type too.
-}
data Type
    = TVar Text
    | TFun Type Type
    | TCons Text [Type]
    deriving (Eq, Ord, Show, Read, Generic)

instance Hashable Type

infixr 1 ~>

-- | The function type from the first type to the second.
(~>) :: Type -> Type -> Type
(~>) = TFun

-- | The type variables of a type, each once, in order of occurrence.
typeVariables :: Type -> [Text]
typeVariables = nubOrd . go
  where
    go (TVar name) = [name]
    go (TFun argument result) = go argument <> go result
    go (TCons _ arguments) = concatMap go arguments

{- | Parse a type in Haskell syntax. A lowercase name is a type variable. A
capitalized name with its arguments is a type constructor, as in
@Either a b@. The type @[t]@ is the constructor @List@, @(a, b)@ is @Pair@,
and @()@ is @Unit@. The arrow @->@ is a function type, and it associates to
the right. A class constraint uses the encoding of Hoogle+: @Eq a => t@ is
the function type from the dictionary @\@\@hplusTC\@\@Eq a@ to @t@, and
@(Eq a, Show b) => t@ takes the dictionaries in the written order. A name
can contain \@, so that a dictionary can be a type of its own.
-}
parseType :: Text -> Either String Type
parseType = parseWhole "type" typeParser

{- | The parser of 'parseType', for the parsers of larger syntax, such as the
refinement types of "Data.CFTA.Gen.Synthesis.Liquid".
-}
typeParser :: ReadP Type
typeParser = constrained +++ function
  where
    constrained = do
        dictionaries <- context <* token "=>"
        (\body -> foldr TFun body dictionaries) <$> typeParser
    context = (pure <$> constraint) +++ between (token "(") (token ")") (sepBy1 constraint (token ","))
    constraint = TCons . (classPrefix <>) <$> constructorName <*> many atomic
    function = do
        argument <- applied
        option argument (TFun argument <$> (token "->" *> typeParser))
    applied = (TCons <$> constructorName <*> many1 atomic) +++ atomic
    atomic =
        choice
            [ TVar <$> name isLower
            , (`TCons` []) <$> constructorName
            , TCons "Unit" [] <$ (token "(" *> token ")")
            , (\element -> TCons "List" [element]) <$> between (token "[") (token "]") typeParser
            , between (token "(") (token ")") $ do
                firstType <- typeParser
                option firstType ((\secondType -> TCons "Pair" [firstType, secondType]) <$> (token "," *> typeParser))
            ]
    constructorName = name (\c -> isUpper c || c == '@')
    name isStart = lexeme $ Text.pack <$> ((:) <$> satisfy isStart <*> munch isNameCharacter)
    isNameCharacter c = isAlphaNum c || c `elem` ("_'@" :: String)

{- | A type in the syntax of 'parseType'. 'parseType' reads the result back
to the same type when each name is valid in that syntax.
-}
renderType :: Type -> String
renderType = go 0
  where
    -- The precedence is 0 for any type, 1 for the argument of a function
    -- type, and 2 for the argument of a type constructor.
    go :: Int -> Type -> String
    go precedence typ = case typ of
        TVar name -> Text.unpack name
        TCons "List" [element] -> "[" <> go 0 element <> "]"
        TCons "Pair" [firstType, secondType] -> "(" <> go 0 firstType <> ", " <> go 0 secondType <> ")"
        TCons "Unit" [] -> "()"
        TCons name [] -> Text.unpack name
        TCons name arguments -> parenthesize (precedence > 1) $ applied name arguments
        TFun argument result -> parenthesize (precedence > 0) $ case constraints typ of
            ([], _) -> go 1 argument <> " -> " <> go 0 result
            ([constraint], body) -> constraint <> " => " <> go 0 body
            (several, body) -> "(" <> intercalate ", " several <> ") => " <> go 0 body
    applied name arguments = unwords (Text.unpack name : map (go 2) arguments)
    -- The class constraints at the start of a type, and the rest of the type.
    constraints (TFun (TCons name arguments) result)
        | Just className <- Text.stripPrefix classPrefix name =
            first (applied className arguments :) (constraints result)
    constraints typ = ([], typ)
    parenthesize True text = "(" <> text <> ")"
    parenthesize False text = text

-- | The prefix of the type constructor of a class dictionary in Hoogle+.
classPrefix :: Text
classPrefix = "@@hplusTC@@"

-- Libraries and queries

-- | A component library, grouped by type.
data Library = Library
    { libraryGroups :: [(Text, Type, [Text])]
    -- ^ Each group: its representative, the type, and its members in source order.
    , libraryArgumentOnly :: [(Text, Type)]
    -- ^ Components that only appear as an argument, such as @($)@ and @id@.
    , libraryAvoid :: [([Text], Maybe [Text])]
    {- ^ Pruning rules for terms of size two: a function of the first list is
    not applied to a component of the second list, such as @head@ to @Nil@.
    With 'Nothing', the functions head no term of size two.
    -}
    , libraryEncoding :: Encoding
    -- ^ How the automaton encodes the types.
    }
    deriving (Show)

-- | How the automaton encodes the types of a library and a query.
data Encoding
    = -- | A type constructor is the symbol of an edge, with its arguments as its children.
      FirstOrder
    | {- | A type constructor is a leaf, applied to its arguments one at a
      time by @\@@ edges, so that a type variable can stand for a type
      constructor. A type constructor whose name starts with @?@, as
      @?Foldable t0@ or @?Ord t1@, is a type variable whose domain the map
      gives, by the text after the @?@ up to the first space (the names of
      the variable's classes, as @Foldable@ or @Applicative,Foldable@).
      -}
      Curried Defaulting (Map.Map Text Domain)
    deriving (Show)

-- | The types over which a variable of the curried encoding ranges.
data Domain
    = {- | Types of kind @* -> *@, as @Maybe@ or @Either e@ (each a type
      constructor with one argument less than its arity), and whether the
      list type is the variable's default under 'OnlyDefault'.
      -}
      HeadDomain Bool [Type]
    | {- | Types of kind @*@, as @Int@ or @List x0@. When the program does
      not determine such a variable, a run lists one typed term for it, not
      one for each type ('domainMarkers').
      -}
      TypeDomain [Type]
    deriving (Show)

{- | Which types of its domain a variable of kind @* -> *@ of the curried
encoding takes when the program does not determine it, as @t@ in
@length (pure x)@. The program determines a variable when a constraint of
the run ties it to a type constructor, as @lookup@ ties the @t@ of
@length (lookup k xs)@ to @Maybe@.
-}
data Defaulting
    = -- | Every type of its domain, so a program has a typed term for each.
      AnyHead
    | {- | Only the list type, when the 'HeadDomain' of the variable (or of
      one of the domains that the run intersects with it) has the list as
      its default; else none, so the run is dropped. GHC's
      @ExtendedDefaultRules@ default such a variable to the list type when
      one of its classes is @Foldable@ or @Traversable@.
      -}
      OnlyDefault
    deriving (Show)

{- | The library of the components, with the components that only appear as
an argument and the pruning rules. Components of one type form one group,
whose representative is @f@ and its index; a pruning rule names members, and
it applies to their groups.
-}
library :: [(Text, Type)] -> [(Text, Type)] -> [([Text], Maybe [Text])] -> Library
library components argumentOnly avoid =
    Library
        { libraryGroups = [(representativeOf index, typ, members) | (index, (typ, members)) <- zip [0 :: Int ..] groups]
        , libraryArgumentOnly = argumentOnly
        , libraryAvoid = [(map toRepresentative functions, map toRepresentative <$> arguments) | (functions, arguments) <- avoid]
        , libraryEncoding = FirstOrder
        }
  where
    groups = foldr addMember [] (reverse components)
    addMember (name, typ) found = case break ((== typ) . fst) found of
        (before, (_, members) : after) -> before <> ((typ, members <> [name]) : after)
        (before, []) -> before <> [(typ, [name])]
    representativeOf index = "f" <> Text.pack (show index)
    toRepresentative name = fromMaybe name $ Map.lookup name memberToRepresentative
    memberToRepresentative =
        Map.fromList [(member, representativeOf index) | (index, (_, members)) <- zip [0 :: Int ..] groups, member <- members]

-- | A query: the arguments with their types, and the goal type.
data Query = Query
    { queryArguments :: [(Text, Type)]
    , queryGoal :: Type
    }
    deriving (Eq, Show)

-- Programs

-- | A program: a component or an argument, or an application.
data Program
    = Var Text
    | App Program Program
    deriving (Eq, Ord, Show, Read)

-- | A program in Haskell syntax, as in @map f xs@.
renderProgram :: Program -> String
renderProgram = go False
  where
    go _ (Var name) = Text.unpack name
    go nested (App function argument) =
        (if nested then \text -> "(" <> text <> ")" else id) $
            goFunction function <> " " <> go True argument
    goFunction (Var name) = Text.unpack name
    goFunction applied = go False applied

{- | Parse a program in Haskell syntax: names and their applications, as in
@map f (filter p xs)@. Application associates to the left. A name is a run
of characters without spaces and parentheses, such as
@Data.Maybe.fromMaybe@ or @$@. An operator in parentheses is part of a
name, as in @(Data.Bool.&&)@, and the name can continue after the
parenthesis, as in @(Data.Eq.\/=)_Ord@. Other parentheses group.
'parseProgram' reads the result of 'renderProgram' back to the same program.
-}
parseProgram :: Text -> Either String Program
parseProgram = parseWhole "program" programParser

-- | The parser of 'parseProgram'.
programParser :: ReadP Program
programParser = foldl1 App <$> many1 (lexeme atom)
  where
    atom = (Var . Text.pack <$> name) <++ between (char '(') (lexeme (char ')')) programParser
    name = ((<>) <$> parenthesizedOperator <*> munch nameCharacter) +++ munch1 nameCharacter
    parenthesizedOperator = do
        operator <- between (char '(') (char ')') (munch1 nameCharacter)
        guard $ not $ isAlphaNum (last operator) || last operator `elem` ("_'" :: String)
        pure ("(" <> operator <> ")")
    nameCharacter c = not (isSpace c) && c `notElem` ("()" :: String)

-- | Every program that replaces each representative by a member of its group.
expand :: Library -> Program -> [Program]
expand lib = go
  where
    members = Map.fromList [(representativeName, names) | (representativeName, _, names) <- libraryGroups lib]
    go (Var name) = map Var $ fromMaybe [name] $ Map.lookup name members
    go (App function argument) = App <$> go function <*> go argument

-- | The program with each component replaced by the representative of its group.
representative :: Library -> Program -> Program
representative lib = go
  where
    toRepresentative =
        Map.fromList [(member, representativeName) | (representativeName, _, members) <- libraryGroups lib, member <- members]
    go (Var name) = Var $ fromMaybe name $ Map.lookup name toRepresentative
    go (App function argument) = App (go function) (go argument)

-- The encoding

-- | The marker that is the first child of a function type.
arrowMarker :: Node Symbol
arrowMarker = Node [Edge "(->)" []]

-- | The node of a function type.
arrowType :: Node Symbol -> Node Symbol -> Node Symbol
arrowType argument result = Node [Edge "->" [arrowMarker, argument, result]]

{- | The node of a type, with each type variable a rigid leaf. A component
type replaces these leaves by the node of all types ('generalize').
-}
typeNode :: Type -> Node Symbol
typeNode (TVar name) = Node [Edge (variableSymbol name) []]
typeNode (TFun argument result) = arrowType (typeNode argument) (typeNode result)
typeNode (TCons "Fun" [argument, result]) = arrowType (typeNode argument) (typeNode result)
typeNode (TCons name arguments) = Node [Edge (Symbol name) (map typeNode arguments)]

{- | The symbol of a type variable. The paper names the first four variables
@var1@ to @var4@, and the node of all types contains these four.
-}
variableSymbol :: Text -> Symbol
variableSymbol name = Symbol $ fromMaybe ("var_" <> name) $ lookup name [("a", "var1"), ("b", "var2"), ("c", "var3"), ("d", "var4")]

{- | The node of a type in an encoding: 'typeNode' for 'FirstOrder'. In the
curried encoding, a type constructor is a leaf, and an application of a
type to a type is an @\@@ edge; a function type is as in 'typeNode'.
-}
typeNodeWith :: Encoding -> Type -> Node Symbol
typeNodeWith FirstOrder = typeNode
typeNodeWith (Curried _ _) = curried
  where
    curried (TVar name) = Node [Edge (variableSymbol name) []]
    curried (TFun argument result) = arrowType (curried argument) (curried result)
    curried (TCons "Fun" [argument, result]) = arrowType (curried argument) (curried result)
    curried (TCons name arguments) = foldl typeApplication (Node [Edge (Symbol name) []]) (map curried arguments)

-- | In the curried encoding, the application of a type to a type.
typeApplication :: Node Symbol -> Node Symbol -> Node Symbol
typeApplication function argument = Node [Edge "@" [function, argument]]

-- | The key of the domain of the leaf of a type variable of kind @* -> *@ in the curried encoding: the names of its classes.
higherClass :: Node Symbol -> Maybe Text
higherClass (Node [Edge (Symbol name) []]) = Text.takeWhile (/= ' ') <$> Text.stripPrefix "?" name
higherClass _ = Nothing

-- | Whether a node is the leaf of a type variable.
isVariable :: Node Symbol -> Bool
isVariable (Node [Edge (Symbol name) []]) = name `elem` ["var1", "var2", "var3", "var4"] || "var_" `Text.isPrefixOf` name
isVariable _ = False

{- | The node of all types: the function types, the four type variables, and
the type constructors of the library and the query with their arities.
-}
allTypes :: [(Text, Int)] -> Node Symbol
allTypes constructors =
    createMu $ \types ->
        union $
            [arrowType types types]
                <> map (\name -> Node [Edge name []]) ["var1", "var2", "var3", "var4"]
                <> [Node [Edge (Symbol name) (replicate arity types)] | (name, arity) <- constructors]

{- | The node of all types in the curried encoding: the function types, the
four type variables, and each type constructor applied to as many types as
its arity. The arity of a type constructor is the largest number of
arguments that it has in the types.
-}
allCurriedTypes :: Defaulting -> Bool -> [(Text, Int)] -> Node Symbol
allCurriedTypes defaulting typeDomains constructors =
    createMu $ \types ->
        let ofKind missing =
                union $
                    [Node [Edge (Symbol name) []] | (name, arity) <- arities, arity == missing]
                        <> [typeApplication (ofKind (missing + 1)) types | missing < largest]
                        <> [marker | missing == 1, marker <- anyMarkers defaulting]
         in union $
                [arrowType types types]
                    <> map (\name -> Node [Edge name []]) ["var1", "var2", "var3", "var4"]
                    <> [ofKind 0]
                    <> [anyTypeMarker | typeDomains]
  where
    arities = Map.toList (Map.fromListWith max [(name, arity) | (name, arity) <- constructors, not ("?" `Text.isPrefixOf` name)])
    largest = maximum (0 : map snd arities)

-- | Whether a domain is a 'TypeDomain'.
isTypeDomain :: Domain -> Bool
isTypeDomain (TypeDomain _) = True
isTypeDomain (HeadDomain _ _) = False

-- | The type constructors of a type with their arities.
constructorsOf :: Type -> [(Text, Int)]
constructorsOf (TVar _) = []
constructorsOf (TFun argument result) = constructorsOf argument <> constructorsOf result
constructorsOf (TCons name arguments) = [(name, length arguments) | name /= "Fun"] <> concatMap constructorsOf arguments

{- | A component type with each type variable replaced by the node of all
types, and equality constraints that tie the occurrences of each variable.
-}
generalize :: Node Symbol -> Node Symbol -> Node Symbol
generalize types typ@(Node [Edge symbol _]) = case mapNodes (\node -> if isVariable node then types else node) typ of
    Node [Edge _ children] -> Node [mkEdge symbol children (equalityConstraint $ mkEqConstraints $ map pathsOf variables)]
    other -> other
  where
    variables = nubOrd $ crush (\node -> [node | isVariable node]) typ
    pathsOf variable = pathsMatching (== variable) typ
generalize _ typ = typ

{- | 'generalize' in an encoding. In the curried encoding, a curried variable
is replaced by the node of its domain ('domainNodes'), and the equality
constraints also tie its occurrences.
-}
generalizeWith :: Encoding -> Map.Map Text (Node Symbol) -> Node Symbol -> Node Symbol -> Node Symbol
generalizeWith FirstOrder _ types typ = generalize types typ
generalizeWith (Curried _ _) nodes types typ@(Node [Edge symbol _]) = case mapNodes replace typ of
    Node [Edge _ children] -> Node [mkEdge symbol children (equalityConstraint $ mkEqConstraints $ map pathsOf variables)]
    other -> other
  where
    replace node
        | isVariable node = types
        | Just className <- higherClass node = Map.findWithDefault (union []) className nodes
        | otherwise = node
    variables = nubOrd $ crush (\node -> [node | isVariable node || isJust (higherClass node)]) typ
    pathsOf variable = pathsMatching (== variable) typ
generalizeWith _ _ _ typ = typ

{- | The node of each domain of the curried encoding: its types, with their
type variables replaced by the node of all types, and its markers
('domainMarkers'). A curried variable in a type of a domain, as the
@?Ord x0@ of @List (?Ord x0)@ in the domain of @Ord@, is the node of its
own domain, unrolled to 'domainDepth' levels; below them it is the node of
all types, which only adds types. So the domain of @Ord@ holds @(Int, Int)@
and not a pair with a rigid part, and a deeper type takes the node of all
types, as without the recursion.
-}
domainNodes :: Encoding -> Node Symbol -> Map.Map Text (Node Symbol)
domainNodes encoding@(Curried defaulting domains) types = iterate deeper (nodesWith (const types)) !! domainDepth
  where
    deeper previous = nodesWith (\key -> Map.findWithDefault types key previous)
    nodesWith argument = Map.map (nodeOf argument) domains
    nodeOf argument found =
        union $
            [mapNodes (replace argument) (typeNodeWith encoding typ) | typ <- domainTypes found]
                <> domainMarkers defaulting found
    replace argument node
        | isVariable node = types
        | Just key <- higherClass node = argument key
        | otherwise = node
    domainTypes (HeadDomain _ types') = types'
    domainTypes (TypeDomain types') = types'
domainNodes FirstOrder _ = Map.empty

{- | The levels to which 'domainNodes' unrolls a domain that refers to
domains. A domain that refers to itself as a 'Mu' makes the reduction of
some search spaces too large: firstKey at size 3 did not end its reduction
in 30 seconds. A second level costs about 50 MB of allocation in the
reduction of each small query, and on the queries that we measured it
changes no rank.
-}
domainDepth :: Int
domainDepth = 1

{- | The leaves that the domain of a curried variable has beside its types,
so that the intersection of domains in a run tells whether the program
determines the variable, and whether it has a default:

* @?any@ is in every 'TypeDomain', and in the node of all types when the
  encoding has a 'TypeDomain', but not in a type constructor. So a run that
  ties the variable to a type, as @Int@, loses it.
* With 'OnlyDefault', @?@ is in every 'HeadDomain', and in the types of
  kind @* -> *@ of the node of all types ('anyMarkers'), but not in a type
  constructor. So a run that ties the variable to a type constructor, as
  @Maybe@, loses it.
* With 'OnlyDefault', @?nodefault@ is in a 'HeadDomain' without the list as
  its default, and in the types of kind @* -> *@ of the node of all types.
  So a run keeps it when no domain of the intersection has a default.

'narrowHeads' reads them, and drops them, before the enumeration tries the
edges of a node.
-}
domainMarkers :: Defaulting -> Domain -> [Node Symbol]
domainMarkers _ (TypeDomain _) = [anyTypeMarker]
domainMarkers AnyHead (HeadDomain _ _) = []
domainMarkers OnlyDefault (HeadDomain defaults _) = [openMarker] <> [noDefaultMarker | not defaults]

-- | The markers of the types of kind @* -> *@ of the node of all types: both, which an intersection keeps.
anyMarkers :: Defaulting -> [Node Symbol]
anyMarkers AnyHead = []
anyMarkers OnlyDefault = [openMarker, noDefaultMarker]

-- | The leaves of 'domainMarkers'.
openMarker, noDefaultMarker, anyTypeMarker :: Node Symbol
openMarker = Node [Edge (Symbol "?") []]
noDefaultMarker = Node [Edge (Symbol "?nodefault") []]
anyTypeMarker = Node [Edge (Symbol "?any") []]

{- | The edges of a node of a run with markers ('domainMarkers'). A node
without a marker keeps its edges. A node with a marker is the domain of a
variable that the program does not determine. With @?any@, it keeps only
that leaf, so the run lists one typed term. With @?@, it keeps the list
type when it has no @?nodefault@, and no edge when it has.
-}
narrowHeads :: [Edge Symbol] -> [Edge Symbol]
narrowHeads edges
    | any (leaf "?any") edges = filter (leaf "?any") edges
    | not (any (leaf "?") edges) = edges
    | any (leaf "?nodefault") edges = []
    | otherwise = filter (leaf "List") edges
  where
    leaf name (Edge (Symbol symbol) []) = symbol == name
    leaf _ _ = False

-- | The application of a function term to an argument term.
application :: Node Symbol -> Node Symbol -> Node Symbol -> Node Symbol
application types function argument =
    Node
        [ mkEdge
            "app"
            [types, arrowMarker, function, argument]
            ( equalityConstraint $
                mkEqConstraints
                    [ [path [1], path [2, 0, 0]]
                    , [path [3, 0], path [2, 0, 1]]
                    , [path [0], path [2, 0, 2]]
                    ]
            )
        ]

-- | Keep the terms of a node whose type child equals the goal type.
ofType :: Node Symbol -> Node Symbol -> Node Symbol
ofType candidates goal =
    Node [mkEdge "filter" [goal, candidates] (equalityConstraint $ mkEqConstraints [[path [0], path [1, 0]]])]

{- | Propagate the constraints and remove the redundant edges until nothing
changes, for at most 'reductionRounds' rounds, as the paper does. At some
sizes the rounds do not converge: on takeNdropM at size 7 the automaton
stays near 3,400 nodes, and the enumeration of the bounded result finds the
solution. Reduction does not change the language, so the bound only stops
earlier.
-}
reduceFully :: Node Symbol -> Node Symbol
reduceFully = last . reductions

{- | The spaces of 'reduceFully': the input, and the space after each round,
until a round changes nothing or after 'reductionRounds' rounds.
-}
reductions :: Node Symbol -> [Node Symbol]
reductions = go reductionRounds
  where
    go 0 node = [node]
    go rounds node
        | next == node = [node]
        | otherwise = node : go (rounds - 1) next
      where
        next = withoutRedundantEdges (reducePartially node)

-- | The bound of 'reduceFully' on reduction rounds: 30, as in the paper.
reductionRounds :: Int
reductionRounds = 30

{- | The automaton of the programs of a size that use every argument of the
query once and have the goal type, reduced and refolded. A size counts the
components and arguments of a program.
-}
searchSpace :: Library -> Query -> Int -> Node Symbol
searchSpace lib query = refold . reduceFully . rawSearchSpace lib query

{- | A search space after the reduction, with Hectare's order of its edges
('reduceWithOrder').
-}
data Space = Space
    { spaceNode :: !(Node Symbol)
    -- ^ The automaton, reduced and refolded.
    , spaceOrder :: !(Edge Symbol -> Double)
    -- ^ The weights of 'runsBy': an edge from an earlier round of the reduction is heavier.
    }

{- | 'reduceFully' and 'refold', with Hectare's order of the edges: an edge
that is in the space after an earlier round of the reduction comes first,
and the canonical order of 'runsBy' orders the edges of one round. The input
is round 0. An edge of the refolded space has the earliest round of the
edges that refold makes it from. An edge that the enumeration builds, as an
intersection, comes after the edges of the space. The order depends only on
the automata, not on what the process built before, so it is the same in
every process.

On the Hoogle+ and Stack Overflow suites, with 60 seconds for each query,
this order solves the same 53 queries as the order of the edge identities,
which depends on what the process built before, and lists the expected
solutions at 1.07 times their rank in that order (the geometric mean of the
rank plus one). The canonical order alone lists them at 1.32 times that rank,
and solves 51.
-}
reduceWithOrder :: Node Symbol -> Space
reduceWithOrder = orderedSpace . reductions

{- | The last space of a reduction ('reductions'), refolded, with Hectare's
order of its edges ('reduceWithOrder').
-}
orderedSpace :: [Node Symbol] -> Space
orderedSpace spaces = rounds `seq` Space folded order
  where
    (born, final, count) = births spaces
    (folded, refolded) = refoldEdges final
    rounds =
        IntMap.unionWith min born $
            IntMap.fromListWith
                min
                [ (edgeKey (refolded edge), index)
                | edges <- IntMap.elems (reachable final)
                , edge <- edges
                , Just index <- [IntMap.lookup (edgeKey edge) born]
                ]
    order edge = negate (fromIntegral (IntMap.findWithDefault count (edgeKey edge) rounds))

{- | The first round of each edge of the spaces of a reduction, by its
identity, with the last space and the number of spaces. A round reads the
edges that the enumeration reads ('reachable'), and it stops at the nodes of
the rounds before: their edges have a round already.
-}
births :: [Node Symbol] -> (IntMap.IntMap Int, Node Symbol, Int)
births = go 0 IntSet.empty IntMap.empty
  where
    go _ _ _ [] = error "births: no space"
    go index seen born (space : rest) = case rest of
        [] -> (born', space, index + 1)
        _ -> go (index + 1) seen' born' rest
      where
        (seen', born') = visit index seen born [space]
    -- The nodes that a round reaches and the rounds before did not.
    visit _ !seen !born [] = (seen, born)
    visit index !seen !born (EmptyNode : pending) = visit index seen born pending
    visit index !seen !born (node : pending)
        | IntSet.member ident seen = visit index seen born pending
        | otherwise =
            visit
                index
                (IntSet.insert ident seen)
                (foldl' (\table edge -> IntMap.insertWith (\_ old -> old) (edgeKey edge) index table) born edges)
                (concatMap edgeChildren edges <> pending)
      where
        NodeId ident = nodeIdentity node
        edges = nodeEdges node

-- | The identity of an edge as a key of a table.
edgeKey :: Edge Symbol -> Int
edgeKey edge = let EdgeId identity = edgeIdentity edge in identity

-- | 'searchSpace', with Hectare's order of its edges.
orderedSearchSpace :: Library -> Query -> Int -> Space
orderedSearchSpace lib query = reduceWithOrder . rawSearchSpace lib query

-- | The automaton of 'searchSpace' before the reduction.
rawSearchSpace :: Library -> Query -> Int -> Node Symbol
rawSearchSpace lib query size = ofType (relevantOfSize size) (typeNodeWith encoding $ queryGoal query)
  where
    encoding = libraryEncoding lib
    types = typesOf lib query
    nodes = domainNodes encoding types
    component name typ = Edge (Symbol name) [generalizeWith encoding nodes types (typeNodeWith encoding typ)]
    components = [(name, component name typ) | (name, typ, _) <- libraryGroups lib]
    anyFunction = Node (map snd components)
    argumentOnly = Node [component name typ | (name, typ) <- libraryArgumentOnly lib]
    argumentEdges = [(name, Edge (Symbol name) [typeNodeWith encoding typ]) | (name, typ) <- queryArguments query]
    anyArgument = Node (map snd argumentEdges)
    without names = Node [edge | (name, edge) <- components, name `notElem` names]
    restricted = concatMap fst (libraryAvoid lib)

    -- The terms of a size that use no argument in particular; the flag
    -- admits the components that only appear as an argument. The table
    -- builds the terms of each flag and size once.
    termsOfSize :: Bool -> Int -> [Node Symbol]
    termsOfSize asArgument size' = termsTable Map.! (asArgument, size')
    termsTable =
        LazyMap.fromList
            [((asArgument, size'), buildTerms asArgument size') | asArgument <- [False, True], size' <- [0 .. size]]
    buildTerms _ 0 = []
    buildTerms asArgument 1 = [anyArgument, anyFunction] <> [argumentOnly | asArgument]
    buildTerms _ 2 =
        [ application
            types
            (Node [edge | (name, edge) <- components, name `elem` functions])
            (union [without arguments, anyArgument, argumentOnly])
        | (functions, Just arguments) <- libraryAvoid lib
        ]
            <> [application types (union [without restricted, anyArgument]) (union $ termsOfSize True 1)]
    buildTerms _ size' =
        [ application types (union $ termsOfSize False left) (union $ termsOfSize True (size' - left))
        | left <- [1 .. size' - 1]
        ]

    -- The terms of a size that use each of the arguments once. The
    -- arguments are an ordered selection of the query's arguments, and the
    -- table builds the terms of each flag, size, and selection once.
    relevant :: Bool -> Int -> [(Text, Edge Symbol)] -> [Node Symbol]
    relevant asArgument size' arguments = relevantTable Map.! (asArgument, size', map fst arguments)
    relevantTable =
        LazyMap.fromList
            [ ((asArgument, size', map fst arguments), buildRelevant asArgument size' arguments)
            | asArgument <- [False, True]
            , size' <- [0 .. size]
            , arguments <- concatMap permutations (subsequences argumentEdges)
            ]
    buildRelevant asArgument size' [] = termsOfSize asArgument size'
    buildRelevant _ 1 [(_, edge)] = [Node [edge]]
    buildRelevant _ size' arguments
        | size' < length arguments = []
        | otherwise =
            [ application types (union $ relevant False left used) (union $ relevant True (size' - left) rest)
            | left <- [1 .. size' - 1]
            , (used, rest) <- map (`splitAt` arguments) [0 .. length arguments]
            ]

    relevantOfSize size' = union $ concatMap (relevant True size') (permutations argumentEdges)

-- | The node of all types of a library and a query.
typesOf :: Library -> Query -> Node Symbol
typesOf lib query = case libraryEncoding lib of
    FirstOrder -> allTypes constructors
    Curried defaulting domains -> allCurriedTypes defaulting (any isTypeDomain domains) constructors
  where
    constructors =
        nubOrd $
            concatMap (\(_, typ, _) -> constructorsOf typ) (libraryGroups lib)
                <> concatMap (constructorsOf . snd) (libraryArgumentOnly lib)
                <> concatMap (constructorsOf . snd) (queryArguments query)
                <> constructorsOf (queryGoal query)

{- | How the components of a library form terms in which each head is applied
to all its parameters, by the names of the group representatives.
-}
data Saturation = Saturation
    { saturationArities :: Map.Map Text Int
    -- ^ The heads, with the number of their parameters.
    , saturationValues :: [Text]
    -- ^ The components that can be an argument without arguments of their own.
    }
    deriving (Eq, Show)

{- | The automaton of the saturated programs of a size that use every argument
of the query and have the goal type. A head is applied to all its
parameters, and an argument is a query argument, a value, or such an
application, so no partial application is an argument. A size counts the
components and arguments of a program, as in 'rawSearchSpace'. The library's
argument-only components and pruning rules play no part.
-}
rawSaturatedSearchSpace :: Saturation -> Library -> Query -> Int -> Node Symbol
rawSaturatedSearchSpace saturation lib query size =
    ofType
        (union [node | arguments <- permutations argumentEdges, node <- complete size arguments])
        (typeNode $ queryGoal query)
  where
    types = typesOf lib query
    component name typ = Edge (Symbol name) [generalize types (typeNode typ)]
    headsWith parameters =
        Node
            [ component name typ
            | (name, typ, _) <- libraryGroups lib
            , Map.lookup name (saturationArities saturation) == Just parameters
            ]
    values = Node [component name typ | (name, typ, _) <- libraryGroups lib, name `elem` saturationValues saturation]
    argumentEdges = [(name, Edge (Symbol name) [typeNode typ]) | (name, typ) <- queryArguments query]
    anyArgument = Node (map snd argumentEdges)
    largestArity = maximum (1 : Map.elems (saturationArities saturation))
    selections = concatMap permutations (subsequences argumentEdges)

    -- The complete terms of a size that use each argument of a selection
    -- once, and the heads of a size with some parameters left, applied to
    -- the arguments before them. The tables build each once.
    complete :: Int -> [(Text, Edge Symbol)] -> [Node Symbol]
    complete size' arguments = completeTable Map.! (size', map fst arguments)
    partial :: Int -> Int -> [(Text, Edge Symbol)] -> [Node Symbol]
    partial size' left arguments = partialTable Map.! (size', left, map fst arguments)
    completeTable =
        LazyMap.fromList
            [((size', map fst arguments), buildComplete size' arguments) | size' <- [0 .. size], arguments <- selections]
    partialTable =
        LazyMap.fromList
            [ ((size', left, map fst arguments), buildPartial size' left arguments)
            | size' <- [0 .. size]
            , left <- [1 .. largestArity]
            , arguments <- selections
            ]
    buildComplete 0 _ = []
    buildComplete 1 [] = [anyArgument, values]
    buildComplete 1 [(_, edge)] = [Node [edge]]
    buildComplete size' arguments
        | size' < length arguments = []
        | otherwise = applied size' 1 arguments
    buildPartial 0 _ _ = []
    buildPartial 1 left [] = [headsWith left]
    buildPartial 1 _ _ = []
    buildPartial size' left arguments = applied size' (left + 1) arguments
    -- A head with so many parameters left, applied to one more argument.
    applied size' left arguments =
        [ application types (union $ partial functionSize left used) (union $ complete (size' - functionSize) rest)
        | left <= largestArity
        , functionSize <- [1 .. size' - 1]
        , (used, rest) <- map (`splitAt` arguments) [0 .. length arguments]
        ]

{- | The programs of a size in the saturated search space that solve the
query, each once, in Hectare's order ('reduceWithOrder'), as
'distinctSolutionsOfSize' gives them for 'rawSearchSpace'.
-}
distinctSaturatedSolutionsOfSize :: Saturation -> Library -> Query -> Int -> [Program]
distinctSaturatedSolutionsOfSize saturation lib query =
    distinctProgramsIn . reduceWithOrder . rawSaturatedSearchSpace saturation lib query

{- | The programs of a search space, each once, in Hectare's order: the order
in which 'programsIn' first lists them. 'programsIn' keeps a set of the
typed terms, and a program can have many; this keeps a set of the programs
only.
-}
distinctProgramsIn :: Space -> [Program]
distinctProgramsIn = catMaybes . programRuns FirstOrder

{- | The runs of a search space in Hectare's order, one for each typed term,
each with its program when no run before it has that program. So the
programs are those of 'distinctProgramsIn', and the length is the number of
typed terms that the enumeration lists. A typed term can repeat, as in
'runs'. With markers ('domainMarkers'), the runs are narrowed by
'narrowHeads'.
-}
programRuns :: Encoding -> Space -> [Maybe Program]
programRuns encoding space = go Set.empty $ map (toProgram . fst) $ listRuns "Mu" (spaceNode space)
  where
    listRuns = case encoding of
        Curried OnlyDefault _ -> runsNarrowedBy (spaceOrder space) narrowHeads
        Curried AnyHead domains | any isTypeDomain domains -> runsNarrowedBy (spaceOrder space) narrowHeads
        _ -> runsBy (spaceOrder space)
    go _ [] = []
    go seen (program : rest)
        | Set.member program seen = Nothing : go seen rest
        | otherwise = Just program : go (Set.insert program seen) rest

-- | The programs of a term of the search space: the types go.
toProgram :: Term Symbol -> Program
toProgram term = case (Term.rootLabel term, Term.subForest term) of
    ("app", children@(_ : _ : _)) -> App (toProgram $ children !! (length children - 2)) (toProgram $ last children)
    ("filter", children@(_ : _)) -> toProgram $ last children
    (symbol, _) -> Var (symbolText symbol)

-- | The programs of a search space, one for each typed term, in Hectare's order.
programsIn :: Space -> [Program]
programsIn space = map toProgram $ nubOrd $ map fst $ runsBy (spaceOrder space) "Mu" (spaceNode space)

-- | The programs of a size that solve the query, with representatives.
solutionsOfSize :: Library -> Query -> Int -> [Program]
solutionsOfSize lib query = programsIn . orderedSearchSpace lib query

{- | The programs of a size that solve the query, each once, in the order in
which 'solutionsOfSize' first lists them. 'solutionsOfSize' keeps a set of
the typed terms, and a large size has millions of them; this lists the runs
of the search space and keeps a set of the programs only, which needs much
less memory.
-}
distinctSolutionsOfSize :: Library -> Query -> Int -> [Program]
distinctSolutionsOfSize lib query = distinctProgramsIn . orderedSearchSpace lib query

-- | The programs up to a size that solve the query, smallest first.
synthesize :: Library -> Query -> Int -> [Program]
synthesize lib query bound = concatMap (solutionsOfSize lib query) [1 .. bound]

{- | The programs of a size that solve the query, as a generator: an exact
count, a rank for each typed program, sampling, and shrinking. Two typed
terms with the same program are two ranks.

The import counts a recursive automaton only when no edge has a constraint.
A type variable can take any type, so the search space of a polymorphic
query keeps the recursive node of all types under constrained edges, and the
generator gives 'Data.CFTA.Gen.Error.CannotCountConstrainedEdges'. Then use
'programsOfSizeUpToDepth'.
-}
programsOfSize :: Library -> Query -> Int -> ECTAGen Program
programsOfSize lib query size = toProgram <$> ECTAGen.fromAutomaton (searchSpace lib query size)

{- | The programs of a size whose typed terms have at most a depth, as a
generator. The depth bounds the types that the type variables take, so the
count is exact for that bound.
-}
programsOfSizeUpToDepth :: Depth -> Library -> Query -> Int -> ECTAGen Program
programsOfSizeUpToDepth depth lib query size = toProgram <$> ECTAGen.fromAutomatonUpToDepth depth (searchSpace lib query size)
