{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TupleSections #-}

{- | Compile a refinement generator with a solver, and check candidates explicitly.

'compile' folds the recipe of a generator whose constructors carry guards.
Each child language is grouped by the finite observations its parent guard
reads: the label at the child's root, and at deeper requested paths. The
solver decides a guard once per tuple of child groups, the accepted tuples
become one join per constructor, and an imported automaton is pruned and
split by the same observations without enumerating its terms. The result is
an ordinary generator of the engine. It is finite, or recursive for a
recursive import. 'validOutcomes' is the oracle: it enumerates every
candidate and checks each complete witness.
-}
module Data.CFTA.Gen.Refinement.Internal.Compile (
    compile,
    validOutcomes,
    reportTimeLimit,
    spineArity,
    isIntegerName,
    namedTerms,
) where

import Control.Applicative ((<|>))
import Control.Exception (handle)
import Data.Bifunctor (first)
import Data.Containers.ListUtils (nubOrd)
import Data.Either (fromLeft)
import Data.Foldable (toList)
import Data.IORef (IORef, modifyIORef', newIORef, readIORef)
import qualified Data.IntMap.Strict as IntMap
import Data.List (isPrefixOf, mapAccumL, sortOn, (!?))
import qualified Data.Map.Strict as Map
import Data.Maybe (catMaybes, fromMaybe, isNothing)
import Data.Ratio (denominator, numerator)
import qualified Data.Sequence as Sequence
import Data.Set (Set)
import qualified Data.Set as Set
import Data.String (fromString)
import qualified Data.Text as Text
import System.Mem.StableName (StableName, eqStableName, hashStableName, makeStableName)
import Unsafe.Coerce (unsafeCoerce)

import qualified Data.CFTA as FTA (fromTerms, mixedArity)
import Data.CFTA.Equality.Constraint (EqConstraints (EmptyConstraints))
import qualified Data.CFTA.Formula as Formula
import Data.CFTA.Gen
import Data.CFTA.Gen.Internal.Bucket (
    KeyedBucket (..),
    MassIndex (..),
    mergeComponentsByKey,
    pairMassIndex,
    payMassIndex,
 )
import qualified Data.CFTA.Gen.Internal.Flat as Flat
import Data.CFTA.Gen.Internal.Grouped (groupKeys)
import Data.CFTA.Gen.Internal.Static (
    Outcome (outcomeMass),
    OutcomeIndex (outcomeSelect, outcomeSizeIndex),
    RootCount (..),
    Static (staticAtomic, staticOutcomes, staticRootCount),
    addRootCounts,
    atomicStatic,
    commonRootCount,
    holeStatic,
    labelStaticMatching,
    mapStatic,
    pointsStatic,
    resizedStatic,
    staticSampling,
 )
import Data.CFTA.Gen.Internal.Types (Gen (..), Grouped (..), Language (..), Recipe (..), payGrouped)
import Data.CFTA.Gen.Label (ChoiceIndex)
import Data.CFTA.Gen.Refinement.Internal.Witness
import Data.CFTA.Index (
    Arity (..),
    Cardinality (..),
    Depth (..),
    Rank (..),
    VarIndex (..),
    Weight (..),
    childIndexes,
    countWeight,
    everyRank,
 )
import Data.CFTA.Ranked.Internal.Size (minimumMemberSize)
import Data.CFTA.Refinement
import Data.CFTA.Refinement.Expression (
    definingTerm,
    freeNames,
    literal,
    refinementFormula,
    substitute,
    true,
    variable,
    (.&&),
    (.==),
 )
import Data.CFTA.Refinement.Lattice (
    LatticeError (UnboundedVariable),
    Points,
    onlyPoint,
    pointAt,
    pointCount,
    pointRank,
    points,
 )
import Data.CFTA.Refinement.LiquidFixpoint (TimeLimitReached (..))
import Data.CFTA.Symbol (valueName)
import Data.CFTA.Term (Term)
import qualified Data.CFTA.Term as Term

-- | A generator over liquid tree automata.
type LTAGen = Gen Symbol

-- | A grouped generator over liquid tree automata.
type LTAGrouped key = Grouped Symbol key

{- | The observations that identify one group: the label at each observed
path, and whether that node is a leaf. A path that a member does not have is
absent. The position orders the groups of one language by the first member
that has their observations, so ranks follow source order.
-}
data ObservationKey = ObservationKey
    { keyPosition :: !Int
    , keyObservations :: !Observations
    }
    deriving (Eq, Ord, Show)

-- | The key of a group that nothing observes.
noObservations :: ObservationKey
noObservations = ObservationKey 0 Map.empty

{- | Regroup by observations, positioned by first appearance.

The keys of the given groups are in source order. Groups with the same
observations merge, and the merged group takes the position of the first.
-}
reposition :: (key -> Observations) -> LTAGrouped key a -> LTAGrouped ObservationKey a
reposition observationsOf grouped = regroupOn rekey grouped
  where
    positions = firstPositions $ map observationsOf $ groupKeys grouped
    rekey key = ObservationKey (positions Map.! observationsOf key) (observationsOf key)

-- | The index of the first appearance of each identity.
firstPositions :: (Ord identity) => [identity] -> Map.Map identity Int
firstPositions identities = Map.fromListWith (\_ earlier -> earlier) $ zip identities [0 ..]

-- | An open key at a new position.
atPosition :: Int -> OpenKey -> OpenKey
atPosition position key = key{openObservations = (openObservations key){keyPosition = position}}

-- | The number of child positions in an applicative spine.
spineArity :: Gen symbol a -> Arity
spineArity = Arity . length . spineRootCounts

-- TODO: Consider positions that look through a choice whose alternatives all
-- give the same number of children, so that a guard can read the children of
-- a choice of products such as @oneof [pair1, pair2]@. That changes
-- 'spineArity', the observations, and 'candidatesOf'. A built child that gives
-- several terms, such as a join, or no term, such as 'fromIndexed', has the
-- same problem, and 'alignedSpine' refuses it in the same way.

{- | Whether each part of an applicative spine gives its constructor one
child, as 'spineArity' counts it. 'rootCount' gives the number of children of
each part. When a part gives another number, a guard that reads the children
by position reads the wrong ones.
-}
alignedSpine :: Gen symbol a -> Bool
alignedSpine = all (== RootCount 1) . spineRootCounts

-- | The 'rootCount' of each position of an applicative spine, as 'spineArity' counts the positions.
spineRootCounts :: Gen symbol a -> [RootCount]
spineRootCounts generator = case genRecipe generator of
    Lifted _ -> []
    Mapped _ inner -> spineRootCounts inner
    Paid inner -> spineRootCounts inner
    Applied functions arguments -> spineRootCounts functions <> spineRootCounts arguments
    _ -> [rootCount generator]

{- | The number of children that each member of a generator gives its
constructor, when all members give the same number. The children are the
roots that 'surface' gives for the term of the member, and 'validOutcomes'
reads the same children.

A constructor, an import, and an integer leaf give one child, and @pure@
gives none. A choice removes its own wrapper, so a choice of products gives
several children, and a choice of @pure@ values gives none. A built language
gives the number that its members give, which 'staticRootCount' keeps: a
source without symbols, such as 'fromIndexed' and the pools of @freeze@ and
@samplePool@, gives none, and a join gives one for each side. A language
without members, or a language that failed to build, gives one, so that the
guard does not report the failure first. The result is 'NoCommonCount' when
two members give different numbers, and for a recursive or opaque built
language, whose number is not known.
-}
rootCount :: Gen symbol a -> RootCount
rootCount generator = case genRecipe generator of
    Lifted _ -> RootCount 0
    Mapped _ inner -> rootCount inner
    Paid inner -> rootCount inner
    Applied functions arguments -> addRootCounts (rootCount functions) (rootCount arguments)
    Chosen alternatives -> commonRootCount $ map (rootCount . snd) alternatives
    Uniform alternatives -> commonRootCount $ map rootCount alternatives
    Closed{} -> RootCount 1
    ClosedBy{} -> RootCount 1
    Imported{} -> RootCount 1
    Integers _ -> RootCount 1
    Built -> case genLanguage generator of
        TransparentLanguage (Right static) -> staticRootCount static
        TransparentLanguage (Left _) -> RootCount 1
        CyclicLanguage (Left _) -> RootCount 1
        _ -> NoCommonCount

{- | What one compilation shares: the cached solver, the groups compiled so
far, and which generators contain integer leaves.
-}
data Compiler = Compiler
    { compilerEntailment :: !Entailment
    , compilerClosed :: !(Memo ClosedGroups)
    , compilerOpen :: !(Memo OpenGroups)
    , compilerIntegers :: !(Memo Contains)
    }

-- | The groups of a generator that leaves no variable open.
newtype ClosedGroups a = ClosedGroups (Either GenError (LTAGrouped ObservationKey a))

-- | The groups of a generator whose members can leave integer variables open.
newtype OpenGroups a = OpenGroups (Either GenError (LTAGrouped OpenKey ([Integer] -> a)))

-- | Whether a generator contains an integer leaf.
newtype Contains a = Contains Bool

-- | Results by the stable name of a generator and the paths requested of it.
type Memo f = IORef (IntMap.IntMap [Entry f])

{- | One result for one generator. A stable name identifies one heap object,
so the result has the type of that object.
-}
data Entry f = forall a. Entry !(StableName (LTAGen a)) !(Set Path) (f a)

-- | The recorded result for a generator and requested paths, or the computed one, recorded.
memoized :: Memo f -> Set Path -> LTAGen a -> IO (f a) -> IO (f a)
memoized memo requested generator compute = do
    name <- makeStableName $! generator
    known <- readIORef memo
    case [ unsafeCoerce result
         | Entry other paths result <- IntMap.findWithDefault [] (hashStableName name) known
         , eqStableName name other
         , paths == requested
         ] of
        result : _ -> pure result
        [] -> do
            result <- compute
            modifyIORef' memo $ IntMap.insertWith (<>) (hashStableName name) [Entry name requested result]
            pure result

-- | Whether a generator waits for 'compile'.
deferred :: Gen symbol a -> Bool
deferred generator = case genLanguage generator of
    TransparentLanguage (Left SourceRequiresCompilation) -> True
    _ -> False

{- | Compile a generator whose guards need the solver.

A generator that the engine built at construction is returned unchanged. All
solver work finishes here, so the result samples, replays, and shrinks
without the solver. A guard the compiler cannot decide from its observations,
a solver that cannot decide a guard, a solver query that reaches its time
limit, and a guard the symbolic counter cannot count are compile failures; an
empty language is not.
-}
compile :: Entailment -> LTAGen a -> IO (Either GenError (LTAGen a))
compile uncachedEntailment generator
    | not (deferred generator) = pure $ Right generator
    | otherwise = reportTimeLimit $ do
        entailment <- cacheEntailment uncachedEntailment
        closedMemo <- newIORef IntMap.empty
        openMemo <- newIORef IntMap.empty
        integersMemo <- newIORef IntMap.empty
        fmap ungroup <$> compileGen (Compiler entailment closedMemo openMemo integersMemo) (Set.singleton $ path []) generator

-- | Compile one generator, grouped by the observations its parent needs.
compileGen :: Compiler -> Set Path -> LTAGen a -> IO (Either GenError (LTAGrouped ObservationKey a))
compileGen compiler requested generator =
    fmap (\(ClosedGroups groups) -> groups) $
        memoized (compilerClosed compiler) requested generator $
            ClosedGroups <$> do
                open <- containsIntegers compiler generator
                if open
                    then (>>= closeOpen) <$> compileOpen compiler requested generator
                    else compileGenOnce compiler requested generator

-- | Compile one generator that the memo does not hold.
compileGenOnce :: Compiler -> Set Path -> LTAGen a -> IO (Either GenError (LTAGrouped ObservationKey a))
compileGenOnce compiler requested generator
    | not (deferred generator) && null requested = pure $ Right $ keyed noObservations generator
    | otherwise = case genRecipe generator of
        Built -> pure $ groupBuilt requested generator
        Lifted value -> pure $ Right $ keyed noObservations $ pure value
        Mapped transform inner -> fmap (mapWithKey (const transform)) <$> compileGen compiler requested inner
        Paid inner -> fmap payGrouped <$> compileGen compiler requested inner
        Applied _ _
            -- A product whose one term comes from one part answers the
            -- requested paths of that part. Another product observes nothing.
            | Just position <- oneTermPart requested generator ->
                fmap (regroupOn (!! position))
                    <$> compileSpine compiler (partRequirements position requested generator) generator
            | otherwise ->
                fmap (regroupOn (const noObservations))
                    <$> compileSpine compiler (replicate (fromEnum $ spineArity generator) Set.empty) generator
        Chosen alternatives -> do
            compiled <- traverse (compileGen compiler requested . snd) alternatives
            pure $ choose (map fst alternatives) <$> sequence compiled
        Uniform alternatives -> do
            compiled <- traverse (compileGen compiler requested) alternatives
            pure $ (\groups -> choose (uniformWeights groups) groups) <$> sequence compiled
        Closed symbol constraint child -> compileNode compiler requested (FixedLabel symbol) constraint child
        ClosedBy symbolOf constraint child -> compileNode compiler requested (ComputedLabel symbolOf) constraint child
        Imported bound order automaton -> compileImport (compilerEntailment compiler) requested bound order automaton
        Integers _ ->
            error
                "cfta-generator bug in Data.CFTA.Gen.Refinement.Internal.Compile.compileGenOnce: \
                \an integer leaf reached it, but compileGen sends such a leaf to compileOpen"
  where
    -- A choice of the compiled alternatives, with one weight for each.
    choose weights groups = reposition (keyObservations . snd) $ chooseGroups $ zip weights groups
    -- The weights of 'uniformly': each finite alternative weighs its members,
    -- and a recursive alternative makes the choice equal.
    uniformWeights groups
        | any recursiveGroup groups = map (const 1) groups
        | otherwise = map (either (const 1) (countWeight . sum) . cardinalities) groups

{- | A choice of compiled alternatives, each group keyed by its choice index. An
empty alternative is left out.
-}
chooseGroups :: (Ord key) => [(Weight, LTAGrouped key a)] -> LTAGrouped (ChoiceIndex, key) a
chooseGroups weighted =
    frequencies
        [ (weight, regroupOn (index,) grouped)
        | (index :: ChoiceIndex, (weight, grouped)) <- zip [0 ..] weighted
        , not $ emptyGroups grouped
        ]

-- | The leaf of one integer, refined as itself.
integerSymbol :: Integer -> Symbol
integerSymbol value = RefinedSymbol (fromString $ show value) $ refinementFormula (.== literal value)

-- | The conjunction of the conditions on an integer leaf.
integerDomain :: Constraint -> Formula
integerDomain constraint = foldr (.&&) true $ conditions $ constraintAsGuard constraint
  where
    conditions Top = []
    conditions (And guards) = concatMap conditions guards
    conditions (Satisfies target formula) | target == path [] = [formula]
    conditions guard =
        error $
            "cfta-generator bug in Data.CFTA.Gen.Refinement.Internal.Compile.integerDomain: \
            \an integer leaf carries the guard "
                <> show guard

-- | Whether a grouped generator is a recursive family.
recursiveGroup :: LTAGrouped key a -> Bool
recursiveGroup (CyclicGrouped _) = True
recursiveGroup _ = False

-- | Whether a grouped generator has no member.
emptyGroups :: LTAGrouped key a -> Bool
emptyGroups grouped = case cardinalities grouped of
    Left EmptyGenerator -> True
    Right groups -> all (== 0) groups
    Left _ -> False

{- | Group a language the engine built by the requested observations.

Without observations the language is one group, and so is a language whose
members have no root, such as 'fromIndexed'. With observations every member
is read back with its term; a member's term is the user's part of the
engine's labelled term. A member keeps its mass, its size, and its weight
inside its size class. The groups carry these weights to the merges that join
them again, so a guard that reads the language keeps its distribution inside a
size class. The pairs of the children of a node keep them too, and so do the
groups that close their integer points.
-}
groupBuilt :: Set Path -> LTAGen a -> Either GenError (LTAGrouped ObservationKey a)
groupBuilt requested generator
    | deferred generator = Left SourceRequiresCompilation
    | null requested = Right $ keyed noObservations generator
    -- A member without a root has no observation, so all members form one group.
    | rootCount generator == RootCount 0 = Right $ keyed noObservations generator
    | Left EmptyGenerator <- cardinality generator = Right $ frequencies []
    | otherwise = do
        total <- cardinality generator
        members <- traverse member $ everyRank total
        let scale = foldr (\(mass, _, _, _) -> lcm (denominator mass)) 1 members
        pure
            $ reposition keyObservations
            $ frequencies
                [ ( Weight $ numerator (mass * fromInteger scale)
                  , keyedMember rank size (ObservationKey rank $ observe forest) (rebuild size forest value)
                  )
                | (rank, (mass, size, value, forest)) <- zip [0 ..] members
                ]
  where
    -- Each member keeps its own mass and its own size, so an 'atomic' choice
    -- keeps its distribution and every member keeps its size class.
    member rank =
        (,,,)
            <$> massAt rank
            <*> pure (sizeOfRank generator rank)
            <*> unrank generator rank
            <*> (surface <$> termAt generator rank)
    massAt rank = case genLanguage generator of
        TransparentLanguage result -> do
            static <- result
            outcomeMass <$> outcomeSelect (staticOutcomes static) rank
        _ -> Left UnboundedGenerator
    observe [term] = Map.fromList [(target, observation) | target <- Set.toList requested, Just observation <- [labelAt target term]]
    observe _ = Map.empty
    -- A rebuilt term counts the source choices of its own nodes, which need not
    -- be the choices that made the member, so the member takes its own size. A
    -- member of an atomic source is rebuilt atomic: inside a size class, a
    -- choice weighs an atomic member by its mass and other members by count.
    rebuild size forest value = keepSize size $ case forest of
        [Term.Node label children] -> node label $ withChildren children value
        _ -> withChildren forest value
    keepSize size rebuilt = case (size, genLanguage rebuilt) of
        (Just original, TransparentLanguage result) ->
            Gen Built $ TransparentLanguage $ resizedStatic original . (if atomicSource then atomicStatic else id) <$> result
        _ -> rebuilt
    atomicSource = case genLanguage generator of
        TransparentLanguage (Right static) -> staticAtomic static
        _ -> False
    -- A member keeps its weight inside its size class in the source, so the
    -- merges of the groups keep the source's distribution inside a size class.
    -- A later product is not atomic, so atomic members also need this weight.
    keyedMember rank size key rebuilt = case (sourceWeight, size, genLanguage rebuilt) of
        (Just weightOf, Just memberSize, TransparentLanguage result) ->
            Grouped $ do
                static <- result
                weight <- weightOf $ toEnum rank
                pure $ Map.singleton key $ KeyedBucket 1 static $ Just $ MassIndex [(memberSize, weight)]
        _ -> keyed key rebuilt
    sourceWeight = case genLanguage generator of
        TransparentLanguage (Right static) -> snd $ staticSampling static
        _ -> Nothing

    -- The label at one path of a term, and whether it is a leaf.
    labelAt :: Path -> Term Symbol -> Maybe Observed
    labelAt target = go (unPath target)
      where
        go [] (Term.Node label children) = Just $ Observed label $ leafnessOf children
        go (ChildIndex index : rest) term = go rest =<< Term.child index term

-- | A generator of one value whose term has the given children.
withChildren :: [Term Symbol] -> a -> LTAGen a
withChildren children value = foldl (\prefix child -> prefix <* rebuild child) (pure value) children
  where
    rebuild (Term.Node label grandchildren) = node label $ withChildren grandchildren ()

{- | Compile a child description as one group per tuple of child observations.

Each position of the applicative spine is compiled with the observations its
parent requests at that position, and the positions are joined left to
right. An empty position empties the product without compiling the rest.
-}
compileSpine :: Compiler -> [Set Path] -> LTAGen a -> IO (Either GenError (LTAGrouped [ObservationKey] a))
compileSpine compiler requirements generator = case genRecipe generator of
    Lifted value -> pure $ Right $ keyed [] $ pure value
    Mapped transform inner -> fmap (mapWithKey (const transform)) <$> compileSpine compiler requirements inner
    Paid inner -> fmap payGrouped <$> compileSpine compiler requirements inner
    Applied functions arguments -> do
        let (functionRequirements, argumentRequirements) = splitAt (fromEnum $ spineArity functions) requirements
        compiledFunctions <- compileSpine compiler functionRequirements functions
        case compiledFunctions of
            Left err -> pure $ Left err
            Right functionGroups
                | emptyGroups functionGroups -> pure $ Right $ frequencies []
                | otherwise -> do
                    compiledArguments <- compileSpine compiler argumentRequirements arguments
                    case compiledArguments of
                        Left err -> pure $ Left err
                        Right argumentGroups -> do
                            related <- relateGroupsM (\_ _ -> pure $ Right True) (<>) functionGroups argumentGroups
                            pure $ mapWithKey (\_ (function, argument) -> function argument) <$> related
    _ -> fmap (regroupOn pure) <$> compileGen compiler (Set.unions $ take 1 requirements) generator

{- | How a constructor gets its label: a fixed label, or a label that a
function computes from the root labels of the children.
-}
data Labelling
    = FixedLabel !Symbol
    | ComputedLabel ([Symbol] -> Either GenError Symbol)

{- | The shape of a constructor over a child description: its arity, its
leafness, the paths that its guard and its parent observe, and the paths that
it requests of each child.
-}
nodeShape :: Set Path -> Labelling -> Constraint -> LTAGen a -> (Arity, Leafness, Set Path, [Set Path])
nodeShape requested labelling constraint child = (arity, leafness, observed, childRequirements)
  where
    arity = spineArity child
    -- The term of the constructor is a leaf when its child description gives no
    -- term. When 'rootCount' gives no number, the leafness is 'Mixed', which an
    -- observer reads as not known.
    leafness = case rootCount child of
        RootCount 0 -> Leaf
        RootCount _ -> Inner
        NoCommonCount -> Mixed
    observed = Set.unions [requested, constraintPaths constraint, roots]
      where
        roots = case labelling of
            FixedLabel _ -> Set.empty
            ComputedLabel _ -> Set.fromList [path [index] | index <- childIndexes arity]
    childRequirements =
        [ Set.fromList [path suffix | target <- Set.toList observed, index : suffix <- [unPath target], index == childIndex]
        | childIndex <- childIndexes arity
        ]

{- | Compile one guarded constructor.

The children are grouped by the paths the guard reads below each position,
by what the parent requests, and by their roots when the constructor's label
depends on them. The solver decides the guard once per tuple of child
groups; the accepted tuples are closed with the constructor and regrouped by
the parent's observations.
-}
compileNode ::
    Compiler ->
    Set Path ->
    Labelling ->
    Constraint ->
    LTAGen a ->
    IO (Either GenError (LTAGrouped ObservationKey a))
compileNode compiler requested labelling constraint child
    | not (all null childRequirements) && not (alignedSpine child) = pure $ Left ChildNotOneTerm
    | otherwise = do
        compiledChild <- compileSpine compiler childRequirements child
        case compiledChild of
            Left err -> pure $ Left err
            Right childGroups -> do
                retained <- filterGroupsM decide childGroups
                pure $ reposition closeObservations . nodeWithKey closeLabel <$> retained
  where
    (_, leafness, _, childRequirements) = nodeShape requested labelling constraint child
    labelOf childKeys = case labelling of
        FixedLabel label -> Right label
        ComputedLabel symbolOf -> traverse rootOf childKeys >>= symbolOf
    -- The root label retained by a group, which a computed label needs.
    rootOf :: ObservationKey -> Either GenError Symbol
    rootOf key =
        maybe (Left MissingRootObservation) (\(Observed label _) -> Right label) $ Map.lookup (path []) $ keyObservations key
    decide childKeys = case labelOf childKeys of
        Left err -> pure $ Left err
        Right label -> constraintDecision (compilerEntailment compiler) label leafness constraint childKeys
    -- Only accepted tuples are closed, and their labels were computed to accept them.
    closeLabel childKeys = case labelOf childKeys of
        Right label -> label
        Left _ ->
            error
                "cfta-generator bug in Data.CFTA.Gen.Refinement.Internal.Compile.compileNode: \
                \an accepted group lost its root observation"
    closeObservations childKeys = parentObservations requested (closeLabel childKeys) leafness childKeys

{- | Whether a generator contains an integer leaf outside an imported
automaton. Only such a generator compiles through open groups.
-}
containsIntegers :: Compiler -> LTAGen a -> IO Bool
containsIntegers compiler generator =
    fmap (\(Contains found) -> found) $
        memoized (compilerIntegers compiler) Set.empty generator $
            Contains <$> case genRecipe generator of
                Integers _ -> pure True
                Mapped _ inner -> containsIntegers compiler inner
                Paid inner -> containsIntegers compiler inner
                Applied functions arguments -> (||) <$> containsIntegers compiler functions <*> containsIntegers compiler arguments
                Chosen alternatives -> or <$> traverse (containsIntegers compiler . snd) alternatives
                Uniform alternatives -> or <$> traverse (containsIntegers compiler) alternatives
                Closed _ _ child -> containsIntegers compiler child
                ClosedBy _ _ child -> containsIntegers compiler child
                _ -> pure False

{- | The key of a group whose members can leave integer variables open: what
the parent observes, the number of open variables, the formula over them
that the members satisfy, and the number of its points. The variables are
named by 'integerName', and a root label that names them is a term of them.

The mass of a group is the mass of all its points, as for a group of pools:
one point has the product of the masses of the children, divided by their point
counts, and a constructor multiplies this by the share of the points that it
keeps. A pool group sums the masses of its members in the same unit.
The number of points is 'Nothing' when the conditions of an integer leaf do
not bound it and only a contract does.
-}
data OpenKey = OpenKey
    { openObservations :: !ObservationKey
    , openCount :: !Int
    , openFormula :: !Formula
    , openPoints :: !(Maybe Cardinality)
    }
    deriving (Eq, Ord, Show)

-- | The key of a group that leaves no variable open.
closedKey :: ObservationKey -> OpenKey
closedKey key = OpenKey key 0 true (Just 1)

-- | The name of one open integer variable.
integerName :: VarIndex -> String
integerName index = "__cfta_integer_" <> show index

-- | Whether a name is the name of an open integer variable.
isIntegerName :: String -> Bool
isIntegerName = isPrefixOf "__cfta_integer_"

{- | Compile one generator whose members can leave integer variables open.

A generator without integers compiles with 'compileGen', and its members read
no variable. An integer leaf leaves its one variable open. A constructor joins
the variables of its children, and closes them when its label names none of
them.
-}
compileOpen :: Compiler -> Set Path -> LTAGen a -> IO (Either GenError (LTAGrouped OpenKey ([Integer] -> a)))
compileOpen compiler requested generator =
    fmap (\(OpenGroups groups) -> groups) $
        memoized (compilerOpen compiler) requested generator $
            OpenGroups <$> do
                open <- containsIntegers compiler generator
                if not open
                    then fmap (regroupOn closedKey . mapWithKey (const const)) <$> compileGen compiler requested generator
                    else case genRecipe generator of
                        Integers constraint -> pure $ integerGroup constraint
                        Mapped transform inner -> fmap (mapWithKey (const (transform .))) <$> compileOpen compiler requested inner
                        Paid inner -> fmap payGrouped <$> compileOpen compiler requested inner
                        Applied _ _
                            -- As in 'compileGenOnce', a product whose one term comes from
                            -- one part answers the requested paths of that part.
                            | Just position <- oneTermPart requested generator ->
                                fmap (regroupOn $ \keys -> (joinOpenKeys keys){openObservations = openObservations (keys !! position)})
                                    <$> compileOpenSpine compiler (partRequirements position requested generator) generator
                            | otherwise ->
                                fmap joinPositioned <$> compileOpenSpine compiler (replicate (fromEnum $ spineArity generator) Set.empty) generator
                        Chosen alternatives -> do
                            compiled <-
                                traverse (\(weight, alternative) -> fmap (weight,) <$> compileOpen compiler requested alternative) alternatives
                            pure $ do
                                weighted <- sequence compiled
                                -- A choice weighs the mass of each alternative, which an unbounded leaf does not have.
                                case [key | (_, grouped) <- weighted, not $ emptyGroups grouped, key <- openKeys grouped] of
                                    keys
                                        | length (filter (not . emptyGroups . snd) weighted) > 1
                                        , key : _ <- filter (isNothing . openPoints) keys ->
                                            Left $ fromLeft UnboundedGenerator $ countPoints integerLabel (openCount key) (openFormula key)
                                    _ -> Right ()
                                pure $ repositionOpen $ chooseGroups weighted
                        Uniform alternatives -> do
                            compiled <- traverse (compileOpen compiler requested) alternatives
                            pure $ do
                                groups <- sequence compiled
                                -- As 'uniformly', each alternative weighs its members, which are
                                -- the points of its open groups, and a recursive one makes the
                                -- choice equal. A leaf without bounds has no number of points.
                                weights <- case filter (not . emptyGroups) groups of
                                    _ : _ : _ | not $ any recursiveGroup groups -> traverse members groups
                                    _ -> Right $ map (const 1) groups
                                pure $ repositionOpen $ chooseGroups $ zip weights groups
                        Closed symbol constraint child -> compileOpenNode compiler requested (FixedLabel symbol) constraint child
                        ClosedBy symbolOf constraint child -> compileOpenNode compiler requested (ComputedLabel symbolOf) constraint child
                        _ ->
                            error
                                "cfta-generator bug in Data.CFTA.Gen.Refinement.Internal.Compile.compileOpen: \
                                \a generator without an integer leaf reached the open path"
  where
    members grouped = case cardinalities grouped of
        Right counts -> countWeight . sum <$> traverse (uncurry pointsOf) (Map.toList counts)
        Left _ -> Right 1
    pointsOf key count = case openPoints key of
        Just found -> Right $ count * found
        Nothing -> Left $ fromLeft UnboundedGenerator $ countPoints integerLabel (openCount key) (openFormula key)

{- | One integer leaf as an open group: one variable, which the conditions of
the leaf bound. A leaf without values is empty.
-}
integerGroup :: Constraint -> Either GenError (LTAGrouped OpenKey ([Integer] -> Integer))
integerGroup constraint = case points [valueName] domain of
    Right found | pointCount found == 0 -> Right $ Grouped $ Left EmptyGenerator
    Right found -> Right $ group $ Just $ pointCount found
    Left (UnboundedVariable _) -> Right $ group Nothing
    Left err -> Left $ UncountableIntegers err
  where
    group count =
        keyed (OpenKey (ObservationKey 0 $ Map.singleton (path []) $ Observed root Leaf) 1 bounded count)
            $ Gen Built
            $ TransparentLanguage
            $ Right
            $ holeStatic (RefinedSymbol (fromString "integers") domain) firstInteger
      where
        firstInteger point = case point of
            value : _ -> value
            [] ->
                error
                    "cfta-generator bug in Data.CFTA.Gen.Refinement.Internal.Compile.integerGroup: \
                    \an integer leaf read an empty point"
    domain = integerDomain constraint
    root = RefinedSymbol (fromString "integers") $ refinementFormula (.== variable (integerName 0))
    bounded = substitute [(valueName, variable $ integerName 0)] domain

-- | Join the keys of each tuple of a bare spine, positioned by first appearance.
joinPositioned :: LTAGrouped [OpenKey] a -> LTAGrouped OpenKey a
joinPositioned grouped = regroupOn rekey grouped
  where
    identity keys = let joined = joinOpenKeys keys in (openCount joined, openFormula joined)
    positions = firstPositions $ map identity $ groupKeys grouped
    rekey keys = atPosition (positions Map.! identity keys) $ joinOpenKeys keys

-- | The key of a bare applicative spine: no observation, and the variables of its positions joined.
joinOpenKeys :: [OpenKey] -> OpenKey
joinOpenKeys keys =
    OpenKey
        noObservations
        (sum $ map openCount keys)
        (foldr (.&&) true $ renamedFormulas keys)
        (product <$> traverse openPoints keys)

{- | The part of a product whose one term is the term of the product, such as
the first part of @elements [2] <* pure ()@, when a parent requests paths.
The other parts give no term.
-}
oneTermPart :: Set Path -> LTAGen a -> Maybe Int
oneTermPart requested generator
    | null requested = Nothing
    | all (`elem` [RootCount 0, RootCount 1]) counts
    , [position] <- [index | (index, RootCount 1) <- zip [0 ..] counts] =
        Just position
    | otherwise = Nothing
  where
    counts = spineRootCounts generator

-- | The requested paths at one part of a product, and none at the other parts.
partRequirements :: Int -> Set Path -> LTAGen a -> [Set Path]
partRequirements position requested generator =
    [if index == position then requested else Set.empty | index <- [0 .. length (spineRootCounts generator) - 1]]

{- | Count the points of a formula over the given number of open variables. On
a failure, count again with readable names for the variables, so that the
error names them.
-}
countPoints :: (VarIndex -> String) -> Int -> Formula -> Either GenError Points
countPoints nameOf count formula = case points (map integerName indexes) formula of
    Right found -> Right found
    Left err -> Left $ UncountableIntegers $ fromLeft err $ points (map nameOf indexes) readable
  where
    indexes = [0 .. VarIndex count - 1]
    readable = substitute [(integerName index, variable $ nameOf index) | index <- indexes] formula

-- | A readable name for an open variable of a group.
integerLabel :: VarIndex -> String
integerLabel index = "integer " <> show index

-- | A readable name for an open variable of a constructor: the child that holds it.
childLabel :: Symbol -> [OpenKey] -> VarIndex -> String
childLabel (RefinedSymbol (Symbol constructor) _) childKeys index =
    case [ (child, index - offset, key)
         | (child, offset, key) <- zip3 [0 :: Int ..] (offsets childKeys) childKeys
         , index >= offset
         , index < offset + VarIndex (openCount key)
         ] of
        (child, _, key) : _ | openCount key == 1 -> "child " <> show child <> " of " <> Text.unpack constructor
        (child, within, _) : _ -> "integer " <> show within <> " of child " <> show child <> " of " <> Text.unpack constructor
        [] -> integerLabel index

-- | The keys of the groups of a grouped generator.
openKeys :: LTAGrouped OpenKey a -> [OpenKey]
openKeys = either (const []) Map.keys . cardinalities

-- | The formula of each group of a tuple, with the variables of the tuple renamed apart.
renamedFormulas :: [OpenKey] -> [Formula]
renamedFormulas keys = [renameFrom offset key $ openFormula key | (offset, key) <- zip (offsets keys) keys]

-- | The first variable of each group of a tuple, once the variables are joined in order.
offsets :: [OpenKey] -> [VarIndex]
offsets = scanl (+) 0 . map (VarIndex . openCount)

-- | Rename the variables of one group so that they start at the given offset.
renameFrom :: VarIndex -> OpenKey -> Formula -> Formula
renameFrom offset key =
    substitute [(integerName index, variable $ integerName $ offset + index) | index <- [0 .. VarIndex (openCount key) - 1]]

-- | Regroup open groups by what the parent observes, positioned by first appearance.
repositionOpen :: LTAGrouped (ChoiceIndex, OpenKey) a -> LTAGrouped OpenKey a
repositionOpen grouped = regroupOn rekey grouped
  where
    identity (_, key) = (keyObservations $ openObservations key, openCount key, openFormula key)
    positions = firstPositions $ map identity $ groupKeys grouped
    rekey indexed@(_, key) = atPosition (positions Map.! identity indexed) key

{- | Compile a child description of open groups as one group per tuple of child
groups. The value of a tuple reads the variables of each position in turn.
-}
compileOpenSpine :: Compiler -> [Set Path] -> LTAGen a -> IO (Either GenError (LTAGrouped [OpenKey] ([Integer] -> a)))
compileOpenSpine compiler requirements generator = case genRecipe generator of
    Lifted value -> pure $ Right $ keyed [] $ pure $ const value
    Mapped transform inner -> fmap (mapWithKey (const (transform .))) <$> compileOpenSpine compiler requirements inner
    Paid inner -> fmap payGrouped <$> compileOpenSpine compiler requirements inner
    Applied functions arguments -> do
        let (functionRequirements, argumentRequirements) = splitAt (fromEnum $ spineArity functions) requirements
            applyReader keys (function, argument) =
                let split = sum $ map openCount $ take (fromEnum $ spineArity functions) keys
                 in \point -> function (take split point) (argument $ drop split point)
        compiledFunctions <- compileOpenSpine compiler functionRequirements functions
        case compiledFunctions of
            Left err -> pure $ Left err
            Right functionGroups
                | emptyGroups functionGroups -> pure $ Right $ frequencies []
                | otherwise -> do
                    compiledArguments <- compileOpenSpine compiler argumentRequirements arguments
                    case compiledArguments of
                        Left err -> pure $ Left err
                        Right argumentGroups -> do
                            related <- relateGroupsM (\_ _ -> pure $ Right True) (<>) functionGroups argumentGroups
                            pure $ mapWithKey applyReader <$> related
    _ -> fmap (regroupOn pure) <$> compileOpen compiler (Set.unions $ take 1 requirements) generator

{- | Compile one constructor whose children can leave integer variables open.

The children are grouped as for 'compileNode'. For each tuple of child groups,
the variables of the children are renamed apart and joined. The solver decides
the parts of the guard that read no open child, as in 'compileNode'. The other
parts, the conditions on the constructor's own measure, and the formulas of the
children form one linear formula over the joined variables; a child names its
value by its root label, as an exact integer or as a term of its variables.
When the constructor's label names no variable, the constructor closes them:
its members are the integer points of the formula, counted without
enumeration, and the points fill the placeholder leaves in order. Otherwise
the constructor leaves the variables open for its parent.
-}
compileOpenNode ::
    Compiler ->
    Set Path ->
    Labelling ->
    Constraint ->
    LTAGen a ->
    IO (Either GenError (LTAGrouped OpenKey ([Integer] -> a)))
compileOpenNode compiler requested labelling constraint child
    | not (all null childRequirements) && not (alignedSpine child) = pure $ Left ChildNotOneTerm
    | otherwise = do
        compiledChild <- compileOpenSpine compiler childRequirements child
        case compiledChild of
            Left err -> pure $ Left err
            Right childGroups -> do
                retained <- filterGroupsM decide childGroups
                pure $ retained >>= settleGroups settle . labelGroups
  where
    (arity, leafness, observed, childRequirements) = nodeShape requested labelling constraint child
    parts = conjuncts $ constraintGuard constraint
    open childKeys (ChildIndex index) = maybe False ((> 0) . openCount) $ childKeys !? index
    -- A parent reads only the root of a child that leaves variables open.
    readsInsideOpen childKeys target = case unPath target of
        index : _ : _ -> open childKeys index
        _ -> False
    equalityPaths = constraintPaths $ equalityConstraint $ constraintEqualities constraint
    renamedRoot childKeys (ChildIndex index) = do
        key <- childKeys !? index
        Observed (RefinedSymbol symbol refinement) _ <- Map.lookup (path []) $ keyObservations $ openObservations key
        pure $ RefinedSymbol symbol $ renameFrom (offsets childKeys !! index) key refinement
    labelOf childKeys = case labelling of
        FixedLabel label -> Right label
        ComputedLabel symbolOf ->
            traverse (maybe (Left MissingRootObservation) Right . renamedRoot childKeys) (childIndexes arity) >>= symbolOf
    symbolic (RefinedSymbol _ refinement) = any isIntegerName $ freeNames refinement
    readsOpen childKeys label part =
        flip any (guardPaths part) $ \target -> case unPath target of
            index : _ -> open childKeys index
            [] -> symbolic label
    decide childKeys
        | any (readsInsideOpen childKeys) (observed <> equalityPaths) || any (any (open childKeys) . firstIndex) equalityPaths =
            pure $ Left $ IntegerLeafRead Nothing
        | otherwise = case labelOf childKeys of
            Left err -> pure $ Left err
            Right label ->
                let finiteParts = filter (not . readsOpen childKeys label) parts
                    -- A closed child keeps the symbolic labels of its integer leaves until a point fills them.
                    readsSymbolic target = case Map.lookup target $ completeObservations label leafness $ map openObservations childKeys of
                        Just (Observed found _) -> symbolic found
                        Nothing -> False
                 in case filter (any readsSymbolic . guardPaths) finiteParts of
                        part : _ -> pure $ Left $ IntegerLeafRead $ Just part
                        []
                            | any readsSymbolic equalityPaths -> pure $ Left $ IntegerLeafRead Nothing
                            | null finiteParts && constraintEqualities constraint == EmptyConstraints -> pure $ Right True
                            | otherwise ->
                                constraintDecision
                                    (compilerEntailment compiler)
                                    label
                                    leafness
                                    constraint{constraintGuard = if null finiteParts then Top else And finiteParts}
                                    (map openObservations childKeys)
      where
        firstIndex target = take 1 $ unPath target
    -- Only accepted tuples are closed, and their labels were computed to accept them.
    closeLabel childKeys = case labelOf childKeys of
        Right label -> label
        Left _ ->
            error
                "cfta-generator bug in Data.CFTA.Gen.Refinement.Internal.Compile.compileOpenNode: \
                \an accepted group lost its label"
    -- 'fillHoles' makes a label that names open variables exact and keeps
    -- its name, so a filled term ranks under any label with that name.
    -- 'settleGroups' refuses a cyclic group.
    labelGroups (Grouped result) = Grouped $ Map.mapWithKey labelBucket <$> result
    labelGroups cyclic = nodeWithKey closeLabel cyclic
    labelBucket childKeys bucket =
        bucket
            { keyedBucketStatic = labelStaticMatching (fills label) label originalStatic
            , keyedBucketMasses = payMassIndex sourceMinimum <$> keyedBucketMasses bucket
            }
      where
        label = closeLabel childKeys
        originalStatic = keyedBucketStatic bucket
        sourceMinimum = minimumMemberSize $ outcomeSizeIndex $ staticOutcomes originalStatic
    fills label@(RefinedSymbol symbol _) found@(RefinedSymbol foundSymbol _)
        | symbolic label = foundSymbol == symbol
        | otherwise = found == label
    settle childKeys = do
        let label@(RefinedSymbol _ labelRefinement) = closeLabel childKeys
            total = sum $ map openCount childKeys
            -- A defining term must determine its value independently of that value.
            termOf refinement =
                (literal <$> onlyPoint valueName refinement) <|> do
                    term <- definingTerm refinement
                    if valueName `elem` freeNames (term .== 0)
                        then Nothing
                        else Just term
            refinementAt target = case unPath target of
                [] -> Just labelRefinement
                [index] -> (\(RefinedSymbol _ refinement) -> refinement) <$> renamedRoot childKeys index
                _ -> Nothing
            -- A part reads a named measure of a target as the term that the
            -- refinement of the target gives for it, and a target as its value.
            readTargets part names targets formula = do
                refinements <- maybe (Left $ IntegerLeafRead $ Just part) Right $ traverse refinementAt targets
                let applied =
                        replaceNamedReads
                            [(Formula.Name $ fromString name, namedTerms refinement) | (name, refinement) <- zip names refinements]
                            formula
                targetValues <-
                    sequence
                        [ maybe (Left $ IntegerLeafRead $ Just part) (Right . (,) name) (termOf refinement)
                        | (name, refinement) <- zip names refinements
                        , name `elem` freeNames applied
                        ]
                pure $ substitute targetValues applied
            partFormula part = case part of
                Satisfies target formula -> readTargets part [valueName] [target] formula
                Holds targets formula -> readTargets part (map contractTermName [0 ..]) targets formula
                _ -> Left $ IntegerLeafRead $ Just part
        openFormulas <- traverse partFormula $ filter (readsOpen childKeys label) parts
        let formula = foldr (.&&) true $ renamedFormulas childKeys <> openFormulas
            observations = ObservationKey 0 $ parentObservations requested label leafness $ map openObservations childKeys
        found <- countPoints (childLabel label childKeys) total formula
        -- The share of the points of the children that the constructor keeps. An unbounded leaf is common to all tuples.
        let kept = toRational (pointCount found) / toRational (product $ map (fromMaybe 1 . openPoints) childKeys)
        pure $
            if pointCount found == 0
                then Nothing
                else
                    if symbolic label
                        then Just (OpenKey observations total formula (Just $ pointCount found), kept, Nothing)
                        else
                            -- Children without open variables have no point to select, so
                            -- the constructor selects none; closeOpen applies them.
                            Just (closedKey observations, kept, if total == 0 then Nothing else Just found)

{- | Settle each tuple of child groups: drop it, leave its variables open under
a new key, or close them by the integer points of its formula. The mass of a
tuple keeps the share of its points that the constructor keeps, as a guard
keeps the accepted tuples of pools. New keys are positioned by first
appearance.
-}
settleGroups ::
    ([OpenKey] -> Either GenError (Maybe (OpenKey, Rational, Maybe Points))) ->
    LTAGrouped [OpenKey] ([Integer] -> a) ->
    Either GenError (LTAGrouped OpenKey ([Integer] -> a))
settleGroups _ (CyclicGrouped _) = Right $ Grouped $ Left UnboundedGenerator
settleGroups _ (Grouped (Left err)) = Right $ Grouped $ Left err
settleGroups settle (Grouped (Right buckets)) = do
    settled <- catMaybes <$> traverse one (Map.toAscList buckets)
    let identity key = (keyObservations $ openObservations key, openCount key, openFormula key)
        positions = firstPositions [identity key | (key, _) <- settled]
        positioned key = atPosition (positions Map.! identity key) key
    pure $ Grouped $ mergeComponentsByKey [(positioned key, bucket) | (key, bucket) <- settled]
  where
    one (childKeys, bucket) = fmap (build (sum $ map openCount childKeys) bucket) <$> settle childKeys
    build _ bucket (key, kept, Nothing) = (key, bucket{keyedBucketMass = keyedBucketMass bucket * kept})
    build variables (KeyedBucket mass static masses) (key, kept, Just found) =
        ( key
        , KeyedBucket
            (mass * kept)
            (mapStatic const $ closePoints variables found static)
            (closedMasses variables found <$> masses)
        )

{- | Close every open group by the integer points of its formula, for a parent
that reads no variable.
-}
closeOpen :: LTAGrouped OpenKey ([Integer] -> a) -> Either GenError (LTAGrouped ObservationKey a)
closeOpen (CyclicGrouped _) = Right $ Grouped $ Left UnboundedGenerator
closeOpen (Grouped (Left err)) = Right $ Grouped $ Left err
closeOpen (Grouped (Right buckets)) = do
    closed <- catMaybes <$> traverse one (Map.toAscList buckets)
    pure $ Grouped $ mergeComponentsByKey closed
  where
    one (key, bucket@(KeyedBucket mass static masses))
        | openCount key == 0 = Right $ Just (openObservations key, bucket{keyedBucketStatic = mapStatic ($ []) static})
        | otherwise = do
            found <- countPoints integerLabel (openCount key) (openFormula key)
            pure $
                if pointCount found == 0
                    then Nothing
                    else
                        Just
                            ( openObservations key
                            , KeyedBucket mass (closePoints (openCount key) found static) (closedMasses (openCount key) found <$> masses)
                            )

{- | Apply the outcomes of an open group to the integer points of its formula,
over the given number of variables. A term ranks by the integers at its
placeholder leaves. Each integer of a point is one source choice, as each
member of 'elements' is, so a point has one size for each variable.
-}
closePoints :: Int -> Points -> Static Symbol ([Integer] -> a) -> Static Symbol a
closePoints variables found = pointsStatic (fromIntegral variables) fillHoles rankPoint (Indexed (pointCount found) (pointAt found))
  where
    rankPoint symbols = do
        point <- traverse leafValue symbols
        rank <- pointRank found point
        pure (rank, point)
      where
        leafValue (RefinedSymbol _ refinement) = onlyPoint valueName refinement

{- | The weights of a group in each size class after 'closePoints' over the
given number of variables. Every member takes each point, and a point has one
size for each variable.
-}
closedMasses :: Int -> Points -> MassIndex -> MassIndex
closedMasses variables found masses = pairMassIndex masses $ MassIndex [(fromIntegral variables, toRational $ pointCount found)]

{- | Replace the placeholder leaves of a term, in order, by the leaves of the
integers of a point, and make each label that names open variables exact.

The variables of a constructor are the placeholders of its subtree, in
order, so a label names them from the first placeholder below it.
-}
fillHoles :: [Integer] -> Term (Label Symbol) -> Term (Label Symbol)
fillHoles point = snd . fill point
  where
    fill (value : rest) (Term.Node Placeholder _) = (rest, Term.Node (Label $ integerSymbol value) [])
    fill remaining (Term.Node (Label label) children) = Term.Node (Label $ exactLabel remaining label) <$> mapAccumL fill remaining children
    fill remaining (Term.Node private children) = Term.Node private <$> mapAccumL fill remaining children
    exactLabel remaining label@(RefinedSymbol symbol refinement)
        | any isIntegerName $ freeNames refinement =
            let named = substitute [(integerName index, literal value) | (index, value) <- zip [0 ..] remaining] refinement
             in RefinedSymbol symbol $ maybe named (\value -> refinementFormula (.== literal value)) $ onlyPoint valueName named
        | otherwise = label

{- | The terms of the named measures that a refinement fixes: each conjunct
@name(v) == t@ whose term does not read the value @v@.
-}
namedTerms :: Formula.Formula -> [(String, Formula.Term)]
namedTerms formula = case formula of
    Formula.And parts -> concatMap namedTerms parts
    Formula.Atom Formula.Eq left right
        | Just found <- named left right <|> named right left -> [found]
    _ -> []
  where
    value = Formula.Name $ fromString valueName
    named (Formula.App (Formula.Name function) [Formula.Var argument]) term
        | argument == value
        , value `notElem` Formula.freeNames (Formula.Atom Formula.Eq term (Formula.Lit 0)) =
            Just (Text.unpack function, term)
    named _ _ = Nothing

{- | Replace each read of a named measure of a target, @name(target)@, by the
term that the table gives for it. Other applications stay.
-}
replaceNamedReads :: [(Formula.Name, [(String, Formula.Term)])] -> Formula.Formula -> Formula.Formula
replaceNamedReads table = formulaWith
  where
    formulaWith formula = case formula of
        Formula.And parts -> Formula.And (map formulaWith parts)
        Formula.Or parts -> Formula.Or (map formulaWith parts)
        Formula.Not inner -> Formula.Not (formulaWith inner)
        Formula.Atom relation left right -> Formula.Atom relation (termWith left) (termWith right)
        Formula.Forall bound inner -> Formula.Forall bound (formulaWith inner)
        Formula.Exists bound inner -> Formula.Exists bound (formulaWith inner)
        _ -> formula
    termWith term = case term of
        Formula.App (Formula.Name function) [Formula.Var target]
            | Just named <- lookup target table
            , Just replacement <- lookup (Text.unpack function) named ->
                replacement
        Formula.App function arguments -> Formula.App function (map termWith arguments)
        Formula.Neg inner -> Formula.Neg (termWith inner)
        Formula.Add left right -> Formula.Add (termWith left) (termWith right)
        Formula.Sub left right -> Formula.Sub (termWith left) (termWith right)
        Formula.Mul left right -> Formula.Mul (termWith left) (termWith right)
        Formula.Div left right -> Formula.Div (termWith left) (termWith right)
        Formula.Mod left right -> Formula.Mod (termWith left) (termWith right)
        Formula.Ite condition yes no -> Formula.Ite (formulaWith condition) (termWith yes) (termWith no)
        Formula.Cast inner sort -> Formula.Cast (termWith inner) sort
        _ -> term

-- | The top-level conjuncts of a guard.
conjuncts :: Guard -> [Guard]
conjuncts Top = []
conjuncts (And guards) = concatMap conjuncts guards
conjuncts guard = [guard]

-- | Decide one guard from the leafness of the constructor and the already-grouped child observations.
constraintDecision :: Entailment -> Symbol -> Leafness -> Constraint -> [ObservationKey] -> IO (Either GenError Bool)
constraintDecision entailment label leafness constraint childKeys = do
    verdict <- decide $ constraintAsGuard constraint
    case verdict of
        Yes -> pure $ Right True
        No -> pure $ Right False
        -- Sparse observations cannot decide an equality of complete subtrees.
        -- Report that only when the rest of the guard is decided: otherwise
        -- the solver could not decide the rest.
        Unknown -> do
            semantic <- decide $ fst $ splitGuard $ constraintGuard constraint
            -- With a solver that answers every query, the guard is decided when
            -- the observations decide its equalities: then only the solver left
            -- it undecided. This also covers an equality under 'Or' or 'Not'.
            answered <- traverse (\answer -> decideWith (Entailment $ \_ _ -> pure answer) $ constraintAsGuard constraint) [Yes, No]
            pure $ case semantic of
                Unknown -> Left SolverUnknown
                _
                    | Unknown `notElem` answered -> Left SolverUnknown
                    -- An equality reads a node whose members are leaves and non-leaves.
                    | any unknownLeaf $ guardPaths $ snd $ splitGuard $ constraintGuard constraint ->
                        Left ChildNotOneTerm
                    | constraintEqualities constraint /= EmptyConstraints ->
                        Left $ RelationalEqualityUnsupported $ constraintEqualities constraint
                    | containsSame (constraintGuard constraint) ->
                        Left $ RelationalSyntacticEqualityUnsupported $ constraintGuard constraint
                    | otherwise -> Left SolverUnknown
  where
    observations = completeObservations label leafness childKeys
    unknownLeaf target = case Map.lookup target observations of
        Just (Observed _ Mixed) -> True
        _ -> False
    decide = decideWith entailment
    decideWith entailment' = evaluateGuardWithShape entailment' (`Map.lookup` observations)

-- | The observations a parent requests above one accepted node.
parentObservations :: Set Path -> Symbol -> Leafness -> [ObservationKey] -> Observations
parentObservations requested label leafness childKeys =
    Map.restrictKeys (completeObservations label leafness childKeys) $ Set.insert (path []) requested

{- | The root, with its label and leafness, plus the sparse observations
retained by every direct child group.
-}
completeObservations :: Symbol -> Leafness -> [ObservationKey] -> Observations
completeObservations label leafness childKeys =
    Map.fromList $
        (path [], Observed label leafness)
            : [ (path $ childIndex : unPath target, observed)
              | (childIndex, childKey) <- zip [0 ..] childKeys
              , (target, observed) <- Map.toList $ keyObservations childKey
              ]

{- | Compile an imported automaton.

The automaton is bounded, pruned with the solver, and split into one
sub-automaton per tuple of requested observations. Each part is read by the
engine, which counts it symbolically where alternatives overlap or guards of
Boolean equality remain.

Pruning can leave a guard that the symbolic counter cannot count. A bounded
import then reads its bounded denotation ('denotationAtMost'): the solver
decides every guard of the original automaton on each complete term, and the
import reads an automaton of exactly those terms. So pruning is not needed
for the result. An unbounded import has no finite denotation, and it reports
the guard as 'ResidualGuard' before any part is read.
-}
compileImport ::
    (Ord key) =>
    Entailment ->
    Set Path ->
    Maybe Depth ->
    (Symbol -> key) ->
    Automaton ->
    IO (Either GenError (LTAGrouped ObservationKey (Term Symbol)))
compileImport entailment requested bound order automaton
    | Just depth <- bound, depth < 0 = pure $ Right $ frequencies []
    | otherwise = do
        pruned <- prune entailment $ maybe id boundDepth bound automaton
        case first pruningError pruned >>= discharged of
            Left (ResidualGuard guard) | Just depth <- bound -> denoted depth guard
            result -> pure $ grouped <$> result
  where
    pruningError (PruneUnknown _) = SolverUnknown
    pruningError err = InvalidPruning err

    discharged reduced =
        reduced
            <$ mapM_ (first ResidualGuard . constraintIndicators . edgeConstraint) (concat $ IntMap.elems $ reachable reduced)

    -- The parts are sorted by their observations, which order by symbol text
    -- and refinement, so the ranks do not depend on the order in which the
    -- process interned the edges.
    grouped reduced =
        uniformlyGrouped
            [ keyed (ObservationKey position observations) $ Flat.fromAutomaton order part
            | (position, (observations, part)) <- zip [0 ..] $ sortOn fst $ splitByObservations requested reduced
            ]

    -- The terms of the bounded denotation of the original automaton, as an
    -- automaton without guards. The guard stays the error if those terms do
    -- not make one automaton.
    denoted depth guard = do
        accepted <- denotationAtMost entailment depth automaton
        pure $ case accepted of
            Left (DenotationUnknown _ _) -> Left SolverUnknown
            Right denotation -> case FTA.mixedArity (FTA.fromTerms denotation) of
                Just _ -> Left $ ResidualGuard guard
                Nothing -> Right $ grouped $ fromFTA $ FTA.fromTerms denotation

{- | Partition the language of an automaton by the labels at the requested paths.

Each part accepts exactly the terms with one tuple of observations, and the
parts share their unobserved subgraphs. The parts are in the order of their
first transition. A recursive node is unfolded once per requested level.
-}
splitByObservations :: Set Path -> Automaton -> [(Observations, Automaton)]
splitByObservations requested root
    | Set.null requested = [(Map.empty, root)]
    | otherwise = case root of
        Node edges -> mergeParts $ concatMap splitEdge edges
        Mu _ -> splitByObservations requested $ unfoldOuterRec root
        InternedUnion _ -> splitByObservations requested $ Node $ nodeEdges root
        _ -> []
  where
    observesRoot = Set.member (path []) requested
    childRequests =
        Map.fromListWith
            Set.union
            [(index, Set.singleton $ path rest) | target <- Set.toList requested, index : rest <- [unPath target]]

    splitEdge (Transition symbol refinement children constraint) =
        [ (Map.unions (rootObservation : childObservations), Node [Transition symbol refinement parts constraint])
        | (childObservations, parts) <- combinations $ zipWith splitChild [0 ..] children
        ]
      where
        rootObservation
            | observesRoot = Map.singleton (path []) $ Observed (RefinedSymbol symbol refinement) $ leafnessOf children
            | otherwise = Map.empty

        splitChild index child =
            [ (Map.mapKeys (path . (index :) . unPath) observations, part)
            | (observations, part) <- splitByObservations (Map.findWithDefault Set.empty index childRequests) child
            ]

    combinations =
        foldr
            (\options rest -> [(observations : more, part : parts) | (observations, part) <- options, (more, parts) <- rest])
            [([], [])]

-- | Merge the parts with equal observations, keeping the order of first appearance.
mergeParts :: [(Observations, Automaton)] -> [(Observations, Automaton)]
mergeParts parts = [(observations, union $ toList $ grouped Map.! observations) | observations <- nubOrd $ map fst parts]
  where
    grouped = Map.fromListWith (flip (<>)) [(observations, Sequence.singleton part) | (observations, part) <- parts]

-- | Report a solver query that reached its time limit as 'SolverTimeLimit'.
reportTimeLimit :: IO (Either GenError a) -> IO (Either GenError a)
reportTimeLimit = handle $ \(TimeLimitReached milliseconds) -> pure $ Left $ SolverTimeLimit milliseconds

{- | Check every candidate explicitly and keep the accepted values in order.

Every combination the recipe describes is a candidate. Each complete witness
is checked with the solver, guard by guard. An imported automaton is pruned
first and contributes its accepted terms.
-}
validOutcomes :: Entailment -> LTAGen a -> IO (Either GenError [a])
validOutcomes uncachedEntailment generator = reportTimeLimit $ do
    entailment <- cacheEntailment uncachedEntailment
    candidates <- candidatesOf entailment generator
    case candidates of
        Left err -> pure $ Left err
        Right members -> fmap catMaybes . sequence <$> traverse (accept entailment) members
  where
    -- The value of an accepted candidate.
    accept :: Entailment -> (a, [Witness]) -> IO (Either GenError (Maybe a))
    accept entailment (value, witnesses) = go witnesses
      where
        go [] = pure $ Right $ Just value
        go (witness : rest) = do
            verdict <- checkWitness entailment witness
            case verdict of
                Yes -> go rest
                No -> pure $ Right Nothing
                Unknown -> pure $ Left SolverUnknown

-- | Every candidate of a recipe with the witnesses of its positions.
candidatesOf :: Entailment -> LTAGen a -> IO (Either GenError [(a, [Witness])])
candidatesOf entailment generator = case genRecipe generator of
    Built -> pure $ builtCandidates generator
    Lifted value -> pure $ Right [(value, [])]
    Mapped transform inner -> fmap (map (first transform)) <$> candidatesOf entailment inner
    Paid inner -> candidatesOf entailment inner
    Applied functions arguments -> do
        functionCandidates <- candidatesOf entailment functions
        argumentCandidates <- candidatesOf entailment arguments
        pure $
            ( \fs xs ->
                [ (function argument, functionWitnesses <> argumentWitnesses)
                | (function, functionWitnesses) <- fs
                , (argument, argumentWitnesses) <- xs
                ]
            )
                <$> functionCandidates
                <*> argumentCandidates
    Chosen alternatives -> fmap concat . sequence <$> traverse (candidatesOf entailment . snd) alternatives
    Uniform alternatives -> fmap concat . sequence <$> traverse (candidatesOf entailment) alternatives
    Closed label constraint child -> (>>= close (const $ Right label) constraint) <$> candidatesOf entailment child
    ClosedBy labelOf constraint child -> (>>= close (labelOf . map witnessLabel) constraint) <$> candidatesOf entailment child
    Imported bound order automaton -> do
        imported <- compileImport entailment Set.empty bound order automaton
        pure $ imported >>= builtCandidates . ungroup
    Integers constraint -> pure $ integerCandidates constraint
  where
    close labelOf constraint = traverse $ \(value, witnesses) -> (\label -> (value, [Witness label constraint witnesses])) <$> labelOf witnesses

{- | Every integer between the least and the greatest counted integer of a
leaf, each with a witness that checks the leaf's conditions.
-}
integerCandidates :: Constraint -> Either GenError [(Integer, [Witness])]
integerCandidates constraint = case points [valueName] (integerDomain constraint) of
    Left err -> Left $ UncountableIntegers err
    Right found
        | pointCount found == 0 -> Right []
        | otherwise ->
            Right
                [ (value, [Witness (integerSymbol value) constraint []])
                | value <- [least .. greatest]
                ]
      where
        least = head' $ pointAt found 0
        greatest = let Cardinality count = pointCount found in head' $ pointAt found $ Rank $ count - 1
        head' point = case point of
            [value] -> value
            _ ->
                error
                    "cfta-generator bug in Data.CFTA.Gen.Refinement.Internal.Compile.integerCandidates: a point of one variable has another dimension"

-- | The members of a built language, each with the witnesses of its term.
builtCandidates :: LTAGen a -> Either GenError [(a, [Witness])]
builtCandidates generator
    | deferred generator = Left SourceRequiresCompilation
    | Left EmptyGenerator <- cardinality generator = Right []
    | otherwise = do
        total <- cardinality generator
        traverse member $ everyRank total
  where
    member rank = (\value term -> (value, map termWitness $ surface term)) <$> unrank generator rank <*> termAt generator rank
