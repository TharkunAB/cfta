{- | Internal representation for finite ranked generators.

This module is an exposed internal module. The generator layers of
cfta-generator use it directly. Its exports are not covered by the PVP
contract of the package.
-}
module Data.CFTA.Ranked.Internal (
    Indexed (..),
    WeightedIndexed (..),
    Ranked,
    rankedPlan,
    rankedValueAt,
    RankedError (..),
    fromIndexed,
    fromIndexedOnDemand,
    fromWeightedIndexedOnDemand,
    share,
    pay,
    scale,
    fromWeighted,
    frequency,
    oneof,
    cardinality,
    unrank,
    lower,
    lowerWithRank,
    shrinkRank,
    smallerMembers,
    sizeOfRank,
    withOffsets,
) where

import Data.Array (listArray, (!))

import Data.CFTA.Index (Cardinality (..), Rank (..), Size, Weight (..), countWeight, hasRank)
import Data.CFTA.Ranked.Internal.Decoder (
    Plan (..),
    RankDecoder (..),
    RankedValue (..),
    SizeClass (..),
    compilePlan,
    offsetRankedValue,
    planCardinality,
    sharedChoiceBound,
 )
import Data.CFTA.Ranked.Internal.Sampler (
    GenBackend (..),
    Sampler (..),
    mapSampler,
    productSampler,
    uniformSampler,
 )
import Data.CFTA.Ranked.Internal.Shrink (
    planMemberSize,
    shrinkPlanRank,
    smallerPlanMembers,
    withOffsets,
 )
import Data.CFTA.Ranked.Internal.Size (MinimumSize (..), SizeIndex (minimumMemberSize), payIndex, scaleIndex, sizeIndex)

-- | A finite source addressed by a stable zero-based rank.
data Indexed a = Indexed
    { indexedCardinality :: !Cardinality
    -- ^ Number of selectable values.
    , indexedSelect :: Rank -> a
    -- ^ Decode one valid rank.
    }

{- | A weighted finite source with separate replay ranks and sampling tickets.

Each valid rank must receive a positive number of tickets. That number is its
relative sampling weight. The ticket callback must return a valid rank for
every ticket below the total weight. These callback invariants are the caller's
responsibility; checking them would enumerate the source.
-}
data WeightedIndexed a = WeightedIndexed
    { weightedIndexedCardinality :: !Cardinality
    -- ^ Number of distinct zero-based replay ranks.
    , weightedIndexedTotalWeight :: !Weight
    -- ^ Number of zero-based sampling tickets across all ranks.
    , weightedIndexedSelect :: Rank -> a
    -- ^ Decode one valid replay rank.
    , weightedIndexedRankAtTicket :: Integer -> Rank
    -- ^ Map one valid sampling ticket to its replay rank.
    }

-- | Failure while constructing or selecting from a finite ranked generator.
data RankedError
    = -- | The language has no members.
      EmptyRanked
    | {- | A weight was below one: the weight of an alternative or of a
      value, or the total weight of a weighted source.
      -}
      NonPositiveRankedWeight !Weight
    | {- | The total weight cannot give every rank a positive integer weight.
      The fields contain the cardinality and total weight, respectively.
      -}
      InsufficientRankedWeight !Cardinality !Weight
    | -- | Ranks start at zero.
      NegativeRankedRank !Rank
    | -- | A rank fell outside a language of the given cardinality.
      RankedSelectionOutOfRange !Rank !Cardinality
    deriving (Eq, Show)

-- | A non-empty finite language with stable ranks and a sampling plan.
data Ranked a = Ranked
    { rankedPlan :: !(Plan a)
    -- ^ The raw plan. It is the source of truth for rank order and shrinking.
    , rankedSampler :: !(Sampler a)
    -- ^ The compositional sampler used by 'lower'.
    , rankedDecoder :: !(RankDecoder a)
    -- ^ The compiled decoder used by 'unrank'.
    , rankedSizeIndex :: SizeIndex a
    {- ^ The size classes of the plan, built on first use and retained so a
    shrink loop pays for them once.
    -}
    }

instance Functor Ranked where
    fmap transform Ranked{rankedPlan, rankedSampler} =
        makeRanked
            (PlanMap transform rankedPlan)
            (mapSampler transform rankedSampler)

instance Applicative Ranked where
    pure value =
        makeRanked
            (PlanPure value)
            (uniformSampler 1 $ const value)

    functions <*> arguments =
        makeRanked
            ( PlanAp
                (cardinality arguments)
                (rankedPlan functions)
                (rankedPlan arguments)
            )
            ( productSampler
                (cardinality arguments)
                (rankedSampler functions)
                (rankedSampler arguments)
            )

-- | Build a ranked language from an indexed source.
fromIndexed :: Indexed a -> Either RankedError (Ranked a)
fromIndexed Indexed{indexedCardinality, indexedSelect}
    | indexedCardinality <= 0 = Left EmptyRanked
    | otherwise =
        Right $
            makeRanked
                (PlanSelect indexedCardinality indexedSelect)
                (uniformSampler indexedCardinality indexedSelect)

{- | Build a ranked language that decodes a member each time a caller reads it.

'fromIndexed' tabulates a source of at most 4096 members, so the decoder
keeps each member that it decodes. This function does not tabulate.
Automaton imports use it.
-}
fromIndexedOnDemand :: Indexed a -> Either RankedError (Ranked a)
fromIndexedOnDemand Indexed{indexedCardinality, indexedSelect}
    | indexedCardinality <= 0 = Left EmptyRanked
    | otherwise =
        Right $
            makeRanked
                (PlanSelectOnDemand indexedCardinality indexedSelect)
                (uniformSampler indexedCardinality indexedSelect)

{- | Build a weighted ranked language without enumerating its values or tickets.

Sampling selects one ticket and maps it to the retained replay rank. Weight
does not change cardinality or rank order. The constructor checks cardinality
and total weight only; it does not evaluate either callback.
-}
fromWeightedIndexedOnDemand :: WeightedIndexed a -> Either RankedError (Ranked a)
fromWeightedIndexedOnDemand
    WeightedIndexed
        { weightedIndexedCardinality
        , weightedIndexedTotalWeight
        , weightedIndexedSelect
        , weightedIndexedRankAtTicket
        }
        | weightedIndexedCardinality <= 0 = Left EmptyRanked
        | weightedIndexedTotalWeight <= 0 = Left $ NonPositiveRankedWeight weightedIndexedTotalWeight
        | weightedIndexedTotalWeight < countWeight weightedIndexedCardinality =
            Left $ InsufficientRankedWeight weightedIndexedCardinality weightedIndexedTotalWeight
        | otherwise =
            Right $
                makeRanked
                    (PlanSelectOnDemand weightedIndexedCardinality weightedIndexedSelect)
                    ( Sampler
                        (weightedIndexedSelect <$> runValueSampler tickets)
                        ((\rank -> RankedValue rank (weightedIndexedSelect rank)) <$> runValueSampler tickets)
                    )
      where
        -- The tickets are the ranks of a uniform language with one member for each ticket.
        Weight ticketCount = weightedIndexedTotalWeight
        tickets = uniformSampler (Cardinality ticketCount) (\(Rank ticket) -> weightedIndexedRankAtTicket ticket)

{- | Reuse a compiled subplan without expanding it at each parent occurrence.

The shared node keeps the compiled decoder and the size classes of the plan.
The decoder, the size classes of a parent, and the smallest member read them,
so a plan that several parents reach is compiled and counted once. The walks
that follow one member, for its size and for its shrink candidates, go into
the original plan. A part with two or more members cannot occur that often in
one member: each occurrence multiplies the cardinality by at least two.

A language with one member is a sized leaf instead: one size class with one
member. Its plan can be a shared tree with far more nodes than the plan has,
for example a balanced tree whose two children are one node. A walk of its
one member visits every node of that tree. The leaf gives the size and the
member directly.
-}
share :: Ranked a -> Ranked a
share ranked
    | cardinality ranked == 1 = ranked{rankedPlan = PlanSized [SizeClass size 1 (const member) (const member)]}
    | otherwise =
        ranked
            { rankedPlan =
                PlanShared
                    (cardinality ranked)
                    (rankedDecoder ranked)
                    (rankedSizeIndex ranked)
                    (rankedPlan ranked)
            }
  where
    member = decode (rankedDecoder ranked) 0
    size = case minimumMemberSize (rankedSizeIndex ranked) of
        MinimumSize size' -> size'
        NoFiniteMember ->
            error
                "cfta-generator bug in Data.CFTA.Ranked.Internal.share: \
                \a language with one member has no size"

{- | Add one to the size of every member: the @pay@ of FEAT (Duregård, Jansson,
and Wang, Haskell Symposium 2012). Sizes count pays: 'pure' has size zero, an
indexed source has size one, and '<*>' adds the sizes of its sides. Ranks and
values do not change.
-}
pay :: Ranked a -> Ranked a
pay ranked =
    ranked
        { rankedPlan = PlanPay $ rankedPlan ranked
        , rankedSizeIndex = payIndex $ rankedSizeIndex ranked
        }

{- | Multiply the size of every member by a positive factor: the size of a
member that a term holds at that many positions, such as the one subterm of a
group of equal children. Ranks and values do not change.
-}
scale :: Int -> Ranked a -> Ranked a
scale 1 ranked = ranked
scale factor ranked =
    ranked
        { rankedPlan = PlanScale factor $ rankedPlan ranked
        , rankedSizeIndex = scaleIndex factor $ rankedSizeIndex ranked
        }

{- | Build a ranked language whose members have positive relative weights.

Weight affects sampling, not cardinality or rank order: each list entry has
exactly one stable rank.
-}
fromWeighted :: [(Weight, a)] -> Either RankedError (Ranked a)
fromWeighted [] = Left EmptyRanked
fromWeighted weighted
    | badWeight : _ <- [weight | (weight, _) <- weighted, weight <= 0] =
        Left (NonPositiveRankedWeight badWeight)
    | otherwise =
        Right $
            makeRanked
                (PlanSelect total selectValue)
                ( Sampler
                    (frequencyGen [(weight, pure value) | (weight, value) <- weighted])
                    ( frequencyGen
                        [ (weight, pure $ RankedValue rank value)
                        | (rank, (weight, value)) <- zip [0 ..] weighted
                        ]
                    )
                )
  where
    total = Cardinality $ toInteger $ length weighted
    table = listArray (0, length weighted - 1) (map snd weighted)
    selectValue (Rank rank) = table ! fromInteger rank

-- | Combine non-empty alternatives with positive relative weights.
frequency :: [(Weight, Ranked a)] -> Either RankedError (Ranked a)
frequency [] = Left EmptyRanked
frequency alternatives
    | badWeight : _ <- [weight | (weight, _) <- alternatives, weight <= 0] =
        Left (NonPositiveRankedWeight badWeight)
    | otherwise =
        Right $
            makeRanked
                ( PlanChoice
                    [ (cardinality ranked, alternativePlan ranked)
                    | (_, ranked) <- alternatives
                    ]
                )
                ( Sampler
                    ( frequencyGen
                        [ (weight, runValueSampler $ rankedSampler ranked)
                        | (weight, ranked) <- alternatives
                        ]
                    )
                    ( frequencyGen
                        [ (weight, offsetRankedValue offset <$> runRankSampler (rankedSampler ranked))
                        | (offset, (weight, ranked)) <- withOffsets (cardinality . snd) alternatives
                        ]
                    )
                )
  where
    -- An alternative with more than 'sharedChoiceBound' members is a shared
    -- node, so a language that several alternatives reuse is compiled and
    -- counted once.
    alternativePlan ranked
        | cardinality ranked > sharedChoiceBound = rankedPlan $ share ranked
        | otherwise = rankedPlan ranked

-- | Combine equally weighted non-empty alternatives.
oneof :: [Ranked a] -> Either RankedError (Ranked a)
oneof = frequency . map (1,)

-- | Return the exact number of stable ranks.
cardinality :: Ranked a -> Cardinality
cardinality = planCardinality . rankedPlan

-- | Decode one stable rank.
unrank :: Ranked a -> Rank -> Either RankedError a
unrank _ rank | rank < 0 = Left (NegativeRankedRank rank)
unrank ranked rank
    | not $ hasRank total rank = Left (RankedSelectionOutOfRange rank total)
    | otherwise = Right $ decode (rankedDecoder ranked) rank
  where
    total = cardinality ranked

-- | Decode a valid rank without range checks. Internal adapters check it first.
rankedValueAt :: Ranked a -> Rank -> a
rankedValueAt = decode . rankedDecoder

-- | Lower a ranked language to any supported sampling backend.
lower :: (GenBackend gen) => Ranked a -> gen a
lower = runValueSampler . rankedSampler

-- | Lower a ranked language while retaining the selected replay rank.
lowerWithRank :: (GenBackend gen) => Ranked a -> gen (RankedValue a)
lowerWithRank = runRankSampler . rankedSampler

{- | Structural shrink candidates for one rank.

Each candidate is a strictly smaller valid rank of the same language whose
member is no larger than the current member, measured in size.
Earlier alternatives come first at their smallest member, then each product
component shrinks on its own. Use 'smallerMembers' for every member of
strictly smaller size.
-}
shrinkRank :: Ranked a -> Rank -> [Rank]
shrinkRank ranked rank
    | not $ hasRank (cardinality ranked) rank = []
    | otherwise = shrinkPlanRank (rankedPlan ranked) rank

-- | Every member structurally smaller than the selected member, in size order.
smallerMembers :: Ranked a -> Rank -> [RankedValue a]
smallerMembers ranked rank
    | not $ hasRank (cardinality ranked) rank = []
    | otherwise = smallerPlanMembers (rankedSizeIndex ranked) (rankedPlan ranked) rank

-- | Structural size of the member at a valid rank.
sizeOfRank :: Ranked a -> Rank -> Maybe Size
sizeOfRank ranked rank
    | not $ hasRank (cardinality ranked) rank = Nothing
    | otherwise = Just $ planMemberSize (rankedPlan ranked) rank

-- | Build a ranked language from its plan and sampler, and compile the plan once.
makeRanked :: Plan a -> Sampler a -> Ranked a
makeRanked plan sampler =
    Ranked
        plan
        sampler
        (compilePlan (planCardinality plan) plan)
        (sizeIndex plan)

-- | Decode a valid rank with a compiled decoder.
decode :: RankDecoder a -> Rank -> a
decode (SmallDecoder _ select) = \(Rank rank) -> select $ fromInteger rank
decode (LargeDecoder _ select) = select
