{- | Rank the terms of a finite equality language without enumerating the
language: count the terms, decode a rank to a term, and give the rank of a
term.
-}
module Data.CFTA.Gen.Internal.Symbolic (symbolicRanked) where

import qualified Control.Monad.State.Lazy as State
import Data.Hashable (Hashable)
import Data.IORef (IORef, atomicModifyIORef', newIORef, readIORef)
import qualified Data.IntMap.Strict as IntMap
import Data.List ((!?))
import qualified Data.Map.Strict as Map
import Data.Maybe (mapMaybe)
import qualified Data.Set as Set
import Data.Typeable (Typeable)
import System.IO.Unsafe (unsafePerformIO)

import Data.CFTA.Constraint (
    Constraint (..),
    indicators,
 )
import qualified Data.CFTA.Equality as ECTA
import Data.CFTA.Index (Arity (..), Cardinality (..), Rank (..), VarIndex (..), childIndexes)
import Data.CFTA.Interned (Node (Node))
import Data.CFTA.Interned.Operations (intersect, intersectEdge, nodeEdges)
import Data.CFTA.Interned.Type (Edge, NodeId (..), edgeChildren, edgeConstraint, edgeSymbol, nodeIdentity, setChildren)
import Data.CFTA.Path (ChildIndex (..), Path (ConsPath, EmptyPath), adjustAt, path)
import qualified Data.CFTA.Ranked.Internal as Ranked
import Data.CFTA.Term (Term)
import qualified Data.CFTA.Term as Term

-- | A constructor context whose variables denote whole subtree languages.
data Fragment symbol = Variable VarIndex | Constructor symbol [Fragment symbol]
    deriving (Eq, Ord)

-- | A position in a constructor context.
data Target symbol = Target (Fragment symbol) Path
    deriving (Eq, Ord)

-- | A required position or an equality between two positions.
data Obligation symbol = Exists (Target symbol) | Equal (Target symbol) (Target symbol)
    deriving (Eq, Ord)

-- | Independent variable domains, substitutions, and pending equalities.
data Problem symbol = Problem
    { domains :: IntMap.IntMap (Node symbol)
    , bindings :: IntMap.IntMap (Fragment symbol)
    , nextVariable :: VarIndex
    , obligations :: [Obligation symbol]
    }

-- | A resolved position, an absent position, or a variable to expand.
data Resolution symbol = Resolved (Fragment symbol) | Absent | Expand VarIndex

-- | A normalized equality context and its independent domain identities.
type ProblemKey symbol = ([(VarIndex, NodeId)], [Obligation symbol])

-- | Counts shared by graph identity and normalized equality context.
data Counts symbol = Counts
    { graphCounts :: IntMap.IntMap Cardinality
    , contextCounts :: Map.Map (ProblemKey symbol) Cardinality
    }

-- | Empty caches scoped to one compiled language.
emptyCounts :: Counts symbol
emptyCounts = Counts IntMap.empty Map.empty

{- | The counts of one compiled language, shared by all its selections.

Every count is a function of interned graphs and normalized contexts, so
sharing the cache changes no result. Two concurrent selections can each
replace the cache; the loser's new counts are only computed again later.

The selections must share the cache. A selection conditions the graph on one
constructor at each position and counts the conditioned problems, and later
selections need many of the same counts. On an equality import of depth three
with overlapping alternatives and equalities below the children, selections
that each start from the counts of the total allocate 12.6 times as much, and
take 11 times as long, as selections that share the cache. The keys of the
cache are not known before the selections run: a key is a normalized context
of variables, nodes, and pending equalities. A pure memo table would need a
lazy trie over such keys, which the counter does not have, so the cache is an
'IORef' that 'unsafePerformIO' makes.
-}
newCountCache :: Counts symbol -> IORef (Counts symbol)
newCountCache counts = unsafePerformIO $ newIORef counts
{-# NOINLINE newCountCache #-}

-- | Run a selection or a ranking from the shared counts, and keep the counts it adds.
selectCached :: IORef (Counts symbol) -> State.State (Counts symbol) a -> a
selectCached cache selection = unsafePerformIO $ do
    counts <- readIORef cache
    let (result, grown) = State.runState selection counts
    atomicModifyIORef' cache $ const (grown, ())
    pure result
{-# NOINLINE selectCached #-}

-- | Requirements of the shared graph and its equality interpretation.
type Theory symbol = (Ord symbol, Hashable symbol, Typeable symbol)

{- | A constraint as a sum of equality indicators. Each term's sum must be zero
or one.

'indicators' keeps to this. It gives the path equalities of a constraint as
one summand, or none for a contradiction, and writes its Boolean guard as a
polynomial in the indicators of path equality. Such a polynomial has the value
zero or one on every term.

For example, the negation of equality is the unconstrained indicator minus
the equality indicator. This representation permits Boolean constraints without
enumerating the terms that fail an equality.

Each equality class requires that all its paths exist and hold equal subterms.
A singleton class requires only existence. The interpretation must preserve
conjunction: interpreting conjoined guards must give the pointwise product of
their indicators. 'indicators' preserves it, because conjunction merges the
equality classes and conjoins the guards. Checking this by enumerating the
language would defeat the compiler.
-}
interpret :: Constraint -> [(Integer, [[Path]])]
interpret constraint = case indicators constraint of
    Just summands -> summands
    Nothing ->
        error
            "cfta-generator bug in Data.CFTA.Gen.Internal.Symbolic.interpret: \
            \a constraint without indicators reached symbolic counting"

-- | A count times a signed coefficient of inclusion and exclusion.
scaled :: Integer -> Cardinality -> Cardinality
scaled coefficient (Cardinality count) = Cardinality $ coefficient * count

{- | Give each term of a finite equality language one rank.

The count expands a constructor context only along a constrained path. Equal
variables share the intersection of their domains. Inclusion-exclusion counts
overlapping alternatives once. To decode a rank, the function keeps one
constructor at a time in the graph. It constructs only the selected term and
keeps no table of terms.

Ranks follow the order of the constructors at each position, and the
constructors are ordered by arity, then by the given key. Two symbols of one
arity with equal keys stay apart, ordered by the symbol. Pass a key with a
stable order, such as the text of an interned symbol, so that ranks do not
depend on interning order.

The second result is the inverse of the ranks. It gives the rank of a term,
or 'Nothing' when the language does not contain the term. The two results
share one count cache.
-}
symbolicRanked ::
    (Theory symbol, Ord key) =>
    (symbol -> key) ->
    ECTA.Node symbol ->
    Either Ranked.RankedError (Ranked.Ranked (Term symbol), Term symbol -> Maybe Rank)
symbolicRanked order root = do
    ranked <- Ranked.fromIndexedOnDemand $ Ranked.Indexed total select
    pure (ranked, rankOf)
  where
    (total, counts) = State.runState (countNode root) emptyCounts
    cache = newCountCache counts
    select rank = selectCached cache $ selectTerm order root EmptyPath rank
    rankOf term = selectCached cache $ fmap (Rank . snd) <$> rankAt order root EmptyPath term 0

-- | Count a shared graph once per interned identity.
countNode ::
    (Theory symbol) => Node symbol -> State.State (Counts symbol) Cardinality
countNode node
    | null (nodeEdges node) = pure 0
    | otherwise = do
        counts <- State.get
        case IntMap.lookup ident $ graphCounts counts of
            Just count -> pure count
            Nothing -> do
                count <- countUnion (countEdge) $ nodeEdges node
                State.modify' $ \cache -> cache{graphCounts = IntMap.insert ident count $ graphCounts cache}
                pure count
  where
    NodeId ident = nodeIdentity node

-- | Count a union through distinct intersections of its alternatives.
countUnion ::
    (Theory symbol) =>
    (Edge symbol -> State.State (Counts symbol) Cardinality) ->
    [Edge symbol] ->
    State.State (Counts symbol) Cardinality
countUnion count edges =
    sum <$> traverse contribution (Map.toList $ foldl' add Map.empty edges)
  where
    contribution (edge, coefficient) = scaled coefficient <$> count edge
    add terms edge =
        Map.filter (/= 0)
            $ Map.insertWith (+) edge 1
            $ Map.unionWith (+) terms
            $ Map.fromListWith
                (+)
                [ (common, negate coefficient)
                | (previous, coefficient) <- Map.toList terms
                , Just common <- [intersectEdge edge previous]
                , not $ null $ nodeEdges $ Node [common]
                ]

-- | Convert an edge into independent child domains and path obligations.
countEdge ::
    (Theory symbol) => Edge symbol -> State.State (Counts symbol) Cardinality
countEdge edge =
    sum
        <$> traverse (\(coefficient, constraint) -> scaled coefficient <$> count constraint) (interpret $ edgeConstraint edge)
  where
    count constraint =
        solve $
            Problem
                (IntMap.fromList $ zip [0 ..] children)
                IntMap.empty
                (VarIndex (length children))
                (edgeObligations context constraint)
    children = edgeChildren edge
    context = Constructor (edgeSymbol edge) $ map Variable [0 .. VarIndex (length children) - 1]

-- | Preserve path existence, including classes that contain only one path.
edgeObligations :: Fragment symbol -> [[Path]] -> [Obligation symbol]
edgeObligations context = concatMap obligationsFor
  where
    obligationsFor paths = case map (Target context) paths of
        [] -> []
        first : rest -> Exists first : map (Equal first) rest

-- | Follow substitutions without expanding a variable's language.
resolve :: Problem symbol -> Target symbol -> Resolution symbol
resolve problem (Target (Variable variable) position) =
    case IntMap.lookup (fromEnum variable) $ bindings problem of
        Just fragment -> resolve problem $ Target fragment position
        Nothing -> case position of
            EmptyPath -> Resolved $ Variable variable
            _ -> Expand variable
resolve _ (Target fragment EmptyPath) = Resolved fragment
resolve problem (Target (Constructor _ children) (ConsPath (ChildIndex index) rest)) =
    case children !? index of
        Just child -> resolve problem $ Target child rest
        Nothing -> Absent

{- | Remove resolved path prefixes and renumber the remaining variables.

Constructor choices outside the remaining obligations cannot affect equality.
Removing those contexts lets different choices reuse the same count. Free
domains remain present because each still contributes independent choices.
-}
normalize :: (Ord symbol) => Problem symbol -> Maybe (Problem symbol)
normalize problem = do
    pending <- concat <$> traverse normalizeObligation (obligations problem)
    pure
        $ Problem renamedDomains IntMap.empty (VarIndex (IntMap.size renamedDomains))
        $ Set.toAscList
        $ Set.fromList pending
  where
    names = IntMap.fromList $ zip (IntMap.keys $ domains problem) [0 ..]
    renamedDomains = IntMap.mapKeysMonotonic (fromEnum . (names IntMap.!)) $ domains problem
    inline (Variable variable) = maybe (Variable variable) inline $ IntMap.lookup (fromEnum variable) $ bindings problem
    inline (Constructor symbol children) = Constructor symbol $ map inline children

    follow (Variable variable) position = case IntMap.lookup (fromEnum variable) $ bindings problem of
        Nothing -> Just $ Target (Variable variable) position
        Just fragment -> follow fragment position
    follow fragment EmptyPath = Just $ Target (inline fragment) EmptyPath
    follow (Constructor _ children) (ConsPath (ChildIndex index) rest) = (`follow` rest) =<< children !? index

    target (Target fragment position) = do
        Target resolved rest <- follow fragment position
        pure $ Target (rename resolved) rest
      where
        rename (Variable variable) = Variable $ names IntMap.! fromEnum variable
        rename (Constructor symbol children) = Constructor symbol $ map rename children
    required (Target _ EmptyPath) = []
    required remaining = [Exists remaining]
    normalizeObligation (Exists position) = required <$> target position
    normalizeObligation (Equal left right) = do
        first <- target left
        second <- target right
        pure $ if first == second then required first else [Equal (min first second) (max first second)]

-- | Share counts of equivalent contexts before expanding constrained variables.
solve ::
    (Theory symbol) =>
    Problem symbol -> State.State (Counts symbol) Cardinality
solve problem
    | any (null . nodeEdges) $ IntMap.elems $ domains problem = pure 0
    | otherwise = case normalize problem of
        Nothing -> pure 0
        Just normalized -> do
            cache <- State.get
            let key =
                    ( [(VarIndex variable, nodeIdentity node) | (variable, node) <- IntMap.toList $ domains normalized]
                    , obligations normalized
                    )
            case Map.lookup key $ contextCounts cache of
                Just count -> pure count
                Nothing -> do
                    count <- solveStep normalized
                    State.modify' $ \current -> current{contextCounts = Map.insert key count $ contextCounts current}
                    pure count

-- | Solve one normalized obligation, then multiply independent domain counts.
solveStep ::
    (Theory symbol) =>
    Problem symbol -> State.State (Counts symbol) Cardinality
solveStep problem = case obligations problem of
    [] -> product <$> traverse (countNode) (IntMap.elems $ domains problem)
    Exists target : rest -> case resolve problem target of
        Absent -> pure 0
        Expand variable -> expandVariable problem variable
        Resolved _ -> solve problem{obligations = rest}
    Equal left right : rest -> case (resolve problem left, resolve problem right) of
        (Absent, _) -> pure 0
        (_, Absent) -> pure 0
        (Expand variable, _) -> expandVariable problem variable
        (_, Expand variable) -> expandVariable problem variable
        (Resolved first, Resolved second) -> unify problem{obligations = rest} first second

-- | Merge whole subtree variables or compare constructor contexts.
unify ::
    (Theory symbol) =>
    Problem symbol ->
    Fragment symbol ->
    Fragment symbol ->
    State.State (Counts symbol) Cardinality
unify problem (Variable left) (Variable right)
    | left == right = solve problem
    | otherwise =
        solve
            problem
                { domains = IntMap.insert (fromEnum right) common $ IntMap.delete (fromEnum left) $ domains problem
                , bindings = IntMap.insert (fromEnum left) (Variable right) $ bindings problem
                }
  where
    common =
        (domains problem IntMap.! fromEnum left)
            `intersect` (domains problem IntMap.! fromEnum right)
unify problem (Variable variable) fragment
    | occurs problem variable fragment = pure 0
    | otherwise =
        expandVariable
            problem{obligations = Equal (Target (Variable variable) EmptyPath) (Target fragment EmptyPath) : obligations problem}
            variable
unify problem fragment (Variable variable) = unify problem (Variable variable) fragment
unify problem (Constructor left children) (Constructor right others)
    | left /= right || length children /= length others = pure 0
    | otherwise =
        solve
            problem
                { obligations = zipWith (\a b -> Equal (Target a EmptyPath) (Target b EmptyPath)) children others <> obligations problem
                }

-- | Reject an equality between a finite tree and its proper subtree.
occurs :: Problem symbol -> VarIndex -> Fragment symbol -> Bool
occurs problem variable fragment = case resolve problem $ Target fragment EmptyPath of
    Resolved (Variable other) -> variable == other
    Resolved (Constructor _ children) -> any (occurs problem variable) children
    _ -> False

-- | Expose one constrained variable's root, preserving overlaps symbolically.
expandVariable ::
    (Theory symbol) =>
    Problem symbol -> VarIndex -> State.State (Counts symbol) Cardinality
expandVariable problem variable =
    countUnion expand $ nodeEdges $ domains problem IntMap.! fromEnum variable
  where
    expand edge =
        sum
            <$> traverse
                (\(coefficient, constraint) -> scaled coefficient <$> expandWith edge constraint)
                (interpret $ edgeConstraint edge)
    expandWith edge constraint =
        solve
            problem
                { domains = IntMap.union fresh $ IntMap.delete (fromEnum variable) $ domains problem
                , bindings = IntMap.insert (fromEnum variable) context $ bindings problem
                , nextVariable = nextVariable problem + VarIndex (length children)
                , obligations = edgeObligations context constraint <> obligations problem
                }
      where
        children = edgeChildren edge
        variables = take (length children) [nextVariable problem ..]
        fresh = IntMap.fromList $ zip (map fromEnum variables) children
        context = Constructor (edgeSymbol edge) $ map Variable variables

-- | Keep one constructor at a selected position in the graph.
condition :: (Theory symbol) => Path -> (symbol, Arity) -> Node symbol -> Node symbol
condition EmptyPath (symbol, arity) node =
    Node [edge | edge <- nodeEdges node, edgeSymbol edge == symbol, Arity (length (edgeChildren edge)) == arity]
condition (ConsPath index@(ChildIndex child) rest) constructor node =
    Node
        [ setChildren edge $ adjustAt index (condition rest constructor) children
        | edge <- nodeEdges node
        , let children = edgeChildren edge
        , Just _ <- [children !? child]
        ]

{- | Read possible constructors at a path without enumerating subterms, by
arity, then in key order. Two symbols with one key stay apart, in symbol
order, so a key that does not tell symbols apart loses no constructor.
-}
constructorsAt ::
    (Theory symbol, Ord key) => (symbol -> key) -> Path -> Node symbol -> [(symbol, Arity)]
constructorsAt order position root =
    map snd
        $ Map.toAscList
        $ Map.fromList
            [ ((arity, order symbol, symbol), (symbol, arity))
            | edge <- nodeEdges $ project position root
            , let symbol = edgeSymbol edge
                  arity = Arity $ length $ edgeChildren edge
            ]

-- | An upper bound on the subtree language at one position.
project :: (Theory symbol) => Path -> Node symbol -> Node symbol
project position root = Node $ concatMap nodeEdges $ Set.toList $ go position $ Set.singleton root
  where
    go EmptyPath nodes = nodes
    go (ConsPath (ChildIndex index) rest) nodes =
        go rest
            $ Set.fromList
            $ mapMaybe
                ((!? index) . edgeChildren)
                [edge | node <- Set.toList nodes, edge <- nodeEdges node]

-- | Select one term in constructor order, carrying counts for the remaining suffix.
selectTerm ::
    (Theory symbol, Ord key) =>
    (symbol -> key) ->
    Node symbol ->
    Path ->
    Rank ->
    State.State (Counts symbol) (Term symbol)
selectTerm order root position (Rank rank) = do
    ~(term, _, _) <- selectAt order root position rank
    pure term

-- | Restrict the selected prefix and decode only its selected descendants.
selectAt ::
    (Theory symbol, Ord key) =>
    (symbol -> key) ->
    Node symbol ->
    Path ->
    Integer ->
    State.State (Counts symbol) (Term symbol, Node symbol, Integer)
selectAt order root position rank = do
    let local = project position root
    count <- countNode local
    if count == 1
        then do
            counts <- State.get
            pure (State.evalState (selectUniqueAt order local EmptyPath) counts, root, rank)
        else choose rank $ constructorsAt order position root
  where
    choose _ [] =
        error
            "cfta-generator bug in Data.CFTA.Gen.Internal.Symbolic.selectAt: \
            \a rank outside the language"
    choose remaining (constructor@(symbol, arity) : rest) = do
        let restricted = condition position constructor root
        Cardinality count <- countNode restricted
        if remaining >= count
            then choose (remaining - count) rest
            else do
                ~(children, final, suffixRank) <- selectChildren restricted remaining (childIndexes arity)
                pure (Term.Node symbol children, final, suffixRank)
    selectChildren graph remaining [] = pure ([], graph, remaining)
    selectChildren graph remaining (index : rest) = do
        ~(term, restricted, suffixRank) <- selectAt order graph (position <> path [index]) remaining
        ~(children, final, finalRank) <- selectChildren restricted suffixRank rest
        pure (term : children, final, finalRank)

{- | Add the count of the terms that 'selectAt' puts before a subterm, and
restrict the graph as 'selectAt' does.

The result is the restricted graph and the new count. It is 'Nothing' when no
term of the graph has the subterm at the position.
-}
rankAt ::
    (Theory symbol, Ord key) =>
    (symbol -> key) ->
    Node symbol ->
    Path ->
    Term symbol ->
    Integer ->
    State.State (Counts symbol) (Maybe (Node symbol, Integer))
rankAt order root position term@(Term.Node symbol children) before = do
    let local = project position root
    count <- countNode local
    if count == 1
        then do
            counts <- State.get
            let unique = State.evalState (selectUniqueAt order local EmptyPath) counts
            pure $ if unique == term then Just (root, before) else Nothing
        else case break (== (symbol, Arity (length children))) $ constructorsAt order position root of
            (_, []) -> pure Nothing
            (earlier, constructor : _) -> do
                skipped <- traverse (\other -> countNode $ condition position other root) earlier
                let restricted = condition position constructor root
                    Cardinality skippedCount = sum skipped
                restrictedCount <- countNode restricted
                if restrictedCount == 0
                    then pure Nothing
                    else rankChildren restricted (before + skippedCount) $ zip [0 ..] children
  where
    rankChildren graph rank [] = pure $ Just (graph, rank)
    rankChildren graph rank ((index, child) : rest) = do
        result <- rankAt order graph (position <> path [index]) child rank
        case result of
            Nothing -> pure Nothing
            Just (restricted, suffixRank) -> rankChildren restricted suffixRank rest

-- | Decode a singleton language without traversing unobserved sibling trees.
selectUniqueAt ::
    (Theory symbol, Ord key) =>
    (symbol -> key) ->
    Node symbol ->
    Path ->
    State.State (Counts symbol) (Term symbol)
selectUniqueAt order root position = choose $ constructorsAt order position root
  where
    choose [] =
        error
            "cfta-generator bug in Data.CFTA.Gen.Internal.Symbolic.selectUniqueAt: \
            \a language with one member has no constructor"
    choose (constructor@(symbol, arity) : rest) = do
        count <- countNode $ condition position constructor root
        if count == 0
            then choose rest
            else do
                counts <- State.get
                pure $
                    Term.Node
                        symbol
                        [ State.evalState (selectUniqueAt order root $ position <> path [index]) counts
                        | index <- childIndexes arity
                        ]
