{- | The argument chains of a grouped application.

One chain holds the matched group of every signature component, in order. The
folds over a chain count, sample, and decode the joined ranks. Only
'lookupArgs' and 'mapChain' are shared by finite and recursive argument
families. The support, inspection, and counting folds have one version for each.
-}
module Data.CFTA.Gen.Internal.Chain (
    -- * Chains
    ArgMaps (..),
    ArgChain (..),
    ArgStatics,
    lookupArgs,
    mapChain,

    -- * Finite chains
    chainLength,
    chainMass,
    chainSupports,
    chainInspections,
    chainRootCounts,
    chainCardinality,
    chainUniformMass,
    chainSampler,
    chainPlan,
    chainDecoder,
    selectChain,
    chainRanks,
    joinKeysMatch,

    -- * Recursive chains
    recursiveChainTerms,
    recursiveSupports,
    recursiveInspections,
    recursiveChainProduct,
    recursiveChainWeighted,
    recursiveChainMassWeighted,
    recursiveChainConstruction,
) where

import qualified Data.IntSet as IntSet
import Data.Kind (Type)
import Data.List (sort)
import qualified Data.Map.Strict as Map
import Data.Sequence (Seq (..))

import Data.CFTA.Equality (Node)
import Data.CFTA.Gen.Error (GenError (..))
import Data.CFTA.Gen.Internal.Bucket (KeyedBucket (..))
import Data.CFTA.Gen.Internal.Inspection
import Data.CFTA.Gen.Internal.Recursive
import Data.CFTA.Gen.Internal.Static
import Data.CFTA.Gen.Label (ComponentIndex, Label (..))
import Data.CFTA.Gen.Sig (Sig (..))
import Data.CFTA.Index (ArgumentIndex (..), Cardinality, Rank, pairRank, splitRank)
import Data.CFTA.Ranked.Internal.Decoder (Plan (..))
import Data.CFTA.Ranked.Internal.Sampler
import Data.CFTA.Ranked.Internal.Size (SizeIndex (minimumMemberSize), mapIndex, productIndex, productPosition)
import Data.CFTA.Term (Term)
import qualified Data.CFTA.Term as Term

{- | Group maps of every argument family, threaded through the operation type.

The group payload is a parameter: finite argument families carry a
@KeyedBucket@, recursive ones a @KeyedRecursive@. Only the functions that do not
depend on the payload are shared. The other folds have one version for each.
-}
data ArgMaps f (argKeys :: [Type]) operation result where
    MapsNil :: ArgMaps f '[] result result
    MapsCons ::
        (Ord argKey) =>
        Map.Map argKey (f arg) ->
        ArgMaps f argKeys operation result ->
        ArgMaps f (argKey ': argKeys) (arg -> operation) result

-- | The matched group of every argument family, in signature order.
data ArgChain f operation result where
    ChainNil :: ArgChain f result result
    ChainCons ::
        f arg ->
        ArgChain f operation result ->
        ArgChain f (arg -> operation) result

-- | The matched finite group of every argument family, in signature order.
type ArgStatics symbol = ArgChain (Static symbol)

-- | Find the argument group for every signature key.
lookupArgs ::
    Sig argKeys resultKey ->
    ArgMaps f argKeys operation result ->
    Maybe (ArgChain f operation result)
lookupArgs (key :-> _) (MapsCons groups MapsNil) = do
    group <- Map.lookup key groups
    Just $ ChainCons group ChainNil
lookupArgs (key :* rest) (MapsCons groups restMaps) = do
    group <- Map.lookup key groups
    chain <- lookupArgs rest restMaps
    Just $ ChainCons group chain

-- | Replace every group in a chain, keeping its shape.
mapChain :: (forall x. f x -> g x) -> ArgChain f operation result -> ArgChain g operation result
mapChain _ ChainNil = ChainNil
mapChain transform (ChainCons group rest) =
    ChainCons (transform group) (mapChain transform rest)

-- | Read every group of a chain, in order.
chainToList :: (forall x. f x -> b) -> ArgChain f operation result -> [b]
chainToList _ ChainNil = []
chainToList read_ (ChainCons group rest) = read_ group : chainToList read_ rest

-- | The product of the matched groups' probability masses.
chainMass :: ArgChain (KeyedBucket symbol) operation result -> Rational
chainMass = product . chainToList keyedBucketMass

-- | Number of arguments in the chain.
chainLength :: ArgStatics symbol operation result -> Int
chainLength = length . chainToList (const ())

-- | ECTA support of every argument group, in order.
chainSupports ::
    ArgStatics symbol operation result -> [Node (Label symbol)]
chainSupports = chainToList staticSupport

-- | The root count of every argument group, in order.
chainRootCounts :: ArgStatics symbol operation result -> [RootCount]
chainRootCounts = chainToList staticRootCount

-- | Diagnostic metadata of each matched finite argument group.
chainInspections ::
    ArgStatics symbol operation result -> [Inspection symbol]
chainInspections = chainToList staticInspection

-- | Product of the argument group cardinalities.
chainCardinality :: ArgStatics symbol operation result -> Cardinality
chainCardinality = product . chainToList (outcomeCardinality . staticOutcomes)

-- | Product of the argument uniform masses, when all are uniform.
chainUniformMass :: ArgStatics symbol operation result -> Maybe Rational
chainUniformMass = fmap product . sequence . chainToList (outcomeUniformMass . staticOutcomes)

{- | Compose the mixed-radix rank sampler as a left 'productSampler' fold.

The composed rank is @operationRank@ most significant, then argument ranks
left to right, matching 'chainDecoder'.
-}
chainSampler ::
    Sampler operation -> ArgStatics symbol operation result -> Sampler result
chainSampler sampler ChainNil = sampler
chainSampler sampler (ChainCons static rest) =
    chainSampler
        ( productSampler
            (outcomeCardinality $ staticOutcomes static)
            sampler
            (outcomeSampler $ staticOutcomes static)
        )
        rest

{- | Mirror 'chainSampler' as plan structure, one product per argument.

Each argument is a shared plan: the compiled decoder of the join calls the
compiled decoder of the argument group, and the size walks of the join read
the size classes of the group. Many joins use the same group, for
example every step of a trace uses the groups of the step before it. A plan
that copied the group's plan into each join would compile one copy for each
path to the group, and the decoder would keep each copy that a sample reached.
For 20,000 traces of length 20, that kept 414 MB, against 2.3 MB with sharing.
-}
chainPlan :: Plan operation -> ArgStatics symbol operation result -> Plan result
chainPlan plan ChainNil = plan
chainPlan plan (ChainCons static rest) =
    chainPlan
        ( PlanAp
            (outcomeCardinality outcomes)
            plan
            ( PlanShared
                (outcomeCardinality outcomes)
                (outcomeDecoder outcomes)
                (outcomeSizeIndex outcomes)
                (outcomePlan outcomes)
            )
        )
        rest
  where
    outcomes = staticOutcomes static

-- | Build a rank decoder once, capturing every suffix cardinality.
chainDecoder ::
    ArgStatics symbol operation result -> operation -> Rank -> result
chainDecoder ChainNil = const
chainDecoder (ChainCons static ChainNil) =
    let valueAt = outcomeValueAt $ staticOutcomes static
     in \operation index -> operation $ valueAt index
chainDecoder (ChainCons first (ChainCons second ChainNil)) =
    let firstValueAt = outcomeValueAt $ staticOutcomes first
        secondOutcomes = staticOutcomes second
        secondCardinality = outcomeCardinality secondOutcomes
        secondValueAt = outcomeValueAt secondOutcomes
     in \operation index ->
            let (firstIndex, secondIndex) = splitRank secondCardinality index
             in operation (firstValueAt firstIndex) (secondValueAt secondIndex)
chainDecoder (ChainCons static rest) =
    let decodeRest = chainDecoder rest
        suffixCardinality = chainCardinality rest
        valueAt = outcomeValueAt $ staticOutcomes static
     in \partial index ->
            let (here, there) = splitRank suffixCardinality index
             in decodeRest (partial $ valueAt here) there

{- | The mixed-radix ranks of the argument terms of a join, in ascending
order: the argument ranks left to right, as 'selectChain' reads them. The
keys of the arguments are not checked here: see 'joinKeysMatch'.
-}
chainRanks ::
    ArgStatics symbol operation result ->
    [Term (Label symbol)] ->
    [CheckedRank Rank]
chainRanks ChainNil [] = [CheckedRank 0 True]
chainRanks (ChainCons static rest) (Term.Node ArgKeyed [_, term] : terms) =
    checkedProduct
        (pairRank $ chainCardinality rest)
        (outcomeRanks (staticOutcomes static) $ WholeTerm term)
        (chainRanks rest terms)
chainRanks _ _ = []

{- | Whether the children of an n-way join carry the keys of the component in
order: the keys after the operation, and the key of each argument.
-}
joinKeysMatch :: ComponentIndex -> [Term (Label symbol)] -> [Term (Label symbol)] -> Bool
joinKeysMatch component keys argumentNodes =
    length keys == length argumentNodes
        && and (zipWith isKey [0 :: Int ..] keys)
        && and (zipWith isArgument [0 ..] argumentNodes)
  where
    -- The positions are enumerated as 'Int' so that the list fuses away.
    isKey position (Term.Node (ArgKey component' position') []) = component' == component && position' == ArgumentIndex position
    isKey _ _ = False
    isArgument position (Term.Node ArgKeyed [key, _]) = isKey position key
    isArgument _ _ = False

selectChain ::
    operation ->
    ArgStatics symbol operation result ->
    [Term (Label symbol)] ->
    Rank ->
    Either GenError ([Term (Label symbol)], [Term (InspectionSymbol symbol)], Rational, result)
selectChain value ChainNil _ _ = Right ([], [], 1, value)
selectChain partial (ChainCons static rest) (keyTerm : keyTerms) index = do
    let (here, there) = splitRank (chainCardinality rest) index
    outcome <- outcomeSelect (staticOutcomes static) here
    (terms, inspections, mass, value) <- selectChain (partial $ outcomeValue outcome) rest keyTerms there
    pure
        ( Term.Node ArgKeyed [keyTerm, outcomeTerm outcome] : terms
        , Term.Node
            (plainSymbol ArgKeyed)
            [ fmap (\symbol -> InspectionSymbol symbol $ inspectionName $ staticInspection static) keyTerm
            , outcomeInspection outcome
            ]
            : inspections
        , outcomeMass outcome * mass
        , value
        )
selectChain _ (ChainCons _ _) [] _ =
    error
        "cfta-generator bug in Data.CFTA.Gen.Internal.Chain.selectChain: \
        \fewer key terms than arguments"

{- | The terms of one joined component of a recursive keyed application.

The term of a member is an n-way join, as for a finite join: the operation
term before the argument keys, then each argument term with its key. The value
indexes of the operation and of the arguments give the counts of the product
chain. 'Nothing' means that an argument does not track terms.
-}
recursiveChainTerms ::
    ComponentIndex ->
    SizeIndex operation ->
    RecursiveTerms symbol ->
    ArgChain (KeyedRecursive symbol) operation result ->
    Maybe (RecursiveTerms symbol)
recursiveChainTerms componentIndex operationIndex operationTerms arguments = do
    argumentTerms <- chainTerms arguments
    let keyTerms = [Term.Node (ArgKey componentIndex position) [] | position <- map ArgumentIndex [0 .. length argumentTerms - 1]]
        -- The term index accumulates the argument terms in order.
        accumulated =
            foldl
                ( \partial (_, terms) ->
                    productIndex
                        (mapIndex (\(operation, earlier) argument -> (operation, earlier <> [argument])) partial)
                        (recursiveTermIndex terms)
                )
                (mapIndex (,[]) $ recursiveTermIndex operationTerms)
                argumentTerms
        joinTerm (operation, argumentTerms') =
            Term.Node JoinN $
                Term.Node CenterKeyed (operation : keyTerms)
                    : zipWith (\key argument -> Term.Node ArgKeyed [key, argument]) keyTerms argumentTerms'
        -- The counts of the product chain after each argument.
        chainIndexes =
            scanl
                (\partial (index, _) -> productIndex (mapIndex const partial) index)
                (mapIndex (const ()) operationIndex)
                argumentTerms
        positions view = sort $ case view of
            WholeTerm (Term.Node JoinN children) -> childrenPositions children
            WholeTerm _ -> []
            LabelledView children -> childrenPositions children
            SpineView (term :<| Empty) -> positions $ WholeTerm term
            SpineView _ -> []
        childrenPositions (Term.Node CenterKeyed centre : argumentNodes)
            | operation : keys <- centre
            , Just arguments' <- traverse argumentOf argumentNodes
            , length arguments' == length argumentTerms =
                let keysChecked = joinKeysMatch componentIndex keys argumentNodes
                 in foldl
                        ( \partialPositions (partialIndex, (argumentIndex, terms), argument) ->
                            checkedProduct
                                (productPosition partialIndex argumentIndex)
                                partialPositions
                                (recursiveTermPositions terms $ WholeTerm argument)
                        )
                        [ CheckedRank position (checked && keysChecked)
                        | CheckedRank position checked <- recursiveTermPositions operationTerms $ WholeTerm operation
                        ]
                        (zip3 chainIndexes argumentTerms arguments')
        childrenPositions _ = []
        argumentOf (Term.Node ArgKeyed [_, argument]) = Just argument
        argumentOf _ = Nothing
    pure $ RecursiveTerms (mapIndex joinTerm accumulated) positions
  where
    chainTerms ::
        ArgChain (KeyedRecursive symbol) operation' result' -> Maybe [(SizeIndex (), RecursiveTerms symbol)]
    chainTerms ChainNil = Just []
    chainTerms (ChainCons recursive rest) = do
        let language = keyedRecursiveLanguage recursive
        terms <- recursiveTerm language
        ((mapIndex (const ()) $ recursiveIndex language, terms) :) <$> chainTerms rest

-- | The support of every matched recursive argument group, in order.
recursiveSupports ::
    ArgChain (KeyedRecursive symbol) operation result -> [Node (Label symbol)]
recursiveSupports = chainToList (recursiveSupport . keyedRecursiveLanguage)

-- | Diagnostic metadata of each matched recursive argument group.
recursiveInspections ::
    ArgChain (KeyedRecursive symbol) operation result -> [Inspection symbol]
recursiveInspections = chainToList (recursiveInspection . keyedRecursiveLanguage)

{- | Consume the argument groups into the operation, left to right: the size
index, the masses, and the sampler of the product. The index of the operation
gives the smallest size of each product. One fold builds the three, so they
share each product index.
-}
recursiveChainProduct ::
    SizeIndex operation ->
    MassIndex ->
    SampleIndex operation ->
    ArgChain (KeyedRecursive symbol) operation result ->
    (SizeIndex result, MassIndex, SampleIndex result)
recursiveChainProduct index mass sampling ChainNil = (index, mass, sampling)
recursiveChainProduct index mass sampling (ChainCons recursive rest) =
    recursiveChainProduct nextIndex nextMass nextSampling rest
  where
    recursive' = keyedRecursiveLanguage recursive
    nextIndex = productIndex index $ recursiveIndex recursive'
    nextMass = productMassIndex (minimumMemberSize nextIndex) mass $ keyedRecursiveMasses recursive
    nextSampling =
        productMassSampleIndex
            index
            (massAtSize mass)
            sampling
            (recursiveIndex recursive')
            (keyedRecursiveMassAtSize recursive)
            (recursiveSampling recursive')

-- | Whether any recursive argument contains a weighted atomic choice.
recursiveChainWeighted ::
    ArgChain (KeyedRecursive symbol) operation result -> Bool
recursiveChainWeighted = or . chainToList (recursiveWeighted . keyedRecursiveLanguage)

-- | Whether the mass of a recursive argument differs from its member counts.
recursiveChainMassWeighted ::
    ArgChain (KeyedRecursive symbol) operation result -> Bool
recursiveChainMassWeighted = or . chainToList keyedRecursiveMassWeighted

-- | The active construction occurrences reached by the recursive arguments.
recursiveChainConstruction :: ArgChain (KeyedRecursive symbol) operation result -> IntSet.IntSet
recursiveChainConstruction = IntSet.unions . chainToList (recursiveConstruction . keyedRecursiveLanguage)
