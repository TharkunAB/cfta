{-# LANGUAGE NoImplicitPrelude #-}

{- | Qualified applicative do-notation for generators.

Enable @ApplicativeDo@ and @QualifiedDo@ and qualify the block with a module
that exports these operators: this module, or one of the @QuickCheck@
facades, which re-export it. A block builds the applicative product of its
statements, and 'Data.CFTA.Gen.node' closes it with one constructor:

@
import qualified Data.CFTA.Gen.QuickCheck as FTAGen

pairs = FTAGen.node "pair" $ FTAGen.do
    left <- choices
    right <- choices
    FTAGen.pure (left, right)
@

When the first bind chooses an operation family keyed by
'Data.CFTA.Gen.Sig', the block is one operation application of any arity:

@
binaryLayer children = ECTAGen.node "binary-application" $ ECTAGen.do
    operation <- binaryFunctionsBySignature
    left <- children
    right <- children
    ECTAGen.pure (compileBinary operation left right)
@

Statements are independent: the block builds the same applicative product
as @<*>@ composition, so a later generator cannot use an earlier bound value.
The final statement must use the /qualified/ 'pure' or 'return'; GHC does not
recognize the unqualified names inside a qualified block.
-}
module Data.CFTA.Gen.Do (
    GenApply (..),
    Applying,
    fmap,
    pure,
    return,
    (>>),
    (>>=),
    join,
    fail,
) where

import Data.Kind (Type)
import GHC.TypeError (ErrorMessage (..), Unsatisfiable, unsatisfiable)
import Prelude (Ord, type (~))
import qualified Prelude

import Data.CFTA.Gen (Args (..), Gen, Grouped, Sig, apply)
import Data.Hashable (Hashable)
import Data.Typeable (Typeable)

-- | Map a generator.
fmap :: (Prelude.Functor f) => (a -> b) -> f a -> f b
fmap = Prelude.fmap

-- | The result of a block with no more binds: the language of one value.
pure :: (Hashable symbol, Typeable symbol) => a -> Gen symbol a
pure = Prelude.pure

-- | Synonym for 'pure'.
return :: (Hashable symbol, Typeable symbol) => a -> Gen symbol a
return = pure

{- | Sequence two generators, keeping only the second value.

The discarded choice still counts: the sequence of an
@m@-outcome and an @n@-outcome generator has cardinality @m * n@.
-}
(>>) :: (Prelude.Functor f, GenApply f g h) => f a -> g b -> h b
first >> second = fmap (\_ value -> value) first <*> second

{- | Applicative application for do-notation.

For a 'Gen', this is the '<*>' of 'Prelude.Applicative'. For a grouped
operation family, it takes one argument family at a time. After the last
argument, it builds one 'apply' join, and it builds no join before that.
GHC selects the instance by the 'Sig' in the key of the operation family. The
key list of the signature gives the number of arguments that remain. The type
checker requires that the key of each argument family is the key at its
position in the signature.
-}
class GenApply f g h | f g -> h where
    -- | Apply one generated function layer to one generated argument layer.
    (<*>) :: f (a -> b) -> g a -> h b

-- The argument is a fresh variable equated in the context rather than
-- repeated in the head, so instance selection needs only the function side.
-- A statement built from a source whose theory is still open, such as
-- @elements [..]@, then takes the theory of the block.
instance
    (argument ~ Gen symbol, Hashable symbol, Typeable symbol) =>
    GenApply (Gen symbol) argument (Gen symbol)
    where
    (<*>) = (Prelude.<*>)

{- | An operation family that has absorbed a prefix of its argument families
and awaits the families for @pendingKeys@.

A block result of this type means the do-block bound fewer arguments than the
operation's signature arity.
-}
newtype Applying symbol (pendingKeys :: [Type]) resultKey b
    = Applying
        ( forall result.
          Args symbol pendingKeys b result ->
          Grouped symbol resultKey result
        )

-- The argument family is likewise a fresh variable equated in the context, so
-- instance selection needs only the operation side. An argument written as
-- @keyed 0 ...@, whose key type is still open and would default to Integer,
-- then resolves against the operation's signature the way it does when
-- @apply@ is written out, and its theory is the operation's.
instance
    ( argument ~ Grouped symbol argKey
    , Ord argKey
    , Ord resultKey
    , Hashable symbol
    , Typeable symbol
    ) =>
    GenApply
        (Grouped symbol (Sig '[argKey] resultKey))
        argument
        (Grouped symbol resultKey)
    where
    operations <*> argument = apply operations (argument :& ANil)

instance
    ( argument ~ Grouped symbol argKey
    , Ord argKey
    , Ord resultKey
    , Hashable symbol
    , Typeable symbol
    ) =>
    GenApply
        (Grouped symbol (Sig (argKey ': nextKey ': pendingKeys) resultKey))
        argument
        (Applying symbol (nextKey ': pendingKeys) resultKey)
    where
    operations <*> argument =
        Applying (\rest -> apply operations (argument :& rest))

instance
    (argument ~ Grouped symbol argKey, Ord argKey) =>
    GenApply
        (Applying symbol '[argKey] resultKey)
        argument
        (Grouped symbol resultKey)
    where
    Applying continue <*> argument = continue (argument :& ANil)

instance
    (argument ~ Grouped symbol argKey, Ord argKey) =>
    GenApply
        (Applying symbol (argKey ': nextKey ': pendingKeys) resultKey)
        argument
        (Applying symbol (nextKey ': pendingKeys) resultKey)
    where
    Applying continue <*> argument =
        Applying (\rest -> continue (argument :& rest))

type NotApplicativeMessage =
    'Text "This qualified do-block cannot be desugared applicatively."
        ':$$: 'Text "Common causes, most likely first:"
        ':$$: 'Text "  * The block does not end with a qualified pure:"
        ':$$: 'Text "    write M.pure <expr> for the module alias M of the"
        ':$$: 'Text "    block (an unqualified pure or return is not"
        ':$$: 'Text "    recognized inside M.do)."
        ':$$: 'Text "  * ApplicativeDo is not enabled in this module;"
        ':$$: 'Text "    qualified do-notation needs it alongside QualifiedDo."
        ':$$: 'Text "  * A statement binds a strict pattern, as in"
        ':$$: 'Text "    (a, b) <- match ...: ApplicativeDo needs a lazy one,"
        ':$$: 'Text "    so write ~(a, b) <- match ... instead."
        ':$$: 'Text "  * The block contains a let statement, which ApplicativeDo"
        ':$$: 'Text "    has nowhere to place: bind the value in the final"
        ':$$: 'Text "    M.pure, or in a where clause."
        ':$$: 'Text "  * A later generator uses a value generated earlier."
        ':$$: 'Text "    Generators are applicative, so choices are"
        ':$$: 'Text "    independent. Relate values with the node's guard,"
        ':$$: 'Text "    with match, relate, or apply, or embed a monadic"
        ':$$: 'Text "    QuickCheck Gen with fromGen (that region becomes opaque)."

type CannotFailMessage =
    'Text "This pattern can fail, and a generator cannot discard"
        ':$$: 'Text "outcomes. Bind a total pattern and condition values"
        ':$$: 'Text "with the node's guard, match, or relate instead."

-- | Rejected at compile time: generators have no bind.
(>>=) :: (Unsatisfiable NotApplicativeMessage) => generator -> continuation -> result
(>>=) = unsatisfiable

-- | Rejected at compile time: generators have no bind.
join :: (Unsatisfiable NotApplicativeMessage) => generator -> result
join = unsatisfiable

-- | Rejected at compile time: generators cannot discard outcomes.
fail :: (Unsatisfiable CannotFailMessage) => message -> result
fail = unsatisfiable
