{- | Finite languages and the builders that compose them.

A t'Static' is an ECTA support paired with an t'OutcomeIndex' that counts,
selects, decodes, and samples outcomes by rank. Each basic finite
combinator of "Data.CFTA.Gen" is one function here: pure, elements,
frequency, fmap, application, pay, atomic, and node. Joins, grouping, and
recursion live in "Data.CFTA.Gen.Internal.Join", "Data.CFTA.Gen.Internal.Grouped",
"Data.CFTA.Gen.Internal.Bucket", and "Data.CFTA.Gen.Internal.Recur". The
sampling engine itself lives in
"Data.CFTA.Ranked.Internal.Sampler".
-}
module Data.CFTA.Gen.Internal.Static (
    -- * Languages
    Outcome (..),
    OutcomeIndex (..),
    CheckedRank (..),
    checkedProduct,
    TermView (..),
    mkOutcomeIndex,
    leafRanks,
    enumeratedRanks,
    seqPlan,
    Static (..),
    staticSampling,
    RootCount (..),
    termRootCount,
    addRootCounts,
    commonRootCount,

    -- * Building languages
    pureStatic,
    indexedStatic,
    indexedStaticWithLabels,
    pointsStatic,
    holeStatic,
    termStatic,
    userTerm,
    applyStatic,
    frequencyStatic,
    frequencyStaticWithMasses,
    pairStaticWithMasses,
    mapStatic,
    atomicStatic,
    resizedStatic,
    labelStatic,
    labelStaticMatching,
    payStatic,

    -- * Sampling and lowering
    sequenceSampler,
    sampleStatic,
    sampleStaticWithRank,
    drawUniform,
    drawUniformWithRank,

    -- * Inspection
    enumerateOutcomeIndex,
    enumerateWeighted,
    compileOutcomes,
    commonValue,
    checkIndex,
    normalize,
    integerOutcomes,
) where

import Control.Monad (zipWithM)
import qualified Data.Bifunctor as Bifunctor
import Data.Foldable (toList)
import Data.Hashable (Hashable)
import Data.Maybe (fromMaybe, isJust)
import Data.Sequence (Seq (..))
import qualified Data.Sequence as Sequence
import Data.Text (Text)
import Data.Typeable (Typeable)

import Data.CFTA.Equality (Edge (Edge), Node (Node))
import Data.CFTA.Gen.Error (GenError (..))
import Data.CFTA.Gen.Internal.Inspection
import Data.CFTA.Gen.Internal.Support (labelSupport, labelTerm, labelTermWith, labelledChildren, relabel, spineChildren)
import Data.CFTA.Gen.Label (ChoiceIndex, Label (..))
import Data.CFTA.Index (
    Cardinality (..),
    ClassRank (..),
    Rank (..),
    RankOffset (..),
    Size,
    Weight,
    everyRank,
    hasRank,
    nextOffset,
    offsetRank,
    pairRank,
    rebaseRank,
    splitRank,
 )
import Data.CFTA.Ranked.Internal (Indexed (..))
import qualified Data.CFTA.Ranked.Internal as Ranked
import Data.CFTA.Ranked.Internal.Decoder (
    Plan (..),
    RankDecoder (..),
    RankedValue (RankedValue, rankedValue),
    SizeClass (..),
    compilePlan,
    offsetRankedValue,
    sharedChoiceBound,
 )
import Data.CFTA.Ranked.Internal.Sampler
import Data.CFTA.Ranked.Internal.Shrink (planMemberSize)
import Data.CFTA.Ranked.Internal.Size (
    MinimumSize (..),
    SizeIndex (minimumMemberSize, sizeClassCounts),
    countAtSize,
    mapIndex,
    payIndex,
    sizeIndex,
 )
import Data.CFTA.Term (Term)
import qualified Data.CFTA.Term as Term

-- | One term, its normalized probability mass, and its decoded value.
data Outcome symbol a = Outcome
    { outcomeTerm :: Term (Label symbol)
    , outcomeMass :: Rational
    , outcomeValue :: a
    , outcomeInspection :: Term (InspectionSymbol symbol)
    -- ^ Source descriptions for a selected outcome, built only for inspection.
    }

-- | A finite language with exact cardinality and rank-based selection.
data OutcomeIndex symbol a = OutcomeIndex
    { outcomeCardinality :: !Cardinality
    , outcomeUniformMass :: !(Maybe Rational)
    , outcomeSelect :: Rank -> Either GenError (Outcome symbol a)
    , outcomeRanks :: TermView symbol -> [CheckedRank Rank]
    {- ^ The ranks whose term has the given view, in ascending order. The
    inverse of 'outcomeSelect' on terms: one term can have several ranks,
    because a node label removes the choice wrapper of its alternatives. Each
    rank tells whether the ranking checked every symbol of the term.
    -}
    , outcomeValueAt :: Rank -> a
    , outcomeSampler :: Sampler a
    {- ^ The sampler that the combinators compose. It is built on first use.
    A uniform language samples through 'outcomeDecoder' and does not build it.
    A weighted or atomic language builds it once.
    -}
    , outcomePlan :: Plan a
    , outcomeSizeIndex :: SizeIndex a
    {- ^ The size classes of 'outcomePlan', built on first use and retained so
    a shrink loop builds them once. Construct through 'mkOutcomeIndex'.
    -}
    , outcomeDecoder :: RankDecoder a
    {- ^ The compiled 'outcomePlan', built on first use and kept.
    'sampleStatic' and 'sampleStaticWithRank' read this field, so all their
    samples share one decoder. The samplers of the combinators do not read this
    field.
    -}
    , outcomeSizeSampling :: Maybe (SampleIndex a, Rank -> Either GenError Rational)
    {- ^ The sampler of each size class, and the weight of each rank inside its
    size class, when a component atomic choice is not uniform. The weight of a
    rank is its mass inside its size class times the number of members of the
    class, so the weights of one size class add up to its member count. The
    positions of the sampler are the positions of 'outcomeSizeIndex'.
    'Nothing' means that every size class is uniform, and every rank has the
    weight one. 'mkOutcomeIndex' sets 'Nothing'; 'applyStatic' and
    'frequencyStatic' set a sampler and a weight from their components.
    -}
    }

{- | A rank of a term, and whether the ranking checked every symbol of the
term.

A ranking follows the private labels of the term. It does not always check
every user symbol. A rank that is not checked can belong to another term
with the same private labels. The rank is a 'Rank', or a
'Data.CFTA.Ranked.Internal.Size.SizedRank' for a recursive language. The
fields are lazy, as in a pair, because a reader can read one field only.
-}
data CheckedRank rank = CheckedRank
    { checkedRank :: rank
    -- ^ The rank of the term.
    , everySymbolChecked :: Bool
    -- ^ Whether the ranking checked every symbol of the term.
    }
    deriving (Eq, Ord, Show)

{- | The checked ranks of a product of two parts, from the checked ranks of
each part. The function combines a rank of the first part with a rank of the
second part. A rank of the product checks every symbol when the two ranks
check every symbol. The ranks of the second part vary fastest.
-}
checkedProduct :: (a -> b -> c) -> [CheckedRank a] -> [CheckedRank b] -> [CheckedRank c]
checkedProduct combine firsts seconds =
    [ CheckedRank (combine first second) (firstChecked && secondChecked)
    | CheckedRank first firstChecked <- firsts
    , CheckedRank second secondChecked <- seconds
    ]
{-# INLINE checkedProduct #-}

-- | Build an outcome index whose size classes are derived from its plan.
mkOutcomeIndex ::
    Cardinality ->
    Maybe Rational ->
    (Rank -> Either GenError (Outcome symbol a)) ->
    (TermView symbol -> [CheckedRank Rank]) ->
    (Rank -> a) ->
    Sampler a ->
    Plan a ->
    OutcomeIndex symbol a
mkOutcomeIndex total mass select ranks valueAt sampler plan =
    OutcomeIndex total mass select ranks valueAt sampler plan (sizeIndex plan) (compilePlan total plan) Nothing

{- | A term as a language reads it when it ranks the term.

A language reads its own terms whole. The function side of an applicative
spine reads the arguments that the spine gives it, and a closed constructor
reads the children that 'labelTerm' gives its term: 'labelTerm' removes the
private labels of a spine, of an n-way join, and of a choice. The engine terms
carry these private labels, so ranking follows them. A node label checks its
own symbol, and the ranks tell which user symbols the ranking checked.
-}
data TermView symbol
    = -- | The whole term.
      WholeTerm (Term (Label symbol))
    | -- | The arguments of an applicative spine on its function side.
      SpineView (Seq (Term (Label symbol)))
    | -- | The children under a node label.
      LabelledView [Term (Label symbol)]

{- | The ranks or positions of a view, for a language whose term roots are
kept whole by both constructor closing and function-side application.
Each view of such a term retains the term itself.
-}
leafRanks :: (Term (Label symbol) -> [rank]) -> TermView symbol -> [rank]
leafRanks ranksOfTerm view = case view of
    WholeTerm term -> ranksOfTerm term
    SpineView (term :<| Empty) -> ranksOfTerm term
    LabelledView [term] -> ranksOfTerm term
    _ -> []

{- | The ranks of a view for a language whose terms are listed in rank order.
This compares whole terms, so it checks every symbol.
-}
enumeratedRanks :: (Eq symbol) => [Term (Label symbol)] -> TermView symbol -> [CheckedRank Rank]
enumeratedRanks terms view = [CheckedRank rank True | (rank, term) <- zip [0 ..] terms, hasView term view]

-- | Whether a term has the view.
hasView :: (Eq symbol) => Term (Label symbol) -> TermView symbol -> Bool
hasView term view = case view of
    WholeTerm wanted -> term == wanted
    SpineView wanted -> spineChildren term == wanted
    LabelledView wanted -> labelledChildren term == wanted

-- | Decode positions of one enumerated outcome sequence.
seqPlan :: Seq (Outcome symbol a) -> Plan a
seqPlan outcomes =
    PlanSelect
        (toEnum $ Sequence.length outcomes)
        (outcomeValue . Sequence.index outcomes . fromEnum)

-- | One transparent ECTA with a matching indexed outcome language.
data Static symbol a = Static
    { staticSupport :: Node (Label symbol)
    {- ^ The ECTA support is demand-driven. Counting, mass, and sampling
    use the outcome index without forcing this field. A support observer builds
    it when needed; finite combinators retain their support work as a thunk.
    -}
    , staticOutcomes :: !(OutcomeIndex symbol a)
    , staticAtomic :: !Bool
    {- ^ Whether 'atomicStatic' made this language one atom.

    Inside a size class, the ordinary finite weights of a language become
    member counts. An atom keeps its weights: 'staticSampling' draws its
    members by weight inside the one size of the atom. That size is one, or
    more under a pay. The sampler is in 'staticOutcomes'.
    -}
    , staticInspection :: Inspection symbol
    -- ^ Diagnostic structure. Counting and decoding do not force this field.
    , staticRootCount :: RootCount
    {- ^ The number of user roots that the term of each member has, as
    'termRootCount' counts them, when all members have the same number, and
    'NoCommonCount' otherwise. Each combinator sets it from its parts, so
    reading it lists no member. A language that does not know it lists its
    members on first use.
    -}
    }

{- | The sampler of each size class of a finite language, and the weight of
each rank inside its size class when that sampler is not uniform.

Inside a size class, the ordinary finite weights of the language become
member counts. An atomic choice keeps its own distribution, also when it is
a component of a product or of a choice. 'outcomeSizeSampling' describes the
weight. The weight of an atomic choice comes from its exact outcome masses.
-}
staticSampling :: Static symbol a -> (SampleIndex a, Maybe (Rank -> Either GenError Rational))
staticSampling static
    | staticAtomic static =
        ( atomicSampleIndex atomSize $ outcomeSampler outcomes
        , case outcomeUniformMass outcomes of
            Nothing -> Just atomWeight
            Just _ -> Nothing
        )
    | Just (sampling, weight) <- outcomeSizeSampling outcomes = (sampling, Just weight)
    | otherwise = (uniformSampleIndex $ outcomeSizeIndex outcomes, Nothing)
  where
    outcomes = staticOutcomes static
    -- Every member of an atom has one size: one, or more under a pay.
    atomSize = case minimumMemberSize $ outcomeSizeIndex outcomes of
        MinimumSize size -> size
        NoFiniteMember -> 1
    -- Every member of an atom has one size, so its mass inside its size class
    -- is its mass.
    atomWeight rank =
        (* toRational (outcomeCardinality outcomes)) . outcomeMass
            <$> outcomeSelect outcomes rank

-- | The one-outcome language of a single value.
pureStatic :: (Hashable symbol, Typeable symbol) => a -> Static symbol a
pureStatic value =
    Static
        (Node [Edge Pure []])
        ( mkOutcomeIndex
            1
            (Just 1)
            ( \index -> do
                checkIndex 1 index
                pure $ Outcome (Term.Node Pure []) 1 value (Term.Node (plainSymbol Pure) [])
            )
            pureRanks
            (const value)
            (uniformSampler 1 $ const value)
            (PlanPure value)
        )
        False
        (Inspection Nothing $ Node [Edge (plainSymbol Pure) []])
        (RootCount 0)
  where
    -- A spine and a node label give pure no arguments.
    pureRanks view = case view of
        WholeTerm (Term.Node Pure []) -> [CheckedRank 0 True]
        SpineView Empty -> [CheckedRank 0 True]
        LabelledView [] -> [CheckedRank 0 True]
        _ -> []

-- | The language of one finite indexed source.
indexedStatic :: (Hashable symbol, Typeable symbol) => Indexed a -> Static symbol a
indexedStatic = indexedStaticWithLabels $ const Nothing

-- | Retain source names independently of values and rank decoding.
indexedStaticWithLabels ::
    (Hashable symbol, Typeable symbol) =>
    (Rank -> Maybe Text) -> Indexed a -> Static symbol a
indexedStaticWithLabels label indexed =
    Static
        (Node [Edge (Index index) [] | index <- everyRank totalOutcomes])
        ( mkOutcomeIndex
            totalOutcomes
            (Just $ 1 / toRational totalOutcomes)
            select
            (leafRanks indexRanks)
            (indexedSelect indexed)
            (uniformSampler totalOutcomes $ indexedSelect indexed)
            (PlanSelect totalOutcomes $ indexedSelect indexed)
        )
        False
        (Inspection Nothing $ Node [Edge (namedSymbol index) [] | index <- everyRank totalOutcomes])
        (RootCount 0)
  where
    namedSymbol index = InspectionSymbol (Index index) (label index)
    totalOutcomes = indexedCardinality indexed
    indexRanks term = case term of
        Term.Node (Index index) [] | hasRank totalOutcomes index -> [CheckedRank index True]
        _ -> []
    select index = do
        checkIndex totalOutcomes index
        pure $
            Outcome
                (Term.Node (Index index) [])
                (1 / toRational totalOutcomes)
                (indexedSelect indexed index)
                (Term.Node (namedSymbol index) [])

{- | The language of one placeholder leaf with one value.

Its term is a private 'Placeholder', which a theory fills when it compiles. The
support is one leaf with the given symbol, which describes the values that
can fill the placeholder. The placeholder is not a source choice, so it has
size zero. The theory gives the size of the values that fill it.
-}
holeStatic :: (Hashable symbol, Typeable symbol) => symbol -> a -> Static symbol a
holeStatic summary value =
    Static
        (Node [Edge (Label summary) []])
        ( mkOutcomeIndex
            1
            (Just 1)
            ( \index -> do
                checkIndex 1 index
                pure $ Outcome (Term.Node Placeholder []) 1 value (Term.Node (plainSymbol Placeholder) [])
            )
            -- A theory fills the placeholder with a leaf, so any leaf takes rank
            -- zero. Only the placeholder itself is checked.
            ( leafRanks $ \case
                Term.Node Placeholder [] -> [CheckedRank 0 True]
                Term.Node _ [] -> [CheckedRank 0 False]
                _ -> []
            )
            (const value)
            (uniformSampler 1 $ const value)
            (PlanSized [SizeClass 0 1 (const value) (const value)])
        )
        False
        (Inspection Nothing $ Node [Edge (plainSymbol $ Label summary) []])
        (RootCount 1)

{- | Apply each outcome, a function of a point, to every point of an indexed
source.

Ranks are outcome-major, so the point varies fastest, and the masses of the
outcomes are shared equally among their points. The given function rewrites
the term of an outcome for its point. The support stays the support of the
outcomes. To rank a term, the language ranks the outcome structurally, then
gives the symbols at the placeholder leaves of the outcome, in order, to the
given function, which gives the rank of the point and the point. The rewrite
of the outcome for the point must then give the term, which checks every
symbol of the term. Every point has the given size.
-}
pointsStatic ::
    (Hashable symbol, Typeable symbol) =>
    Size ->
    (p -> Term (Label symbol) -> Term (Label symbol)) ->
    ([symbol] -> Maybe (Rank, p)) ->
    Indexed p ->
    Static symbol (p -> a) ->
    Static symbol a
pointsStatic size rewrite rankPoint pointSource functions =
    applied
        { staticSupport = staticSupport functions
        , staticOutcomes = (staticOutcomes applied){outcomeSelect = select, outcomeRanks = ranks}
        , staticInspection = staticInspection functions
        }
  where
    applied = applyStatic functions $ resizedStatic size $ indexedStatic pointSource
    select index = do
        outcome <- outcomeSelect (staticOutcomes applied) index
        let point = indexedSelect pointSource $ snd $ splitRank (indexedCardinality pointSource) index
            term = case outcomeTerm outcome of
                Term.Node Apply [functionTerm, _] -> rewrite point functionTerm
                other -> other
        pure outcome{outcomeTerm = term, outcomeInspection = fmap plainSymbol term}
    -- The rewrite keeps the private labels, so the outcome ranks the filled
    -- term. It changes symbols, so the checks of the outcome do not apply.
    ranks view =
        [ CheckedRank (pairRank (indexedCardinality pointSource) functionRank pointRank) True
        | CheckedRank functionRank _ <- outcomeRanks (staticOutcomes functions) view
        , Right outcome <- [outcomeSelect (staticOutcomes functions) functionRank]
        , Just symbols <- [holeSymbols (outcomeTerm outcome) view]
        , Just (pointRank, point) <- [rankPoint symbols]
        , hasView (rewrite point $ outcomeTerm outcome) view
        ]
    holeSymbols term view = case view of
        WholeTerm filled -> holesIn [term] [filled]
        SpineView filled -> holesIn (toList $ spineChildren term) (toList filled)
        LabelledView filled -> holesIn (labelledChildren term) filled
    holesIn terms filled
        | length terms == length filled = concat <$> zipWithM holes terms filled
        | otherwise = Nothing
    holes (Term.Node Placeholder []) (Term.Node (Label symbol) []) = Just [symbol]
    holes (Term.Node _ children) (Term.Node _ filled) = holesIn children filled

{- | Retain a shared ranked term compiler and its exact equality support.

The values are the accepted terms of the automaton, and the support is the
automaton under user labels. Sampling is uniform over accepted terms. The
common plan supplies replay and structural shrinking. No term is decoded
while this adapter is constructed.
-}
termStatic ::
    (Hashable symbol, Typeable symbol) =>
    Node symbol ->
    (Term symbol -> Either GenError Rank) ->
    Ranked.Ranked (Term symbol) ->
    Static symbol (Term symbol)
termStatic root rankTerm ranked =
    Static
        supportNode
        ( mkOutcomeIndex
            total
            (Just mass)
            select
            (leafRanks termRanks)
            valueAt
            (uniformSampler total valueAt)
            (Ranked.rankedPlan ranked)
        )
        False
        (plainInspection supportNode)
        (RootCount 1)
  where
    supportNode = relabel Label root
    total = Ranked.cardinality ranked
    mass = 1 / toRational total
    valueAt = Ranked.rankedValueAt ranked
    -- The term of a member is the accepted user term under 'Label'.
    termRanks term = maybe [] (either (const []) (\rank -> [CheckedRank rank True]) . rankTerm) $ userTerm term
    select rank = do
        checkIndex total rank
        let term = valueAt rank
            labelled = fmap Label term
        pure $ Outcome labelled mass term (fmap plainSymbol labelled)

-- | The user term under the 'Label's of an engine term, if it has no private label.
userTerm :: Term (Label symbol) -> Maybe (Term symbol)
userTerm = traverse userSymbol
  where
    userSymbol (Label symbol) = Just symbol
    userSymbol _ = Nothing

-- | The applicative product of a function language and an argument language.
applyStatic ::
    (Hashable symbol, Typeable symbol) =>
    Static symbol (a -> b) -> Static symbol a -> Static symbol b
applyStatic functions values =
    Static
        ( Node
            [ Edge
                Apply
                [staticSupport functions, staticSupport values]
            ]
        )
        ( mkOutcomeIndex
            totalOutcomes
            ((*) <$> outcomeUniformMass functionOutcomes <*> outcomeUniformMass valueOutcomes)
            select
            productRanks
            selectValue
            ( productSampler
                valueCardinality
                (outcomeSampler functionOutcomes)
                (outcomeSampler valueOutcomes)
            )
            ( PlanAp
                valueCardinality
                (outcomePlan functionOutcomes)
                (outcomePlan valueOutcomes)
            )
        )
            { outcomeSizeSampling = sizeSampling
            }
        False
        ( Inspection Nothing $
            Node
                [ Edge (plainSymbol Apply) [inspectionGraph $ staticInspection functions, inspectionGraph $ staticInspection values]
                ]
        )
        (addRootCounts (staticRootCount functions) (staticRootCount values))
  where
    functionOutcomes = staticOutcomes functions
    valueOutcomes = staticOutcomes values
    valueCardinality = outcomeCardinality valueOutcomes
    totalOutcomes = outcomeCardinality functionOutcomes * valueCardinality

    -- Each side samples its own size class, so an atomic side keeps its
    -- distribution inside every size of the product.
    (functionSampling, functionWeight) = staticSampling functions
    (valueSampling, valueWeight) = staticSampling values
    sizeSampling = case (functionWeight, valueWeight) of
        (Nothing, Nothing) -> Nothing
        _ ->
            Just
                ( productSampleIndex
                    (outcomeSizeIndex functionOutcomes)
                    functionSampling
                    (outcomeSizeIndex valueOutcomes)
                    valueSampling
                , \index ->
                    let (functionIndex, valueIndex) = splitIndex index
                     in (*)
                            <$> maybe (Right 1) ($ functionIndex) functionWeight
                            <*> maybe (Right 1) ($ valueIndex) valueWeight
                )

    select index = do
        checkIndex totalOutcomes index
        let (functionIndex, valueIndex) = splitIndex index
        functionOutcome <- outcomeSelect functionOutcomes functionIndex
        valueOutcome <- outcomeSelect valueOutcomes valueIndex
        pure $
            Outcome
                ( Term.Node
                    Apply
                    [outcomeTerm functionOutcome, outcomeTerm valueOutcome]
                )
                (outcomeMass functionOutcome * outcomeMass valueOutcome)
                (outcomeValue functionOutcome $ outcomeValue valueOutcome)
                (Term.Node (plainSymbol Apply) [outcomeInspection functionOutcome, outcomeInspection valueOutcome])

    selectValue index =
        let (functionIndex, valueIndex) = splitIndex index
         in outcomeValueAt functionOutcomes functionIndex $
                outcomeValueAt valueOutcomes valueIndex

    splitIndex = splitRank valueCardinality

    -- A spine and a node label give the arguments of the spine in order: the
    -- last one is this product's argument, the others belong to its function.
    productRanks view = case view of
        WholeTerm (Term.Node Apply [function, argument]) -> ranksFrom (WholeTerm function) argument
        WholeTerm _ -> []
        SpineView arguments -> spineRanks arguments
        LabelledView arguments -> spineRanks $ Sequence.fromList arguments
      where
        spineRanks arguments = case arguments of
            functionArguments :|> argument -> ranksFrom (SpineView functionArguments) argument
            Empty -> []

        ranksFrom functionView argument =
            checkedProduct
                (pairRank valueCardinality)
                (outcomeRanks functionOutcomes functionView)
                (outcomeRanks valueOutcomes (WholeTerm argument))

{- | 'frequencyStatic' for alternatives that come with their weight in each
size class, on the scale of member counts, when it is not their member count.

Inside a size class these weights choose the alternative, and the alternative
keeps its own weights inside it. A weight of the result keeps the convention
of 'staticSampling': the weights of a size class add up to its member count.
'Nothing' is the member count of the alternative.
-}
frequencyStaticWithMasses ::
    (Hashable symbol, Typeable symbol) =>
    [(Weight, Maybe (Size -> Rational), Static symbol a)] -> Static symbol a
frequencyStaticWithMasses alternatives =
    merged{staticOutcomes = (staticOutcomes merged){outcomeSizeSampling = Just (sampling, weightAt)}}
  where
    merged = frequencyStatic [(weight, alternative) | (weight, _, alternative) <- alternatives]
    indexOf = outcomeSizeIndex . staticOutcomes
    weighted =
        [ (alternative, fromMaybe (toRational . countAtSize (indexOf alternative)) masses)
        | (_, masses, alternative) <- alternatives
        ]
    sampling =
        choiceMassSampleIndex
            [(indexOf alternative, massAt, fst $ staticSampling alternative) | (alternative, massAt) <- weighted]
    -- The count of the size class, times the share of the alternative in the
    -- class, times the share of the member in the alternative.
    weightAt rank = do
        let size = planMemberSize (outcomePlan $ staticOutcomes merged) rank
            (offset, alternative, massAt) = branchOf rank
            total = sum [mass size | (_, mass) <- weighted]
            inside = toRational $ countAtSize (indexOf alternative) size
        memberWeight <- maybe (Right 1) ($ rebaseRank offset rank) $ snd $ staticSampling alternative
        pure $ toRational (countAtSize (indexOf merged) size) * massAt size / total * memberWeight / inside
    branchOf rank =
        last
            [ (offset, alternative, massAt)
            | (offset, (alternative, massAt)) <- zip offsets weighted
            , let RankOffset first = offset
            , let Rank value = rank
            , first <= value
            ]
    offsets = map fst $ offsetAlternatives [(1, alternative) | (alternative, _) <- weighted]

{- | Give a pair of two languages the sampler and the weights that follow the
weights of its parts in each size class, when a part has weights of its own.

The pair has the ranks of a join over an operation of size zero: a rank pairs
a rank of the left with a rank of the right, the right as the less significant
part, and the size of a member is the sum of the sizes of its parts. Inside a
size class, the weights of the parts choose the split of the size, and each
part keeps its own weights inside its size class. A weight of the result keeps
the convention of 'staticSampling'. 'Nothing' is the member count of a part.
-}
pairStaticWithMasses ::
    Maybe (Size -> Rational) ->
    Static symbol left ->
    Maybe (Size -> Rational) ->
    Static symbol right ->
    Static symbol (left, right) ->
    Static symbol (left, right)
pairStaticWithMasses leftMasses left rightMasses right pair =
    pair{staticOutcomes = (staticOutcomes pair){outcomeSizeSampling = Just (sampling, weightAt)}}
  where
    indexOf = outcomeSizeIndex . staticOutcomes
    massOf masses part = fromMaybe (toRational . countAtSize (indexOf part)) masses
    leftMass = massOf leftMasses left
    rightMass = massOf rightMasses right
    sampling =
        productMassSampleIndex
            (mapIndex (,) $ indexOf left)
            leftMass
            (mapSampleIndex (,) $ fst $ staticSampling left)
            (indexOf right)
            rightMass
            (fst $ staticSampling right)
    -- The count of the size class, times the share of the split of the size in
    -- the class, times the share of each part's member in its own size class.
    weightAt rank = do
        let (leftRank, rightRank) = splitRank (outcomeCardinality $ staticOutcomes right) rank
            leftSize = sizeOf left leftRank
            rightSize = sizeOf right rightRank
        leftWeight <- maybe (Right 1) ($ leftRank) $ snd $ staticSampling left
        rightWeight <- maybe (Right 1) ($ rightRank) $ snd $ staticSampling right
        let size = leftSize + rightSize
            splits = sum [leftMass split * rightMass (size - split) | (split, _) <- sizeClassCounts (indexOf left), split <= size]
            share part partSize weight = weight / toRational (countAtSize (indexOf part) partSize)
        pure $
            toRational (countAtSize (indexOf pair) size)
                * (leftMass leftSize * rightMass rightSize / splits)
                * share left leftSize leftWeight
                * share right rightSize rightWeight
    sizeOf part = planMemberSize $ outcomePlan $ staticOutcomes part

-- | Concatenate weighted alternatives with stable rank offsets.
frequencyStatic ::
    (Hashable symbol, Typeable symbol) =>
    [(Weight, Static symbol a)] -> Static symbol a
frequencyStatic alternatives =
    Static
        ( Node
            [ Edge (Choice index) [staticSupport static]
            | (_, _, index, _, static) <- rankedBranches
            ]
        )
        ( mkOutcomeIndex
            totalOutcomes
            uniformMass
            select
            choiceRanks
            selectValue
            sampler
            ( PlanChoice
                [ ( outcomeCardinality $ staticOutcomes static
                  , alternativePlan $ staticOutcomes static
                  )
                | (_, static) <- alternatives
                ]
            )
        )
            { outcomeSizeSampling = sizeSampling
            }
        False
        (choiceInspection $ map (staticInspection . snd) alternatives)
        (commonRootCount $ map (staticRootCount . snd) alternatives)
  where
    totalWeight = sum $ map fst alternatives
    rankedBranches =
        [ ( nextOffset offset $ outcomeCardinality (staticOutcomes static)
          , offset
          , branchIndex
          , weight
          , static
          )
        | (branchIndex, (offset, (weight, static))) <-
            zip [0 :: ChoiceIndex ..] $ offsetAlternatives alternatives
        ]
    totalOutcomes = sum [outcomeCardinality $ staticOutcomes static | (_, static) <- alternatives]
    uniformMass = commonValue $ map branchUniformMass alternatives
      where
        branchUniformMass (weight, static) =
            (toRational weight / toRational totalWeight *)
                <$> outcomeUniformMass (staticOutcomes static)
    sampler = case uniformMass of
        Just _ -> uniformSampler totalOutcomes selectValue
        Nothing -> frequencySampler alternatives

    -- Member counts choose the alternative inside a size class, as in a
    -- recursive choice. An atomic alternative keeps its own distribution.
    samplings = map (staticSampling . snd) alternatives
    sizeSampling
        | any (isJust . snd) samplings =
            Just
                ( choiceSampleIndex
                    [ (outcomeSizeIndex $ staticOutcomes static, sampling)
                    | ((sampling, _), (_, static)) <- zip samplings alternatives
                    ]
                , \index ->
                    let (_, _, static, childIndex) = selectBranch index rankedBranches
                     in maybe (Right 1) ($ childIndex) $ snd $ staticSampling static
                )
        | otherwise = Nothing

    select index = do
        checkIndex totalOutcomes index
        let (branchIndex, weight, static, childIndex) = selectBranch index rankedBranches
        child <- outcomeSelect (staticOutcomes static) childIndex
        pure $
            Outcome
                (Term.Node (Choice branchIndex) [outcomeTerm child])
                ( toRational weight
                    / toRational totalWeight
                    * outcomeMass child
                )
                (outcomeValue child)
                (Term.Node (plainSymbol $ Choice branchIndex) [outcomeInspection child])

    selectValue index =
        let (_, _, static, childIndex) = selectBranch index rankedBranches
         in outcomeValueAt (staticOutcomes static) childIndex

    -- A node label removes the choice wrapper, so it can match every
    -- alternative; a spine gives the whole choice term as one argument.
    choiceRanks view = case view of
        WholeTerm (Term.Node (Choice branchIndex) [child]) -> branchRanks branchIndex $ WholeTerm child
        WholeTerm _ -> []
        SpineView (term :<| Empty) -> choiceRanks $ WholeTerm term
        SpineView _ -> []
        LabelledView _ -> concat [branchRanks branchIndex view | (_, _, branchIndex, _, _) <- rankedBranches]
    branchRanks branchIndex view =
        [ CheckedRank (offsetRank offset rank) checked
        | (_, offset, index, _, static) <- rankedBranches
        , index == branchIndex
        , CheckedRank rank checked <- outcomeRanks (staticOutcomes static) view
        ]

    selectBranch _ [] =
        error
            "cfta-generator bug in Data.CFTA.Gen.Internal.Static.frequencyStatic: \
            \rank outside the alternatives"
    selectBranch index@(Rank rank) ((RankOffset upperBound, offset, branchIndex, weight, static) : remaining)
        | rank < upperBound = (branchIndex, weight, static, rebaseRank offset index)
        | otherwise = selectBranch index remaining

{- | The plan of one alternative of a choice.

An alternative with more than 'sharedChoiceBound' members is a shared node:
the choice calls its compiled decoder and reads its size classes, and does not
copy its plan. A plan that is shared already stays as it is, because a second
shared node would add one call to each decode.
-}
alternativePlan :: OutcomeIndex symbol a -> Plan a
alternativePlan outcomes = case outcomePlan outcomes of
    plan@PlanShared{} -> plan
    plan
        | outcomeCardinality outcomes > sharedChoiceBound ->
            PlanShared (outcomeCardinality outcomes) (outcomeDecoder outcomes) (outcomeSizeIndex outcomes) plan
        | otherwise -> plan

-- | Map the values of a static language.
mapStatic :: (a -> b) -> Static symbol a -> Static symbol b
mapStatic transform static =
    static{staticOutcomes = mapOutcomeIndex transform $ staticOutcomes static}

-- | Map the values of an outcome index.
mapOutcomeIndex :: (a -> b) -> OutcomeIndex symbol a -> OutcomeIndex symbol b
mapOutcomeIndex transform outcomes =
    ( mkOutcomeIndex
        (outcomeCardinality outcomes)
        (outcomeUniformMass outcomes)
        (fmap (mapOutcome transform) . outcomeSelect outcomes)
        (outcomeRanks outcomes)
        (transform . outcomeValueAt outcomes)
        (mapSampler transform $ outcomeSampler outcomes)
        (PlanMap transform $ outcomePlan outcomes)
    )
        { outcomeSizeSampling =
            Bifunctor.first (mapSampleIndex transform) <$> outcomeSizeSampling outcomes
        }

-- | Map the value of one outcome.
mapOutcome :: (a -> b) -> Outcome symbol a -> Outcome symbol b
mapOutcome transform outcome =
    Outcome
        (outcomeTerm outcome)
        (outcomeMass outcome)
        (transform $ outcomeValue outcome)
        (outcomeInspection outcome)

-- | Make every outcome of a finite language contribute one unit of size.
atomicStatic :: Static symbol a -> Static symbol a
atomicStatic static =
    static
        { staticOutcomes =
            mkOutcomeIndex
                (outcomeCardinality outcomes)
                (outcomeUniformMass outcomes)
                (outcomeSelect outcomes)
                (outcomeRanks outcomes)
                (outcomeValueAt outcomes)
                retainedSampler
                (PlanSelect (outcomeCardinality outcomes) (outcomeValueAt outcomes))
        , staticAtomic = True
        }
  where
    outcomes = staticOutcomes static
    retainedSampler =
        case compiledWeightedSampler outcomes of
            Just sampler -> sampler
            Nothing -> outcomeSampler outcomes

{- | Give every outcome of a finite language one size.

A language that is rebuilt from the terms of its members counts the source
choices of the rebuilt terms, which need not be the choices that made the
members. 'Data.CFTA.Gen.Refinement.Internal.Compile' rebuilds a member when a
guard reads it, and gives the rebuilt member the size that it had.
-}
resizedStatic :: Size -> Static symbol a -> Static symbol a
resizedStatic size static =
    static
        { staticOutcomes =
            mkOutcomeIndex
                count
                (outcomeUniformMass outcomes)
                (outcomeSelect outcomes)
                (outcomeRanks outcomes)
                (outcomeValueAt outcomes)
                (outcomeSampler outcomes)
                ( PlanSized
                    [SizeClass size count (\(ClassRank rank) -> outcomeValueAt outcomes $ Rank rank) (outcomeValueAt outcomes . toEnum)]
                )
        }
  where
    outcomes = staticOutcomes static
    count = outcomeCardinality outcomes

{- | Close an applicative or grouped child layer with one user-facing node
label.

The generator engine uses private symbols while a child product is still open.
Closing it removes that scaffolding from the root term: applicative spines
become direct children, grouped joins retain their equality constraints, and
choice wrappers distribute the new label over their alternatives. The label is
a constructor, so it pays: every member is one larger.
-}
labelStatic ::
    (Hashable symbol, Typeable symbol) =>
    symbol -> Static symbol a -> Static symbol a
labelStatic symbol = labelStaticMatching (== symbol) symbol

{- | 'labelStatic' for a label that a theory rewrites when it fills the
term, as the rewrite of 'pointsStatic' can. The test gives the labels that
the label can become. A term ranks under a label that passes the test, and
a label other than the given one leaves its ranks unchecked.
-}
labelStaticMatching ::
    (Hashable symbol, Typeable symbol) =>
    (symbol -> Bool) -> symbol -> Static symbol a -> Static symbol a
labelStaticMatching matches symbol static =
    static
        { staticSupport = labelSupport symbol $ staticSupport static
        , staticOutcomes = payOutcomes $ labelOutcomeTerms matches symbol $ staticOutcomes static
        , staticInspection = labelInspection symbol $ staticInspection static
        , staticRootCount = RootCount 1
        }

{- | The members of a finite language, each one larger: the @pay@ of FEAT.
The terms, the ranks, and the values do not change.
-}
payStatic :: Static symbol a -> Static symbol a
payStatic static = static{staticOutcomes = payOutcomes $ staticOutcomes static}

{- | The members of an outcome index, each one larger, as 'payStatic' gives
them. The ranks, the values, and the decoder do not change.
-}
payOutcomes :: OutcomeIndex symbol a -> OutcomeIndex symbol a
payOutcomes outcomes =
    outcomes
        { outcomePlan = PlanPay $ outcomePlan outcomes
        , outcomeSizeIndex = payIndex $ outcomeSizeIndex outcomes
        , outcomeSizeSampling = Bifunctor.first paySampleIndex <$> outcomeSizeSampling outcomes
        }

-- | Relabel the retained term of every outcome that the index selects.
labelOutcomeTerms :: (Eq symbol) => (symbol -> Bool) -> symbol -> OutcomeIndex symbol a -> OutcomeIndex symbol a
labelOutcomeTerms matches symbol outcomes =
    outcomes
        { outcomeSelect = fmap (labelOutcome symbol) . outcomeSelect outcomes
        , outcomeRanks = leafRanks labelledRanks
        }
  where
    -- The label replaces the private root of the inner term, so the inner
    -- language reads the children under it. A term with a label that fails
    -- the test has no rank here, so a choice of labels reads each term in
    -- one alternative.
    labelledRanks term = case term of
        Term.Node (Label found) children
            | matches found ->
                [ CheckedRank rank (checked && found == symbol)
                | CheckedRank rank checked <- outcomeRanks outcomes $ LabelledView children
                ]
        _ -> []

-- | Relabel the retained term of one finite outcome.
labelOutcome :: symbol -> Outcome symbol a -> Outcome symbol a
labelOutcome symbol outcome =
    outcome
        { outcomeTerm = labelTerm symbol $ outcomeTerm outcome
        , outcomeInspection = labelTermWith originalSymbol (plainSymbol $ Label symbol) $ outcomeInspection outcome
        }

-- | Sample one outcome sequence by its masses.
sequenceSampler :: Seq (Outcome symbol a) -> Either GenError (Sampler a)
sequenceSampler outcomes
    | Just _ <- commonValue $ Just . outcomeMass <$> toList outcomes =
        pure $ uniformSampler totalOutcomes selectValue
    | otherwise = do
        weightedRanks <-
            integerOutcomes
                [ (outcomeMass outcome, RankedValue index (outcomeValue outcome))
                | (index, outcome) <- zip [0 ..] $ toList outcomes
                ]
        pure $
            Sampler
                (frequencyGen [(weight, pure value) | (weight, RankedValue _ value) <- weightedRanks])
                (frequencyGen [(weight, pure ranked) | (weight, ranked) <- weightedRanks])
  where
    totalOutcomes = toEnum $ Sequence.length outcomes
    selectValue = outcomeValue . Sequence.index outcomes . fromEnum

-- | Sample weighted alternatives with rank offsets.
frequencySampler :: [(Weight, Static symbol a)] -> Sampler a
frequencySampler alternatives =
    Sampler
        ( frequencyGen
            [ (weight, runValueSampler $ outcomeSampler $ staticOutcomes static)
            | (weight, static) <- alternatives
            ]
        )
        ( frequencyGen
            [ (weight, offsetRankedValue offset <$> runRankSampler (outcomeSampler $ staticOutcomes static))
            | (offset, (weight, static)) <- offsetAlternatives alternatives
            ]
        )

-- | Pair every alternative with its cumulative rank offset.
offsetAlternatives :: [(Weight, Static symbol a)] -> [(RankOffset, (Weight, Static symbol a))]
offsetAlternatives = go 0
  where
    go _ [] = []
    go offset (alternative@(_, static) : remaining) =
        (offset, alternative)
            : go
                (nextOffset offset $ outcomeCardinality (staticOutcomes static))
                remaining

-- | Largest non-uniform language compiled to one exact ticket selection.
weightedCompilationBound :: Cardinality
weightedCompilationBound = 32768

-- | Compile a small non-uniform language without aggregating equal values.
compiledWeightedSampler :: OutcomeIndex symbol a -> Maybe (Sampler a)
compiledWeightedSampler outcomes
    | Just _ <- outcomeUniformMass outcomes = Nothing
    | outcomeCardinality outcomes > weightedCompilationBound = Nothing
    | otherwise = do
        enumerated <- either (const Nothing) Just $ enumerateOutcomeIndex outcomes
        weighted <-
            either (const Nothing) Just $
                integerOutcomes
                    [ (outcomeMass outcome, RankedValue rank (outcomeValue outcome))
                    | (rank, outcome) <- zip [0 ..] enumerated
                    ]
        compiled <- compileWeighted weighted
        pure $
            Sampler
                (rankedValue <$> selectWeighted weighted compiled)
                (selectWeighted weighted compiled)

-- | Sample one value; uniform languages go through the compiled decoder.
sampleStatic ::
    (GenBackend gen) =>
    Static symbol a ->
    gen (Either GenError a)
sampleStatic static
    | Just _ <- outcomeUniformMass outcomes = Right <$> drawUniform (outcomeDecoder outcomes)
    | otherwise =
        Right <$> runValueSampler (outcomeSampler outcomes)
  where
    outcomes = staticOutcomes static

-- | Sample one value together with its replay rank.
sampleStaticWithRank ::
    (GenBackend gen) =>
    Static symbol a ->
    gen (Either GenError (RankedValue a))
sampleStaticWithRank static
    | Just _ <- outcomeUniformMass outcomes = Right <$> drawUniformWithRank (outcomeDecoder outcomes)
    | otherwise =
        Right <$> runRankSampler (outcomeSampler outcomes)
  where
    outcomes = staticOutcomes static

-- | Draw one value of a uniform language through its compiled decoder.
drawUniform :: (GenBackend gen) => RankDecoder a -> gen a
drawUniform (SmallDecoder bound decode) = decode <$> selectInt bound
drawUniform (LargeDecoder bound decode) = decode <$> selectInteger bound

-- | 'drawUniform' with the replay rank of the value.
drawUniformWithRank :: (GenBackend gen) => RankDecoder a -> gen (RankedValue a)
drawUniformWithRank (SmallDecoder bound decode) =
    (\index -> RankedValue (Rank $ toInteger index) (decode index)) <$> selectInt bound
drawUniformWithRank (LargeDecoder bound decode) = (\rank -> RankedValue rank (decode rank)) <$> selectInteger bound

-- | Select every outcome in rank order.
enumerateOutcomeIndex :: OutcomeIndex symbol a -> Either GenError [Outcome symbol a]
enumerateOutcomeIndex outcomes =
    traverse
        (outcomeSelect outcomes)
        (everyRank $ outcomeCardinality outcomes)

{- | Select every outcome in rank order, with the weight of its rank inside
its size class.

'outcomeSizeSampling' describes the weight. Every outcome of a language with
uniform size classes has the weight one.
-}
enumerateWeighted :: Static symbol a -> Either GenError [(Rational, Outcome symbol a)]
enumerateWeighted static = do
    outcomes <- enumerateOutcomeIndex $ staticOutcomes static
    weights <-
        traverse
            (fromMaybe (const $ Right 1) $ snd $ staticSampling static)
            (everyRank $ toEnum $ length outcomes)
    pure $ zip weights outcomes

-- | Enumerate a language as normalized mass and value pairs.
compileOutcomes :: Static symbol a -> Either GenError [(Rational, a)]
compileOutcomes static = do
    outcomes <- enumerateOutcomeIndex $ staticOutcomes static
    normalize [(outcomeMass outcome, outcomeValue outcome) | outcome <- outcomes]

{- | The number of user roots of an engine term: the length of 'surface' of
the term, where a placeholder counts as the leaf that fills it.
-}
termRootCount :: Term (Label symbol) -> Int
termRootCount (Term.Node (Label _) _) = 1
termRootCount (Term.Node Placeholder []) = 1
termRootCount (Term.Node _ children) = sum $ map termRootCount children

{- | The number of user roots that each member of a language gives its
constructor, or 'NoCommonCount'. 'NoCommonCount' is for a language whose
members give different numbers, and for a language that does not know the
number: a bounded recursive language without a term index, and, in the
refinement compiler, a recursive or opaque built language. Each reader
treats the two cases the same.
-}
data RootCount
    = NoCommonCount
    | RootCount !Int
    deriving (Eq, Show)

-- | The root count of a product: the sum of the root counts of its two parts.
addRootCounts :: RootCount -> RootCount -> RootCount
addRootCounts (RootCount left) (RootCount right) = RootCount $ left + right
addRootCounts _ _ = NoCommonCount

{- | The root count that every part gives, when the parts agree. A list
without parts gives one, so that a language without members does not refuse
a guard that reads its children.
-}
commonRootCount :: [RootCount] -> RootCount
commonRootCount counts = case counts of
    [] -> RootCount 1
    count : rest | all (== count) rest -> count
    _ -> NoCommonCount

-- | The value shared by every entry, if any.
commonValue :: (Eq a) => [Maybe a] -> Maybe a
commonValue [] = Nothing
commonValue (Just value : remaining)
    | all (== Just value) remaining = Just value
commonValue _ = Nothing

-- | Reject a rank outside the language.
checkIndex :: Cardinality -> Rank -> Either GenError ()
checkIndex totalOutcomes@(Cardinality total) index@(Rank rank)
    | rank < 0 = Left $ NegativeRank index
    | rank >= total = Left $ SelectionOutOfRange index totalOutcomes
    | otherwise = Right ()

-- | Scale masses so they sum to one.
normalize :: [(Rational, a)] -> Either GenError [(Rational, a)]
normalize [] = Left EmptyGenerator
normalize outcomes =
    let total = sum $ map fst outcomes
     in if total <= 0
            then Left EmptyGenerator
            else Right [(mass / total, value) | (mass, value) <- outcomes]

{- | Convert rational masses to the smallest equivalent integer weights,
rejecting a set that cannot be sampled.

This is 'integerMasses' with its positivity precondition checked: a language
with no outcomes, or one whose masses are not all positive, has nothing to
sample.
-}
integerOutcomes ::
    [(Rational, a)] ->
    Either GenError [(Weight, a)]
integerOutcomes [] = Left EmptyGenerator
integerOutcomes outcomes
    | any ((<= 0) . fst) outcomes = Left EmptyGenerator
    | otherwise = Right $ integerMasses outcomes
