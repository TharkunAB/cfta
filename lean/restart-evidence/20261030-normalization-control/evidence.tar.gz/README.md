# Original normalization and forecast path control

Full goal ACTIVE. Read final-documents/lean/notes-current-normalization-control.md.
Audit4697/82567 and public1068/86 pass. Six strict sources match.
Five new modules prove17 public laws and define Common. All493 old protected
and835 native/build inputs match. Current protected baseline498.
The SAME original finite carrier bounds native guard projections after every
admitted physical prefix and all complete parent/resident forecast budgets.
Prepared normalization derives its finite word carrier from original raw paths.
Inherited values, multiplicity, keys/handles, all-alternative structural work,
sufficientD, whole coverage/order/stops and Haskell correspondence remain open.
The public DFS candidate is not starvation. The fresh library build and exact
runtime replay pass; all835 native inputs match before and after. No Haskell
source changed. FINDINGS records the local GMP repair and API wording correction.
Retain both failed Lean drafts, the failed native rebuild, checked probes,
symbolic unverified candidates, all source scopes and provenance incidents.
Six owned bundles verify412 pins, including one explicit Root supplement.
All20 commands and91 input snapshots remain. Every regular payload is archived
without filtering. Keep this area immutable. The verifier runs no Lean or Haskell.
