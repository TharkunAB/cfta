# Verified common carrier for source equality normalization

Status: unchanged V1 passes Root build and strict checking.
Timestamp: 2026-10-30 02:26 CET.

The new module proves that actual successful normalization of `first ++ second` preserves the SAME alphabet, segmentation gap, and anchor list. It derives a finite word carrier from those fixed parameters. This resolves the local common-bound closure proposed in the earlier original-path investigation. It does not yet initialize that bound from every original native input or prove the full native writer invariant.

The production module is `SourceEqualityNormalizationCarrier.lean`, namespace `MicroCFTA.SourceEqualityNormalizationCarrier`. It has 167 lines, 9,495 bytes, and SHA256 `ee0ec58cb9179a648ac83d91293e9822bd688e44b0459655153a4a304cd688bd`. Production, owner V1, Root build input, Root strict input, and Root strict checked source are byte-identical. Root accepted the first proof version without a source repair.

## Public contracts

`Common gap anchors alphabet classes` is the conjunction of existing `SegmentedState gap classes`, `Anchored anchors classes`, and `UsesAlphabet alphabet classes`.

The six public laws are append_common, prepare_common, complete_common, fixMaybe_common, normalize_common, and normalize_append_carrier. They preserve these same parameters through the actual operations. The final law is:

```lean
theorem normalize_append_carrier {first second output : Constraints}
    (firstActive : Active first) (secondActive : Active second)
    (left : Common gap anchors alphabet first) (right : Common gap anchors alphabet second)
    (observed : normalize (first ++ second) = some output) :
    Common gap anchors alphabet output ∧ NormalState output ∧ isContradicting output = false ∧
      Within (words alphabet (gap * (anchors.length + 1))) output
```

The law assumes neither input normality nor input disjointness, canonical order, or consistency. It assumes no model, output membership, future worker, or future resource packet. The output facts come from the actual successful normalization equation. The bound has no D parameter and does not change with normalization fuel.

## Proof and admission

The definitions were checked before drafting. Anchored is class-local and is closed under class-list append. Segmentation uses markers in the current member-path set. Append retains all markers, so segments_mono transfers each operand's segmentation certificate. Alphabet membership also transfers directly.

Actual preparation deduplicates each class and filters trivial classes. The private prepare_members_active proof gives exact member preservation under Active admission. This retains every segmentation marker. The actual nontrivialB_correct theorem establishes membership in the retained filter. Anchors and alphabet membership then transfer.

Completion preserves member paths exactly. For an output component, its actual active normality supplies a member. complete_covers finds the retained source component. components_equal uses the shared member and output disjointness to identify it with the selected output component. The original anchor is then retained. No semantic model occurs.

The fixed-point proof follows the actual fixMaybe branches. It rejects timeout and contradiction by the observed normalized result. A stable branch has the original class list. A recursive branch uses the existing step_segmented, step_anchored, step_alphabet, and actual step activity before its induction hypothesis.

The normalization proof follows the existing normalize_cached result-split pattern. It builds the prepared/completed Common state, propagates it through the actual iteration, and derives NormalState and noncontradiction from actual normalization invariants. Existing bounded_state then supplies the finite word carrier.

Active is an explicit gate. It ensures preparation retains all recorded markers. Without that gate, singleton marker classes can be discarded. The source-level example with gap1, singleton classes `{0}`, `{00}`, `{1}`, `{11}`, and active class `{000,111}` explains the issue: the original markers permit length-three paths in unit segments, but preparation discards those singleton markers. The report does not claim a separately compiled concrete counterexample. For actual source caches, Active must come from their existing Cached/NormalClasses admission. Positive literal construction must supply its actual nontrivial admission.

## Remaining scope

The module does not yet construct Common for every original heap cache or guard literal. It does not yet lift Common through all native guard writers, sourceEqualities, or positiveNormalized. The inherited-workspace nonfeedback obligation also remains separate. These are original-origin and actual constructor obligations. They are not replaced with a supplier of the desired final carrier.

A finite path carrier alone does not bound handles, bucket multiplicity, allocation count, recursion-key count, or worker depth. The module proves no global coverage or global configured-control theorem. The full soundness, coverage, configured stop/order, and Haskell correspondence objective remains active. No Haskell defect or fix was found.

## Verification

Root carrier-v1-build passed with 112 jobs. Its full 114-byte log is retained. Root carrier-v1-strict passed with warningAsError=true and linter.all=true. Its log is empty. Both full reports, commands, logs, input metadata, target snapshots, and strict checked source are retained under root-evidence. The report/log byte counts and hashes match. Every recorded input snapshot hash was checked against Root's actual snapshot. Current production and all target copies match the owner V1 source. Aggregate Audit, protected/public readback, and integration remain Root's separate work.

This owner ran no compiler or evaluator. It produced source and verified the matching Root receipts.

## Source provenance and incidents

The bundle contains nine new bounded cuts and twenty reused frozen cuts. All source identities, literal cuts, and requested/actual numerical endpoints pass the recorded validation. Fresh unions are EqualityNormalize159/1352 lines, EqualityTermination109/640, and EqualitySaturation18/436. Total unions including reuse are EqualityNormalize323/1352, EqualityTermination253/640, SourceCompactGuards66/574, SourceEqualityGuardReadback52/105, and EqualitySaturation18/436. There is no new literal whole old-source acquisition. The largest fresh union is 17.1%. The largest total union is 49.5%. Even charging both largest total unions as conservative broad near-whole scopes remains within the two-source budget. NEEDED-SIGNATURES.md maps every existing interface to its retained scope.

The first four source-acquisition helpers were wrongly run in parallel. Their shared manifest/index updates collided. The initial manifest and surviving copies remain under initial-parallel-*. All four exact scopes were reacquired sequentially. The final acquisitions.json and cuts directory contain every complete requested cut. No source content or proof result is missing from that final record. The incident is also retained in its own text file. No tool display was truncated, and no requested/actual endpoint overrun occurred.

Whole source files were hashed for identity checks; retained source content is limited to the declared cuts. No repository edit, compiler/evaluator/native execution, Git, network, board, or subagent call was performed by this owner. All earlier frozen bundles remain unchanged. REPORT-v1.md is the historical pre-check report; this report records the matching accepted result.
