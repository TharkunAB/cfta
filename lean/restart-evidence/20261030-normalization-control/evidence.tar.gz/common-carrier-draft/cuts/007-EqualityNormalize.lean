theorem complete_covers (classes : Constraints) : Covers classes (complete classes) := by
  intro paths member
  obtain ⟨component, componentMember, includes⟩ := completeFuel_covers classes.length classes paths member
  refine ⟨canonicalClass component, ?_, fun path present => (mem_canonicalClass path component).mpr (includes path present)⟩
  simpa [complete, canonicalize] using (List.mem_map.mpr ⟨component, componentMember, rfl⟩ :
    canonicalClass component ∈ (completeFuel classes.length classes).map canonicalClass)

/-- At a step fixed point, every generated suffix class occurs inside an output component. -/
theorem fixedPoint_congruence_closed (classes : Constraints) (fixed : congruenceStep classes = some classes)
