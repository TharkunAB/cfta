inductive Segments (gap : Nat) (classes : Constraints) : List Nat → List Nat → Prop where
  | short : first.IsPrefix last → last.length ≤ first.length + gap → Segments gap classes first last
  | step : first.IsPrefix middle → first.length < middle.length → middle.IsPrefix last →
      middle.length ≤ first.length + gap → middle ∈ members classes →
      Segments gap classes middle last → Segments gap classes first last

/-- Every segmented interval follows the path-prefix order. -/
theorem segments_prefix (gap : Nat) (classes : Constraints) (first last : List Nat)
    (segments : Segments gap classes first last) : first.IsPrefix last := by
  cases segments with
  | short initial _ => exact initial
  | step initial _ remaining _ _ _ => exact initial.trans remaining

/-- Adding recorded paths preserves a segmentation certificate. -/
theorem segments_mono (gap : Nat) (before after : Constraints)
    (monotone : ∀ path ∈ members before, path ∈ members after) (first last : List Nat)
    (segments : Segments gap before first last) : Segments gap after first last := by
  induction segments with
  | short initial bound => exact .short initial bound
  | step initial proper remaining bound recorded nested ih => exact .step initial proper remaining bound (monotone _ recorded) ih

/-- An existing segmentation can be cut at any intermediate prefix. -/
