def NormalState (classes : Constraints) : Prop :=
  Active classes ∧ classes.Pairwise (fun left right => overlap left right = false) ∧
    classes.Pairwise (· ≤ ·) ∧ ∀ paths ∈ classes, canonicalClass paths = paths

/-- Completion establishes the canonical component invariants. -/
theorem complete_normal (classes : Constraints) (active : Active classes) : NormalState (complete classes) :=
  ⟨complete_active classes active, complete_disjoint classes, canonicalize_ordered _, canonicalize_members _⟩

/-- A successful step maintains canonical components. -/
theorem step_normal (classes output : Constraints) (active : Active classes)
    (success : congruenceStep classes = some output) : NormalState output := by
  dsimp only [congruenceStep] at success
  split at success
  next contradiction => simp at success
  next consistent =>
    have same : output = complete (addCongruences classes) := Option.some.inj success.symm
    subst output
    exact complete_normal _ (addCongruences_active classes active)
