theorem components_equal (classes : Constraints)
    (disjoint : classes.Pairwise (fun left right => overlap left right = false))
    (left right : Class) (leftMember : left ∈ classes) (rightMember : right ∈ classes)
    (path : Path) (inLeft : path ∈ left) (inRight : path ∈ right) : left = right := by
  by_cases same : left = right
  · exact same
  · have empty := disjoint_components classes disjoint left right leftMember rightMember same
    have shared := (overlap_correct left right).mpr ⟨path, inLeft, inRight⟩
    rw [empty] at shared
    contradiction

/-- One member of the first class is a proper prefix of a member of the second. -/
def Subsumes (first second : Class) : Prop :=
  ∃ left ∈ first, ∃ right ∈ second, left.IsPrefix right ∧ left ≠ right

