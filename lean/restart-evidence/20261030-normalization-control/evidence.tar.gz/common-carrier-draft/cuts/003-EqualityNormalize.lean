  deriving DecidableEq

/-- Interpret a completed normalization result. -/
def RunSat (term : Term Symbol) : RunResult → Prop
  | .timeout => False
  | .contradiction => False
  | .normalized classes => Satisfies term classes

/-- Iterate the source partial step until it fails, stabilizes, or consumes its bound. -/
def fixMaybe : Nat → Constraints → RunResult
  | 0, _ => .timeout
  | fuel + 1, classes =>
      match congruenceStep classes with
      | none => .contradiction
      | some next => if next = classes then .normalized classes else fixMaybe fuel next

/-- Every completed fixed-point execution preserves exactly the input language. -/
theorem fixMaybe_correct (term : Term Symbol) (fuel : Nat) (classes : Constraints)
    (active : Active classes) (finished : fixMaybe fuel classes ≠ .timeout) :
    RunSat term (fixMaybe fuel classes) ↔ Satisfies term classes := by
  induction fuel generalizing classes with
  | zero => simp [fixMaybe] at finished
  | succ fuel ih =>
      cases stepped : congruenceStep classes with
      | none => simpa [fixMaybe, stepped, RunSat, ResultSat] using congruenceStep_correct term classes active
      | some next =>
          by_cases stable : next = classes
          · simp [fixMaybe, stepped, stable, RunSat]
          · have nextActive := (congruenceStep_invariants classes next active stepped).1
            have nextFinished : fixMaybe fuel next ≠ .timeout := by simpa [fixMaybe, stepped, stable] using finished
            have current := congruenceStep_correct term classes active
            rw [stepped] at current
            simpa [fixMaybe, stepped, stable] using (ih next nextActive nextFinished).trans current

/-- A successful step has disjoint output classes. -/
theorem congruenceStep_disjoint (classes output : Constraints) (success : congruenceStep classes = some output) :
    output.Pairwise (fun left right => overlap left right = false) := by
  dsimp only [congruenceStep] at success
  split at success
  next contradictory => simp at success
  next consistent =>
    have same : output = complete (addCongruences classes) := Option.some.inj success.symm
    subst output
    exact complete_disjoint _

/-- A normalized result is active, disjoint, contradiction-free, and a step fixed point. -/
theorem fixMaybe_invariants (fuel : Nat) (classes output : Constraints) (active : Active classes)
    (success : fixMaybe fuel classes = .normalized output) :
    Active output ∧ isContradicting output = false ∧
      output.Pairwise (fun left right => overlap left right = false) ∧ congruenceStep output = some output := by
  induction fuel generalizing classes with
  | zero => simp [fixMaybe] at success
  | succ fuel ih =>
      cases stepped : congruenceStep classes with
      | none => simp [fixMaybe, stepped] at success
      | some next =>
          by_cases stable : next = classes
          · subst next
            have same : output = classes := by simpa [fixMaybe, stepped] using success.symm
            subst output
            have invariant := congruenceStep_invariants classes classes active stepped
            exact ⟨invariant.1, invariant.2, congruenceStep_disjoint classes classes stepped, stepped⟩
          · have recursive : fixMaybe fuel next = .normalized output := by simpa [fixMaybe, stepped, stable] using success
            exact ih next (congruenceStep_invariants classes next active stepped).1 recursive

/-- Normalize input path lists after set insertion, trivial-class removal, and completion. -/
def mkEqConstraints (fuel : Nat) (classes : Constraints) : RunResult := fixMaybe fuel (complete (prepare classes))

/-- Completed bounded normalization is equivalent to the original PCS constraints. -/
theorem mkEqConstraints_correct (term : Term Symbol) (fuel : Nat) (classes : Constraints)
    (finished : mkEqConstraints fuel classes ≠ .timeout) :
    RunSat term (mkEqConstraints fuel classes) ↔ Satisfies term classes :=
  (fixMaybe_correct term fuel _ (complete_active _ (prepare_active classes)) finished).trans
    ((complete_correct term _).trans (prepare_correct term classes))

/-- Successful normalization establishes the invariants needed by trie construction. -/
theorem mkEqConstraints_invariants (fuel : Nat) (classes output : Constraints)
    (success : mkEqConstraints fuel classes = .normalized output) :
    Active output ∧ isContradicting output = false ∧
      output.Pairwise (fun left right => overlap left right = false) ∧ congruenceStep output = some output :=
  fixMaybe_invariants fuel _ output (complete_active _ (prepare_active classes)) success

/-- Combining completed constraint sets normalizes their conjunction. -/
def combineEqConstraints (fuel : Nat) : RunResult → RunResult → RunResult
  | .timeout, _ => .timeout
