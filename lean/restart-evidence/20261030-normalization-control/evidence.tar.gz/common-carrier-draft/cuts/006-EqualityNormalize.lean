def Covers (before after : Constraints) : Prop :=
  ∀ paths ∈ before, ∃ larger ∈ after, ∀ path ∈ paths, path ∈ larger

/-- Class containment composes across completion steps. -/
theorem covers_trans (first second third : Constraints) (left : Covers first second) (right : Covers second third) :
    Covers first third := by
  intro paths member
