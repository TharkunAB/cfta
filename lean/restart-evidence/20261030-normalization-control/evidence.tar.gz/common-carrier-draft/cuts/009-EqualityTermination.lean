def SegmentedState (gap : Nat) (classes : Constraints) : Prop :=
  ∀ path ∈ members classes, Segments gap classes [] path

/-- One source step preserves the original maximum gap between marked prefixes. -/
theorem step_segmented (gap : Nat) (classes output : Constraints) (segmented : SegmentedState gap classes)
    (success : congruenceStep classes = some output) : SegmentedState gap output := by
  have outputEq : complete (addCongruences classes) = output := by
    dsimp only [congruenceStep] at success
    split at success
    next contradiction => simp at success
    next consistent => exact Option.some.inj success
  have retained : ∀ path ∈ members classes, path ∈ members output := by
    intro path member
    obtain ⟨paths, pathsMember, present⟩ := (mem_members _ _).mp member
    obtain ⟨component, componentMember, included⟩ := step_covers classes output success paths pathsMember
    exact (mem_members _ _).mpr ⟨component, componentMember, included path present⟩
  intro path recorded
  have added : path ∈ members (addCongruences classes) := by
    rw [← outputEq] at recorded
    exact (complete_members _ _).mp recorded
  obtain ⟨paths, pathsMember, present⟩ := (mem_members _ _).mp added
  rcases List.mem_append.mp pathsMember with old | generated
  · exact segments_mono gap classes output retained [] path (segmented path ((mem_members _ _).mpr ⟨paths, old, present⟩))
  · obtain ⟨source, sourceMember, suffixMember⟩ := List.mem_flatMap.mp generated
    obtain ⟨suffix, requested, same⟩ := List.mem_map.mp suffixMember
    subst paths
    obtain ⟨replacement, replacementMember, rfl⟩ := (mem_extendClass _ _ _).mp present
    obtain ⟨base, baseMember, extension, extensionMember, _, extensionEq⟩ := (mem_suffixes _ _ _).mp requested
    have replacementRecorded : replacement ∈ members classes := (mem_members _ _).mpr ⟨source, sourceMember, replacementMember⟩
    have baseInitial : base.IsPrefix extension := ⟨suffix, extensionEq⟩
    have first := segments_mono gap classes output retained [] replacement (segmented replacement replacementRecorded)
    have tail := segments_cut gap classes [] extension base (segmented extension extensionMember) (by simp) baseInitial
    have equal : inSame classes base replacement = true := (inSame_correct _ _ _).mpr ⟨source, sourceMember, baseMember, replacementMember⟩
    have translated := segments_replace gap classes output base replacement base extension tail (List.prefix_refl base)
      (fun path member initial => step_replace_member classes output base replacement path equal member initial success)
    have translated' : Segments gap output replacement (replacement ++ suffix) := by
      rw [← extensionEq] at translated
      simpa [replacePrefix] using translated
    exact segments_join gap output [] replacement (replacement ++ suffix) first translated' (retained replacement replacementRecorded)

/-- A class is encountered by a path when one of its members is a prefix. -/
