theorem step_anchored (anchors : List (List Nat)) (classes output : Constraints)
    (active : Active classes) (anchored : Anchored anchors classes)
    (success : congruenceStep classes = some output) : Anchored anchors output := by
  have normal := step_normal classes output active success
  have outputEq : complete (addCongruences classes) = output := by
    dsimp only [congruenceStep] at success
    split at success
    next contradiction => simp at success
    next consistent => exact Option.some.inj success
  intro component componentMember
  have inherits : ∀ source ∈ classes, ∀ shared, shared ∈ source → shared ∈ component →
      ∃ path, path ∈ component ∧ path ∈ anchors := by
    intro source sourceMember shared inSource inComponent
    obtain ⟨retained, retainedMember, included⟩ := step_covers classes output success source sourceMember
    have same := components_equal output normal.2.1 retained component retainedMember componentMember shared (included shared inSource) inComponent
    obtain ⟨anchor, anchorMember, original⟩ := anchored source sourceMember
    exact ⟨anchor, by simpa [same] using included anchor anchorMember, original⟩
  obtain ⟨path, present, _, _, _⟩ := normal.1 component componentMember
  have pathRecorded : path ∈ members output := (mem_members _ _).mpr ⟨component, componentMember, present⟩
  have added : path ∈ members (addCongruences classes) := by
    rw [← outputEq] at pathRecorded
    exact (complete_members _ _).mp pathRecorded
  obtain ⟨paths, pathsMember, atPath⟩ := (mem_members _ _).mp added
  rcases List.mem_append.mp pathsMember with old | generated
  · exact inherits paths old path atPath present
  · obtain ⟨source, sourceMember, mapped⟩ := List.mem_flatMap.mp generated
    obtain ⟨suffix, requested, same⟩ := List.mem_map.mp mapped
    subst paths
    obtain ⟨base, baseMember, originalPath, originalMember, _, equal⟩ := (mem_suffixes _ _ _).mp requested
    have generatedMember : extendClass source suffix ∈ addCongruences classes := List.mem_append_right _
      (List.mem_flatMap.mpr ⟨source, sourceMember, List.mem_map.mpr ⟨suffix, requested, rfl⟩⟩)
    obtain ⟨retained, retainedMember, included⟩ := complete_covers (addCongruences classes) (extendClass source suffix) generatedMember
    rw [outputEq] at retainedMember
    have same := components_equal output normal.2.1 retained component retainedMember componentMember path (included path atPath) present
    have originalInComponent : originalPath ∈ component := by
      have originalInGenerated := (mem_extendClass originalPath source suffix).mpr ⟨base, baseMember, equal⟩
      simpa [same] using included originalPath originalInGenerated
    obtain ⟨oldClass, oldClassMember, inOld⟩ := (mem_members _ _).mp originalMember
    exact inherits oldClass oldClassMember originalPath inOld originalInComponent

/-- Every active initial class has an anchor in its own finite recorded-path set. -/
theorem initially_anchored (classes : Constraints) (active : Active classes) : Anchored (members classes) classes := by
  intro paths member
  obtain ⟨path, present, _, _, _⟩ := active paths member
  exact ⟨path, present, (mem_members _ _).mpr ⟨paths, member, present⟩⟩

