
/-- Set insertion removes duplicates without changing PCS semantics. -/
theorem classSat_eraseDups (term : Term Symbol) (paths : Class) :
    ClassSat term paths.eraseDups ↔ ClassSat term paths :=
  classSat_congr term _ _ (by intro path; simp)

/-- A set with fewer than two members imposes no equality. -/
theorem trivial_satisfies (term : Term Symbol) (paths : Class) (trivial : ¬Nontrivial paths) : ClassSat term paths := by
  intro left leftMember right rightMember different
  exact False.elim (trivial ⟨left, leftMember, right, rightMember, different⟩)

/-- Decide whether a class has two distinct paths. -/
def nontrivialB (paths : Class) : Bool := paths.any (fun left => paths.any (fun right => decide (left ≠ right)))

/-- The finite class test is exact. -/
theorem nontrivialB_correct (paths : Class) : nontrivialB paths = true ↔ Nontrivial paths := by
  simp [nontrivialB, Nontrivial, List.any_eq_true]

/-- Remove repeated paths and classes with fewer than two set members. -/
def prepare (classes : Constraints) : Constraints :=
  (classes.map List.eraseDups).filter nontrivialB

/-- Input preparation preserves every PCS equality condition. -/
theorem prepare_correct (term : Term Symbol) (classes : Constraints) :
    Satisfies term (prepare classes) ↔ Satisfies term classes := by
  constructor
  · intro output paths member
    by_cases active : Nontrivial paths.eraseDups
    · apply (classSat_eraseDups term paths).mp
      exact output paths.eraseDups (List.mem_filter.mpr
        ⟨List.mem_map.mpr ⟨paths, member, rfl⟩, (nontrivialB_correct _).mpr active⟩)
    · exact (classSat_eraseDups term paths).mp (trivial_satisfies term paths.eraseDups active)
  · intro original paths member
    obtain ⟨mapped, _⟩ := List.mem_filter.mp member
    obtain ⟨source, sourceMember, rfl⟩ := List.mem_map.mp mapped
    exact (classSat_eraseDups term source).mpr (original source sourceMember)

/-- Preparation establishes the required path-existence invariant. -/
theorem prepare_active (classes : Constraints) : Active (prepare classes) := by
  intro paths member
  exact (nontrivialB_correct paths).mp (List.mem_filter.mp member).2

/-- Each path in a nontrivial satisfied class denotes an existing subterm. -/
