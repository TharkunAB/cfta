# Common original carrier through normalization

Status: source-only draft. Root compilation is pending.
Timestamp: 2026-10-30 02:24 CET.

The 167-line module `SourceEqualityNormalizationCarrier.lean` has 9,495 bytes and SHA256 `ee0ec58cb9179a648ac83d91293e9822bd688e44b0459655153a4a304cd688bd`. The proposed production filename was absent at intake. The exact draft is retained as `draft-v1.lean`.

The actual definitions support the proposed common invariant. `Anchored anchors classes` supplies an original anchor in each class. It is closed under list append. `SegmentedState gap classes` uses paths recorded in that same class list as its intermediate markers. Append retains each operand's markers, so `segments_mono` transfers each certificate to the concatenation. Alphabet use is also closed under append.

`Common gap anchors alphabet classes` packages those three existing predicates. The public interfaces are:

* `append_common`: concatenate two Common inputs with the SAME parameters.
* `prepare_common`: prepare an Active Common input.
* `complete_common`: complete an Active Common input.
* `fixMaybe_common`: preserve Common through an actual successful fixed-point iteration.
* `normalize_common`: preserve Common through actual successful source normalization and derive output NormalState and noncontradiction.
* `normalize_append_carrier`: normalize the concatenation and derive all preceding facts plus membership in the existing finite word carrier.

The last law takes Active first and second, Common with the same parameters for each, and the actual equation `SourceCompactGuards.normalize (first ++ second) = some output`. It returns Common output, NormalState output, noncontradiction, and `Within (words alphabet (gap * (anchors.length + 1))) output`. It does not assume input normality, disjointness, canonical order, consistency, a model, final path membership, or a future worker or packet. The gap, anchors, and alphabet are fixed parameters, independent of the normalization fuel or D.

## Exact proof route

Preparation is `(classes.map List.eraseDups).filter nontrivialB` at EqualityNormalize91–92. The private `prepare_members_active` lemma proves exact preservation of member paths under Active admission. It constructs the filtered deduplicated class using the actual `nontrivialB_correct` theorem. This retains every segmentation marker. Class anchors and alphabet membership then transfer directly.

Completion retains exactly the member paths by `complete_members`. For an output component, its actual Active/NormalState contract supplies a member. The source class containing that member is covered by a retained completed component through `complete_covers`. Output disjointness and `components_equal` identify that component with the selected output component. Its source anchor is therefore retained. Completion does not need any semantic model.

The fixed-point proof follows the actual fixMaybe branches. Timeout and contradiction cannot equal the observed normalized output. At a stable step, the actual output equals the input class list. Otherwise, the proof uses step_segmented, step_anchored, and step_alphabet, plus actual step activity, before applying the induction hypothesis. No output-membership property is used as an input.

The source-normalization proof follows the checked normalize_cached unfolding pattern: unfold normalize, rewrite arrayNormalize_eq, and split the actual mkEqConstraints result. The normalized branch uses the prepared/completed Common certificate. Its actual invariants supply activity, noncontradiction, and the fixed point. `step_normal` supplies NormalState. Finally, existing `bounded_state` supplies the finite carrier.

## Admission boundary

Active is an explicit required gate. It is not replaced by arbitrary input normality. Preparation can discard singleton classes that serve as segmentation markers. For example, with gap1, singleton classes `{0}`, `{00}`, `{1}`, `{11}` can mark prefixes for an active class `{000,111}`. Preparation drops the singleton markers but retains the active class. The same gap1 segmentation certificate does not follow for its retained length-three paths. This is a source-level explanation of the admission, not a compiled concrete counterexample. Initial source-cache Active admission must be obtained from its actual Cached/NormalClasses contract. Positive literal classes also need their actual nontrivial-literal admission.

This theorem does not initialize the common parameters from all original heap data. It does not yet lift them through every native constraint writer, sourceEqualities, or positiveNormalized. It does not establish nonfeedback of descended inherited workspace classes into native guard caches. It also supplies no handle, bucket multiplicity, allocation, recursion-key, worker-depth, or global coverage bound. Those remain separate obligations. No Haskell defect or fix was found.

## Source scope and execution

All source-cut identities and literal copies pass the recorded validation. New unions are EqualityNormalize159/1352 lines, EqualityTermination109/640, and EqualitySaturation18/436. New plus reused unions are EqualityNormalize323/1352, EqualityTermination253/640, SourceCompactGuards66/574, SourceEqualityGuardReadback52/105, and EqualitySaturation18/436. No whole old source was newly acquired. The largest fresh union is 17.1%; the largest reused total union is 49.5%. Even if the two largest total unions are conservatively charged as broad near-whole acquisitions, the task remains within its two-source limit.

The first four acquisition helpers were mistakenly run in parallel. Their shared manifest/index updates collided. The initial manifest and surviving copies are preserved under `initial-parallel-*`. All four exact scopes were then acquired sequentially, followed by the additional small scopes. `acquisitions.json` and `cuts/` contain the complete final record. No source content or proof result was lost in that final record. No tool display was truncated, and there was no requested/actual endpoint overrun. Whole-source bytes were hashed for identity; retained source content is limited to the declared cuts.

This owner ran no Lean/compiler, evaluator, native, Git, network, board, or subagent command. The repository and all frozen prior bundles remain unchanged. Root owns compilation and integration. The bundle will remain writable until Root reports results.
