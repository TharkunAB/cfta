  exact strict_prefix_paths_not_equal term left suffix nonempty
    (satisfied paths pathsMember left leftMember (left ++ suffix) rightMember different)

/-- One source normalization step: generate, complete, and check for contradictions. -/
def congruenceStep (classes : Constraints) : Option Constraints :=
  let closed := complete (addCongruences classes)
  if isContradicting closed then none else some closed

/-- A contradictory result denotes no complete terms. -/
def ResultSat (term : Term Symbol) : Option Constraints → Prop
  | none => False
  | some classes => Satisfies term classes
