theorem complete_members (classes : Constraints) (path : Path) :
    path ∈ members (complete classes) ↔ path ∈ members classes := by
  constructor
  · intro member
    obtain ⟨paths, pathsMember, present⟩ := (mem_members _ _).mp member
    exact (connected_member classes path path ((complete_components classes path path).mp
      ⟨paths, pathsMember, present, present⟩)).1
  · intro member
