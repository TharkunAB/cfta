/-- Actual Constraint.equalities retains its EmptyConstraints fast path. -/
noncomputable def sourceEqualities (constraint : Constraint Formula) : Option (List (List Path)) :=
  match positiveNormalized constraint.guard with
  | none | some (some []) => constraint.equalities
  | some added => combineEqualities constraint.equalities added

