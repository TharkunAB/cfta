def SegmentedState (gap : Nat) (classes : Constraints) : Prop :=
  ∀ path ∈ members classes, Segments gap classes [] path

/-- One source step preserves the original maximum gap between marked prefixes. -/
theorem step_segmented (gap : Nat) (classes output : Constraints) (segmented : SegmentedState gap classes)
    (success : congruenceStep classes = some output) : SegmentedState gap output := by
  have outputEq : complete (addCongruences classes) = output := by
    dsimp only [congruenceStep] at success
    split at success
    next contradiction => simp at success
    next consistent => exact Option.some.inj success
  have retained : ∀ path ∈ members classes, path ∈ members output := by
    intro path member
    obtain ⟨paths, pathsMember, present⟩ := (mem_members _ _).mp member
