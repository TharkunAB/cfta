def UsesAlphabet (alphabet : List Nat) (classes : Constraints) : Prop :=
  ∀ path ∈ members classes, ∀ index ∈ path, index ∈ alphabet

/-- Source suffix generation introduces no new child indices. -/
theorem step_alphabet (alphabet : List Nat) (classes output : Constraints)
    (allowed : UsesAlphabet alphabet classes) (success : congruenceStep classes = some output) : UsesAlphabet alphabet output := by
  have outputEq : complete (addCongruences classes) = output := by
    dsimp only [congruenceStep] at success
    split at success
    next contradiction => simp at success
    next consistent => exact Option.some.inj success
  intro path member index inPath
  have added : path ∈ members (addCongruences classes) := by
    rw [← outputEq] at member
    exact (complete_members _ _).mp member
  obtain ⟨paths, pathsMember, present⟩ := (mem_members _ _).mp added
  rcases List.mem_append.mp pathsMember with old | generated
  · exact allowed path ((mem_members _ _).mpr ⟨paths, old, present⟩) index inPath
  · obtain ⟨source, sourceMember, mapped⟩ := List.mem_flatMap.mp generated
    obtain ⟨suffix, requested, same⟩ := List.mem_map.mp mapped
    subst paths
    obtain ⟨replacement, replacementMember, rfl⟩ := (mem_extendClass _ _ _).mp present
    rcases List.mem_append.mp inPath with inReplacement | inSuffix
    · exact allowed replacement ((mem_members _ _).mpr ⟨source, sourceMember, replacementMember⟩) index inReplacement
    · obtain ⟨base, _, original, originalMember, _, equal⟩ := (mem_suffixes _ _ _).mp requested
      apply allowed original originalMember index
      rw [← equal]
      exact List.mem_append_right _ inSuffix

/-- All finite paths over an alphabet up to a supplied length. -/
def words (alphabet : List Nat) : Nat → List (List Nat)
  | 0 => [[]]
  | bound + 1 => [] :: alphabet.flatMap (fun index => (words alphabet bound).map (index :: ·))

/-- The finite word domain is exact. -/
theorem words_correct (alphabet : List Nat) (bound : Nat) (path : List Nat) :
    path ∈ words alphabet bound ↔ path.length ≤ bound ∧ ∀ index ∈ path, index ∈ alphabet := by
  induction bound generalizing path with
  | zero => cases path <;> simp [words]
  | succ bound ih =>
      cases path with
      | nil => simp [words]
      | cons index rest =>
          simp [words, ih, and_assoc, and_left_comm, and_comm]


/-- Every successful state lies in a fixed finite path domain. -/
theorem bounded_state (gap : Nat) (anchors : List (List Nat)) (alphabet : List Nat) (classes : Constraints)
    (normal : NormalState classes) (consistent : isContradicting classes = false)
    (segmented : SegmentedState gap classes) (anchored : Anchored anchors classes) (allowed : UsesAlphabet alphabet classes) :
    Within (words alphabet (gap * (anchors.length + 1))) classes := by
  intro path member
  apply (words_correct alphabet _ path).mpr
  have classBound := anchored_class_bound anchors classes anchored normal.2.1
  have lengthBound := segmented_length_bound gap classes consistent segmented path member
  have productBound := Nat.mul_le_mul_left gap (show classes.length + 1 ≤ anchors.length + 1 by omega)
  exact ⟨Nat.le_trans lengthBound productBound, allowed path member⟩


/-- A bounded-gap, anchored state reaches a fixed point or contradiction in finitely many steps. -/
theorem fixMaybe_finishes_bounded (gap : Nat) (anchors : List (List Nat)) (alphabet : List Nat)
