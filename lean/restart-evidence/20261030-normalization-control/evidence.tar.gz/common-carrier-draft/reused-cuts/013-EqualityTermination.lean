
/-- The initial finite path set bounds the maximum unmarked path segment. -/
def initialGap (classes : Constraints) : Nat := MicroCFTA.EqualityTrie.pathBudget (members classes)

/-- Every original path fits within one bounded segment. -/
theorem initially_segmented (classes : Constraints) : SegmentedState (initialGap classes) classes := by
  intro path member
  have bound := MicroCFTA.EqualityTrie.pathBudget_sufficient (members classes) path member
  exact .short (by simp) (by simp only [List.length_nil, Nat.zero_add]; exact Nat.le_of_lt bound)

/-- Collect the child indices that occur in the initial paths. -/
def initialAlphabet (classes : Constraints) : List Nat := (members classes).flatten.eraseDups

/-- Initial child indices lie in their computed finite alphabet. -/
theorem initially_allowed (classes : Constraints) : UsesAlphabet (initialAlphabet classes) classes := by
  intro path member index present
  simp only [initialAlphabet, List.mem_eraseDups, List.mem_flatten]
  exact ⟨path, member, present⟩

/-- A finite path domain for every successful state descended from the initial one. -/
def saturationDomain (classes : Constraints) : List (List Nat) :=
  words (initialAlphabet classes) (initialGap classes * ((members classes).length + 1))

/-- A conservative proof bound on strict relation growth and the final stopping step. -/
def saturationBound (classes : Constraints) : Nat := (pathPairs (saturationDomain classes)).length + 1

/-- Every canonical active state terminates without a finite-model premise. -/
theorem fixMaybe_terminates (classes : Constraints) (normal : NormalState classes) :
    fixMaybe (saturationBound classes) classes ≠ .timeout := by
  apply fixMaybe_finishes_bounded (initialGap classes) (members classes) (initialAlphabet classes)
    (saturationBound classes) classes normal (initially_segmented classes) (initially_anchored classes normal.1)
    (initially_allowed classes)
  unfold saturationBound saturationDomain
  omega

/-- The concrete normalization bound uses the prepared canonical starting state. -/
def normalizationBound (classes : Constraints) : Nat := saturationBound (complete (prepare classes))

/-- Source normalization always stops, including unsatisfiable inputs. -/
theorem mkEqConstraints_terminates (classes : Constraints) :
    mkEqConstraints (normalizationBound classes) classes ≠ .timeout :=
  fixMaybe_terminates (complete (prepare classes)) (complete_normal (prepare classes) (prepare_active classes))

