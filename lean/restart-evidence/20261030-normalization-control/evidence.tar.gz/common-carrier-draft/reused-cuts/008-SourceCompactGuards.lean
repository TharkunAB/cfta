theorem normalize_value (paths : List (List Path)) (active : EqualityNormalize.Active paths) (term : Term Symbol) :
    ConstraintIndicators.equalityValue (classTest term) (normalize paths) = paths.all (classTest term) := by
  unfold normalize
  rw [arrayNormalize_eq]
  exact SymbolicEqualityBridge.normalization_value term _ paths active (EqualityTermination.mkEqConstraints_terminates paths)

/-- The source combineEqConstraints cases, including both contradiction and empty shortcuts. -/
noncomputable def combineEqualities : Option (List (List Path)) → Option (List (List Path)) → Option (List (List Path))
  | none, _ | _, none => none
  | some [], some [] => some []
  | some first, some second => normalize (first ++ second)

/-- Combining normalized source operands keeps every stored class nontrivial. -/
theorem combine_active (first second : Option (List (List Path))) : ActiveOption (combineEqualities first second) := by
