noncomputable def combineEqualities : Option (List (List Path)) → Option (List (List Path)) → Option (List (List Path))
  | none, _ | _, none => none
  | some [], some [] => some []
  | some first, some second => normalize (first ++ second)

/-- Combining normalized source operands keeps every stored class nontrivial. -/
theorem combine_active (first second : Option (List (List Path))) : ActiveOption (combineEqualities first second) := by
  cases first with
