/-- The source EqConstraints view of a completed array run. -/
noncomputable def normalize (paths : List (List Path)) : Option (List (List Path)) :=
  SymbolicEqualityBridge.resultClasses (arrayNormalize paths)
