def members (classes : Constraints) : List Path := classes.flatten.eraseDups

/-- Recorded-path membership exposes its source class. -/
theorem mem_members (path : Path) (classes : Constraints) :
    path ∈ members classes ↔ ∃ paths ∈ classes, path ∈ paths := by
  simp [members]
