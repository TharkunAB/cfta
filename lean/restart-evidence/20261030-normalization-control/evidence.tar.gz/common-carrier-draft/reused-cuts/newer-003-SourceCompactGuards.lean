noncomputable def sourceEqualities (constraint : Constraint Formula) : Option (List (List Path)) :=
  match positiveNormalized constraint.guard with
  | none | some (some []) => constraint.equalities
  | some added => combineEqualities constraint.equalities added

mutual
/-- Intermediate array normalization does not change the source residual syntax test. -/
theorem positiveNormalized_support (guard : Guard Formula) :
    (positiveNormalized guard).isSome = (positive guard).isSome := by
  cases guard with
