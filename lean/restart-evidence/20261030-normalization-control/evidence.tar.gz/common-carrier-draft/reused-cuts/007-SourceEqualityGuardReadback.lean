open SourceCompactGuards

/-- A completed source payload has nontrivial, consistent, canonical classes. -/
def NormalClasses (classes : Constraints) : Prop :=
  Active classes ∧ isContradicting classes = false ∧
    ∀ paths ∈ classes, canonicalClass paths = paths

/-- Cached source equalities retain their actual normalized representation. -/
def Cached (equalities : Option Constraints) : Prop :=
  ∀ classes, equalities = some classes → NormalClasses classes

/-- Completed normalization supplies every physical source class invariant. -/
theorem normalized {fuel : Nat} {input output : Constraints}
    (done : mkEqConstraints fuel input = .normalized output) : NormalClasses output := by
  obtain ⟨active, consistent, _, fixed⟩ := mkEqConstraints_invariants _ _ _ done
  exact ⟨active, consistent, (EqualitySaturation.step_normal output output active fixed).2.2.2⟩

/-- Actual completed parent-array normalization derives the cached representation. -/
theorem normalize_cached (classes : Constraints) : Cached (normalize classes) := by
  intro output same
  unfold normalize at same
  rw [arrayNormalize_eq] at same
  cases done : mkEqConstraints (EqualityTermination.normalizationBound classes) classes with
  | timeout | contradiction => simp [done, SymbolicEqualityBridge.resultClasses] at same
  | normalized result =>
      have identical : result = output := by simpa [done, SymbolicEqualityBridge.resultClasses] using same
      subst output
      exact normalized done

/-- The empty source payload satisfies the same physical invariants. -/
theorem empty_cached : Cached (some []) := by
  intro classes same
  cases same
  simp [NormalClasses, Active, isContradicting]

/-- Actual source combination derives normalized classes, including its empty shortcut. -/
theorem combine_cached (first second : Option Constraints) : Cached (combineEqualities first second) := by
  cases first with
  | none => simp [combineEqualities, Cached]
  | some first => cases second with
    | none => simp [combineEqualities, Cached]
    | some second => cases first <;> cases second <;>
        first | exact empty_cached | exact normalize_cached _

/-- Constraint.equalities retains normalized physical payloads through every guard branch. -/
theorem source_cached (constraint : Constraint Formula) (cached : Cached constraint.equalities) :
    Cached (sourceEqualities constraint) := by
  unfold sourceEqualities
  split <;> first | exact cached | exact combine_cached _ _

/-- Cached class invariants imply the existing source indicator invariant. -/
theorem active {equalities : Option Constraints} (cached : Cached equalities) : ActiveOption equalities :=
