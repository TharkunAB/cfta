  SymbolicEqualityBridge.resultClasses (arrayNormalize paths)

/-- Canonical source equality classes are nontrivial. -/
def ActiveOption (equalities : Option (List (List Path))) : Prop :=
  ∀ paths, equalities = some paths → EqualityNormalize.Active paths

/-- Each completed array result establishes the cached-class invariant. -/
