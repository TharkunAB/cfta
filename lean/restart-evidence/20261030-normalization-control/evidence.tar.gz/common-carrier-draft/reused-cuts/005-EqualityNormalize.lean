theorem mem_members (path : Path) (classes : Constraints) :
    path ∈ members classes ↔ ∃ paths ∈ classes, path ∈ paths := by
  simp [members]

/-- Return the nonempty suffix of a strict path extension. -/
def strictSuffix (base extension : Path) : Option Path :=
  if base.IsPrefix extension ∧ base ≠ extension then some (extension.drop base.length) else none

/-- Prefix-suffix extraction is exact, including its strictness condition. -/
theorem strictSuffix_correct (base extension suffix : Path) :
    strictSuffix base extension = some suffix ↔ suffix ≠ [] ∧ base ++ suffix = extension := by
  constructor
  · intro selected
    unfold strictSuffix at selected
    split at selected
    next condition =>
      obtain ⟨rest, same⟩ := condition.1
      subst extension
      have equal : rest = suffix := by simpa using selected
      subst rest
      refine ⟨?_, rfl⟩
      intro empty
      simp [empty] at condition
    next condition => simp at selected
  · rintro ⟨nonempty, rfl⟩
    have distinct : base ≠ base ++ suffix := by
      intro equal
      have lengths := congrArg List.length equal
      simp only [List.length_append] at lengths
      have empty : suffix = [] := List.length_eq_zero_iff.mp (by omega)
      contradiction
    simp [strictSuffix, distinct]

/-- Every suffix read from a class and any recorded strict extension. -/
def suffixes (paths : Class) (classes : Constraints) : List Path :=
  (paths.flatMap (fun base => (members classes).filterMap (strictSuffix base))).eraseDups

/-- The suffix table records precisely the class's recorded strict extensions. -/
theorem mem_suffixes (suffix : Path) (paths : Class) (classes : Constraints) :
    suffix ∈ suffixes paths classes ↔
      ∃ base ∈ paths, ∃ extension ∈ members classes, suffix ≠ [] ∧ base ++ suffix = extension := by
  simp [suffixes, List.mem_flatMap, strictSuffix_correct]

/-- Extend every class member by the same suffix and preserve set semantics. -/
def extendClass (paths : Class) (suffix : Path) : Class := (paths.map (· ++ suffix)).eraseDups

/-- Generated classes contain exactly the uniformly extended paths. -/
theorem mem_extendClass (path : Path) (paths : Class) (suffix : Path) :
    path ∈ extendClass paths suffix ↔ ∃ base ∈ paths, base ++ suffix = path := by
  simp [extendClass]

/-- A common path suffix preserves distinctness of class members. -/
theorem extendClass_active (paths : Class) (suffix : Path) (active : Nontrivial paths) :
    Nontrivial (extendClass paths suffix) := by
  obtain ⟨left, leftMember, right, rightMember, different⟩ := active
  refine ⟨left ++ suffix, (mem_extendClass _ _ _).mpr ⟨left, leftMember, rfl⟩,
    right ++ suffix, (mem_extendClass _ _ _).mpr ⟨right, rightMember, rfl⟩, ?_⟩
  intro same
  exact different (List.append_cancel_right same)

/-- Add exactly the prefix-induced equality classes used by normalization. -/
def addCongruences (classes : Constraints) : Constraints :=
  classes ++ classes.flatMap (fun paths => (suffixes paths classes).map (extendClass paths))

/-- Prefix-induced classes remain nontrivial. -/
theorem addCongruences_active (classes : Constraints) (active : Active classes) : Active (addCongruences classes) := by
  intro paths member
  rcases List.mem_append.mp member with original | generated
  · exact active paths original
  · obtain ⟨source, sourceMember, built⟩ := List.mem_flatMap.mp generated
    obtain ⟨suffix, _, rfl⟩ := List.mem_map.mp built
    exact extendClass_active source suffix (active source sourceMember)

/-- Every recorded path exists under a satisfying assignment to active classes. -/
theorem member_exists (term : Term Symbol) (classes : Constraints) (active : Active classes)
    (satisfied : Satisfies term classes) (path : Path) (member : path ∈ members classes) :
    ∃ value, term.atPath path = some value := by
  obtain ⟨paths, pathsMember, pathMember⟩ := (mem_members path classes).mp member
  exact class_member_exists term paths (active paths pathsMember) (satisfied paths pathsMember) path pathMember

/-- Equal existing subterms inherit every suffix that exists at one class member. -/
theorem extendClass_satisfied (term : Term Symbol) (paths : Class) (active : Nontrivial paths)
    (satisfied : ClassSat term paths) (base suffix : Path) (baseMember : base ∈ paths)
    (existing : ∃ value, term.atPath (base ++ suffix) = some value) : ClassSat term (extendClass paths suffix) := by
  obtain ⟨value, found⟩ := existing
  have shared : ∀ path ∈ paths, term.atPath (path ++ suffix) = some value := by
    intro path member
    obtain ⟨root, atBase, atOther⟩ := class_pair_equal term paths active satisfied base path baseMember member
    rw [atPath_append, atBase] at found
    simpa [atPath_append, atOther] using found
