  apply Bool.eq_iff_iff.mpr
  simp only [overlap_correct, mem_canonicalClass]

/-- Canonical sorting retains disjoint components. -/
theorem canonicalize_disjoint (classes : Constraints)
    (disjoint : classes.Pairwise (fun left right => overlap left right = false)) :
    (canonicalize classes).Pairwise (fun left right => overlap left right = false) := by
  have mapped : (classes.map canonicalClass).Pairwise (fun left right => overlap left right = false) := disjoint.map canonicalClass (fun left right absent => by simpa [overlap_canonicalClass] using absent)
  exact mapped.perm (List.mergeSort_perm _ _).symm (fun absent => by rw [overlap_symm]; exact absent)

/-- Completion can merge at most the original number of classes. -/
def complete (classes : Constraints) : Constraints := canonicalize (completeFuel classes.length classes)

/-- Every finite completion pass preserves exactly the original equality conditions. -/
theorem completeFuel_correct (term : Term Symbol) (fuel : Nat) (classes : Constraints) :
    Satisfies term (completeFuel fuel classes) ↔ Satisfies term classes := by
  induction fuel generalizing classes with
  | zero => rfl
  | succ fuel ih =>
      cases merged : mergeOne classes with
      | none => simp [completeFuel, merged]
      | some output =>
          simp only [completeFuel, merged]
          exact (ih output).trans (mergeOne_correct term classes output merged)

/-- Completion preserves the path-existence invariant. -/
theorem completeFuel_active (fuel : Nat) (classes : Constraints) (active : Active classes) :
    Active (completeFuel fuel classes) := by
  induction fuel generalizing classes with
  | zero => exact active
  | succ fuel ih =>
      cases merged : mergeOne classes with
      | none => simpa [completeFuel, merged] using active
      | some output => simpa [completeFuel, merged] using ih output (mergeOne_active classes output active merged)

/-- The computed completion bound is sufficient to reach disjoint classes. -/
