# Existing signatures used by the draft

All paths are under `lean/MicroCFTA`. Exact source/copy hashes and endpoint records are in the manifests. Existing proofs are unchanged.

| Source | Scope | Used interface |
|---|---|---|
| EqualityNormalize | 23–37,454–459 | Path, Class, Constraints, members, mem_members |
| EqualityNormalize | 84–112 | nontrivialB_correct, prepare, prepare_active |
| EqualityNormalize | 920–921,995–1000 | Covers, complete_covers |
| EqualityNormalize | 1041–1050 | components_equal with output pairwise disjointness and a shared path |
| EqualityNormalize | 1228–1235 | complete_members: exact member equivalence |
| EqualityNormalize | 639–644 | fixMaybe actual branch definition |
| EqualityNormalize | 676–710 | fixMaybe/mkEqConstraints invariants and actual prepared/completed entry |
| EqualitySaturation | 176–193 | NormalState, complete_normal, step_normal |
| EqualityTermination | 210–229 | Segments, segments_mono |
| EqualityTermination | 311–349 | SegmentedState, step_segmented |
| EqualityTermination | 416–417,445–483 | Anchored, step_anchored |
| EqualityTermination | 492–518 | UsesAlphabet, step_alphabet |
| EqualityTermination | 539–548 | bounded_state |
| SourceCompactGuards | 367–375 | normalize and actual resultClasses wrapper |
| SourceEqualityGuardReadback | reused normalize_cached proof | actual normalize/arrayNormalize_eq/result split pattern |

The draft imports SourceEqualityGuardReadback. It opens EqualityNormalize, EqualitySaturation, EqualityTermination, and SourceCompactGuards. It adds no typeclass premise, axiom, proof placeholder, suppression, or executable evaluation.
