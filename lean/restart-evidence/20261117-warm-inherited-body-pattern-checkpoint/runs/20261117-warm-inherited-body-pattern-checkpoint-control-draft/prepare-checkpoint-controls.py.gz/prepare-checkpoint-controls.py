from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/tritlo/Code/mcfta')
BASE = ROOT / 'lean/restart-evidence'
WORK = Path(__file__).resolve().parent
assert WORK == BASE / '20261117-warm-inherited-body-pattern-work'
PUBLIC = BASE / '20261117-warm-inherited-body-pattern-publication'
ARCHIVE = '20261117-warm-inherited-body-pattern-checkpoint'
BOARD_PREFIX = 'current-board-warm-inherited-body-pattern-'
SHA = lambda data: hashlib.sha256(data).hexdigest()
GIT = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
read = lambda path: json.loads(path.read_text())
bindings = read(WORK / 'prior-bindings.json')
prior = bindings['prior_checkpoint']
commit = read(WORK / 'SOURCE-COMMIT.json')
code = commit['source_commit']
assert re.fullmatch(r'[0-9a-f]{40}', code)
assert commit['parent'] == prior
assert GIT('rev-parse', 'HEAD').decode().strip() == code
assert GIT('rev-parse', code + '^').decode().strip() == prior
assert GIT('branch', '--show-current').decode().strip() == 'formalize'
assert not GIT('status', '--porcelain', '--untracked-files=no')
report = read(PUBLIC / 'checked.json')
verified = read(WORK / 'PUBLICATION-VERIFIED.json')
assert verified['actual_terminal'] and verified['pins_unchanged']
assert verified['checks'] == report['checks']
assert len(report['checks']) == 5
assert [item['total_axiom_reports'] for item in report['checks']] == [680, 1, 275, 680, 680]
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['nonstandard_axioms']
           and not item['sorryAx'] for item in report['checks'])
for key, expected in {'source_files': 6253, 'direct_audit_imports': 5253,
                      'individual_reports': 680, 'independent_reports': 275,
                      'fresh_resource_component_reports': 1,
                      'inherited_resource_component_reports': 473,
                      'resource_and_component_probes': 474,
                      'fresh_owner_preflight_reports': 0,
                      'actual_publication_strict_reports': 1,
                      'new_modules': 1, 'new_public_theorems': 1,
                      'new_private_component_reports': 0, 'new_private_predicates': 0,
                      'new_theorem_reports': 1, 'replaced_old_reports': 0}.items():
    assert report[key] == expected, key
assert [(item['axiom_groups'], item['axiom_free_reports']) for item in report['checks']] == [
    (674, 6), (1, 0), (272, 3), (674, 6), (674, 6)]
assert not report['owner_recompiled_in_publication_strict_gate']
assert report['fresh_owner_preflight_evidence'] is None
assert report['inherited_owner_preflight_evidence']['reports'] == 264
assert not report['inherited_owner_preflight_evidence']['fresh_this_batch']
assert report['inherited_owner_preflight_evidence']['included_in_inherited_473']
assert report['new_theorem_declarations'] == 1
assert report['new_private_helpers'] == report['new_private_theorems'] == 0
assert report['private_helpers_checked_transitively']
assert not report['private_helpers_counted_as_explicit_fresh_reports']
for key in ['actual_inherited_cold_BP_hit_pair_absence_proved', 'qualification_derived_internally',
            'both_first_headers_byte_exact', 'full_open_header_not_compiled',
            'first_check_passed_without_repair', 'whole_worker_program_slots_fixed_marks_proved']:
    assert report[key], key
for key in ['future_semantic_law_supplied', 'future_Profile_or_Gamma_or_model_supplier',
            'fresh_evaluated_child_pair_absence_proved', 'same_warm_produced_cells_pair_absence_proved',
            'every_warm_worker_call_qualification_proved', 'warm_query_no_new_mu_proved',
            'all_warm_cells_source_qualification_proved',
            'earlier_source_family_semantic_IH_discharged', 'every_cell_joint_query_attachment_proved',
            'inherited_cell_semantic_chronology_proved', 'mixed_qualified_profile_height_orientation_derived',
            'independent_query_inherited_warm_tables_proved', 'warm_across_independent_queries_proved',
            'all_native_inhabitance_proved', 'source_type_marker_class_consistency_proved',
            'joint_finite_completion_proved', 'compiled_haskell_correspondence_proved', 'haskell_changed']:
    assert not report[key], key
pins = read(PUBLIC / 'source-pins.json')
for name, digest in pins.items():
    assert SHA((ROOT / name).read_bytes()) == digest, name
source_pins = {name: digest for name, digest in pins.items()
               if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
actual = {str(path.relative_to(ROOT)) for path in (ROOT / 'lean/MicroCFTA').glob('*.lean')}
assert len(source_pins) == 6253 and actual == set(source_pins)
assert verified['reverified_pins'] == len(pins)
for name in commit['files']:
    assert GIT('show', code + ':' + name) == (ROOT / name).read_bytes(), name
module = 'SourceSynthesisCurrentUniverseWarmInheritedChild'
module_path = 'lean/MicroCFTA/' + module + '.lean'
audit = 'lean/MicroCFTA/Audit.lean'
changed = {module_path, audit}
stage = read(WORK / 'SOURCES-NORMAL-STAGING.json')
assert stage['new_module'] == module and stage['source_path'] == module_path
assert stage['new_theorem_declarations'] == 1 and stage['fresh_explicit_axiom_reports'] == 1
assert stage['new_public_theorems'] == 1 and stage['new_private_helpers'] == 0
assert stage['private_helpers_covered_transitively']
assert set(commit['files']) == changed
assert set(GIT('diff', '--name-only', prior, code).decode().splitlines()) == changed
baseline = read(WORK / 'baseline-source-pins.json')
assert len(baseline) == 6252 and module_path not in baseline
assert actual == set(baseline) | {module_path}
for name, digest in baseline.items():
    if name != audit:
        assert source_pins[name] == digest, name
assert len(set(baseline) - {audit}) == 6251
old_audit = (WORK / 'Audit-BEFORE.lean.txt').read_bytes()
assert GIT('show', prior + ':' + audit) == old_audit
assert len(old_audit) == stage['old_audit_bytes'] == 425558
assert SHA(old_audit) == stage['old_audit_sha256']
assert old_audit.count(b'#print axioms ') == 679
packet = BASE / '20261117-next-warm-inherited-body-pattern-absence-draft'
assert (ROOT / module_path).read_bytes() == (packet / (module + '.lean')).read_bytes()
assert source_pins[module_path] == stage['raw_sha256'] == '5c73e9d63c6d25a265d731b7e8bb0e666060d4f5e8db0bc298011793a8821236'
assert SHA((packet / 'MANIFEST.json').read_bytes()) == stage['selected_manifest_sha256']
for name, item in [(item['file'], item) for item in read(packet / 'MANIFEST.json')['files']]:
    data = (packet / name).read_bytes()
    assert len(data) == item['bytes'] and SHA(data) == item['sha256'], name
for item in read(packet / 'SOURCE-PINS.json')['files']:
    data = (ROOT / item['path']).read_bytes()
    assert len(data) == item['bytes'] and SHA(data) == item['sha256'], item['path']
new_import = (WORK / 'IMPORTS.lean.txt').read_bytes()
assert new_import == ('import MicroCFTA.' + module + '\n').encode()
assert len(new_import) == stage['old_audit_exact_offset'] == 66
assert stage['old_audit_contiguous_bytes_preserved']
public = (WORK / 'PUBLIC-PROBES.lean.txt').read_bytes()
assert public == ''.join('#check ' + name + '\n#print axioms ' + name + '\n' for name in stage['names']).encode()
assert (ROOT / audit).read_bytes() == new_import + old_audit + b'\n' + public
owner = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
assert source_pins[owner] == baseline[owner] == report['old_resource_owner_sha256']
prior_archive = BASE / bindings['prior_archive']
for name, key in [('manifest.json', 'prior_manifest_sha256'),
                  ('checkpoint.json', 'prior_checkpoint_json_sha256')]:
    data = (prior_archive / name).read_bytes()
    assert SHA(data) == bindings[key]
    assert GIT('show', prior + ':' + str((prior_archive / name).relative_to(ROOT))) == data
old_checkpoint = read(prior_archive / 'checkpoint.json')
assert old_checkpoint['resource_and_component_probes'] == 473
assert report['inherited_resource_component_reports'] == old_checkpoint['resource_and_component_probes']
assert old_checkpoint['checked_code'] == GIT('rev-parse', prior + '^').decode().strip()
prior_files = {item['path']: item for item in read(prior_archive / 'manifest.json')['files']}
for name in ['source-pins.json.gz', 'verification.json', 'archived-inputs.json']:
    data = (prior_archive / name).read_bytes()
    assert len(data) == prior_files[name]['bytes']
    assert SHA(data) == prior_files[name]['sha256']
    assert GIT('show', prior + ':' + str((prior_archive / name).relative_to(ROOT))) == data
old_verification = read(prior_archive / 'verification.json')
assert old_verification['checked_code'] == old_checkpoint['checked_code']
assert old_verification['source_tree_sha256'] == old_checkpoint['source_tree_sha256']
assert old_verification['prior_document_bytes_preserved']
old_pins = json.loads(gzip.decompress((prior_archive / 'source-pins.json.gz').read_bytes()))
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    assert old_pins[name] == pins[name], name
assert baseline == {name: digest for name, digest in old_pins.items()
                    if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
request = read(WORK / (BOARD_PREFIX + 'request.json'))
canonical = read(WORK / (BOARD_PREFIX + 'canonical.json'))
assert canonical.get('verified', True)
post = canonical.get('post', canonical)
assert post['id'] == request['request_id']
assert type(post['sequence']) is int and post['sequence'] > 0
for key, expected in [('author', request['username']), ('thread_id', request['thread_id']),
                      ('post_type', request['post_type']), ('content', request['content']),
                      ('metadata', request['metadata'])]:
    assert post[key] == expected, key
assert post['metadata']['source'] == code
receipt = read(WORK / 'FIRST-CHECK-VERIFIED.json')
assert receipt['actual_session'] == 88089 and receipt['actual_terminal_exit'] == 0
assert receipt['both_first_headers_exact'] and receipt['full_open_header_not_compiled']
assert receipt['actual_inherited_cold_BP_hit_pair_absence_proved'] and receipt['qualification_derived_internally']
assert not receipt['future_semantic_law_supplied']
checked = read(BASE / receipt['run'] / 'checked.json')
assert receipt['checks'] == checked['checks']
assert checked['normal_module_checked'] and checked['source_pins_unchanged']
assert checked['checks'][-1]['total_axiom_reports'] == 1
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['nonstandard_axioms']
           and not item['sorryAx'] for item in checked['checks'])
chronology = BASE / '20261117-same-warm-returned-cell-chronology-audit'
assert SHA((chronology / 'MANIFEST.json').read_bytes()) == bindings['chronology_audit_manifest_sha256']
chronology_manifest = read(chronology / 'MANIFEST.json')
assert chronology_manifest['status'] == 'FROZEN_SOURCE_REUSE_MAP_NO_NEW_THEOREM'
assert not chronology_manifest['compilerRun'] and not chronology_manifest['sourceWrites']
for name, digest in chronology_manifest['files'].items():
    assert SHA((chronology / name).read_bytes()) == digest, name
assert (chronology / 'FULL-OPEN-TARGET-UNCHANGED.lean.txt').read_bytes() == (packet / 'FULL-OPEN-FIRST-HEADER.lean.txt').read_bytes()
cleanup = read(WORK / 'combined-terminal-cleanup-result.json')
assert cleanup['no_double_counting'] and cleanup['all_terminal_directories_distinct']
cleanup_paths = [item.get('directory', item.get('path')) for item in cleanup['targets']]
assert all(isinstance(path, str) and path for path in cleanup_paths)
assert len(set(cleanup_paths)) == len(cleanup_paths)
assert cleanup['all_targets_absent']
assert cleanup['sources_logs_live_jobs_normal_lake_unknown_entries_preserved']
assert cleanup['removed_bytes'] == sum(item['bytes'] for item in cleanup['targets'])
assert cleanup['cumulative_removed_bytes'] >= cleanup['removed_bytes']
assert all(item['terminal_exit'] in [0, 1] for item in cleanup['targets'])
start = read(WORK / 'START.json')
assert start['user_explicitly_resumed'] and start['earlier_usage_pause_lifted']
assert start['active_work_authorized']
resume = read(WORK / 'RESUME-AUTHORIZATION.json')
assert resume['user_explicitly_resumed'] and resume['earlier_usage_pause_lifted'] and resume['work_authorized']
assert resume['user_instruction'] == "Keep going. We'll use a reset if needed."
assert resume['persistent_goal_control_at_resume'] == 'paused' and resume['no_goal_resume_operation_available']
usage = read(WORK / 'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int, float] and 0 <= percent <= 100
assert usage['earlier_usage_pause_lifted_by_user_resume']
roots = read(WORK / 'selection-roots.json')
additional_path = WORK / 'archive-additional-roots.json'
additional = read(additional_path) if additional_path.exists() else []
for item in additional:
    assert re.fullmatch(r'20261117-[a-z0-9-]+', item['root'])
    assert item['manifest'] in ['MANIFEST.json', 'manifest.json', 'MANIFEST.sha256']
    assert SHA((BASE / item['root'] / item['manifest']).read_bytes()) == item['sha256']
    roots.append(item['root'])
assert len(roots) == len(set(roots))
assert all((BASE / name).is_dir() and not (BASE / name).is_symlink() for name in roots)
# Each selected compiler run must have an actual terminal result.
for name in roots:
    run = BASE / name
    if (run / 'PREPARATION-FAILED.json').exists():
        failure = read(run / 'PREPARATION-FAILED.json')
        assert not failure['compiler_started']
        assert not failure['source_or_object_output_created']
    elif (run / 'check.py').exists():
        result = read(run / ('checked.json' if (run / 'checked.json').exists() else 'results.json'))
        assert result['checks'] and all(type(item['exit']) is int for item in result['checks']), name
for item in read(WORK / 'original-header-files.json'):
    assert SHA((ROOT / item['path']).read_bytes()) == item['sha256'], item['path']
    assert SHA((ROOT / item['original']).read_bytes()) == item['sha256'], item['original']
selected = sorted(str((BASE / name).relative_to(ROOT)) for name in roots)
assert not (BASE / ARCHIVE).exists()
config = dict(report)
tree = hashlib.sha256()
for name, digest in sorted(source_pins.items()):
    tree.update(name.encode() + b'\0' + digest.encode() + b'\n')
config.update(checked_code=code, prior_checkpoint=prior, public_run=str(PUBLIC), public_gates=5,
    explicit_reports=report['individual_reports'], board_prefix=BOARD_PREFIX,
    board_post_id=post['id'], board_sequence=post['sequence'],
    source_tree_sha256=tree.hexdigest(),
    old_non_audit_source_files_byte_exact=6251,
    old_audit_contiguous_bytes_preserved=425558, old_audit_exact_offset=66,
    ordinary_audit_import_bytes=66, new_audit_imports=1, old_audit_is_prefix=False,
    old_owner_proof_bodies_unchanged=True, old_owner_proof_limits_unchanged=True,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],
    cleanup_receipt='combined-terminal-cleanup-result.json',
    primary_usage_percent=usage['rate_limits']['primary']['used_percent'],
    primary_usage_checked_at=usage['event_timestamp'],
    prior_immutable_archive=bindings['prior_archive'],
    prior_manifest_sha256=bindings['prior_manifest_sha256'],
    new_theorem_declarations=1, fresh_strict_reports=1,
    inherited_component_reports=473, replaced_old_reports=0,
    all_new_formal_proof_checks_first_pass=True, first_check_passed_without_repair=True,
    historical_failed_proofs_preserved_in_prior_immutable_chain=True,
    chronology_audit_new_theorem_credit=0,
    chronology_audit_manifest_sha256=bindings['chronology_audit_manifest_sha256'],
    user_explicitly_resumed=True, earlier_usage_pause_lifted=True,
    work_authorized_by_explicit_user_resume=True,
    persistent_goal_control_status='paused', goal_resume_operation_performed=False,
    goal_completion_claimed=False,
    private_helpers_add_no_explicit_report_credit=True,
    additional_uncompiled_candidates_add_no_theorem_credit=True,
    additional_frozen_roots=additional,
    joint_finite_completion_proved=False,
    compiled_haskell_correspondence_proved=False, haskell_changed=False, goal_active=False)
skipped = sorted(str(path.relative_to(ROOT)) for path in BASE.iterdir()
    if path.is_dir() and path.name.startswith('20261117-') and str(path.relative_to(ROOT)) not in selected)
review = {
    'prior_checkpoint': prior, 'prior_immutable_archive': bindings['prior_archive'],
    'prior_manifest_sha256': bindings['prior_manifest_sha256'], 'selected_roots': len(selected),
    'base_roots': len(read(WORK / 'selection-roots.json')), 'additional_frozen_roots': additional,
    'policy': 'Keep the exact inherited-hit first candidate and both FIRST headers, successful first strict check, publication controls/runtime, full actual child OPEN target, exact same-warm chronology audit with no theorem credit, and current full target. Historical failed proofs remain in the prior immutable chain. Additional frozen candidates add no theorem credit.',
    'new_public_theorem_reports': 1, 'new_private_component_reports': 0,
    'new_private_helpers': 0, 'new_private_predicates': 0, 'new_theorem_declarations': 1,
    'fresh_owner_preflight_reports': 0, 'actual_publication_strict_reports': 1,
    'fresh_reports_this_batch': 1, 'inherited_bound_reports': 473,
    'prior_component_reports': 473, 'replaced_old_reports': 0,
    'inherited_owner_reports_included': 264,
    'all_new_formal_proof_checks_first_pass': True,
    'first_check_passed_without_repair': True, 'private_helpers_counted_as_explicit_reports': False,
    'actual_inherited_cold_BP_hit_pair_absence_proved': True, 'qualification_derived_internally': True,
    'fresh_evaluated_child_pair_absence_proved': False, 'same_warm_produced_cells_pair_absence_proved': False,
    'full_actual_child_header_compiled': False, 'chronology_audit_new_theorem_credit': 0,
    'all_warm_worker_call_qualifications_proved': False, 'warm_query_no_new_mu_proved': False,
    'earlier_source_family_semantic_IH_discharged': False,
    'every_cell_joint_query_attachment_proved': False, 'inherited_cell_semantic_chronology_proved': False,
    'warm_across_independent_queries_proved': False, 'all_native_inhabitance_proved': False,
    'type_marker_class_consistency_proved': False, 'joint_finite_completion_proved': False,
    'haskell_changed': False, 'no_axiom_string_replay': True,
    'no_compiled_objects_or_import_overlays': True,
    'user_explicitly_resumed': True, 'earlier_usage_pause_lifted': True,
    'persistent_goal_control_status': 'paused', 'goal_resume_operation_performed': False,
}
note = (WORK / 'checkpoint-note.md').read_text()
for key, value in {'THEOREMS': report['audited_theorems'], 'REMOVED': cleanup['removed_bytes'],
                   'CLEANUP': cleanup['cumulative_removed_bytes'],
                   'USAGE': config['primary_usage_percent']}.items():
    note = note.replace('{{' + key + '}}', str(value))
assert set(re.findall(r'\{\{(.*?)\}\}', note)) == {'TIME', 'TREE', 'CODE'}
outputs = {'checkpoint-config.json': config, 'archive-roots.json': selected,
           'skipped-published-roots.json': skipped, 'selection-review.json': review}
assert all(not (WORK / name).exists() for name in outputs)
for name, value in outputs.items():
    (WORK / name).write_text(json.dumps(value, indent=2) + '\n')
(WORK / 'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code': code, 'packet': ARCHIVE,
                  'roots': len(selected), 'board_sequence': post['sequence'],
                  'new_theorem_declarations': 1, 'fresh_strict_reports': 1, 'inherited_reports': 473}))
