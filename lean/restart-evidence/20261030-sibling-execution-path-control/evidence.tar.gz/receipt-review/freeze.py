from pathlib import Path
import datetime
import hashlib
import json

area = Path('/tmp/mcfta-sibling-execution-path-control-20261030/receipt-review')

def digest(data):
    return hashlib.sha256(data).hexdigest()

now = datetime.datetime.now().astimezone().isoformat()
checks = []
for ledger_name in ('acquisitions.json', 'reuse-ledger.json'):
    for row in json.loads((area / ledger_name).read_text()):
        source = Path(row['source_path'])
        current = source.read_bytes()
        copy = (area / row['copy']).read_bytes()
        assert len(current) == row['source_bytes']
        assert digest(current) == row['source_sha256']
        assert len(copy) == row['copy_bytes']
        assert digest(copy) == row['copy_sha256']
        frozen_same = None
        if 'frozen_copy' in row:
            frozen = Path(row['frozen_bundle']) / row['frozen_copy']
            assert frozen.read_bytes() == current
            frozen_same = True
        checks.append({'source_path':str(source), 'source_bytes':len(current),
                       'source_sha256':digest(current), 'owned_copy':row['copy'],
                       'same_current_source':current == copy, 'same_frozen_copy':frozen_same})
root = (area / 'root-FROZEN.json').read_bytes()
assert digest(root) == '5189cdf101d7ecf8e70ff7e88b50754b80ace164c93d8dfbb872f0ed0b6b677f'
assert json.loads(root)['write_halt'] is True
(area / 'final-source-verification.json').write_text(json.dumps({'time':now,'checks':checks},indent=2)+'\n')
incidents = {
    'time':now,
    'compiler_or_evaluator_runs':[],
    'source_truncations':[],
    'whole_body_budget':2,
    'new_whole_body_count':2,
    'near_whole_or_union_overruns':[],
    'non_source_events':[
        'python executable unavailable; text generation retried successfully with python3',
        'one collaboration acknowledgement at 09:15 reported model-context truncation; source acquisitions were not truncated',
        'Python text generator import created a bytecode cache inside the owned directory; cache removed',
        'CallbackControl production file presence test found it absent; no source bytes acquired'
    ],
    'untested_api':[
        'ExecutionCallbackControl.native_left_of_singleton and prepared_left_of_singleton: names and intended premises supplied by Root; exact compiled headers not acquired'
    ]
}
(area / 'incidents.json').write_text(json.dumps(incidents,indent=2)+'\n')
for path in (area / 'pins.json', area / 'FROZEN'):
    assert not path.exists()
payloads=[]
for path in sorted(area.rglob('*')):
    if path.is_file():
        data=path.read_bytes()
        payloads.append({'path':str(path.relative_to(area)),'bytes':len(data),'sha256':digest(data)})
pins={'time':now,'owner':'/root/earlier_stop_control','status':'SOURCE-ONLY UNCOMPILED',
      'write_halt':True,'payloads':payloads}
(area / 'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
seal={'time':now,'write_halt':True,'proof_status':'New receipt draft UNCOMPILED',
      'payload_count':len(payloads),'pins_sha256':digest((area/'pins.json').read_bytes()),
      'draft_sha256':digest((area/'ExecutionReceiptBridge-v1-UNCOMPILED.lean').read_bytes()),
      'report_sha256':digest((area/'REPORT.md').read_bytes()),
      'scope':'Two authorized old whole bodies; three frozen full source reuses; no additional production body read',
      'pending':'Root singleton helper header compatibility and all new compilation remain unchecked'}
(area / 'FROZEN').write_text(json.dumps(seal,indent=2)+'\n')
for path in area.rglob('*'):
    if path.is_file():
        path.chmod(0o444)
for path in sorted(area.rglob('*'),reverse=True):
    if path.is_dir():
        path.chmod(0o555)
area.chmod(0o555)
print(json.dumps(seal,indent=2))
print('FROZEN_SHA256',digest((area/'FROZEN').read_bytes()))
