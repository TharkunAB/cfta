from pathlib import Path
import hashlib,json
owner=Path(__file__).parent;base=Path('/tmp/mcfta-execution-path-control-20261030');repo=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
sha=lambda b:hashlib.sha256(b).hexdigest()
freeze=(base/'FROZEN.json').read_bytes();manifest=json.loads(freeze);assert manifest['write_halt'] is True
(owner/'root-FROZEN.json').write_bytes(freeze);(owner/'reused').mkdir()
records=[]
for module in ['SourcePruningEnumerationExecutionPaths','SourcePruningEnumerationExecutionPathData','SourcePruningEnumerationExecutionCallbackBridge']:
 source=repo/(module+'.lean');full=source.read_bytes();h=sha(full)
 matches=[r for r in manifest['payloads'] if r['sha256']==h and r['path'].endswith(module+'.lean')]
 assert matches
 matches.sort(key=lambda r:(not ('strict' in r['path'] and ('checked' in r['path'] or '/MicroCFTA/' in r['path'])),r['path']))
 r=matches[0];b=(base/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==h and b==full
 dest=owner/'reused'/(module+'.lean');dest.write_bytes(b)
 records.append({'source_path':str(source),'source_bytes':len(full),'source_lines':len(full.splitlines()),'source_sha256':h,'actual_start':1,'actual_end':len(full.splitlines()),'requested_start':1,'requested_end':len(full.splitlines()),'copy':str(dest.relative_to(owner)),'copy_bytes':len(b),'copy_sha256':h,'frozen_bundle':str(base),'frozen_manifest':'FROZEN.json','frozen_manifest_sha256':sha(freeze),'frozen_copy':r['path'],'whole':True,'new_whole':False})
(owner/'reuse-ledger.json').write_text(json.dumps(records,indent=2)+'\n')
for r in records:print(r['copy'],r['copy_bytes'],r['source_sha256'],r['frozen_copy'])
print((owner/'reused/SourcePruningEnumerationExecutionPaths.lean').read_text())
