import hashlib
import json
from pathlib import Path
from build_draft import area, parts

def sha(value):
    return hashlib.sha256(value.encode()).hexdigest()

records = []
for variant, index, name in [
    ('Native', '001', 'SourcePruningEnumerationFiniteReceiptResources.lean'),
    ('Prepared', '002', 'SourcePruningEnumerationPreparedFiniteReceiptResources.lean')]:
    old = (area / 'cuts' / f'{index}-{name}').read_text()
    old_header = old.split('theorem receipt_finite_complete_resources\n', 1)[1].split(' := by\n', 1)[0]
    old_inputs, old_result = old_header.split(' :\n    ∃', 1)
    namespace, preamble, header, _, _ = parts(variant)
    new_header = header.split('theorem receipt_finite_complete_resources_paths\n', 1)[1]
    recovered_inputs = new_header.split('\n    (P : EqualityTrie.Path → Prop)', 1)[0]
    new_result = new_header.split(' :\n    ∃', 1)[1]
    recovered_result = new_result.split(' ∧\n      (∀ extra, match (generalizing := false) receipt with', 1)[0]
    old_context = old.split('\nopen EnumerationState', 1)[1].split('/--', 1)[0]
    old_context = 'open EnumerationState' + old_context
    assert recovered_inputs == old_inputs
    assert recovered_result == old_result
    assert old_context in preamble
    records.append({
        'variant': variant,
        'old_theorem': 'receipt_finite_complete_resources',
        'new_namespace': namespace,
        'new_theorem': 'receipt_finite_complete_resources_paths',
        'all_old_inputs_verbatim': True,
        'all_old_result_clauses_verbatim': True,
        'all_old_context_lines_including_three_instances_verbatim': True,
        'old_inputs_sha256': sha(old_inputs),
        'old_result_sha256': sha(old_result),
        'old_context_sha256': sha(old_context),
        'added_inputs': ['P', 'receiptPaths', 'projected', 'pathsIH'],
        'appended_conjuncts': ['LeftPaths for every extra on the complete receipt', 'OutcomePaths of the stable outcome'],
        'kernel_checked': False,
        'scope': 'text recovery only; new Prepared namespace explicitly opens original PreparedRecursive scope'
    })
(area / 'header-recovery.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))
