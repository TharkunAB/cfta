from pathlib import Path
import hashlib
import json
import sys

area = Path(__file__).resolve().parent
source = Path('/home/tritlo/Code/mcfta') / sys.argv[1]
first, last = map(int, sys.argv[2:4])
data = source.read_bytes()
lines = data.splitlines(keepends=True)
assert 1 <= first <= last <= len(lines)
record_path = area / 'acquisitions.json'
records = json.loads(record_path.read_text()) if record_path.exists() else []
out = area / 'cuts' / f'{len(records) + 1:03d}-{source.name}'
out.parent.mkdir(exist_ok=True)
copy = b''.join(lines[first - 1:last])
out.write_bytes(copy)
record = dict(source_path=str(source), source_bytes=len(data), source_lines=len(lines),
              source_sha256=hashlib.sha256(data).hexdigest(), requested_start=first,
              requested_end=last, actual_start=first, actual_end=last,
              copy=str(out.relative_to(area)), copy_bytes=len(copy),
              copy_sha256=hashlib.sha256(copy).hexdigest(), whole=first == 1 and last == len(lines))
records.append(record)
record_path.write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(record))
for number, line in enumerate(copy.decode().splitlines(), first):
    print(f'{number}: {line}')
