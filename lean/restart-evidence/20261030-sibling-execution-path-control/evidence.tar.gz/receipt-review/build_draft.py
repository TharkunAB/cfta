from pathlib import Path

area = Path('/tmp/mcfta-sibling-execution-path-control-20261030/receipt-review')

def parts(variant):
    native = variant == 'Native'
    old_name = ('SourcePruningEnumerationFiniteReceiptResources.lean' if native else
                'SourcePruningEnumerationPreparedFiniteReceiptResources.lean')
    index = '001' if native else '002'
    old = (area / 'cuts' / f'{index}-{old_name}').read_text()
    old_namespace = ('MicroCFTA.SourcePruningEnumerationNativeHookResources' if native else
                     'MicroCFTA.SourcePruningEnumerationPreparedRecursive')
    namespace = f'MicroCFTA.SourcePruningEnumerationExecutionReceiptBridge.{variant}'
    reservation = ('SourcePruningEnumerationFiniteReservation' if native else
                   'SourcePruningEnumerationPreparedReservation')
    failure = f'{variant}FailurePaths'
    resume = f'Resume{variant}'
    concrete = f'SourcePruningEnumerationExecutionPaths.{variant}'
    callback = f'SourcePruningEnumerationExecutionCallbackBridge.{variant}'
    worker = ('SourcePruningEnumerationRecursive' if native else
              'SourcePruningEnumerationPreparedRecursive')
    preamble = old.split(f'namespace {old_namespace}\n', 1)[1].split('/--', 1)[0]
    if not native:
        preamble = 'open SourcePruningEnumerationPreparedRecursive\n' + preamble
    preamble += '''open SourcePruningEnumerationPathTransport (StatePaths ProjectionPaths)
open SourcePruningEnumerationExecutionPathData (FullReceiptPaths OutcomePaths NativeFailurePaths PreparedFailurePaths)
open SourcePruningEnumerationExecutionPaths (LeftPaths ResumeNative ResumePrepared)
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Metadata" => SourcePruningRecordTypes.Metadata
local notation "suspendedBound" => SourcePruningEnumerationPrefixAdmission.suspendedBound
'''
    old_header = old.split('theorem receipt_finite_complete_resources\n',1)[1].split(' := by\n',1)[0]
    old_inputs, old_result = old_header.split(' :\n    ∃',1)
    old_inputs = old_inputs.replace('(reserved : '+reservation+'.Reserved bits recursiveFuel seed ceiling)',
        '(reserved : '+reservation+'.Reserved bits recursiveFuel seed ceiling)')
    new_inputs = f'''
    (P : EqualityTrie.Path → Prop)
    (receiptPaths : FullReceiptPaths P receipt)
    (projected : ProjectionPaths ({reservation}.final recursiveFuel seed ceiling).1 P)
    (pathsIH : ∀ (nextInventory : Inventory) (nextCaller : Caller (bits + 2))
        (nextMemos : Memos) (nextCache : Cached) (nextMetadata : Metadata Typing)
        (nextSeed : Seed) (nextCeiling : Nat),
      Packet formulas solver nextInventory nextCaller nextMemos nextMetadata nextCache →
      Fits nextSeed.2 nextCaller.checked →
      Heap (fun guard => guard ∈ nextSeed.1) nextCaller.checked.native.machine.heap →
      (∀ entry rows depth free, ∀ edge ∈ edgesOf (.node entry rows depth free), edge ∈ rows) →
      (∀ entry rows depth free, (edgesOf (.node entry rows depth free)).length ≤ rows.length) →
      suspendedBound nextCache.core ≤ nextCeiling →
      {reservation}.Reserved bits recursiveFuel nextSeed nextCeiling →
      StatePaths P nextCache.core →
      ProjectionPaths ({reservation}.final recursiveFuel nextSeed nextCeiling).1 P →
      ∃ bound, ∀ extra,
        {concrete} P holeKey fits admits graph templates checkEmpty edgesOf stop order
          (bound + extra) recursiveFuel nextMetadata nextCaller nextMemos.query nextCache)'''
    added_result = f''' ∧
      (∀ extra, match (generalizing := false) receipt with
        | .complete fragment actual saved after =>
            LeftPaths P
              ({resume} P holeKey fits admits graph templates checkEmpty edgesOf stop order
                (fuel + extra) recursiveFuel)
              ({failure} P)
              (continueWith
                (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
                  (fuel + extra) recursiveFuel)
                graph templates stop order (fuel + extra) metadata uv)
              graph templates stop order (fuel + extra) metadata uv fragment actual saved after
        | _ => True) ∧
      OutcomePaths P ({failure} P) outcome'''
    header = 'theorem receipt_finite_complete_resources_paths\n' + old_inputs + new_inputs + ' :\n    ∃' + old_result + added_result
    left_type = f'''∀ extra,
          LeftPaths P
            ({resume} P holeKey fits admits graph templates checkEmpty edgesOf stop order
              (fuel + extra) recursiveFuel)
            ({failure} P)
            (continueWith
              (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
                (fuel + extra) recursiveFuel)
              graph templates stop order (fuel + extra) metadata uv)
            graph templates stop order (fuel + extra) metadata uv fragment reached final.query after'''
    body_start = f'''  cases receipt with
  | unhandled => cases advanced
  | rejected actual saved after | stopped fragments observation candidate =>
      have originalResources : OutcomeResources (Typing := Typing) formulas solver reached seed
          (.complete [] reached final.query) := by
        refine ⟨reached, next, final, Post.refl post.context, bounded, known, rfl, rfl, ?_⟩
        intro output member
        exact False.elim (List.not_mem_nil member)
      have growth := {reservation}.final_ge recursiveFuel seed ceiling
      refine ⟨0, .complete [] reached final.query, fun _ => rfl,
        originalResources.mono growth.1 growth.2, ?_, ?_⟩
      · intro _extra
        trivial
      · intro output member
        exact False.elim (List.not_mem_nil member)
  | complete fragment actual saved after =>
      have endpoints : (actual, saved) = (reached, final.query) := Option.some.inj advanced
      obtain ⟨callerSame, querySame⟩ := Prod.mk.inj endpoints
      subst actual
      subst saved
      obtain ⟨level, frontier, ordered⟩ := packet.ordered
      have current := SourcePruningEnumerationRecursive.receipt_packet before.core uv fragment after level frontier
        post.context admitted history pending ordered packet.bounded
      have currentPaths : StatePaths P after.core := receiptPaths.1
      obtain ⟨fuel, result, callbackCore, outcome, _returned, _stable, _frame, _types, _holes, _typing,
        callback, running, resources, _framedPaths, continuing⟩ :=
        {callback}.callback_finite_complete_resources_with_execution_ih
          holeKey fits admits formulas solver next graph templates metadata uv fragment reached final after
          checkEmpty edgesOf stop order recursiveFuel recursive seed ceiling
          current admitted.2.2.1 bounded known selectionMembers selectionLength mass reserved
          P currentPaths projected
          (fun work updated actual saved cache =>
            {concrete} P holeKey fits admits graph templates checkEmpty edgesOf stop order
              work recursiveFuel updated actual saved cache)
          pathsIH
      have left : {left_type} := by
        intro extra
'''
    body_end = f'''      have outcomePaths : OutcomePaths P ({failure} P) outcome := by
        have actualPaths := (left 0).2.2.1
        rw [running 0] at actualPaths
        exact actualPaths
      exact ⟨fuel, outcome, running, resources, left, outcomePaths⟩
'''
    return namespace, preamble, header, body_start, body_end

if __name__ == '__main__':
    targets = '# Internal receipt targets\n\nUNCOMPILED. These inputs are internal induction premises.\n\n'
    for variant in ('Native', 'Prepared'):
        namespace, preamble, header, _, _ = parts(variant)
        targets += f'## {variant}\n\n```lean\nnamespace {namespace}\n{preamble}\n{header}\nend {namespace}\n```\n\n'
    (area / 'PUBLIC-TARGETS-UNCOMPILED.md').write_text(targets)
