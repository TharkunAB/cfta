# Internal receipt resource and execution-path composition

Status: SOURCE-ONLY. The new Lean draft is UNCOMPILED.
The owner has run no Lean compiler, evaluator, native job, Git command,
network command, or board command. The owner has made no production edit.
The full CFTA goal remains active.

## Result

`ExecutionReceiptBridge-v1-UNCOMPILED.lean` contains two complete proposed
proofs. Their public names are:

- `MicroCFTA.SourcePruningEnumerationExecutionReceiptBridge.Native.receipt_finite_complete_resources_paths`
- `MicroCFTA.SourcePruningEnumerationExecutionReceiptBridge.Prepared.receipt_finite_complete_resources_paths`

Each proof retains the old receipt resource inputs. Each result retains the
old existential work bound, outcome, stable running equation at every larger
work bound, and `OutcomeResources` clause. It adds these two conjuncts:

1. A complete receipt has actual `LeftPaths` at every `fuel + extra`.
2. The same stable outcome has `OutcomePaths` with the correct failure type.

The Native result uses `ResumeNative`, `NativeFailurePaths`, the native
`continueWith` and `resume`, and `FiniteReservation.final`. The Prepared
result uses their Prepared counterparts. The two failure types are distinct.
The configured stop, order, work bound, recursive depth, metadata, recording
variable, fragment, caller, query memo, and receipt cache are explicit in each
`LeftPaths` result.

The draft has 316 lines and 20,672 bytes. Its SHA256 is
`d567bdcd58df9c98380a2dae30d890b7ef68e7ad861829ebc3e66a8ffe478dd3`.
This version is immutable after announcement.

## Exact additional inputs

Each theorem adds only:

- `P : EqualityTrie.Path → Prop`.
- `FullReceiptPaths P receipt` for the actual receipt.
- `ProjectionPaths (Reservation.final recursiveFuel seed ceiling).1 P`.
- A concrete internal smaller-depth eventual execution-path induction
  hypothesis.

The induction hypothesis quantifies an inventory, caller, memos, cache,
metadata, seed, and ceiling. It takes the current `Packet`, `Fits`, heap
membership, edge membership and length policies, suspended mass bound,
reservation, `StatePaths`, and projections of that exact final forecast.
It returns a bound above which the concrete `ExecutionPaths.Native` or
`ExecutionPaths.Prepared` holds at `recursiveFuel` and the actual metadata,
caller, query memo, and cache. This is the same internal hypothesis required
by the checked generic callback bridge after its `Paths` parameter is
instantiated. It is intended for the successor-depth proof. It is not a new
public original-input supplier theorem.

No new Complete, final Packet, final outcome membership, satisfying model,
or detached future cache witness is introduced. The old `Complete` input
remains in its original place. No path predicate for the unrelated original
cache is added. In the complete case, the actual receipt's cache paths follow
from `receiptPaths.1`.

## Proof composition

The complete case follows the original receipt proof through its endpoint
equalities and its call to `SourcePruningEnumerationRecursive.receipt_packet`.
That call constructs the current callback Packet from the same admitted
receipt, history, pending condition, ordered state, bound, and Post context.

The proof then instantiates the checked
`ExecutionCallbackBridge.Native/Prepared.callback_finite_complete_resources_with_execution_ih`
with the concrete execution predicate. The callback bridge supplies one work
bound that supports the old stable outcome and the smaller-depth path
property. It supplies the actual recording singleton at every larger work
bound. Its conditional execution property uses the same work bound, updated
metadata, caller, query memo, and `frame callbackCore receiptCache`.

Root is preparing
`SourcePruningEnumerationExecutionCallbackControl.native_left_of_singleton`
and `prepared_left_of_singleton`. The proposed proof applies these helpers
to the actual current paths, recording singleton, and conditional execution
property. The target explicitly fixes every operational argument. The draft
uses `apply` followed by `all_goals assumption` so the helper binder order
need not be guessed. The recording singleton and conditional execution
property are first placed in the local context. Their exact compatibility
with Root's helper header has not been checked. Root had not installed that
production module when the owner tested its presence. No source bytes were
acquired by that presence test.

Once `left` is obtained, `(left 0).2.2.1` gives paths for the actual hook
outcome. Rewriting the old stable equation at extra zero gives paths for the
same existential outcome. This avoids a second outcome witness or an
unproved equality between independently chosen outcomes.

The rejected and stopped receipt cases retain the old empty complete outcome
and its resource proof. Their new LeftPaths match is True. Their empty output
list has OutcomePaths. The unhandled case remains impossible by the same
`advanced` equation. The receipt paths input is stronger than this local
noncomplete case needs, because the sibling composition also retains stopped
receipt observations before finish discards them.

## Header recovery

`PUBLIC-TARGETS-UNCOMPILED.md` contains the two complete headers and contexts.
`check_header_recovery.py` produced `header-recovery.json`.
It verifies textually that removing the four added inputs, two new result
conjuncts, and changed theorem name recovers every old input and result
clause byte for byte. It also verifies that the original context, including
all three DecidableEq instances, is present verbatim. The new Prepared
namespace explicitly opens the original PreparedRecursive namespace.

This is a text check. It does not replace elaboration or a kernel check.
The original classes are DecidableEq Symbol, DecidableEq EdgeKey, and
DecidableEq Node. No new class or semantic premise is added.

## Source scope and reuse

The only two new whole production bodies were named in the task before
acquisition. Both were read and copied in full. Their line unions are exactly:

- `SourcePruningEnumerationFiniteReceiptResources.lean`: 1–92 of 92,
  6,241 bytes, SHA256
  `39c50e4e883a05a348f599a9c3f223124a54b7d1b6fca50b3be16c3f60cfa21b`.
- `SourcePruningEnumerationPreparedFiniteReceiptResources.lean`: 1–92 of 92,
  6,205 bytes, SHA256
  `183be95a49b5518def6959ca03360cda93aa1b4c6e7024caf7a18a05d2e29dc1`.

Requested and actual ranges coincide. The allowance is fully used: two new
whole bodies and no third whole or near-whole body. Repeated displays of the
owned copies add no new production range. The complete new draft was also
read in one display without truncation.

Three full sources were reused from the prior frozen Root bundle after
checking its write-halt manifest, manifest pins, current full source bytes,
and current full source hashes. They are copies of the installed checked
sources, rather than the older owner drafts:

- `ExecutionPaths`: 1–282, 19,132 bytes,
  `4d38fc8805cd0fb104ce2451e8e438e6eaa7228c34c38b4c28284c478ed70b76`.
- `ExecutionPathData`: 1–102, 5,884 bytes,
  `db39b16c885d60ecca4a600763acef2c64447778dd6fec51f13cc88d0cdc2a28`.
- `ExecutionCallbackBridge`: 1–267, 17,838 bytes,
  `7a8aa7d11ad842a20b2c4ab35b12cc754a1f4a2260b9679e9b02db2c3df2c01f`.

`reuse-ledger.json` records the exact frozen strict snapshot for each source.
`root-FROZEN.json` is the copied Root manifest. Its SHA256 is
`5189cdf101d7ecf8e70ff7e88b50754b80ace164c93d8dfbb872f0ed0b6b677f`.
Its time is 2026-10-30T08:58:10.258666+01:00 and write_halt is true. Its
matching_current_strict table names all three reused strict snapshots. Those
are Root's existing checks. This owner has not rerun them or checked the new
receipt draft. The Root manifest also retains six earlier failed commands;
this report does not describe the whole prior command set as passing.

The task reported base commit
`2c32ebc4bacbee067ab55a7470c14c6ab0831e52`. The owner has not independently
queried Git. Source identity is established by the recorded bytes and hashes.

## Coordination and incidents

The exact header and result nesting were sent to Root and
`/root/prefix_count_review`. The result appends `left, outcomePaths` after the
old `running, resources` fields. The prefix reviewer can keep the same receipt
and stable outcome witnesses when using this result in the actual sibling
step.

The first administration command used `python`, which is unavailable. It
failed before the text generator ran. The same generator then ran with
`python3`. Python was used only for file text, hashes, and provenance. One
local Python bytecode cache created by importing the text generator was
removed from the owned directory. No Lean or Haskell code was executed.

One collaboration acknowledgement at 09:15 reported context-output
truncation. It was not a source acquisition or diagnostic display. The
relevant message contract was sent again at 09:21 and 09:26. No source display
in this task was truncated. No compiler failure or passing check exists for
the new draft in this owner bundle.

## Remaining scope

This local receipt composition is not the whole-worker path invariant. The
sibling induction must retain paths for processed and current receipts and
all actual invocations. The whole Native and Prepared worker inductions must
then discharge their concrete smaller-depth path hypothesis. The original
wrapper must compose forecast projections from the same original guard-derived
carrier. Root reports that the ClosedForecastPaths original-path laws are
already checked. The missing work here is their whole-worker composition,
not another local projection law. A fixed finite guard list supplies a finite
list of concrete projected paths. Initial stored paths and suffixes then give
a finite carrier. This result alone supplies no bound on native handle
renewal, multiplicity, neutral steps, or sufficient recursive depth for every
earlier alternative before a permitted finite witness.

Configured stop policy coverage, sufficient original depth, public generator
coverage, and Haskell correspondence remain outside this local draft. No
Haskell defect, repair, or runtime claim is made. Root handles production
integration, validation, FINDINGS, and publication.
