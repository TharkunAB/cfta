# Actual head and sibling execution paths

Status: four internal companion declarations drafted in two immutable UNCOMPILED files. All old explicit inputs, existential witnesses, stable equations and resource/certificate clauses pass literal header recovery. Root reports repaired Head V3 is installed and strict-passing. Root's exact Sibling V1 probe failed; Root owns the V2 repairs. This owner ran no compiler, evaluator or native command. This bundle does not claim that Sibling V1 compiles or that the whole recursive execution invariant is proved.

## Concrete deliverables

`ExecutionHeadBridge-v1-UNCOMPILED.lean` has 455 lines and 32,851 bytes. Its SHA256 is `0354bc5d031db1e1189c15414d0dd5cbd9be7d911e2de578935aa039bcc75c31`. The intended unique module is `SourcePruningEnumerationExecutionHeadBridge`. Its paired public names are:

- `SourcePruningEnumerationExecutionHeadBridge.Native.head_finite_complete_resources_paths`.
- `SourcePruningEnumerationExecutionHeadBridge.Prepared.head_finite_complete_resources_paths`.

`ExecutionSiblingBridge-v1-UNCOMPILED.lean` has 722 lines and 49,595 bytes. Its SHA256 is `7fc20334e832950210e611226b6722c8d6898dca4e525a606bf335c10a48ad70`. The intended unique module is `SourcePruningEnumerationExecutionSiblingBridge`. Its paired public names are:

- `SourcePruningEnumerationExecutionSiblingBridge.Native.alternatives_finite_complete_resources_paths`.
- `SourcePruningEnumerationExecutionSiblingBridge.Prepared.alternatives_finite_complete_resources_paths`.

Both intended production filenames were absent when the drafts were generated. This owner wrote no production file.

PUBLIC-CONTRACTS.json retains all four full headers, their implicit-variable/typeclass contexts and their complete old headers. header-recovery.json records successful literal recovery of every old input and result clause. This check is a text check. It is not a Lean elaboration or proof check.

## Added internal inputs

Each companion retains the exact old `Complete` premise at recursiveFuel. That premise already exists in the internal resource theorem. The new source does not add it to an original-input public worker theorem. The planned worker induction must discharge both that old premise and the new smaller-depth premise internally.

The five added inputs are P, original StatePaths, suffix closure, a projection fact for the exact computed forecast, and pathsIH. Head uses ProjectionPaths of `finiteStep recursiveFuel seed capturedMass inherited`. Sibling uses ProjectionPaths of `stage recursiveFuel seed capturedMass inherited selectedEdges.length`.

pathsIH is the receipt bridge's concrete internal induction premise. It quantifies over the actual next Inventory/Caller/Memos/cache/metadata/seed/ceiling. Its gates are Packet, Fits, known Heap, both old selection conditions, mass, Reserved, StatePaths and ProjectionPaths of the computed smaller final forecast. It returns an eventual concrete ExecutionPaths.Native or Prepared at the same recursiveFuel. It supplies no satisfying model or unrelated future trace. It is not an original-input API supplier.

Root must later instantiate this premise from the smaller-D worker induction. The declaration itself does not discharge that whole-worker step.

## Head proof and exact result shape

The old head proof constructs the actual captured receipt and native effects. It retains the old common work bound and callback outcome construction. The draft derives the new local paths from current facts:

1. Original StatePaths and the exact stored slot give BucketPaths for inherited scs.
2. The actual available parent, linked heap facts and selected edge give physical edge residency. known then gives that edge guard's seed membership.
3. The reservation's step_ge theorem transports that seed membership into the exact computed step projection. Thus no separate arbitrary edge-projection or guard-origin supplier is added.
4. The checked PathReceiptsRaw.captured_paths theorem applies to the literal actual head run. The stable some-receipt equation identifies its exact receipt and yields FullReceiptPaths.
5. The paired receipt bridge supplies the callback's old resources, actual LeftPaths and outcome paths at a common callback bound. Shifting by the head bound retains the same actual receipt/outcome and every old stable clause.

The top head tuple adds `receiptPaths` after `knownHead` and before the old shape disjunction. Its unsupported branch remains the exact old unhandled clause. The supported branch appends `callbackLeft, callbackPaths` after the unchanged old captured clause. callbackLeft covers every bound+extra and only an actual complete receipt; it names the actual fragment/caller/query/cache and the literal continueWith/resume closure. callbackPaths is OutcomePaths of the stable actual outcome.

Native derives parent availability from the original packet realization and exact native lookup. Prepared retains its separate parentAvailable and parentClosed premises. The Prepared theorem does not borrow the Native lookup equation or equate the prepared parent with the old stored handle.

The immutable Head V1 generator omitted both advanced-branch tuple extensions because a literal replacement did not match indentation. Root detected that before probing and owns the repair. The extra callbackLeft proof bullet was already present. Root subsequently reports both Head V3 laws installed and strict-passing. ROOT-STATUS.json records this as Root-reported status, not independent owner validation. The Head V1 file is retained unchanged as the initial failed draft.

## Sibling induction and actual invocations

The source extends the exact existing selectedEdges induction. It preserves all old running/Post/Packet/Fits/Heap fields, processed/output bounds and certificates, and the complete/stopped shape with its endpoint and StoppedAt certificate.

The two appended result fields are FoldPaths of the stable actual result, and a forall-extra statement that every actual HookInvocation has the corresponding literal LeftPaths at that work amount. There is no output-membership or processed-membership gate.

The new head projection is obtained from the original stage forecast. The tail retains the original captured metadata/cache, receives the actual completed hook's native caller and full memos, and uses the next stage's exact forecast. Native preserves the lookup through actual Post effects. Prepared preserves the actual prepared parent's availability through those effects.

The path cases cover the full ordered scan:

- Empty edges: no receipt, output or Invocation.
- Unsupported head: the actual unhandled current receipt is retained. There is no advancing hook or suffix call.
- Complete hook: retain the head FullReceiptPaths, both output-list append halves, the actual tail fold's current stop, and all actual head/tail Invocations.
- Stopped hook: retain the current complete receipt and recursive reason even though the processed prefix is empty at this head. A completed suffix Invocation is impossible after this actual stop.
- A handled non-complete receipt uses its exact advance endpoint before the suffix. This covers the Invocation.other case without inventing a complete-fragment callback.

The three actual Invocation constructors are here, completed and other. The proof aligns their observed captured-edge equation with the stable head equation. completed aligns the actual hook's returned caller/query pair with the tail resources. other aligns its actual advance endpoint. The work arguments use the same common bound arithmetic as the old running proof.

FoldPaths is retained before finish. A complete fold with no outputs still retains all processed receipts. A stopped current hook stays outside that processed prefix and still has FullReceiptPaths plus its nested failure paths.

Root's Sibling V1 probe found six anonymous-tuple nomatch parsing errors and four dependent-rewrite errors in Invocation.other. Root's repairs replace the empty-list lambda bodies with False.elim (List.not_mem_nil member), and use cases same across the dependent context before eliminating notComplete. These repairs concern proof terms. The four public contracts are unchanged. This owner does not claim the repaired sibling proof passes.

## Exact dependency contract

The paired receipt supplier is `SourcePruningEnumerationExecutionReceiptBridge.Native/Prepared.receipt_finite_complete_resources_paths`. It returns `fuel, outcome, running, resources, left, outcomePaths`. Its exact full paired headers were copied from the supplier owner's immutable PUBLIC-TARGETS-UNCOMPILED.md and verified against its pins. The document SHA256 is `77a287d4634ac138589a9144436e4e2f0903ac419e22b527c98071a5d7c02b34`.

Root reports receipt V1 strict-passed unchanged. Its SHA256 is `d567bdcd58df9c98380a2dae30d890b7ef68e7ad861829ebc3e66a8ffe478dd3`. The supplier owner reports installed V2 removes only its uncompiled status sentence; its SHA256 is `94a97a311d304ac5b3a143ee3a8ddd477b3e0b61070bee8904a4dbb89769245d`. Root's singleton callback helper supplies the actual LeftPaths from initial paths, the literal singleton raw row and the conditional smaller execution. This owner does not rerun those checks.

## Remaining whole objective

These internal companions support the eventual whole-worker path induction. They do not establish it. The remaining composition must cover actual selected prefixes, parked recursive calls, Native entry, Prepared preparation and both opaque branches, then discharge the concrete smaller-D pathsIH internally. The separate Prepared opaque companion belongs to the receipt owner.

The temporary computed forecast projections must be derived from the same original carrier at the final original-input wrapper. No future actual trace, callback completion or whole-execution certificate may replace that supplier.

Even a completed fixed-D execution-path theorem would allow exhaustion. It would not produce an original sufficient recursive capacity, rank native ordinary renewal, bound fresh native handles or raw multiplicity, or establish public Haskell correspondence. Both workers and those original global-control objectives remain in scope for the full project.

No Haskell source was read or changed here. No Haskell fix or runtime defect was established. Root retains FINDINGS ownership.

## Acquisitions and immutable status

Exactly two newly acquired whole production sources were approved and used:

- SourcePruningEnumerationFiniteHeadResources: 167 lines, 12,234 bytes, SHA256 ec10901397814d0c201748a3064895f324196f468c13ebae3e5963c90f1e1e1a.
- SourcePruningEnumerationPreparedFiniteHeadResources: 170 lines, 12,519 bytes, SHA256 34bfa6cd1cc06fef2269b33a4efb28bed13756561457af2c492f516ac326d0b2.

Both full bodies were displayed in complete bounded recovery chunks. Their original inputs and proof structures were read before drafting. Seven additional saved cuts are bounded. The largest new unions are PathReceiptsRaw 1–23 plus 64–96 (56/96 lines), and HookInvocation 10–24 plus 36–69 (49/163 lines). Other new cuts are PathHead238–256, FiniteReservation132–148, and PreparedReservation127–143. The PathReceiptsRaw requested endpoint101 clamps to EOF96. No third whole or near-whole production body was acquired by joining snippets.

Five whole frozen sources were reused after current-byte and frozen-pin equality checks: both old sibling resource bodies, installed ExecutionPaths, installed ExecutionPathData and installed ExecutionCallbackProjection. The old sibling sources match callback-path-review/reused exactly. The installed execution sources match the prior Root frozen Audit input copies. Source-unions.json separates new and reused coverage.

The first metadata listing/locator outputs were truncated. Required source and constructor scopes were recovered in complete saved cuts. A Python sibling generator assertion failed before a Lean candidate was written; the exact failed generator and error are retained. Head V1's source-detected tuple omission and the Root-reported Sibling V1 compiler failure are retained separately. The full Root raw compiler log remains outside this bundle at its exact immutable path/hash in ROOT-STATUS.json. Root explicitly requested no new draft and no read of that 95,988-byte log.

All owner candidates remain named UNCOMPILED. Root repairs and compiler outputs are separate evidence. No source check is presented as a compiler result. No owner compiler/evaluator/native/Git/network/board command or subagent ran. All mutations stayed inside this fresh owner directory. No prior frozen bundle was changed. Every final regular file, including scripts, marker, manifest and pins, has its write bits removed at sealing.
