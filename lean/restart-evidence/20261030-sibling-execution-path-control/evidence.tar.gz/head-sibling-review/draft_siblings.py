from pathlib import Path
import re,json,hashlib
r=Path('/tmp/mcfta-sibling-execution-path-control-20261030/head-sibling-review')
assert not Path('/home/tritlo/Code/mcfta/lean/MicroCFTA/SourcePruningEnumerationExecutionSiblingBridge.lean').exists()
spec=(r/'receipt-public-targets-UNCOMPILED.md').read_text();parts=[]
def change(s,old,new):
 assert old in s,old[:150]
 return s.replace(old,new,1)
for kind in ['Native','Prepared']:
 prep=kind=='Prepared';name='SourcePruningEnumerationPreparedFiniteSiblingResources.lean' if prep else 'SourcePruningEnumerationFiniteSiblingResources.lean';old=(r/'reused'/name).read_text();ns='MicroCFTA.SourcePruningEnumerationPreparedFiniteSiblingResources' if prep else 'MicroCFTA.SourcePruningEnumerationNativeFiniteSiblingResources';newns='MicroCFTA.SourcePruningEnumerationExecutionSiblingBridge.'+kind;R='SourcePruningEnumerationPreparedReservation' if prep else 'SourcePruningEnumerationFiniteReservation';failure='PreparedFailurePaths' if prep else 'NativeFailurePaths';resume='ResumePrepared' if prep else 'ResumeNative';base='SourcePruningEnumerationPreparedRecursive' if prep else 'SourcePruningEnumerationRecursive'
 s=old[old.index('namespace '+ns):].replace('namespace '+ns,'namespace '+newns,1).replace('end '+ns,'end '+newns)
 s=change(s,'theorem alternatives_finite_complete_resources\n','theorem alternatives_finite_complete_resources_paths\n')
 s=change(s,'variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]\n',f'''variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
open {ns.removeprefix('MicroCFTA.')} (ReceiptAt OutputAt StoppedAt)
open SourcePruningEnumerationPathTransport (StatePaths ProjectionPaths)
open SourcePruningEnumerationExecutionPathData (FullReceiptPaths FoldPaths NativeFailurePaths PreparedFailurePaths)
open SourcePruningEnumerationExecutionPaths (LeftPaths ResumeNative ResumePrepared)
local notation "Metadata" => SourcePruningRecordTypes.Metadata
''')
 section=spec.split('namespace MicroCFTA.SourcePruningEnumerationExecutionReceiptBridge.'+kind,1)[1];ih=section.split('    (pathsIH :',1)[1].split(') :\n    ∃ (fuel',1)[0]
 end='    (reserved : ScanReserved bits recursiveFuel seed capturedMass inherited selectedEdges.length) :'
 s=change(s,end,end[:-2]+'''\n    (P : EqualityTrie.Path → Prop)
    (original : StatePaths P before.core)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (projected : ProjectionPaths (stage recursiveFuel seed capturedMass inherited selectedEdges.length).1 P)
    (pathsIH :'''+ih+') :')
 oldend='          StoppedAt recursiveFuel formulas solver caller before uv seed scs capturedMass inherited processed.length outputs current) := by'
 s=change(s,oldend,f'''          StoppedAt recursiveFuel formulas solver caller before uv seed scs capturedMass inherited processed.length outputs current) ∧
      FoldPaths P ({failure} P) result ∧
      (∀ extra fragment reached saved after,
        SourcePruningEnumerationHookInvocation.Invocation
          (continueWith (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
            (bound + extra) recursiveFuel) graph templates stop order (bound + extra) metadata uv)
          checkEmpty (bound + extra) (bound + extra) (bound + extra) (bound + extra) (bound + extra)
          uv scs before selectedEdges caller memos.query fragment reached saved after →
        LeftPaths P
          ({resume} P holeKey fits admits graph templates checkEmpty edgesOf stop order
            (bound + extra) recursiveFuel)
          ({failure} P)
          (continueWith (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
            (bound + extra) recursiveFuel) graph templates stop order (bound + extra) metadata uv)
          graph templates stop order (bound + extra) metadata uv fragment reached saved after) := by''')
 s=change(s,'fun _ => rfl, Post.refl packet.context, packet, bounded, known, Nat.le_refl _, ?_, ?_, .inl rfl⟩','fun _ => rfl, Post.refl packet.context, packet, bounded, known, Nat.le_refl _, ?_, ?_, .inl rfl, ?_, ?_⟩')
 s=change(s,'  | cons edge rest ih =>','''      · exact ⟨fun _ member => nomatch member, fun _ member => nomatch member⟩
      · intro extra fragment reached saved after invoked
        cases invoked
  | cons edge rest ih =>
      have headProjected : ProjectionPaths (afterHook recursiveFuel seed capturedMass inherited).1 P := by
        intro guard member
        exact projected guard
          (('''+R+'''.stage_ge recursiveFuel
            (afterHook recursiveFuel seed capturedMass inherited) capturedMass inherited rest.length).2 member)''')
 s=change(s,'headRun, headPost, headQueries, admitted, pending, history, cacheBounds, headFits, headKnown, shape⟩ :=','headRun, headPost, headQueries, admitted, pending, history, cacheBounds, headFits, headKnown, receiptPaths, shape⟩ :=')
 s=change(s,('SourcePruningEnumerationPreparedNativeHookResources' if prep else 'SourcePruningEnumerationNativeHookResources')+'.head_finite_complete_resources','SourcePruningEnumerationExecutionHeadBridge.'+kind+'.head_finite_complete_resources_paths')
 s=change(s,'capturedMass inherited initialMass inheritedLength reserved.head','capturedMass inherited initialMass inheritedLength reserved.head\n          P original tails headProjected pathsIH')
 s=change(s,'rcases shape with unsupported | ⟨outcome, advanced, callbackRun, resources, captured⟩','rcases shape with unsupported | ⟨outcome, advanced, callbackRun, resources, captured, callbackLeft, callbackPaths⟩')
 s=change(s,'by simp, ?_, ?_, .inr ⟨_, rfl, .inl rfl, .inl rfl⟩⟩','by simp, ?_, ?_, .inr ⟨_, rfl, .inl rfl, .inl rfl⟩, ?_, ?_⟩')
 marker='''      · have receiptCertificate'''
 extras='''        · refine ⟨fun _ member => nomatch member, fun _ member => nomatch member, ?_⟩
          intro current observed
          cases Option.some.inj observed
          exact receiptPaths
        · intro extra fragment reached saved after invoked
          have first := headRun extra
          cases invoked with
          | here observed => rw [first] at observed; cases observed
          | completed observed _ _ => rw [first] at observed; cases observed
          | other observed _ advanced _ =>
              rw [first] at observed
              cases Option.some.inj observed
              cases advanced
'''
 s=change(s,marker,extras+marker)
 s=change(s,'tailRun, tailPost, tailCaptured, tailFits, tailKnown, tailLength, tailReceipts, tailOutputs, tailShape⟩ :=','tailRun, tailPost, tailCaptured, tailFits, tailKnown, tailLength, tailReceipts, tailOutputs, tailShape, tailPaths, tailInvocations⟩ :=')
 s=change(s,'hookFits hookKnown reserved.tail','hookFits hookKnown reserved.tail projected')
 s=change(s,'              ?_, ?_, ?_⟩','              ?_, ?_, ?_, ?_, ?_⟩')
 marker='''        | stopped headOutputs reason reached =>'''
 paths=f'''            · cases tailResult with
              | complete receipts later actual queries =>
                  refine ⟨?_, ?_⟩
                  · intro current member
                    rcases List.mem_cons.mp member with same | laterMember
                    · subst current; exact receiptPaths
                    · exact tailPaths.1 current laterMember
                  · intro output member
                    rcases List.mem_append.mp member with first | laterMember
                    · exact callbackPaths output first
                    · exact tailPaths.2 output laterMember
              | stopped receipts later current =>
                  refine ⟨?_, ?_, tailPaths.2.2⟩
                  · intro currentReceipt member
                    rcases List.mem_cons.mp member with same | laterMember
                    · subst currentReceipt; exact receiptPaths
                    · exact tailPaths.1 currentReceipt laterMember
                  · intro output member
                    rcases List.mem_append.mp member with first | laterMember
                    · exact callbackPaths output first
                    · exact tailPaths.2.1 output laterMember
            · intro extra fragment reached saved after invoked
              let w := bound + extra
              have hl : headBound ≤ w := by dsimp [w, bound]; omega
              have tl : tailBound ≤ w := by dsimp [w, bound]; omega
              have first := headRun (w - headBound)
              rw [Nat.add_sub_of_le hl] at first
              have hooked := callbackRun (w - headBound)
              rw [Nat.add_sub_of_le hl] at hooked
              have left := callbackLeft (w - headBound)
              rw [Nat.add_sub_of_le hl] at left
              have later := tailInvocations (w - tailBound)
              rw [Nat.add_sub_of_le tl, hookQuery] at later
              cases invoked with
              | here observed =>
                  have same := Option.some.inj (first.symm.trans observed)
                  rw [same] at left
                  exact left
              | completed observed continued tail =>
                  have same := Option.some.inj (first.symm.trans observed)
                  rw [same] at hooked
                  obtain ⟨_outputs, rfl, rfl⟩ :=
                    SourcePruningEnumerationNativeContinuations.HookResult.complete.inj (hooked.symm.trans continued)
                  exact later fragment reached saved after tail
              | other observed notComplete advancedTail tail =>
                  have same := Option.some.inj (first.symm.trans observed)
                  have notCompleteHead := notComplete
                  rw [← same] at notCompleteHead
                  have endpoint := advancedTail
                  rw [← same] at endpoint
                  have continued : advance receipt = some (hookCaller, hookQueries) := by
                    cases receipt with
                    | complete first actual queries cache => cases notCompleteHead
                    | unhandled => cases advanced
                    | rejected actual queries cache | stopped fragments observation candidate =>
                        obtain ⟨_empty, actual, queries⟩ :=
                          SourcePruningEnumerationNativeContinuations.HookResult.complete.inj hooked
                        rw [actual, queries] at advanced
                        exact advanced
                  obtain ⟨rfl, rfl⟩ := Prod.mk.inj (Option.some.inj (continued.symm.trans endpoint))
                  exact later fragment reached saved after tail
'''
 s=change(s,marker,paths+marker)
 s=change(s,'returnedFits.mono laterGrowth.1, ?_, by simp, ?_, ?_, ?_⟩','returnedFits.mono laterGrowth.1, ?_, by simp, ?_, ?_, ?_, ?_, ?_⟩')
 marker='''                receiptCertificate, currentResources⟩⟩
'''
 stopped='''            · exact ⟨fun _ member => nomatch member, callbackPaths.1, receiptPaths, callbackPaths.2⟩
            · intro extra fragment' reached' saved' after' invoked
              have first := headRun extra
              have hooked := callbackRun extra
              cases invoked with
              | here observed =>
                  have same := Option.some.inj (first.symm.trans observed)
                  cases same
                  exact callbackLeft extra
              | completed observed continued _ =>
                  have same := Option.some.inj (first.symm.trans observed)
                  cases same
                  have impossible := hooked.symm.trans continued
                  cases impossible
              | other observed notComplete _ _ =>
                  have same := Option.some.inj (first.symm.trans observed)
                  rw [← same] at notComplete
                  cases notComplete
'''
 s=change(s,marker,marker+stopped)
 parts.append(s)
text='''import MicroCFTA.SourcePruningEnumerationFiniteSiblingResources
import MicroCFTA.SourcePruningEnumerationPreparedFiniteSiblingResources
import MicroCFTA.SourcePruningEnumerationExecutionHeadBridge
import MicroCFTA.SourcePruningEnumerationHookInvocation

/-!
# Finite ordered siblings with actual callback execution paths

UNCOMPILED source-only draft. Each old witness and resource clause stays.
The actual fold and every actual Invocation retain paths before finish.
-/
'''+ '\n'.join(parts)
q=r/'ExecutionSiblingBridge-v1-UNCOMPILED.lean';assert not q.exists();q.write_text(text);q.chmod(0o444)
print(json.dumps(dict(path=str(q),lines=len(text.splitlines()),bytes=len(text.encode()),sha256=hashlib.sha256(text.encode()).hexdigest()),indent=2))
