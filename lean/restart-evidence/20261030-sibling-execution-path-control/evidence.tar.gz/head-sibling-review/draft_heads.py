from pathlib import Path
import re,hashlib,json
r=Path('/tmp/mcfta-sibling-execution-path-control-20261030/head-sibling-review')
assert not Path('/home/tritlo/Code/mcfta/lean/MicroCFTA/SourcePruningEnumerationExecutionHeadBridge.lean').exists()
spec=(r/'receipt-public-targets-UNCOMPILED.md').read_text()
parts=[]
for kind in ['Native','Prepared']:
 prep=kind=='Prepared';src='SourcePruningEnumerationPreparedFiniteHeadResources.lean' if prep else 'SourcePruningEnumerationFiniteHeadResources.lean';old=(r/'sources'/src).read_text();ns='MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources' if prep else 'MicroCFTA.SourcePruningEnumerationNativeHookResources';newns='MicroCFTA.SourcePruningEnumerationExecutionHeadBridge.'+kind
 s=old[old.index('namespace '+ns):].replace('namespace '+ns,'namespace '+newns,1).replace('end '+ns,'end '+newns)
 s=s.replace('theorem head_finite_complete_resources\n','theorem head_finite_complete_resources_paths\n',1)
 s=s.replace('variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]\n','''variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
open SourcePruningEnumerationPathTransport (StatePaths BucketPaths ProjectionPaths)
open SourcePruningEnumerationExecutionPathData (FullReceiptPaths OutcomePaths NativeFailurePaths PreparedFailurePaths)
open SourcePruningEnumerationExecutionPaths (LeftPaths ResumeNative ResumePrepared)
local notation "Metadata" => SourcePruningRecordTypes.Metadata
''',1)
 section=spec.split('namespace MicroCFTA.SourcePruningEnumerationExecutionReceiptBridge.'+kind,1)[1]
 ih=section.split('    (pathsIH :',1)[1].split(') :\n    ∃ (fuel',1)[0]
 reserved='    (reserved : SourcePruningEnumeration'+('PreparedReservation' if prep else 'FiniteReservation')+'.HeadReserved bits recursiveFuel seed capturedMass inherited) :'
 new_inputs='''    (P : EqualityTrie.Path → Prop)
    (original : StatePaths P before.core)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (projected : ProjectionPaths (finiteStep recursiveFuel seed capturedMass inherited).1 P)
    (pathsIH :'''+ih+') :'
 assert reserved in s;s=s.replace(reserved,reserved[:-2]+'\n'+new_inputs,1)
 key='      Heap (fun guard => guard ∈ (afterHead seed inherited).1) middleCaller.checked.native.machine.heap ∧\n'
 assert key in s;s=s.replace(key,key+'      FullReceiptPaths P receipt ∧\n',1)
 s=s.replace('          match outcome with\n','          (match outcome with\n',1)
 failure='PreparedFailurePaths' if prep else 'NativeFailurePaths';resume='ResumePrepared' if prep else 'ResumeNative'
 left=f'''          (∀ extra, match (generalizing := false) receipt with
          | .complete fragment actual saved after =>
              LeftPaths P
                ({resume} P holeKey fits admits graph templates checkEmpty edgesOf stop order
                  (bound + extra) recursiveFuel)
                ({failure} P)
                (continueWith
                  (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
                    (bound + extra) recursiveFuel)
                  graph templates stop order (bound + extra) metadata uv)
                graph templates stop order (bound + extra) metadata uv fragment actual saved after
          | _ => True) ∧
          OutcomePaths P ({failure} P) outcome) := by'''
 s=s.replace('          | .stopped _ _ _ => True) := by','          | .stopped _ _ _ => True) ∧\n'+left,1)
 marker='  rcases shape with advanced | unsupported\n'
 available='parentAvailable' if prep else 'available'
 R='SourcePruningEnumerationPreparedReservation' if prep else 'SourcePruningEnumerationFiniteReservation'
 path_proof=f'''  have inheritedPaths : BucketPaths P scs :=
    original (.unenumerated (some handle) scs) (List.mem_of_getElem? stored)
  have resident : InternedEdgeResidency.EdgeResident caller.checked.native.machine.heap edge :=
    InternedEdgeResidency.resident_edges caller.checked.native.machine.heap
      packet.context.ready.semantic.ready.semantic.1.normal.facts.linked
      (.node parentEntry storedEdges depth free) {available}.resident edge selected
  have guardIncluded : edge.entry.key.constraint ∈ seed.1 :=
    known edge.entry.key edge resident
  have edgeProjected : ∀ tries residual,
      SourcePruningEnumerationConstraint.project edge.entry.key.constraint = some (tries, residual) →
      ∀ trie ∈ tries, ∀ path ∈ EqualityTrie.fromPathTrie trie, P path := by
    intro tries residual projection
    exact projected edge.entry.key.constraint
      (({R}.step_ge recursiveFuel seed capturedMass inherited).2 guardIncluded)
      tries residual projection
  have receiptPaths : FullReceiptPaths P receipt := by
    have observedPaths := SourcePruningEnumerationPathReceiptsRaw.captured_paths
      checkEmpty headBound headBound headBound headBound headBound uv scs edge caller before memos.query
      original inheritedPaths tails edgeProjected
    rw [headAt headBound (Nat.le_refl _)] at observedPaths
    cases receipt <;> exact observedPaths
'''
 assert marker in s;s=s.replace(marker,path_proof+marker,1)
 s=s.replace('obtain ⟨callbackFuel, outcome, callbackRun, resources⟩ := '+('SourcePruningEnumerationPreparedRecursive.receipt_finite_complete_resources' if prep else 'receipt_finite_complete_resources'),'obtain ⟨callbackFuel, outcome, callbackRun, resources, callbackLeft, callbackPaths⟩ :=\n      SourcePruningEnumerationExecutionReceiptBridge.'+kind+'.receipt_finite_complete_resources_paths',1)
 s=s.replace('selectionMembers selectionLength (by cases receipt <;> exact mass) reserved.2','selectionMembers selectionLength (by cases receipt <;> exact mass) reserved.2\n      P receiptPaths projected pathsIH',1)
 s=s.replace('history, cacheBounds, boundedHead, knownHead,\n       .inr ⟨outcome, advancedQuery, ?_, fullResources, ?_⟩⟩','history, cacheBounds, boundedHead, knownHead, receiptPaths,\n       .inr ⟨outcome, advancedQuery, ?_, fullResources, ?_, ?_, callbackPaths⟩⟩',1)
 # Append the shifted callback path proof after the unchanged completed-captured proof.
 end='''          exact ⟨next, final, post, query, captured, returnedFits, returnedKnown⟩
  · exact'''
 replacement='''          exact ⟨next, final, post, query, captured, returnedFits, returnedKnown⟩
    · intro extra
      have actual := callbackLeft (headBound + extra)
      have common : callbackFuel + (headBound + extra) = headBound + callbackFuel + extra := by omega
      rw [common] at actual
      exact actual
  · exact'''
 assert end in s;s=s.replace(end,replacement,1)
 s=s.replace('history, cacheBounds, boundedHead, knownHead, .inl unsupported⟩','history, cacheBounds, boundedHead, knownHead, receiptPaths, .inl unsupported⟩',1)
 parts.append(s)
text='''import MicroCFTA.SourcePruningEnumerationFiniteHeadResources
import MicroCFTA.SourcePruningEnumerationPreparedFiniteHeadResources
import MicroCFTA.SourcePruningEnumerationExecutionReceiptBridge
import MicroCFTA.SourcePruningEnumerationPathReceiptsRaw

/-!
# Actual head receipts and finite callback execution paths

UNCOMPILED source-only draft. The old head witnesses and resource clauses stay.
The smaller-depth execution premise is internal to the worker induction.
-/
'''+ '\n'.join(parts)
q=r/'ExecutionHeadBridge-v1-UNCOMPILED.lean';assert not q.exists();q.write_text(text);q.chmod(0o444)
print(json.dumps(dict(path=str(q),lines=len(text.splitlines()),bytes=len(text.encode()),sha256=hashlib.sha256(text.encode()).hexdigest()),indent=2))
