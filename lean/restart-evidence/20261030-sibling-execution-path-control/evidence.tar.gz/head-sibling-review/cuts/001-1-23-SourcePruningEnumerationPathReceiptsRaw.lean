import MicroCFTA.SourcePruningEnumerationPathTraversalRaw
import MicroCFTA.SourcePruningEnumerationPathReceipts

/-!
# Paths in every retained captured edge state

Actual own preparation supplies the paths for the ordered child traversal.
Captured receipts preserve their cache states and every successful raw row.
-/
namespace MicroCFTA.SourcePruningEnumerationPathReceiptsRaw
open EnumerationState InternedConstructorTemplates SourcePruningEnumerationPathTransport
open SourcePruningEnumerationPathPreparedOpaque (ReceiptPaths)
open SourcePruningEnumerationPathObservationRaw (ObservationPaths)
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Fragment" => Fragments.Fragment Symbol
variable {width : Nat} {P : EqualityTrie.Path → Prop}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

