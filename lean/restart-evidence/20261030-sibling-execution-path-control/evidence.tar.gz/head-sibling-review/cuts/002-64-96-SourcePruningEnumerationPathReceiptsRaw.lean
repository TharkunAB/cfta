                    (staged.map (fun input => (input.1, input.2.1))) caller middle queries
                    fragments current retained rowPaths.1 buckets traversed

/-- Every actual captured receipt retains its cache paths and all successful raw rows. -/
theorem captured_paths
    (checkEmpty : Bool) (r n p h k target : Nat) (scs : List Suspended)
    (edge : EdgeValue Symbol Constraint) (caller : Caller width) (before : Cached) (queries : Queries)
    (paths : StatePaths P before.core) (inherited : BucketPaths P scs)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (projected : ∀ tries residual,
      SourcePruningEnumerationConstraint.project edge.entry.key.constraint = some (tries, residual) →
      ∀ trie ∈ tries, ∀ path ∈ EqualityTrie.fromPathTrie trie, P path) :
    (match SourcePruningEnumerationCapturedEdge.run checkEmpty r n p h k target scs edge caller before queries with
      | none => True
      | some receipt => ReceiptPaths P receipt) ∧
    (match SourcePruningEnumerationCapturedEdge.run checkEmpty r n p h k target scs edge caller before queries with
      | some (.stopped _ observation _) => ObservationPaths P observation
      | _ => True) := by
  refine ⟨SourcePruningEnumerationPathReceipts.captured_paths checkEmpty r n p h k target scs edge
    caller before queries paths inherited tails projected, ?_⟩
  unfold SourcePruningEnumerationCapturedEdge.run
  cases selected : SourcePruningEnumerationSelectedEdge.run checkEmpty r n p h k scs edge caller before queries with
  | unhandled => trivial
  | rejected reached saved after => trivial
  | stopped completedPrefix observation candidate =>
      exact selected_stopped_raw_paths checkEmpty r n p h k scs edge caller before queries
        paths inherited tails projected completedPrefix observation candidate selected
  | complete fragment reached saved after =>
      dsimp only
      cases finished : SourcePruningEnumerationFinalize.run
          reached.checked.native.machine.heap k target fragment after <;> trivial

end MicroCFTA.SourcePruningEnumerationPathReceiptsRaw
