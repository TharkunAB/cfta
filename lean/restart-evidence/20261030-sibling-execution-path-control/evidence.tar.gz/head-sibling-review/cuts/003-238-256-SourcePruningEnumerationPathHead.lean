    original (.unenumerated (some handle) scs) (List.mem_of_getElem? stored)
  obtain ⟨_roots, _paths, _storage, realized, _counts, _flags⟩ := receipt.admission.packet.valid
  obtain ⟨parent, parentLookup, available, _closed⟩ := realized uv handle scs stored
  have parentSame : parent = .node parentEntry storedEdges depth free :=
    Option.some.inj (parentLookup.symm.trans decoded)
  subst parent
  have resident : InternedEdgeResidency.EdgeResident caller.checked.native.machine.heap edge :=
    InternedEdgeResidency.resident_edges caller.checked.native.machine.heap
      receipt.admission.packet.context.ready.semantic.ready.semantic.1.normal.facts.linked
      (.node parentEntry storedEdges depth free) available.resident edge selected
  have guardIncluded : edge.entry.key.constraint ∈ guards :=
    included (receipt.admission.known edge.entry.key edge resident)
  have completed := receipt.running 0
  simp only [Nat.add_zero] at completed
  apply SourcePruningEnumerationCapturedEdge.complete_paths checkEmpty bound bound bound bound bound
    uv scs edge caller reached before after memos.query saved fragment original inheritedPaths tails
    ?_ completed
  intro tries residual projection
  exact projected edge.entry.key.constraint guardIncluded tries residual projection
