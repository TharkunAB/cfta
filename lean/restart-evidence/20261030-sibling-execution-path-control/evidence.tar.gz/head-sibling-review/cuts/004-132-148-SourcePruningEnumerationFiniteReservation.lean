theorem afterHead_le_step (depth : Nat) (seed : Seed) (capturedMass inherited : Nat) :
    Le (afterHead seed inherited).2 (step depth seed capturedMass inherited).2 ∧
      (afterHead seed inherited).1 ⊆ (step depth seed capturedMass inherited).1 :=
  final_ge depth (afterHead seed inherited) (massCeil seed capturedMass inherited)

/-- Each paired stage retains its input seed. -/
theorem step_ge (depth : Nat) (seed : Seed) (capturedMass inherited : Nat) :
    Le seed.2 (step depth seed capturedMass inherited).2 ∧
      seed.1 ⊆ (step depth seed capturedMass inherited).1 := by
  have head := SourcePruningEnumerationRecursiveReservation.afterHead_ge seed inherited
  have callback := afterHead_le_step depth seed capturedMass inherited
  exact ⟨head.1.trans callback.1, fun _ member => callback.2 (head.2 member)⟩

/-- Every sibling schedule retains its original profile and guards. -/
theorem stage_ge (depth : Nat) (seed : Seed) (capturedMass inherited count : Nat) :
    Le seed.2 (stage depth seed capturedMass inherited count).2 ∧
      seed.1 ⊆ (stage depth seed capturedMass inherited count).1 :=
