from pathlib import Path
import hashlib,json,datetime,stat
area=Path('/tmp/mcfta-sibling-execution-path-control-20261030/opaque-review')
repo=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
def sha(data):return hashlib.sha256(data).hexdigest()
now=datetime.datetime.now().astimezone().isoformat()
checks=[]
for row in json.loads((area/'acquisitions.json').read_text())+json.loads((area/'reuses.json').read_text()):
 source=Path(row['source_path']); source_data=source.read_bytes(); copy=(area/row['copy']).read_bytes()
 assert len(source_data)==row['source_bytes'] and sha(source_data)==row['source_sha256']
 assert len(copy)==row['copy_bytes'] and sha(copy)==row['copy_sha256']
 current=repo/source.name
 assert current.read_bytes()==source_data
 checks.append({'source_path':str(source),'current_production':str(current),'source_sha256':sha(source_data),
 'source_bytes':len(source_data),'copy':row['copy'],'copy_sha256':sha(copy),'copy_bytes':len(copy),
 'same_current_production':True})
for name in ['pins.json','FROZEN']:
 assert not (area/name).exists()
(area/'final-verification.json').write_text(json.dumps({'time':now,'checks':checks,
 'new_opaque_compiler_runs':[],'new_opaque_evaluator_runs':[],
 'scope_overruns':[],'source_truncations':[],'old_whole_bodies':1,'authorized_old_whole_max':2,
 'receipt_dependency_checked_by':'Root only; matching report and snapshot copied',
 'all_prior_frozen_bundles_unmodified':True},indent=2)+'\n')
payloads=[]
for path in sorted(area.rglob('*')):
 if path.is_file():
  data=path.read_bytes(); payloads.append({'path':str(path.relative_to(area)),'bytes':len(data),'sha256':sha(data)})
(area/'pins.json').write_text(json.dumps({'time':now,'owner':'/root/earlier_stop_control','write_halt':True,
 'new_proof_status':'Opaque V1 UNCOMPILED','payloads':payloads},indent=2)+'\n')
seal={'time':now,'write_halt':True,'payload_count':len(payloads),
 'pins_sha256':sha((area/'pins.json').read_bytes()),'report_sha256':sha((area/'REPORT.md').read_bytes()),
 'draft_sha256':sha((area/'ExecutionOpaqueBridge-v1-UNCOMPILED.lean').read_bytes()),
 'proof_status':'Opaque V1 SOURCE-ONLY UNCOMPILED; ReceiptBridge V2 checked by Root',
 'source_scope':'one new whole OLD body; one explicitly authorized new Root output; three verified frozen source reuses; exact bounded cuts',
 'full_goal_active':True,'no_haskell_claim':True}
(area/'FROZEN').write_text(json.dumps(seal,indent=2)+'\n')
for path in area.rglob('*'):
 if path.is_file():path.chmod(0o444)
for path in sorted(area.rglob('*'),reverse=True):
 if path.is_dir():path.chmod(0o555)
area.chmod(0o555)
for row in payloads:
 data=(area/row['path']).read_bytes();assert sha(data)==row['sha256'] and len(data)==row['bytes']
files=[p for p in area.rglob('*') if p.is_file()]
assert all(not (stat.S_IMODE(p.stat().st_mode)&0o222) for p in files)
print(json.dumps(seal,indent=2))
print('FROZEN_SHA256',sha((area/'FROZEN').read_bytes()))
print('REGULAR_FILES_READ_ONLY',len(files))
