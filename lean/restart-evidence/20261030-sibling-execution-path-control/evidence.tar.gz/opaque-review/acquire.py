from pathlib import Path
import datetime,hashlib,json
AREA=Path('/tmp/mcfta-sibling-execution-path-control-20261030/opaque-review')
REPO=Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
def sha(data): return hashlib.sha256(data).hexdigest()
def save(source, output, category, start=1,end=None,manifest=None):
 source=Path(source); data=source.read_bytes(); lines=data.splitlines(keepends=True)
 if end is None: end=len(lines)
 actual_end=min(end,len(lines)); selected=b''.join(lines[start-1:actual_end])
 dest=AREA/output; assert not dest.exists(); dest.write_bytes(selected)
 row={'time':datetime.datetime.now().astimezone().isoformat(),'source_path':str(source),
 'source_bytes':len(data),'source_lines':len(lines),'source_sha256':sha(data),
 'requested_start':start,'requested_end':end,'actual_start':start,'actual_end':actual_end,
 'copy':output,'copy_bytes':len(selected),'copy_sha256':sha(selected),
 'category':category,'whole':start==1 and actual_end==len(lines)}
 if manifest: row['frozen_evidence']=manifest
 p=AREA/'acquisitions.json'; rows=json.loads(p.read_text()) if p.exists() else []; rows.append(row)
 p.write_text(json.dumps(rows,indent=2)+'\n'); return row

if __name__=='__main__':
 print(json.dumps(save(REPO/'SourcePruningEnumerationPreparedOpaqueFiniteResources.lean',
 'cuts/001-PreparedOpaqueFiniteResources.lean','new whole OLD production source'),indent=2))
 source=Path('/tmp/mcfta-sibling-execution-path-control-20261030/receipt-bridge-strict-v2/MicroCFTA/SourcePruningEnumerationExecutionReceiptBridge.lean')
 assert sha(source.read_bytes())=='94a97a311d304ac5b3a143ee3a8ddd477b3e0b61070bee8904a4dbb89769245d'
 assert source.read_bytes()==(REPO/source.name).read_bytes()
 print(json.dumps(save(source,'reused/SourcePruningEnumerationExecutionReceiptBridge.lean',
 'explicitly authorized NEW Root checked output'),indent=2))
 manifest=AREA/'reused/traversal-FROZEN.json'; d=json.loads(manifest.read_text()); assert d['write_halt']
 rel='path-prepared-opaque-raw-v1-strict/MicroCFTA/SourcePruningEnumerationPathPreparedOpaqueRaw.lean'
 pin=next(e for e in d['payloads'] if e['path']==rel)
 source=Path('/tmp/mcfta-traversal-path-control-20261030')/rel
 data=source.read_bytes(); assert len(data)==pin['bytes'] and sha(data)==pin['sha256']
 assert data==(REPO/source.name).read_bytes()
 print(json.dumps(save(source,'reused/SourcePruningEnumerationPathPreparedOpaqueRaw.lean',
 'verified frozen full source reuse',manifest={'path':str(manifest),'sha256':sha(manifest.read_bytes()),'payload':pin}),indent=2))
