from pathlib import Path
import json,hashlib
area=Path('/tmp/mcfta-sibling-execution-path-control-20261030/opaque-review')
old=(area/'cuts/001-PreparedOpaqueFiniteResources.lean').read_text()
bridge=(area/'reused/SourcePruningEnumerationExecutionReceiptBridge.lean').read_text()
prepared=bridge.split('namespace MicroCFTA.SourcePruningEnumerationExecutionReceiptBridge.Prepared\n',1)[1]
ih='    (pathsIH :'+prepared.split('    (pathsIH :',1)[1].split(' :\n    ∃',1)[0]
old_ns='MicroCFTA.SourcePruningEnumerationPreparedNativeHookResources'
new_ns='MicroCFTA.SourcePruningEnumerationExecutionOpaqueBridge.Prepared'
context=old.split('namespace '+old_ns+'\n',1)[1].split('/--',1)[0]
new_context='open SourcePruningEnumerationPreparedNativeHookResources\n'+context+'''open SourcePruningEnumerationPathTransport (StatePaths BucketPaths ProjectionPaths)
open SourcePruningEnumerationExecutionPathData (FullReceiptPaths FoldPaths OutcomePaths PreparedFailurePaths)
open SourcePruningEnumerationExecutionPaths (OpaquePaths ResumePrepared)
'''
header,body=old.split('theorem opaque_finite_complete_resources\n',1)[1].split(' := by\n',1)
body=body.rsplit('\nend '+old_ns,1)[0]
inputs,result=header.split(' :\n    ∃',1)
new_inputs=inputs+'''
    (P : EqualityTrie.Path → Prop)
    (paths : StatePaths P before.core)
    (projected : ProjectionPaths (finiteStep recursiveFuel seed capturedMass inherited).1 P)
'''+ih
opaque='''OpaquePaths P
          (ResumePrepared P holeKey fits admits graph templates checkEmpty edgesOf stop order
            (bound + extra) recursiveFuel)
          (PreparedFailurePaths P)
          (continueWith
            (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
              (bound + extra) recursiveFuel)
            graph templates stop order (bound + extra) metadata target)
          graph templates stop order checkEmpty (bound + extra) metadata target target
          scs value caller before memos.query'''
new_result=result+' ∧\n      (∀ extra, '+opaque+') ∧\n      OutcomePaths P (PreparedFailurePaths P) (finish target folded)'
needle='  have padding := '
insert='''  have inputs : BucketPaths P scs :=
    paths (.unenumerated (some handle) scs) (List.mem_of_getElem? stored)
  have receiptPaths : FullReceiptPaths P receipt := by
    have actualPaths := SourcePruningEnumerationPathPreparedOpaqueRaw.run_paths checkEmpty
      (headBound + 0) (headBound + 0) (headBound + 0) (headBound + 0) (headBound + 0)
      target scs value caller before memos.query paths inputs
    rw [headRun 0] at actualPaths
    exact actualPaths
'''
assert body.count(needle)==1
body=body.replace(needle,insert+needle)
body=body.replace('obtain ⟨callbackFuel, outcome, callbackRun, resources⟩ :=',
                  'obtain ⟨callbackFuel, outcome, callbackRun, resources, receiptLeft, outcomePaths⟩ :=')
body=body.replace('    SourcePruningEnumerationPreparedRecursive.receipt_finite_complete_resources\n',
                  '    SourcePruningEnumerationExecutionReceiptBridge.Prepared.receipt_finite_complete_resources_paths\n')
needle='      boundedHead knownHead selectionMembers selectionLength mass reserved.2\n'
assert body.count(needle)==1
body=body.replace(needle,needle+'      P receiptPaths projected pathsIH\n')
start='''  have foldedPaths : FoldPaths P (PreparedFailurePaths P) folded := by
    cases receipt with
    | unhandled => cases advancedQuery
    | complete fragment reached queries after =>
        cases outcome with
        | complete outputs actual saved =>
            refine ⟨?_, outcomePaths⟩
            intro observed member
            rcases List.mem_singleton.mp member with rfl
            exact receiptPaths
        | stopped outputs reason endpoint =>
            refine ⟨?_, outcomePaths.1, receiptPaths, outcomePaths.2⟩
            intro observed member
            exact False.elim (List.not_mem_nil member)
    | rejected reached queries after | stopped fragments observation candidate =>
        refine ⟨?_, ?_⟩
        · intro observed member
          rcases List.mem_singleton.mp member with rfl
          exact receiptPaths
        · intro output member
          exact False.elim (List.not_mem_nil member)
  have opaqueAt (extra : Nat) :
      OpaquePaths P
        (ResumePrepared P holeKey fits admits graph templates checkEmpty edgesOf stop order
          (headBound + callbackFuel + extra) recursiveFuel)
        (PreparedFailurePaths P)
        (continueWith
          (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
            (headBound + callbackFuel + extra) recursiveFuel)
          graph templates stop order (headBound + callbackFuel + extra) metadata target)
        graph templates stop order checkEmpty (headBound + callbackFuel + extra) metadata target target
        scs value caller before memos.query := by
    have dispatched := headRun (callbackFuel + extra)
    rw [← Nat.add_assoc] at dispatched
    refine ⟨?_, ?_, ?_⟩
    · intro observed actual
      rw [dispatched] at actual
      have same := Option.some.inj actual
      cases same
      exact receiptPaths
    · rw [dispatched, foldAt extra]
      exact foldedPaths
    · intro fragment reached queries after actual
      rw [dispatched] at actual
      have same : receipt = .complete fragment reached queries after := Option.some.inj actual
      have actualLeft := receiptLeft (headBound + extra)
      rw [callbackCommon extra, same] at actualLeft
      exact actualLeft
'''
needle='  refine ⟨headBound + callbackFuel,'
assert body.count(needle)==1
body=body.replace(needle,start+needle)
body=body.replace('shape, boundedHead, knownHead, callbackAligned, foldAt, finished, ?_⟩',
                  'shape, boundedHead, knownHead, callbackAligned, foldAt, finished, ?_, ?_, ?_⟩')
body+='''  · exact opaqueAt
  · exact SourcePruningEnumerationExecutionPathData.prepared_finish_paths target folded foldedPaths
'''
text='''import MicroCFTA.SourcePruningEnumerationPreparedOpaqueFiniteResources
import MicroCFTA.SourcePruningEnumerationExecutionReceiptBridge

/-!
# Internal execution paths through prepared opaque dispatch

This draft is UNCOMPILED.
The old resource result retains every witness and operational equation.
The additional paths inspect the actual opaque callback and its final result.
The smaller-depth execution premise is an internal induction hypothesis.
-/
namespace '''+new_ns+'\n'+new_context+'\n/-- Keep opaque resources and the paths in the same actual dispatch and callback. -/\n'
text+='theorem opaque_finite_complete_resources_paths\n'+new_inputs+' :\n    ∃'+new_result+' := by\n'+body+'\nend '+new_ns+'\n'
output=area/'ExecutionOpaqueBridge-v1-UNCOMPILED.lean'
assert not output.exists(); output.write_text(text)
recovery={'old_namespace':old_ns,'new_namespace':new_ns,'old_inputs_verbatim':new_inputs.startswith(inputs),
 'old_result_verbatim':new_result.startswith(result),'old_context_verbatim':context in new_context,
 'all_three_original_instances_retained':context.count('variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]')==1,
 'concrete_IH_identical_to_checked_ReceiptBridge':ih in new_inputs,
 'old_inputs_sha256':hashlib.sha256(inputs.encode()).hexdigest(),
 'old_result_sha256':hashlib.sha256(result.encode()).hexdigest(),
 'old_context_sha256':hashlib.sha256(context.encode()).hexdigest(),
 'new_inputs':['P','paths','projected','pathsIH'],
 'new_results':['OpaquePaths at every bound+extra','OutcomePaths of finish target folded'],
 'kernel_checked':False}
assert all(recovery[k] for k in ['old_inputs_verbatim','old_result_verbatim','old_context_verbatim','all_three_original_instances_retained','concrete_IH_identical_to_checked_ReceiptBridge'])
(area/'header-recovery-v1.json').write_text(json.dumps(recovery,indent=2)+'\n')
print(json.dumps({'path':str(output),'bytes':len(text.encode()),'lines':len(text.splitlines()),'sha256':hashlib.sha256(text.encode()).hexdigest(),'recovery':recovery},indent=2))
