
/-- Every represented path in the bucket satisfies the predicate. -/
def BucketPaths (P : EqualityTrie.Path → Prop) (scs : List Suspended) : Prop :=
  ∀ sc ∈ scs, ∀ path ∈ EqualityTrie.fromPathTrie sc.trie, P path

/-- Every stored pending bucket satisfies the path predicate. -/
def StatePaths {Symbol Guard : Type} (P : EqualityTrie.Path → Prop)
    (state : EnumerationState.State Symbol Guard) : Prop :=
  ∀ value ∈ state.values, BucketPaths P (references value)

/-- Each actual guard projection satisfies the path predicate. -/
def ProjectionPaths
    (guards : List (SourceSymbolicIndex.Constraint FullSyntax.Formula))
    (P : EqualityTrie.Path → Prop) : Prop :=
  ∀ guard ∈ guards, ∀ tries residual,
    SourcePruningEnumerationConstraint.project guard = some (tries, residual) →
    ∀ trie ∈ tries, ∀ path ∈ EqualityTrie.fromPathTrie trie, P path

