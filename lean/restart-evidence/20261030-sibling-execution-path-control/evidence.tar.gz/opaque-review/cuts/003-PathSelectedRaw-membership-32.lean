  exact ⟨paths, paths value (List.mem_of_getElem? stored)⟩
