# Prepared opaque resource and execution-path bridge

Status: SOURCE-ONLY. The new Opaque V1 draft is UNCOMPILED.
The owner has run no Lean compiler, evaluator, native job, Git command,
network command, or board command. The owner has made no production edit.
The full CFTA goal remains active.

## Result

`ExecutionOpaqueBridge-v1-UNCOMPILED.lean` proposes:

`MicroCFTA.SourcePruningEnumerationExecutionOpaqueBridge.Prepared.opaque_finite_complete_resources_paths`

The draft has 300 lines and 19,346 bytes. Its SHA256 is
`0f6952c9fc723141ef67f731b7189b6f7312cad82e3efb9c7d8c20a932e05298`.
This version is immutable after announcement. The owner has read it in full.

The theorem retains every input of the old `opaque_finite_complete_resources`.
It retains all eight witnesses: bound, receipt, middleCaller, saved,
middleMemos, middleInventory, outcome, and folded. It retains every old
receipt, Post, memo, admission, pending, history, Fits, heap, receipt-shape,
callback, fold, resource, and stable-running clause.

The result appends two conjuncts:

- At every `bound + extra`, the actual dispatcher and its actual callback
  satisfy `ExecutionPaths.OpaquePaths`.
- The same `finish target folded` has `OutcomePaths` with
  `PreparedFailurePaths`.

The callback is literally the old Prepared `continueWith` with Prepared
`resume`, at the same work bound and recursive depth. Its metadata is the
old metadata. Both the recording variable and opaque target are `target`.
The caller, cache, and query memo are the old `caller`, `before`, and
`memos.query`. No other outer recording variable or cache frame is substituted.
If a later caller has a distinct recordUV parameter, that caller must prove
the required equality or use an appropriate generalization. This draft does
not prove equality between an arbitrary recordUV and target.

## Additional internal inputs

There are exactly four added inputs:

- `P : EqualityTrie.Path → Prop`.
- `StatePaths P before.core`.
- `ProjectionPaths (finiteStep recursiveFuel seed capturedMass inherited).1 P`.
- The concrete smaller-depth eventual Prepared execution-path induction
  hypothesis from the checked ReceiptBridge.

The IH text is identical to the checked Prepared ReceiptBridge header. It
quantifies the current inventory, caller, memos, cache, metadata, seed, and
ceiling. It takes Packet, Fits, heap membership, the old selection policies,
suspended mass, reservation, current cache paths, and the exact computed
final forecast projections. It returns eventual concrete Prepared execution
paths at recursiveFuel. It is an internal successor-depth composition input.
The original-input theorem must discharge it by induction.

The old Complete input remains. No new Complete, final Packet, successful
query, satisfying model, future receipt, or detached future cache supplier
is added. Bucket paths and receipt paths are derived inside the proof.
All three original DecidableEq instances remain unchanged.

## Proof route

The proof first follows the old head resource producer unchanged. The
stored `.unenumerated (some handle) scs` value is a member of before.core.values.
The input StatePaths therefore gives BucketPaths for scs. The existing
PathSelectedRaw proof at line 32 confirms the same List.mem_of_getElem?
membership idiom.

The checked arbitrary-work `PathPreparedOpaqueRaw.run_paths`, applied to the
same opaque operation at headBound plus zero, gives both ReceiptPaths and
all successful rows in a retained stopped observation. Rewriting by the
actual headRun equation gives FullReceiptPaths for the fixed receipt.
This uses no new validity, model, or native resource premise.

The checked ReceiptBridge then supplies the callback resource result, actual
LeftPaths, and paths for the same callback outcome. The original head padding,
mass proof, callback common-bound arithmetic, folded definition, fold equations,
and finished resource proof are retained. In particular, callback work remains
aligned at headBound + callbackFuel + extra.

The new FoldPaths proof inspects the fixed receipt and fixed callback outcome.
A complete receipt followed by a complete callback retains the singleton
processed receipt and every output cache. A stopped callback retains its
current receipt and the full Prepared failure paths. A rejected or stopped
head receipt retains its singleton processed receipt even though it emits no
output. The unhandled receipt remains impossible by the old advance equation.

OpaquePaths follows from the stable actual dispatcher equation, this FoldPaths
proof, and the checked receipt LeftPaths at the aligned work bound. It includes
the actual completed callback and its literal false recursive calls before
finish discards processed receipts. Finally, the checked prepared_finish_paths
law gives OutcomePaths of finish target folded. No second outcome witness or
unproved equality between independent outcomes is used.

## Header preservation

`header-recovery-v1.json` records a successful text check. The old inputs,
old result, and old context occur verbatim in the new declaration after the
additions are removed. The eight existential witnesses and their order are
unchanged. The concrete IH is copied from the checked ReceiptBridge.
This text check does not replace elaboration or a kernel check.

## Checked receipt dependency

Root reported that ReceiptBridge owner V1 passed strict checking unchanged.
Installed V2 deletes only the sentence `This draft is UNCOMPILED.` from its
module documentation. The owner verified this exact byte transformation.
The installed source, Root strict snapshot, and owned copy all have SHA256
`94a97a311d304ac5b3a143ee3a8ddd477b3e0b61070bee8904a4dbb89769245d`.
The snapshot has 315 lines and 20,646 bytes.

`root-checks/receipt-bridge-v2-report.json` records Root's successful strict
command, exit code zero, an empty log, and that source SHA. The recorded
memory limit is 4 GiB and swap limit is zero. The owner copied and read this
report and the empty log. The owner did not run the command.

The earlier receipt-review bundle remains frozen and unmodified. Its report
correctly describes its own earlier uncompiled checkpoint. The present report
records the later Root validation. The present Opaque V1 remains uncompiled.

## Source scope

The only new whole OLD proof-bearing body acquired was:

- `SourcePruningEnumerationPreparedOpaqueFiniteResources.lean`, requested and
  actual lines 1–206 of 206, 14,081 bytes, SHA256
  `e64c0d8530d49ec2e25cf60a38fcbff90bd2cbfebbe574dd2d1ce5bd56a96ae6`.

The second named body, PreparedOpaqueFiniteResourcesArity, was not needed.
Only wc/hash metadata was obtained for it: 210 lines, SHA256
`2b050960b07f27eaf4ed599d94bf46ffc2f5fb145bba74f63dc6bb06ada20ca8`.
No header or proof body from that file was copied or displayed.

ReceiptBridge V2 was a separate full acquisition of new Root output explicitly
authorized by this task. It was not treated as frozen old source or charged
silently to the old-body allowance.

Three full sources were reused after manifest, pin, current hash, and byte
identity checks:

- ExecutionPaths, 282 lines, 19,132 bytes,
  `4d38fc8805cd0fb104ce2451e8e438e6eaa7228c34c38b4c28284c478ed70b76`.
- ExecutionPathData, 102 lines, 5,884 bytes,
  `db39b16c885d60ecca4a600763acef2c64447778dd6fec51f13cc88d0cdc2a28`.
- PathPreparedOpaqueRaw, 88 lines, 4,986 bytes,
  `e564c89a827609cc1de32186774f60af1878e804243a5c2ffb243cc401634271`.

The first two came from frozen receipt-review payloads. The raw opaque source
came from the frozen traversal Root strict snapshot. Its copied Root manifest
has SHA256
`c67c2ba81e41484d04f8b16d662d67a4e25c71dd0f00ce413764a01150fde47f`
and write_halt is true. All copied sources match current production bytes.
The raw opaque proof and the new ReceiptBridge source were read in full.

Bounded new production cuts are PathTransport lines 13–30 plus declaration
locators, and PathSelectedRaw line 32. The aggregate PathTransport union is
13–30, 50, 59, 72, 88, 106, 152, and 207: 25 lines of 240. PathSelectedRaw is
one line of 161. Neither is a whole or near-whole acquisition. Exact requested
and actual endpoints, full source hashes, copy bytes, and range unions are in
acquisitions.json, reuses.json, and scope-unions.json. There is no third whole
OLD body, source truncation, compiler diagnostic, or scope overrun.

The current branch base was supplied by Root as
`26b76c6fd289819222c8f862ada72f8e3c667f65`. No Git command was run. The older
2c32 context in the prior receipt report is historical. Current source identity
is established by the recorded hashes and bytes.

## Limits and next action

Root must compile the complete immutable draft. In particular, the new local
FullReceiptPaths conversion, FoldPaths constructor proofs, and OpaquePaths
rewrites have not been checked. No proof placeholder, custom axiom, lint
suppression, or source evaluation is used in the draft.

This internal opaque bridge does not establish the whole-worker execution
invariant. It does not establish sufficient original recursive depth, coverage
of every earlier alternative before a permitted finite witness, finite handle
renewal, or neutral-step progress. Root already has the original guard-derived
forecast path laws; their full worker composition remains separate.

No Haskell defect, repair, or runtime claim is made. Root handles production
integration, validation, FINDINGS, and publication. The owner will freeze all
regular files read-only with a manifest and write-halt marker, then stop writes.
