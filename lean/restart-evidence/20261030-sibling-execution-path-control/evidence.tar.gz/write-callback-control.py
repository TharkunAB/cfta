from pathlib import Path
import json
r=Path('/tmp/mcfta-sibling-execution-path-control-20261030')
head='''import MicroCFTA.SourcePruningEnumerationExecutionPaths
import MicroCFTA.SourcePruningEnumerationPathRecordingValues

/-!
# Paths through the literal recursive callback

The singleton observation fixes the actual framed recursive input.
The result retains paths even when the callback emits no output.
-/
namespace MicroCFTA.SourcePruningEnumerationExecutionCallbackControl
open EnumerationState InternedConstructorTemplates
open SourcePruningEnumerationPathTransport (StatePaths)
open SourcePruningEnumerationPathSelectedRaw (RawPaths)
open SourcePruningEnumerationExecutionPathData
open SourcePruningEnumerationExecutionPaths
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Fragment" => Fragments.Fragment Symbol
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Queries" => SourceEndpointMemo.Memos
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
local notation "Metadata" => SourcePruningRecordTypes.Metadata
local notation "Core" => EnumerationState.State Symbol Constraint
variable {Typing Key : Type} {width : Nat}
variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]

'''
cfg='''    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool) (admits : Key → Node → Bool)
    (graph : Graph Symbol Constraint) (templates : List (Template.Pattern Symbol))
    (checkEmpty : Bool) (edgesOf : Node → List (EdgeValue Symbol Constraint))
    (stop : Option (Metadata Typing → Nat → Bool))
    (order : Metadata Typing → List Nat → Option Nat) (workFuel recursiveFuel : Nat)'''
args='holeKey fits admits graph templates checkEmpty edgesOf stop order workFuel recursiveFuel'
s=head
for label,worker,reason in [('Native','SourcePruningEnumerationRecursive','NativeFailurePaths'),('Prepared','SourcePruningEnumerationPreparedRecursive','PreparedFailurePaths')]:
 lo=label.lower()
 s+=f'''/-- An actual recursive execution retains its literal outcome paths. -/
theorem resume_{lo}_outcome (P : EqualityTrie.Path → Prop)
{cfg}
    (metadata : Metadata Typing) (caller : Caller width) (queries : Queries) (before : Cached)
    (next : Option Next)
    (paths : Resume{label} P {args} metadata caller queries before next) :
    OutcomePaths P ({reason} P)
      ({worker}.resume {args} metadata caller queries before next) := by
  cases recursiveFuel with
  | zero => exact paths.2
  | succ fuel => exact paths.2.1

'''
for label,worker,reason in [('Native','SourcePruningEnumerationRecursive','NativeFailurePaths'),('Prepared','SourcePruningEnumerationPreparedRecursive','PreparedFailurePaths')]:
 lo=label.lower()
 s+=f'''/-- The actual singleton callback carries the same paths into its literal false continuation. -/
theorem {lo}_left_of_singleton (P : EqualityTrie.Path → Prop)
{cfg}
    (metadata : Metadata Typing) (uv : Nat) (fragment : Fragment)
    (caller : Caller width) (queries : Queries) (before : Cached)
    (result : Bool × Metadata Typing) (after : Core)
    (paths : StatePaths P before.core)
    (observed : ExceptT.run (SourcePruningRecordTypes.recordTypes
      graph templates workFuel metadata uv (.inl fragment) before.core) = [.ok (result, after)])
    (nested : result.1 = false → {label} P {args}
      result.2 caller queries (EnumerationExpandableIndex.frame after before)) :
    LeftPaths P (Resume{label} P {args}) ({reason} P)
      ({worker}.continueWith ({worker}.resume {args})
        graph templates stop order workFuel metadata uv)
      graph templates stop order workFuel metadata uv fragment caller queries before := by
  refine ⟨paths, ?_, ?_, ?_⟩
  · intro actual core member
    exact SourcePruningEnumerationPathRecordingValues.recordTypes_paths
      graph templates workFuel metadata uv (.inl fragment) before.core core actual paths member
  · cases result with
    | mk keep updated =>
        cases keep with
        | false =>
            rw [{worker}.continueWith, observed]
            exact resume_{lo}_outcome P {args} updated caller queries
              (EnumerationExpandableIndex.frame after before)
              (SourcePruningEnumerationRestart.decision stop order updated
                (EnumerationExpandableIndex.frame after before)) (nested rfl)
        | true =>
            rw [{worker}.continueWith, observed]
            intro output member
            cases member
  · intro updated core seen
    have rowSame := (List.cons.inj (observed.symm.trans seen)).1
    have pairSame := Prod.mk.inj (Except.ok.inj rowSame)
    rcases pairSame with ⟨rfl, rfl⟩
    exact nested rfl

'''
s+='end MicroCFTA.SourcePruningEnumerationExecutionCallbackControl\n';(r/'callback-control-v1.lean').write_text(s);(r/'probe-control-v1.json').write_text(json.dumps([['probe','callback-control-v1-probe','callback-control-v1.lean']])+'\n')
