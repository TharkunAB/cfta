from pathlib import Path
import hashlib
import json
import sys
from datetime import datetime

original = Path('/tmp/mcfta-sibling-execution-path-control-20261030')
r = Path(sys.argv[1]) if len(sys.argv) > 1 else original
out = Path(sys.argv[2]) if len(sys.argv) > 2 else r
out.mkdir(exist_ok=True)
repo = Path('/home/tritlo/Code/mcfta')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def inspect_sources(value, directory, checked):
    if isinstance(value, list):
        for row in value:
            inspect_sources(row, directory, checked)
    if not isinstance(value, dict):
        return
    name = value.get('source_path', value.get('source'))
    digest = value.get('source_sha256')
    if isinstance(name, str) and name.startswith(str(repo / 'lean/MicroCFTA') + '/') and digest:
        source = Path(name).read_bytes()
        assert sha(source) == digest, name
        if 'source_bytes' in value:
            assert len(source) == value['source_bytes'], name
        copy = value.get('copy')
        if isinstance(copy, str) and (directory / copy).is_file():
            copied = (directory / copy).read_bytes()
            if 'copy_sha256' in value:
                assert sha(copied) == value['copy_sha256'], copy
            start = value.get('actual_start')
            end = value.get('actual_end')
            if isinstance(value.get('actual'), list):
                start, end = value['actual']
            if start == 1 and end == len(source.splitlines()):
                assert copied == source, copy
        checked.add((name, digest))
    for child in value.values():
        if isinstance(child, (list, dict)):
            inspect_sources(child, directory, checked)


owners = ['receipt-review', 'head-sibling-review', 'opaque-review', 'parked-review']
if (r / 'public-readback-review/pins.json').is_file():
    owners.append('public-readback-review')
results = []
for name in owners:
    directory = r / name
    pin_bytes = (directory / 'pins.json').read_bytes()
    pins = json.loads(pin_bytes)
    if name == 'head-sibling-review':
        manifest_bytes = (directory / 'MANIFEST.json').read_bytes()
        assert sha(manifest_bytes) == pins['manifest_sha256']
        assert sha((directory / 'FROZEN').read_bytes()) == pins['marker_sha256']
        assert sha((directory / 'REPORT.md').read_bytes()) == pins['report_sha256']
        rows = json.loads(manifest_bytes)['files']
        metadata = {'MANIFEST.json', 'pins.json'}
    else:
        rows = pins if isinstance(pins, list) else pins['payloads']
        marker = 'FROZEN.json' if (directory / 'FROZEN.json').exists() else 'FROZEN'
        seal = json.loads((directory / marker).read_text())
        halt = seal['write_halt']
        if isinstance(halt, str):
            assert datetime.fromisoformat(halt).tzinfo is not None
        else:
            assert halt is True
        assert seal['pins_sha256'] == sha(pin_bytes)
        metadata = {'pins.json', marker}
    actual = {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()}
    assert actual == {row['path'] for row in rows} | metadata, name
    for row in rows:
        p = directory / row['path']
        b = p.read_bytes()
        assert len(b) == row['bytes'] and sha(b) == row['sha256'], p
    checked = set()
    for p in directory.rglob('*'):
        if not p.is_file():
            continue
        assert not p.is_symlink() and not (p.stat().st_mode & 0o222), p
        if p.suffix == '.json':
            inspect_sources(json.loads(p.read_text()), directory, checked)
    results.append({'owner': name, 'payloads': len(rows), 'regular_files': len(actual),
                    'pins_sha256': sha(pin_bytes), 'current_source_identities': len(checked),
                    'payload_hashes_and_file_set': 'pass', 'all_files_read_only': True})

summary = {'owners': results, 'payloads': sum(row['payloads'] for row in results),
           'regular_files': sum(row['regular_files'] for row in results),
           'all_hashes_modes_and_current_source_identities': 'pass'}
(out / 'owned-verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
