# Sibling execution-path control

The full goal is to formalize the library with its optimized interned core.
For admissible original inputs, enough original resources must produce each
intended finite prefix that the configured order, edge policy, and stop rule
permit. Returned values must be sound. Keep the required native range gates.
Cover both workers, Prefix, table, count, checkpoint, and public adapters.
Connect the source model to Haskell. Retain the constructor and equality
results, exact accepted terms per node count, size order, and rank/unrank laws.

This phase composes actual execution paths through recording, receipts,
native and prepared heads, ordinary siblings, and prepared opaque dispatch.
The next target is a separate eventual positive-depth path induction for both
workers. Combine its work bound C with the unchanged resource bound B at B+C.
Do not add a future trace, model, Complete, or callback supplier to a closed
original-input theorem. Internal smaller-depth induction premises must later
be discharged. A fixed-depth Complete result can still report exhaustion.

The main remaining gap is sufficient original recursion depth through all
earlier alternatives and staged children. Handle renewal, composed rewrites,
raw multiplicity, branch and slot work, and neutral steps need bounds.
A finite original path carrier alone does not give these bounds.

The starting branch is formalize at 26b76c6fd289819222c8f862ada72f8e3c667f65.
Main is bd5a406a6a3f84b7e3ae0906082783911509df83.
The initial comparison retains 535 protected sources, 4734 Lean sources,
835 native inputs, 1164 public checks, and 116 definition prints.
The complete prior public output and prior root documents are retained.
The prior phase made verified progress and published its complete archive.
Both upstream refs were refreshed again at 19:38 CET after a long interval.
The branch was current. No cause for the interval is inferred.

Root alone runs compilers, evaluates code, changes production files, uses
Git or network tools, posts board notes, and packages evidence.
Every compiler command runs serially with capped --mem 4G --time 5m.
Use Lean 4.34.1, warningAsError=true, and linter.all=true for strict checks.
Keep memory.max and memory.high at 4294967296 and memory.swap.max at zero.
Keep all diagnostics, command failures, source versions, and snapshots.
Do not change the cap, heartbeat, queue, or server configuration.

The receipt owner has frozen receipt-review with 19 payloads.
It read exactly the two approved old receipt resource bodies.
It reused three exact frozen path and callback sources.
Root verified every payload hash, file mode, and current reused source.
Its report gives an older unverified base commit. The actual base is above.
No frozen report is changed. Root records this correction separately.

The head and sibling owner owns only head-sibling-review.
It may read the two approved old head resource bodies in full.
It may reuse the approved frozen sibling and execution-path sources.
Other new production reads must remain bounded.

The opaque owner owns only opaque-review.
It may read the two approved prepared opaque finite resource bodies in full.
It may reuse exact frozen paths and the current checked receipt bridge.
Each owner records acquisition ranges and hashes, reads its complete draft
and report, freezes every file, and stops. Owners run no code or compilers.
Owners do not change production files, use Git or network tools, or spawn.

The parked owner owns only parked-review.
It may read the native and prepared FiniteParkedResources bodies in full.
It may reuse the exact frozen execution paths and current receipt bridge.
Its target is the same resource witness plus paths through the actual parked
raw rows and the returned smaller-depth restart call. The same owner rules
apply. This independent task uses the fourth available execution slot.

No Haskell input changes in this phase so far. No native command runs.
No new Haskell defect, repair, or candidate is established.
Record any later Haskell finding in root FINDINGS.md.
Keep all previous root document bodies as exact suffixes.
Normal pushes to origin formalize have explicit standing authorization.
No force push is authorized. This phase does not complete the full goal.

The goal controller reported blocked when read at 19:41 CET despite the
explicit instruction to keep going and current verified proof progress.
Root cannot change that marker to active with the available status tool.
No current technical blocker is inferred from this administrative marker.
Work continues under the user's instruction. Do not mark the goal complete.
