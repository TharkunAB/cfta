from pathlib import Path
import hashlib
import json

r = Path(__file__).parent
receipt = (r / 'reused/SourcePruningEnumerationExecutionReceiptBridge.lean').read_text()
module = '''import MicroCFTA.SourcePruningEnumerationFiniteParkedResources
import MicroCFTA.SourcePruningEnumerationPreparedFiniteParkedResources
import MicroCFTA.SourcePruningEnumerationExecutionPaths
import MicroCFTA.SourcePruningEnumerationPathSelectedPrefix

/-!
# Internal resource and execution paths for a parked expansion

This source-only draft has not been compiled.
The smaller-depth execution premise is an internal induction hypothesis.
The same bound applies to the resource outcome and all actual execution paths.
The original-input theorem must derive the induction hypotheses.
-/

'''
recoveries = []
for prepared in [False, True]:
    kind = 'Prepared' if prepared else 'Native'
    oldname = ('SourcePruningEnumerationPreparedFiniteParkedResources' if prepared
               else 'SourcePruningEnumerationFiniteParkedResources')
    original = (r / 'sources' / (oldname + '.lean')).read_text()
    oldns = ('MicroCFTA.SourcePruningEnumerationPreparedRecursive' if prepared
             else 'MicroCFTA.SourcePruningEnumerationRecursive')
    newns = 'MicroCFTA.SourcePruningEnumerationExecutionParkedBridge.' + kind
    context = original[original.index('namespace ' + oldns):original.index('/-- The original reservation')]
    context = context.replace('namespace ' + oldns, 'namespace ' + newns, 1)
    context = context.replace('open EnumerationState InternedConstructorTemplates',
                              'open ' + oldns.split('MicroCFTA.')[1] + '\nopen EnumerationState InternedConstructorTemplates', 1)
    context += '''open SourcePruningEnumerationPathTransport (StatePaths ProjectionPaths)
open SourcePruningEnumerationExecutionPathData (OutcomePaths NativeFailurePaths PreparedFailurePaths)
open SourcePruningEnumerationPathSelectedRaw (SelectedPrefixPaths)
open SourcePruningEnumerationExecutionPaths (ResumeNative ResumePrepared)
local notation "suspendedBound" => SourcePruningEnumerationPrefixAdmission.suspendedBound

'''
    start = original.index('theorem parked_finite_complete_resources')
    end = original.index(' := by', start)
    oldheader = original[start:end]
    pos = oldheader.index(' :\n    ∃')
    res = ('SourcePruningEnumerationPreparedReservation' if prepared
           else 'SourcePruningEnumerationFiniteReservation')
    block = receipt.split('namespace MicroCFTA.SourcePruningEnumerationExecutionReceiptBridge.' + kind, 1)[1]
    ihstart = block.index('    (pathsIH :')
    ihend = block.index(') :\n    ∃ (fuel', ihstart)
    ih = block[ihstart:ihend + 1]
    additions = ('\n    (P : EqualityTrie.Path → Prop)\n'
                 '    (paths : StatePaths P before.core)\n'
                 '    (projected : ProjectionPaths (' + res + '.final (recursiveFuel + 1) seed ceiling).1 P)\n' + ih)
    worker = 'ResumePrepared' if prepared else 'ResumeNative'
    added_result = (' ∧\n      (∀ extra, ' + worker + ' P holeKey fits admits graph templates checkEmpty edgesOf stop order\n'
                    '        (bound + extra) (recursiveFuel + 1) metadata caller memos.query before (some (.expand uv)))')
    header = (oldheader[:pos] + additions + oldheader[pos:] + added_result).replace(
        'theorem parked_finite_complete_resources', 'theorem parked_finite_complete_resources_paths', 1)
    recovered = header.replace(additions, '', 1)
    assert recovered.endswith(added_result)
    recovered = recovered[:-len(added_result)].replace(
        'theorem parked_finite_complete_resources_paths', 'theorem parked_finite_complete_resources', 1)
    assert recovered == oldheader
    (r / (kind + '-old-header.lean.txt')).write_text(oldheader + '\n')
    (r / (kind + '-recovered-header.lean.txt')).write_text(recovered + '\n')
    recoveries.append({'worker': kind, 'old_header_bytes': len(oldheader.encode()),
                       'old_header_sha256': hashlib.sha256(oldheader.encode()).hexdigest(),
                       'exact_recovery': True, 'new_premise_block': additions, 'new_conclusion': added_result})
    body = original[original.index(' := by', start) + len(' := by'):original.rindex('end ' + oldns)]
    body = '''
  have selectedPaths := SourcePruningEnumerationPathSelectedPrefix.runPrefix_paths
    holeKey fits admits graph templates stop order metadata
    (prefixFuel + 0) (prefixFuel + 0) (prefixFuel + 0)
    (prefixFuel + 0) (prefixFuel + 0) (prefixFuel + 0) uv caller before memos.query paths
  rw [(phase 0).1] at selectedPaths
  have checkedPaths : StatePaths P checked.core := selectedPaths.1
''' + body
    blocked_old = '''    refine ⟨prefixFuel, .complete [] caller memos.query, ?_, resources.mono growth.1 growth.2⟩
    intro extra
    have observed := (phase extra).1
    rw [SourcePruningEnumerationRestart.run_exact, ite_eq_left blocked] at observed
    rw [resume, observed]
'''
    blocked_new = '''    refine ⟨prefixFuel, .complete [] caller memos.query, ?_, resources.mono growth.1 growth.2, ?_⟩
    · intro extra
      have observed := (phase extra).1
      rw [SourcePruningEnumerationRestart.run_exact, ite_eq_left blocked] at observed
      rw [resume, observed]
    · intro extra
      have observed := (phase extra).1
      rw [SourcePruningEnumerationRestart.run_exact, ite_eq_left blocked] at observed
      have actualPrefixPaths := SourcePruningEnumerationPathSelectedPrefix.runPrefix_paths
        holeKey fits admits graph templates stop order metadata
        (prefixFuel + extra) (prefixFuel + extra) (prefixFuel + extra)
        (prefixFuel + extra) (prefixFuel + extra) (prefixFuel + extra) uv caller before memos.query paths
      rw [observed] at actualPrefixPaths
      refine ⟨paths, ?_, ?_⟩
      · rw [resume, observed]
        intro output member
        exact False.elim (List.not_mem_nil member)
      · dsimp only
        rw [observed]
        exact ⟨actualPrefixPaths, True.intro⟩
'''
    assert blocked_old in body
    body = body.replace(blocked_old, blocked_new, 1)
    body = body[:body.index('    refine ⟨prefixFuel + resumeFuel, outcome')]
    body += ('    have smallerProjected : ProjectionPaths\n      (' + res + '.final recursiveFuel parkedSeed parkedMass).1 P := by\n'
             '      intro guard member\n      exact projected guard (growth.2 member)\n')
    if prepared:
        resume_call = '''rw [resume_parked holeKey fits admits graph templates checkEmpty edgesOf stop order
  (prefixFuel + resumeFuel + pathFuel + extra) recursiveFuel uv metadata metadata caller memos.query before
  checked checked.core checked.core (SourcePruningEnumerationRestart.decision stop order metadata checked)
  observed, framed]'''
    else:
        resume_call = '''rw [resume_parked holeKey fits admits graph templates checkEmpty edgesOf stop order
  (prefixFuel + resumeFuel + pathFuel + extra) recursiveFuel metadata caller memos.query before uv
  checked.core checked.core checked metadata (SourcePruningEnumerationRestart.decision stop order metadata checked)
  observed, framed]'''
    def indent(text, amount):
        return '\n'.join(' ' * amount + line for line in text.splitlines())
    body += '''    obtain ⟨pathFuel, continuing⟩ := pathsIH inventory caller memos checked metadata parkedSeed parkedMass
      checkedPacket parkedFits parkedKnown selectionMembers selectionLength boundedMass reserved.first.2
      checkedPaths smallerProjected
    refine ⟨prefixFuel + resumeFuel + pathFuel, outcome, ?_, resources.mono growth.1 growth.2, ?_⟩
    · intro extra
      have observed := (phase (resumeFuel + pathFuel + extra)).1
      have prefixSame : prefixFuel + (resumeFuel + pathFuel + extra) =
          prefixFuel + resumeFuel + pathFuel + extra := by omega
      rw [prefixSame, SourcePruningEnumerationRestart.run_exact, ite_eq_right blocked] at observed
''' + indent(resume_call, 6) + '''
      have actual := running (prefixFuel + pathFuel + extra)
      have common : resumeFuel + (prefixFuel + pathFuel + extra) =
          prefixFuel + resumeFuel + pathFuel + extra := by omega
      rw [common] at actual
      exact actual
    · intro extra
      have observed := (phase (resumeFuel + pathFuel + extra)).1
      have prefixSame : prefixFuel + (resumeFuel + pathFuel + extra) =
          prefixFuel + resumeFuel + pathFuel + extra := by omega
      rw [prefixSame, SourcePruningEnumerationRestart.run_exact, ite_eq_right blocked] at observed
      have actualPrefixPaths := SourcePruningEnumerationPathSelectedPrefix.runPrefix_paths
        holeKey fits admits graph templates stop order metadata
        (prefixFuel + resumeFuel + pathFuel + extra) (prefixFuel + resumeFuel + pathFuel + extra)
        (prefixFuel + resumeFuel + pathFuel + extra) (prefixFuel + resumeFuel + pathFuel + extra)
        (prefixFuel + resumeFuel + pathFuel + extra) (prefixFuel + resumeFuel + pathFuel + extra)
        uv caller before memos.query paths
      rw [observed] at actualPrefixPaths
      have nextExecution := continuing (prefixFuel + resumeFuel + extra)
      have pathWork : pathFuel + (prefixFuel + resumeFuel + extra) =
          prefixFuel + resumeFuel + pathFuel + extra := by omega
      rw [pathWork] at nextExecution
'''
    failure = 'PreparedFailurePaths' if prepared else 'NativeFailurePaths'
    body += ('      have nextResume : ' + worker + ''' P holeKey fits admits graph templates checkEmpty edgesOf stop order
          (prefixFuel + resumeFuel + pathFuel + extra) recursiveFuel metadata caller memos.query checked
          (SourcePruningEnumerationRestart.decision stop order metadata checked) := nextExecution
      have nextOutcome : OutcomePaths P (''' + failure + ''')
          (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
            (prefixFuel + resumeFuel + pathFuel + extra) recursiveFuel metadata caller memos.query checked
            (SourcePruningEnumerationRestart.decision stop order metadata checked)) := by
        cases recursiveFuel with
        | zero => exact nextResume.2
        | succ fuel => exact nextResume.2.1
      refine ⟨paths, ?_, ?_⟩
      · ''' + resume_call.splitlines()[0] + '\n' + indent('\n'.join(resume_call.splitlines()[1:]), 8) + '''
        exact nextOutcome
      · dsimp only
        rw [observed]
        refine ⟨actualPrefixPaths, ?_⟩
        dsimp only
        rw [framed]
        exact nextResume

''')
    module += (context + '/-- Retain the parked resource outcome and every literal recursive execution path. -/\n' +
               header + ' := by' + body + 'end ' + newns + '\n\n')
(r / 'header-recovery.json').write_text(json.dumps(recoveries, indent=2) + '\n')
p = r / 'ExecutionParkedBridge-v1-UNCOMPILED.lean'
p.write_text(module)
p.chmod(0o444)
print(len(module.splitlines()), len(module.encode()), hashlib.sha256(module.encode()).hexdigest())
