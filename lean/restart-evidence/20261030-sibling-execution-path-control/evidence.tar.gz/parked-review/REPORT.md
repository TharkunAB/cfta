# Paired parked resource and execution-path companions

## Status

The owner produced two complete source-only theorem drafts in one proposed module. The current candidate is `ExecutionParkedBridge-v2-UNCOMPILED.lean`. It has 421 lines and 28798 bytes. Its SHA256 is `3e2cfe4665de7329d5baf091e4b10cefbd92c501c80c7eba2b830920271b02cb`. The owner did not run Lean, an evaluator, a native program, Git, the network or the board. Root is the sole compiler and production writer. No repository file or prior frozen bundle was changed by the owner.

The draft gives one Native companion and one Prepared companion. Each retains the full old parked resource theorem and adds the actual execution-path predicate at the SAME existential bound plus every extra unit of work. It adds no placeholder, `sorry`, axiom, accepting model or future completion supplier. Its smaller-depth path premise is the concrete internal induction hypothesis from the checked ReceiptBridge. The original-input induction still has to discharge that premise.

This result is a proposed local composition step. It does not prove the whole worker invariant, sufficient original recursive depth, global coverage, public API correctness or Haskell correspondence. A fixed-depth resource result can still retain an exhausted outcome.

## Exact public targets

The proposed production module is `MicroCFTA.SourcePruningEnumerationExecutionParkedBridge`. The source path was absent when the draft was generated. Root owns any installation.

The two public targets are:

- `SourcePruningEnumerationExecutionParkedBridge.Native.parked_finite_complete_resources_paths`.
- `SourcePruningEnumerationExecutionParkedBridge.Prepared.parked_finite_complete_resources_paths`.

Each theorem preserves all old configuration inputs, recursive `Complete` premise, original inventory, caller, full memos, cache, metadata, prefix fuel, variable, checked cache, seed, ceiling, Packet, Fits, known heap, edge membership and length clauses, mass bound, reservation and exact stable parked phase. The old phase still includes its full `PrefixValid` result. The new theorem does not replace that phase with a supplied path theorem.

The added inputs are the predicate P, `StatePaths P before.core`, projection paths for the SAME original finite final forecast at depth `recursiveFuel + 1`, and the concrete smaller-depth execution IH. No suffix-closure premise is needed. The existing actual `runPrefix_paths` law preserves the initial predicate without one.

The IH is copied literally from the matching Native or Prepared ReceiptBridge signature. It quantifies over the actual next inventory, caller, full memos, cache, metadata, seed and ceiling. It requires their Packet, Fits, known heap, edge reader gates, mass bound, smaller reservation, input StatePaths and projection paths for their smaller final forecast. It returns an eventual bound for the corresponding `ExecutionPaths.Native` or `ExecutionPaths.Prepared` at the smaller depth. It does not receive a future successful query, frame, path trace or completed receipt.

Each result retains the old existential bound and outcome types, the old literal resume equality for every extra value, and the full unconditional `OutcomeResources` at the original final forecast. The only appended result is `ResumeNative` or `ResumePrepared` at that SAME bound plus extra, depth `recursiveFuel + 1`, original metadata, caller, query memos and before cache, with literal `some (.expand uv)`.

`header-recovery.json` records the exact additions. Removing only those additions and restoring the old theorem name recovers both complete old headers byte for byte. The old and recovered headers are saved separately. `PUBLIC-HEADERS.json` retains the complete new headers and their namespace, notation, class and implicit-variable context.

## Actual path derivation

`SourcePruningEnumerationPathSelectedPrefix.runPrefix_paths` requires only the original StatePaths. The draft applies it to the literal old phase at `prefixFuel + 0`. Rewriting by `(phase 0).1` gives StatePaths for `checked.core`. The proof does not infer those paths from PrefixValid, a model or a future recursive result.

The same actual prefix law is used again at every final common work value. Its `SelectedPrefixPaths` field retains the checked outer core, the attached checked cache and EVERY successful row of the actual parked raw list. It is not restricted to emitted outputs or candidate membership.

The original Packet and checked mass derivations are retained from the old proof. Native uses the original narrow seed. Prepared uses the original prepared seed. Each then uses the same `afterHead` seed and `massCeil` value as its old proof. Original Fits and known-heap gates grow along exactly those old inclusions. The smaller reservation is the same `reserved.first.2`.

`first_le_final` supplies the exact inclusion from the smaller final forecast at the parked seed and mass into the original final forecast at depth n+1. Its second field transports the new ProjectionPaths input to the concrete smaller IH. A carrier recomputed from a future heap is not used.

## Bound alignment and returned decision

In the stuck branch, the bound remains `prefixFuel`. The actual restart raw list is empty. The outcome remains the original empty complete outcome and the resource result remains unconditional. The added Resume predicate retains the actual selected-prefix paths and has no smaller recursive call in this branch. The smaller path IH is not invoked.

In the continuing branch, let R be the bound returned by the old smaller resource premise, C the bound returned by the smaller path IH, and F the original prefix fuel. The common bound is `F + R + C`. At extra e:

| Operation | Supplied extra | Actual work |
| --- | --- | --- |
| Original stable prefix phase | R+C+e | F+R+C+e |
| Smaller resource stability | F+C+e | R+(F+C+e) |
| Smaller execution IH | F+R+e | C+(F+R+e) |

The draft proves the required arithmetic equalities with omega. All three calls therefore use the same work. The resource outcome witness is still the one returned by the old smaller `Complete` premise. The old OutcomeResources value is retained and enlarged by the same original final-forecast inclusion.

`Restart.run_exact` supplies the actual singleton returned row when the decision is not stuck. That row contains the actual metadata, the actual returned `Restart.decision stop order metadata checked`, and `checked.core`. The selected-prefix Resume clause uses that RETURNED decision. Its recursive input is the literal frame of the returned core and the checked cache. The old proof's exact identity `frame checked.core checked = checked` relates this input to the smaller IH. The draft does not substitute the original before cache or assume a future frame.

The smaller execution predicate supplies its actual outcome paths. Since its depth is arbitrary, the proof splits zero and successor only when selecting the outcome field of Resume. This handles the different conjunction shapes at zero depth. It does not assert that zero depth succeeds without exhaustion.

## Source scope and provenance

Exactly two new old whole bodies were approved and read:

- `SourcePruningEnumerationFiniteParkedResources.lean`, complete 117 lines, 8290 bytes, SHA256 `4083b76dc4180f5d9f42d7a410908e225559ec4407ae6dd37233737038f90395`.
- `SourcePruningEnumerationPreparedFiniteParkedResources.lean`, complete 118 lines, 8423 bytes, SHA256 `88454d3834efe8c1b9a4af0943392fada54670eeaaa2630222c3f855d8425b7b`.

The full ExecutionPaths and ExecutionPathData copies were reused from the frozen receipt-review bundle only after their complete current bytes and hashes matched the frozen pins. The installed ReceiptBridge is an explicitly approved fresh Root-output reuse. Its complete current bytes match Root's strict snapshot at SHA256 `94a97a311d304ac5b3a143ee3a8ddd477b3e0b61070bee8904a4dbb89769245d`.

Other old reads are bounded named cuts for the actual selected-prefix path header, SelectedPrefixPaths, restart paths, StatePaths, ProjectionPaths and their namespace/notation context. Declaration-line navigation is recorded separately, including the unused PrefixPaths navigation. No third old whole or near-whole body was reconstructed. `source-unions.json` includes navigation lines in the aggregate old-source unions. It counts every union at or above 80 percent as near-whole. The count is two.

`acquisitions.json` records each complete source identity, copy identity, requested and actual range, EOF status, and reuse classification. Frozen full reuse and fresh Root output are labelled as whole reuse, not partial reads. Final identity validation checks every source and copy again. This bundle does not run a compiler to validate the drafts.

The memory registry was used only to orient the distinction between an internal execution IH and a closed original-input theorem. Current theorem claims and exact interfaces come from the pinned current source. No publication or current repository state was inferred from memory.

## Versions and corrections

The first text-generator attempt failed with a Python SyntaxError before it wrote the generator or a Lean draft. The corrected generator then produced immutable V1. This was a text-generation failure, not a Lean or runtime failure.

The owner read all 421 lines of V1 in two uncapped cuts. That review found that two proof-local outcome type annotations omitted P on NativeFailurePaths and PreparedFailurePaths. Immutable V2 changes only those two applications. Its public headers are unchanged. The full V2 was reviewed through the complete V1 plus the exact two-line diff. Both versions remain in this bundle.

Root owns any compiler results, subsequent mechanical repairs and production installation. If matching Root evidence arrives before this bundle is sealed, the evidence is saved separately and identified in `VALIDATION.json`. An owner `.UNCOMPILED` filename remains a historical source-only artifact even if Root later checks a matching input.

No Haskell source was read or changed. No Haskell fix or runtime defect was found for FINDINGS. The full objective still includes both distinct workers, global recursive coverage, the public contract and Haskell correspondence.

## Remaining proof work

These paired parked companions consume the same concrete smaller-depth execution IH as ReceiptBridge. The positive-depth whole-worker induction must discharge that IH for every actual smaller call. Its sibling, head, opaque and ordinary/prepared entry branches must retain their complete old resource contracts and the same original predicate. These local parked laws do not replace those branches.

The old stable parked phase and resource premises remain explicit internal inputs. The full original-input theorem must obtain them from the actual selected execution and finite reservations. Sufficient original recursive depth through every earlier alternative remains a separate control proof. No termination or nonstarvation result for the whole potentially infinite enumeration is claimed.

The final seal records the exact payload set and measured write halt. Do not change this directory after it is sealed.
