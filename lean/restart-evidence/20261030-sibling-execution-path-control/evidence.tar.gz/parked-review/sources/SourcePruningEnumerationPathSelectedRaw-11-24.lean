namespace MicroCFTA.SourcePruningEnumerationPathSelectedRaw
open EnumerationState EnumerationCorrectness EnumerationSchedule InternedConstructorTemplates
open SourcePruningEnumerationNodes
open SourcePruningEnumerationPathTransport SourcePruningEnumerationPathStorage
local notation "Symbol" => SourcePruningTemplates.Symbol

local instance rawMonadList : Monad List where
  pure value := [value]
  bind values continuation := values.flatMap continuation

/-- Every successful row retains the supplied stored path predicate. -/
def RawPaths {Guard α : Type} (P : EqualityTrie.Path → Prop)
    (raw : List (Except EnumerationState.Error (α × EnumerationState.State Symbol Guard))) : Prop :=
  ∀ result after, Except.ok (result, after) ∈ raw → StatePaths P after
