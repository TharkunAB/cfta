import MicroCFTA.SourcePruningEnumerationCachedOwn
import MicroCFTA.SourcePruningEnumerationPreparedHeadAdmission

/-!
# Model-free transport of stored paths

The predicate applies to every represented path in a pending bucket.
Child descent needs only closure under deletion of a leading index.
The statements do not require a satisfying term or trie validity.
-/
namespace MicroCFTA.SourcePruningEnumerationPathTransport
open EnumerationState EnumerationSchedule

/-- Every represented path in the bucket satisfies the predicate. -/
