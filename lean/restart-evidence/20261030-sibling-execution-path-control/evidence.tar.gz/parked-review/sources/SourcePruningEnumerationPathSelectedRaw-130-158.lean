def SelectedPrefixPaths {Typing : Type} {width : Nat} (P : EqualityTrie.Path → Prop) :
    SourcePruningEnumerationSelectedStep.Result width Typing → Prop
  | .stopped read checked =>
      RawPaths P read ∧ ∀ rows, checked = some rows → RawPaths P rows
  | .parked checked candidate raw =>
      StatePaths P checked ∧
      (∀ after, candidate = some after → StatePaths P after.core) ∧
      ∀ rows, raw = some rows → RawPaths P rows
  | .narrowed checked _ _ _ action candidate right ordinary =>
      StatePaths P checked ∧
      (∀ rows, action = some rows → RawPaths P rows) ∧
      (∀ after, candidate = some after → StatePaths P after.core) ∧
      (∀ rows, right = some rows → RawPaths P rows) ∧ ordinary = none

/-- Restart keeps the supplied input core in every actual successful row. -/
theorem restart_paths {Typing : Type} {P : EqualityTrie.Path → Prop}
    (stop : Option (SourcePruningRecordTypes.Metadata Typing → Nat → Bool))
    (order : SourcePruningRecordTypes.Metadata Typing → List Nat → Option Nat)
    (metadata : SourcePruningRecordTypes.Metadata Typing)
    (cached : EnumerationExpandableIndex.Cached Symbol (SourceSymbolicIndex.Constraint FullSyntax.Formula))
    (before : EnumerationState.State Symbol (SourceSymbolicIndex.Constraint FullSyntax.Formula))
    (paths : StatePaths P before) :
    RawPaths P (ExceptT.run (SourcePruningEnumerationRestart.run stop order metadata cached before)) := by
  intro result after member
  by_cases stuck : SourcePruningEnumerationRestart.decision stop order metadata cached = some .stuck
  · simp only [SourcePruningEnumerationRestart.run, ite_eq_left stuck, ExceptT.run, List.not_mem_nil] at member
  · simp only [SourcePruningEnumerationRestart.run, ite_eq_right stuck, ExceptT.run,
      List.mem_singleton, Except.ok.injEq, Prod.mk.injEq] at member
    obtain ⟨_result, rfl⟩ := member
