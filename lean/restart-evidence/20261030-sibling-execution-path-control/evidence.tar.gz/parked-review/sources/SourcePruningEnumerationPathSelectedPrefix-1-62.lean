import MicroCFTA.SourcePruningEnumerationPathSelectedRaw

/-!
# Paths in all selected-prefix observations

Every retained core and every successful raw row keeps the supplied path
predicate. It does not assume a singleton result,
native completion, a model, a resource packet or a future continuation.
-/
namespace MicroCFTA.SourcePruningEnumerationPathSelectedPrefix
open EnumerationState EnumerationCorrectness EnumerationSchedule InternedConstructorTemplates
open SourcePruningEnumerationNodes
open SourcePruningEnumerationPathTransport SourcePruningEnumerationPathSelectedRaw
local notation "Symbol" => SourcePruningTemplates.Symbol

/-- Every actual selected prefix preserves paths in all retained cores and raw rows. -/
theorem runPrefix_paths {Typing Key : Type} {width : Nat}
    [DecidableEq (EdgeKey Symbol (SourceSymbolicIndex.Constraint FullSyntax.Formula))]
    {P : EqualityTrie.Path → Prop}
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool)
    (admits : Key → Value Symbol (SourceSymbolicIndex.Constraint FullSyntax.Formula) → Bool)
    (graph : Graph Symbol (SourceSymbolicIndex.Constraint FullSyntax.Formula))
    (templates : List (Template.Pattern Symbol))
    (stop : Option (SourcePruningRecordTypes.Metadata Typing → Nat → Bool))
    (order : SourcePruningRecordTypes.Metadata Typing → List Nat → Option Nat)
    (metadata : SourcePruningRecordTypes.Metadata Typing)
    (readFuel checkFuel nativeFuel representativeFuel indexFuel callbackFuel uv : Nat)
    (caller : SourceCurrentAllocatedPartialState.State width)
    (before : EnumerationExpandableIndex.Cached Symbol (SourceSymbolicIndex.Constraint FullSyntax.Formula))
    (queries : SourceEndpointMemo.Memos) (paths : StatePaths P before.core) :
    SelectedPrefixPaths P (SourcePruningEnumerationSelectedStep.runPrefix
      holeKey fits admits graph templates stop order metadata readFuel checkFuel nativeFuel
      representativeFuel indexFuel callbackFuel uv caller before queries) := by
  unfold SourcePruningEnumerationSelectedStep.runPrefix
  generalize readEq : ExceptT.run (getValue readFuel uv before.core) = read
  have readPaths : RawPaths P read := by
    intro value after member
    exact (getValue_paths readFuel uv before.core after value paths (by
      change Except.ok (value, after) ∈ ExceptT.run (getValue readFuel uv before.core)
      simpa only [readEq] using member)).1
  cases read with
  | nil => simpa [SelectedPrefixPaths] using readPaths
  | cons first rest =>
      cases first with
      | error error => simpa [SelectedPrefixPaths] using readPaths
      | ok pair =>
          rcases pair with ⟨value, readAfter⟩
          cases value with
          | eliminated => simpa [SelectedPrefixPaths] using readPaths
          | enumerated fragment => simpa [SelectedPrefixPaths] using readPaths
          | unenumerated handle scs =>
              cases handle with
              | none => simpa [SelectedPrefixPaths] using readPaths
              | some oldHandle =>
                  cases rest with
                  | cons second tail => simpa [SelectedPrefixPaths] using readPaths
                  | nil =>
                      have reading : Success (getValue readFuel uv) before.core
                          (.unenumerated (some oldHandle) scs) readAfter := by
                        change Except.ok _ ∈ ExceptT.run (getValue readFuel uv before.core)
                        rw [readEq]
                        exact List.mem_cons_self
