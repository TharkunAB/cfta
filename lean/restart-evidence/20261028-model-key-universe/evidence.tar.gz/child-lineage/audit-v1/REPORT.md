[2026-10-28 23:16:11 CET] Actual child and traversal historical-key carrier preservation.

Seven additive candidate modules are frozen. All are SOURCE-ONLY candidates.
Root owns all compiler, strict-linter, Audit and repository evidence. No local
compiler/evaluator was run. Exact source identities and twelve complete public
statements are preserved in source-manifest.json and signatures/.

Public interfaces

TerminalPrefix.run_key_ancestry retains the carrier through the actual
successful prefix at fixed bounds. It uses Success, representative_success,
unionVariables_success and actual mapM/forM invariants. It requires neither
Total nor Safe, because only the complete nonforest fields are relevant.

CachedPrepare.rows_key_ancestry handles every member of an actual some rows.
cache_key_ancestry handles its actual attached candidate, including Empty
rejection. Ordinary nodes use installed prepareOrdinary_key_ancestry; Mu/Union
use actual allocate_key_ancestry. Reference/unsupported rows have no candidate.

CachedAdapter.run_key_ancestry returns the exact successful-singleton property
and every attached-cache property. It obtains the raw singleton certificate
from the literal actual dispatch and the peer's dispatch_key_ancestry. Private
adapter helpers merely identify that raw core or the old rejected cache.
They do not expose a future or arbitrary child-property input to the producer.

Fold.run_key_ancestry covers the actual OUTER core for every result tag at the
same fixed bounds. CachedFold.candidate_key_ancestry covers every attached
cache. The induction follows actual singleton actions; raw empty/failed/multiple
rows keep the appropriate actual prefix. All caller/query observations stay
in the literal equations. No later state is substituted.

CachedTerminalAdapter.candidate_key_ancestry composes the concrete prefix,
fold and incoming observers. A raw Empty rejection retains the actual fold
cache. A successful fold aligns its raw singleton with the exact outer core
using the existing singleton_core theorem. The actual incoming adapter then
supplies the final candidate, including synthetic Empty writes. Missing cache,
outer error and unsupported rows expose no after cache and are excluded by
the literal Some-cache observation, not by an added hypothesis.

ChildDispatch.observed_cache_key_ancestry covers the actual empty rejection,
ordinary preparation, opaque allocation and terminal route. Its premise is only
the original KeyAncestry plus (actual run ...).2 = some after. It does not
restrict the raw result tag, native value, input bucket or caller resources.
successful_key_ancestry is its literal singleton specialization.

ChildTraversal.trace_key_ancestry composes the actual completed child trace.
complete_key_ancestry bounded completed and stopped_key_ancestry bounded stopped
have all other indexed data implicit. The stopped theorem takes the actual
Result.stopped completedPrefix observation (some after), with an unrestricted
observation. stopped_trace recovers the exact completed-prefix state and next
child call; no resource or model property at that later state is supplied.

Original assumptions and scope

KeyAncestry is the installed all-slot invariant: every recursionAncestry key,
INCLUDING slots beyond counter, and every expansionAncestry key has its whole
tries component in one fixed carrier. Fresh allocation can retain stale keys
at counter, so reducing this premise to allocated slots would be unsound.
The carrier here is arbitrary and fixed. These downstream operations only
retain or combine keys. Entry is the separate modeled insertion point.

No Satisfies/Origins/Canonical, ProperState, input-trie validity, Context,
FITS/Reserved, future heap/model/output, native-success existence or arbitrary
child-property supplier is added to these preservation observers. The only
other hypotheses are the existing primitive typeclasses and literal runtime
observations. They do not add new model-relative key shape derivations.

The source/prepared parent distinction is preserved because no parent identity
cast appears in this chain. Root's selected/captured/prepared receipt composition
must consume these exact actual observations at the caller it already owns.

The candidates do not bound native handles, count distinct whole native keys,
prove all historical keys fit a carrier without an initial invariant, establish
uniform global depth, prove global search termination, or infer Discharged.
They make no Haskell defect claim and edit no Haskell source.

Frozen candidate identities

SourcePruningEnumerationCachedPrepareKeyAncestry.lean: 81 lines, 4060 bytes; SHA256 bff214db0532a67cb4c55655d7997b53b85aed6c82d65f53fc7017a7ada84ae7
SourcePruningEnumerationTerminalPrefixKeyAncestry.lean: 47 lines, 2430 bytes; SHA256 4a26920607283fdffea1806ea69c7a619a65c9afe7344af39601aed33284fa58
SourcePruningEnumerationCachedAdapterKeyAncestry.lean: 113 lines, 5855 bytes; SHA256 2393fed75a61d0520513ab11e3368d8b15f271cf029663e11547b6f276b8ec8e
SourcePruningEnumerationFoldKeyAncestry.lean: 145 lines, 7613 bytes; SHA256 336c0f66c2206a3505fc61d033a3c8c54c1e48ea7eada3bf0c2b2af9faa22bec
SourcePruningEnumerationChildKeyAncestry.lean: 72 lines, 3914 bytes; SHA256 b495d556dd3d6a1855a80917dbe5af2d3b3d5845c26993e0e915c8c2b66f871d
SourcePruningEnumerationTerminalKeyAncestry.lean: 111 lines, 6139 bytes; SHA256 fab29868369f0d08656b63ad396d89822f0c99f7bee98fc2ed45e966331131ce
SourcePruningEnumerationTraversalKeyAncestry.lean: 62 lines, 3667 bytes; SHA256 291c2fb169d486302dbacfb07c2fe69351ab826ce2b64d10d9f593315a4f841a

Only this new owned child-lineage area was written. The earlier shapes and
head/model reports remain immutable. Source snapshots distinguish whole reads
from literal cuts. Some exploratory outputs were truncated and are not promoted
to whole-read evidence. Parent compiler evidence can be recorded separately;
these historical candidate status labels remain unchanged.
