# Incoming ancestry preservation candidate

Date: 2026-10-28, Europe/Stockholm.
Status: UNTESTED source candidate. Root owns compilation and integration.
No repository, compiler, evaluator, native, Git, network or board action ran.
No Haskell source changed. No Haskell defect or fix was established.

## Delivered module

`SourcePruningEnumerationIncomingKeyAncestry.lean` has 195 lines and 9,427 bytes.
SHA256: `0736f503c0515375724652fff43aa62aee120e8f7482f13106ae8f98f2328d46`.
It has two public theorems and four private concrete case helpers.
It adds no runtime definition or assumed preservation family.

The exact public helper calls are:

    IncomingNode.run_key_ancestry
      checkEmpty r n p h caller before target incoming incomingScs queries bounded

    IncomingCacheAdapter.observed_cache_key_ancestry
      checkEmpty r n p h k caller before target incoming incomingScs queries bounded after candidate

The carrier is implicit. Runtime typeclass and width indices remain implicit.
The public state uses the actual enumeration Constraint type, as in IncomingProper.

The first theorem gives ancestry at the exact outer read core of the literal
IncomingNode result. It also gives ancestry at any actual successful singleton
row core. It covers every fixed runtime bound. The second theorem takes only
the original cached core's ancestry property and the literal SOME cache
observation. It derives ancestry at that actual attached cache.

The second conclusion includes the adapter's raw-empty synthetic write.
It does not require a successful singleton, Safe, resource admission, a model,
future caller/cache property or an emitted output history.

## Concrete proof route

`IncomingNode.run` can change native callers, but its outer enumeration core
is either the original core or its actual representative-read core. That read
changes only representatives. It keeps both ancestry fields definitionally.
The first theorem follows the checked IncomingProper run-case proof pattern.
It examines the actual native result and optional emptiness-check branches.

The concrete `finish` action writes the incoming bucket, then calls
`inheritAncestry`. Its target ancestry becomes the duplicate-free union of
the old expansion ancestry and the old target ancestry. All other slot lists
and the expansion list retain their old keys. The private write proof uses
those exact two membership sources. It needs the original invariant at every
slot, including slots beyond the allocation counter, as KeyAncestry specifies.

The private singleton proof reduces `finish` at its actual replacement value.
Empty returns no rows. Every other replacement returns the exact written core.
The native result cases then identify any actual singleton with that core.

For raw-empty adaptation, `IncomingCacheAdapter.adapt` constructs the same
ancestry union at the target and frames its native-index result with that
explicit core. The proof follows this literal record update. It does not
assume an unrelated write preserves history. For a singleton, the existing
`adapt_singleton_core` identifies the attached core with the actual row core.
Every other raw shape produces no candidate.

The private adapter case helper has a predicate for singleton members of its
one actual raw list. The public observer discharges that predicate from the
concrete IncomingNode theorem in this same module. No such family remains
in either public statement. It is not a premise about future dispatches.

## Scope for terminal composition

The announced interfaces were sent to opaque_meaning. They can feed the
actual terminal fold and ChildDispatch ancestry proofs. The node theorem
provides both outer read and actual singleton facts. The cache theorem
provides the attached cache directly, including a rejected Empty action.

The outer-read conclusion concerns enumeration ancestry only. It makes no
claim that an arbitrary native-error caller has a semantic/resource invariant.
The cache conclusion does not claim Safe on rejection.

KeyAncestry bounds whole trie-list shapes of historical keys. These results
do not bound their native handle field, establish new-key insertion policy,
construct an output or prove sufficient recursive depth. The separate native
factor audit retains those boundaries.

## Read scope and preservation

The manifest records six WHOLE proof sources: 39,562 bytes and 739 lines.
Three exact runtime/definition cuts retain 13,652 bytes and 230 lines.
Each literal cut retains its whole-source hash without a whole-read claim.
The exact input copies and cut hashes were checked against the current source.
The candidate was read back whole. It remains uncompiled by this author.

The initial path guesses IncomingNodeProper and IncomingCacheProper were
absent. The actual combined source is IncomingProper, which was read whole.
An aggregate read also produced a truncation warning. Separate reads recovered
KeyAncestry and Storage whole and the incoming runtime/observer definitions
as exact cuts. No claim relies on truncated completion-producer output.

The memory registry supplied only the restart-boundary convention.
All technical claims use the copied current sources. Previous task evidence
and source files remain unchanged. This candidate version and report are
frozen after delivery.
