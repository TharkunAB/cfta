[2026-10-28 22:56:10 CET] Explicit finite carrier of current actual recursion-key trie shapes.

Candidate: /tmp/mcfta-model-key-universe-20261028/shapes/candidate-v1/MicroCFTA/SourcePruningEnumerationModelKeyShapes.lean
SHA256 229447834d6c24678c12af267d0d24a76e4853c6685ddcded98ccc95e11d86e8; 2425 bytes; 47 lines.
Status: SOURCE-ONLY CANDIDATE; UNTESTED. Root owns actual checks.
All old source files and previous evidence remain unchanged.

The module adds two pure finite-list definitions and one theorem. It imports
checked ModelPathDomain. It reuses the existing generic list enumeration from
SourceEqualityConstraintPathInventory and generic duplicate elimination from
SymbolicSelection. It defines no new enumerator or generic helper.

Let P = ModelPathDomain.relativePaths whole and D = P.length.
trieShapes whole = PathInventory.lists P D.
keyShapes whole = PathInventory.lists (trieShapes whole) (trieShapes whole).length.
Both are explicit finite lists determined only by the original finite whole
term. The lists are conservative carriers. They may include duplicates and
shapes that no valid sorted source key can produce. No evaluation is needed.

The exact exported theorem is ModelKeyShapes.stored_recursion_key_mem, within
namespace MicroCFTA.SourcePruningEnumerationModelKeyShapes. Explicit premises,
in order: language, meaning, state, whole, assignment, satisfied, origins,
canonical, inside, stored. Symbol/Guard and uv/handle/scs are implicit.
The last five proof premises are exactly:
  Satisfies language meaning assignment state;
  AssignmentOrigins whole state.counter assignment;
  Canonical state;
  uv < state.counter;
  state.values[uv]? = some (.unenumerated (some handle) scs).
It concludes:
  (EnumerationState.recursionKey handle scs).tries belongs to keyShapes whole.
A separate complete signature file preserves the exact Lean statement.

Proof route

1. Checked stored_recursion_key_paths gives membership in P and length <= D
for every path list of the ACTUAL stored key. PathInventory.mem_lists places
each such trie in trieShapes whole.
2. The ACTUAL outer key trie-list is a mergeSort of eraseDups of the mapped
stored bucket. Generic SymbolicDriver.eraseDups_nodup and mergeSort_perm derive
its Nodup. No caller-supplied distinctness or future-key certificate is used.
3. Nodup.length_le_of_subset bounds the actual outer list length by the finite
trieShapes whole list length. A second mem_lists gives keyShapes membership.
The proof needs no Ascending, native readback, future heap or model extension.

Why reuse this utility

EqualityTermination.words has the correct length<=bound enumeration shape, but
its alphabet is List Nat. PathInventory.lists and mem_lists already generalize
that exact construction to any Type. SourceCurrentConjunctionTupleBounds.words
is specialized to guards and exact lengths. No duplication is needed.
The generic Nodup lemma is also already public in SymbolicSelection; the
similarly named EqualityTrie lemma applies only to List Nat.

Scope

The conclusion concerns the trie-list COMPONENT of the actual recursion key
at one stored original model point. The numeric native handle is unrestricted.
There is no claim that arbitrary attached recursionAncestry/expansionAncestry
keys satisfy the carrier, no finite native-handle factor, no bound on callbacks
or global depth, and no termination claim. The sibling ancestry task may use
this point membership for actual Entry insertion, then prove all-slot transport.
Its all-slot premise is distinct from the allocated-prefix model/origin premise.

The candidate, three full public declarations, relevant whole-source snapshots,
literal source/stdlib cuts and SHA256 identities are preserved in audit-v1.
No Haskell behavior or defect is claimed. No repository source was edited.
