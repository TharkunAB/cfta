# Raw dispatch historical key-shape preservation

Timestamp: 2026-10-28 23:11:44 CET.
Status: UNTESTED source candidate. The author ran no compiler, evaluator, native execution, Git, network, or board command. Root owns installation and verification.

## Candidate

`/tmp/mcfta-model-key-universe-20261028/dispatch-lineage/candidate-v1/MicroCFTA/SourcePruningEnumerationDispatchKeyAncestry.lean`

40 lines; 2181 bytes; SHA256 `db0689d1d1efa693414e2b10aed916739cba0a2dd280a5f93d10b5741a5f93f0`.

Public theorem: `SourcePruningEnumerationDispatch.dispatch_key_ancestry`.

The theorem retains the announced `dispatch_proper` argument order. It adds the implicit whole-shape carrier and the explicit original `bounded` premise. It keeps the literal `selected` dispatch endpoint and the literal `completed` singleton action result. The conclusion is `KeyAncestry carrier after` for the actual returned core.

## Proof and exact scope

The existing `DispatchShape.singleton` theorem classifies that same selected action and completed singleton. The returned core equals the original core, or it equals the exact `assimilated before target source ...` update. The candidate uses this classifier once. The first case uses the original invariant. The second case uses `bounded.assimilated target source ...`.

`KeyAncestry` covers both `recursionAncestry` and `expansionAncestry`. Its recursion condition covers every slot, including slots beyond the current counter. The theorem retains the same finite whole-tries shape carrier. It does not bound `key.node`.

The selected action, reached caller, and saved queries stay bound to the exact original dispatch observation. The theorem adds no new native relation. It needs no `Context`, `Satisfies`, `Origins`, `Canonical`, heap invariant, slot readiness, key-domain supplier, or preservation supplier. It proves no execution existence or completion bound. It makes no claim about absent actions, outer errors, empty raw results, or nonsingleton raw rows. The cache adapter has separate branches for those cases.

No new runtime definition, broad history contract, or source/prepared identity cast is present. The proof reuses the existing actual dispatcher classifier. It does not repeat the native query and optional Empty-check branch analysis.

## Integration

`opaque_meaning` requested this exact singleton interface for the actual CachedAdapter/Fold chain. The import is `MicroCFTA.SourcePruningEnumerationDispatchKeyAncestry`. The theorem call is:

`dispatch_key_ancestry checkEmpty nativeFuel p h beforeCaller before source target queries action afterCaller savedQueries after bounded selected completed`.

Root reported the exact base `KeyAncestry` source default PASS. Root also reported Storage, Assimilation, and OwnFinalize default PASS. These status reports are external observations. They are not verification of this new candidate.

The original-model insertion theorem is still the source of new whole-shape membership at actual entry. This raw dispatch observer only transports the original carrier through exact existing history updates. It does not claim a closed whole-history model-lineage result or sufficient recursive depth.

## Evidence

`MANIFEST.json` records the immutable candidate identity, complete copied dependency source identities, exact literal read cuts, and source equality at seal. `DispatchShape` and `KeyAncestry` were read whole. The exact actual dispatcher definitions were read at lines 1–105. Prior focused source reads supplied the old Proper, storage, assimilation, and consumer scopes shown in the manifest. No claim is made that the rest of the copied dispatcher or fold source was read in this bounded task.

Candidate and report are frozen. No Haskell source changed and no Haskell finding arose.
