"""Verify current identities and make the complete proof area immutable."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

ROOT = Path('/home/tritlo/Code/mcfta')
AREA = Path('/tmp/mcfta-model-key-universe-20261028')
def sha(data):
    return hashlib.sha256(data).hexdigest()

for name in ['prior-lean-sources.json', 'prior-strong-sources.json',
             'inherited-prior-haskell-sources.json', 'final-proof-sources.json',
             'final-documents.json']:
    for record in json.loads((AREA / name).read_text()):
        data = (ROOT / record['path']).read_bytes()
        assert sha(data) == record['sha256'], record['path']
        if 'bytes' in record:
            assert len(data) == record['bytes'], record['path']
for record in json.loads((AREA / 'prior-documents.json').read_text()):
    old = (AREA / 'prior-document-bodies' / record['path']).read_bytes()
    assert (len(old), sha(old)) == (record['bytes'], record['sha256'])
    assert (ROOT / record['path']).read_bytes().endswith(old)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == json.loads((AREA / 'docs-commit.json').read_text())['head']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
subprocess.run(['git', 'merge-base', '--is-ancestor', 'origin/main', 'HEAD'], cwd=ROOT, check=True)
upstream = dict(main=subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=ROOT, text=True).strip(),
    head=head, main_is_ancestor=True)
(AREA / 'upstream-state.json').write_text(json.dumps(upstream, indent=2) + '\n')
assert json.loads((AREA / 'root-progress-final.json').read_text())['goal']['status'] == 'active'
assert json.loads((AREA / 'root-progress-final.json').read_text())['full_objective_complete'] is False
payloads = []
for path in sorted(AREA.rglob('*')):
    assert not path.is_symlink(), path
    if path.is_file():
        data = path.read_bytes()
        payloads.append(dict(path=str(path.relative_to(AREA)), bytes=len(data), sha256=sha(data)))
seal = dict(write_halt=True, time=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_head=json.loads((AREA / 'source-head.json').read_text())['head'], docs_head=head,
    full_goal='active', payloads=payloads)
(AREA / 'FROZEN.json').write_text(json.dumps(seal, indent=2) + '\n')
for path in AREA.rglob('*'):
    os.chmod(path, 0o555 if path.is_dir() else 0o444)
os.chmod(AREA, 0o555)
print(json.dumps(dict(write_halt=True, payloads=len(payloads),
    bytes=sum(record['bytes'] for record in payloads), source_head=seal['source_head'], docs_head=head)))
