from pathlib import Path
import json, hashlib
OWN=Path('/tmp/mcfta-prepared-origins-20261028/child-origins')
AREA=OWN.parent
REPO=Path('/home/tritlo/Code/mcfta')
def digest(b): return hashlib.sha256(b).hexdigest()
def save(rel,b):
 p=OWN/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return {'path':str(rel),'bytes':len(b),'sha256':digest(b)}
def cp(src,rel): return save(rel,Path(src).read_bytes())
def js(rel,v): return save(rel,(json.dumps(v,indent=2)+'\n').encode())
index=json.loads((OWN/'source-index.json').read_text())
def source(path,ranges,scope,copy_rel=None):
 p=Path(path);data=p.read_bytes();lines=data.splitlines(keepends=True)
 rec={'source':str(p),'whole':cp(p,copy_rel or 'sources/'+p.name),'cuts':[],'inspected_scope':scope}
 for first,last in ranges:
  assert 1<=first<=last<=len(lines)
  rec['cuts'].append(dict(save('cuts/'+p.stem+f'.L{first}-{last}.txt',b''.join(lines[first-1:last])),first_line=first,last_line=last))
 existing=next((i for i,x in enumerate(index['sources']) if x['source']==str(p)),None)
 if existing is None:index['sources'].append(rec)
 else:index['sources'][existing]=rec
 return rec
source(REPO/'lean/MicroCFTA/SourcePruningEnumerationPreparedOpaqueOrigins.lean',[(66,154),(155,248)],'whole final installed source; exact to reviewed root draft and passing strict snapshot')
source(REPO/'lean/MicroCFTA/SourcePruningEnumerationPreparedRecursive.lean',[(42,68),(75,116)],'whole runtime; stop audit only')
source(REPO/'lean/MicroCFTA/SourcePruningEnumerationNativeContinuations.lean',[(43,72),(107,116)],'whole runtime; actual stopped-hook suffix omission and completed-prefix outputs')
source(REPO/'lean/MicroCFTA/SourcePruningEnumerationRecursion.lean',[(16,29),(31,65)],'lines 1-90 inspected; actual recursion-key parking operation and producer contract only')
source(REPO/'lean/MicroCFTA/SourcePruningEnumerationNativeIndex.lean',[(16,27)],'candidate definition reviewed for audit; larger source retained for provenance')
source(REPO/'lean/MicroCFTA/EnumerationState.lean',[(55,64)],'recursion-key definition only; equality-variable identities are omitted')
source(REPO/'lean/MicroCFTA/SourcePruningEnumerationSelectedContinuations.lean',[(35,62)],'whole runtime read; actual prepared ordinary route enters the hook-aware scan')
for name in ['source-validation.json','public-validation.json','public-read-scopes.json','strict-checks.json','audit-summary.json','modules.json','source-head.txt','validation-attempts.md','document-inverse.json']:
 cp(AREA/name,'evidence/'+name)
validation=json.loads((AREA/'source-validation.json').read_text())
commands=[]
for entry in validation['commands']:
 d=AREA/entry['folder'];report=json.loads((d/'report.json').read_text());raw=(d/'raw.log').read_bytes()
 assert report['bytes']==len(raw)==entry['bytes'] and report['sha256']==digest(raw)==entry['sha256']
 assert report['exit_code']==entry['exit_code']
 lim=report['cgroup_limits'];assert lim=={'memory.max':'4294967296','memory.high':'4294967296','memory.swap.max':'0'}
 for name in ['report.json','raw.log','inputs.json']:
  if (d/name).is_file():cp(d/name,'checks/'+entry['folder']+'/'+name)
 commands.append({'folder':entry['folder'],'inherited':entry['folder']=='prior-public-readback','exit_code':report['exit_code'],'bytes':len(raw),'sha256':digest(raw),'measured_limits':lim})
for folder,module in [('prepared-opaque-v1','SourcePruningEnumerationPreparedOpaqueOrigins'),('child-v1','SourcePruningEnumerationChildCoverageOrigins')]:
 snap=AREA/folder/'MicroCFTA'/f'{module}.lean';live=REPO/'lean/MicroCFTA'/f'{module}.lean'
 assert snap.read_bytes()==live.read_bytes()
 cp(snap,'checks/'+folder+'/MicroCFTA/'+snap.name)
for folder in ['origins-v1','origins-v2']:
 snap=AREA/folder/'MicroCFTA/SourcePruningEnumerationOrigins.lean'
 cp(snap,'checks/'+folder+'/MicroCFTA/'+snap.name)
js('evidence/command-review.json',{'status':'pass','current_commands':sum(not x['inherited'] for x in commands),'inherited_commands':sum(x['inherited'] for x in commands),'current_failures':sum(not x['inherited'] and x['exit_code']!=0 for x in commands),'commands':commands,'scope':'Validate existing recorded bytes, exit codes and measured limits; no commands rerun.'})
full=(AREA/'public-readback-final/raw.log').read_bytes();prior=(AREA/'prior-public-readback/raw.log').read_bytes();new=(AREA/'new-public-blocks.txt').read_bytes()
assert full==prior+new
assigned=[]
for rec in json.loads((AREA/'public-read-scopes.json').read_text()):
 if rec['owner']!='child-origins':continue
 b=(OWN/'public-blocks'/f"{rec['declaration']}.txt").read_bytes()
 assert b==new[rec['offset']:rec['offset']+rec['bytes']] and digest(b)==rec['sha256']
 assert b'Classical.choice' in b and b'Quot.sound' in b and b'propext' in b
 assigned.append(rec)
assert len(assigned)==3
js('evidence/public-review.json',{'status':'pass','whole_assigned_blocks_read':assigned,'whole_final_readback_captured':True,'whole_final_readback_read':False,'full_output_bytes':len(full),'full_output_sha256':digest(full),'prior_exact_prefix_bytes':len(prior),'new_appendix_bytes':len(new),'scope':'All three assigned complete blocks read. Other new public declarations are reviewed by their named owners.'})
for a,b in [('original-child-declaration.txt','recovered-child-declaration-v1.txt'),('root-opaque-original-resource-declaration.txt','root-opaque-recovered-resource-declaration-v1.txt')]:
 assert (OWN/'contracts'/a).read_bytes()==(OWN/'contracts'/b).read_bytes()
js('contracts/root-opaque-checked-final.json',{'status':'CLEAR','installed_source_sha256':digest((REPO/'lean/MicroCFTA/SourcePruningEnumerationPreparedOpaqueOrigins.lean').read_bytes()),'strict_receipt':'checks/prepared-opaque-v1/report.json','raw_bytes':0,'proof_repairs':[],'entire_original_finite_resource_declaration_bytes':5308,'entire_original_finite_resource_declaration_sha256':'4adcf89c095304928a6a5859b4a4f465bb4a655dd6121b9b07fd248383807816','scope':'Retains original finite resource packet. Does not duplicate separate older unrestricted semantic observer. Uses same actual finite receipt and new origin-aware model witness.'})
note=REPO/'lean/notes-current-prepared-origins.md'
source(note,[(1,len(note.read_bytes().splitlines()))],'whole final note read',copy_rel='documents/notes-current-prepared-origins.md')
for n in ['common.md','findings.md']:cp(AREA/'document-insertions'/n,'documents/insertions/'+n)
docs=[]
for rel,entry in json.loads((AREA/'document-inverse.json').read_text()).items():
 p=REPO/rel;cur=p.read_bytes();old=(AREA/'prior-documents'/rel).read_bytes();count=entry['inserted_bytes'];ins=cur[:count]
 template=(AREA/'document-insertions'/('findings.md' if rel=='FINDINGS.md' else 'common.md')).read_bytes()
 assert ins==template and cur[count:]==old
 assert digest(cur)==entry['after_sha256'] and digest(old)==entry['before_sha256']
 lines=cur.splitlines(keepends=True);nlines=len(ins.splitlines(keepends=True));assert b''.join(lines[:nlines])==ins
 cut=save('documents/cuts/'+rel.replace('/','__')+'.inserted.txt',ins)
 record={'source':str(p),'cuts':[dict(cut,first_line=1,last_line=nlines)],'inspected_scope':'exact new insertion only; whole old body equality checked by byte inverse, not read','whole_identity':{'bytes':len(cur),'sha256':digest(cur)}}
 index['sources'].append(record)
 docs.append({'path':rel,'source':str(p),'whole_bytes':len(cur),'whole_sha256':digest(cur),'prior_bytes':len(old),'prior_sha256':digest(old),'inserted_bytes':count,'inserted_sha256':digest(ins),'exact_inverse':True,'read_scope':'new insertion only'})
js('documents/document-verification.json',{'status':'pass','whole_note_read':{'path':str(note),'bytes':note.stat().st_size,'sha256':digest(note.read_bytes())},'whole_common_and_findings_read':True,'nine_exact_insertions_verified':docs,'old_body_read_claim':False})
js('source-index.json',index)
for rec in index['sources']:
 data=Path(rec['source']).read_bytes();lines=data.splitlines(keepends=True)
 if 'whole' in rec:
  w=rec['whole'];assert (OWN/w['path']).read_bytes()==data and w['bytes']==len(data) and w['sha256']==digest(data)
 for c in rec['cuts']:
  b=b''.join(lines[c['first_line']-1:c['last_line']]);assert (OWN/c['path']).read_bytes()==b and len(b)==c['bytes'] and digest(b)==c['sha256']
print(json.dumps({'sources':len(index['sources']),'cuts':sum(len(x['cuts']) for x in index['sources']),'commands':len(commands),'current_commands':19,'inherited_commands':1,'assigned_public_blocks':len(assigned),'note_bytes':note.stat().st_size,'note_sha256':digest(note.read_bytes())},indent=2))
