from pathlib import Path
import hashlib,json
r=Path('/home/tritlo/Code/mcfta');a=Path('/tmp/mcfta-prepared-origins-20261028');head=(a/'source-head.txt').read_text().strip();pub=json.loads((a/'public-validation.json').read_text());src=json.loads((a/'source-validation.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
common=f'''
## Original subtree paths through prepared enumeration

Source checkpoint: {head}.
The existing finite-pruning language preservation and prepared finite resource
induction remain. New actual startup, equality allocation, child traversal,
selected-edge and prepared-head theorems construct a satisfying assignment
whose every allocated value has a path in the original complete term.
The same new model witness supplies the actual receipt and callback-entry cache.
Terminal work retains the counter. Opaque work adds one variable. Empty equality
classes use the current accepted term as a valid witness.

Original policies for all structural subtrees now supply the local forbidden
pattern and ProgramEncoding conditions at actual recording callbacks.
The actual recording frame retains variable origins and the same certified
restart outcome. Bounded pending refutation transports through old-ID agreement.
These are original syntax assumptions. Native acceptance does not imply them.
ProgramAt skips annotations, so root-only program policies are insufficient.

Whole-driver output soundness and original accepted-output coverage remain open.
The next proof must compose these model and origin witnesses through actual
recursive histories. It must establish sufficient depth for ALL earlier reachable
callbacks and accepting-row selector coverage. A chosen term's height does not
bound earlier alternatives. The existing earlier-stop alternative remains.
Public APIs, ranking, sampling and physical Haskell correspondence remain open.
Goal ACTIVE; checkpoint PROGRESS. No new Haskell defect or required fix was found.

Eight new modules add 22 public theorems and three definitions. All nine final
strict checks pass. Full Audit passes 4395 jobs and checks 80957 dependencies.
Public readback has 471 theorem blocks and 44 definitions. Its entire prior
1902411-byte readback remains an exact prefix. All 4386 prior non-Audit Lean,
235 strong and 810 Haskell source/evidence files retain bytes.
Details: `lean/notes-current-prepared-origins.md`.

'''
findings=common+'''### Haskell comparison and external integration handoff

No Haskell or Cabal file changed. No Haskell test or benchmark ran.
No new implementation defect or required Haskell repair was established.
Keep the integrated LPO and KBO Natural-weight fixes and their evidence below.
The new results request no Haskell patch.

Preserve one actual native preparation and the original stored handle.
Each branch keeps its captured metadata and cache. Actual Caller effects and
full Memos pass to the next sibling. The new origin proofs concern the SAME
actual receipt and callback-entry cache. They do not certify recursive outputs.

OriginPolicies quantifies over structural subtrees of the ORIGINAL complete
term. Each such subtree must satisfy Avoids and program-position ProgramEncoding.
ProgramAt does not inspect annotation or application-marker children. A native
accepted term or a root-only ProgramAt policy does not establish OriginPolicies.
This is a formal policy boundary. No annotation-related Haskell fault is proved.

The new origin-aware semantic observer uses one extension for all of its model,
fragment-fill and path conclusions. It does not assert that every arbitrary
witness of the older unconstrained existential observer has origins. An empty
equality class can admit unrelated witnesses. The new construction chooses an
original subtree and still satisfies that class. Operational witnesses are fixed
before the model observer. The complete older proofs remain unchanged.

Coverage audit: an actual stopped hook omits its remaining sibling suffix.
At recursive depth zero, an expand request produces exhausted with no outputs
at every work fuel. More work fuel cannot remove that depth stop. An unbounded
earlier branch would therefore obstruct a later accepting branch. No admitted
all-depth counterexample was established. The simple candidate A=f(A)|a is
insufficient: a fresh Mu child with no bucket is not expandable, and repeated
native recursion keys clear the bucket or park the work. A valid obstruction
must retain genuinely expandable unseen inputs. Do not report the candidate as
a Haskell defect or a proved failure. Prove earlier-callback termination or find
a complete original Context/Packet counterexample before strengthening coverage.

'''
(a/'document-insertions').mkdir(exist_ok=True)
(a/'document-insertions/common.md').write_text(common);(a/'document-insertions/findings.md').write_text(findings)
records={}
for p in sorted((a/'prior-documents').rglob('*.md')):
 rel=p.relative_to(a/'prior-documents');old=p.read_bytes();insertion=(findings if str(rel)=='FINDINGS.md' else common).encode();first,rest=old.split(b'\n',1);new=first+b'\n'+insertion+rest
 assert new.replace(insertion,b'',1)==old
 (r/rel).write_bytes(new);records[str(rel)]=dict(before_sha256=sha(old),after_sha256=sha(new),inserted_bytes=len(insertion))
(a/'document-inverse.json').write_text(json.dumps(records,indent=2)+'\n')
modules=json.loads((a/'modules.json').read_text())
note=f'''# Original subtree paths through prepared enumeration

Source checkpoint: {head}. Whole-CFTA goal ACTIVE. Checkpoint PROGRESS.
The three source commits are pushed to formalize. The evidence commit follows.

The strongest current combined claim is conditional finite-pruning language
preservation, genuine prepared finite-depth execution and resource closure,
and constructive preservation of original accepted models through actual
preparation, branch construction and permitted recording restarts. The new
branch models retain an original-term path for every allocated variable.
This is not whole-driver output soundness or accepted-output existence.

## Actual proof additions

Origin whole term means that some actual child-index path in whole returns term.
AssignmentOrigins checks every ID below the actual allocation counter.
The generic construction preserves old IDs, chooses equality witnesses with
original paths, and installs them at the exact consecutive fresh IDs. If a class
has no paths, the current original subtree is a valid witness. No validity or
nonempty-class premise is added. Origin also gives a term-height upper bound.

Literal startup uses the original accepted root model. Its counter is one.
Every allocated startup variable is therefore the original root variable.
The terminal child returns the same counter. The opaque child returns precisely
one fresh hole. Its fill equation fixes the fresh variable to the accepted
original subtree. The origin observer uses the SAME old child-model witness.

Actual ordered traversal combines the head extension and suffix extension.
It preserves earlier fills and all old IDs. The selected edge first allocates
its equality classes, then runs that traversal, then records its residual guard.
The new observer constructs ONE extension that satisfies every old semantic
conclusion AND every allocated origin. It uses the same already-fixed actual
operational result, caller, full memos and cache. The unrelated old existential
model observer is retained too. Its arbitrary witness need not have origins.

Prepared ordinary, opaque and terminal head laws consume these origin-aware
observers. A common adequate diagonal identifies the SAME actual finite receipt.
Finalization writes the original target and leaves the counter unchanged.
Every allocated variable at the actual callback-entry cache retains an original
path. The old complete resource packets remain. These two laws add origins to
their model observer; they do not duplicate the separate older unrestricted
semantic observer, whose original theorem remains unchanged and available.

OriginPolicies is an assumption on every structural subtree of the ORIGINAL
complete term. It requires template Avoids and ProgramEncoding at each inspected
program position there. ProgramAt skips annotations and markers. Root-only
program policies cannot be transported to arbitrary structural subtrees.
The new actual recording and finite callback corollaries derive their local
policies from a concrete origin. Recording retains pending refutation. The same
resource-certified recursive restart follows, and its actual frame preserves
AssignmentOrigins in both directions. A separate bounded raw-ID congruence law
transports original pending refutation through assignment extension.
Native acceptance supplies neither these syntax policies nor a future model.

New modules:
'''+''.join('- `MicroCFTA.'+m+'`\n' for m in modules)+f'''
## Remaining work

Compose actual model/origin witnesses through full prepared recursive histories,
including selected prefixes and all callback entries. Keep full old resource
packets, actual captures and both original and prepared handles. Derive original
sufficient depth and appropriate policies for ALL earlier reachable callbacks.
Do not assume the desired successful callback, output model or future origin.
Derive accepting-row selector coverage from an original selector law.
Whole-driver soundness, accepted-output coverage, public APIs, ranking, sampling
and physical Haskell correspondence remain open. Older constructor/equality
proofs and all prior counterexamples remain preserved.

A stopped ordered hook omits the sibling suffix. Recursive depth zero returns
exhausted for an expansion regardless of workFuel. The origin/height bound for
one chosen model does not prove that all earlier callbacks terminate. An
unbounded earlier branch is a possible obstruction, not an established admitted
counterexample. The simple A=f(A)|a proposal fails to establish that obstruction:
fresh empty-bucket Mu children are noncandidate, and repeated native keys clear
or park the bucket. Establish a real original Context/Packet example or prove
an appropriate termination condition. This is no proved Haskell defect.

## Validation and preservation

Eight modules add 22 public theorems and three definitions. Nineteen current
compiler/build/public commands ran; two failed. One inherited prior-public
receipt is retained separately. Nine final strict checks pass with warningAsError=true and linter.all=true. Full Audit passes
4395 jobs and checks 80957 theorem dependencies. No heartbeat or recursion limit
was raised. No linter was disabled. No sorry, admit, custom axiom or native_decide
occurs in new proof code. Each actual compiler/build/public command is serial
under measured memory.max=memory.high=4294967296 and memory.swap.max=0.

The public readback contains 471 complete theorem signatures and axiom checks,
plus 44 printed definitions. No elision occurs. Its prior 1902411 bytes are an
exact prefix. Full output: {pub['bytes']} bytes, SHA256 {pub['sha256']}.
The new 113252-byte appendix has SHA256 {pub['new_sha256']}.
Only propext, Classical.choice and Quot.sound occur in the axiom lists.

All 4386 prior non-Audit Lean, 235 strong and 810 tracked Haskell source/evidence
files retain their exact bytes. Audit adds imports before its complete prior
body. Nine status documents retain their full prior bodies after removal of
the recorded insertion. No Haskell or Cabal source changed. No Haskell test or
benchmark ran. No new required Haskell repair was established. FINDINGS records
the external integration boundaries and preserves the LPO/KBO repairs.

Two failed strict commands are retained in full. Origins-v1 used a variable
name removed by substitution and tried to simplify a recursive counter too
far. Origins-v2 exposed an overgeneralized local induction and nondefinitional
addition order. The final proof reuses the existing Schedule counter theorem.
No contract was weakened. All other first candidate strict checks passed.
The first source-validator attempt matched the English word admit in a comment.
The corrected validator removes comments before the same forbidden-code scan.
The full independent Audit and printed axiom checks also pass. The first TEMP
bootstrap attempted to copy a document directory as a file. Its repair copied
all nine document paths recursively. Neither packaging repair changed proofs.

## Evidence and restart

Raw evidence: /tmp/mcfta-prepared-origins-20261028.
Repository archive: lean/restart-evidence/20261028-prepared-origins.
Each command records its exact tested main source, current new-module inputs,
raw output, exit code, hashes and measured resource limits. Owner reviews retain
whole source snapshots, literal slices and exact printed declaration blocks.
Root read the new source bodies and failed raw logs. Public appendix reading is
split among the named owners; do not infer a whole-appendix root read.
The manifest records every frozen payload with raw and stored hashes.
The archive verifier checks exact sets, hashes, command limits, old/public
preservation and document inverse bodies. It can reconstruct exact TEMP bytes
and verify committed archive payloads. All prior evidence areas stay frozen.
Use a FRESH area after this checkpoint. Goal ACTIVE; no work remains in this
checkpoint, but the complete formalization is not finished.
'''
(r/'lean/notes-current-prepared-origins.md').write_text(note)
(a/'root-review/notes-current-prepared-origins.md').write_text(note)
print(json.dumps(dict(documents=len(records),note_bytes=len(note.encode()),common_bytes=len(common.encode()),findings_bytes=len(findings.encode()))))
