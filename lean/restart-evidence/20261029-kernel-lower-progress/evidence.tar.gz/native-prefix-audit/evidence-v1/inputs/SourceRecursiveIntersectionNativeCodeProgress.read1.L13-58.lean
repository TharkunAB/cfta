open Cache InternedConstructorTemplates InternedProbeProvenance InternedBinderProtocol IntersectionFlatMemoKeyDomain
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceRecursiveIntersectionInputView IntersectSchedule

/-- Strictly smaller body observations derive finite actual code observations without a supplied completed run. -/
theorem code_terminal_of_bodies [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (source : InternedConstructorTemplates.State Symbol Guard) (holds : Guard → Language.Term Symbol → Bool)
    (bound : Nat) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (bodies : BodiesBelow source holds bound width emptyGuard conjoin) (code : Code Symbol Guard A) :
    ∀ (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) (post : Machine Symbol Guard → A → Prop),
    Safe code state.machine post → Below source holds bound code state.machine →
    SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin state → Grows source state.machine.heap →
    Extends source.nodes.issued state.machine.heap.nodes.issued → ActiveAbove (view source holds) holds bound state →
    WordRanges emptyGuard conjoin code state → ∃ fuel, ReturnsOrPending (execute emptyGuard conjoin fuel code state) := by
  induction code with
  | pure value => intro state _ _ _ _ _ _ _ _; exact ⟨1, .done value state⟩
  | fail failure => intro _ _ _ impossible; cases impossible
  | work job next ih =>
      intro state post safe below valid growth history active ranges
      let actual := InternedConstructorTemplates.run job state.machine.heap
      let current : Machine Symbol Guard := {state.machine with heap := actual.2}
      have physical : Extension state.machine current := safe.2.1
      have continued := ih actual.1 (advance state current) post (safe.2.2 actual.1 current rfl) (below actual.1 current rfl)
        (advance_valid width emptyGuard conjoin state valid current safe.1 physical)
        (grows_trans growth physical.heap) (extends_trans history physical.history)
        (active.advance _ holds bound state current) (ranges.after_step emptyGuard conjoin _ _ _ _ rfl)
      exact returns_after_step emptyGuard conjoin _ _ _ _ rfl continued
  | enter domain left right first second next ih =>
      intro state post safe below valid growth history active ranges
      let actual := SourceRecursiveIntersectionEnvironment.enter state.machine.domains domain.key left right first second
      let current : Machine Symbol Guard := {state.machine with domains := actual.2}
      have physical : Extension state.machine current := safe.2.1
      have continued := ih actual.1 (advance state current) post safe.2.2 below
        (advance_valid width emptyGuard conjoin state valid current safe.1 physical)
        (grows_trans growth physical.heap) (extends_trans history physical.history)
        (active.advance _ holds bound state current) (ranges.after_step emptyGuard conjoin _ _ _ _ rfl)
      exact returns_after_step emptyGuard conjoin _ _ _ _ rfl continued
  | read name next ih =>
      intro state post safe below valid growth history active ranges
      exact returns_after_step emptyGuard conjoin _ _ _ _ rfl
        (ih _ state post safe below valid growth history active (ranges.after_step emptyGuard conjoin _ _ _ _ rfl))
  | optionalBinder key body next ih =>
      intro state post safe below valid growth history active ranges
      cases constructed : SourceRecursiveIntersectionMaybeMu.maybeMu key body state.machine.heap with
      | pending pending heap =>
          exact ⟨1, by simp only [execute, step, constructed]; exact .constructor _ _ _⟩
