/-- Source code excludes failures and retains original request scope and its strict body limit through actual continuations. -/
def Below [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (source : InternedConstructorTemplates.State Symbol Guard)
    (holds : Guard → Language.Term Symbol → Bool) (bound : Nat) (code : Code Symbol Guard A) (state : Machine Symbol Guard) : Prop :=
  match code with
  | .pure _ => True
  | .fail _ => False
  | .work job next =>
      let actual := SourceRecursiveIntersectionKernel.work job state
      ∀ value after, actual = .done value after → Below source holds bound (next value) after
  | .enter domain left right first second next =>
      let actual := SourceRecursiveIntersectionEnvironment.enter state.domains domain.key left right first second
      Below source holds bound (next actual.1) {state with domains := actual.2}
  | .read name next => Below source holds bound (next (SourcePreparedSharedRows.read state.heap name)) state
  | .optionalBinder key body next =>
      let actual := construction (SourceRecursiveIntersectionMaybeMu.maybeMu key body state.heap) state
      ∀ value after, actual = .done value after → Below source holds bound (next value) after
  | .node request next =>
      NodeBelow source holds bound request ∧ ∀ value after, SourceRecursiveIntersectionKernel.Valid after → Extension state after →
        Available after.heap value → Below source holds bound (next value) after
  | .edge request next =>
      EdgeBelow source holds bound request ∧ ∀ value after, SourceRecursiveIntersectionKernel.Valid after → Extension state after →
        EdgeResident after.heap value → Below source holds bound (next value) after
  | .finishNode .. | .finishEdge .. => False

/-- Safe source sequencing retains the strict request limit through exact returned machines. -/
theorem below_bind [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (source : InternedConstructorTemplates.State Symbol Guard)
    (holds : Guard → Language.Term Symbol → Bool) (bound : Nat) (code : Code Symbol Guard A) (next : A → Code Symbol Guard B)
    (state : Machine Symbol Guard) (valid : SourceRecursiveIntersectionKernel.Valid state) (intermediate : Machine Symbol Guard → A → Prop)
    (safe : Safe code state intermediate) (bounded : Below source holds bound code state)
    (continuation : ∀ value after, SourceRecursiveIntersectionKernel.Valid after → Extension state after →
      intermediate after value → Below source holds bound (next value) after) : Below source holds bound (code.bind next) state := by
  induction code generalizing state with
  | pure value => exact continuation value state valid (.refl state) safe
  | fail failure => exact bounded
