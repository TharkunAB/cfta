open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode

/-- A zero-step trace retains its original control and every cache. -/
theorem steps_zero [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (code next : Code Symbol Guard A) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (trace : Steps emptyGuard conjoin 0 code state next after) : code = next ∧ state = after := by
  cases trace
  exact ⟨rfl, rfl⟩

/-- A positive trace exposes the exact original first step and remaining trace. -/
theorem steps_succ [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (fuel : Nat) (code next : Code Symbol Guard A) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (trace : Steps emptyGuard conjoin (fuel + 1) code state next after) :
    ∃ (rest : Code Symbol Guard A) (current : SourceRecursiveIntersectionThunks.State width Symbol Guard),
      step emptyGuard conjoin code state = .yielded rest current ∧ Steps emptyGuard conjoin fuel rest current next after := by
  cases trace with
  | cons code state rest current next after fuel one tail => exact ⟨rest, current, one, tail⟩

/-- A pure value cannot make a yielded step, so its completed trace is empty. -/
theorem pure_trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (fuel : Nat) (first value : A) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (trace : Steps emptyGuard conjoin fuel (.pure first) state (.pure value) after) : fuel = 0 ∧ first = value ∧ state = after := by
  cases trace with
  | refl => exact ⟨rfl, rfl, rfl⟩
  | cons code state rest current final after fuel one tail => cases one

/-- Every completed appended trace derives its inner value, exact shared state, and finite continuation trace. -/
theorem steps_bind_inverse [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (fuel : Nat) (code : Code Symbol Guard A) (next : A → Code Symbol Guard B)
    (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard) (value : B)
    (trace : Steps emptyGuard conjoin fuel (code.bind next) state (.pure value) after) :
    ∃ (inner outer : Nat) (result : A) (current : SourceRecursiveIntersectionThunks.State width Symbol Guard),
      inner + outer = fuel ∧ Steps emptyGuard conjoin inner code state (.pure result) current ∧
        Steps emptyGuard conjoin outer (next result) current (.pure value) after := by
