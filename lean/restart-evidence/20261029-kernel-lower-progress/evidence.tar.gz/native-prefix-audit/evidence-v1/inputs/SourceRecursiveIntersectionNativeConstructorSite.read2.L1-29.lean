import MicroCFTA.SourceRecursiveIntersectionNativePrefixCoverage

/-!
# Exact source site of an actual pending constructor

A pending native constructor can arise only at an optional-binder
instruction. An actual bounded blocked run derives its finite yielded
prefix, original source body, pre-call native state, and exact returned
heap. No source-site witness is supplied.
-/
namespace MicroCFTA.SourceRecursiveIntersectionNative
open Cache InternedConstructorTemplates InternedBinderProtocol IntersectionFlatMemoKeyDomain
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode

/-- One actual constructor block identifies its original optional-binder instruction and exact source effect. -/
theorem step_constructor_site [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (code remaining : Code Symbol Guard A)
    (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard) (key : NodeKey)
    (blocked : step emptyGuard conjoin code state = .blocked (.constructor key) remaining after) :
    ∃ pair body next heap, code = .optionalBinder pair body next ∧ remaining = .optionalBinder pair body next ∧
      SourceRecursiveIntersectionMaybeMu.maybeMu pair body state.machine.heap = .pending key heap ∧
      after = advance state {state.machine with heap := heap} := by
  cases code with
  | pure | fail | work | enter | read | finishNode | finishEdge => cases blocked
  | optionalBinder pair body next =>
      cases constructed : SourceRecursiveIntersectionMaybeMu.maybeMu pair body state.machine.heap with
      | done => simp only [step, constructed] at blocked; cases blocked
      | pending actual heap =>
          have same := Outcome.blocked.inj (by simpa only [step, constructed] using blocked)
