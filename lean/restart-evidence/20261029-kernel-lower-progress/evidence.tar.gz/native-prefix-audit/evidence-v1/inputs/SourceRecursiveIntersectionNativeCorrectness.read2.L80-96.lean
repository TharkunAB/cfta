    have growth : Extension state.machine current.machine := by rw [called.2.1]; exact .refl _
    have later := ih post (clean value) (safe.2 value current.machine called.1.machine growth called.2.2.1) called.1
    exact ⟨later.valid, growth.trans later.growth, later.result, Meaning.node called.2.2.2 later.meaning⟩
  | @edgeReady A request next state selected current final handle value result lookup demand tail safeWord tailBound ih =>
    intro clean safe valid
    have called := edge_ready_source emptyGuard conjoin state selected current valid request safe.1 safeWord handle value lookup demand
    have growth : Extension state.machine current.machine := by rw [called.2.1]; exact .refl _
    have later := ih post (clean value) (safe.2 value current.machine called.1.machine growth called.2.2.1) called.1
    exact ⟨later.valid, growth.trans later.growth, later.result, Meaning.edge called.2.2.2 later.meaning⟩
  | @nodeStarted A request actual next state selected current middle final handle value result lookup demand body tail safeWord bodyBound tailBound bodyIH tailIH =>
    intro clean safe valid
    have started := node_started_source emptyGuard conjoin state selected current valid request actual safe.1 safeWord handle lookup demand
    have same := started.2.1
    subst actual
    have ready : NodeReady current.machine request := by rw [started.2.2.1]; exact safe.1
    have built := bodyIH (fun after value => Available after.heap value) (compileNode_bodyCode request)
      (compileNode_safe request current.machine started.1.machine ready) started.1
