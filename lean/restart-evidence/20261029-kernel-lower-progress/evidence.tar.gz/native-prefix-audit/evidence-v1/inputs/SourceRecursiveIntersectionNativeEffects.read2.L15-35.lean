/-- Native constructor work retains the exact physical source worker and its returned cache. -/
theorem work_step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (job : Work Symbol Guard X) (next : X → Code Symbol Guard A) (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) :
    let actual := InternedConstructorTemplates.run job state.machine.heap
    step emptyGuard conjoin (.work job next) state = .yielded (next actual.1) (advance state { state.machine with heap := actual.2 }) := rfl

/-- Actual constructor verification retains both memo families through native work. -/
theorem work_step_valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard)
    (conjoin : Guard → Guard → Guard) (state : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (valid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin state) (job : Work Symbol Guard X)
    (property : InternedConstructorTemplates.State Symbol Guard → X → Prop)
    (verified : InternedNestedFacts.Verified state.machine.heap (InternedNestedConstruction.work job state.machine.heap) property)
    (next : X → Code Symbol Guard A) :
    SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin (step emptyGuard conjoin (.work job next) state).state := by
  have checked := work_checked state.machine valid.machine job property verified
  exact advance_valid width emptyGuard conjoin state valid _ checked.valid checked.extension

/-- Native domain entry uses the original canonical allocation before entering the continuation. -/
theorem enter_step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (domain : Interned DomainKey) (left right : Value Symbol Guard) (first second : Nat)
    (next : Interned DomainKey → Code Symbol Guard A) (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) :
