def Safe [DecidableEq (EdgeKey Symbol Guard)] (code : Code Symbol Guard A) (state : Machine Symbol Guard)
    (post : Machine Symbol Guard → A → Prop) : Prop :=
  match code with
  | .pure value => post state value
  | .fail _ => True
  | .work job next =>
      let actual := SourceRecursiveIntersectionKernel.work job state
      SourceRecursiveIntersectionKernel.Valid actual.state ∧ Extension state actual.state ∧
        ∀ value after, actual = .done value after → Safe (next value) after post
  | .enter domain left right first second next =>
      let actual := SourceRecursiveIntersectionEnvironment.enter state.domains domain.key left right first second
      let after : Machine Symbol Guard := { state with domains := actual.2 }
      SourceRecursiveIntersectionKernel.Valid after ∧ Extension state after ∧ Safe (next actual.1) after post
  | .read name next => Safe (next (SourcePreparedSharedRows.read state.heap name)) state post
  | .optionalBinder key body next =>
      let actual := construction (SourceRecursiveIntersectionMaybeMu.maybeMu key body state.heap) state
      SourceRecursiveIntersectionKernel.Valid actual.state ∧ Extension state actual.state ∧
        ∀ value after, actual = .done value after → Safe (next value) after post
  | .node request next =>
      NodeReady state request ∧ ∀ value after, SourceRecursiveIntersectionKernel.Valid after → Extension state after →
        Available after.heap value → Safe (next value) after post
  | .edge request next =>
      EdgeReady state request ∧ ∀ value after, SourceRecursiveIntersectionKernel.Valid after → Extension state after →
        EdgeResident after.heap value → Safe (next value) after post
  | .finishNode .. | .finishEdge .. => False

/-- Safe source sequencing composes actual cache growth and returned record properties. -/
theorem safe_bind [DecidableEq (EdgeKey Symbol Guard)] (code : Code Symbol Guard A) (next : A → Code Symbol Guard B)
