
/-- Every actual native source prefix has safe request words when its reached caches fit. -/
theorem prefix_words [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (bits : Nat) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (fuel : Nat) {A : Type}
    (code : Code Symbol Guard A) (state after : SourceRecursiveIntersectionThunks.State (bits + 2) Symbol Guard)
    (remaining : Code Symbol Guard A) (post : Machine Symbol Guard → A → Prop)
    (clean : BodyCode code) (safe : Safe code state.machine post)
    (valid : SourceRecursiveIntersectionThunks.Valid (bits + 2) emptyGuard conjoin state)
    (ranges : CacheRanges bits emptyGuard conjoin code state)
    (trace : Steps emptyGuard conjoin fuel code state remaining after) : Words (bits + 2) remaining := by
  induction fuel using Nat.strongRecOn generalizing A code state after remaining with
  | ind fuel ih =>
      cases fuel with
      | zero =>
          obtain ⟨same, retained⟩ := steps_zero emptyGuard conjoin _ _ _ _ trace
          subst remaining
          subst after
          exact words bits code state.machine valid.machine (ranges.current bits emptyGuard conjoin code state)
