
/-- Actual native memo requests retain the existing explicit machine-word range premises. -/
inductive Bounds {width : Nat} {Symbol Guard : Type} [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    {emptyGuard : Guard} {conjoin : Guard → Guard → Guard} : {A : Type} → {code : Code Symbol Guard A} →
      {state after : SourceRecursiveIntersectionThunks.State width Symbol Guard} → {value : A} →
      Evaluation width Symbol Guard emptyGuard conjoin code state value after → Prop where
  | pure (value : A) (state) : Bounds (Evaluation.pure value state)
  | work {job : Work Symbol Guard X} {next : X → Code Symbol Guard A} {state final} {result : A}
      {tail : Evaluation width Symbol Guard emptyGuard conjoin
        (next (InternedConstructorTemplates.run job state.machine.heap).1)
        (advance state {state.machine with heap := (InternedConstructorTemplates.run job state.machine.heap).2}) result final}
      (bounded : Bounds tail) : Bounds (Evaluation.work (job := job) (next := next) (state := state) tail)
  | enter {domain : Interned DomainKey} {left right : Value Symbol Guard} {first second : Nat}
      {next : Interned DomainKey → Code Symbol Guard A} {state final} {result : A}
      {tail : Evaluation width Symbol Guard emptyGuard conjoin
        (next (SourceRecursiveIntersectionEnvironment.enter state.machine.domains domain.key left right first second).1)
        (advance state {state.machine with domains := (SourceRecursiveIntersectionEnvironment.enter state.machine.domains domain.key left right first second).2}) result final}
      (bounded : Bounds tail) : Bounds (Evaluation.enter (domain := domain) (left := left) (right := right)
        (first := first) (second := second) (next := next) (state := state) tail)
  | read {name : Nat} {next : Option (Value Symbol Guard) → Code Symbol Guard A} {state final} {result : A}
      {tail : Evaluation width Symbol Guard emptyGuard conjoin (next (SourcePreparedSharedRows.read state.machine.heap name)) state result final}
      (bounded : Bounds tail) : Bounds (Evaluation.read (name := name) (next := next) (state := state) tail)
  | optionalBinder {key : Nat × Nat} {body value : Value Symbol Guard} {next : Value Symbol Guard → Code Symbol Guard A}
      {state final} {after : InternedConstructorTemplates.State Symbol Guard} {result : A}
      (done : SourceRecursiveIntersectionMaybeMu.maybeMu key body state.machine.heap = .done value after)
      {tail : Evaluation width Symbol Guard emptyGuard conjoin (next value) (advance state {state.machine with heap := after}) result final}
      (bounded : Bounds tail) : Bounds (Evaluation.optionalBinder (next := next) done tail)
  | nodeDirect {request actual : NodeRequest Symbol Guard} {next : Value Symbol Guard → Code Symbol Guard A}
      {state selected middle final} {value : Value Symbol Guard} {result : A}
      (lookup : lookupNode width request state = (.direct actual, selected))
      {body : Evaluation width Symbol Guard emptyGuard conjoin (compileNode actual) selected value middle}
      {tail : Evaluation width Symbol Guard emptyGuard conjoin (next value) middle result final}
