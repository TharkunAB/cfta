/-- Only a pure value can complete one native step. -/
theorem step_done_iff [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (code : Code Symbol Guard A) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard) (value : A) :
    step emptyGuard conjoin code state = .done value after ↔ code = .pure value ∧ state = after := by
  cases code with
  | pure result => simp only [step, Outcome.done.injEq, Code.pure.injEq]
  | fail failure | work job next | enter domain left right first second next | read name next | finishNode handle result next | finishEdge handle result next =>
    simp only [step, reduceCtorEq, false_and]
  | optionalBinder key body next =>
    cases actual : SourceRecursiveIntersectionMaybeMu.maybeMu key body state.machine.heap <;> simp only [step, actual, reduceCtorEq, false_and]
  | node request next =>
    cases selected : lookupNode width request state with
    | mk selection current =>
      cases selection with
      | direct actual => simp only [step, selected, reduceCtorEq, false_and]
      | memoized handle =>
        cases demanded : demandNode handle current with
        | mk observation final =>
          cases observation <;> simp only [step, selected, demanded, reduceCtorEq, false_and]
  | edge request next =>
    cases selected : lookupEdge width request state with
    | mk handle current =>
      cases demanded : demandEdge handle current with
      | mk observation final =>
        cases observation <;> simp only [step, selected, demanded, reduceCtorEq, false_and]

/-- A completed native run derives a finite exact trace to its returned pure value. -/
theorem done_trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (fuel : Nat) (code : Code Symbol Guard A) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (value : A) (done : execute emptyGuard conjoin fuel code state = .done value after) :
    ∃ steps, steps < fuel ∧ Steps emptyGuard conjoin steps code state (.pure value) after := by
  induction fuel generalizing code state with
  | zero => cases done
  | succ fuel ih =>
    cases one : step emptyGuard conjoin code state with
    | done result current =>
