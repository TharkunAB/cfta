        | mk observation current => cases observation <;> simp only [step, lookup, demand] at blocked <;> cases blocked

/-- An actual finite constructor block derives its exact earlier source site and complete yielded prefix. -/
theorem constructor_trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (fuel : Nat) (code remaining : Code Symbol Guard A)
    (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard) (key : NodeKey)
    (blocked : execute emptyGuard conjoin fuel code state = .blocked (.constructor key) remaining after) :
    ∃ steps before pair body next heap, steps < fuel ∧
      Steps emptyGuard conjoin steps code state (.optionalBinder pair body next) before ∧
      remaining = .optionalBinder pair body next ∧
      SourceRecursiveIntersectionMaybeMu.maybeMu pair body before.machine.heap = .pending key heap ∧
      after = advance before {before.machine with heap := heap} := by
  induction fuel generalizing code state with
  | zero => cases blocked
  | succ fuel ih =>
      cases one : step emptyGuard conjoin code state with
      | done | failed => simp only [execute, one] at blocked; cases blocked
      | yielded rest current =>
          have tail : execute emptyGuard conjoin fuel rest current = .blocked (.constructor key) remaining after := by
            simpa only [execute, one] using blocked
          obtain ⟨steps, before, pair, body, next, heap, smaller, trace, original, constructed, final⟩ := ih rest current tail
          exact ⟨steps + 1, before, pair, body, next, heap, by omega,
            .cons _ _ _ _ _ _ steps one trace, original, constructed, final⟩
      | blocked reason rest current =>
          have same := Outcome.blocked.inj (by simpa only [execute, one] using blocked)
          rcases same with ⟨rfl, rfl, rfl⟩
