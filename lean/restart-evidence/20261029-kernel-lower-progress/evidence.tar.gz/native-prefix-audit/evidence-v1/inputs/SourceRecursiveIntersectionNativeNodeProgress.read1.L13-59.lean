open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceRecursiveIntersectionInputView IntersectSchedule

/-- A node instruction has a finite terminal observation when smaller bodies and its actual continuation do. -/
theorem node_terminal [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (source : InternedConstructorTemplates.State Symbol Guard) (holds : Guard → Language.Term Symbol → Bool)
    (bound : Nat) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (bodies : BodiesBelow source holds bound width emptyGuard conjoin)
    (request : NodeRequest Symbol Guard) (next : Value Symbol Guard → Code Symbol Guard A)
    (state : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (valid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin state) (ready : NodeReady state.machine request)
    (below : NodeBelow source holds bound request) (growth : Grows source state.machine.heap)
    (history : Extends source.nodes.issued state.machine.heap.nodes.issued) (active : ActiveAbove (view source holds) holds bound state)
    (ranges : WordRanges emptyGuard conjoin (.node request next) state)
    (later : ∀ value after, SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin after → Extension state.machine after.machine →
      Available after.machine.heap value → ActiveAbove (view source holds) holds bound after → WordRanges emptyGuard conjoin (next value) after →
      ∃ fuel, ReturnsOrPending (execute emptyGuard conjoin fuel (next value) after)) :
    ∃ fuel, ReturnsOrPending (execute emptyGuard conjoin fuel (.node request next) state) := by
  obtain ⟨scope, complete, smaller⟩ := below
  let limit := requiredFuel (view source holds) (nodeSemantic request) complete
  cases lookup : lookupNode width request state with
  | mk selection chosen =>
    cases selection with
    | direct original =>
      obtain ⟨same, retained⟩ := lookupNode_direct request original state chosen lookup
      subst original
      subst chosen
      have one : step emptyGuard conjoin (.node request next) state = .yielded ((compileNode request).bind next) state := by
        simp only [step, lookup]
      have entered := ranges.after_step emptyGuard conjoin _ _ _ _ one
      have bodyRanges := entered.before_bind emptyGuard conjoin _ _ _
      have observed := bodies.nodes request scope complete smaller state valid ready growth history
        (active.weaken _ holds bound limit (Nat.le_of_lt smaller) state) bodyRanges
      apply returns_after_step emptyGuard conjoin _ _ _ _ one
      apply returns_bind emptyGuard conjoin (compileNode request) next state observed
      intro fuel value after done
      have evaluated := evaluation_of_done emptyGuard conjoin fuel (compileNode request) state after value done
      have built := (evaluated.bounds_of_ranges bodyRanges).correct (fun after value => Available after.heap value)
        (compileNode_bodyCode request) (compileNode_safe request state.machine valid.machine ready) valid
      have returnedActive := active.running_before _ holds bound state after
        (evaluated.running_before (compileNode_bodyCode request) (shape_of_valid emptyGuard conjoin state valid))
      exact later value after built.valid built.growth built.result returnedActive
        (entered.after_body emptyGuard conjoin _ _ _ _ value evaluated)
    | memoized handle =>
      obtain ⟨key, requested, _, _⟩ := lookupNode_memoized request state chosen handle lookup
      have safeWord := ranges.current emptyGuard conjoin _ _ key requested
      have chosenActive : ActiveAbove (view source holds) holds bound chosen := by
