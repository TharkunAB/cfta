import MicroCFTA.SourceRecursiveIntersectionMaybeMuCoverage
import MicroCFTA.SourceRecursiveIntersectionNativeRangeCertificate

/-!
# Payload coverage on every actual yielded native prefix

Ordinary work and completed optional binders retain coverage. Domain and
memo operations do not change the constructor heap. Thus any finite yielded
prefix retains its incoming pending-key allowance. No completed native run,
body preparation, word bound, or memo provenance premise is needed.
-/
namespace MicroCFTA.SourceRecursiveIntersectionNative
open Cache InternedConstructorTemplates InternedRecordCoherence InternedBinderProtocol IntersectionFlatMemoKeyDomain
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode

/-- Every native node lookup and demand leaves the source machine unchanged at its immediate observation. -/
theorem node_step_machine [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (request : NodeRequest Symbol Guard)
    (next : Value Symbol Guard → Code Symbol Guard A) (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) :
    (step emptyGuard conjoin (.node request next) state).state.machine = state.machine := by
  cases lookup : lookupNode width request state with
  | mk selection chosen =>
    have chosenMachine : chosen.machine = state.machine := by simpa only [lookup] using lookupNode_machine request state
    cases selection with
    | direct actual => simpa only [step, lookup, Outcome.state] using chosenMachine
    | memoized handle =>
      cases demand : demandNode handle chosen with
      | mk observation current =>
        have currentMachine : current.machine = chosen.machine := by simpa only [demand] using demandNode_machine handle chosen
        cases observation <;> simpa only [step, lookup, demand, Outcome.state] using currentMachine.trans chosenMachine

/-- Every native row lookup and demand leaves the source machine unchanged at its immediate observation. -/
theorem edge_step_machine [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (request : EdgeRequest Symbol Guard)
    (next : EdgeValue Symbol Guard → Code Symbol Guard A) (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) :
    (step emptyGuard conjoin (.edge request next) state).state.machine = state.machine := by
  cases lookup : lookupEdge width request state with
