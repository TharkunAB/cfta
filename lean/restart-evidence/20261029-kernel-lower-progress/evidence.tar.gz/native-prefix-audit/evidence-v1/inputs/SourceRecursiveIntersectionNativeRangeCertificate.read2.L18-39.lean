    WordRanges emptyGuard conjoin code state → Bounds evaluated := by
  induction evaluated with
  | pure => intro ranges; exact .pure _ _
  | work tail ih =>
      intro ranges
      exact .work (ih (ranges.after_step emptyGuard conjoin _ _ _ _ rfl))
  | enter tail ih =>
      intro ranges
      exact .enter (ih (ranges.after_step emptyGuard conjoin _ _ _ _ rfl))
  | read tail ih =>
      intro ranges
      exact .read (ih (ranges.after_step emptyGuard conjoin _ _ _ _ rfl))
  | optionalBinder done tail ih =>
      intro ranges
      exact .optionalBinder done (ih (ranges.after_step emptyGuard conjoin _ _ _ _ (by simp only [step, done])))
  | @nodeDirect A request actual next state chosen middle final value result lookup body tail bodyIH tailIH =>
      intro ranges
      have entered : WordRanges emptyGuard conjoin ((compileNode actual).bind next) chosen :=
        ranges.after_step emptyGuard conjoin _ _ _ _ (by simp only [step, lookup])
      have bodyRanges := entered.before_bind emptyGuard conjoin (compileNode actual) next chosen
      have tailRanges := entered.after_body emptyGuard conjoin (compileNode actual) next chosen middle value body
      exact .nodeDirect lookup (bodyIH bodyRanges) (tailIH tailRanges)
