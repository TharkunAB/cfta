
/-- Source code retains the semantic heap conditions at its actual effect and request sites. -/
def Semantic [DecidableEq (EdgeKey Symbol Guard)] (code : Code Symbol Guard A) (state : Machine Symbol Guard) : Prop :=
  match code with
  | .pure _ | .fail _ => True
  | .work job next =>
      let actual := SourceRecursiveIntersectionKernel.work job state
      (SemanticHeap state.heap → SemanticHeap actual.state.heap) ∧
        ∀ value after, actual = .done value after → Semantic (next value) after
  | .enter domain left right first second next =>
      let actual := SourceRecursiveIntersectionEnvironment.enter state.domains domain.key left right first second
      Semantic (next actual.1) {state with domains := actual.2}
  | .read name next => Semantic (next (SourcePreparedSharedRows.read state.heap name)) state
  | .optionalBinder key body next =>
      Available state.heap body ∧
        ∀ value after, construction (SourceRecursiveIntersectionMaybeMu.maybeMu key body state.heap) state = .done value after →
          Semantic (next value) after
  | .node request next =>
      NodeReady state request ∧ ∀ value after, SourceRecursiveIntersectionKernel.Valid after → Extension state after →
        Available after.heap value → Semantic (next value) after
  | .edge request next =>
      EdgeReady state request ∧ ∀ value after, SourceRecursiveIntersectionKernel.Valid after → Extension state after →
        EdgeResident after.heap value → Semantic (next value) after
  | .finishNode _ _ next | .finishEdge _ _ next => Semantic next state

/-- Safe source sequencing retains the semantic heap conditions through exact returned machines. -/
theorem semantic_bind [DecidableEq (EdgeKey Symbol Guard)] (code : Code Symbol Guard A) (next : A → Code Symbol Guard B)
    (state : Machine Symbol Guard) (valid : SourceRecursiveIntersectionKernel.Valid state) (intermediate : Machine Symbol Guard → A → Prop)
    (safe : Safe code state intermediate) (semantic : Semantic code state)
