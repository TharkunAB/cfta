open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode

/-- A finite trace retains every actual yielded native step and intermediate cache. -/
inductive Steps [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) :
    Nat → Code Symbol Guard A → SourceRecursiveIntersectionThunks.State width Symbol Guard →
      Code Symbol Guard A → SourceRecursiveIntersectionThunks.State width Symbol Guard → Prop where
  | refl (code state) : Steps emptyGuard conjoin 0 code state code state
  | cons (code state next after final result fuel)
      (step : SourceRecursiveIntersectionNative.step emptyGuard conjoin code state = .yielded next after)
      (rest : Steps emptyGuard conjoin fuel next after final result) :
      Steps emptyGuard conjoin (fuel + 1) code state final result

/-- Every finite yielded trace is the exact original bounded native execution. -/
theorem Steps.execute [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (fuel : Nat) (code next : Code Symbol Guard A) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (trace : Steps emptyGuard conjoin fuel code state next after) :
    execute emptyGuard conjoin fuel code state = .yielded next after := by
  induction trace with
  | refl => rfl
  | cons code state next after final result fuel one rest ih =>
    simp only [SourceRecursiveIntersectionNative.execute, one]
    exact ih

/-- A yielded bounded run derives all actual intermediate steps without an assumed trace. -/
theorem execute_steps [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (fuel : Nat) (code next : Code Symbol Guard A) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (yielded : execute emptyGuard conjoin fuel code state = .yielded next after) :
    Steps emptyGuard conjoin fuel code state next after := by
  induction fuel generalizing code state with
  | zero =>
    have same := Outcome.yielded.inj yielded
    rcases same.1 with rfl
    rcases same.2 with rfl
    exact .refl _ _
  | succ fuel ih =>
    cases one : step emptyGuard conjoin code state with
    | yielded rest current =>
      have remaining : execute emptyGuard conjoin fuel rest current = .yielded next after := by
        simpa only [execute, one] using yielded
      exact .cons _ _ _ _ _ _ _ one (ih rest current remaining)
    | done | failed | blocked => simp only [execute, one] at yielded; cases yielded

/-- Native yielded traces compose at the exact preceding returned state. -/
theorem Steps.trans [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (first second : Nat) (code middle next : Code Symbol Guard A)
    (state current after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (earlier : Steps emptyGuard conjoin first code state middle current) (later : Steps emptyGuard conjoin second middle current next after) :
