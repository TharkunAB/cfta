import MicroCFTA.SourceRecursiveIntersectionNativeCorrectness

/-!
# Actual completed native node and edge source calls

Actual bounded native completion supplies its evaluation tree. Checked word
bounds on that tree derive complete guarded kernel correspondence and new
memo provenance. No uncached body execution is supplied. Successful first-run
termination for every input remains a separate obligation.
-/
namespace MicroCFTA.SourceRecursiveIntersectionNative
open Cache InternedConstructorTemplates InternedProbeProvenance InternedEdgeResidency
open InternedBinderProtocol IntersectionFlatMemoKeyDomain SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode

/-- An actual completed native node call derives its exact guarded kernel execution and strong returned memo invariants. -/
theorem native_node_correct [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (fuel : Nat) (request : NodeRequest Symbol Guard) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (value : Value Symbol Guard) (valid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin state)
    (ready : NodeReady state.machine request)
    (done : execute emptyGuard conjoin fuel (.node request .pure) state = .done value after)
    (bounds : Bounds (evaluation_of_done emptyGuard conjoin fuel (.node request .pure) state after value done)) :
    SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin after ∧ Extension state.machine after.machine ∧
      Available after.machine.heap value ∧ ∃ bound, ∀ extra,
        SourceRecursiveIntersectionKernel.execute emptyGuard conjoin (bound + extra) request.domain request.left request.right state.machine = .done value after.machine := by
  have correct := bounds.correct (fun after value => Available after.heap value) (by intro value; trivial)
    (safe_requestNode request.domain request.left request.right state.machine ready) valid
  obtain ⟨bound, repeated⟩ := correct.meaning
  refine ⟨correct.valid, correct.growth, correct.result, bound, ?_⟩
  intro extra
  have observed := repeated extra
  change (SourceRecursiveIntersectionKernel.execute emptyGuard conjoin (bound + extra)
    request.domain request.left request.right state.machine).bind (fun value after => .done value after) = .done value after.machine at observed
  simpa only [result_bind_pure] using observed

/-- An actual completed native edge call derives its exact guarded row execution and strong returned memo invariants. -/
theorem native_edge_correct [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
