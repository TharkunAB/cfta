open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode

/-- Every finite nested evaluation constructs its actual completed native trace. -/
theorem Evaluation.trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (code : Code Symbol Guard A) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard) (value : A)
    (evaluated : Evaluation width Symbol Guard emptyGuard conjoin code state value after) :
    ∃ fuel, Steps emptyGuard conjoin fuel code state (.pure value) after := by
  induction evaluated with
  | pure => exact ⟨0, .refl _ _⟩
  | work tail ih | enter tail ih | read tail ih | finishNode tail ih | finishEdge tail ih =>
    obtain ⟨fuel, trace⟩ := ih
    exact ⟨fuel + 1, .cons _ _ _ _ _ _ _ rfl trace⟩
  | optionalBinder done tail ih =>
    obtain ⟨fuel, trace⟩ := ih
    refine ⟨fuel + 1, .cons _ _ _ _ _ _ _ ?_ trace⟩
    simp only [step, done]
  | @nodeDirect A request actual next state selected middle final value result lookup body tail bodyIH tailIH =>
    obtain ⟨inner, bodyTrace⟩ := bodyIH
    obtain ⟨outer, tailTrace⟩ := tailIH
    refine ⟨inner + outer + 1, .cons _ _ ((compileNode actual).bind next) selected _ _ _ ?_ ?_⟩
    · simp only [step, lookup]
    · apply Steps.trans emptyGuard conjoin inner outer
      case later => exact tailTrace
