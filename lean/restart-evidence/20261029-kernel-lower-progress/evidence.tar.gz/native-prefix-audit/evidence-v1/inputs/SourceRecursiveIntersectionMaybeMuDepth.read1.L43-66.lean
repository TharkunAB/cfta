    omega
  · cases done
    omega

/-- Every new Mu body is below the actual optional-binder plan bound. -/
theorem lower [DecidableEq (EdgeKey Symbol Guard)] (key : Nat × Nat)
    (body : Value Symbol Guard) (state : State Symbol Guard)
    (context : InternedFreshOrdinaryContext.Context state [])
    (cached : InternedFreshOrdinaryDepthHeap.Heap state)
    (opened : InternedOpenDepthReadback.Heap state)
    (available : Available state body) :
    InternedStoredPlanBinderDepthProgress.Lower state (valueDepth body + 1)
      (maybeMu key body state).state := by
  have captured : InternedFreshOrdinaryContext.Context state (leaves body) :=
    ⟨context.normal, leaves_available body state available, context.profiles, context.freeNames⟩
  have zero : ∀ leaf ∈ leaves body, valueDepth leaf = 0 := by
    intro leaf member
    rcases InternedStoredLeafShape.leaves_shape body leaf member with closed | ⟨name, rfl⟩
    · rw [valueDepth.eq_def]
      simp only [closed, List.isEmpty_nil, ↓reduceIte]
    · simp [valueDepth]
  rw [maybeMu_eq key body state state context.normal.facts available]
  split
  · exact InternedStoredPlanBinderDepthProgress.build_lower _ _ state captured cached opened
