/-- Completed optional-binder construction enters its continuation at the exact returned source heap. -/
theorem optionalBinder_done_step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (key : Nat × Nat) (body value : Value Symbol Guard) (next : Value Symbol Guard → Code Symbol Guard A)
    (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) (after : InternedConstructorTemplates.State Symbol Guard)
    (done : SourceRecursiveIntersectionMaybeMu.maybeMu key body state.machine.heap = .done value after) :
    step emptyGuard conjoin (.optionalBinder key body next) state = .yielded (next value) (advance state { state.machine with heap := after }) := by
  simp only [step, done]

/-- Pending optional-binder construction retains its actual installed key, new heap, and original continuation. -/
theorem optionalBinder_pending_step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (key : Nat × Nat) (body : Value Symbol Guard) (next : Value Symbol Guard → Code Symbol Guard A)
    (state : SourceRecursiveIntersectionThunks.State width Symbol Guard) (pending : NodeKey) (after : InternedConstructorTemplates.State Symbol Guard)
    (blocked : SourceRecursiveIntersectionMaybeMu.maybeMu key body state.machine.heap = .pending pending after) :
    step emptyGuard conjoin (.optionalBinder key body next) state =
      .blocked (.constructor pending) (.optionalBinder key body next) (advance state { state.machine with heap := after }) := by
  simp only [step, blocked]

/-- Actual optional-binder verification retains both memo families on completion and pending outcomes. -/
theorem optionalBinder_step_valid [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (width : Nat) (emptyGuard : Guard)
    (conjoin : Guard → Guard → Guard) (state : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (valid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin state) (key : Nat × Nat) (body : Value Symbol Guard)
    (available : InternedProbeProvenance.Available state.machine.heap body) (next : Value Symbol Guard → Code Symbol Guard A) :
    SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin (step emptyGuard conjoin (.optionalBinder key body next) state).state := by
  have verified := SourceRecursiveIntersectionMaybeMu.verified key body state.machine.heap valid.machine.1 available
  have checked := construction_checked state.machine valid.machine _ InternedProbeProvenance.Available verified
  cases actual : SourceRecursiveIntersectionMaybeMu.maybeMu key body state.machine.heap with
  | done value after =>
    have finalValid := checked.valid
    have growth := checked.extension
    simp only [actual, construction, Result.state] at finalValid growth
    simp only [step, actual, Outcome.state]
    exact advance_valid width emptyGuard conjoin state valid _ finalValid growth
  | pending pending after =>
    have finalValid := checked.valid
    have growth := checked.extension
