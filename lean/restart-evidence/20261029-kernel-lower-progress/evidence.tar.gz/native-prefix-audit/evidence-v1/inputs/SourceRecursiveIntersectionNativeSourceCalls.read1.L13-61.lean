open InternedBinderProtocol IntersectionFlatMemoKeyDomain SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode

/-- Actual node start derives captured request identity, strong current facts, and its exact running cell. -/
theorem node_started_source [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (state selected current : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (valid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin state) (request actual : NodeRequest Symbol Guard)
    (ready : NodeReady state.machine request) (safe : SourceRecursiveIntersectionMemo.KeySafe width request.domain request.left request.right)
    (handle : Nat) (lookup : lookupNode width request state = (.memoized handle, selected))
    (demand : demandNode handle selected = (.evaluate actual, current)) :
    SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin current ∧ actual = request ∧ current.machine = state.machine ∧
      current.nodes.cells handle = some ⟨actual, .evaluating⟩ := by
  have selectedValid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin selected := by
    simpa only [lookup] using lookupNode_valid width emptyGuard conjoin state valid request ready safe
  have currentValid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin current := by
    simpa only [demand] using demandNode_valid width emptyGuard conjoin selected selectedValid handle
  obtain ⟨key, requested, published, machine⟩ := lookupNode_memoized request state selected handle lookup
  have selectedReady : NodeReady selected.machine request := by simpa only [machine] using ready
  have cells := demandNode_evaluate handle selected current actual demand
  have same : actual = request := node_request_exact width emptyGuard conjoin selected selectedValid request selectedReady key
    ⟨requested, safe⟩ handle published ⟨actual, .suspended⟩ cells.1
  have physical : current.machine = selected.machine := by simpa only [demand] using demandNode_machine handle selected
  exact ⟨currentValid, same, physical.trans machine, cells.2⟩

/-- Actual edge start derives captured row identity, strong current facts, and its exact running cell. -/
theorem edge_started_source [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (state selected current : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (valid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin state) (request actual : EdgeRequest Symbol Guard)
    (ready : EdgeReady state.machine request) (safe : SourceRecursiveIntersectionEdgeMemo.KeySafe width request.domain request.left request.right)
    (handle : Nat) (lookup : lookupEdge width request state = (handle, selected))
    (demand : demandEdge handle selected = (.evaluate actual, current)) :
    SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin current ∧ actual = request ∧ current.machine = state.machine ∧
      current.edges.cells handle = some ⟨actual, .evaluating⟩ := by
  have selectedValid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin selected := by
    simpa only [lookup] using lookupEdge_valid width emptyGuard conjoin state valid request ready safe
  have currentValid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin current := by
    simpa only [demand] using demandEdge_valid width emptyGuard conjoin selected selectedValid handle
  obtain ⟨published, machine⟩ := lookupEdge_selected request state selected handle lookup
  have selectedReady : EdgeReady selected.machine request := by simpa only [machine] using ready
  have cells := demandEdge_evaluate handle selected current actual demand
  have same : actual = request := edge_request_exact width emptyGuard conjoin selected selectedValid request selectedReady _
    ⟨rfl, safe⟩ handle published ⟨actual, .suspended⟩ cells.1
  have physical : current.machine = selected.machine := by simpa only [demand] using demandEdge_machine handle selected
  exact ⟨currentValid, same, physical.trans machine, cells.2⟩

/-- An actual completed native node hit derives stable guarded kernel replay without physical effects. -/
theorem node_ready_source [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (state selected current : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (valid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin state) (request : NodeRequest Symbol Guard)
    (ready : NodeReady state.machine request) (safe : SourceRecursiveIntersectionMemo.KeySafe width request.domain request.left request.right)
