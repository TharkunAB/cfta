import MicroCFTA.SourceRecursiveIntersectionKernelReturnDegree
import MicroCFTA.SourceRecursiveIntersectionKernelLowerSequencing

/-!
# All-outcome allocation bounds for an actual kernel Mu branch

The smaller-runtime hypothesis bounds the actual body heap.
The closed return theorem bounds its value when the body succeeds.
The optional binder bound includes probes and pending construction.
-/
namespace MicroCFTA.SourceRecursiveIntersectionKernel
open Cache InternedConstructorTemplates InternedProbeProvenance InternedNestedFacts
open InternedBinderProtocol IntersectionFlatMemoKeyDomain
