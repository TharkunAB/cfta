
/-- A finite first observation completes, fails, or reports its actual pending constructor. -/
inductive Terminal : Outcome width Symbol Guard A → Prop where
  | done (value : A) (state) : Terminal (.done value state)
  | failed (failure : Failure) (state) : Terminal (.failed failure state)
  | constructor (key : NodeKey) (code : Code Symbol Guard A) (state) : Terminal (.blocked (.constructor key) code state)

/-- An actual finite yielded prefix composes with a finite terminal continuation. -/
theorem terminal_after_trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (fuel : Nat) (code next : Code Symbol Guard A) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (trace : Steps emptyGuard conjoin fuel code state next after)
    (later : ∃ extra, Terminal (execute emptyGuard conjoin extra next after)) :
    ∃ total, Terminal (execute emptyGuard conjoin total code state) := by
  obtain ⟨extra, terminal⟩ := later
  refine ⟨fuel + extra, ?_⟩
  rw [execute_add, trace.execute, resume]
  exact terminal

/-- One actual yielded step composes with a finite terminal continuation. -/
theorem terminal_after_step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (code next : Code Symbol Guard A) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (one : step emptyGuard conjoin code state = .yielded next after)
    (later : ∃ fuel, Terminal (execute emptyGuard conjoin fuel next after)) :
    ∃ fuel, Terminal (execute emptyGuard conjoin fuel code state) :=
  terminal_after_trace emptyGuard conjoin 1 code next state after (.cons _ _ _ _ _ _ 0 one (.refl _ _)) later

/-- An actual failed body retains its exact failure and complete native state through outer code. -/
theorem execute_bind_failed [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (fuel : Nat) (code : Code Symbol Guard A) (next : A → Code Symbol Guard B)
    (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard) (failure : Failure)
    (done : execute emptyGuard conjoin fuel code state = .failed failure after) :
    execute emptyGuard conjoin fuel (code.bind next) state = .failed failure after := by
  induction fuel generalizing code state with
  | zero => cases done
  | succ fuel ih =>
