  | edge request resume =>
      have same := edge_step_machine emptyGuard conjoin request resume state
      rw [one] at same
      change after.machine = state.machine at same
      rw [same]
      exact ⟨valid, covered⟩

/-- Every actual finite yielded prefix retains valid constructor caches and its incoming payload coverage. -/
theorem Steps.covered [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (fuel : Nat) (code next : Code Symbol Guard A)
    (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (trace : Steps emptyGuard conjoin fuel code state next after) :
    InternedConstructorTemplates.Valid state.machine.heap → Covered pending state.machine.heap →
    InternedConstructorTemplates.Valid after.machine.heap ∧ Covered pending after.machine.heap := by
  induction trace with
  | refl => intro valid covered; exact ⟨valid, covered⟩
  | cons code state next after final result fuel one rest ih =>
      intro valid covered
      have retained := step_yielded_covered emptyGuard conjoin code next state after valid covered one
      exact ih retained.1 retained.2

end MicroCFTA.SourceRecursiveIntersectionNative
