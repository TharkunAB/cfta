open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace)
open SourceCurrentAllocatedNativeSemanticTraceReadback (current_inputs effects)
open SourceCurrentAllocatedNativePhysicalCompletion (Good)
open SourceEqualityNativeDemandMemo (Retained)
open SourceRecursiveIntersectionControl (decision identity pair)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Checked" => SourceEqualityNativeDemand.State
variable {width : Nat}

open SourceCurrentNativeMuBodyOrigins (Body)

variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]

/-- A completed Mu body derives its checked open child entry and exact request origin. -/
theorem trace {before after reader : Checked width} (writers : ∀ (handle : Nat) (request : NodeRequest Symbol Guard) (result : Value Symbol Guard),
      reader.native.nodes.cells handle = some ⟨request,.returned result⟩ →
        SourceCurrentNativeWriterReadyRetention.Written handle request result reader.native)
    (request : NodeRequest Symbol Guard) (fuel : Nat) (result : Value Symbol Guard)
    (good : Good before)
    (actual : Trace fuel (.code (compileMu request.domain request.left request.right)) before (.code (.pure result)) after)
    (retained : Retained after.native reader.native) : Body reader fuel request before result after := by
  obtain ⟨first,second,childFuel,bodyValue,middle,heap,leftId,rightId,count,child,available,binder,final,_⟩ :=
    SourceCurrentNativeMuWriterOrigins.trace request fuel before after result actual
  have one := SourceCurrentAllocatedNativeMuSource.enter_prefix request before first second leftId rightId
  have reached := SourceCurrentAllocatedNativePhysicalCompletion.step_invariants
    (.code (compileMu request.domain request.left request.right)) before good (current_inputs actual)
    (SourceCurrentAllocatedNativeCodeFields.compileMu_fields before.operations request.domain request.left request.right)
  rw [one] at reached
  have middleGood := (effects child reached.1 (by intro value; trivial)).1
  have middleRetained : Retained middle.native reader.native := by
    have next := SourceEqualityNativeDemandMemo.advance_retained middle.native {middle.native.machine with heap := heap}
    rw [final] at retained
    exact next.trans retained
