inductive Terminal : Outcome width Symbol Guard A → Prop where
  | done (value : A) (state) : Terminal (.done value state)
  | failed (failure : Failure) (state) : Terminal (.failed failure state)
  | constructor (key : NodeKey) (code : Code Symbol Guard A) (state) : Terminal (.blocked (.constructor key) code state)

/-- An actual finite yielded prefix composes with a finite terminal continuation. -/
theorem terminal_after_trace [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (fuel : Nat) (code next : Code Symbol Guard A) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (trace : Steps emptyGuard conjoin fuel code state next after)
    (later : ∃ extra, Terminal (execute emptyGuard conjoin extra next after)) :
    ∃ total, Terminal (execute emptyGuard conjoin total code state) := by
  obtain ⟨extra, terminal⟩ := later
  refine ⟨fuel + extra, ?_⟩
  rw [execute_add, trace.execute, resume]
  exact terminal

/-- One actual yielded step composes with a finite terminal continuation. -/
theorem terminal_after_step [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (code next : Code Symbol Guard A) (state after : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (one : step emptyGuard conjoin code state = .yielded next after)
