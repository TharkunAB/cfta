open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceEqualityNativeDemand
open SourceCurrentAllocatedNativePhysicalTraceCompletion (Trace)
open SourceCurrentAllocatedNativeSemanticTraceReadback (current_inputs effects)
open SourceCurrentAllocatedNativePhysicalCompletion (Good)
open SourceCurrentNativeEdgeWriterGrowth (History)
open SourceEqualityNativeDemandMemo (Retained)
open SourceRecursiveIntersectionControl (decision identity pair)
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Checked" => SourceEqualityNativeDemand.State
variable {width : Nat}

private theorem identity_keyable (value : Value Symbol Guard) (name : Nat) (named : identity value = some name) :
    ∃ input, IntersectionFlatMemoKey.input value.referenceOf = some input := by
  cases value with
  | reference reference => cases reference <;> simp_all [identity,Value.referenceOf,IntersectionFlatMemoKey.input]
  | empty | node | mu | union => simp_all [identity,Value.referenceOf,IntersectionFlatMemoKey.input]

variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]

/-- The actual entered body retains both checked states and final-reader request provenance. -/
def Body (reader : Checked width) (fuel : Nat) (request : NodeRequest Symbol Guard)
    (before : Checked width) (result : Value Symbol Guard) (after : Checked width) : Prop :=
  ∃ first second childFuel bodyValue middle heap,
    let entered := SourceRecursiveIntersectionEnvironment.enter before.native.machine.domains request.domain.key
      request.left request.right first second
    let entry := {before with native := advance before.native {before.native.machine with domains := entered.2}}
    identity request.left = some first ∧ identity request.right = some second ∧
    fuel = childFuel + 2 ∧ Good entry ∧
    Trace childFuel (.code (requestNode entered.1 (body request.left) (body request.right)))
      entry (.code (.pure bodyValue)) middle ∧ Good middle ∧
    SourceCurrentNativeForwardLineage.Forwarded reader
      ⟨entered.1,body request.left,body request.right⟩ entry middle bodyValue ∧
    Available middle.native.machine.heap bodyValue ∧
    SourceRecursiveIntersectionMaybeMu.maybeMu (pair first second) bodyValue middle.native.machine.heap =
      .done result heap ∧
    after = {middle with native := advance middle.native {middle.native.machine with heap := heap}}

/-- A completed Mu body derives its checked open child entry and exact request origin. -/
theorem trace {before after reader : Checked width} (history : History reader)
    (request : NodeRequest Symbol Guard) (fuel : Nat) (result : Value Symbol Guard)
    (good : Good before)
    (actual : Trace fuel (.code (compileMu request.domain request.left request.right)) before (.code (.pure result)) after)
    (retained : Retained after.native reader.native) : Body reader fuel request before result after := by
