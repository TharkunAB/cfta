# Proposed next public theorem

Status: UNPROVED audit target. This is not an installed Lean declaration.
No proof placeholder or axiom is introduced.

Use the existing native namespace and existing open names from NativeReturnLower.

```lean
theorem node_prefix_lower
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (source : InternedConstructorTemplates.State Symbol Guard)
    (facts : InternedNestedFacts.Facts source)
    (limit : Nat) (bounded : InternedMuDepthInventory.Bounded source limit)
    (holds : Guard → Language.Term Symbol → Bool) (width : Nat)
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (fuel : Nat)
    (request : NodeRequest Symbol Guard) (scope : NodeScope source request)
    (complete : Completes (view source holds) (nodeSemantic request))
    (state : SourceRecursiveIntersectionThunks.State width Symbol Guard)
    (valid : SourceRecursiveIntersectionThunks.Valid width emptyGuard conjoin state)
    (ready : NodeReady state.machine request)
    (growth : Grows source state.machine.heap)
    (history : Extends source.nodes.issued state.machine.heap.nodes.issued)
    (semantic : SemanticHeap state.machine.heap)
    (opened : InternedOpenDepthReadback.Heap state.machine.heap)
    (ranges : WordRanges emptyGuard conjoin (.node request .pure) state) :
    InternedStoredPlanBinderDepthProgress.Lower state.machine.heap
      (limit + requiredFuel (view source holds) (nodeSemantic request) complete)
      (execute emptyGuard conjoin fuel (.node request .pure) state).state.machine.heap
```

There is no returned-value equation, endpoint invariant, completion existence,
ActiveAbove, Idle, or supplied future body/value/heap family in this target.
The same fuel, request, full native state, and actual Outcome.state are retained.
The original initial heap can already contain older bodies above the new bound;
Lower keeps its exact old-record alternative. Absolute Bounded follows only
with the corresponding original/cold-heap argument.
