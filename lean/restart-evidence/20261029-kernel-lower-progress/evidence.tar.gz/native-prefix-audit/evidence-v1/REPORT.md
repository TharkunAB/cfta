# Native stopped-prefix allocation-bound audit

Date: 2026-10-29 19:56:37 CET.
Status: SOURCE-ONLY AUDIT. The proposed next theorem is UNPROVED.
Root reports checked source c63fd18298a6060b39076eea484dc5db26f8a997 and Board734.
This child did not run Git, inspect the board, or verify a repository head.

The missing step is a Lower proof for the actual unfinished native continuation.
It is not a missing all-outcome kernel theorem. NativeReturnLower.node_return_lower
already transfers a literal native DONE observation through native_node_correct
to the exact kernel endpoint and then Kernel.node_lower. The same transfer is
closed for successful rows. That proof has no route for a yielded native result
or a blocked/failed body without a DONE correspondence witness.

The smallest useful public target is node_prefix_lower, written in full in
TARGET-STATEMENT.md. Keep the original NodeScope/Completes and current strong
Valid/NodeReady/source-growth/history/SemanticHeap/OpenHeap gates. Keep the
existing WordRanges gate. Replace the successful endpoint premise with the
actual Outcome.state projection for every runtime fuel. Do not add a future
heap, value, or completed-execution supplier.

The exact invariant gap

A memoized miss yields a compiled body with a literal finishNode/finishEdge
frame. Code.Safe and Code.Below BOTH reduce to False on those frames. Therefore
neither can simply be propagated as the invariant of all residual native code.
Evaluation and Bounds describe completed nested native evaluations only.
Steps describes actual yielded prefixes, but carries neither a body-degree
ceiling nor the original owner scope/rank of an optionalBinder instruction.
Steps.covered supplies constructor Valid plus payload coverage, not the full
semantic/open heap or a Mu body-depth ceiling. These distinctions appear in
the exact copied definitions and statements; none is a renaming of another.

Recommended proof route

1. Prove concrete initial-node and compiled-node/compiled-edge prefix observers
   over actual finite native observations. Use existing Steps and
   steps_bind_cases to distinguish a prefix inside an actual body from a
   completed body followed by an actual continuation prefix. Keep the original
   source request scope, semantic rank, and actual owner frame in the proof
   context. Do not invent a public arbitrary-residual Safe premise, which the
   generated finish frames already contradict.
2. At a completed inner request, reuse native_node_correct/native_edge_correct
   and closed node/edge_return_degree. At a completed compiled body, reuse
   Bounds.correct with compileNode/compileEdge body safety and Meaning's body
   readback, as the existing nodeStarted correctness proof does. Those actual
   completed observations derive strong Valid, Extension, available result,
   SemanticHeap/OpenHeap, and the result degree. Existing cell-retention plus
   finishNode_valid/finishEdge_valid support strong memo validity at the real
   completion frame. No external return theorem is an input to the target.
3. The essential new site fact is: an actual reached optionalBinder belongs to
   an actual compileMu owner, and its body is the result of that owner's
   completed entered child. Derive that child's original NodeScope/Completes
   and strict smaller semantic rank from the original owner. With the exact
   successful child observation, closed return degree gives
   valueDepth body + 1 <= limit + owner rank <= the initial request ceiling.
   Availability and current SemanticHeap/OpenHeap must also be derived there.
   Existing generic constructor_trace identifies pair/body/site/returned heap,
   but does NOT supply this owner scope or degree fact.
4. Apply the already proved SourceRecursiveIntersectionMaybeMu.lower at that literal site. It covers
   every complete new record, including probes and pending construction.
   Lower.mono raises its body+1 ceiling; Lower.trans combines it with the
   accumulated prefix bound. Preserve the actual advanced heap when the result
   is blocked constructor. This is the main allocating terminal branch.
5. Ordinary jobs emitted by these compilers are makeEdge, makeNode, and
   makeUnion. Their no-new-Mu theorems preserve Lower. Domain entry and reads
   retain the heap. Memo lookup/demand and finish frames retain the machine or
   heap. They must retain the accumulated bound when execution stops there.
   Do not claim the same fact for an arbitrary Work program without inspecting
   its constructor operation.

A generic all-outcome bind inversion can reduce repeated bookkeeping.
steps_bind_cases already supplies the yielded-prefix split. step_bind,
execute_bind_failed, execute_bind_constructor, and constructor_trace supply
existing terminal pieces. The missing substantive proof is the retained
original owner/rank and actual-body-return fact through native continuations,
not successful evaluation existence. The specialized SourceCurrent native
origin modules use Checked wrappers, Physical Trace, Good, and writer-history
premises; they are not a direct generic theorem about these Symbol/Guard
Native.execute inputs. Reusing them would require a genuine bridge, not a cast.

Exact outcome scopes

- Native fuel exhaustion is yielded residual code: execute 0 returns yielded.
  Kernel fuel exhaustion is failed exhausted. Their tags cannot be equated.
  A zero-step native observation has Lower.refl at the original heap.
- A native DONE result already transfers to the exact kernel endpoint through
  native_node_correct and node_return_lower. Completed inner calls can be used
  in the same way at their actual starting heaps and original child scopes.
- Memo absent/busy blocks do not change the machine at that immediate step.
  NativePrefixCoverage.node_step_machine/edge_step_machine already prove this
  for every demand case. They preserve an already established prefix bound;
  they do not bound all earlier prefix allocations by themselves.
- A native failed source instruction leaves the current heap unchanged, but
  its earlier prefix still needs the invariant. Matching a failure label is
  not a kernel endpoint correspondence theorem.
- Pending constructor may change the heap before the block. constructor_trace
  retains that literal changed heap. SourceRecursiveIntersectionMaybeMu.lower already bounds this
  local effect once the site's actual body and heap facts have been derived.
- Existing native progress results require BodiesBelow/ActiveAbove and conclude
  a finite terminal observation. Those extra gates are not present here, and
  terminal observations include pending construction. They do not replace the
  requested all-prefix safety proof or supply universal completed replay.

Evidence and limits

Eight individual requests acquired an entire Lean file, counting the two
repeat reads used to repair truncated displays. Across all literal cuts,
seven distinct source files were acquired in full; KernelMuLower is the one
whole source assembled from overlapping cuts. The manifest records both counts,
each requested/effective cut, and complete source identities. The final whole
reviews of PrefixCoverage and Api were explicitly repeated without truncation.
Several exploratory batches were truncated; these are disclosed and are not
claimed as whole reviews. All seven complete source identities were ultimately
reviewed through exact displayed whole reads or complete numbered cuts.

The proposed statement is documentation, not a Lean declaration, axiom, or
placeholder. No proof was compiled or evaluated. There is no claim that native
prefix Lower, prefix absolute Bounded, or eventual successful native completion
has now been proved. No repo or prior frozen area was modified. No Haskell
change, compiler/evaluator/native job, Git, network, or board operation was made.
