
/-- Run matched source edge requests before canonical node construction. -/
def node [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (call : Value Symbol Guard → Value Symbol Guard → Machine Symbol Guard → Result Symbol Guard (Value Symbol Guard))
    (left right : List (EdgeValue Symbol Guard)) (state : Machine Symbol Guard) : Result Symbol Guard (Value Symbol Guard) :=
  (walk (fun rows => edge emptyGuard conjoin call rows.1 rows.2) (pairs left right) state).bind fun values after =>
    work (makeNode values) after

/-- Execute the actual source branch with ordered child requests and both physical cache families. -/
def onNode [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (call : Interned DomainKey → Value Symbol Guard → Value Symbol Guard → Machine Symbol Guard → Result Symbol Guard (Value Symbol Guard))
    (domain : Interned DomainKey) (left right : Value Symbol Guard) (state : Machine Symbol Guard) :
    Result Symbol Guard (Value Symbol Guard) :=
  match decision domain.key left right with
