    pair ∈ pairs left right ↔ pair.1 ∈ left ∧ pair.2 ∈ right ∧ pair.1.entry.key.symbol = pair.2.entry.key.symbol := by
  rw [pairs, SymbolicHashJoin.hashJoin_member]
  constructor
  · rintro ⟨first, firstIn, second, secondIn, same, rfl⟩
    exact ⟨firstIn, secondIn, same⟩
  · rintro ⟨firstIn, secondIn, same⟩
    exact ⟨pair.1, firstIn, pair.2, secondIn, same, rfl⟩

/-- Ordered matched source row requests retain complete resident edge records. -/
theorem rows_checked [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
