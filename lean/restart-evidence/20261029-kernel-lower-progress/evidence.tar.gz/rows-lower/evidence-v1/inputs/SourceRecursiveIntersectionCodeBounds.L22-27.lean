
/-- A recursive row request retains original scope and strictly decreases the current body limit. -/
def EdgeBelow [DecidableEq Symbol] (source : InternedConstructorTemplates.State Symbol Guard)
    (holds : Guard → Language.Term Symbol → Bool) (bound : Nat) (request : EdgeRequest Symbol Guard) : Prop :=
  EdgeScope source request ∧ ∃ complete : Completes (view source holds) (SourceRecursiveIntersectionNative.edgeSemantic holds request),
    requiredFuel (view source holds) (SourceRecursiveIntersectionNative.edgeSemantic holds request) complete < bound
