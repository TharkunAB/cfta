
/-- Guarded edge calls retain complete ordered child records and canonical physical edge results. -/
theorem edge_checked [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (call : Interned DomainKey → Value Symbol Guard → Value Symbol Guard → Machine Symbol Guard → Result Symbol Guard (Value Symbol Guard))
    (calls : Calls call) (domain : Interned DomainKey) (left right : EdgeValue Symbol Guard) (state : Machine Symbol Guard)
    (valid : Valid state) (known : Domain state domain) (leftResident : EdgeResident state.heap left) (rightResident : EdgeResident state.heap right) :
    Checked state (edge emptyGuard conjoin (call domain) left right state) (fun after value => EdgeResident after.heap value) := by
  unfold edge
  split
  · have children := children_checked call calls domain (left.children.zip right.children) state valid known (by
      intro pair member
      have contained := List.of_mem_zip member
      exact ⟨valid.1.cached.edges left.entry.key left leftResident pair.1 contained.1,
        valid.1.cached.edges right.entry.key right rightResident pair.2 contained.2⟩)
    apply checked_bind state _ _ _ _ children
    intro values after returned afterValid available
    exact work_checked after afterValid _ EdgeResident
      (InternedNestedFacts.edge_verified _ _ values after.heap afterValid.1 available)
  · exact work_checked state valid _ EdgeResident
      (InternedNestedFacts.edge_verified _ _ [.empty] state.heap valid.1
        (by intro value member; simp only [List.mem_singleton] at member; subst value; exact empty_available state.heap))

