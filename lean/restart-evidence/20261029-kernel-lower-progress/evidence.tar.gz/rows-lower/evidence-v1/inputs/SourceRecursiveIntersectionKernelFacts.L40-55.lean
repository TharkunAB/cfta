  canonical : Canonical domain.key
  typed : Typed domain.key
  bindings : AvailableBindings state.heap domain.key

/-- An earlier source domain remains valid after later caller effects. -/
theorem Domain.grows (domain : Interned DomainKey) (known : Domain before domain) (extension : Extension before after) :
    Domain after domain := by
  refine ⟨⟨known.represented.1, ?_⟩, known.canonical, known.typed,
    known.bindings.grows before.heap after.heap domain.key extension.heap extension.history⟩
  by_cases empty : domain.key = IntersectionEmptyDomain.emptyKey
  · simpa only [empty, ite_true] using known.represented.2
  · obtain ⟨entry, present, same⟩ := by simpa only [empty, ite_false] using known.represented.2
    simpa only [empty, ite_false] using
      (show ∃ entry, after.domains.table domain.key = some entry ∧ domain.identity = entry.identity + 1 from
        ⟨entry, extension.domains _ _ present, same⟩)

