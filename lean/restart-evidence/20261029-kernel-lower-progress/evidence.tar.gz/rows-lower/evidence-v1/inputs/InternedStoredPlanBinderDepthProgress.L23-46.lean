    initial.nodeRecords key = some (.mu entry body depth ordinary) ∨ valueDepth body < bound

variable {initial : State Symbol Guard} {bound : Nat}

/-- Every initial record retains its own exact payload. -/
theorem lower_refl (state : State Symbol Guard) (bound : Nat) : Lower state bound state := by
  intro key entry body depth ordinary present
  exact Or.inl present

/-- Effects with no new Mu preserve the initial-record or lower-depth alternatives. -/
theorem preserve (before after : State Symbol Guard) (lower : Lower initial bound before)
    (old : NoNewMu before after) : Lower initial bound after := by
  intro key entry body depth ordinary present
  exact lower key entry body depth ordinary (old key entry body depth ordinary present)

/-- Sequencing retains the bound at the exact completed or pending cache. -/
theorem bind_lower (outcome : Outcome Symbol Guard First)
    (next : First → State Symbol Guard → Outcome Symbol Guard Result) (lower : Lower initial bound outcome.state)
    (later : ∀ value after, outcome = .done value after → Lower initial bound after → Lower initial bound (next value after).state) :
    Lower initial bound (outcome.bind next).state := by
  cases outcome with
  | pending => exact lower
  | done value after => exact later value after rfl lower

