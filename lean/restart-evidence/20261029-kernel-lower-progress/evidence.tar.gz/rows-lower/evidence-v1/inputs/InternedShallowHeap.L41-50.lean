/-- Ordinary source construction makes no new Mu record. -/
theorem makeNode_noNewMu [DecidableEq (EdgeKey Symbol Guard)] (edges : List (EdgeValue Symbol Guard))
    (state : State Symbol Guard) : NoNewMu state (run (makeNode edges) state).2 := by
  unfold makeNode
  dsimp only
  split
  · exact noNewMu_refl state
  · exact nodeStep_noNewMu _ _ state (by intros; simp [identifyNode])

/-- Every source union branch preserves the existing Mu payload set. -/
