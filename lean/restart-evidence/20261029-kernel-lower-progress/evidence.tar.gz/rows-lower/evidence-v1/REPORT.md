# All-outcome row and node allocation bound

Date: 2026-10-29 19:47:37 CET.
Status: UNTESTED source-only candidate. Root owns compilation and repository edits.

The only export is `SourceRecursiveIntersectionKernel.rows_lower`.
It has exactly the requested argument order, recorded in manifest.json.
Its all-outcome nodeIH is the same explicit local runtime-fuel hypothesis as
union_lower. There is no done equation, returned value, or returned machine
premise. The conclusion is Lower from the actual input heap at limit + bound
to the exact `.state.heap` of the actual Kernel.node execution.

Each rowBounds witness gives original EdgeScope, semantic Completes, and the
strict smaller semantic rank. edge_result_lower covers every actual row
outcome at that rank. Lower.mono raises the rank to the parent's bound.
The generic walk_lower keeps the exact heap if a row fails, including any
earlier row and child effects. It does not require a successful whole walk.

The local successful-row invariant retains Valid, Domain, residency of every
original pair, original Grows and issued history, SemanticHeap, and OpenHeap.
edge_checked supplies actual Valid and Extension. The already proved CLOSED
row_result_degree supplies actual returned SemanticHeap and OpenHeap.
These are derived from the same observed row call at the same fuels and
endpoints. They are not assumed as a return-preservation function.
All original rows transfer through edge_grows. Domain and original histories
transfer through the same actual Extension. This use of the closed degree
proof creates no dependency cycle: that proof uses the older rows_degree,
not the new rows_lower or the new Lower driver.

pairs_member derives initial pair residency from the supplied left/right
resident rows. Kernel.node retains the actual hash-join order and every row
occurrence. Generic result_bind_lower preserves a failed walk unchanged.
After a successful walk, makeNode_noNewMu and the existing preserve theorem
retain the accumulated bound at the actual constructor endpoint. Empty row
lists, arity rejection, exhausted calls, and pending child failures remain
within the exact all-outcome observation.

No future body-degree gate, future heap supplier, current-heap Bounded
premise, fresh model, or source/prepared identity cast is added. Root must
supply nodeIH from the smaller runtime-fuel induction step in the final
Lower driver. This helper does not itself assert that final theorem.

The candidate has 92 lines and 6521 bytes. SHA256:
`f5dc1ec9aa3b626455a9ccaa3530079040f46ef01cf0730c8aea527ef6c2bb7b`.
The full candidate and exact public statement were reviewed without
truncation. The full theorem and exact nodeIH statements are copied here.

Five repository source files were requested and reviewed whole, below the
limit of eight. All other acquisitions are literal cuts. Source hashes,
numbered cut identities, and exact snapshots are retained in manifest.json.
No truncated output is claimed as whole review. Root reported the edge lower
interface stable while repairing its local arity-mismatch proof. This task
uses that exact interface and does not modify the dependency.

Only candidate-v1 exists; no compiler was run and no failed compiler draft
exists in this area. Candidate-v1 and evidence-v1 are frozen on delivery.
No prior evidence or sealed area was changed. No repository, Git, compiler,
evaluator, native, network, or board operation was performed. No placeholder,
axiom, budget change, or linter suppression was added. No Haskell change was made.
