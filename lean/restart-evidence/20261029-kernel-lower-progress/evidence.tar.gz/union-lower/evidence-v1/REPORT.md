# All-outcome union allocation bound

Date: 2026-10-29 19:44:41 CET.
Status: UNTESTED source-only candidate. Root owns compiler and repository operations.

`SourceRecursiveIntersectionKernel.union_lower` is the only new export.
It proves `Lower state.heap (limit + bound)` at the exact `.state.heap` of the
literal ordered union walk and its `makeUnion` continuation. It takes no
successful-result equation and no returned-value or returned-machine premise.
It covers failed child execution, including exhausted and pending failures,
and preserves the exact reached heap with all earlier child effects.

The original source, its Facts, its Bounded source limit, semantic view, and
runtime fuel remain fixed. The explicit nodeIH quantifies the original
NodeScope, semantic Completes, current Valid/NodeReady, original Grows and
issued history, current SemanticHeap and current OpenHeap. It concludes
Lower relative to that child's own actual input heap at its own semantic rank.
It has no after/value/done premise. Root must supply it from the smaller
runtime-fuel induction hypothesis in the final theorem. No assumed future
result or body-value family is added to the final claim.

The generic walk_lower carries a local conjunction of actual inputs.
For each member, the actual original NodeBelow provides scope and a semantic
rank below the parent bound. Lower.mono raises the child's bound to the parent
bound. The actual successful-child branch derives Valid and Extension with
execute_checked. The already closed node_result_degree supplies the actual
returned SemanticHeap and OpenHeap. Domain, every original member, and the
other operand transfer through that same Extension. Original Grows and
issued history compose. This preservation is derived from existing theorems;
it is not a second supplier argument to union_lower.

result_bind_lower retains any failed walk's exact heap. On a completed walk,
InternedStoredPlanBinderDepthProgress.preserve and makeUnion_noNewMu retain
the accumulated Lower at the actual constructor endpoint. Both operand
orders and every member-list length are covered. No current-heap Bounded
premise appears. No depth existence or semantic model statement is added.

The candidate has 108 lines and 7247 bytes. SHA256:
`3c9c9f87a27e3e4d0c1f13f7b984dc32c13ff7d1e3c960651a472dd7b3735e5a`.
Its complete statement and exact nodeIH statement are copied beside this report.
The candidate was reviewed in consecutive literal cuts 1-56 and 57-108.

Two repository Lean files were requested and reviewed whole, below the limit
of eight. Every other source read is a literal numbered cut in manifest.json.
All source outputs fit their tool budgets; no truncated output is claimed as
whole review. Full input file hashes identify the files but do not claim
whole-file review. The two new algebra/sequencing modules were unchecked when
Root assigned this task; their snapshots record the exact used contracts.

The initial 107-line draft is preserved in draft-v1. Before submission, the
candidate was revised to compute NodeReady before destructuring its local
conjunction. The exact diff is preserved. Neither version was compiled here;
there is no failed compiler result to report. Candidate-v1 and evidence-v1
are frozen on delivery. No earlier sealed area was changed.

No repository edit, Git, compiler, evaluator, native job, network, or board
operation was performed. No placeholder, axiom, budget change, or linter
suppression was added. No Haskell change was made.
