theorem makeNode_noNewMu [DecidableEq (EdgeKey Symbol Guard)] (edges : List (EdgeValue Symbol Guard))
    (state : State Symbol Guard) : NoNewMu state (run (makeNode edges) state).2 := by
  unfold makeNode
  dsimp only
  split
  · exact noNewMu_refl state
  · exact nodeStep_noNewMu _ _ state (by intros; simp [identifyNode])

/-- Every source union branch preserves the existing Mu payload set. -/
theorem makeUnion_noNewMu [DecidableEq (EdgeKey Symbol Guard)] (values : List (Value Symbol Guard))
    (state : State Symbol Guard) : NoNewMu state (run (makeUnion values) state).2 := by
  unfold makeUnion
  split
  · exact noNewMu_refl state
  · exact noNewMu_refl state
  · split
    · exact makeNode_noNewMu _ state
    · simp only [run]
      exact nodeStep_noNewMu _ _ state (by intros; simp)

