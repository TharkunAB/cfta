import MicroCFTA.InternedOpenDepthExecution
import MicroCFTA.InternedStoredLeafShape

/-!
# New Mu bodies have lower depth during actual repaired unfolding

Zero-depth lexical inputs remain fixed through source callbacks. Each new
Mu body comes from a strict subplan and satisfies its proved source bound.
All complete records in the returned cache are covered, including probes.
-/
namespace MicroCFTA.InternedStoredPlanBinderDepthProgress
open Cache InternedConstructorTemplates InternedRecordCoherence InternedProbeProvenance
open InternedNestedConstruction (Syntax EdgeSyntax Outcome work request)
open InternedNestedFacts InternedNestedRequestFacts InternedFreshProbeKeys InternedShallowHeap
open InternedNestedProvenance (Values depth_available ordinary_available)
open InternedFreshOrdinaryConstruction InternedFreshOrdinaryFacts InternedFreshOrdinaryContext
open InternedStoredPlanBinderDepth
open InternedBinderProtocol (Reference NodeKey)

/-- Each complete Mu is an exact initial record or has body depth below the fixed source bound. -/
def Lower (initial : State Symbol Guard) (bound : Nat) (state : State Symbol Guard) : Prop :=
  ∀ key entry body depth ordinary, state.nodeRecords key = some (.mu entry body depth ordinary) →
    initial.nodeRecords key = some (.mu entry body depth ordinary) ∨ valueDepth body < bound

variable {initial : State Symbol Guard} {bound : Nat}

/-- Every initial record retains its own exact payload. -/
theorem lower_refl (state : State Symbol Guard) (bound : Nat) : Lower state bound state := by
  intro key entry body depth ordinary present
  exact Or.inl present

/-- Effects with no new Mu preserve the initial-record or lower-depth alternatives. -/
theorem preserve (before after : State Symbol Guard) (lower : Lower initial bound before)
    (old : NoNewMu before after) : Lower initial bound after := by
  intro key entry body depth ordinary present
  exact lower key entry body depth ordinary (old key entry body depth ordinary present)

/-- Sequencing retains the bound at the exact completed or pending cache. -/
theorem bind_lower (outcome : Outcome Symbol Guard First)
    (next : First → State Symbol Guard → Outcome Symbol Guard Result) (lower : Lower initial bound outcome.state)
    (later : ∀ value after, outcome = .done value after → Lower initial bound after → Lower initial bound (next value after).state) :
    Lower initial bound (outcome.bind next).state := by
  cases outcome with
  | pending => exact lower
  | done value after => exact later value after rfl lower

/-- First-writer completion installs its lower-depth candidate or retains an exact earlier record. -/
theorem complete_lower (smart : Bool) (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard)
    (state : State Symbol Guard) (lower : Lower initial bound state) (small : valueDepth body < bound) :
    Lower initial bound (complete smart entry body depth ordinary state).state := by
  intro key actual actualBody actualDepth actualOrdinary present
  rcases record_cases state.nodeRecords (muKey depth ordinary) key (.mu entry body depth ordinary)
    (.mu actual actualBody actualDepth actualOrdinary) present with old | ⟨_, same⟩
  · exact lower key actual actualBody actualDepth actualOrdinary old
  · cases same
    exact Or.inr small

mutual
/-- Every actual source allocation respects the enclosing plan bound from zero-depth lexical inputs. -/
theorem build_lower [DecidableEq (EdgeKey Symbol Guard)] (expression : Syntax Symbol Guard)
    (environment : List (Value Symbol Guard)) (state : State Symbol Guard) (context : Context state environment)
    (cached : InternedFreshOrdinaryDepthHeap.Heap state) (heap : InternedOpenDepthReadback.Heap state)
    (lower : Lower initial bound state) (zeros : ∀ value ∈ environment, valueDepth value = 0)
    (limited : syntaxDepth expression ≤ bound) : Lower initial bound (build expression environment state).state := by
  cases expression with
  | empty | var => simpa only [build, Outcome.state] using lower
  | node edges =>
      rw [build]
      exact bind_lower _ _ (buildEdges_lower edges environment state context cached heap lower zeros
