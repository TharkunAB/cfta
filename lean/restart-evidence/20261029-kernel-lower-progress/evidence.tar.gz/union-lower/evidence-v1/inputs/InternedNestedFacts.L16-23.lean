
/-- The three source record invariants used by nested construction. -/
structure Facts (state : State Symbol Guard) : Prop where
  coherent : Coherent state
  cached : Cached state
  linked : Linked state

/-- The source starts with all record invariants established. -/
