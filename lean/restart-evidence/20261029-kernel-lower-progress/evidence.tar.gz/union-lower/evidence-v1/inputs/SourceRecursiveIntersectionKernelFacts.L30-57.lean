  ⟨grows_trans first.heap second.heap, extends_trans first.history second.history, extends_trans first.domains second.domains⟩

/-- All earlier complete physical records survive recursive caller effects. -/
theorem Extension.available {before after : Machine Symbol Guard} (extension : Extension before after) (value : Value Symbol Guard)
    (available : Available before.heap value) : Available after.heap value :=
  available.grows before.heap after.heap extension.heap extension.history

/-- A source domain retains its actual cache identity and original complete Mu bindings. -/
structure Domain (state : Machine Symbol Guard) (domain : Interned DomainKey) : Prop where
  represented : IntersectionEmptyDomain.Represents state.domains domain.key domain
  canonical : Canonical domain.key
  typed : Typed domain.key
  bindings : AvailableBindings state.heap domain.key

/-- An earlier source domain remains valid after later caller effects. -/
theorem Domain.grows (domain : Interned DomainKey) (known : Domain before domain) (extension : Extension before after) :
    Domain after domain := by
  refine ⟨⟨known.represented.1, ?_⟩, known.canonical, known.typed,
    known.bindings.grows before.heap after.heap domain.key extension.heap extension.history⟩
  by_cases empty : domain.key = IntersectionEmptyDomain.emptyKey
  · simpa only [empty, ite_true] using known.represented.2
  · obtain ⟨entry, present, same⟩ := by simpa only [empty, ite_false] using known.represented.2
    simpa only [empty, ite_false] using
      (show ∃ entry, after.domains.table domain.key = some entry ∧ domain.identity = entry.identity + 1 from
        ⟨entry, extension.domains _ _ present, same⟩)

/-- The reserved empty source domain requires no cache allocation or physical binding. -/
theorem empty_domain (state : Machine Symbol Guard) : Domain state IntersectionEmptyDomain.emptyDomain := by
