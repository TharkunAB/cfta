
/-- Original node inputs stay available while the thunk is suspended or running. -/
def NodeReady (machine : Machine Symbol Guard) (request : NodeRequest Symbol Guard) : Prop :=
  Domain machine request.domain ∧ Available machine.heap request.left ∧ Available machine.heap request.right

/-- Original edge inputs retain their complete resident row records. -/
def EdgeReady (machine : Machine Symbol Guard) (request : EdgeRequest Symbol Guard) : Prop :=
  Domain machine request.domain ∧ EdgeResident machine.heap request.left ∧ EdgeResident machine.heap request.right

