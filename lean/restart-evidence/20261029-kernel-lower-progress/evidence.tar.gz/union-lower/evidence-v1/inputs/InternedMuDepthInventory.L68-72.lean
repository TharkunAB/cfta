def Bounded (state : State Symbol Guard) (limit : Nat) : Prop :=
  ∀ key entry body depth ordinary, state.nodeRecords key = some (.mu entry body depth ordinary) → valueDepth body < limit

/-- The finite initial inventory supplies an upper bound without bounding future cached depth. -/
theorem initial_bounded (state : State Symbol Guard) (facts : InternedNestedFacts.Facts state) :
