open InternedBinderProtocol IntersectionFlatMemoKeyDomain SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks
open SourceRecursiveIntersectionInputView IntersectSchedule

/-- A recursive node request retains original scope and strictly decreases the current body limit. -/
def NodeBelow [DecidableEq Symbol] (source : InternedConstructorTemplates.State Symbol Guard)
    (holds : Guard → Language.Term Symbol → Bool) (bound : Nat) (request : NodeRequest Symbol Guard) : Prop :=
  NodeScope source request ∧ ∃ complete : Completes (view source holds) (SourceRecursiveIntersectionNative.nodeSemantic request),
    requiredFuel (view source holds) (SourceRecursiveIntersectionNative.nodeSemantic request) complete < bound

/-- A recursive row request retains original scope and strictly decreases the current body limit. -/
def EdgeBelow [DecidableEq Symbol] (source : InternedConstructorTemplates.State Symbol Guard)
    (holds : Guard → Language.Term Symbol → Bool) (bound : Nat) (request : EdgeRequest Symbol Guard) : Prop :=
  EdgeScope source request ∧ ∃ complete : Completes (view source holds) (SourceRecursiveIntersectionNative.edgeSemantic holds request),
    requiredFuel (view source holds) (SourceRecursiveIntersectionNative.edgeSemantic holds request) complete < bound
