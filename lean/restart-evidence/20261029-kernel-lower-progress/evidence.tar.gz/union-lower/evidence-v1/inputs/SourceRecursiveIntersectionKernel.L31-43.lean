
/-- Every source outcome retains its exact current caches. -/
inductive Result (Symbol Guard A : Type) where
  | done (value : A) (state : Machine Symbol Guard)
  | failed (failure : Failure) (state : Machine Symbol Guard)

/-- Read the actual cache after success or failure. -/
def Result.state : Result Symbol Guard A → Machine Symbol Guard
  | .done _ state | .failed _ state => state

/-- Later source calls execute only after the previous value completes. -/
def Result.bind (result : Result Symbol Guard A)
    (next : A → Machine Symbol Guard → Result Symbol Guard B) : Result Symbol Guard B :=
