        · exact finalResults output present
  have observed : ((walk call members state).bind
      fun values middle => work (makeUnion values) middle) = .done value after := by
    simpa only [callSame] using done
  cases walked : walk call members state with
  | failed failure middle =>
      simp only [walked, Result.bind] at observed
      cases observed
  | done values middle =>
      obtain ⟨middleValid, _middleExtension, middleSemantic, middleOpened, outputs⟩ :=
        visit members state middle values ((walk_done_iff call members state values middle).mp walked)
          bounds valid known available membersAvailable growth history semantic opened
      have constructed : work (makeUnion values) middle = .done value after := by
        simpa only [walked, Result.bind] using observed
      obtain ⟨sameValue, sameState⟩ := work_done (makeUnion values) middle value after constructed
      rw [sameValue, sameState]
      exact ⟨SourceRecursiveIntersectionSemanticHeap.union values middle.heap middleSemantic
          (fun output present => (outputs output present).1),
        SourceRecursiveIntersectionOpenDepthEffects.union values middle.heap middleOpened,
        makeUnion_le values middle.heap middleValid.1.coherent middleValid.1.cached middleValid.1.linked
          (fun output present => (outputs output present).1) (limit + parentRank)
