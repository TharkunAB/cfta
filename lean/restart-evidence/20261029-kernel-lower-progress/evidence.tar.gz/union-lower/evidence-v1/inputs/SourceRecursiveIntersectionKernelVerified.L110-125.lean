      exact unsupported_checked _ _ state valid

/-- Every bounded recursive source call derives complete state invariants and available successful results. -/
theorem execute_checked [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (fuel : Nat) : Calls (execute (Symbol := Symbol) emptyGuard conjoin fuel) := by
  induction fuel with
  | zero =>
      intro domain left right state valid known leftAvailable rightAvailable
      simp only [execute]
      exact checked_failed state valid .exhausted _
  | succ fuel ih =>
      intro domain left right state valid known leftAvailable rightAvailable
      simp only [execute]
      exact onNode_checked emptyGuard conjoin _ ih domain left right state valid known leftAvailable rightAvailable

end MicroCFTA.SourceRecursiveIntersectionKernel
