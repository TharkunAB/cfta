open SourceRecursiveIntersectionSemanticHeap (SemanticHeap)

/-- Ordered union requests pass actual returned heaps to the remaining requests. -/
theorem union_degree {Symbol Guard : Type}
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (source : InternedConstructorTemplates.State Symbol Guard)
    (_facts : InternedNestedFacts.Facts source) (limit : Nat)
    (_bounded : InternedMuDepthInventory.Bounded source limit)
    (holds : Guard → Language.Term Symbol → Bool)
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (fuel : Nat)
    (nodeIH : ∀ (request : NodeRequest Symbol Guard) (_scope : NodeScope source request)
      (complete : Completes (view source holds) (nodeSemantic request))
      (state after : Machine Symbol Guard) (_valid : Valid state) (_ready : NodeReady state request)
      (_growth : Grows source state.heap)
      (_history : Extends source.nodes.issued state.heap.nodes.issued)
      (_semantic : SemanticHeap state.heap) (_opened : InternedOpenDepthReadback.Heap state.heap)
      (value : Value Symbol Guard)
      (_done : execute emptyGuard conjoin fuel request.domain request.left request.right state = .done value after),
      SemanticHeap after.heap ∧ InternedOpenDepthReadback.Heap after.heap ∧
        valueDepth value ≤ limit + requiredFuel (view source holds) (nodeSemantic request) complete)
    (domain : Interned DomainKey) (members : List (Value Symbol Guard))
    (other : Value Symbol Guard) (left : Bool) (parentRank : Nat)
    (state after : Machine Symbol Guard) (valid : Valid state) (known : Domain state domain)
    (available : Available state.heap other)
    (membersAvailable : ∀ member ∈ members, Available state.heap member)
    (growth : Grows source state.heap)
    (history : Extends source.nodes.issued state.heap.nodes.issued)
    (semantic : SemanticHeap state.heap) (opened : InternedOpenDepthReadback.Heap state.heap)
    (memberBounds : ∀ member ∈ members,
      if left then NodeBelow source holds parentRank ⟨domain, member, other⟩
      else NodeBelow source holds parentRank ⟨domain, other, member⟩)
    (value : Value Symbol Guard)
    (done : ((walk (fun member =>
      if left then execute emptyGuard conjoin fuel domain member other
      else execute emptyGuard conjoin fuel domain other member) members state).bind
      fun values middle => work (makeUnion values) middle) = .done value after) :
    SemanticHeap after.heap ∧ InternedOpenDepthReadback.Heap after.heap ∧
      valueDepth value ≤ limit + parentRank := by
  let request (member : Value Symbol Guard) : NodeRequest Symbol Guard :=
    if left then ⟨domain, member, other⟩ else ⟨domain, other, member⟩
  let call (member : Value Symbol Guard) (current : Machine Symbol Guard) :=
    execute emptyGuard conjoin fuel (request member).domain (request member).left (request member).right current
  have callSame : call = (fun member =>
      if left then execute emptyGuard conjoin fuel domain member other
      else execute emptyGuard conjoin fuel domain other member) := by
    funext member current
    cases left <;> rfl
  have bounds : ∀ member ∈ members, NodeBelow source holds parentRank (request member) := by
    intro member present
    cases left <;> exact memberBounds member present
  have visit : ∀ (requests : List (Value Symbol Guard)) (current final : Machine Symbol Guard)
      (results : List (Value Symbol Guard)), WalkTrace call requests current results final →
      (∀ member ∈ requests, NodeBelow source holds parentRank (request member)) →
