-/
namespace MicroCFTA.SourceRecursiveIntersectionKernel
open Cache Binding BinderLanguage InternedConstructorTemplates InternedProbeProvenance InternedNestedFacts
open InternedBinderProtocol IntersectionFlatMemoKeyDomain SourceRecursiveIntersectionThunks
open SourceRecursiveIntersectionInputView SourceRecursiveIntersectionNative IntersectSchedule
open SourceRecursiveIntersectionCode InternedStoredPlanBinderDepth
open SourceRecursiveIntersectionControl SourceRecursiveIntersectionDomain
open SourceRecursiveIntersectionSemanticHeap (SemanticHeap)

/-- Every actual completed original request satisfies its original-input degree bound. -/
theorem node_result_degree
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (source : InternedConstructorTemplates.State Symbol Guard) (facts : Facts source)
    (limit : Nat) (sourceBounded : InternedMuDepthInventory.Bounded source limit)
    (holds : Guard → Language.Term Symbol → Bool) (emptyGuard : Guard) (conjoin : Guard → Guard → Guard)
    (fuel : Nat) :
    ∀ (request : NodeRequest Symbol Guard) (_scope : NodeScope source request)
      (complete : Completes (view source holds) (nodeSemantic request))
      (state after : Machine Symbol Guard),
      Valid state → NodeReady state request →
      Grows source state.heap → Extends source.nodes.issued state.heap.nodes.issued →
      SemanticHeap state.heap → InternedOpenDepthReadback.Heap state.heap →
      ∀ value, execute emptyGuard conjoin fuel request.domain request.left request.right state = .done value after →
      SemanticHeap after.heap ∧ InternedOpenDepthReadback.Heap after.heap ∧
        valueDepth value ≤ limit + requiredFuel (view source holds) (nodeSemantic request) complete := by
  induction fuel with
  | zero =>
      intro request scope complete state after valid ready growth history semantic opened value done
      cases done
  | succ fuel ih =>
      intro request scope complete state after valid ready growth history semantic opened value done
      cases request with
      | mk domain left right =>
          obtain ⟨known, leftAvailable, rightAvailable⟩ := ready
          let bound := requiredFuel (view source holds) (nodeSemantic ⟨domain, left, right⟩) complete
          have recurse (child : NodeRequest Symbol Guard) (below : NodeBelow source holds bound child)
              (childReady : NodeReady state child)
              (returned : execute emptyGuard conjoin fuel child.domain child.left child.right state = .done value after) :
              SemanticHeap after.heap ∧ InternedOpenDepthReadback.Heap after.heap ∧ valueDepth value ≤ limit + bound := by
            obtain ⟨childScope, childComplete, childLess⟩ := below
            obtain ⟨afterSemantic, afterOpened, childDegree⟩ := ih child childScope childComplete state after valid childReady
              growth history semantic opened value returned
            exact ⟨afterSemantic, afterOpened,
              Nat.le_trans childDegree (Nat.add_le_add_left (Nat.le_of_lt childLess) limit)⟩
          simp only [execute] at done
          cases selected : decision domain.key left right with
          | empty =>
              simp only [onNode, selected] at done
              cases done
              exact ⟨semantic, opened, by simp [valueDepth, Value.free]⟩
          | self =>
              simp only [onNode, selected] at done
              cases done
              exact ⟨semantic, opened, Nat.le_trans
                (InternedMuDepthAvailableBounds.value_le source limit sourceBounded _ scope.leftAvailable) (Nat.le_add_right _ _)⟩
          | repeated key =>
              simp only [onNode, selected] at done
              cases done
              exact ⟨semantic, opened, by simp [repeatedValue, valueDepth, Value.free]⟩
