theorem union_lower {Symbol Guard : Type}
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (source : InternedConstructorTemplates.State Symbol Guard)
    (facts : InternedNestedFacts.Facts source) (limit : Nat)
    (sourceBounded : InternedMuDepthInventory.Bounded source limit)
    (holds : Guard → Language.Term Symbol → Bool)
    (emptyGuard : Guard) (conjoin : Guard → Guard → Guard) (fuel : Nat)
    (nodeIH : ∀ (request : NodeRequest Symbol Guard) (_scope : NodeScope source request)
      (complete : Completes (view source holds) (nodeSemantic request))
      (state : Machine Symbol Guard) (_valid : Valid state) (_ready : NodeReady state request)
      (_growth : Grows source state.heap)
      (_history : Extends source.nodes.issued state.heap.nodes.issued)
      (_semantic : SemanticHeap state.heap) (_opened : InternedOpenDepthReadback.Heap state.heap),
      Lower state.heap (limit + requiredFuel (view source holds) (nodeSemantic request) complete)
        (execute emptyGuard conjoin fuel request.domain request.left request.right state).state.heap)
    (domain : Interned DomainKey) (members : List (Value Symbol Guard))
    (other : Value Symbol Guard) (left : Bool) (bound : Nat)
    (state : Machine Symbol Guard) (valid : Valid state) (known : Domain state domain)
    (available : Available state.heap other)
    (membersAvailable : ∀ member ∈ members, Available state.heap member)
    (growth : Grows source state.heap)
    (history : Extends source.nodes.issued state.heap.nodes.issued)
    (semantic : SemanticHeap state.heap) (opened : InternedOpenDepthReadback.Heap state.heap)
    (memberBounds : ∀ member ∈ members,
      if left then NodeBelow source holds bound ⟨domain, member, other⟩
      else NodeBelow source holds bound ⟨domain, other, member⟩) :
    Lower state.heap (limit + bound)
      (((walk (fun member =>
        if left then execute emptyGuard conjoin fuel domain member other
        else execute emptyGuard conjoin fuel domain other member) members state).bind
        fun values middle => work (makeUnion values) middle).state.heap)
