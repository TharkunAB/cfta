from pathlib import Path
import hashlib,json,subprocess

root=Path('/home/tritlo/Code/mcfta')
r=Path('/tmp/mcfta-kernel-lower-progress-20261029')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
counts={}
for name in ['prior-lean-sources.json','prior-strong-sources.json','prior-haskell-sources.json']:
    records=json.loads((r/name).read_text())
    for v in records:assert sha(root/v['path'])==v['sha256'],v['path']
    counts[name]=len(records)
assert counts=={'prior-lean-sources.json':4623,'prior-strong-sources.json':461,'prior-haskell-sources.json':829}
assert (root/'lean/MicroCFTA/Audit.lean').read_bytes().endswith((r/'prior-Audit.lean').read_bytes())
for v in json.loads((r/'prior-documents.json').read_text()):
    old=r/'prior-document-bodies'/v['path']
    assert sha(old)==v['sha256']
    now=(root/v['path']).read_bytes()
    assert now.startswith((r/'current-header.md').read_bytes()) and now.endswith(old.read_bytes())
for name in ['final-proof-sources.json','final-documents.json']:
    for v in json.loads((r/name).read_text()):assert sha(root/v['path'])==sha(r/v['copy'])==v['sha256']
commands=[]
snapshots=0
for p in sorted(r.glob('*/report.json')):
    d=json.loads(p.read_text())
    assert sha(p.parent/'raw.log')==d['sha256'] and (p.parent/'raw.log').stat().st_size==d['bytes']
    assert d['cgroup_limits']=={'memory.max':'4294967296','memory.high':'4294967296','memory.swap.max':'0'}
    for v in json.loads((p.parent/'inputs.json').read_text()):
        assert sha(p.parent/'input-sources'/(v['module']+'.lean'))==v['sha256']
        snapshots+=1
    commands.append(dict(label=p.parent.name,exit_code=d['exit_code'],command=d['command']))
assert len(commands)==23 and sum(v['exit_code']==0 for v in commands)==21 and snapshots==160
strict=json.loads((r/'final-proof-sources.json').read_text())
assert len(strict)==10
for v in strict:
    d=json.loads((r/v['strict']/'report.json').read_text())
    assert d['exit_code']==0 and d['source_sha256']==v['sha256']
    assert '-DwarningAsError=true'in d['command'] and '-Dlinter.all=true'in d['command']
public=(r/'public-final/raw.log').read_bytes()
old=(r/'prior-public-readback.log').read_bytes()
assert public.startswith(old) and len(old)==3654083 and len(public)==3691779
review=json.loads((r/'public-review-verification.json').read_text())
assert review['all_ranges_read'] and b''.join((r/v['path']).read_bytes()for v in review['ranges'])==public[len(old):]
assert sha(r/'public-final/raw.log')=='b23355ece0ebb608477299ec28002fe31ca33d7f0dd01b952ab355f4fc39d6c0'
assert len(json.loads((r/'public-declarations.json').read_text()))==890
assert len(json.loads((r/'public-definitions.json').read_text()))==73
assert '82108 MicroCFTA theorems'in(r/'audit-final/raw.log').read_text()
historical={sha(p):p.read_bytes()for p in r.rglob('*.lean')}
scopes={}
for sub,expected in [('union-lower',2),('rows-lower',5)]:
    d=json.loads((r/sub/'evidence-v1/manifest.json').read_text())
    whole=d['whole_sources_requested']
    n=len(whole)if isinstance(whole,list)else whole
    assert n==expected and n<=8
    cuts=0
    for v in d['inputs']:
        raw=Path(v['source']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=v['sha256']:raw=historical[v['sha256']]
        for cut in v.get('literal_cuts',v.get('cuts',[])):
            p=r/sub/cut['snapshot'];assert sha(p)==cut['sha256']
            start,end=cut.get('lines',[cut.get('start'),cut.get('end')])
            assert p.read_bytes()==b''.join(raw.splitlines(keepends=True)[start-1:end])
            cuts+=1
    scopes[sub]=dict(whole_requests=n,limit=8,exact_cuts=cuts)
sub='native-prefix-audit'
d=json.loads((r/sub/'evidence-v1/manifest.json').read_text())
assert d['individual_whole_file_requests_including_repeats']==8
assert d['distinct_whole_sources_including_cut_aggregation']==7
cuts=0
for v in d['inputs']:
    raw=Path(v['source']).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=v['sha256']:raw=historical[v['sha256']]
    for cut in v['acquisitions']:
        p=r/sub/cut['snapshot'];assert sha(p)==cut['sha256']
        start,end=cut['effective_lines']
        assert p.read_bytes()==b''.join(raw.splitlines(keepends=True)[start-1:end])
        cuts+=1
scopes[sub]=dict(whole_requests=8,distinct_whole_sources=7,limit=8,exact_cuts=cuts,truncations_disclosed=d['truncated_exploratory_outputs'],status='source-only-unproved')
board=json.loads((r/'board-progress-verification.json').read_text())
assert board['sequence']==734 and board['exact_author_content_metadata_type_thread']
assert json.loads((r/'goal-live.json').read_text())['goal']['status']=='active'
subprocess.run(['git','diff','--exit-code','9718c09a7','--','lean/restart-evidence'],cwd=root,check=True)
facts=dict(counts=counts,strict_sources=10,commands=commands,completed_compiler_commands=23,pass_commands=21,retained_failed_drafts=2,input_snapshots=160,documents=27,old_document_suffixes=26,public_theorems=890,public_definition_bodies=73,public_bytes=len(public),public_sha256=sha(r/'public-final/raw.log'),prior_public_prefix_bytes=len(old),added_public_bytes=len(public)-len(old),source_scope_verification=scopes,board_sequence=734,full_goal='active',verified_progress=True,complete=False)
(r/'verification.json').write_text(json.dumps(facts,indent=2)+'\n')
print(json.dumps({k:v for k,v in facts.items()if k!='commands'}))
