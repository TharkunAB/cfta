import MicroCFTA.SourceCurrentNativeWarmCoherentInitialPayloads

namespace MicroCFTA.SourceCurrentNativeNumericalCoherentCallbacks
open Cache Language InternedConstructorTemplates InternedNestedFacts InternedProbeProvenance
open InternedBinderProtocol (NodeKey Reference)
open SourceRecursiveIntersectionControl SourceRecursiveIntersectionDomain
open SourceRecursiveIntersectionKernel SourceRecursiveIntersectionThunks SourceRecursiveIntersectionCode
open SourceSynthesisTypeSyntax (Library Query)
open SourceSynthesisFirstOrderConstruction (Expression)
open InternedStoredSubstitution (input)
open InternedStoredSubstitutionRebind (replacement)
open SourceCurrentAllocatedNativeTopRowQueryGlobalLaws (KnownResult)
open SourceEqualityNativeDemand
local notation "Symbol" => SourceObservations.Label FullSyntax.Formula
local notation "Guard" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Checked" => SourceEqualityNativeDemand.State
local notation "Physical" => SourceCurrentAllocatedNativePhysicalCache.Valid
local notation "ordinarySymbols" => SourceSynthesisUniverseCallerBoundary.ordinarySymbols
set_option autoImplicit false

/- Note [Numerical source coherent callbacks]
The source records fix the open body and every ordered row child.
The numerical keys retain both source recursive pairs and their exclusions.
The callbacks cover all equal-key handles and grown physical heaps.
No future pattern, entry or returned law supplies their meaning.
-/

theorem original_universe_coherent_callbacks_at_numerical_base
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
    (lib : Library) (query : Query) (signed : Int) (whole : Expression)
    (accepted : SourceSynthesisCurrentConstruction.firstOrderRaw lib query signed = .ok whole)
    (rootValue : Value Symbol Guard) (sourceHeap : InternedConstructorTemplates.State Symbol Guard)
    (built : InternedFreshOrdinaryConstruction.build (ordinarySymbols whole) [] empty =
      .done rootValue sourceHeap)
    (key : NodeKey) (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard)
    (stored : sourceHeap.nodeRecords key = some (.mu entry body depth ordinary))
    (bodyId : Nat) (bodyIdentity : identity body = some bodyId)
    (heap : InternedConstructorTemplates.State Symbol Guard) (facts : Facts heap)
    (sourceGrowth : Grows sourceHeap heap)
    (patternId : Nat) (patternUniverseApart : patternId ≠ entry.identity)
    (patternBodyApart : patternId ≠ bodyId) :
    let universeValue : Value Symbol Guard := .mu entry body depth ordinary
    let referenceValue : Value Symbol Guard := .reference (.interned entry.identity)
    let baseKey := extend IntersectionEmptyDomain.emptyKey [entry.identity] (pair entry.identity patternId)
    let firstKey := extend baseKey [entry.identity] (pair entry.identity entry.identity)
    let selectedKey := extend firstKey [entry.identity] (pair bodyId entry.identity)
    (∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = selectedKey →
      compileNode ⟨actualDomain, body, body⟩ =
        compileRows actualDomain (InternedEdgeResidency.nodeEdges body) (InternedEdgeResidency.nodeEdges body)) ∧
    (∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = selectedKey → ∀ row ∈ InternedEdgeResidency.nodeEdges body,
      All₂ (fun (children : Value Symbol Guard × Value Symbol Guard) (value : Value Symbol Guard) =>
        KnownResult ⟨actualDomain, children.1, children.2⟩ value)
        (row.children.zip row.children)
        (row.children.map (input (replacement (.interned entry.identity)
          (repeatedValue (pair entry.identity entry.identity)))))) ∧
    (∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = firstKey → decision actualDomain.key body universeValue = .rightMu) ∧
    (∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = firstKey →
      ∀ current : Cache.State IntersectionFlatMemoKeyDomain.DomainKey, Cache.Valid current →
      (SourceRecursiveIntersectionEnvironment.enter current actualDomain.key body universeValue
        bodyId entry.identity).1.key = selectedKey) ∧
    (pair bodyId entry.identity ≠ pair entry.identity entry.identity) ∧
    (∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = firstKey →
      ∀ current : Checked width, Physical current.native →
      Grows sourceHeap current.native.machine.heap →
      SourceEqualityNativeDemand.step
        (.code (compileNode ⟨actualDomain, body, referenceValue⟩)) current =
        .yielded (.code (requestNode actualDomain body universeValue)) current) := by
  have _retainedPatternUniverseApart := patternUniverseApart
  obtain ⟨bodyEntry, _marker, arrow, rows, bodyShape, _bodyAvailable, _markerShape,
      _arrowChildren, _arrowKey, _catalog, _markerClosed, _markerAvailable, _markerAtoms,
      rowKinds, _arrowRetained⟩ :=
    SourceSynthesisCurrentUniverseBodyChildClassification.current_stored_universe_body_physical_children_after_growth
      lib query signed whole accepted rootValue sourceHeap built key entry body depth ordinary stored
      heap facts sourceGrowth
  have actualBodyIdentity : identity body = some bodyEntry.identity := by
    rw [bodyShape]
    rfl
  have sameBodyId : bodyId = bodyEntry.identity :=
    Option.some.inj (bodyIdentity.symm.trans actualBodyIdentity)
  subst bodyId
  let universeValue : Value Symbol Guard := .mu entry body depth ordinary
  let referenceValue : Value Symbol Guard := .reference (.interned entry.identity)
  let baseKey := extend IntersectionEmptyDomain.emptyKey [entry.identity] (pair entry.identity patternId)
  let firstKey := extend baseKey [entry.identity] (pair entry.identity entry.identity)
  let selectedKey := extend firstKey [entry.identity] (pair bodyEntry.identity entry.identity)
  have universeAvailable : Available heap universeValue :=
    facts.cached.nodes key _ (sourceGrowth.nodeRecords key _ stored)
  have bodyApart : bodyEntry.identity ≠ entry.identity := by
    apply SourceSynthesisUniverseBodyReferenceControl.body_identity_ne
      entry bodyEntry (canonicalEdges (arrow :: rows)) depth ordinary ⟨heap, Cache.emptyState⟩ facts
    change Available heap (.mu entry
      (.node bodyEntry (canonicalEdges (arrow :: rows)) 0 [.interned entry.identity]) depth ordinary)
    rw [← bodyShape]
    exact universeAvailable
  have diagonalParts (first second owner : Nat) (same : pair first second = pair owner owner) :
      first = owner ∧ second = owner := by
    have lower := congrArg Prod.fst same
    have upper := congrArg Prod.snd same
    simp only [pair, Nat.min_self, Nat.max_self] at lower upper
    omega
  have freshExtra : pair bodyEntry.identity entry.identity ∉ firstKey.seen := by
    intro member
    rcases (extend_seen _ _ _ _).mp member with same | previous
    · exact bodyApart (diagonalParts bodyEntry.identity entry.identity entry.identity same).1
    · rcases (extend_seen _ _ _ _).mp previous with same | empty
      · have lower := congrArg Prod.fst same
        have upper := congrArg Prod.snd same
        simp only [pair] at lower upper
        exact patternBodyApart (by omega)
      · simp only [IntersectionEmptyDomain.emptyKey, List.not_mem_nil] at empty
  have freshBody : pair bodyEntry.identity bodyEntry.identity ∉ selectedKey.seen := by
    intro member
    rcases (extend_seen _ _ _ _).mp member with same | previous
    · exact bodyApart
        (diagonalParts bodyEntry.identity entry.identity bodyEntry.identity same.symm).2.symm
    · rcases (extend_seen _ _ _ _).mp previous with same | earlier
      · exact bodyApart (diagonalParts entry.identity entry.identity bodyEntry.identity same.symm).1.symm
      · rcases (extend_seen _ _ _ _).mp earlier with same | empty
        · exact bodyApart (diagonalParts entry.identity patternId bodyEntry.identity same.symm).1.symm
        · simp only [IntersectionEmptyDomain.emptyKey, List.not_mem_nil] at empty
  have sourceRows : InternedEdgeResidency.nodeEdges body = canonicalEdges (arrow :: rows) := by
    rw [bodyShape]
    rfl
  have compiler : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = selectedKey →
      compileNode ⟨actualDomain, body, body⟩ =
        compileRows actualDomain (InternedEdgeResidency.nodeEdges body) (InternedEdgeResidency.nodeEdges body) := by
    intro actualDomain sameKey
    have fresh : pair bodyEntry.identity bodyEntry.identity ∉ actualDomain.key.seen := by
      rw [sameKey]
      exact freshBody
    have shaped : decision actualDomain.key
        (.node bodyEntry (canonicalEdges (arrow :: rows)) 0 [.interned entry.identity])
        (.node bodyEntry (canonicalEdges (arrow :: rows)) 0 [.interned entry.identity]) = .ordinary := by
      simp [decision, hasEmpty, reset, closedSelf, greater, compareValue, tag, identity, payload,
        Value.referenceOf, Value.free, fresh]
    have literalCompiled : compileNode ⟨actualDomain,
        .node bodyEntry (canonicalEdges (arrow :: rows)) 0 [.interned entry.identity],
        .node bodyEntry (canonicalEdges (arrow :: rows)) 0 [.interned entry.identity]⟩ =
        compileRows actualDomain (canonicalEdges (arrow :: rows)) (canonicalEdges (arrow :: rows)) := by
      simp only [compileNode, shaped]
    calc
      compileNode ⟨actualDomain, body, body⟩ = compileNode ⟨actualDomain,
          .node bodyEntry (canonicalEdges (arrow :: rows)) 0 [.interned entry.identity],
          .node bodyEntry (canonicalEdges (arrow :: rows)) 0 [.interned entry.identity]⟩ :=
        congrArg (fun value : Value Symbol Guard => compileNode ⟨actualDomain, value, value⟩) bodyShape
      _ = compileRows actualDomain (canonicalEdges (arrow :: rows)) (canonicalEdges (arrow :: rows)) := literalCompiled
      _ = compileRows actualDomain (InternedEdgeResidency.nodeEdges body)
          (InternedEdgeResidency.nodeEdges body) := by rw [sourceRows]
  have orderedInputs : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = selectedKey → ∀ row ∈ InternedEdgeResidency.nodeEdges body,
      All₂ (fun (children : Value Symbol Guard × Value Symbol Guard) (value : Value Symbol Guard) =>
        KnownResult ⟨actualDomain, children.1, children.2⟩ value)
        (row.children.zip row.children)
        (row.children.map (input (replacement (.interned entry.identity)
          (repeatedValue (pair entry.identity entry.identity))))) := by
    intro actualDomain sameKey
    let environment : InternedStoredSubstitution.Environment Symbol Guard :=
      replacement (.interned entry.identity) (repeatedValue (pair entry.identity entry.identity))
    have diagonalSeen : pair entry.identity entry.identity ∈ actualDomain.key.seen := by
      rw [sameKey]
      apply (extend_seen _ _ _ _).mpr
      right
      exact (extend_seen _ _ _ _).mpr (Or.inl rfl)
    have terminalSelected : decision actualDomain.key referenceValue referenceValue =
        .repeated (pair entry.identity entry.identity) := by
      simp [decision, hasEmpty, reset, closedSelf, greater, compareValue, tag, identity,
        referenceValue, Value.referenceOf, Value.free, diagonalSeen,
        SourceRecursiveIntersectionSchedule.reference_interned]
    have terminalPure : compileNode ⟨actualDomain, referenceValue, referenceValue⟩ =
        .pure (repeatedValue (pair entry.identity entry.identity)) := by
      simp only [compileNode, terminalSelected]
    have referenceInput : input environment (.reference (.interned entry.identity)) =
        repeatedValue (pair entry.identity entry.identity) := by
      simp [environment, input, replacement]
    have diagonalMany (values : List (Value Symbol Guard)) :
        (∀ child ∈ values, KnownResult ⟨actualDomain, child, child⟩ (input environment child)) →
        All₂ (fun (children : Value Symbol Guard × Value Symbol Guard) (value : Value Symbol Guard) =>
          KnownResult ⟨actualDomain, children.1, children.2⟩ value)
          (values.zip values) (values.map (input environment)) := by
      induction values with
      | nil => intro _each; exact .nil
      | cons child tail ih =>
          intro each
          exact .cons (each child List.mem_cons_self)
            (ih (fun value member => each value (List.mem_cons_of_mem child member)))
    intro row member
    apply diagonalMany row.children
    intro child childMember
    have kinds := rowKinds row (by rw [← sourceRows]; exact member)
    rcases kinds.2.2 child childMember with referenceCase | closedCase
    · subst child
      apply Or.inr
      rw [referenceInput]
      exact terminalPure
    · exact Or.inl ⟨rfl, closedCase.2.2.1,
        InternedStoredSubstitutionScope.input_closed child environment closedCase.2.2.1⟩
  have rightMu : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = firstKey → decision actualDomain.key body universeValue = .rightMu := by
    intro actualDomain sameKey
    have fresh : pair bodyEntry.identity entry.identity ∉ actualDomain.key.seen := by
      rw [sameKey]
      exact freshExtra
    have tagOrder : compare (1 : Nat) 2 = .lt := by decide
    have shaped : decision actualDomain.key
        (.node bodyEntry (canonicalEdges (arrow :: rows)) 0 [.interned entry.identity]) universeValue = .rightMu := by
      simp [decision, hasEmpty, reset, closedSelf, greater, compareValue, tag, identity, payload,
        universeValue, Value.referenceOf, Value.free, fresh, tagOrder]
    exact (congrArg (fun value : Value Symbol Guard => decision actualDomain.key value universeValue)
      bodyShape).trans shaped
  have childKey : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = firstKey →
      ∀ current : Cache.State IntersectionFlatMemoKeyDomain.DomainKey, Cache.Valid current →
      (SourceRecursiveIntersectionEnvironment.enter current actualDomain.key body universeValue
        bodyEntry.identity entry.identity).1.key = selectedKey := by
    intro actualDomain sameKey current currentValid
    have names : (SourceRecursiveIntersectionEnvironment.bindings body universeValue).map Prod.fst =
        [entry.identity] := by
      rw [bodyShape]
      rfl
    rw [SourceRecursiveIntersectionSchedule.entered_key current currentValid actualDomain.key
      body universeValue bodyEntry.identity entry.identity, names, sameKey]
  have pairedApart : pair bodyEntry.identity entry.identity ≠ pair entry.identity entry.identity := by
    intro same
    exact bodyApart (diagonalParts bodyEntry.identity entry.identity entry.identity same).1
  have read : ∀ actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey,
      actualDomain.key = firstKey → ∀ current : Checked width, Physical current.native →
      Grows sourceHeap current.native.machine.heap →
      SourceEqualityNativeDemand.step (.code (compileNode ⟨actualDomain, body, referenceValue⟩)) current =
        .yielded (.code (requestNode actualDomain body universeValue)) current := by
    intro actualDomain sameKey current physical currentGrowth
    have bound : entry.identity ∈ names actualDomain.key := by
      rw [sameKey]
      exact (extend_names _ _ _ _).mpr (Or.inl (List.mem_singleton.mpr rfl))
    have fresh : pair bodyEntry.identity entry.identity ∉ actualDomain.key.seen := by
      rw [sameKey]
      exact freshExtra
    have tagOrder : compare (1 : Nat) 4 = .lt := by decide
    have referenceSelected : decision actualDomain.key body referenceValue = .rightReference := by
      rw [bodyShape]
      simp [decision, hasEmpty, reset, closedSelf, greater, compareValue, tag, identity, payload,
        referenceValue, Value.referenceOf, Value.free, fresh, tagOrder]
    have compiled : compileNode ⟨actualDomain, body, referenceValue⟩ =
        compileReference actualDomain entry.identity body false := by
      simp only [compileNode, referenceSelected, referenceValue]
    have currentUniverse : Available current.native.machine.heap universeValue :=
      physical.machine.1.cached.nodes key _ (currentGrowth.nodeRecords key _ stored)
    have sourceRead : SourcePreparedSharedRows.read current.native.machine.heap entry.identity =
        some universeValue := SourcePreparedSharedRows.read_identity current.native.machine.heap
      physical.machine.1 universeValue currentUniverse entry.identity rfl
    have readStep : SourceEqualityNativeDemand.step
        (.code (compileReference actualDomain entry.identity body false)) current =
        .yielded (.code (requestNode actualDomain body universeValue)) current := by
      simp [compileReference, bound, SourceEqualityNativeDemand.step,
        SourceRecursiveIntersectionNative.step, sourceRead, SourceEqualityNativeDemand.lift]
    exact (congrArg (fun code : Code Symbol Guard (Value Symbol Guard) =>
      SourceEqualityNativeDemand.step (.code code) current) compiled).trans readStep
  exact ⟨compiler, orderedInputs, rightMu, childKey, pairedApart, read⟩

end MicroCFTA.SourceCurrentNativeNumericalCoherentCallbacks
