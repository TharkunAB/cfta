# Active numerical invariant work

FINAL CHECKED SNAPSHOT AT 2026-11-18 00:12 CET. Source is committed as
1a3de82aec4bab8cc6b21012103e6311a951b266. Normal publication10938 is TERMINAL0.
Its five report counts are724/15/319/724/724. Root independently verified all
7,750current input pins. The global Audit checked100,189declarations. Source
has6,278files,5,278Audit imports and319independent reports. Fifteen public and
ten private theorems are new. Seeds is one pure Prop definition. Its one
declaration check has zero axiom-report credit. Fifteen fresh public reports
plus503inherited give518combined; all264resource reports remain inherited.
The two owning-private reports remain separate from public credit.

The strongest new result is the actual finite admitted-query sequence
invariant. It derives source inventory and cache Seeds from genuine initially
empty node and edge memo tables, then retains them at every actual execute
endpoint and every bounded prefix. Each query keeps its own supplied fuel
and actual root/state. Closed empty-domain roots, the initial source inventory
and original InputsThrough/FieldsThrough plans remain explicit admissions.
No caller supplies Seeds, Gamma, desired Profiles, result laws or a model.
This does not derive every eager-worker admission or the full worker's
interleaving. Profile is a reference/atom property, not language membership.
The finite accepted completion under ONE assignment for EVERY historical
obligation remains open. The full objective below still governs the work.

SOURCE-COMMIT.json records actual27639 TERMINAL0 and exactly14Lean source
paths. Git parent is5be034665. The tracked tree is clean. A separate checkpoint
and its push are pending. Do not start the next normal Source wave until that
checkpoint is pushed and independently verified. The destination is only
git@github.com:TharkunAB/cfta.git refs/heads/formalize, without force.

Board note1521 is independently read back and deeply verified. Its prefix is
current-board-native-query-sequence-, UUID7d1da47a-24a8-49d4-861b-ce0f51572855.
The request and canonical files are final. combined-terminal-cleanup-result.json
is final: all six owned temporary object directories are removed;72,476,920
regular bytes and37,806links were removed. All6,312normal cache targets retain
their final stat data. The initial two cleanups preserved the then6,304targets;
the later normal build legitimately added and rebuilt objects. Known cumulative
regular cleanup is6,565,688,965bytes. The readable/tmp census is6,424,901,363bytes,
with six protected permission errors. Unknown entries remain untouched.

START is preserved. BATCH-SCOPE-UPDATE, RESUME-AUTHORIZATION and USAGE are final.
The81percent usage record is HISTORICAL at17:53onNovember17. Current usage was
not measured. Matti lifted the earlier pause and authorized continued work.

Next checkpoint archive is20261118-actual-query-sequence-seeds-checkpoint.
actual_edge_footprint prepares its frozen controller. Root owns assembly,
documentation, archive verification, checkpoint commit, push, remote readback
and post-push current-tree verification. Preserve every earlier root document
byte as an exact suffix. No Haskell source changed or new reachable Haskell
defect was established. Earlier FINDINGS must stay intact.

Next-wave attachment audit9c6fc8ee, descendant gate218ee3d9, and same-state
shared-empty skip5d2ea599 remain UNCOMPILED with ZERO credit in this checkpoint.
They address the real checkEmpty=true phase without a flag restriction or a
supplied gate answer. The actual worker's constructor/preparation effects,
query-list producer, field plans, inhabitance and finite model remain open.

---

The following sections preserve the earlier work chronology. The final checked
snapshot above supersedes their statements about pending checks and staging.

The full objective remains in FULL-TARGET.md. Work continues under Matti's
explicit resume and standing authorization to push origin/formalize. The
persistent goal control is paused. No goal operation or completion claim was
made. The earlier usage pause was lifted. Current usage was not measured.

## Published baseline

Source f21685746f00e574ef5554a85a7c83676b11e5fc is committed. Checkpoint
5be0346650aac0057062fd1e0d36b9744bcb4c79 is pushed and independently verified.
Work55/PUSH-VERIFIED.json binds push42894, remote check85042 and the post-push
current-tree verification. The remote is git@github.com:TharkunAB/cfta.git,
refs/heads/formalize. No fork push or force push is authorized.

The immutable checkpoint is 20261117-third-query-six-seed-checkpoint. Its
manifest SHA256 is b581a4ad0fdb153f7388c0fb1b566d4b68a7dfcd810078361fec91000146fd1c.
It has443 archived inputs,461files and5,507,830bytes. Source has6,270files.
Publication60614 passed all five gates709/7/304/709/709 with7fresh reports.
The original checkpoint preparer failed a wrapped-prose assertion before
writes. The separate usage-wrap repair preserves that preparer and changes
only whitespace normalization plus its required self/archive bookkeeping.

The checked result derives middle source Mu inventory and all six INITIAL
cache implication laws for the SAME fixed FULL third history after one cold
and one middle prefix. The joint FIRST remains exact b4b2af07. It does not
prove third-query endpoint or all-prefix inventory, arbitrary query closure,
native inhabitance, guard truth or a joint finite accepted completion.

## Current mathematical route

Seeds is a pure Prop definition. It has no future root, history or entry.
It contains source NoNewMu, closed node/edge clauses, ANY-singleton node/edge
Profiles and four auxiliary Returned laws for each numerical pid apart from
the source universe and body identities. A final source-chain induction must
derive Seeds. Lower components may use genuine past Seeds as their induction
hypothesis. Do not add Seeds, Gamma, desired Profiles, results or a model as a
new final-source caller premise.

The planned step covers ALL execute outcomes and EVERY bounded actual prefix,
with the original source, fuel, plans and retained state. It keeps mismatched
arity and sentinel behavior. Profile concerns references and original-U atoms;
it does not prove language membership or a common finite model.

## Actual checks and retained failures

95793 is terminal1. Runtime numerical-source-callbacks-check failed with one
BodyFirst parser diagnostic and six Coherent type/goal diagnostics. Generated
sorryAx reports were rejected. FIRST-CHECK-REJECTED.json binds6,321pins.

78168 is terminal1. Runtime numerical-source-callbacks-repair-check passed
Coherent with one standard report. BodyFirst had one remaining local-reference
matcher goal. The mapper had an unavailable by_contra tactic and three
downstream goals. REPAIR-CHECK-REJECTED.json binds6,373pins. Both failed theorem
reports are rejected. Coherent's successful component is distinct from the
failed combined check. No normal Source changed.

The original BodyFirst FIRST25e9a6 changes to5d4177 only by a required let
semicolon. Both headers remain. Do not claim byte equality. Its subsequent
proof-only repair unfolds referenceValue. Coherent retains FIRSTaf6066 exactly.
The mapper repair retains public FIRST95e4c0, private FIRST8903cd and the pure
Seeds definition2e2de7 byte for byte. It uses Classical.byContradiction directly.

## Frozen component packets

The first nine selected components passed actual55279. The full thirteen
components passed actual31981 after the two repairs below. Normal Source
integration is complete. The normal publication checks are still pending.

- Numerical BodyFirst reference repair: ec381ea9 manifest,4017ee6c raw.
- Numerical Coherent typing/read repair:769e771e manifest,bb0beb77 raw.
- Fixed-history mapper Classical repair:8b5291a7 manifest,ca121c51 raw.
- Mixed-finish inner-past export:4e0c65bf manifest. It is a lower component.
  The general Gamma proof derives its inner-past premises at the same cut.
- Numerical CM history original:18e54f79 manifest,d5c88122 raw. Its selected
  pointwise AUX EOF export is deae17e2 manifest,b4cf2bde raw. The complete old
  source remains its exact prefix. Select all three public probes, with the
  two base probes and one new alias probe kept as separate original files.
- Retained Mu-owner admission:17a65efa manifest, FIRSTd74f7d73. Assemble the
  complete152,375byte normal owner plus its frozen append. No new import.
- Auxiliary ANY-singleton separation:a113a1a9 manifest,38c8c629 raw,
  FIRST7ed0c9c0. It appends to ThirdQueryNodeSeed and reuses its private
  actual-entry proof. The entire23,348byte old owner remains an exact prefix.
- Singleton node preservation:cd1cd353 manifest,9d01a226 raw, FIRST065edbb1.
  It has one public theorem and no new private helper or definition.
- Singleton edge preservation:bbbce20c manifest,52685161 raw, FIRSTa3ab2e21.
  It has one public theorem and three checked-source codec helpers. Each
  actual child supplies its own node query, key and exact current cell.
- Retained optional NoNewMu:90387512 manifest,eb872c61 raw, FIRST296b5cab.
  Preserve all47,211old bytes contiguously at offset55 after one Gamma import.
  The import is acyclic. This owner is not an exact byte prefix.
- Retained full NoNewMu:efd951de manifest,911d91cc raw, FIRSTdc458caf. The
  complete11,611byte old owner remains an exact prefix. All outcomes remain.
  The selected identity-scope repair is de12c309 manifest,15af8131 raw.
  It adds one namespace open and preserves that FIRST and all proof bytes.
- Terminal-step Returned bridge:d4ba82f7 manifest,bf01bb59 raw, FIRST81d4b21c.
  It preserves arbitrary laws through the SAME non-yielding step, including
  lookup/demand table changes and edge-body operation changes.
  The selected advance repair is767d319d manifest,e1468059 raw. It unfolds
  advance in the two optionalBinder simplification steps. FIRST is exact.
- Full one-query closure proof:f6a471e9 manifest,44a8de15 raw. The original
  private FIRSTf677fdad is byte exact. The197-line source has two private
  theorems and no new definition. Its owning-module probes are separate
  from public theorem probes. It retains every execute outcome.
- Actual-query Nat producer:8dbf0259 manifest,3af1f639 raw, FIRST6f1637e1 in
  20261117-actual-query-sequence-seeds-draft. It preserves the entire private
  closure source as a prefix and appends one public theorem and one private
  effect helper. It derives initial Seeds from the actual empty memo tables
  and later Seeds by genuine induction over the actual execute endpoints.

Frozen dependency pins remain exact historical records. Selected repair
implementations need explicit header/definition comparison. Do not pretend
their raw source hashes equal the predecessors.

## Actual full check and next publication

The reviewed frozen controller is
20261117-numerical-retained-query-check-control-draft. Its manifest is
681c21d39c218a315953a945b6b147bf87221482307b42182e79e2b4407a8040.
Root copied and ran its preparer. All preflight checks passed. Actual session
55279 is TERMINAL0 in scope mcfta-numerical-retained-query-20261117-2330.scope.
All nine commands passed with11standard reports, no diagnostics/sorry/bad
axioms and one pure Prop declaration check. Root independently verified all
6,497 runtime input pins. RETAINED-QUERY-VERIFIED.json is final. The runtime is
numerical-retained-query-check. Its object directory is
/tmp/mcfta-numerical-retained-query-check-1y2adpzp. It selects nine
components through singleton edge preservation,11public reports,6new private
helpers checked transitively and one pure Seeds #check with zero axiom credit.
No private explicit reports are selected. The optional/full NoNewMu,
terminal bridge and closure are outside this first check. These eleven local
component proofs do not yet establish full Seeds or arbitrary query sequences.
The first full attempt63694 is TERMINAL1. Optional NoNewMu passed. Terminal
had two advance-unfolding goals and Full NoNewMu lacked identity in scope.
Their generated sorryAx reports are rejected. The closure/Nat module was
blocked by a missing dependency object, not checked. Its receipt binds6,584
pins. Both original packets and that failed run remain.

The full retry controller is
20261117-numerical-seed-closure-repair-check-control-draft, manifest
bb6ae3501c3765bbf88fd357e5d8a402b96fc4547d05ab1ae4f4e7a9e945647f.
Actual31981 is TERMINAL0:13commands,15public plus2owning-private standard
reports,10private helpers checked transitively and one Seeds declaration
check. Root independently verified6,619input pins. The definitive receipt is
SEED-CLOSURE-VERIFIED.json. No sorry, diagnostic or nonstandard axiom occurred.
Its runtime is20261117-numerical-seed-closure-repair-check. Its object directory
is/tmp/mcfta-numerical-seed-closure-repair-check-6qs9yhhv.

The public sequence theorem covers actual finite admitted native query
sequences, each supplied fuel, all execute outcomes and every bounded prefix.
It derives Seeds internally from the true empty initial memo tables. It still
requires the genuine physical InputsThrough and FieldsThrough plans. It does
not establish those admissions for every eager-worker call or a finite model.

Root reviewed and executed staging controller522eb45c. SOURCES-NORMAL-STAGING.json
is final:8new modules,5owner changes and Audit,6278Source files,5278imports,
724Audit reports and15fresh public reports. Other6264old Source files remain
exact. Optional retains its old block at55; Audit retains431699old bytes at485.
Git HEAD remains5be034665 and no new proof commit exists yet. The normal Source
tree now differs from f216 by these controlled changes. Private input pin
maps need the six current-wave BEFORE snapshots when verifying after staging.
The historical Work55BodyFirst snapshot remains a separate older override.

actual_edge_footprint is preparing the frozen normal publication controller
20261117-numerical-seed-closure-publication-control-draft. The intended five
gates have724/15/319/724/724reports. The fresh-public fixture also checks Seeds
once with zero axiom credit. No private owning-module query goes in Audit.
The publication must rebuild all thirteen normal modules in correct transitive
order. Source commit is gated on its actual final success and independent pins.
mixed_body_composition is preparing a separate Source-only commit controller.
Do not commit docs or artifact packets with the fourteen Source changes.

Upstream refresh94072 completed0. Main remains e53852064d3ef5a2eafec47d754c27504b11de5f,
already an ancestor of5be. No new main commits need integration.

The separate next-wave worker attachment audit is9c6fc8ee. Its new gate lemma
218ee3d9 /c75af407 /FIRSTd9d5 remains UNCOMPILED. It extends the original-root
gate result to any Available value under genuine source NoNewMu. It supplies
no gate answer as a premise and proves no inhabitance. Actual checkEmpty=true
skip composition, nonquery constructor effects and all-worker plans remain
open. This candidate is excluded from the current thirteen-module publication.

Use serial heavy-management capped jobs,8GiB memory.max/high, zero swap,
Nix/lake, Lean-j1 and warningAsError. Keep default proof limits. Exclude ALL
selected output names from the symlink overlay. Check transitive topology.
Never copy normal cache data. Root owns the compiler, normal Source, Work,
Git, board and temporary cleanup. Other work is confined to new frozen packets.

After terminal success, independently verify every recorded pin and count.
Keep any failure logs and generated sorryAx rejections. Stage normal Source
only after the earlier checkpoint push gate. Run the normal publication
checks before committing proof changes. Then archive, document and push the
new verified result. No theorem counts imply completion of the full goal.

## Temporary objects

The95793 and78168 temporary object directories are removed. Their source,
logs, result and rejection records remain. terminal-failure-cleanup-result.json
records743,800regular bytes and12,608links removed. All6,304normal cache targets
retain the same stat data. Known cumulative regular cleanup is6,493,955,845bytes.
Unknown and other-project entries are untouched. Do not require the old
temporary directories to exist when checking historical failure records.

No Haskell source changed. No new reachable Haskell defect was established.
Retain all previous FINDINGS entries. Record any later Haskell fix there.
