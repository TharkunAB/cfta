from pathlib import Path
import ast
import hashlib
import json
import re
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
control = base / '20261117-numerical-seed-closure-publication-control-draft'
work = base / '20261117-numerical-source-callbacks-work'
runtime = base / '20261117-numerical-seed-closure-publication'
repair = base / '20261117-numerical-seed-closure-publication-receipt-schema-repair'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this preparer.'
assert Path(__file__).read_bytes() == (repair / 'prepare-publication-receipt-schema-repair.py').read_bytes()
assert not runtime.exists(), 'Preserve all earlier runtimes.'
sha = lambda data: hashlib.sha256(data).hexdigest()
bound = set()
audit_name = 'lean/MicroCFTA/Audit.lean'
prior_work = base / '20261117-third-query-node-seed-work'
prior_run = base / '20261117-third-query-six-seed-publication'
prior_archive = base / '20261117-third-query-six-seed-checkpoint'
prior_checkpoint = '5be0346650aac0057062fd1e0d36b9744bcb4c79'
prior_manifest_sha = 'b581a4ad0fdb153f7388c0fb1b566d4b68a7dfcd810078361fec91000146fd1c'
source_commit = 'f21685746f00e574ef5554a85a7c83676b11e5fc'


def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data


def records(value):
    return list(value.items()) if isinstance(value, dict) else [(item['path'], item) for item in value]


for name, record in json.loads((control / 'MANIFEST.json').read_text())['files'].items():
    verify(control / name, record)
bound.add(control / 'MANIFEST.json')
assert sha((control / 'MANIFEST.json').read_bytes()) == '54f4516bf40bfa0e0afe373391d14a341e1987ce291c894981aac0e27e2dc973'
for name, record in json.loads((repair / 'MANIFEST.json').read_text())['files'].items():
    verify(repair / name, record)
bound.add(repair / 'MANIFEST.json')
for name, record in json.loads((control / 'ACTUAL-INPUT-PINS.json').read_text()).items():
    verify(root / name, record)
stage_control = base / '20261117-numerical-seed-closure-repair-staging-control-draft'
verify(stage_control / 'MANIFEST.json', '522eb45cdaab3063a14bf460114ec21e29f80fe2219d05d16ac2812ca8a4917f')
for name, record in json.loads((stage_control / 'MANIFEST.json').read_text())['files'].items():
    verify(stage_control / name, record)
expected_stage = json.loads((control / 'EXPECTED-STAGE.json').read_text())
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage = json.loads(stage_path.read_text())
for key, value in expected_stage.items():
    if key not in ['status', 'actual_private_session', 'actual_terminal']:
        assert stage[key] == value, key
assert stage['status'] == 'ACTUALLY STAGED BY ROOT AFTER VERIFIED TERMINAL PASS'
assert stage['actual_terminal'] and stage['normal_Source_changed'] and not stage['published']
assert stage['source_baseline'] == source_commit and stage['prior_checkpoint'] == prior_checkpoint
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports']) == (6278, 5278, 724)
assert (stage['new_modules'], stage['changed_existing_owners'], stage['fresh_public_reports']) == (8, 5, 15)
assert stage['owning_private_reports_not_in_audit'] == 2 and stage['new_Prop_definitions'] == 1
assert not stage['new_Seeds_check_in_audit'] and not stage['joint_finite_completion_proved']
bound.add(stage_path)
private_control = base / stage['private_control']
verify(private_control / 'MANIFEST.json', stage['private_control_manifest_sha256'])
selection_bytes = verify(private_control / 'SELECTION.json', stage['private_selection_sha256'])
assert selection_bytes == (control / 'CHECK-SELECTION.json').read_bytes()
selected = json.loads(selection_bytes)
assert len(selected['components']) == selected['expected_checks'] == 13
assert selected['expected_axiom_reports'] == 17 and selected['expected_public_axiom_reports'] == 15
assert selected['expected_private_axiom_reports'] == 2 and selected['new_private_helpers'] == 10
private_run = base / stage['runtime']
assert selected['runtime'] == private_run.name
receipt_path = work / stage['future_verified_receipt']
receipt = json.loads(receipt_path.read_text())
assert type(receipt['actual_session']) is int and receipt['actual_session'] > 0
assert receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
assert receipt['actual_session'] == stage['actual_private_session']
assert receipt['runtime'] == private_run.name and receipt['source_baseline'] == source_commit
assert receipt['source_files'] == 6270 and not receipt['normal_Source_changed'] and not receipt['published']
assert receipt['actual_public_reports'] == 15 and receipt['actual_owning_private_reports'] == 2
assert receipt['actual_total_reports'] == 17 and receipt['actual_definition_checks'] == 1
assert receipt['new_private_helpers_transitive'] == 10 and receipt['new_Prop_definitions'] == 1
assert receipt['Prop_axiom_credit'] == 0 and receipt['all_thirteen_components_checked']
assert receipt['actual_admitted_query_sequence_Seeds_producer_checked']
assert not receipt['original_eager_worker_all_calls_Seeds_propagation_proved']
assert not receipt['joint_finite_completion_proved']
checked_bytes = verify(private_run / 'checked.json', receipt['checked_sha256'])
checked = json.loads(checked_bytes)
assert json.loads((private_run / 'results.json').read_text()) == checked
assert receipt['checks'] == checked['checks'] and len(checked['checks']) == 13 and all(checked['passed'])
assert checked['all_thirteen_seed_closure_components_checked'] and checked['proof_credit']
assert checked['failure'] is None and checked['actual_total_axiom_reports'] == 17
assert checked['actual_public_axiom_reports'] == 15 and checked['actual_owning_private_axiom_reports'] == 2
assert checked['actual_definition_declaration_checks'] == 1
assert checked['new_private_helpers_compiled_transitively'] == 10
assert checked['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
assert stage['private_receipt_sha256'] == sha(receipt_path.read_bytes())
assert stage['private_checked_sha256'] == sha(checked_bytes)
private_pin_bytes = verify(private_run / 'source-pins.json', receipt['source_pins_sha256'])
private_pins = json.loads(private_pin_bytes)
assert receipt['pins_independently_reverified'] == stage['actual_pins_reverified'] == len(private_pins)
assert [item['name'] for item in checked['checks']] == selected['compile_order']
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['sorryAx']
    and not item['nonstandard_axioms'] for item in checked['checks'])
bound.update([receipt_path, private_run / 'results.json'])
bound.update(private_run / (item['name'] + '.txt') for item in checked['checks'])

# Resolve every historical Source pin by its exact digest.
overrides = stage['baseline_overrides']
assert len(overrides) == 6
prior_stage = json.loads((prior_work / 'SOURCES-NORMAL-STAGING.json').read_text())
historical_overrides = prior_stage['baseline_overrides']


def verify_historical(name, record):
    digest = record['sha256'] if isinstance(record, dict) else record
    candidates = [root / name]
    for mapping in [overrides, historical_overrides]:
        if name in mapping:
            candidates.append(root / mapping[name])
    for path in candidates:
        if path.is_file() and sha(path.read_bytes()) == digest:
            return verify(path, record)
    raise AssertionError(name)


def verify_pin_map(path):
    bound.add(path)
    for name, record in records(json.loads(path.read_text())):
        verify_historical(name, record)


baseline_path = work / 'SEED-CLOSURE-baseline-source-pins.json'
baseline = json.loads(baseline_path.read_text())
assert len(baseline) == 6270
for name, record in baseline.items():
    verify(root / overrides.get(name, name), record)
current = sorted((root / 'lean/MicroCFTA').glob('*.lean'))
components = stage['components']
assert len(components) == 13
new_names = {item['source_path'] for item in components if item['kind'] == 'new_module'}
assert len(new_names) == 8 and not set(baseline).intersection(new_names)
assert {str(path.relative_to(root)) for path in current} == set(baseline) | new_names
assert len(set(baseline) - set(overrides)) == 6264
for name, record in private_pins.items():
    verify_historical(name, record)
# Bind the prior pushed source, publication and immutable archive.
prior_source = json.loads((prior_work / 'SOURCE-COMMIT.json').read_text())
prior_publication = json.loads((prior_work / 'PUBLICATION-VERIFIED.json').read_text())
push = json.loads((prior_work / 'PUSH-VERIFIED.json').read_text())
assert prior_source['source_commit'] == push['source_commit'] == source_commit
assert prior_source['actual_terminal'] and prior_source['actual_terminal_exit'] == 0
assert prior_publication['actual_terminal'] and prior_publication['actual_terminal_exit'] == 0
assert prior_publication['actual_session'] == prior_source['publication_actual_session'] == 60614
assert [item['total_axiom_reports'] for item in prior_publication['checks']] == [709, 7, 304, 709, 709]
assert push['checkpoint_commit'] == push['remote_commit'] == prior_checkpoint
assert push['actual_push_terminal'] and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal'] and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
verify(prior_archive / 'manifest.json', prior_manifest_sha)
prior_checked = json.loads((prior_run / 'checked.json').read_text())
assert (prior_checked['source_files'], prior_checked['independent_reports'], prior_checked['resource_and_component_probes']) == (6270, 304, 503)
assert len(prior_checked['checks']) == 5 and prior_checked['all_five_gates_passed']
verify_pin_map(prior_run / 'source-pins.json')
bound.update([prior_work / 'SOURCE-COMMIT.json', prior_work / 'PUSH-VERIFIED.json',
    prior_work / 'PUBLICATION-VERIFIED.json', prior_work / 'SOURCES-NORMAL-STAGING.json',
    prior_run / 'checked.json', prior_archive / 'verify.py', prior_archive / 'archived-inputs.json'])
for name, session, runtime_name in [
    ('FIRST-CHECK-REJECTED.json', 95793, '20261117-numerical-source-callbacks-check'),
    ('REPAIR-CHECK-REJECTED.json', 78168, '20261117-numerical-source-callbacks-repair-check'),
    ('SEED-CLOSURE-CHECK-REJECTED.json', 63694, '20261117-numerical-seed-closure-check')]:
    path = work / name
    rejected = json.loads(path.read_text())
    if session == 95793:
        assert 'runtime' not in rejected
        original_control = base / '20261117-numerical-source-callbacks-check-control-draft'
        verify(original_control / 'MANIFEST.json', '7c861089c8203809bd703ec0515b67cbe9d95790a7c86ecbef4a2922c0378896')
        original_selection = original_control / 'SELECTION.json'
        assert json.loads(original_selection.read_text())['runtime'] == runtime_name
        bound.add(original_selection)
    else:
        assert rejected['runtime'] == runtime_name
    failed_run = base / runtime_name
    result_path = failed_run / 'results.json'
    result_digest = rejected['result_sha256'] if session == 95793 else rejected['results_sha256']
    failed = json.loads(verify(result_path, result_digest))
    for log_name, log_record in rejected['logs'].items():
        filename = log_name if log_name.endswith('.txt') else log_name + '.txt'
        verify(failed_run / filename, log_record)
    assert rejected['actual_session'] == session and rejected['actual_terminal'] and rejected['actual_exit'] == 1
    assert rejected['checks'] == failed['checks'] and rejected['generated_sorryAx_reports_rejected']
    assert not (failed_run / 'checked.json').exists() and not failed['proof_credit']
    verify_pin_map(failed_run / 'source-pins.json')
    bound.update([path, failed_run / 'results.json'])
    bound.update(failed_run / (item['name'] + '.txt') for item in failed['checks'])

chosen = {item['module']: item for item in selected['components']}
raw_sources = {}
public_names = []
definition_names = []
private_count = 0
for item in components:
    for key, value in chosen[item['module']].items():
        assert item[key] == value, (item['module'], key)
    packet = base / item['packet']
    manifest = json.loads(verify(packet / 'MANIFEST.json', item['manifest_sha256']))
    for name, record in records(manifest['files']):
        verify(packet / name, record)
    if (packet / 'SOURCE-PINS.json').exists():
        verify_pin_map(packet / 'SOURCE-PINS.json')
    raw = verify(root / item['source_path'], {'sha256': item['raw_sha256'], 'bytes': item['raw_bytes']})
    declarations = raw
    if item['kind'] == 'existing_owner_EOF':
        before = verify(root / item['old_snapshot'], {'sha256': item['owner_sha256'], 'bytes': item['owner_bytes']})
        prefix = verify(packet / item['import_prefix'], item['import_prefix_sha256']) if item.get('import_prefix') else b''
        appended = verify(packet / item['append'], item['append_sha256'])
        assert raw == prefix + before + appended and item['old_owner_offset'] == len(prefix)
        declarations = appended
    if item.get('raw_stored_in_packet', True):
        assert raw == (packet / item['source']).read_bytes()
    assert b'#print axioms ' not in raw and b'#check ' not in raw
    assert not re.search(rb'set_option\s+(maxHeartbeats|maxRecDepth|warningAsError|linter\.)', declarations)
    assert len(re.findall(rb'^private theorem ', declarations, re.M)) == item['new_private_theorems']
    private_count += item['new_private_theorems']
    for header in item['headers']:
        assert verify(packet / header['file'], header['sha256']).rstrip(b'\n') in declarations
    public_names.extend(item['public_qnames'])
    definition_names.extend(item.get('declaration_names', []))
    raw_sources[item['module']] = raw
assert len(public_names) == len(set(public_names)) == 15 and private_count == 10
assert definition_names == ['MicroCFTA.SourceCurrentNativeNumericalSeedInvariant.Seeds']
public = ''.join('#print axioms ' + name + '\n' for name in public_names).encode()
assert public == (work / 'PUBLIC-PROBES.lean.txt').read_bytes() == (control / 'EXPECTED-PUBLIC-PROBES.lean.txt').read_bytes()
assert b'execute_returned_of_actual_prefixes' not in public and b'seeds_preserved_at_every_actual_query_endpoint' not in public
imports = (work / 'IMPORTS.lean.txt').read_bytes()
assert imports == (control / 'EXPECTED-IMPORTS.lean.txt').read_bytes()
assert len(imports) == stage['audit_old_block_offset'] == 485 and imports.count(b'import ') == 8
old_audit = verify(root / overrides[audit_name], {'sha256': stage['old_audit_sha256'], 'bytes': stage['old_audit_bytes']})
assert old_audit.count(b'#print axioms ') == 709
assert (root / audit_name).read_bytes() == imports + old_audit + b'\n' + public
assert (root / audit_name).read_bytes().count(b'#print axioms ') == 724
assert len(re.findall(rb'^import ', (root / audit_name).read_bytes(), re.M)) == 5278
assert b'#check MicroCFTA.SourceCurrentNativeNumericalSeedInvariant.Seeds' not in (root / audit_name).read_bytes()
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 304
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
verify(root / owner_name, owner_sha)
for name in ['strict-bind.py.txt', 'publication-driver.py.txt', 'shadow-compile.py.txt']:
    ast.parse((control / name).read_text())
normal_objects = root / 'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()

# Root runs the mutation phase only after reviewing every preflight check.
runtime.mkdir()
objects = Path(tempfile.mkdtemp(prefix='mcfta-numerical-seed-closure-publication-'))
(objects / 'MicroCFTA').mkdir()
for dependency in normal_objects.glob('*.olean'):
    if dependency.stem not in chosen:
        (objects / 'MicroCFTA' / dependency.name).symlink_to(dependency)
(runtime / 'objects.json').write_text(json.dumps({'path': str(objects)}, indent=2) + '\n')
for module, raw in raw_sources.items():
    path = runtime / 'source/MicroCFTA' / (module + '.lean')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    bound.add(path)
fresh_imports = ''.join('import MicroCFTA.' + module + '\n' for module in selected['compile_order']).encode()
(runtime / 'FreshPublicProbes.lean').write_bytes(fresh_imports + public + b'\n#check ' + definition_names[0].encode() + b'\n')
(runtime / 'IndependentProbes.lean').write_bytes(imports + prior_independent + b'\n' + public)
for src, dst in [('strict-bind.py.txt', 'strict-new-and-bind.py'), ('publication-driver.py.txt', 'check.py'), ('shadow-compile.py.txt', 'shadow-compile.py')]:
    (runtime / dst).write_bytes((control / src).read_bytes())
(runtime / 'REPORT-BASE.json').write_bytes((control / 'REPORT-BASE.json').read_bytes())
inheritance = {
    'compile_order': selected['compile_order'], 'definition_names': definition_names,
    'prior_checkpoint': prior_checkpoint, 'prior_archive_manifest_sha256': prior_manifest_sha,
    'prior_checked_sha256': sha((prior_run / 'checked.json').read_bytes()),
    'prior_pins_sha256': sha((prior_run / 'source-pins.json').read_bytes()),
    'stage_sha256': sha(stage_path.read_bytes()), 'baseline_sha256': sha(baseline_path.read_bytes()),
    'baseline_overrides': overrides,
    'override_digests': {name: sha((root / path).read_bytes()) for name, path in overrides.items()},
    'inherited_reports': 503, 'fresh_reports': 15, 'combined_reports': 518,
    'resource_owner_sha256': owner_sha, 'resource_owner_reports_inherited': 264,
    'owner_preflight_reports_fresh_this_batch': 0, 'new_private_helpers': 10,
    'owning_private_reports_bound_separately': 2, 'new_Prop_definitions': 1,
    'Prop_declaration_checks': 1, 'Prop_axiom_credit': 0,
    'actual_private_session': receipt['actual_session'], 'private_receipt_sha256': sha(receipt_path.read_bytes()),
    'fresh_owner_theorem_credit': 0, 'cache_data_copied': False,
}
(runtime / 'INHERITANCE-SELECTION.json').write_text(json.dumps(inheritance, indent=2) + '\n')
bound.update([Path(__file__), baseline_path, stage_path, work / 'PUBLIC-PROBES.lean.txt', work / 'IMPORTS.lean.txt', prior_run / 'IndependentProbes.lean'])
bound.update(current)
bound.update(path for path in runtime.iterdir() if path.is_file())
(runtime / 'source-pins.json').write_text(json.dumps({str(path.relative_to(root)): sha(path.read_bytes()) for path in sorted(bound)}, indent=2, sort_keys=True) + '\n')
print(json.dumps({'runtime': str(runtime), 'gates': 5, 'strict_fresh_modules': 13,
    'fresh_public_reports': 15, 'definition_checks': 1, 'inherited_reports': 503,
    'combined_reports': 518, 'source_files': 6278, 'independent_reports': 319,
    'audit_reports': 724, 'objects': str(objects), 'normal_Source_changed': False}))
