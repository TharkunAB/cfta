from pathlib import Path
import ast
import hashlib
import json
import re
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
control = base / '20261117-numerical-seed-closure-publication-control-draft'
work = base / '20261117-numerical-source-callbacks-work'
runtime = base / '20261117-numerical-seed-closure-publication'
repair = base / '20261117-numerical-seed-closure-publication-receipt-schema-repair'
archive_control = base / '20261118-actual-query-sequence-seeds-checkpoint-control-draft'
assert Path(__file__).resolve().parent == work.resolve(), 'Root must review and copy this preparer.'
assert Path(__file__).read_bytes() == (archive_control / 'prepare-checkpoint-controls.py').read_bytes()
assert runtime.is_dir(), 'The actual passed publication must exist.'
sha = lambda data: hashlib.sha256(data).hexdigest()
bound = set()
audit_name = 'lean/MicroCFTA/Audit.lean'
prior_work = base / '20261117-third-query-node-seed-work'
prior_run = base / '20261117-third-query-six-seed-publication'
prior_archive = base / '20261117-third-query-six-seed-checkpoint'
prior_checkpoint = '5be0346650aac0057062fd1e0d36b9744bcb4c79'
prior_manifest_sha = 'b581a4ad0fdb153f7388c0fb1b566d4b68a7dfcd810078361fec91000146fd1c'
source_commit = 'f21685746f00e574ef5554a85a7c83676b11e5fc'


def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data


def records(value):
    return list(value.items()) if isinstance(value, dict) else [(item['path'], item) for item in value]


for name, record in json.loads((control / 'MANIFEST.json').read_text())['files'].items():
    verify(control / name, record)
bound.add(control / 'MANIFEST.json')
assert sha((control / 'MANIFEST.json').read_bytes()) == '54f4516bf40bfa0e0afe373391d14a341e1987ce291c894981aac0e27e2dc973'
for name, record in json.loads((repair / 'MANIFEST.json').read_text())['files'].items():
    verify(repair / name, record)
bound.add(repair / 'MANIFEST.json')
for name, record in json.loads((control / 'ACTUAL-INPUT-PINS.json').read_text()).items():
    verify(root / name, record)
stage_control = base / '20261117-numerical-seed-closure-repair-staging-control-draft'
verify(stage_control / 'MANIFEST.json', '522eb45cdaab3063a14bf460114ec21e29f80fe2219d05d16ac2812ca8a4917f')
for name, record in json.loads((stage_control / 'MANIFEST.json').read_text())['files'].items():
    verify(stage_control / name, record)
expected_stage = json.loads((control / 'EXPECTED-STAGE.json').read_text())
stage_path = work / 'SOURCES-NORMAL-STAGING.json'
stage = json.loads(stage_path.read_text())
for key, value in expected_stage.items():
    if key not in ['status', 'actual_private_session', 'actual_terminal']:
        assert stage[key] == value, key
assert stage['status'] == 'ACTUALLY STAGED BY ROOT AFTER VERIFIED TERMINAL PASS'
assert stage['actual_terminal'] and stage['normal_Source_changed'] and not stage['published']
assert stage['source_baseline'] == source_commit and stage['prior_checkpoint'] == prior_checkpoint
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports']) == (6278, 5278, 724)
assert (stage['new_modules'], stage['changed_existing_owners'], stage['fresh_public_reports']) == (8, 5, 15)
assert stage['owning_private_reports_not_in_audit'] == 2 and stage['new_Prop_definitions'] == 1
assert not stage['new_Seeds_check_in_audit'] and not stage['joint_finite_completion_proved']
bound.add(stage_path)
private_control = base / stage['private_control']
verify(private_control / 'MANIFEST.json', stage['private_control_manifest_sha256'])
selection_bytes = verify(private_control / 'SELECTION.json', stage['private_selection_sha256'])
assert selection_bytes == (control / 'CHECK-SELECTION.json').read_bytes()
selected = json.loads(selection_bytes)
assert len(selected['components']) == selected['expected_checks'] == 13
assert selected['expected_axiom_reports'] == 17 and selected['expected_public_axiom_reports'] == 15
assert selected['expected_private_axiom_reports'] == 2 and selected['new_private_helpers'] == 10
private_run = base / stage['runtime']
assert selected['runtime'] == private_run.name
receipt_path = work / stage['future_verified_receipt']
receipt = json.loads(receipt_path.read_text())
assert type(receipt['actual_session']) is int and receipt['actual_session'] > 0
assert receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
assert receipt['actual_session'] == stage['actual_private_session']
assert receipt['runtime'] == private_run.name and receipt['source_baseline'] == source_commit
assert receipt['source_files'] == 6270 and not receipt['normal_Source_changed'] and not receipt['published']
assert receipt['actual_public_reports'] == 15 and receipt['actual_owning_private_reports'] == 2
assert receipt['actual_total_reports'] == 17 and receipt['actual_definition_checks'] == 1
assert receipt['new_private_helpers_transitive'] == 10 and receipt['new_Prop_definitions'] == 1
assert receipt['Prop_axiom_credit'] == 0 and receipt['all_thirteen_components_checked']
assert receipt['actual_admitted_query_sequence_Seeds_producer_checked']
assert not receipt['original_eager_worker_all_calls_Seeds_propagation_proved']
assert not receipt['joint_finite_completion_proved']
checked_bytes = verify(private_run / 'checked.json', receipt['checked_sha256'])
checked = json.loads(checked_bytes)
assert json.loads((private_run / 'results.json').read_text()) == checked
assert receipt['checks'] == checked['checks'] and len(checked['checks']) == 13 and all(checked['passed'])
assert checked['all_thirteen_seed_closure_components_checked'] and checked['proof_credit']
assert checked['failure'] is None and checked['actual_total_axiom_reports'] == 17
assert checked['actual_public_axiom_reports'] == 15 and checked['actual_owning_private_axiom_reports'] == 2
assert checked['actual_definition_declaration_checks'] == 1
assert checked['new_private_helpers_compiled_transitively'] == 10
assert checked['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
assert stage['private_receipt_sha256'] == sha(receipt_path.read_bytes())
assert stage['private_checked_sha256'] == sha(checked_bytes)
private_pin_bytes = verify(private_run / 'source-pins.json', receipt['source_pins_sha256'])
private_pins = json.loads(private_pin_bytes)
assert receipt['pins_independently_reverified'] == stage['actual_pins_reverified'] == len(private_pins)
assert [item['name'] for item in checked['checks']] == selected['compile_order']
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['sorryAx']
    and not item['nonstandard_axioms'] for item in checked['checks'])
bound.update([receipt_path, private_run / 'results.json'])
bound.update(private_run / (item['name'] + '.txt') for item in checked['checks'])

# Resolve every historical Source pin by its exact digest.
overrides = stage['baseline_overrides']
assert len(overrides) == 6
prior_stage = json.loads((prior_work / 'SOURCES-NORMAL-STAGING.json').read_text())
historical_overrides = prior_stage['baseline_overrides']


def verify_historical(name, record):
    digest = record['sha256'] if isinstance(record, dict) else record
    candidates = [root / name]
    for mapping in [overrides, historical_overrides]:
        if name in mapping:
            candidates.append(root / mapping[name])
    for path in candidates:
        if path.is_file() and sha(path.read_bytes()) == digest:
            return verify(path, record)
    raise AssertionError(name)


def verify_pin_map(path):
    bound.add(path)
    for name, record in records(json.loads(path.read_text())):
        verify_historical(name, record)


baseline_path = work / 'SEED-CLOSURE-baseline-source-pins.json'
baseline = json.loads(baseline_path.read_text())
assert len(baseline) == 6270
for name, record in baseline.items():
    verify(root / overrides.get(name, name), record)
current = sorted((root / 'lean/MicroCFTA').glob('*.lean'))
components = stage['components']
assert len(components) == 13
new_names = {item['source_path'] for item in components if item['kind'] == 'new_module'}
assert len(new_names) == 8 and not set(baseline).intersection(new_names)
assert {str(path.relative_to(root)) for path in current} == set(baseline) | new_names
assert len(set(baseline) - set(overrides)) == 6264
for name, record in private_pins.items():
    verify_historical(name, record)
# Bind the prior pushed source, publication and immutable archive.
prior_source = json.loads((prior_work / 'SOURCE-COMMIT.json').read_text())
prior_publication = json.loads((prior_work / 'PUBLICATION-VERIFIED.json').read_text())
push = json.loads((prior_work / 'PUSH-VERIFIED.json').read_text())
assert prior_source['source_commit'] == push['source_commit'] == source_commit
assert prior_source['actual_terminal'] and prior_source['actual_terminal_exit'] == 0
assert prior_publication['actual_terminal'] and prior_publication['actual_terminal_exit'] == 0
assert prior_publication['actual_session'] == prior_source['publication_actual_session'] == 60614
assert [item['total_axiom_reports'] for item in prior_publication['checks']] == [709, 7, 304, 709, 709]
assert push['checkpoint_commit'] == push['remote_commit'] == prior_checkpoint
assert push['actual_push_terminal'] and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal'] and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
verify(prior_archive / 'manifest.json', prior_manifest_sha)
prior_checked = json.loads((prior_run / 'checked.json').read_text())
assert (prior_checked['source_files'], prior_checked['independent_reports'], prior_checked['resource_and_component_probes']) == (6270, 304, 503)
assert len(prior_checked['checks']) == 5 and prior_checked['all_five_gates_passed']
verify_pin_map(prior_run / 'source-pins.json')
bound.update([prior_work / 'SOURCE-COMMIT.json', prior_work / 'PUSH-VERIFIED.json',
    prior_work / 'PUBLICATION-VERIFIED.json', prior_work / 'SOURCES-NORMAL-STAGING.json',
    prior_run / 'checked.json', prior_archive / 'verify.py', prior_archive / 'archived-inputs.json'])
for name, session, runtime_name in [
    ('FIRST-CHECK-REJECTED.json', 95793, '20261117-numerical-source-callbacks-check'),
    ('REPAIR-CHECK-REJECTED.json', 78168, '20261117-numerical-source-callbacks-repair-check'),
    ('SEED-CLOSURE-CHECK-REJECTED.json', 63694, '20261117-numerical-seed-closure-check')]:
    path = work / name
    rejected = json.loads(path.read_text())
    if session == 95793:
        assert 'runtime' not in rejected
        original_control = base / '20261117-numerical-source-callbacks-check-control-draft'
        verify(original_control / 'MANIFEST.json', '7c861089c8203809bd703ec0515b67cbe9d95790a7c86ecbef4a2922c0378896')
        original_selection = original_control / 'SELECTION.json'
        assert json.loads(original_selection.read_text())['runtime'] == runtime_name
        bound.add(original_selection)
    else:
        assert rejected['runtime'] == runtime_name
    failed_run = base / runtime_name
    result_path = failed_run / 'results.json'
    result_digest = rejected['result_sha256'] if session == 95793 else rejected['results_sha256']
    failed = json.loads(verify(result_path, result_digest))
    for log_name, log_record in rejected['logs'].items():
        filename = log_name if log_name.endswith('.txt') else log_name + '.txt'
        verify(failed_run / filename, log_record)
    assert rejected['actual_session'] == session and rejected['actual_terminal'] and rejected['actual_exit'] == 1
    assert rejected['checks'] == failed['checks'] and rejected['generated_sorryAx_reports_rejected']
    assert not (failed_run / 'checked.json').exists() and not failed['proof_credit']
    verify_pin_map(failed_run / 'source-pins.json')
    bound.update([path, failed_run / 'results.json'])
    bound.update(failed_run / (item['name'] + '.txt') for item in failed['checks'])

chosen = {item['module']: item for item in selected['components']}
raw_sources = {}
public_names = []
definition_names = []
private_count = 0
for item in components:
    for key, value in chosen[item['module']].items():
        assert item[key] == value, (item['module'], key)
    packet = base / item['packet']
    manifest = json.loads(verify(packet / 'MANIFEST.json', item['manifest_sha256']))
    for name, record in records(manifest['files']):
        verify(packet / name, record)
    if (packet / 'SOURCE-PINS.json').exists():
        verify_pin_map(packet / 'SOURCE-PINS.json')
    raw = verify(root / item['source_path'], {'sha256': item['raw_sha256'], 'bytes': item['raw_bytes']})
    declarations = raw
    if item['kind'] == 'existing_owner_EOF':
        before = verify(root / item['old_snapshot'], {'sha256': item['owner_sha256'], 'bytes': item['owner_bytes']})
        prefix = verify(packet / item['import_prefix'], item['import_prefix_sha256']) if item.get('import_prefix') else b''
        appended = verify(packet / item['append'], item['append_sha256'])
        assert raw == prefix + before + appended and item['old_owner_offset'] == len(prefix)
        declarations = appended
    if item.get('raw_stored_in_packet', True):
        assert raw == (packet / item['source']).read_bytes()
    assert b'#print axioms ' not in raw and b'#check ' not in raw
    assert not re.search(rb'set_option\s+(maxHeartbeats|maxRecDepth|warningAsError|linter\.)', declarations)
    assert len(re.findall(rb'^private theorem ', declarations, re.M)) == item['new_private_theorems']
    private_count += item['new_private_theorems']
    for header in item['headers']:
        assert verify(packet / header['file'], header['sha256']).rstrip(b'\n') in declarations
    public_names.extend(item['public_qnames'])
    definition_names.extend(item.get('declaration_names', []))
    raw_sources[item['module']] = raw
assert len(public_names) == len(set(public_names)) == 15 and private_count == 10
assert definition_names == ['MicroCFTA.SourceCurrentNativeNumericalSeedInvariant.Seeds']
public = ''.join('#print axioms ' + name + '\n' for name in public_names).encode()
assert public == (work / 'PUBLIC-PROBES.lean.txt').read_bytes() == (control / 'EXPECTED-PUBLIC-PROBES.lean.txt').read_bytes()
assert b'execute_returned_of_actual_prefixes' not in public and b'seeds_preserved_at_every_actual_query_endpoint' not in public
imports = (work / 'IMPORTS.lean.txt').read_bytes()
assert imports == (control / 'EXPECTED-IMPORTS.lean.txt').read_bytes()
assert len(imports) == stage['audit_old_block_offset'] == 485 and imports.count(b'import ') == 8
old_audit = verify(root / overrides[audit_name], {'sha256': stage['old_audit_sha256'], 'bytes': stage['old_audit_bytes']})
assert old_audit.count(b'#print axioms ') == 709
assert (root / audit_name).read_bytes() == imports + old_audit + b'\n' + public
assert (root / audit_name).read_bytes().count(b'#print axioms ') == 724
assert len(re.findall(rb'^import ', (root / audit_name).read_bytes(), re.M)) == 5278
assert b'#check MicroCFTA.SourceCurrentNativeNumericalSeedInvariant.Seeds' not in (root / audit_name).read_bytes()
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 304
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = '861927716556bffdeefb2ab403160e791b4ef62be50e11caab5209ca0cf73f93'
verify(root / owner_name, owner_sha)
for name in ['strict-bind.py.txt', 'publication-driver.py.txt', 'shadow-compile.py.txt']:
    ast.parse((control / name).read_text())
normal_objects = root / 'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()

# Root executes archive controls only after every receipt below is final.
import gzip
import subprocess

archive = base / '20261118-actual-query-sequence-seeds-checkpoint'
board_prefix = 'current-board-native-query-sequence-'
read = lambda path: json.loads(path.read_text())
git = lambda *args: subprocess.check_output(['git', *args], cwd=root)
for name, record in read(archive_control / 'MANIFEST.json')['files'].items():
    verify(archive_control / name, record)
for name, record in read(archive_control / 'SOURCE-PINS.json').items():
    verify(root / name, record)
bindings = read(archive_control / 'prior-bindings.json')
assert bindings['prior_checkpoint'] == prior_checkpoint
source_receipt = read(work / 'SOURCE-COMMIT.json')
code = source_receipt['source_commit']
assert code == '1a3de82aec4bab8cc6b21012103e6311a951b266'
assert source_receipt['parent'] == prior_checkpoint
assert source_receipt['actual_terminal'] and source_receipt['actual_terminal_exit'] == 0
assert source_receipt['private_actual_session'] == receipt['actual_session'] == 31981
assert source_receipt['publication_actual_session'] == 10938
assert source_receipt['actual_admitted_query_sequence_Seeds_producer_checked']
assert not source_receipt['all_original_eager_worker_query_admissions_proved']
assert not source_receipt['joint_finite_completion_proved'] and not source_receipt['haskell_changed']
assert git('rev-parse', 'HEAD').decode().strip() == code
assert git('rev-parse', code + '^').decode().strip() == prior_checkpoint
assert git('branch', '--show-current').decode().strip() == 'formalize'
assert not git('status', '--porcelain', '--untracked-files=no')
changed = {item['source_path'] for item in components} | {audit_name}
assert len(changed) == 14 and set(source_receipt['files']) == changed
assert set(git('diff', '--name-only', prior_checkpoint, code).decode().splitlines()) == changed
for name in changed:
    assert git('show', code + ':' + name) == (root / name).read_bytes(), name
for name in changed - new_names:
    assert git('show', prior_checkpoint + ':' + name) == (root / overrides[name]).read_bytes(), name
for name in ['NEXT-PROMPT.md', 'HANDOFF.md', 'FINDINGS.md']:
    assert (root / name).read_bytes() == git('show', code + ':' + name), name
source_control = base / '20261117-numerical-seed-closure-source-commit-control-draft'
verify(source_control / 'MANIFEST.json', 'c6755df960a742cd322d870f0bf1501e979ad85a51f96fc352260a43ad548e34')
for name, record in read(source_control / 'MANIFEST.json')['files'].items():
    verify(source_control / name, record)
report = read(runtime / 'checked.json')
publication = read(work / 'PUBLICATION-VERIFIED.json')
assert publication['actual_session'] == 10938 and publication['actual_terminal'] and publication['actual_terminal_exit'] == 0
assert publication['checks'] == report['checks']
assert [item['total_axiom_reports'] for item in report['checks']] == [724, 15, 319, 724, 724]
assert [(item['axiom_groups'], item['axiom_free_reports']) for item in report['checks']] == [(718, 6), (15, 0), (316, 3), (718, 6), (718, 6)]
assert [item['declaration_checks'] for item in report['checks']] == [0, 1, 0, 0, 0]
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['sorryAx'] and not item['nonstandard_axioms'] for item in report['checks'])
assert report['all_five_gates_passed'] and report['source_pins_unchanged']
for name, value in {'source_files': 6278, 'direct_audit_imports': 5278, 'individual_reports': 724,
        'independent_reports': 319, 'resource_and_component_probes': 518,
        'fresh_resource_component_reports': 15, 'inherited_resource_component_reports': 503,
        'new_public_theorems': 15, 'new_private_theorems': 10, 'new_theorem_declarations': 25,
        'new_prop_definitions': 1, 'new_definition_declaration_checks': 1,
        'new_definition_axiom_credit': 0, 'private_owning_module_reports_bound_separately': 2,
        'resource_owner_reports_inherited': 264, 'owner_preflight_reports_fresh_this_batch': 0,
        'audited_theorems': 100189}.items():
    assert report[name] == value, name
assert publication['definition_checks'] == 1 and publication['Prop_axiom_credit'] == 0
assert publication['new_theorem_declarations'] == 25 and publication['new_Prop_definitions'] == 1
assert publication['owning_private_reports_separate'] == 2
assert not report['original_eager_worker_all_calls_Seeds_propagation_proved']
assert not report['native_inhabitance_proved'] and not report['joint_finite_completion_proved'] and not report['haskell_changed']
public_pins = read(runtime / 'source-pins.json')
for name, digest in public_pins.items():
    assert sha((root / name).read_bytes()) == digest, name
assert publication['pins_independently_reverified'] == len(public_pins) == 7750
assert sha((runtime / 'source-pins.json').read_bytes()) == publication['source_pins_sha256']
assert sha((runtime / 'checked.json').read_bytes()) == publication['checked_sha256']
source_pins = {name: digest for name, digest in public_pins.items() if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
assert len(source_pins) == 6278
for name, record in [('manifest.json', 'prior_manifest_sha256'), ('checkpoint.json', 'prior_checkpoint_json_sha256')]:
    data = (prior_archive / name).read_bytes()
    assert sha(data) == bindings[record]
    assert git('show', prior_checkpoint + ':' + str((prior_archive / name).relative_to(root))) == data
prior_checkpoint_data = read(prior_archive / 'checkpoint.json')
assert prior_checkpoint_data['checked_code'] == bindings['prior_source_commit'] == source_commit
assert prior_checkpoint_data['resource_and_component_probes'] == 503
old_pins = json.loads(gzip.decompress((prior_archive / 'source-pins.json.gz').read_bytes()))
assert baseline == {name: digest for name, digest in old_pins.items() if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
for name, digest in old_pins.items():
    verify_historical(name, digest)
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    assert old_pins[name] == public_pins[name]
request = read(work / (board_prefix + 'request.json'))
canonical = read(work / (board_prefix + 'canonical.json'))
assert canonical['verified']
post = canonical.get('post', canonical)
assert post['id'] == request['request_id']
assert type(post['sequence']) is int and post['sequence'] > 0
for key, expected in [('author', request['username']), ('thread_id', request['thread_id']),
        ('post_type', request['post_type']), ('content', request['content']), ('metadata', request['metadata'])]:
    assert post[key] == expected, key
assert post['metadata']['source'] == code
cleanup = read(work / 'combined-terminal-cleanup-result.json')
assert cleanup['all_owned_terminal_only']
assert cleanup['all_current_batch_actual_runs_terminal']
assert cleanup['normal_lake_symlink_targets_preserved'] and cleanup['unknown_tmp_entries_preserved']
assert cleanup['no_cache_data_copied'] and not cleanup['live_process_references']
actual_runs = [(95793, '20261117-numerical-source-callbacks-check'),
    (78168, '20261117-numerical-source-callbacks-repair-check'),
    (55279, '20261117-numerical-retained-query-check'),
    (63694, '20261117-numerical-seed-closure-check'),
    (31981, '20261117-numerical-seed-closure-repair-check'),
    (10938, '20261117-numerical-seed-closure-publication')]
assert len(cleanup['removed_targets']) == 6
paths = []
for item, (session, name) in zip(cleanup['removed_targets'], actual_runs):
    assert item['actual_session'] == session and item['runtime'] == name
    assert item['path'] == read(base / name / 'objects.json')['path']
    assert not Path(item['path']).exists() and not Path(item['path']).is_symlink()
    paths.append(item['path'])
assert len(set(paths)) == 6
assert cleanup['removed_bytes'] == sum(item['regular_bytes'] for item in cleanup['removed_targets'])
assert cleanup['removed_symlinks'] == sum(item['symlinks'] for item in cleanup['removed_targets'])
assert cleanup['prior_cumulative_removed_bytes'] == 6493212045
assert cleanup['prior_cumulative_removed_bytes'] + cleanup['removed_bytes'] == cleanup['cumulative_removed_bytes']
assert type(cleanup['tmp_readable_regular_file_bytes_after']) is int
assert isinstance(cleanup['tmp_census_errors'], list)
early = read(work / 'terminal-failure-cleanup-result.json')
assert early['removed_regular_bytes'] == 743800 and early['removed_symlinks'] == 12608
assert early['targets'] == cleanup['removed_targets'][:2]
assert cleanup['all_targets_removed'] and cleanup['normal_cache_targets'] == 6312
assert cleanup['initial_two_cleanups_normal_cache_targets'] == early['normal_cache_targets'] == 6304
assert sha((work / 'terminal-failure-cleanup-result.json').read_bytes()) == cleanup['initial_two_cleanup_receipt_sha256']
start = read(work / 'START.json')
assert start['manual_work_explicitly_authorized'] and start['usage_pause_lifted']
assert start['persistent_goal_control_status'] == 'paused'
assert start['expected_checks'] == 2 and start['expected_public_reports'] == 2
assert not start['joint_finite_completion_proved']
# START remains an original two-command plan. Final receipts establish13 commands.
batch = read(work / 'BATCH-SCOPE-UPDATE.json')
assert batch['original_START_preserved'] and not batch['joint_finite_completion_proved']
assert [item['session'] for item in batch['actual_compiler_runs']] == [95793, 78168, 55279, 63694, 31981, 10938]
assert batch['source_commit'] == code and batch['normal_Source_files'] == 6278
assert (batch['fresh_reports'], batch['inherited_reports'], batch['combined_reports']) == (15, 503, 518)
resume = read(work / 'RESUME-AUTHORIZATION.json')
assert resume['manual_work_explicitly_authorized'] and resume['earlier_usage_pause_lifted']
assert "Keep going. We'll use a reset if needed." in resume['authorizing_instructions']
assert resume['persistent_goal_control_status'] == 'paused'
assert not resume['goal_operation_performed'] and not resume['goal_completion_claimed']
assert resume['push_scope'] == {'remote': 'git@github.com:TharkunAB/cfta.git', 'ref': 'refs/heads/formalize', 'force': False, 'fork_push': False}
usage = read(work / 'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int, float] and 0 <= percent <= 100
assert usage['current_usage_not_measured'] and usage['earlier_usage_pause_lifted_by_user_resume']
assert percent == 81 and '17:53:' in usage['checked_at']
roots = read(archive_control / 'selection-roots.json')
assert len(roots) == len(set(roots)) == 41
additional = read(archive_control / 'archive-additional-roots.json')
assert len(additional) == 3
for item in additional:
    assert item['current_batch_theorem_credit'] == 0 and not item['private_runtime_selected']
    packet = base / item['root']
    manifest = read(packet / item['manifest'])
    verify(packet / item['manifest'], item['sha256'])
    for name, record in records(manifest['files']):
        verify(packet / name, record)
    roots.append(item['root'])
assert len(roots) == len(set(roots)) == 44
assert all((base / name).is_dir() and not (base / name).is_symlink() for name in roots)
for name in roots:
    packet = base / name
    if (packet / 'check.py').exists():
        result = read(packet / ('checked.json' if (packet / 'checked.json').exists() else 'results.json'))
        assert result['checks'] and all(type(item['exit']) is int for item in result['checks'])
for item in read(archive_control / 'original-header-files.json'):
    assert sha((root / item['path']).read_bytes()) == sha((root / item['original']).read_bytes()) == item['sha256']
selected_roots = sorted(str((base / name).relative_to(root)) for name in roots)
assert not archive.exists()
tree = hashlib.sha256()
for name, digest in sorted(source_pins.items()):
    tree.update(name.encode() + b'\0' + digest.encode() + b'\n')
config = dict(report)
config.update(checked_code=code, prior_checkpoint=prior_checkpoint, public_run=str(runtime), public_gates=5,
    explicit_reports=724, board_prefix=board_prefix, board_post_id=post['id'], board_sequence=post['sequence'],
    source_tree_sha256=tree.hexdigest(), old_non_audit_source_files_byte_exact=6264,
    old_audit_contiguous_bytes_preserved=431699, old_audit_exact_offset=485,
    optional_old_entire_block_bytes=47211, optional_old_entire_block_offset=55,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],
    cleanup_receipt='combined-terminal-cleanup-result.json', removed_symlinks=cleanup['removed_symlinks'],
    tmp_readable_regular_file_bytes_after=cleanup['tmp_readable_regular_file_bytes_after'],
    tmp_census_errors=cleanup['tmp_census_errors'], historical_primary_usage_percent=percent,
    historical_primary_usage_checked_at=usage['checked_at'], current_usage_not_measured=True,
    prior_immutable_archive=prior_archive.name, prior_manifest_sha256=bindings['prior_manifest_sha256'],
    actual_private_session=31981, actual_publication_session=10938,
    actual_private_owning_reports=2, actual_Prop_definition_checks=1, actual_Prop_axiom_credit=0,
    old_usage_pause_reintroduced=False, persistent_goal_control_status='paused',
    work_authorized_by_explicit_user_resume=True, goal_active=False, goal_completion_claimed=False,
    original_worker_admissions_proved=False, native_inhabitance_proved=False,
    joint_finite_completion_proved=False, compiled_haskell_correspondence_proved=False, haskell_changed=False,
    additional_frozen_roots=additional, additional_frozen_roots_theorem_credit=0,
    future_worker_attachment_runtimes_selected=False)
skipped = sorted(str(path.relative_to(root)) for path in base.iterdir()
    if path.is_dir() and path.name.startswith(('20261117-', '20261118-')) and str(path.relative_to(root)) not in selected_roots)
review = {'selected_roots': 44, 'base_roots': 41, 'additional_frozen_roots': additional,
    'additional_frozen_roots_theorem_credit': 0, 'fresh_public_reports': 15,
    'owning_private_reports_bound_separately': 2, 'inherited_reports': 503, 'combined_reports': 518,
    'new_public_theorems': 15, 'new_private_theorems': 10, 'new_theorem_declarations': 25,
    'new_Prop_definitions': 1, 'Prop_declaration_checks': 1, 'Prop_axiom_credit': 0,
    'resource_owner_reports_inherited': 264, 'current_batch_failures_preserved': [95793, 78168, 63694],
    'successful_component_and_full_runs_preserved': [55279, 31981, 10938],
    'base54_and_schema_supplement4e_preserved': True, 'all_root_documents_preserved_as_suffix': True,
    'original_BodyFirst_FIRST_byte_equal_to_selected': False,
    'future_worker_attachment_runtimes_selected': False, 'joint_finite_completion_proved': False}
note = (archive_control / 'checkpoint-note.md').read_text()
for key, value in {'THEOREMS': report['audited_theorems'], 'REMOVED': cleanup['removed_bytes'],
        'SYMLINKS': cleanup['removed_symlinks'], 'CLEANUP': cleanup['cumulative_removed_bytes'],
        'USAGE': percent, 'BOARD': post['sequence']}.items():
    note = note.replace('{{' + key + '}}', str(value))
assert set(re.findall(r'\{\{(.*?)\}\}', note)) == {'TIME', 'TREE', 'CODE'}
outputs = {'checkpoint-config.json': config, 'archive-roots.json': selected_roots,
    'skipped-published-roots.json': skipped, 'selection-review.json': review}
assert all(not (work / name).exists() for name in outputs)
# No archive or Work write occurs before every preceding guard passes.
for name, value in outputs.items():
    (work / name).write_text(json.dumps(value, indent=2) + '\n')
(work / 'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code': code, 'archive': archive.name, 'roots': 44,
    'board_sequence': post['sequence'], 'fresh_public_reports': 15, 'inherited_reports': 503,
    'combined_reports': 518, 'current_usage_not_measured': True}))
