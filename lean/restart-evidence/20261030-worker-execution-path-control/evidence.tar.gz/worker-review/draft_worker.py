from pathlib import Path
import json,hashlib
r=Path('/tmp/mcfta-worker-execution-path-control-20261030/worker-review');headers=json.loads((r/'HEADER-DATA.json').read_text());body=[]
for x in headers:
 kind=x['kind'];original='SourcePruningEnumeration'+('' if kind=='Native' else 'Prepared')+'Recursive';zero='resume_'+kind.lower()+'_zero_paths';proof=''' := by
  revert inventory caller memos before metadata seed ceiling
  induction recursiveFuel with
  | zero =>
      intro _inventory caller memos before metadata _seed _ceiling
        _packet _bounded _known _selectionMembers _selectionLength _initialMass _reserved original _projected
      refine ⟨0, ?_⟩
      intro extra
      exact SourcePruningEnumerationExecutionPaths.ZERO P
        holeKey fits admits graph templates checkEmpty edgesOf stop order (0 + extra)
        metadata caller memos.query before
        (SourcePruningEnumerationRestart.decision stop order metadata before) original
  | succ recursiveFuel ih =>
      intro inventory caller memos before metadata seed ceiling
        packet bounded known selectionMembers selectionLength initialMass reserved original projected
      cases chosen : SourcePruningEnumerationRestart.decision stop order metadata before with
      | none =>
          refine ⟨0, ?_⟩
          intro extra
          unfold SourcePruningEnumerationExecutionPaths.KIND
          rw [chosen]
          refine ⟨original, ?_, True.intro⟩
          intro output member
          cases List.mem_singleton.mp member
          exact original
      | some selected =>
          cases selected with
          | done =>
              refine ⟨0, ?_⟩
              intro extra
              unfold SourcePruningEnumerationExecutionPaths.KIND
              rw [chosen]
              refine ⟨original, ?_, True.intro⟩
              intro output member
              cases List.mem_singleton.mp member
              exact original
          | stuck =>
              refine ⟨0, ?_⟩
              intro extra
              unfold SourcePruningEnumerationExecutionPaths.KIND
              rw [chosen]
              refine ⟨original, ?_, True.intro⟩
              intro output member
              cases member
          | expand uv =>
              obtain ⟨bound, _outcome, _running, _resources, paths⟩ :=
                SourcePruningEnumerationExecutionExpansionBridge.KIND.selected_finite_complete_resources_paths
                  holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver recursiveFuel
                  (ORIGINAL.finite_complete
                    holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver recursiveFuel)
                  inventory caller memos before metadata uv seed ceiling packet bounded known
                  selectionMembers selectionLength initialMass reserved chosen P original tails projected
                  (by
                    intro nextInventory nextCaller nextMemos nextCache nextMetadata nextSeed nextCeiling
                      nextPacket nextBounded nextKnown nextMembers nextLength nextMass nextReserved nextPaths nextProjected
                    exact ih nextInventory nextCaller nextMemos nextCache nextMetadata nextSeed nextCeiling
                      nextPacket nextBounded nextKnown nextMembers nextLength nextMass nextReserved nextPaths nextProjected)
              refine ⟨bound, ?_⟩
              intro extra
              simpa only [SourcePruningEnumerationExecutionPaths.KIND, chosen] using paths extra
'''.replace('KIND',kind).replace('ZERO',zero).replace('ORIGINAL',original)
 resourceProof=''' := by
  obtain ⟨resourceBound, outcome, running, resources⟩ := ORIGINAL.run_finite_complete_resources
    holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver recursiveFuel inventory
    caller memos before metadata seed ceiling packet bounded known selectionMembers selectionLength initialMass reserved
  obtain ⟨pathBound, paths⟩ := run_finite_paths
    holeKey fits admits graph templates checkEmpty edgesOf stop order formulas solver recursiveFuel inventory
    caller memos before metadata seed ceiling packet bounded known selectionMembers selectionLength initialMass reserved
    P original tails projected
  refine ⟨resourceBound + pathBound, outcome, ?_, resources, ?_⟩
  · intro extra
    simpa only [Nat.add_assoc] using running (pathBound + extra)
  · intro extra
    have current := paths (resourceBound + extra)
    have same : pathBound + (resourceBound + extra) = resourceBound + pathBound + extra := by omega
    rw [same] at current
    exact current
'''.replace('ORIGINAL',original)
 body.append(x['context']+'/-- Original inputs derive all actual paths at every finite recursive depth. -/\n'+x['path']+proof+'\n/-- One stable actual outcome keeps its resources and all execution paths at the same work bound. -/\n'+x['resource']+resourceProof+'\nend '+x['namespace']+'\n')
text='''import MicroCFTA.SourcePruningEnumerationFiniteResources
import MicroCFTA.SourcePruningEnumerationPreparedFiniteResources
import MicroCFTA.SourcePruningEnumerationExecutionExpansionBridge

/-!
# Original-input paths for both finite-depth enumeration workers

UNCOMPILED source-only draft. Depth induction supplies every smaller worker.
No future worker, stage, trace or completion supplier remains in the public inputs.
One common larger work bound retains each stable outcome and its resources.
-/
'''+ '\n'.join(body)
p=r/'ExecutionWorkerPaths-v1-UNCOMPILED.lean';assert not p.exists();p.write_text(text);p.chmod(0o444);print(json.dumps(dict(path=str(p),lines=len(text.splitlines()),bytes=len(text.encode()),sha256=hashlib.sha256(text.encode()).hexdigest()),indent=2))
