# Both finite-depth worker path inductions

This is a frozen source-only handoff. The owner candidate remains historical and UNCOMPILED.
Root's probe of the exact owner V1 found four introN errors.
Root repaired those proof binders outside this owner directory and reported its V2 probe PASS.
All four V1 public theorem statements remain exact in Root V2.
Root V3 removes only the status sentence; installed build and strict checking were running at Root's21:01 CET update.
No compiler, evaluator, native command, Git, network, board or production write ran in this owner scope.
The earlier expansion-review bundle remains immutable.

## Artifact and exact public contracts

`ExecutionWorkerPaths-v1-UNCOMPILED.lean` has305 lines and19719 bytes.
Its SHA256 is `8c74504d87ad018c87879e845248a0b234dd535d235f410f16f06ced50b9654a`.
The intended production module is `MicroCFTA.SourcePruningEnumerationExecutionWorkerPaths`.
It contains four public declarations:

- `Native.run_finite_paths`.
- `Prepared.run_finite_paths`.
- `Native.run_finite_complete_resources_paths`.
- `Prepared.run_finite_complete_resources_paths`.

The complete headers and implicit contexts are in `PUBLIC-TARGETS-UNCOMPILED.md`.
`FINAL-CONTRACT-CHECKS.json` compares all four actual V1 headers with those immutable targets.
Each law keeps the exact old run_finite_complete_resources input prefix.
This prefix contains the actual configuration, formulas, solver, depth, inventory, caller, memos, cache, metadata, seed and ceiling.
It also contains the original Packet, Fits, Heap, selected-edge membership/length, suspended mass and Reserved gates.
The added final inputs are exactly P, initial StatePaths, suffix closure and ProjectionPaths of the worker's computed final forecast at the same depth/seed/ceiling.
There is no final Complete, pathsIH, successful trace, future Stage or target equality input.
No original finite-carrier wrapper was added. Root owns that separate composition.

The path law concludes that one work bound supplies actual ExecutionPaths.Native or ExecutionPaths.Prepared at every bound+extra and the supplied finite recursive depth.
The resource companion preserves the exact old existential stable outcome, actual running equation and OutcomeResources clause.
It appends the path law at that same work bound.
The four statements do not claim that the supplied recursive depth suffices for the desired enumeration prefix.

## Concrete induction and branch scope

Both resource finite_complete producers are already closed theorems.
Their result is the old Complete contract at any finite recursive depth.
The worker proof calls that theorem internally at the predecessor depth.
The selected companion therefore receives its old resource supplier without exposing a new public premise.

The zero case applies the already checked literal zero-path law at the original restart decision.
At a successor depth, the proof cases on the actual restart decision.
The none and done branches retain their literal singleton output cache.
The stuck branch has the literal empty output.
Those branches use initial StatePaths directly; they do not assume a later worker or a trace.

The expanding branch calls the corresponding actual selected companion.
It supplies that companion's concrete smaller-depth eventual path premise from the depth induction hypothesis.
That call retains the same P and the smaller call's own Packet, Fits, Heap, reservation, mass and computed forecast gates.
The smaller calls are not restricted to the original cache or caller.
Their inherited path requirement comes from the selected bridge's actual primitive operations and admission.
The final result refers to the literal actual worker and its original decision.

The checked selected predicate already includes parked returned decisions, retained-after caches, raw ordinary/preparation rows, sibling order, every actual hook invocation before finish, stopped hooks, empty-output hooks and retained failure data.
The worker induction consumes that exact predicate. It does not replace it with an output-only assertion.
The Prepared proof uses its separate selected bridge. It retains terminal-before-node dispatch and its own prepared caller/cache.

The resource companion chooses resourceBound+pathBound.
The old resource running equation applies with extra pathBound+extra.
The path equation applies with extra resourceBound+extra.
A natural-number equality identifies their common work bound.
The outcome and resource forecast remain the exact old witnesses and computed final profile.

## The Root-owned proof repair

The V1 tactic reverted inventory, caller, memos, before, metadata, seed and ceiling.
The selected-edge membership and length hypotheses are independent of all those variables.
Lean therefore kept them fixed in context.
V1 incorrectly tried to introduce them again in both zero and successor cases.
This produced the four Root-reported introN errors.

Root V2 removes those duplicate introductions.
It also removes nextMembers and nextLength from the explicit ih application.
The selected bridge still requires those two lambda inputs, so Root keeps them with underscore names.
This proof repair changes no public statement or selected contract.
The immutable owner V1 retains the exact failure for provenance.
Root's repaired and checked source is outside this bundle.

All unfiltered compiler evidence is Root-owned at these exact paths:

- `/tmp/mcfta-worker-execution-path-control-20261030/worker-paths-v1-probe/report.json`.
- `/tmp/mcfta-worker-execution-path-control-20261030/worker-paths-v1-probe/raw.log`.
- `/tmp/mcfta-worker-execution-path-control-20261030/worker-paths-v1-probe/inputs.json`.
- `/tmp/mcfta-worker-execution-path-control-20261030/worker-v1-repair.json`.
- `/tmp/mcfta-worker-execution-path-control-20261030/worker-paths-v2-probe/report.json`.

Root explicitly requested that these outputs stay outside the source-only owner bundle.
This review did not run those commands or independently inspect their logs.
Root reported V2 probe PASS with hash prefix1d8b27ee; it reported unchanged four headers.
No Audit, public sweep or Haskell validation is claimed for this owner candidate.

## Acquisition and source identity

The new OLD whole-source allowance was three modules. Only two were acquired:

- Native finite resources:80/80 lines,5308 bytes, SHA256 `1d894b6901565957ca7fc696f7cc6fdfe380ceef2b0efaf90ec01b3a1c797ea4`.
- Prepared finite resources:81/81 lines,5391 bytes, SHA256 `7f31a61f86e93d33c8b875a0fee8e40c651b37fb685756954750a1ab90a2bc29`.

The actual Native resume/run equations were acquired at83–126 of128 lines.
The actual Prepared resume/run equations were acquired at75–118 of120 lines.
Two one-line finite-run-step declaration locators were retained for the earlier rg output; no proof body was acquired there.
No union of cuts reconstructs a third new whole or near-whole old source.
There were no EOF clamps or output truncation in this task.

Four full frozen payloads were reused after manifest and byte identity checks: ExecutionPaths, ExecutionPathData, the prior paired selected V2 and prior ordinary V2.
The two production predicate sources also match their frozen current bytes.
The prior candidate copies stay labeled UNCOMPILED and are not mistaken for Root's repaired installed sources.

The installed selected source has SHA256 `66849f6807af5dc1e1dac609414c8a3923d996a3fef04b4d1ea56f28dcbde44c`.
Only its complete public contract scopes16–88 and311–387 of755 lines were acquired in this task.
Both match the frozen selected V2 theorem headers exactly.
Root reported the installed selected producer build and strict checks PASS.
The fresh Root output is recorded separately from frozen byte-identical reuse.
All requested/actual scopes, full-source/copy hashes and cumulative unions are pinned in the acquisition metadata.

## Boundary and seal

The internal smaller-depth supplier is removed from both final worker path statements.
Their validity depends on Root's repaired checked proof, not on the historical owner V1.
The original Packet, numeric Fits/Reserved and computed forecast projection gates remain explicit.
This result does not supply an original sufficient depth, configured prefix coverage, public-adapter closure or Haskell correspondence.
The full library objective remains active.
No Haskell source was read, changed or run. No Haskell fix was found for FINDINGS.

Every owner payload is pinned and read-only at write halt.
Root owns any further proof repair, integration, validation and publication outside this bundle.
