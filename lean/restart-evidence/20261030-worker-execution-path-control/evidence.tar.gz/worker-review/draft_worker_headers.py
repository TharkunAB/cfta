from pathlib import Path
import hashlib,json
r=Path('/tmp/mcfta-worker-execution-path-control-20261030/worker-review');parts=[];mapping=[]
for kind,oldFile,reservation in [('Native','SourcePruningEnumerationFiniteResources.lean','SourcePruningEnumerationFiniteReservation'),('Prepared','SourcePruningEnumerationPreparedFiniteResources.lean','SourcePruningEnumerationPreparedReservation')]:
 old=(r/'sources'/oldFile).read_text();oldNs='MicroCFTA.SourcePruningEnumeration'+('' if kind=='Native' else 'Prepared')+'Recursive';newNs='MicroCFTA.SourcePruningEnumerationExecutionWorkerPaths.'+kind;ctx=old[old.index('namespace '+oldNs):old.index('/-- Depth induction')].replace('namespace '+oldNs,'namespace '+newNs,1);ctx+='open '+oldNs.removeprefix('MicroCFTA.')+'\nopen SourcePruningEnumerationPathTransport (StatePaths ProjectionPaths)\n\n';statement=old.split('theorem run_finite_complete_resources\n',1)[1].split(' :=\n  finite_complete',1)[0];inputs,result=statement.split(' :\n',1);extras='''
    (P : EqualityTrie.Path → Prop) (original : StatePaths P before.core)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (projected : ProjectionPaths ('''+reservation+'''.final recursiveFuel seed ceiling).1 P)''';pathResult='''    ∃ bound, ∀ extra,
      SourcePruningEnumerationExecutionPaths.'''+kind+''' P holeKey fits admits graph templates checkEmpty edgesOf stop order
        (bound + extra) recursiveFuel metadata caller memos.query before''';head='theorem run_finite_paths\n'+inputs+extras+' :\n'+pathResult;resource='theorem run_finite_complete_resources_paths\n'+inputs+extras+' :\n'+result+''' ∧
      (∀ extra, SourcePruningEnumerationExecutionPaths.'''+kind+''' P holeKey fits admits graph templates checkEmpty edgesOf stop order
        (bound + extra) recursiveFuel metadata caller memos.query before)''';parts.append(dict(kind=kind,namespace=newNs,context=ctx,path=head,resource=resource,old_source=oldFile,old_inputs=inputs,old_result=result));mapping.append(dict(kind=kind,namespace=newNs,path_theorem='run_finite_paths',resource_theorem='run_finite_complete_resources_paths',old_inputs_prefix_exact=True,resource_result_prefix_exact=True,new_final_gates=['P','StatePaths','suffix closure','ProjectionPaths exact computed final'],no_final_complete_or_pathsIH_gate=True))
(r/'HEADER-DATA.json').write_text(json.dumps(parts,indent=2)+'\n');(r/'HEADER-MAPS.json').write_text(json.dumps(mapping,indent=2)+'\n');md=['# Final worker targets','', 'UNCOMPILED complete target headers. No final Complete or pathsIH supplier.','']
for x in parts:
 md+=['## '+x['kind'],'','```lean',x['context']+x['path'],'```','','```lean',x['context']+x['resource'],'```','']
p=r/'PUBLIC-TARGETS-UNCOMPILED.md';assert not p.exists();p.write_text('\n'.join(md)+'\n');p.chmod(0o444);print(json.dumps(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size,lines=len(p.read_bytes().splitlines()))))
