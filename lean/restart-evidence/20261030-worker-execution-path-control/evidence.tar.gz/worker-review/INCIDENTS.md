# Incidents and external checks

No owner generation, acquisition or display failure occurred in this task.
Root reported four introN errors in its probe of the exact immutable worker V1: base and successor for both workers.
selectionMembers and selectionLength do not depend on the reverted variables. They stay fixed in context.
Root V2 removes them from the repeated intro list and removes the extra nextMembers/nextLength arguments to ih.
The selected IH lambda retains those required inputs with underscore names. All four theorem statements are unchanged.
Root reported V2 strict probe PASS at its21:01 CET message. Root V3 removes only the status comment; installed build/strict was running then.
The owner V1 stays UNCOMPILED and retains the known failed proof. There is no owner V2 repair.

All unfiltered compiler evidence stays Root-owned outside this bundle, as Root explicitly requested:
../worker-paths-v1-probe/report.json
../worker-paths-v1-probe/raw.log
../worker-paths-v1-probe/inputs.json
../worker-v1-repair.json
../worker-paths-v2-probe/report.json

The earlier expansion task's Root-owned repair history is external as well. Ordinary V2 needed dsimp only before NativeStage's pair-fst reduction.
Paired selected V2 needed literal narrowed/pair reductions, Value.free in preparedClosed, and removal of an unavailable Bool.true_eq_true simp name.
Root reported the installed supporting and paired selected modules build/strict PASS. The frozen expansion-review bundle was not modified.
