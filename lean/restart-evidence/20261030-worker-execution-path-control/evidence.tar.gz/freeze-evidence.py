from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json
import subprocess

r = Path('/tmp/mcfta-worker-execution-path-control-20261030')
root = Path('/home/tritlo/Code/mcfta')
assert not (r / 'FROZEN.json').exists()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == 'c6ff953f3977faca20440086554341fa35721d3f'
assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=root, text=True)
publication = json.loads((r / 'checkpoint-publication.json').read_text())
assert publication['head'] == head and publication['readback_exact'] and publication['tracking_exact']
summary = json.loads((r / 'verification-summary.json').read_text())
assert summary['commands'] == 19 and summary['passed'] == 15 and summary['failed'] == 4
assert summary['public_checks'] == 1186 and summary['all_new_axioms_standard']
assert json.loads((r / 'owned-verification.json').read_text())['status'] == 'pass'
for path in r.iterdir():
    if path.is_dir() and not path.name.startswith('prior-') and (path / 'started-command.json').exists():
        assert (path / 'report.json').exists(), path
rows = []
for path in sorted(r.rglob('*')):
    if path.is_file():
        assert not path.is_symlink(), path
        data = path.read_bytes()
        rows.append({'path': str(path.relative_to(r)), 'bytes': len(data),
                     'sha256': hashlib.sha256(data).hexdigest()})
seal = {'created_at': datetime.now(ZoneInfo('Europe/Stockholm')).isoformat(),
        'write_halt': True, 'goal_turn': 'progress', 'full_goal_complete': False,
        'goal_controller_observed_status': 'blocked', 'work_continues_under_user_instruction': True,
        'source_head': '954b21de14883a6ab8604fc3a9dc24bd0e427904', 'docs_head': head,
        'main_head': 'bd5a406a6a3f84b7e3ae0906082783911509df83',
        'latest_board_sequence': 779, 'compiler_commands': 19, 'passed_commands': 15,
        'repaired_failed_commands': 4, 'input_snapshots': 61, 'new_laws': 9,
        'public_checks': 1186, 'public_definitions': 116,
        'payload_count_excluding_seal': len(rows), 'payloads': rows}
(r / 'FROZEN.json').write_text(json.dumps(seal, indent=2) + '\n')
for path in r.rglob('*'):
    if path.is_file():
        path.chmod(path.stat().st_mode & ~0o222)
assert all(not (path.stat().st_mode & 0o222) for path in r.rglob('*') if path.is_file())
print(json.dumps({'sealed': True, 'payloads_excluding_seal': len(rows),
                  'raw_bytes_excluding_seal': sum(row['bytes'] for row in rows),
                  'source_head': seal['source_head'], 'docs_head': head}))
