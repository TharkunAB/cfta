from pathlib import Path
import hashlib
import json
import sys

original = Path('/tmp/mcfta-worker-execution-path-control-20261030')
r = Path(sys.argv[1]) if len(sys.argv) > 1 else original
out = Path(sys.argv[2]) if len(sys.argv) > 2 else r
out.mkdir(exist_ok=True)
def sha(data):
    return hashlib.sha256(data).hexdigest()
def mapped(value):
    path = Path(value)
    return r / path.relative_to(original) if path.is_relative_to(original) else path

def manifest_rows(data):
    value = json.loads(data)
    return value if isinstance(value, list) else value['files']

summary = []
for name, expected in json.loads((r / 'frozen-owner-pins.json').read_text()).items():
    owner = r / name
    for leaf, key in [('MANIFEST.json', 'manifest'), ('REPORT.md', 'report'), ('pins.json', 'pins')]:
        assert sha((owner / leaf).read_bytes()) == expected[key], (name, leaf)
    manifest = json.loads((owner / 'MANIFEST.json').read_text())
    rows = manifest['files']
    actual = {str(path.relative_to(owner)) for path in owner.rglob('*') if path.is_file()}
    assert actual == {row['path'] for row in rows} | set(manifest['excludes']), name
    for row in rows:
        path = owner / row['path']
        data = path.read_bytes()
        assert not path.is_symlink() and not (path.stat().st_mode & 0o222), path
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], path
    assert all(not (path.stat().st_mode & 0o222) for path in owner.rglob('*') if path.is_file())
    pins = json.loads((owner / 'pins.json').read_text())
    assert pins['manifest_sha256'] == expected['manifest']
    assert pins['report_sha256'] == expected['report']
    assert sha((owner / 'FROZEN').read_bytes()) == pins.get('write_halt_marker_sha256', pins.get('write_halt_sha256'))
    source_count = 0
    if name != 'public-review':
        ledgers = ['acquisitions.json', 'bounded-acquisitions.json', 'reuse-ledger.json']
        ledgers += ['root-new-acquisitions.json'] if name == 'expansion-review' else ['root-current-headers.json']
        for ledger in ledgers:
            for row in json.loads((owner / ledger).read_text()):
                data = mapped(row['source_path']).read_bytes()
                copy = (owner / row['copy']).read_bytes()
                assert sha(data) == row['source_sha256']
                assert sha(copy) == row['copy_sha256']
                start, end = row['actual']
                assert copy == b''.join(data.splitlines(keepends=True)[start - 1:end])
                source_count += 1
                if 'frozen_bundle' in row:
                    bundle = Path(row['frozen_bundle'])
                    manifest_path = (r / 'prior-owner-manifests/sibling-head-MANIFEST.json'
                        if not bundle.is_relative_to(original) else mapped(str(bundle / 'MANIFEST.json')))
                    encoded = manifest_path.read_bytes()
                    assert sha(encoded) == row['frozen_manifest_sha256']
                    frozen = next(item for item in manifest_rows(encoded) if item['path'] == row['frozen_copy'])
                    assert len(copy) == frozen['bytes'] and sha(copy) == frozen['sha256']
    else:
        for row in json.loads((owner / 'acquisition.json').read_text())['sources']:
            data = mapped(row['path']).read_bytes()
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
            assert (owner / Path(row['path']).name).read_bytes() == data
            if 'strict_snapshot' in row:
                assert mapped(row['strict_snapshot']).read_bytes() == data
            source_count += 1
        old = (r / 'prior-public-readback/raw.log').read_bytes()
        current = (r / 'public-v2/raw.log').read_bytes()
        assert current.startswith(old)
        assert (owner / 'new-public-tail.log').read_bytes() == current[len(old):]
        for row in json.loads((owner / 'old-reuse-identities.json').read_text())['reuses']:
            data = mapped(row['path']).read_bytes()
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
            assert mapped(row['frozen']).read_bytes() == data
    summary.append({'directory': name, 'payloads': len(rows), 'regular_files': len(actual),
                    'manifest_sha256': expected['manifest'], 'current_source_copies': source_count,
                    'readonly': True, 'root_full_report_read': True})
result = {'owners': summary, 'payloads': sum(row['payloads'] for row in summary),
          'regular_files': sum(row['regular_files'] for row in summary), 'status': 'pass'}
(out / 'owned-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
