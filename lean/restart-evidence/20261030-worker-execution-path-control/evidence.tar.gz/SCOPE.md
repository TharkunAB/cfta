# Whole-worker execution-path composition

Retain the full library formalization objective in the preceding sibling
phase SCOPE.md. Preserve all original inputs, native range gates, sound
outputs, finite-prefix coverage under the configured order and stop rule,
both workers, public adapters, optimized interned core, Haskell correspondence,
and the constructor, equality, node-count, size-order and rank/unrank results.

This phase must discharge the concrete smaller-depth execution hypothesis.
First compose selected expansion, ordinary entry, sibling and opaque dispatch,
and parked restart into actual positive-depth Resume paths. Then prove eventual
whole Native and Prepared paths by induction on recursive depth. Combine each
path work bound with the unchanged old resource bound at a common sum.
Derive fixed original-carrier projections from the checked original alphabet
laws. Do not add a future trace, Complete, callback, or model supplier to the
closed original-input theorem. Sufficient original recursive depth and intended
coverage remain separate requirements even if this path induction succeeds.

The expansion owner owns only expansion-review. Its initial allowance was two
new OLD production bodies in full: FiniteExpansionResources and
PreparedFiniteExpansionResources. At 20:16 CET Root approved one additional
named OLD whole body: FiniteOrdinaryResources, 176 lines. The owner had acquired
102 of those lines before the request. The full body supplies the actual
entered Ready, Stored, Packet, and frame facts for the sibling composition.
The allowance is now three named OLD whole bodies. No fourth whole or
near-whole body is authorized. It may reuse its frozen head/sibling review
and explicitly authorized new Root path bridge outputs, with precise current
hash and check status. Other old reads must be bounded. Do not reconstruct a
further whole body from cuts. Ask Root for a full-read scope change if required.
The owner writes no production files, uses no compiler, evaluator, native job,
Git, network or board tools, and spawns no children. It records acquisitions,
reads its entire draft/report, freezes all files with pins, and stops writes.
Root alone verifies and publishes. All Root compiler checks stay serial at
4 GiB, zero swap and five minutes with strict Lean 4.34.1.

The refreshed Git base is 3cc625711e97c9125296efbe82525023ebac2183.
The sibling phase is published, archived, and independently reconstructed.
The phase bootstrap records current source identities and the complete prior
publication receipts. Sibling evidence remains read-only at
/tmp/mcfta-sibling-execution-path-control-20261030. Preserve that evidence.

Root has also authorized a new worker-review directory. Its owner may reuse
its frozen expansion-review and acquire at most three new OLD whole sources.
It must track cumulative bounded-read unions and request scope before another
whole or near-whole read. The same source-only and write-halt rules apply.
The final worker laws must discharge Complete and the smaller-depth path IH.
Root will derive original-carrier companions.

The goal controller reported blocked at 19:41 despite the resumed user
instruction and continuing checked progress. No technical blocker exists.
The available status tool cannot set active. The full objective is incomplete.
Work continues under the user instruction.
No Haskell defect or repair is established by this source-only task.
