from pathlib import Path
import hashlib
import json
import re

R = Path('/tmp/mcfta-worker-execution-path-control-20261030')
D = R / 'public-review'
repo = Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
sha = lambda b: hashlib.sha256(b).hexdigest()
prior = (R / 'prior-public-readback/raw.log').read_bytes()
old_outputs = []
for name in ['SourcePruningEnumerationForecastPathDomain.carrier', 'SourcePruningEnumerationForecastPathDomain.initial_paths', 'SourcePruningEnumerationForecastPathDomain.tail_closed', 'SourcePruningEnumerationClosedForecastPaths.native_original_paths', 'SourcePruningEnumerationClosedForecastPaths.prepared_original_paths', 'SourcePruningEnumerationPathTransport.StatePaths', 'SourcePruningEnumerationPathPreparedOpaque.ReceiptPaths', 'SourcePruningEnumerationPathSelectedRaw.RawPaths', 'SourcePruningEnumerationPathSelectedRaw.SelectedPrefixPaths', 'SourcePruningEnumerationPathObservationRaw.ObservationPaths']:
    m = re.search(rb'(?m)^(?:def )?MicroCFTA\.' + re.escape(name.encode()) + rb'(?:\n| )', prior)
    following = re.search(rb'(?m)^(?:(?:def|theorem|noncomputable def) )?MicroCFTA\.', prior[m.end():])
    start, end = m.start(), m.end() + following.start()
    b = prior[start:end]
    assert len(b) <= 8000
    target = 'old-public-' + name.rsplit('.', 1)[1] + '.log'
    (D / target).write_bytes(b)
    old_outputs.append(dict(path='prior-public-readback/raw.log', name=name, start=start, end_exclusive=end, bytes=len(b), sha256=sha(b), first_line=prior[:start].count(b'\n')+1, last_line=prior[:end-1].count(b'\n')+1))

def header(b, theorem):
    start = b.index(('theorem ' + theorem + '\n').encode())
    end = b.index(b' :\n    \xe2\x88\x83', start)
    return start, end, b[start:end]

cuts = []
pairs = [
    ('SourcePruningEnumerationFiniteOrdinaryResources.lean', 2409, 40, 82, 'ordinary_finite_complete_resources', 'SourcePruningEnumerationExecutionOrdinaryBridge.lean', 'ordinary_finite_complete_resources_paths'),
    ('SourcePruningEnumerationFiniteExpansionResources.lean', 2495, 43, 72, 'selected_finite_complete_resources', 'SourcePruningEnumerationExecutionExpansionBridge.lean', 'selected_finite_complete_resources_paths'),
    ('SourcePruningEnumerationPreparedFiniteExpansionResources.lean', 2707, 45, None, 'selected_finite_complete_resources', 'SourcePruningEnumerationExecutionExpansionBridge.lean', 'selected_finite_complete_resources_paths'),
    ('SourcePruningEnumerationFiniteResources.lean', 3323, 55, 79, 'run_finite_complete_resources', 'SourcePruningEnumerationExecutionWorkerPaths.lean', 'run_finite_complete_resources_paths'),
    ('SourcePruningEnumerationPreparedFiniteResources.lean', 3394, 56, None, 'run_finite_complete_resources', 'SourcePruningEnumerationExecutionWorkerPaths.lean', 'run_finite_complete_resources_paths'),
]
comparison = []
for old_file, start, first_line, prior_display_last_line, old_name, new_file, new_name in pairs:
    lines = []
    with (repo / old_file).open('rb') as f:
        f.seek(start)
        while True:
            line = f.readline()
            assert line
            lines.append(line)
            if line.endswith(b' :\n'):
                break
        inputs = b''.join(lines).removesuffix(b' :\n')
        # Preserve all bytes already displayed by the earlier bounded sed reads.
        prior_display = b''.join(lines)
        if prior_display_last_line:
            for _ in range(prior_display_last_line - first_line + 1 - len(lines)):
                prior_display += f.readline()
    end = start + len(inputs)
    assert len(inputs) <= 8000
    target = 'old-header-' + old_file
    (D / target).write_bytes(inputs)
    if prior_display_last_line:
        (D / ('old-earlier-display-' + old_file)).write_bytes(prior_display)
    cuts.append(dict(path=str(repo / old_file), start=start, end_exclusive=end, bytes=len(inputs), file_bytes=(repo / old_file).stat().st_size, sha256=sha(inputs), first_line=first_line, last_line=first_line+len(lines)-1, union_intervals=[[start,start+len(prior_display)]], union_bytes=len(prior_display), authorization='Root allowed bounded old-source cuts; includes explicit earlier bounded display'))
    new = (D / new_file).read_bytes()
    if old_file.startswith('SourcePruningEnumerationPrepared'):
        new = new[new.index(b'namespace MicroCFTA.',new.index(b'end MicroCFTA.')+1):]
    _, _, nh = header(new, new_name)
    new_inputs = nh[:nh.index(b'    (P :')].rstrip()
    old_inputs = inputs.replace(('theorem ' + old_name).encode(), ('theorem ' + new_name).encode(), 1)
    # Names and whitespace do not change a type. The old modules use inherited local notation.
    normalize = lambda x: re.sub(rb'\s+', b'', x).replace(b'Forecast', b'SourcePruningEnumerationFiniteReservation.final')
    equal = normalize(new_inputs) == normalize(old_inputs)
    comparison.append(dict(old=old_file, new=new_file, old_name=old_name, new_name=new_name, whitespace_normalized_equal=equal, old_input_bytes=len(old_inputs), new_input_bytes=len(new_inputs)))
(D / 'bounded-acquisitions.json').write_text(json.dumps(dict(old_source_cuts=cuts, old_public_output_cuts=old_outputs, whole_old_machine_reads_before_authorization=1, whole_old_machine_read_incident=dict(path=str(repo / 'SourcePruningEnumerationFiniteOrdinaryResources.lean'), bytes=12829, full_body_semantically_displayed=False, whole_body_copied=False, later_authorization='Root 21:07 CET named frozen reuse, does not apply retroactively'), initial_named_frozen_whole_reuses=2, added_named_frozen_header_reuses=3, other_old_bounded_header_sources=2), indent=2)+'\n')
(D / 'gate-comparison.json').write_text(json.dumps(comparison, indent=2)+'\n')
print((D / 'bounded-acquisitions.json').read_text())
print((D / 'gate-comparison.json').read_text())
