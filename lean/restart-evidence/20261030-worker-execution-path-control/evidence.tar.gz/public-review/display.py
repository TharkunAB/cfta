from pathlib import Path
import hashlib
import json
import sys

D = Path('/tmp/mcfta-worker-execution-path-control-20261030/public-review')
path = D / sys.argv[1]
start = int(sys.argv[2])
count = int(sys.argv[3])
assert 0 < count <= 8000
b = path.read_bytes()
end = min(start + count, len(b))
chunk = b[start:end]
assert chunk
record = dict(path=path.name, start=start, end_exclusive=end, bytes=len(chunk), sha256=hashlib.sha256(chunk).hexdigest(), first_line=1+b[:start].count(b'\n'), last_line=1+b[:end-1].count(b'\n'))
with (D / 'READ-DISPLAYS.jsonl').open('a') as f:
    f.write(json.dumps(record) + '\n')
print(json.dumps(record))
print(chunk.decode('utf-8'))
