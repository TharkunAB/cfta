from pathlib import Path
import hashlib
import json

R = Path('/tmp/mcfta-worker-execution-path-control-20261030')
D = R / 'public-review'
repo = Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
sha = lambda b: hashlib.sha256(b).hexdigest()
records = []
specs = [
    ('OrdinaryBridge', 'ordinary-bridge-v4-strict', '82b138b6135965a42892872a3302d3459eb4d9f3430f269f7b6e47741f051ec5'),
    ('ExpansionBridge', 'expansion-bridge-v5-strict', '66849f6807af5dc1e1dac609414c8a3923d996a3fef04b4d1ea56f28dcbde44c'),
    ('WorkerPaths', 'worker-paths-v3-strict', '3ee418c57de8a0ed2a840b9e0181e36ee99f1573a1947f9e9d9c5e35309f418a'),
    ('OriginalPaths', 'original-worker-paths-v2-strict', '954dfc48016d33c6afe7ac5423a47d5f6ebb252094214d7a36e9858ec05f073f'),
]
for suffix, run, expected in specs:
    name = 'SourcePruningEnumerationExecution' + suffix + '.lean'
    b = (repo / name).read_bytes()
    frozen = (R / run / 'input-sources' / name).read_bytes()
    assert b == frozen and sha(b) == expected
    (D / name).write_bytes(b)
    records.append(dict(path=str(repo / name), bytes=len(b), sha256=sha(b), strict_snapshot=str(R / run / 'input-sources' / name), identical=True, authorization='Root fresh new module whole read'))
manifest_bytes = (R / 'expansion-review/MANIFEST.json').read_bytes()
pins = json.loads((R / 'expansion-review/pins.json').read_text())
assert sha(manifest_bytes) == pins['manifest_sha256'] == 'a24c500d1d1b83c9a13be594a4a17eae192bea1c54a075c382e578625a59bf17'
manifest = json.loads(manifest_bytes)
for suffix in ['Paths', 'PathData']:
    name = 'SourcePruningEnumerationExecution' + suffix + '.lean'
    relative = 'reused/' + name
    entry = next(e for e in manifest['files'] if e['path'] == relative)
    frozen = (R / 'expansion-review' / relative).read_bytes()
    b = (repo / name).read_bytes()
    assert b == frozen and len(b) == entry['bytes'] and sha(b) == entry['sha256']
    (D / name).write_bytes(b)
    records.append(dict(path=str(repo / name), bytes=len(b), sha256=sha(b), frozen_snapshot=str(R / 'expansion-review' / relative), manifest_sha256=sha(manifest_bytes), identical=True, authorization='Root named frozen whole reuse, zero new old-source acquisition'))
prior = (R / 'prior-public-readback/raw.log').read_bytes()
full = (R / 'public-v2/raw.log').read_bytes()
assert len(prior) == 4763554 and len(full) == 4834345
assert sha(full) == '83ef4e72f0b1696180cd4d6677a57b42f0e337d2ec937ada0c9c7d552ba59f56'
assert full[:len(prior)] == prior
tail = full[len(prior):]
assert len(tail) == 70791
(D / 'new-public-tail.log').write_bytes(tail)
names = json.loads((R / 'new-public-declarations.json').read_text())
olddefs = json.loads((R / 'prior-public-definitions.json').read_text())
newdefs = json.loads((R / 'public-definitions.json').read_text())
assert olddefs == newdefs and len(newdefs) == 116
olddecl = json.loads((R / 'prior-public-declarations.json').read_text())
newdecl = json.loads((R / 'public-declarations.json').read_text())
assert newdecl[:len(olddecl)] == olddecl
assert newdecl[len(olddecl):] == names and len(names) == 9
for name in ['new-public-declarations.json', 'new-public-contract-locations.json', 'public-definitions.json']:
    (D / name).write_bytes((R / name).read_bytes())
public_source = (R / 'public-v2.lean').read_bytes()
prior_source = (R / 'prior-public-source.lean').read_bytes()
new_imports = b''.join(('import MicroCFTA.SourcePruningEnumerationExecution' + suffix + '\n').encode() for suffix, _, _ in specs)
assert public_source.startswith(new_imports)
old_and_new_commands = public_source[len(new_imports):]
assert old_and_new_commands.startswith(prior_source)
(D / 'new-public-commands.lean').write_bytes(new_imports + old_and_new_commands[len(prior_source):])
(D / 'acquisition.json').write_text(json.dumps(dict(sources=records, prefix=dict(prior_bytes=len(prior), prior_sha256=sha(prior), full_bytes=len(full), full_sha256=sha(full), literal_prefix_equal=True, tail_bytes=len(tail), tail_sha256=sha(tail), prior_lines=prior.count(b'\n'), full_lines=full.count(b'\n'), tail_lines=tail.count(b'\n')), definitions=dict(count=116, identical=True, sha256=sha((R / 'public-definitions.json').read_bytes())), declarations=dict(prior_count=len(olddecl), full_count=len(newdecl), new_count=9, exact_append=True), commands=dict(prior_bytes=len(prior_source), full_bytes=len(public_source), old_commands_literal_prefix_after_four_added_imports=True, initial_incorrect_source_prefix_assertion='Corrected: four new imports precede unchanged old command source; raw output remains exact literal prefix.'), parent_manifest_sha256=sha(manifest_bytes), source_policy=dict(fresh_new_modules=4, named_frozen_reuses=2, other_old_whole_sources=0, bounded_old_cuts=[])), indent=2) + '\n')
print((D / 'acquisition.json').read_text())
