from pathlib import Path
from datetime import datetime
import hashlib
import json
import stat

D = Path('/tmp/mcfta-worker-execution-path-control-20261030/public-review')
repo = Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
sha = lambda b: hashlib.sha256(b).hexdigest()
assert not (D / 'FROZEN').exists()
coverage = json.loads((D / 'READ-COVERAGE.json').read_text())
assert coverage['total_required_bytes'] == 195681 and coverage['required_chunks'] == 29
assert coverage['maximum_chunk_bytes'] <= 8000
for e in coverage['required_snapshots']:
    b = (D / e['path']).read_bytes()
    assert len(b) == e['bytes'] and sha(b) == e['sha256']
    if e['path'].endswith('.lean'):
        assert (repo / e['path']).read_bytes() == b
report_bytes = (D / 'REPORT.md').read_bytes()
records = [json.loads(s) for s in (D / 'READ-DISPLAYS.jsonl').read_text().splitlines()]
position = 0
for r in [r for r in records if r['path'] == 'REPORT.md']:
    assert r['start'] == position
    assert sha(report_bytes[r['start']:r['end_exclusive']]) == r['sha256']
    position = r['end_exclusive']
assert position == len(report_bytes)
for name in ['audit-build','audit-strict','public-v2']:
    report = json.loads((D / (name+'-report.json')).read_text())
    assert report['exit_code'] == 0
    if name != 'public-v2':
        raw = (D / (name+'-raw.log')).read_bytes()
        assert len(raw) == report['bytes'] and sha(raw) == report['sha256']
created = datetime.now().astimezone().isoformat()
(D / 'FROZEN').write_text('Frozen source-only public review.\nCreated: '+created+'\nAll source snapshots, all nine public contracts, and the complete report were read before sealing.\nThe write halt takes effect when this operation seals the manifest and pins.\nNo writes are permitted after sealing.\nThe pre-authorization 12,829-byte old-source machine read remains a scope incident.\n')
excludes = ['MANIFEST.json','pins.json']
files = []
for p in sorted(D.rglob('*')):
    assert not p.is_symlink()
    if p.is_file() and p.relative_to(D).as_posix() not in excludes:
        b = p.read_bytes()
        files.append(dict(path=p.relative_to(D).as_posix(),bytes=len(b),sha256=sha(b)))
manifest = dict(created_at=created,status='FROZEN source-only public contract review PASS; acquisition incident disclosed',excludes=excludes,payload_count=len(files),payload_bytes=sum(e['bytes'] for e in files),files=files)
manifest_bytes = (json.dumps(manifest,indent=2)+'\n').encode()
(D / 'MANIFEST.json').write_bytes(manifest_bytes)
pins = dict(created_at=created,status='FROZEN',manifest_sha256=sha(manifest_bytes),report_sha256=sha(report_bytes),write_halt_sha256=sha((D / 'FROZEN').read_bytes()),tail_sha256=sha((D / 'new-public-tail.log').read_bytes()),payload_count=len(files),payload_bytes=manifest['payload_bytes'],regular_file_count=len(files)+2,required_source_and_tail_bytes=195681,required_source_and_tail_chunks=29,public_contracts=9,standard_axiom_reports=9,definition_prints=116,source_scope_incidents=1,pre_authorization_whole_machine_read_bytes=12829,current_source_identities=json.loads((D / 'acquisition.json').read_text())['sources'])
(D / 'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
actual = sorted(p.relative_to(D).as_posix() for p in D.rglob('*') if p.is_file())
assert actual == sorted([e['path'] for e in files]+excludes)
for e in files:
    b = (D / e['path']).read_bytes()
    assert len(b) == e['bytes'] and sha(b) == e['sha256']
for p in D.rglob('*'):
    if p.is_file():
        p.chmod(0o444)
for p in D.rglob('*'):
    if p.is_file():
        assert not (stat.S_IMODE(p.stat().st_mode) & 0o222)
D.chmod(0o555)
print(json.dumps(pins,indent=2))
