from pathlib import Path
import hashlib
import json
import re

R = Path('/tmp/mcfta-worker-execution-path-control-20261030')
D = R / 'public-review'
repo = Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
sha = lambda b: hashlib.sha256(b).hexdigest()
prior = (R / 'prior-public-readback/raw.log').read_bytes()
old_outputs = []
for name in ['SourcePruningEnumerationForecastPathDomain.carrier', 'SourcePruningEnumerationForecastPathDomain.initial_paths', 'SourcePruningEnumerationForecastPathDomain.tail_closed', 'SourcePruningEnumerationClosedForecastPaths.native_original_paths', 'SourcePruningEnumerationClosedForecastPaths.prepared_original_paths']:
    m = re.search(rb'(?m)^(?:def )?MicroCFTA\.' + re.escape(name.encode()) + rb'(?:\n| )', prior)
    following = re.search(rb'(?m)^(?:(?:def|theorem|noncomputable def) )?MicroCFTA\.', prior[m.end():])
    start, end = m.start(), m.end() + following.start()
    b = prior[start:end]
    assert len(b) <= 8000
    target = 'old-public-' + name.rsplit('.', 1)[1] + '.log'
    (D / target).write_bytes(b)
    old_outputs.append(dict(path='prior-public-readback/raw.log', name=name, start=start, end_exclusive=end, bytes=len(b), sha256=sha(b), first_line=prior[:start].count(b'\n')+1, last_line=prior[:end-1].count(b'\n')+1))

def header(b, theorem):
    start = b.index(('theorem ' + theorem + '\n').encode())
    end = b.index(b':= by', start)
    return start, end, b[start:end]

cuts = []
pairs = [
    ('SourcePruningEnumerationFiniteOrdinaryResources.lean', 'ordinary_finite_complete_resources', 'SourcePruningEnumerationExecutionOrdinaryBridge.lean', 'ordinary_finite_complete_resources_paths'),
    ('SourcePruningEnumerationFiniteExpansionResources.lean', 'selected_finite_complete_resources', 'SourcePruningEnumerationExecutionExpansionBridge.lean', 'selected_finite_complete_resources_paths'),
    ('SourcePruningEnumerationPreparedFiniteExpansionResources.lean', 'selected_finite_complete_resources', 'SourcePruningEnumerationExecutionExpansionBridge.lean', 'selected_finite_complete_resources_paths'),
    ('SourcePruningEnumerationFiniteResources.lean', 'run_finite_complete_resources', 'SourcePruningEnumerationExecutionWorkerPaths.lean', 'run_finite_complete_resources_paths'),
    ('SourcePruningEnumerationPreparedFiniteResources.lean', 'run_finite_complete_resources', 'SourcePruningEnumerationExecutionWorkerPaths.lean', 'run_finite_complete_resources_paths'),
]
comparison = []
for old_file, old_name, new_file, new_name in pairs:
    b = (repo / old_file).read_bytes()
    start, end, h = header(b, old_name)
    # Only retain the input header, through the theorem's result colon.
    result_start = h.index(b' :\n    \xe2\x88\x83')
    inputs = h[:result_start]
    end = start + result_start
    assert len(inputs) <= 8000
    target = 'old-header-' + old_file
    (D / target).write_bytes(inputs)
    cuts.append(dict(path=str(repo / old_file), start=start, end_exclusive=end, bytes=len(inputs), file_bytes=len(b), sha256=sha(inputs), first_line=b[:start].count(b'\n')+1, last_line=b[:end-1].count(b'\n')+1, union_intervals=[[start,end]], authorization='Root allowed bounded old-source cuts; theorem input header only'))
    new = (D / new_file).read_bytes()
    if old_file.startswith('SourcePruningEnumerationPrepared'):
        new = new[new.index(b'namespace MicroCFTA.',new.index(b'end MicroCFTA.')+1):]
    _, _, nh = header(new, new_name)
    new_inputs = nh[:nh.index(b'    (P :')].rstrip()
    old_inputs = inputs.replace(('theorem ' + old_name).encode(), ('theorem ' + new_name).encode(), 1)
    # Names and whitespace do not change a type. The old modules use inherited local notation.
    normalize = lambda x: re.sub(rb'\s+', b'', x).replace(b'Forecast', b'SourcePruningEnumerationFiniteReservation.final')
    equal = normalize(new_inputs) == normalize(old_inputs)
    comparison.append(dict(old=old_file, new=new_file, old_name=old_name, new_name=new_name, whitespace_normalized_equal=equal, old_input_bytes=len(old_inputs), new_input_bytes=len(new_inputs)))
(D / 'bounded-acquisitions.json').write_text(json.dumps(dict(old_source_cuts=cuts, old_public_output_cuts=old_outputs, whole_old_sources_added=0), indent=2)+'\n')
(D / 'gate-comparison.json').write_text(json.dumps(comparison, indent=2)+'\n')
print((D / 'bounded-acquisitions.json').read_text())
print((D / 'gate-comparison.json').read_text())
