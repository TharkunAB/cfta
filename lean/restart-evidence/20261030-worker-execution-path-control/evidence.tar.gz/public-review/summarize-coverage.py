from pathlib import Path
import hashlib
import json

D = Path('/tmp/mcfta-worker-execution-path-control-20261030/public-review')
records = [json.loads(s) for s in (D / 'READ-DISPLAYS.jsonl').read_text().splitlines()]
required = ['new-public-tail.log'] + ['SourcePruningEnumerationExecution'+s+'.lean' for s in ['OrdinaryBridge','ExpansionBridge','WorkerPaths','OriginalPaths','Paths','PathData']]
coverage = []
for name in required:
    b = (D / name).read_bytes()
    selected = [r for r in records if r['path'] == name]
    assert selected
    position = 0
    for r in selected:
        assert r['start'] == position and r['bytes'] <= 8000
        chunk = b[r['start']:r['end_exclusive']]
        assert hashlib.sha256(chunk).hexdigest() == r['sha256']
        position = r['end_exclusive']
    assert position == len(b)
    coverage.append(dict(path=name, bytes=len(b), sha256=hashlib.sha256(b).hexdigest(), contiguous_union=[[0,len(b)]], chunks=len(selected), lines=b.count(b'\n'), fully_displayed_without_truncation=True, chunk_records=selected))
old = json.loads((D / 'bounded-acquisitions.json').read_text())
report = dict(required_snapshots=coverage, total_required_bytes=sum(e['bytes'] for e in coverage), required_chunks=sum(e['chunks'] for e in coverage), maximum_chunk_bytes=max(r['bytes'] for r in records), old_semantic_union_bytes=sum(e['union_bytes'] for e in old['old_source_cuts']), old_semantic_unions=old['old_source_cuts'], earlier_whole_machine_read_scope_incident=old['whole_old_machine_read_incident'], old_public_output_cuts=old['old_public_output_cuts'], no_other_old_whole_semantic_display=True)
(D / 'READ-COVERAGE.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['required_snapshots','old_semantic_unions','old_public_output_cuts']},indent=2))
