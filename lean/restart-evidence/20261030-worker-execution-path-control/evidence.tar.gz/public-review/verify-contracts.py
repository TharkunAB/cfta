from pathlib import Path
import hashlib
import json
import re

R = Path('/tmp/mcfta-worker-execution-path-control-20261030')
D = R / 'public-review'
repo = Path('/home/tritlo/Code/mcfta/lean/MicroCFTA')
sha = lambda b: hashlib.sha256(b).hexdigest()
parent_manifest_bytes = (R / 'expansion-review/MANIFEST.json').read_bytes()
assert sha(parent_manifest_bytes) == 'a24c500d1d1b83c9a13be594a4a17eae192bea1c54a075c382e578625a59bf17'
manifest = json.loads(parent_manifest_bytes)
reuses = []
for stem in ['FiniteOrdinaryResources', 'FiniteExpansionResources', 'PreparedFiniteExpansionResources']:
    name = 'SourcePruningEnumeration' + stem + '.lean'
    entry = next(e for e in manifest['files'] if e['path'] == 'sources/' + name)
    current = repo / name
    frozen = R / 'expansion-review/sources' / name
    # Compare bytes as a stream. Do not acquire another whole body.
    h = hashlib.sha256()
    with current.open('rb') as a, frozen.open('rb') as b:
        while True:
            ca, cb = a.read(4096), b.read(4096)
            assert ca == cb
            if not ca:
                break
            h.update(ca)
    assert h.hexdigest() == entry['sha256'] and current.stat().st_size == entry['bytes']
    reuses.append(dict(path=str(current), frozen=str(frozen), bytes=entry['bytes'], sha256=entry['sha256'], exact_identity=True, authorization='Root 21:07 CET post-incident named frozen reuse; display only header spans'))
(D / 'old-reuse-identities.json').write_text(json.dumps(dict(parent_manifest_sha256=sha(parent_manifest_bytes), reuses=reuses), indent=2)+'\n')

tail = (D / 'new-public-tail.log').read_bytes()
names = json.loads((D / 'new-public-declarations.json').read_text())
starts = [tail.index(('MicroCFTA.' + n + '\n').encode()) if ('MicroCFTA.' + n + '\n').encode() in tail else tail.index(('MicroCFTA.' + n + ' ').encode()) for n in names]
assert starts == sorted(starts)
index = []
for i, name in enumerate(names):
    start, end = starts[i], starts[i+1] if i+1 < len(names) else len(tail)
    block = tail[start:end]
    marker = ("'MicroCFTA." + name + "' depends on axioms: ").encode()
    ax = block[block.index(marker)+len(marker):].strip()
    assert ax == b'[propext,\n Classical.choice,\n Quot.sound]'
    printed_statement = block[:block.index(marker)].rstrip()
    header_end = printed_statement.index(b' :\n  \xe2\x88\x83')
    inputs = printed_statement[:header_end]
    assert (b'(pathsIH :' in inputs) == (i < 3)
    assert (b'(recursive :' in inputs) == (i < 3)
    assert b'(packet :' in inputs and b'(bounded :' in inputs and b'(known :' in inputs
    assert b'(selectionMembers :' in inputs and b'(selectionLength :' in inputs
    assert b'(initialMass :' in inputs and b'(reserved :' in inputs
    if i >= 3:
        for forbidden in [b'(pathsIH :', b'(recursive :', b'(stages :', b'(future :', b'(stagePaths :', b'(target :']:
            assert forbidden not in inputs
    if 3 <= i < 7:
        assert all(x in inputs for x in [b'(P :', b'(original :', b'(tails :', b'(projected :'])
    if i >= 7:
        assert all(x not in inputs for x in [b'(P :', b'(original :', b'(tails :', b'(projected :'])
        assert all(x in inputs for x in [b'(literals :', b'(normalized :', b'(included :'])
    index.append(dict(name=name, start=start, end_exclusive=end, bytes=end-start, sha256=sha(block), tail_first_line=tail[:start].count(b'\n')+1, tail_last_line=tail[:end-1].count(b'\n')+1, full_first_line=65301+tail[:start].count(b'\n'), full_last_line=65301+tail[:end-1].count(b'\n'), axiom_set=['propext','Classical.choice','Quot.sound'], internal_complete_and_path_IH=i<3))
assert tail.count(b'depends on axioms:') == 9
assert b'sorryAx' not in tail and b'...' not in tail and '\u2026'.encode() not in tail
assert len(re.findall(rb'(?m)^#check ',(D / 'new-public-commands.lean').read_bytes())) == 9
assert len(re.findall(rb'(?m)^#print axioms ',(D / 'new-public-commands.lean').read_bytes())) == 9
new_modules = [D / ('SourcePruningEnumerationExecution'+x+'.lean') for x in ['OrdinaryBridge','ExpansionBridge','WorkerPaths','OriginalPaths']]
assert sum(len(re.findall(rb'(?m)^theorem ',p.read_bytes())) for p in new_modules) == 9
for p in new_modules:
    assert not re.search(rb'(?m)^(?:(?:noncomputable|private|protected) )*(?:def|abbrev|axiom|opaque|structure|inductive) ',p.read_bytes())
(D / 'public-contract-index.json').write_text(json.dumps(index, indent=2)+'\n')
print((D / 'old-reuse-identities.json').read_text())
print((D / 'public-contract-index.json').read_text())
