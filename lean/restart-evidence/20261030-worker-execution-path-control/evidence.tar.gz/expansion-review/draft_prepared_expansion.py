from pathlib import Path
import hashlib,json,textwrap
r=Path('/tmp/mcfta-worker-execution-path-control-20261030/expansion-review');old=(r/'sources/SourcePruningEnumerationPreparedFiniteExpansionResources.lean').read_text();ns='MicroCFTA.SourcePruningEnumerationPreparedRecursive';newns='MicroCFTA.SourcePruningEnumerationExecutionExpansionBridge.Prepared';s=old[old.index('namespace '+ns):].replace('namespace '+ns,'namespace '+newns,1).replace('end '+ns,'end '+newns)
def rep(a,b):
 global s
 assert a in s,a[:140];s=s.replace(a,b,1)
rep('theorem selected_finite_complete_resources\n','theorem selected_finite_complete_resources_paths\n')
rep('variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]\n','''variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
open SourcePruningEnumerationPreparedRecursive
open SourcePruningEnumerationPathTransport (StatePaths ProjectionPaths)
open SourcePruningEnumerationPathSelectedRaw (RawPaths SelectedPrefixPaths)
open SourcePruningEnumerationExecutionPathData (FoldPaths PreparedFailurePaths)
open SourcePruningEnumerationExecutionPaths (ResumePrepared PreparedStage SiblingPaths)
''')
receipt=(r/'root-new/SourcePruningEnumerationExecutionReceiptBridge.lean').read_text().split('namespace MicroCFTA.SourcePruningEnumerationExecutionReceiptBridge.Prepared',1)[1];ih=receipt.split('    (pathsIH :',1)[1].split(') :\n    ∃ (fuel',1)[0].replace('suspendedBound nextCache.core','mass nextCache.core')
rep('    (chosen : SourcePruningEnumerationRestart.decision stop order metadata before = some (.expand uv)) :','''    (chosen : SourcePruningEnumerationRestart.decision stop order metadata before = some (.expand uv))
    (P : EqualityTrie.Path → Prop) (original : StatePaths P before.core)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (projected : ProjectionPaths (Forecast (recursiveFuel + 1) seed ceiling).1 P)
    (pathsIH :'''+ih+') :')
rep('        (Forecast (recursiveFuel + 1) seed ceiling) outcome := by','''        (Forecast (recursiveFuel + 1) seed ceiling) outcome ∧
      (∀ extra, ResumePrepared P holeKey fits admits graph templates checkEmpty edgesOf stop order
        (bound + extra) (recursiveFuel + 1) metadata caller memos.query before (some (.expand uv))) := by''')
rep('  have selection : EnumerationPureSelection.next','''  have stageProjected : ProjectionPaths
      (SourcePruningEnumerationPreparedReservation.stage recursiveFuel start inherited inherited
        (SourcePruningEnumerationPreparedReservation.rows seed)).1 P := by
    simpa only [SourcePruningEnumerationPreparedReservation.final_succ] using projected
  have prefixPaths (work : Nat) := SourcePruningEnumerationPathSelectedPrefix.runPrefix_paths
    holeKey fits admits graph templates stop order metadata work work work work work work uv caller before memos.query original
  have selection : EnumerationPureSelection.next''')
rep('obtain ⟨bound, outcome, running, resources⟩ := parked_finite_complete_resources','obtain ⟨bound, outcome, running, resources, allPaths⟩ :=\n      SourcePruningEnumerationExecutionParkedBridge.Prepared.parked_finite_complete_resources_paths')
rep('selectionMembers selectionLength initialMass reserved phase\n','selectionMembers selectionLength initialMass reserved phase P original projected pathsIH\n')
rep('      simpa only [SourcePruningEnumerationPreparedReservation.final_succ] using resources⟩','      simpa only [SourcePruningEnumerationPreparedReservation.final_succ] using resources, allPaths⟩')
rep('''        (SourcePruningEnumerationExpansionAdmission.narrowSeed seed).2).trans stageGrowth.1) stageGrowth.2⟩
    intro extra
    rw [resume, (phase extra).1]
''','''        (SourcePruningEnumerationExpansionAdmission.narrowSeed seed).2).trans stageGrowth.1) stageGrowth.2, ?_⟩
    · intro extra
      rw [resume, (phase extra).1]
    · intro extra
      refine ⟨original, ?_, prefixPaths (prefixFuel + extra), ?_⟩
      · rw [resume, (phase extra).1]
        intro output member
        exact False.elim (List.not_mem_nil member)
      · rw [(phase extra).1]
        trivial
''')
rep('    rw [prefixAt] at valid\n    have admission :=','''    rw [prefixAt] at valid
    have retainedPaths := prefixPaths (prefixFuel + 0)
    rw [prefixAt] at retainedPaths
    have afterPaths : StatePaths P after.core := retainedPaths.2.2.1 after rfl
    have admission :=''')
rep('    by_cases ordinaryShape :','''    have enteredPathsP : StatePaths P entered.core := by
      apply SourcePruningEnumerationPathPreparedEntry.enter_paths reached.checked.native.machine.heap
        preparationFuel uv after.core entered.core (uv, handle, scs, preparedDecoded) afterPaths
      change Except.ok ((uv, handle, scs, preparedDecoded), entered.core) ∈
        ExceptT.run (SourcePruningEnumerationEntry.enter reached.checked.native.machine.heap preparationFuel uv after.core)
      have actual := congrArg Prod.fst (preparationRun 0)
      dsimp only [SourcePruningEnumerationSelectedPreparation.run] at actual
      simp only [Nat.add_zero] at actual
      rw [actual]
      exact List.mem_singleton_self _
    have framed : EnumerationExpandableIndex.frame entered.core after = entered := by
      cases entered with
      | mk core expandable waiting =>
          simp only [EnumerationExpandableIndex.frame] at *
          congr 1
          · exact enteredFlags.symm
          · exact enteredWaiting.symm
    have rawPaths : RawPaths P
        [.ok ((uv, handle, scs, preparedDecoded), entered.core)] := by
      intro result core member
      cases Except.ok.inj (List.mem_singleton.mp member)
      exact enteredPathsP
    have enteredMassP : mass entered.core ≤ inherited := by
      rw [SourcePruningEnumerationPrefixAdmission.suspendedBound_values after.core entered.core enteredValues]
      exact currentMass
    by_cases ordinaryShape :''')
a=s.index('      refine ⟨prefixFuel + (preparationFuel + scanFuel),');b=s.index('    · have dispatchGate',a);oldProof=s[a:b];runProof=oldProof[oldProof.index('      apply resume_depth_stable'):];runProof='\n'.join('  '+line for line in runProof.splitlines())+'\n'
new='''      have scanProjected : ProjectionPaths
          (SourcePruningEnumerationPreparedReservation.stage recursiveFuel start inherited inherited
            (edgesOf (.node entry rows depth free)).length).1 P := by
        intro guard member
        exact stageProjected guard (growth.2 member)
      obtain ⟨pathFuel, _pathProcessed, _pathOutputs, _pathCaller, _pathInventory, _pathMemos,
        pathResult, scanAt, _pathPost, _pathPacket, _pathFits, _pathKnown, _pathLength,
        _pathReceipts, _pathOutputsAt, _pathShape, foldPaths, invocations⟩ :=
        SourcePruningEnumerationExecutionSiblingBridge.Prepared.alternatives_finite_complete_resources_paths
          holeKey fits admits graph templates checkEmpty edgesOf stop order metadata recursiveFuel start formulas solver recursive inventory
          (SourcePruningEnumerationSelectedValueCaller.advance reached preparedHeap) middleMemos entered
          uv handle scs entry rows (edgesOf (.node entry rows depth free)) depth free
          enteredPacket enteredReady enteredStored
          (by simpa only [preparedHeapEq, same] using preparedAvailable)
          (by simpa only [same] using preparedClosed) (selectionMembers entry rows depth free)
          (EnumerationReferences.incoming_read uv after.core entered.core stable incoming)
          preparedFits preparedKnown selectionMembers selectionLength inherited inherited enteredMassP inheritedBound
          (reserved.scan.prefix countBound) P enteredPathsP tails scanProjected pathsIH
      have dispatchPathsAt (extra : Nat) : SourcePruningEnumerationSelectedContinuations.run
          (continueWith (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
              (preparationFuel + pathFuel + extra) recursiveFuel)
            graph templates stop order (preparationFuel + pathFuel + extra) metadata uv)
          checkEmpty (preparationFuel + pathFuel + extra) (preparationFuel + pathFuel + extra)
          (preparationFuel + pathFuel + extra) (preparationFuel + pathFuel + extra)
          (preparationFuel + pathFuel + extra) (preparationFuel + pathFuel + extra)
          (preparationFuel + pathFuel + extra) uv edgesOf reached after middleMemos.query =
            (([.ok ((uv, handle, scs, preparedDecoded), entered.core)],
              some (.done (.node entry rows depth free) preparedHeap)), some pathResult) := by
        have preparationAt : SourcePruningEnumerationSelectedPreparation.run
            (preparationFuel + pathFuel + extra) (preparationFuel + pathFuel + extra) uv reached after =
              ([.ok ((uv, handle, scs, preparedDecoded), entered.core)],
                some (.done (.node entry rows depth free) preparedHeap)) := by
          simpa only [Nat.add_assoc, same] using preparationRun (pathFuel + extra)
        have actual := SourcePruningEnumerationSelectedContinuations.ordinary
          (continueWith (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
              (preparationFuel + pathFuel + extra) recursiveFuel)
            graph templates stop order (preparationFuel + pathFuel + extra) metadata uv)
          checkEmpty (preparationFuel + pathFuel + extra) (preparationFuel + pathFuel + extra)
          (preparationFuel + pathFuel + extra) (preparationFuel + pathFuel + extra)
          (preparationFuel + pathFuel + extra) (preparationFuel + pathFuel + extra)
          (preparationFuel + pathFuel + extra) uv uv handle scs preparedDecoded entry rows depth free
          preparedHeap entered.core edgesOf reached after middleMemos.query preparationAt nonterminal
        have scan := scanAt (preparationFuel + extra)
        have common : pathFuel + (preparationFuel + extra) = preparationFuel + pathFuel + extra := by omega
        rw [common] at scan
        rw [framed, scan] at actual
        exact actual
      have running : ∀ extra, resume holeKey fits admits graph templates checkEmpty edgesOf stop order
          (prefixFuel + (preparationFuel + scanFuel) + extra) (recursiveFuel + 1)
          metadata caller memos.query before (some (.expand uv)) = finish uv folded := by
'''+runProof+'''      refine ⟨prefixFuel + (preparationFuel + scanFuel) + pathFuel, finish uv folded, ?_,
        (resources.mono growth.1 growth.2).post middlePost, ?_⟩
      · intro extra
        simpa only [Nat.add_assoc] using running (pathFuel + extra)
      · intro extra
        obtain ⟨currentAction, currentPrefix, _valid⟩ := phase (preparationFuel + scanFuel + pathFuel + extra)
        have samePrefix : prefixFuel + (preparationFuel + scanFuel + pathFuel + extra) =
            prefixFuel + (preparationFuel + scanFuel) + pathFuel + extra := by omega
        rw [samePrefix] at currentPrefix
        have dispatch := dispatchPathsAt (prefixFuel + scanFuel + extra)
        have sameDispatch : preparationFuel + pathFuel + (prefixFuel + scanFuel + extra) =
            prefixFuel + (preparationFuel + scanFuel) + pathFuel + extra := by omega
        rw [sameDispatch, middleQuery] at dispatch
        have scan := scanAt (prefixFuel + preparationFuel + scanFuel + extra)
        have currentInvocations := invocations (prefixFuel + preparationFuel + scanFuel + extra)
        have sameScan : pathFuel + (prefixFuel + preparationFuel + scanFuel + extra) =
            prefixFuel + (preparationFuel + scanFuel) + pathFuel + extra := by omega
        rw [sameScan, middleQuery] at scan currentInvocations
        refine ⟨original, ?_, prefixPaths (prefixFuel + (preparationFuel + scanFuel) + pathFuel + extra), ?_⟩
        · rw [resume, currentPrefix, dispatch]
          exact SourcePruningEnumerationExecutionPathData.prepared_finish_paths uv pathResult foldPaths
        · rw [currentPrefix]
          unfold PreparedStage
          rw [dispatch]
          refine ⟨rawPaths, ?_, ?_⟩
          · intro result found
            cases Option.some.inj found
            exact foldPaths
          · rw [nonterminal, framed]
            unfold SiblingPaths
            refine ⟨?_, currentInvocations⟩
            rw [scan]
            exact foldPaths
'''
s=s[:a]+new+s[b:]
rep('''      obtain ⟨opaqueFuel, _receipt,''','''      have opaqueProjected : ProjectionPaths
          (SourcePruningEnumerationPreparedReservation.step recursiveFuel start inherited inherited).1 P := by
        intro guard member
        exact projected guard
          ((SourcePruningEnumerationPreparedReservation.first_le_final recursiveFuel seed ceiling).2 member)
      obtain ⟨opaqueFuel, _receipt,''')
rep('_callbackRun, _receiptRun, resources, opaqueFoldRun⟩ :=\n        SourcePruningEnumerationPreparedNativeHookResources.opaque_finite_complete_resources','_callbackRun, _receiptRun, resources, opaqueFoldRun, opaquePaths, finishedPaths⟩ :=\n        SourcePruningEnumerationExecutionOpaqueBridge.Prepared.opaque_finite_complete_resources_paths')
rep('          inherited inherited enteredMass inheritedBound reserved.first\n','          inherited inherited enteredMass inheritedBound reserved.first P enteredPathsP opaqueProjected pathsIH\n')
rep('      have original := (padded.post preparationPost).post middlePost','      have originalResources := (padded.post preparationPost).post middlePost')
# Factor the exact old opaque dispatch proof into a local equation; no new supplier.
a=s.index('      refine ⟨prefixFuel + (preparationFuel + opaqueFuel),');b=s.index('\nend '+newns,a);opaqueOld=s[a:b];proofStart=opaqueOld.index('        have preparationAt :');proofEnd=opaqueOld.rindex('        simpa only [middleQuery] using dispatchAt');dispatchBody=opaqueOld[proofStart:proofEnd];dispatchBody='\n'.join(line[2:] for line in dispatchBody.splitlines())+'\n      exact dispatchAt\n'
# The inner exact frame proof is retained; shadowing the already derived frame is harmless but unnecessary.
frameA=dispatchBody.index('      have framed :');frameB=dispatchBody.index('      have dispatchAt :',frameA);dispatchBody=dispatchBody[:frameA]+dispatchBody[frameB:]
new='''      have dispatchEquation (extra : Nat) : SourcePruningEnumerationSelectedContinuations.run
          (continueWith (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
              (preparationFuel + opaqueFuel + extra) recursiveFuel)
            graph templates stop order (preparationFuel + opaqueFuel + extra) metadata uv)
          checkEmpty (preparationFuel + opaqueFuel + extra) (preparationFuel + opaqueFuel + extra)
          (preparationFuel + opaqueFuel + extra) (preparationFuel + opaqueFuel + extra)
          (preparationFuel + opaqueFuel + extra) (preparationFuel + opaqueFuel + extra)
          (preparationFuel + opaqueFuel + extra) uv edgesOf reached after middleMemos.query =
            (([.ok ((uv, handle, scs, preparedDecoded), entered.core)], some (.done preparedValue preparedHeap)), some folded) := by
'''+textwrap.indent(dispatchBody,'  ')+'''      have running : ∀ extra, resume holeKey fits admits graph templates checkEmpty edgesOf stop order
          (prefixFuel + (preparationFuel + opaqueFuel) + extra) (recursiveFuel + 1)
          metadata caller memos.query before (some (.expand uv)) = finish uv folded := by
        apply resume_depth_stable holeKey fits admits graph templates checkEmpty edgesOf stop order
          prefixFuel (preparationFuel + opaqueFuel) recursiveFuel uv metadata metadata caller reached
          memos.query memos.query before after
          ([.ok ((uv, handle, scs, preparedDecoded), entered.core)], some (.done preparedValue preparedHeap)) folded
        · intro extra
          obtain ⟨currentAction, currentPrefix, _valid⟩ := phase extra
          exact ⟨checked, .done (phaseValue, some currentAction) heap, currentPrefix⟩
        · intro extra
          simpa only [middleQuery] using dispatchEquation extra
      refine ⟨prefixFuel + (preparationFuel + opaqueFuel), finish uv folded, running, ?_, ?_⟩
      · simpa only [SourcePruningEnumerationPreparedReservation.final_succ] using originalResources
      · intro extra
        obtain ⟨currentAction, currentPrefix, _valid⟩ := phase (preparationFuel + opaqueFuel + extra)
        have samePrefix : prefixFuel + (preparationFuel + opaqueFuel + extra) =
            prefixFuel + (preparationFuel + opaqueFuel) + extra := by omega
        rw [samePrefix] at currentPrefix
        have dispatch := dispatchEquation (prefixFuel + extra)
        have sameDispatch : preparationFuel + opaqueFuel + (prefixFuel + extra) =
            prefixFuel + (preparationFuel + opaqueFuel) + extra := by omega
        rw [sameDispatch, middleQuery] at dispatch
        have currentOpaque := opaquePaths (prefixFuel + preparationFuel + extra)
        have currentFold := opaqueFoldRun (prefixFuel + preparationFuel + extra)
        have sameOpaque : opaqueFuel + (prefixFuel + preparationFuel + extra) =
            prefixFuel + (preparationFuel + opaqueFuel) + extra := by omega
        rw [sameOpaque, middleQuery] at currentOpaque currentFold
        have foldPaths := currentOpaque.2.1
        rw [currentFold] at foldPaths
        refine ⟨original, ?_, prefixPaths (prefixFuel + (preparationFuel + opaqueFuel) + extra), ?_⟩
        · rw [resume, currentPrefix, dispatch]
          exact finishedPaths
        · rw [currentPrefix]
          unfold PreparedStage
          rw [dispatch]
          refine ⟨rawPaths, ?_, ?_⟩
          · intro result found
            cases Option.some.inj found
            exact foldPaths
          · rw [framed]
            cases preparedValue with
            | node entry rows depth free =>
                have terminal : scs.any (fun sc => EqualityTrie.isTerminal sc.trie) = true := by
                  cases terminal : scs.any (fun sc => EqualityTrie.isTerminal sc.trie) with
                  | false => exact False.elim (ordinaryShape ⟨entry, rows, depth, free, rfl, terminal⟩)
                  | true => rfl
                rw [terminal]
                exact currentOpaque
            | empty | reference _ | union _ _ _ _ | mu _ _ _ _ =>
                cases terminal : scs.any (fun sc => EqualityTrie.isTerminal sc.trie) <;> exact currentOpaque
'''
s=s[:a]+new+s[b:]
text='''import MicroCFTA.SourcePruningEnumerationPreparedFiniteExpansionResources
import MicroCFTA.SourcePruningEnumerationExecutionSiblingBridge
import MicroCFTA.SourcePruningEnumerationExecutionOpaqueBridge
import MicroCFTA.SourcePruningEnumerationExecutionParkedBridge
import MicroCFTA.SourcePruningEnumerationPathSelectedPrefix
import MicroCFTA.SourcePruningEnumerationPathPreparedEntry

/-!
# Internal paths through actual prepared selected expansion

UNCOMPILED source-only draft. The smaller-depth premise is internal.
All old selected resource witnesses and clauses remain.
-/
'''+s
q=r/'ExecutionExpansionPrepared-v1-UNCOMPILED.lean';assert not q.exists();q.write_text(text);q.chmod(0o444)
print(json.dumps(dict(path=str(q),lines=len(text.splitlines()),bytes=len(text.encode()),sha256=hashlib.sha256(text.encode()).hexdigest()),indent=2))
