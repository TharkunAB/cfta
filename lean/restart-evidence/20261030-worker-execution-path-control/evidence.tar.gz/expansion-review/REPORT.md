# Selected expansion execution paths: source-only handoff

Status: UNCOMPILED. This bundle contains complete proof candidates, not checked theorems.
Root owns all Lean checks, production edits, native execution, Git, network and board work.
The review changed files only in this owner directory. It did not edit a prior frozen bundle.

## Preferred candidates

Install the supporting module first, if Root accepts it:

- `ExecutionOrdinaryBridge-v2-UNCOMPILED.lean`: 260 lines, 18562 bytes, SHA256 `99f49d20affff59b86a9f297b49b715ac094e0a6807b9d513671141e79cf6385`.
- Intended module: `MicroCFTA.SourcePruningEnumerationExecutionOrdinaryBridge`.
- Public theorem: `Native.ordinary_finite_complete_resources_paths`.

Then check the paired module:

- `ExecutionExpansion-v2-UNCOMPILED.lean`: 744 lines, 52642 bytes, SHA256 `ce013c48a217e9659cce8b4c6cd77a21d15b2eacfbe8cb6a1b5aee32eaf755bb`.
- Intended module: `MicroCFTA.SourcePruningEnumerationExecutionExpansionBridge`.
- Public theorems: `Native.selected_finite_complete_resources_paths` and `Prepared.selected_finite_complete_resources_paths`.
- Both selected namespace bodies equal their separate current candidates by byte identity.
- The selected production module was absent when the paired V1 draft was announced at 20:33 CET.

The paired candidate retains all old explicit inputs and all old result clauses.
`CONTRACT-MAPS.json` checks the original input prefix, original result prefix and implicit equality context by exact text equality.
`PUBLIC-CONTRACTS-UNCOMPILED.md` includes the complete contracts, local notation, open declarations, implicit variables and three equality instances.
These source comparisons do not establish elaboration or kernel acceptance.

## Added premises and conclusion

Each selected companion adds exactly the following internal inputs after the old chosen decision:

1. A path predicate `P` and `StatePaths P before.core`.
2. Suffix closure: `P (index :: suffix)` implies `P suffix`.
3. `ProjectionPaths` for the worker's literal original `final (recursiveFuel + 1) seed ceiling` forecast.
4. The same concrete eventual smaller-depth execution-path IH as ReceiptBridge.

The smaller-depth IH keeps Packet, Fits, Heap, selection membership and length, suspended mass, reservation, initial StatePaths and exact smaller final forecast projections.
It returns an eventual actual Native or Prepared execution-path predicate at `recursiveFuel`.
This is an internal induction premise. The eventual whole-worker proof must discharge it.
The old finite resource `Complete` premise also stays unchanged.
No new arbitrary Stage, successful trace, target equality, whole-execution supplier or public future completion premise is added.

The selected result retains one bound, one stable outcome, the actual running equation at every `bound + extra`, and the exact old OutcomeResources clause.
It appends actual `ResumeNative` or `ResumePrepared` at that same work bound, original cache and decision, and depth `recursiveFuel + 1`.
The ordinary support companion appends actual `NativeStage` at every common larger bound and the paths of its finished actual fold.
It keeps every old entry equation, render stability clause, counter/value/flag/waiting equation, packet, scan equation, post, resource, receipt and output clause.

## Actual branch construction

Both workers use `prefix_checkpoint_complete` and the unconditional `runPrefix_paths` law.
The accepted prefix equation contains the actual action singleton, retained `some after`, false Right singleton and ordinary field `none`.
The path proof extracts StatePaths of this retained `after`.
It does not use the Core displayed in the Right record row as the next cache.

Parked branches call the corresponding checked ParkedBridge companion.
They preserve the actual returned parked decision and its smaller recursive call.
Rejected branches retain the empty actual output and the selected-prefix paths.
An empty output does not remove the local selected-prefix requirement.

Native ordinary entry calls the actual `SelectedEntry.complete` producer.
The producer's singleton contains returned target `uv`.
Its actual lookup equation and the supplied decoded equation identify the node value.
Its flag and waiting equations derive the captured frame.
Its stored, ready, render, pending, ordering and counter clauses derive the entered Packet.
The primitive `Entry.enter_paths` law derives the entered StatePaths from the actual singleton.
No selected/returned-target equality is assumed.

The ordinary support proof obtains the old resource scan and the new sibling path scan.
It equates their actual fold results at a common larger work bound.
It then retains every processed receipt, all actual hook invocations, all raw entry rows and the actual finished failure data.
The selected Native proof keeps the old forecast certificate and adds the ordinary path bound.
Its two actual runs need not have their existential witnesses identified in the selected theorem: the literal Resume predicate concerns the actual run at the common bound.

Native fallback uses the old actual fallback entry equation.
The same primitive Entry path law supplies every singleton raw row.
Terminal nodes and all non-node constructors retain their actual ordinary failure data.
The native terminal fallback performs no sibling scan.

Prepared entry uses the old actual preparation resource producer.
The first projection of its literal `SelectedPreparation.run` equation is the actual Entry singleton.
That singleton derives entered StatePaths.
The old flag and waiting equations derive the captured frame.
The prepared caller is exactly `SelectedValueCaller.advance reached preparedHeap`.
The Prepared sibling call uses its separate parent Available and parent closed facts.
It does not borrow the Native decoded-node gate or substitute the earlier caller.

Prepared ordinary dispatch uses the actual `SelectedContinuations.ordinary` equation and the new Prepared sibling path scan.
The count bound comes from the prepared reservation's `selected_length_le` producer.
`ScanReserved.prefix` restricts the original reservation to the actual selected count.
The count monotonicity clause transports the original final forecast projection into this actual scan forecast.
A common larger bound covers prefix, preparation, old resource scan and new path scan.
All actual sibling invocations retain LeftPaths before finish, including stopped hooks and hooks with empty outputs.

Prepared opaque dispatch calls the checked OpaqueBridge companion.
The original `first_le_final` inclusion derives the smaller exact opaque forecast projection.
The proof retains the actual preparation pair, opaque receipt continuation, FullReceiptPaths, FoldPaths and finished OutcomePaths.
The dispatch equation tests terminal inherited classes before the node branch.
Terminal nodes take the opaque route. Every non-node constructor also takes the opaque route.
The literal prepared caller, captured frame, saved query and callback closure remain in the stage predicate.

## Acquisition scope and provenance

The original allowance was two new whole OLD proof sources.
Root approved a third named source at measured 20:16 CET, before its full acquisition.
`SCOPE-EXTENSION.md` records that the prior ordinary source union was 28–129, or 102/176 lines.
Exactly these three OLD whole sources were acquired:

- Native finite expansion: 195/195 lines, SHA256 `e5caab2b5ddb7096f0351525053161470813775da8ad9ee4b57893ba4503d686`.
- Prepared finite expansion: 257/257 lines, SHA256 `f0ec9527dfe53135c5954f65bedbd59a7f3f74cef3ed469e25e78a47089b9d2e`.
- Native finite ordinary resources: 176/176 lines, SHA256 `78c12f397b7dd49bbcab71654a8261ce89c2916fde6054bbd8a0dade0da1b3b5`.

No fourth OLD whole or near-whole source was acquired by combined cuts.
Seventeen bounded cuts retain their requested and actual endpoints and complete-source and copy hashes.
The prepared preparation source request 103–121 stops at EOF120; this clamp is explicit.
The last new source cut is SelectedContinuations74–100 of234 lines.
`SOURCE-UNIONS.json` records the cumulative union for each production source.
The largest other bounded fraction is PathPreparedEntry11–49 of74 lines.

Five frozen full sources were reused only after frozen-manifest, current complete-source and copied-byte identity checks.
They are the old paired sibling resources, ExecutionPaths, ExecutionPathData and CallbackProjection.
Six fresh Root bridge outputs were separately authorized in full.
They are CallbackControl, ReceiptBridge, HeadBridge, SiblingBridge, OpaqueBridge and ParkedBridge.
They are recorded as fresh outputs, not silently classified as prior frozen reuse.
`SOURCE-CHECKS.json` checks all31 source copies against current bytes and their exact retained ranges.

Root reported strict PASS for CallbackControl, ReceiptBridge, HeadBridge, SiblingBridgeV4 and OpaqueBridgeV3 at their pinned bytes.
Root reported ParkedV2 probe PASS and ParkedV3 as the status-comment-only production version, with strict checking pending at task assignment.
This review did not run or independently inspect those commands.
It makes no Audit or public-tail claim for these new candidates.

## Versions, incidents and remaining work

Every announced candidate remains read-only.
OrdinaryV1 and NativeSelectedV1 contain source-detected extraction repairs that the later versions correct.
OrdinaryV2 corrects its extracted outer proof indentation and unfolds SiblingPaths directly.
NativeSelectedV2 corrects its extracted stable-run indentation and the rejected True branch.
NativeSelectedV3 and pairedV2 make the terminal fallback reduction explicit with a bounded simp set.
PreparedSelectedV1 is unchanged. PairedV1 is retained.
The exact failed generator script is retained. No script failure is called a Lean failure.
The final display output limit was recovered with smaller ranges; `READ-DISPLAYS.json` records the recovery.
`INCIDENTS.md` keeps the locator failures, script repairs and display incident.

Root must compile and strictly check the two preferred modules before any theorem claim.
The concrete smaller-depth IH must then be discharged in both actual whole-worker inductions.
The fixed-D path result still does not establish an original sufficient recursive depth, configured prefix coverage or public Haskell correspondence.
It does not close fresh-handle control, every original public adapter gate, or the full library objective.
No Haskell source was changed or executed. No Haskell repair was identified for FINDINGS in this task.

The final manifest and pins cover this source-only handoff.
The write-halt marker closes this owner scope. Every regular file has all write bits removed.
