open EnumerationState EnumerationCorrectness EnumerationSchedule InternedConstructorTemplates
open SourcePruningEnumerationNodes
open SourcePruningEnumerationPathTransport SourcePruningEnumerationPathSelectedRaw
local notation "Symbol" => SourcePruningTemplates.Symbol

/-- Every actual selected prefix preserves paths in all retained cores and raw rows. -/
theorem runPrefix_paths {Typing Key : Type} {width : Nat}
    [DecidableEq (EdgeKey Symbol (SourceSymbolicIndex.Constraint FullSyntax.Formula))]
    {P : EqualityTrie.Path → Prop}
    (holeKey : Typing → Nat → Key) (fits : Key → Symbol → Bool)
    (admits : Key → Value Symbol (SourceSymbolicIndex.Constraint FullSyntax.Formula) → Bool)
    (graph : Graph Symbol (SourceSymbolicIndex.Constraint FullSyntax.Formula))
    (templates : List (Template.Pattern Symbol))
    (stop : Option (SourcePruningRecordTypes.Metadata Typing → Nat → Bool))
    (order : SourcePruningRecordTypes.Metadata Typing → List Nat → Option Nat)
    (metadata : SourcePruningRecordTypes.Metadata Typing)
    (readFuel checkFuel nativeFuel representativeFuel indexFuel callbackFuel uv : Nat)
    (caller : SourceCurrentAllocatedPartialState.State width)
    (before : EnumerationExpandableIndex.Cached Symbol (SourceSymbolicIndex.Constraint FullSyntax.Formula))
    (queries : SourceEndpointMemo.Memos) (paths : StatePaths P before.core) :
    SelectedPrefixPaths P (SourcePruningEnumerationSelectedStep.runPrefix
      holeKey fits admits graph templates stop order metadata readFuel checkFuel nativeFuel
      representativeFuel indexFuel callbackFuel uv caller before queries) := by
