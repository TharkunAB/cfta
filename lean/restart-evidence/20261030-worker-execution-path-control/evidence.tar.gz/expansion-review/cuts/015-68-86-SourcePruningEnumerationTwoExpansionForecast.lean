    (start seed) (mass before) (mass before) (rows seed)
  exact ⟨(start_ge seed).1.trans stages.1, fun _ member => stages.2 ((start_ge seed).2 member)⟩

/-- Current available rows and a nonincreasing selector fit the original ordinary row budget. -/
theorem selected_length_le {width : Nat} (seed : Seed) (caller : Caller width)
    (bounded : Fits (start seed).2 caller.checked)
    (entry : Cache.Interned InternedBinderProtocol.NodeKey)
    (stored selected : List (EdgeValue Symbol Constraint)) (depth : Nat)
    (free : List InternedBinderProtocol.Reference)
    (available : Available caller.checked.native.machine.heap (.node entry stored depth free))
    (lengths : selected.length ≤ stored.length) : selected.length ≤ rows seed := by
  have heapFits : SourceCurrentConstrainedCapRequiredResources.HeapFits (start seed).2
      caller.checked.native.machine.heap :=
    SourceCurrentConstrainedCapRequiredResources.of_checked
      (profile := (start seed).2) (before := caller.checked) bounded
  have count := SourceCurrentConstrainedCapRequiredResources.node_width heapFits available
  exact Nat.le_trans lengths (Nat.le_trans count (Nat.le_succ _))

/-- The ordinary route uses a prefix of the original sibling reservation. -/
