  | _bits, 0, _seed, _ceiling => True
  | bits, depth + 1, seed, ceiling =>
      ∀ index, index < rows seed →
        SourcePruningEnumerationIncomingReservation.Reserved bits
          (stage depth (narrowSeed seed) ceiling ceiling index)
          (edgeCount (stage depth (narrowSeed seed) ceiling ceiling index) ceiling) ∧
        Reserved bits depth
          (afterHead (stage depth (narrowSeed seed) ceiling ceiling index) ceiling)
          (massCeil (stage depth (narrowSeed seed) ceiling ceiling index) ceiling ceiling)

/-- Reserve an edge and its smaller-depth callback at the same planned head endpoint. -/
def HeadReserved (bits depth : Nat) (seed : Seed) (capturedMass inherited : Nat) : Prop :=
  SourcePruningEnumerationIncomingReservation.Reserved bits seed (edgeCount seed inherited) ∧
    Reserved bits depth (afterHead seed inherited) (massCeil seed capturedMass inherited)

/-- Reserve every paired entry of one original sibling schedule. -/
