def SelectedPrefixPaths {Typing : Type} {width : Nat} (P : EqualityTrie.Path → Prop) :
    SourcePruningEnumerationSelectedStep.Result width Typing → Prop
  | .stopped read checked =>
      RawPaths P read ∧ ∀ rows, checked = some rows → RawPaths P rows
  | .parked checked candidate raw =>
      StatePaths P checked ∧
      (∀ after, candidate = some after → StatePaths P after.core) ∧
      ∀ rows, raw = some rows → RawPaths P rows
  | .narrowed checked _ _ _ action candidate right ordinary =>
      StatePaths P checked ∧
      (∀ rows, action = some rows → RawPaths P rows) ∧
      (∀ after, candidate = some after → StatePaths P after.core) ∧
      (∀ rows, right = some rows → RawPaths P rows) ∧ ordinary = none

