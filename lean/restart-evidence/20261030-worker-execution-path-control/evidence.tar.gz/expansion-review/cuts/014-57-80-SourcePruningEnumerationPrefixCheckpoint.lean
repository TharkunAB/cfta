        runPrefix holeKey fits admits graph templates stop order metadata
            (fuel + extra) (fuel + extra) (fuel + extra) (fuel + extra) (fuel + extra) (fuel + extra)
            uv caller before memos.query =
          .narrowed checked (.done (.empty, some (reject : EnumerateM Symbol Constraint Unit)) heap)
            (SourceCurrentAllocatedPartialState.advance caller
              (advancePhysical caller.checked ⟨heap, caller.checked.operations⟩) caller.fourth caller.merge)
            memos.query (some []) none none none ∧
        PrefixValid holeKey fits admits graph templates checkEmpty edgesOf stop order metadata
            formulas solver inventory (fuel + extra) uv caller before memos
            (runPrefix holeKey fits admits graph templates stop order metadata
            (fuel + extra) (fuel + extra) (fuel + extra) (fuel + extra) (fuel + extra) (fuel + extra)
            uv caller before memos.query)) ∨
      (∃ (checked : Core) (value : Node) (heap : InternedConstructorTemplates.State Symbol Constraint)
          (after : Cached), value ≠ .empty ∧ ∀ extra, ∃ action : EnumerateM Symbol Constraint Unit,
        runPrefix holeKey fits admits graph templates stop order metadata
            (fuel + extra) (fuel + extra) (fuel + extra) (fuel + extra) (fuel + extra) (fuel + extra)
            uv caller before memos.query =
          .narrowed checked (.done (value, some action) heap)
            (SourceCurrentAllocatedPartialState.advance caller
              (advancePhysical caller.checked ⟨heap, caller.checked.operations⟩) caller.fourth caller.merge)
            memos.query (some [.ok ((), after.core)]) (some after)
            (some [.ok ((false, metadata), after.core)]) none ∧
        PrefixValid holeKey fits admits graph templates checkEmpty edgesOf stop order metadata
            formulas solver inventory (fuel + extra) uv caller before memos
