theorem ScanReserved.prefix {bits depth capturedMass inherited first last : Nat} {seed : Seed}
    (reservation : ScanReserved bits depth seed capturedMass inherited last) (counts : first ≤ last) :
    ScanReserved bits depth seed capturedMass inherited first :=
  fun index less => reservation index (Nat.lt_of_lt_of_le less counts)

/-- A consumed scan prefix leaves the exact original remaining reservations. -/
