def run (entryFuel nativeFuel uv : Nat) (caller : Caller width) (before : Cached) :
    Raw × Option (MergedSourceComparison.Result Symbol Constraint Node) :=
  let raw := ExceptT.run (SourcePruningEnumerationEntry.enter caller.checked.native.machine.heap
    entryFuel uv before.core)
  (raw, match raw with
    | [.ok ((_target, _handle, _scs, value), _entered)] =>
        some (SourcePruningEnumerationSelectedValue.run nativeFuel value caller.checked.native.machine.heap)
    | _ => none)

