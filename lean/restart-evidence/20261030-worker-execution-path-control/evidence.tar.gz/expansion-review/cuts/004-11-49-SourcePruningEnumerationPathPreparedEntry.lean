namespace MicroCFTA.SourcePruningEnumerationPathPreparedEntry
open EnumerationState EnumerationCorrectness InternedConstructorTemplates
open SourcePruningEnumerationPathTransport
local notation "Symbol" => SourcePruningTemplates.Symbol
local notation "Constraint" => SourceSymbolicIndex.Constraint FullSyntax.Formula
local notation "Node" => Value Symbol Constraint
local notation "Caller" => SourceCurrentAllocatedPartialState.State
local notation "Cached" => EnumerationExpandableIndex.Cached Symbol Constraint
variable {EnumGuard NativeGuard : Type} {P : EqualityTrie.Path → Prop}

private theorem getValue_paths (fuel uv : Nat)
    (before after : EnumerationState.State Symbol EnumGuard) (value : UVarValue Symbol)
    (paths : StatePaths P before)
    (observed : Success (getValue fuel uv) before value after) : StatePaths P after := by
  obtain ⟨_found, _lookup, _stored, rfl⟩ := (getValue_success fuel uv before after value).mp observed
  exact paths

/-- Every successful entry row retains the original stored-path predicate. -/
theorem enter_paths
    (heap : InternedConstructorTemplates.State Symbol NativeGuard) (fuel uv : Nat)
    (before after : EnumerationState.State Symbol EnumGuard)
    (result : Nat × Nat × List Suspended × Value Symbol NativeGuard)
    (paths : StatePaths P before)
    (observed : Success (SourcePruningEnumerationEntry.enter heap fuel uv) before result after) :
    StatePaths P after := by
  unfold SourcePruningEnumerationEntry.enter at observed
  obtain ⟨value, readState, read, continued⟩ := (success_bind _ _ _ _ _).mp observed
  have readPaths := getValue_paths fuel uv before readState value paths read
  cases value with
  | eliminated => simp [Success, EnumerationState.reject, ExceptT.run] at continued
  | enumerated fragment => simp [Success, EnumerationState.reject, ExceptT.run] at continued
  | unenumerated node scs =>
      cases node with
      | none => simp [Success, EnumerationState.reject, ExceptT.run] at continued
      | some handle =>
          obtain ⟨target, rootState, rooted, continued⟩ := (success_bind _ _ _ _ _).mp continued
          have rootPaths := SourcePruningEnumerationPathStorage.representative_paths
            fuel uv target readState rootState readPaths rooted
          cases decoded : SourcePruningEnumerationNodes.lookupNode heap handle with
