from pathlib import Path
import hashlib,json
r=Path('/tmp/mcfta-worker-execution-path-control-20261030/expansion-review');old=(r/'sources/SourcePruningEnumerationFiniteOrdinaryResources.lean').read_text();ns='MicroCFTA.SourcePruningEnumerationNativeOrdinaryContinuations';newns='MicroCFTA.SourcePruningEnumerationExecutionOrdinaryBridge.Native';s=old[old.index('namespace '+ns):].replace('namespace '+ns,'namespace '+newns,1).replace('end '+ns,'end '+newns)
def rep(a,b):
 global s
 assert a in s,a[:120];s=s.replace(a,b,1)
rep('theorem ordinary_finite_complete_resources\n','theorem ordinary_finite_complete_resources_paths\n')
rep('variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]\n','''variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
open SourcePruningEnumerationNativeOrdinaryContinuations (run entered)
open SourcePruningEnumerationPathTransport (StatePaths ProjectionPaths)
open SourcePruningEnumerationPathSelectedRaw (RawPaths)
open SourcePruningEnumerationExecutionPathData (OutcomePaths NativeFailurePaths)
open SourcePruningEnumerationExecutionPaths (NativeStage SiblingPaths ResumeNative)
''')
receipt=(r/'root-new/SourcePruningEnumerationExecutionReceiptBridge.lean').read_text().split('namespace MicroCFTA.SourcePruningEnumerationExecutionReceiptBridge.Native',1)[1];ih=receipt.split('    (pathsIH :',1)[1].split(') :\n    ∃ (fuel',1)[0]
rep('      (edgesOf (.node parentEntry storedEdges depth free)).length) :','''      (edgesOf (.node parentEntry storedEdges depth free)).length)
    (P : EqualityTrie.Path → Prop) (original : StatePaths P before.core)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (projected : ProjectionPaths (stage recursiveFuel seed capturedMass inherited
      (edgesOf (.node parentEntry storedEdges depth free)).length).1 P)
    (pathsIH :'''+ih+') :')
rep('        (SourcePruningEnumerationRecursive.finish uv result) := by','''        (SourcePruningEnumerationRecursive.finish uv result) ∧
      (∀ extra, NativeStage P
        (ResumeNative P holeKey fits admits graph templates checkEmpty edgesOf stop order
          (bound + extra) recursiveFuel) (NativeFailurePaths P)
        (continueWith (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
          (bound + extra) recursiveFuel) graph templates stop order (bound + extra) metadata uv)
        graph templates stop order checkEmpty (bound + extra) metadata uv edgesOf caller before memos.query) ∧
      OutcomePaths P (NativeFailurePaths P) (SourcePruningEnumerationRecursive.finish uv result) := by''')
mark='  have entryAt (extra : Nat) :'
proof='''  have enteredPathsP : StatePaths P enteredCache.core := by
    apply SourcePruningEnumerationPathPreparedEntry.enter_paths caller.checked.native.machine.heap
      entryFuel uv before.core enteredCache.core
      (uv, handle, scs, .node parentEntry storedEdges depth free) original
    change Except.ok ((uv, handle, scs, .node parentEntry storedEdges depth free), enteredCache.core) ∈
      ExceptT.run (SourcePruningEnumerationEntry.enter caller.checked.native.machine.heap entryFuel uv before.core)
    have actual := entryRun 0
    simp only [Nat.add_zero] at actual
    rw [actual]
    exact List.mem_singleton_self _
  obtain ⟨pathBound, _pathProcessed, _pathOutputs, _pathCaller, _pathInventory, _pathMemos,
    pathResult, pathRun, _pathPost, _pathPacket, _pathFits, _pathKnown, _pathLength,
    _pathReceipts, _pathOutputsAt, _pathShape, foldPaths, invocations⟩ :=
    SourcePruningEnumerationExecutionSiblingBridge.Native.alternatives_finite_complete_resources_paths
      holeKey fits admits graph templates checkEmpty edgesOf stop order metadata recursiveFuel seed formulas solver recursive inventory
      caller memos enteredCache uv handle scs parentEntry storedEdges
      (edgesOf (.node parentEntry storedEdges depth free)) depth free enteredPacket enteredReady enteredStored
      decoded selected (EnumerationReferences.incoming_read uv before.core enteredCache.core stable incoming)
      bounded known selectionMembers selectionLength capturedMass inherited enteredMass inheritedLength reserved
      P enteredPathsP tails projected pathsIH
  have sameResult : pathResult = result := by
    have first := scanRun pathBound
    have second := pathRun scanBound
    have same : pathBound + scanBound = scanBound + pathBound := by omega
    rw [same] at second
    exact second.symm.trans first
  subst pathResult
'''
rep(mark,proof+mark)
# Extend all old stable work equations to a common old/path bound.
body_start=s.index('  have entryAt (extra : Nat) :');prefix=s[:body_start];body=s[body_start:]
body=body.replace('entryFuel + scanBound','entryFuel + scanBound + pathBound').replace('entryRun (scanBound + extra)','entryRun (scanBound + pathBound + extra)').replace('scanRun (entryFuel + extra)','scanRun (entryFuel + pathBound + extra)').replace('scanBound + (entryFuel + extra)','scanBound + (entryFuel + pathBound + extra)')
s=prefix+body
start=s.index('  refine ⟨entryFuel + scanBound + pathBound,')
oldtail=s[start:s.index('\nend '+newns,start)]
# The old final running equation becomes a named equation used by the Stage proof.
proofstart=oldtail.index('   · intro extra\n')+len('   · intro extra\n');outerproof=oldtail[proofstart:]
outerproof='\n'.join(line[5:] if line.startswith('     ') else line for line in outerproof.splitlines())
outer='''  have outerAt (extra : Nat) : run
      (continueWith (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
        (entryFuel + scanBound + pathBound + extra) recursiveFuel)
        graph templates stop order (entryFuel + scanBound + pathBound + extra) metadata uv)
      checkEmpty (entryFuel + scanBound + pathBound + extra) (entryFuel + scanBound + pathBound + extra)
      (entryFuel + scanBound + pathBound + extra) (entryFuel + scanBound + pathBound + extra)
      (entryFuel + scanBound + pathBound + extra) uv edgesOf caller before memos.query =
      ([.ok ((uv, handle, scs, .node parentEntry storedEdges depth free), enteredCache.core)], some result) := by
'''+ '\n'.join('    '+line for line in outerproof.splitlines())+'\n'
finish='''  refine ⟨entryFuel + scanBound + pathBound, enteredCache, processed, outputs, afterCaller, next, final, result,
    entryAt, stable, counter, values, sameFlags, sameWaiting, enteredPacket, outerAt, scanAt, post, captured,
    afterFits, afterKnown, processedLength, receipts, outputPackets, shape, finished, ?_,
    SourcePruningEnumerationExecutionPathData.native_finish_paths uv result foldPaths⟩
  intro extra
  unfold NativeStage
  rw [outerAt extra]
  refine ⟨?_, ?_, ?_⟩
  · intro value core member
    cases Except.ok.inj (List.mem_singleton.mp member)
    exact enteredPathsP
  · intro current found
    cases Option.some.inj found
    exact foldPaths
  · rw [nonterminal]
    change SiblingPaths P _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
    rw [frame]
    refine ⟨?_, ?_⟩
    · rw [scanAt extra]
      exact foldPaths
    · have current := invocations (entryFuel + scanBound + extra)
      have same : pathBound + (entryFuel + scanBound + extra) =
          entryFuel + scanBound + pathBound + extra := by omega
      rw [same] at current
      exact current
'''
s=s[:start]+outer+finish+s[s.index('\nend '+newns,start):]
text='''import MicroCFTA.SourcePruningEnumerationFiniteOrdinaryResources
import MicroCFTA.SourcePruningEnumerationExecutionSiblingBridge
import MicroCFTA.SourcePruningEnumerationPathPreparedEntry

/-!
# Actual ordinary entry and sibling execution paths

UNCOMPILED source-only draft. The actual entry equation supplies its target.
The original resource witnesses and their complete stable result stay.
-/
'''+s
q=r/'ExecutionOrdinaryBridge-v1-UNCOMPILED.lean';assert not q.exists();q.write_text(text);q.chmod(0o444)
print(json.dumps(dict(path=str(q),lines=len(text.splitlines()),bytes=len(text.encode()),sha256=hashlib.sha256(text.encode()).hexdigest()),indent=2))
