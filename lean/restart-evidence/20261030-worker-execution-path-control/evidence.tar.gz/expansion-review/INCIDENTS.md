# Incidents

Two guessed path-module glob names and one guessed EntryPacket filename did not exist. Correct names were located with rg --files and declarations. These were read-only locator failures.

Native ordinary generator V1 halted before writing a Lean candidate because the captured old final proof used two-space rather than three-space bullet indentation. Its exact failed script is retained read-only. The parser extraction was corrected. No compiler was run.

The full source review of Native ordinary V1 detected incorrect indentation in the extracted outerAt proof and an unnecessary schematic change command. An initial repair script requested nine leading spaces instead of the actual eight and halted before writing a version. V2 then copied the original proof block with its exact indentation and unfolds SiblingPaths directly. V1 remains immutable. These are source/script repairs. No compiler result is claimed.

Native selected V1 had an extracted stable-run proof indentation error and an implicit rejected True goal. V2 copies the exact old proof block and closes that True explicitly. Final source review changed the terminal fallback node case from rw alone to simp only on its actual terminal equality, Bool.true_eq_true and reduceIte. Native V3 and paired V2 contain this source repair. All earlier versions remain read-only; no compiler diagnostic is claimed.

The first batched final-display call truncated the fourth paired range and omitted the ordinary output at the tool output limit. The missing ranges were recovered in separate smaller displays: paired 559–650 and651–744, ordinary1–130 and131–260. The final paired V2 differs from the fully displayed V1 by the one reviewed terminal fallback tactic line only.

The preferred pairedV2 was then displayed in four separate full ranges1–186,187–372,373–558 and559–744. The ordinaryV2 source and complete contract map/report were also displayed without remaining truncation. READ-DISPLAYS.json pins the actual final bytes.
