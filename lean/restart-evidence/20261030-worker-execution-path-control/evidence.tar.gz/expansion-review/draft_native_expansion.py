from pathlib import Path
import hashlib,json,textwrap
r=Path('/tmp/mcfta-worker-execution-path-control-20261030/expansion-review');old=(r/'sources/SourcePruningEnumerationFiniteExpansionResources.lean').read_text();ns='MicroCFTA.SourcePruningEnumerationRecursive';newns='MicroCFTA.SourcePruningEnumerationExecutionExpansionBridge.Native';s=old[old.index('namespace '+ns):].replace('namespace '+ns,'namespace '+newns,1).replace('end '+ns,'end '+newns)
def rep(a,b):
 global s
 assert a in s,a[:120];s=s.replace(a,b,1)
rep('theorem selected_finite_complete_resources\n','theorem selected_finite_complete_resources_paths\n')
rep('variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]\n','''variable [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Constraint)] [DecidableEq Node]
open SourcePruningEnumerationRecursive
open SourcePruningEnumerationPathTransport (StatePaths ProjectionPaths)
open SourcePruningEnumerationPathSelectedRaw (RawPaths SelectedPrefixPaths)
open SourcePruningEnumerationExecutionPaths (ResumeNative NativeStage)
''')
receipt=(r/'root-new/SourcePruningEnumerationExecutionReceiptBridge.lean').read_text().split('namespace MicroCFTA.SourcePruningEnumerationExecutionReceiptBridge.Native',1)[1];ih=receipt.split('    (pathsIH :',1)[1].split(') :\n    ∃ (fuel',1)[0].replace('suspendedBound nextCache.core','mass nextCache.core')
rep('    (chosen : SourcePruningEnumerationRestart.decision stop order metadata before = some (.expand uv)) :','''    (chosen : SourcePruningEnumerationRestart.decision stop order metadata before = some (.expand uv))
    (P : EqualityTrie.Path → Prop) (original : StatePaths P before.core)
    (tails : ∀ index suffix, P (index :: suffix) → P suffix)
    (projected : ProjectionPaths (Forecast (recursiveFuel + 1) seed ceiling).1 P)
    (pathsIH :'''+ih+') :')
rep('        (Forecast (recursiveFuel + 1) seed ceiling) outcome := by','''        (Forecast (recursiveFuel + 1) seed ceiling) outcome ∧
      (∀ extra, ResumeNative P holeKey fits admits graph templates checkEmpty edgesOf stop order
        (bound + extra) (recursiveFuel + 1) metadata caller memos.query before (some (.expand uv))) := by''')
rep('  have selection : EnumerationPureSelection.next', '''  have stageProjected : ProjectionPaths
      (SourcePruningEnumerationFiniteReservation.stage recursiveFuel start inherited inherited
        (SourcePruningEnumerationFiniteReservation.rows seed)).1 P := by
    simpa only [SourcePruningEnumerationFiniteReservation.final_succ] using projected
  have prefixPaths (work : Nat) := SourcePruningEnumerationPathSelectedPrefix.runPrefix_paths
    holeKey fits admits graph templates stop order metadata work work work work work work uv caller before memos.query original
  have selection : EnumerationPureSelection.next''')
rep('obtain ⟨bound, outcome, running, resources⟩ := parked_finite_complete_resources','obtain ⟨bound, outcome, running, resources, allPaths⟩ :=\n      SourcePruningEnumerationExecutionParkedBridge.Native.parked_finite_complete_resources_paths')
rep('selectionMembers selectionLength initialMass reserved phase\n','selectionMembers selectionLength initialMass reserved phase P original projected pathsIH\n')
rep('      simpa only [SourcePruningEnumerationFiniteReservation.final_succ] using resources⟩','      simpa only [SourcePruningEnumerationFiniteReservation.final_succ] using resources, allPaths⟩')
reject='''    refine ⟨prefixFuel, .complete [] reached memos.query, ?_, certificate.mono
      stageGrowth.1 stageGrowth.2⟩
    intro extra
    rw [resume, (phase extra).1]
'''
rep(reject,'''    refine ⟨prefixFuel, .complete [] reached memos.query, ?_, certificate.mono
      stageGrowth.1 stageGrowth.2, ?_⟩
    · intro extra
      rw [resume, (phase extra).1]
    · intro extra
      refine ⟨original, ?_, prefixPaths (prefixFuel + extra), ?_⟩
      · rw [resume, (phase extra).1]
        intro output member
        exact False.elim (List.not_mem_nil member)
      · rw [(phase extra).1]
''')
rep('    rw [prefixAt] at valid\n    have admission :=','''    rw [prefixAt] at valid
    have retainedPaths := prefixPaths (prefixFuel + 0)
    rw [prefixAt] at retainedPaths
    have afterPaths : StatePaths P after.core := retainedPaths.2.2.1 after rfl
    have admission :=''')
rep('_shape, _finished, _countBound, _finalFits','_shape, _finished, countBound, _finalFits')
start=s.index('      refine ⟨prefixFuel + scanFuel,');end=s.index('    · have fallback :',start);originalProof=s[start:end];applyProof=originalProof.split('      apply resume_depth_stable',1)[1];applyProof='apply resume_depth_stable'+applyProof;applyProof=textwrap.dedent(applyProof)
new='''      have scanProjected : ProjectionPaths
          (SourcePruningEnumerationFiniteReservation.stage recursiveFuel start inherited inherited
            (edgesOf (.node entry rows depth free)).length).1 P := by
        intro guard member
        exact stageProjected guard
          ((SourcePruningEnumerationFiniteReservation.count_mono recursiveFuel start inherited inherited countBound).2 member)
      obtain ⟨pathFuel, _pathEntered, _pathProcessed, _pathOutputs, _pathCaller, _pathInventory, _pathMemos,
        pathResult, _pathEntry, _pathStable, _pathCounter, _pathValues, _pathFlags, _pathWaiting,
        _pathPacket, pathOuter, _pathScan, _pathPost, _pathCaptured, _pathFits, _pathKnown,
        _pathLength, _pathReceipts, _pathOutputPackets, _pathShape, _pathFinished, stagePaths, outcomePaths⟩ :=
        SourcePruningEnumerationExecutionOrdinaryBridge.Native.ordinary_finite_complete_resources_paths
          holeKey fits admits graph templates checkEmpty edgesOf stop order metadata recursiveFuel start formulas solver recursive inventory
          reached middleMemos after uv handle scs entry rows depth free middlePacket ready stored decoded
          (selectionMembers entry rows depth free) incoming nonterminal middleFits middleKnown
          selectionMembers selectionLength inherited inherited currentMass inheritedBound
          (reserved.scan.prefix countBound) P afterPaths tails scanProjected pathsIH
      have running : ∀ extra, resume holeKey fits admits graph templates checkEmpty edgesOf stop order
          (prefixFuel + scanFuel + extra) (recursiveFuel + 1)
          metadata caller memos.query before (some (.expand uv)) = finish uv result := by
'''+textwrap.indent(applyProof,'        ')+'''      refine ⟨prefixFuel + scanFuel + pathFuel, finish uv result, ?_, certificate.post middlePost, ?_⟩
      · intro extra
        simpa only [Nat.add_assoc] using running (pathFuel + extra)
      · intro extra
        obtain ⟨currentAction, currentPrefix, _valid⟩ := phase (scanFuel + pathFuel + extra)
        have prefixSame : prefixFuel + (scanFuel + pathFuel + extra) = prefixFuel + scanFuel + pathFuel + extra := by omega
        rw [prefixSame] at currentPrefix
        have outer := pathOuter (prefixFuel + scanFuel + extra)
        have stage := stagePaths (prefixFuel + scanFuel + extra)
        have common : pathFuel + (prefixFuel + scanFuel + extra) = prefixFuel + scanFuel + pathFuel + extra := by omega
        rw [common, middleQuery] at outer stage
        refine ⟨original, ?_, prefixPaths (prefixFuel + scanFuel + pathFuel + extra), ?_⟩
        · rw [resume, currentPrefix, outer]
          exact outcomePaths
        · rw [currentPrefix]
          exact stage
'''
s=s[:start]+new+s[end:]
rep('⟨entryFuel, entered, _entryRun, _stable','⟨entryFuel, entered, entryRun, _stable')
mark='      let raw := [Except.ok'
pathproof='''      have enteredPathsP : StatePaths P entered.core := by
        apply SourcePruningEnumerationPathPreparedEntry.enter_paths reached.checked.native.machine.heap
          entryFuel uv after.core entered.core (uv, handle, scs, value) afterPaths
        change Except.ok ((uv, handle, scs, value), entered.core) ∈
          ExceptT.run (SourcePruningEnumerationEntry.enter reached.checked.native.machine.heap entryFuel uv after.core)
        have actual := entryRun 0
        simp only [Nat.add_zero] at actual
        rw [actual]
        exact List.mem_singleton_self _
'''
rep(mark,pathproof+mark)
rep('''      have certificate : OutcomeResources formulas solver reached start outcome := by''','''      have rawPaths : RawPaths P raw := by
        intro result core member
        cases Except.ok.inj (List.mem_singleton.mp member)
        exact enteredPathsP
      have certificate : OutcomeResources formulas solver reached start outcome := by''')
start=s.index('      refine ⟨prefixFuel + entryFuel, outcome,');end=s.index('\nend '+newns,start);oldfallback=s[start:end];runningproof='\n'.join(oldfallback.splitlines()[2:]);# original first two lines are refine and resource expression continuation
# Drop final refine target line before the actual intro.
runningproof=oldfallback[oldfallback.index('      intro extra\n'):]
new='''      have running : ∀ extra, resume holeKey fits admits graph templates checkEmpty edgesOf stop order
          (prefixFuel + entryFuel + extra) (recursiveFuel + 1)
          metadata caller memos.query before (some (.expand uv)) = outcome := by
'''+textwrap.indent(textwrap.dedent(runningproof),'        ')+'''      refine ⟨prefixFuel + entryFuel, outcome, running,
        (certificate.mono stageGrowth.1 stageGrowth.2).post middlePost, ?_⟩
      intro extra
      obtain ⟨currentAction, currentPrefix, _valid⟩ := phase (entryFuel + extra)
      have samePrefix : prefixFuel + (entryFuel + extra) = prefixFuel + entryFuel + extra := by omega
      rw [samePrefix] at currentPrefix
      have actual := fallbackRun (prefixFuel + extra)
        (continueWith (resume holeKey fits admits graph templates checkEmpty edgesOf stop order
          (prefixFuel + entryFuel + extra) recursiveFuel) graph templates stop order
          (prefixFuel + entryFuel + extra) metadata uv)
      have sameEntry : entryFuel + (prefixFuel + extra) = prefixFuel + entryFuel + extra := by omega
      rw [sameEntry, middleQuery] at actual
      refine ⟨original, ?_, prefixPaths (prefixFuel + entryFuel + extra), ?_⟩
      · rw [running extra]
        exact ⟨(fun _ member => False.elim (List.not_mem_nil member)), rawPaths⟩
      · rw [currentPrefix]
        unfold NativeStage
        rw [actual]
        refine ⟨rawPaths, ?_, ?_⟩
        · intro folded impossible
          cases impossible
        · cases value with
          | node entry rows depth free => rw [fallback]
          | empty | reference _ | union _ _ _ _ | mu _ _ _ _ => trivial
'''
s=s[:start]+new+s[end:]
text='''import MicroCFTA.SourcePruningEnumerationFiniteExpansionResources
import MicroCFTA.SourcePruningEnumerationExecutionOrdinaryBridge
import MicroCFTA.SourcePruningEnumerationExecutionParkedBridge
import MicroCFTA.SourcePruningEnumerationPathSelectedPrefix

/-!
# Internal paths through actual native selected expansion

UNCOMPILED source-only draft. The smaller-depth premise is internal.
All old selected resource witnesses and clauses remain.
-/
'''+s
q=r/'ExecutionExpansionNative-v1-UNCOMPILED.lean';assert not q.exists();q.write_text(text);q.chmod(0o444)
print(json.dumps(dict(path=str(q),lines=len(text.splitlines()),bytes=len(text.encode()),sha256=hashlib.sha256(text.encode()).hexdigest()),indent=2))
