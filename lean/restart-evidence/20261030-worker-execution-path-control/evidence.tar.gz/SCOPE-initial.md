# Whole-worker execution-path composition

Retain the full library formalization objective in the preceding sibling
phase SCOPE.md. Preserve all original inputs, native range gates, sound
outputs, finite-prefix coverage under the configured order and stop rule,
both workers, public adapters, optimized interned core, Haskell correspondence,
and the constructor, equality, node-count, size-order and rank/unrank results.

This phase must discharge the concrete smaller-depth execution hypothesis.
First compose selected expansion, ordinary entry, sibling and opaque dispatch,
and parked restart into actual positive-depth Resume paths. Then prove eventual
whole Native and Prepared paths by induction on recursive depth. Combine each
path work bound with the unchanged old resource bound at a common sum.
Derive fixed original-carrier projections from the checked original alphabet
laws. Do not add a future trace, Complete, callback, or model supplier to the
closed original-input theorem. Sufficient original recursive depth and intended
coverage remain separate requirements even if this path induction succeeds.

The expansion owner owns only expansion-review. Its initial allowance was two
new OLD production bodies in full: FiniteExpansionResources and
PreparedFiniteExpansionResources. At 20:16 CET Root approved one additional
named OLD whole body: FiniteOrdinaryResources, 176 lines. The owner had acquired
102 of those lines before the request. The full body supplies the actual
entered Ready, Stored, Packet, and frame facts for the sibling composition.
The allowance is now three named OLD whole bodies. No fourth whole or
near-whole body is authorized. It may reuse its frozen head/sibling review
and explicitly authorized new Root path bridge outputs, with precise current
hash and check status. Other old reads must be bounded. Do not reconstruct a
further whole body from cuts. Ask Root for a full-read scope change if required.
The owner writes no production files, uses no compiler, evaluator, native job,
Git, network or board tools, and spawns no children. It records acquisitions,
reads its entire draft/report, freezes all files with pins, and stops writes.
Root alone verifies and publishes. All Root compiler checks stay serial at
4 GiB, zero swap and five minutes with strict Lean 4.34.1.

The Git base is currently 26b76c6fd289819222c8f862ada72f8e3c667f65.
Six new sibling-phase production modules are checked locally; publication
is pending the complete Audit/public/preservation/evidence checks. Pin source
bytes rather than assuming a later Git commit. Sibling-phase evidence lives
at /tmp/mcfta-sibling-execution-path-control-20261030. Preserve that evidence.
No Haskell defect or repair is established by this source-only task.
