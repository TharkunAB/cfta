# Original source to actual shared preparation

2026-11-15 01:50 CET. Uncompiled. Root owns validation.

The candidate starts from the same accepted original build and stored universe.
Its only metadata condition is the existing `metadata.pending = []` scope.
It does not take a caller context, prefix success, preparation result, or child result as an input.

The public theorem calls `accepted_first_real_prefix`.
It retains that initializer's field receipt, caller, source inventory and root handle.
It obtains the no-stop decision from `accepted_no_stop_eager_entry`.
The two field receipts prove that both constructors return the same cold cache.
Their encodings prove that both root handles are equal.

`SelectedStep.prefix_checkpoint_complete` fixes the real prefix endpoints above one bound.
The heap, cache and caller remain fixed at each larger work fuel.
Only the stored action may vary.
The candidate uses the existing source-prefix receipt to exclude parked results.
It also identifies the checkpoint's actual parent and native heap.
It does not replace that parent with the original cold root.

The rejected case retains the exact Empty prefix and its derived native Post.
The live case derives all of these results:

- The retained cache carries `Recursive.Packet` at the original inventory.
- The parent is the actual narrowed ordinary node.
- The parent's exact handle reads back in the actual narrowed heap.
- `SelectedPreparation.complete` derives the actual entry and native result.
- The ordinary-node native preparation returns the same parent and heap.
- Its returned Packet and Context use the same original inventory.
- The actual shared eager preparation calls the actual shared row scan.

The candidate enlarges the SAME work fuel for preparation.
It uses the fixed prefix endpoints to retain the earlier cache and caller at that bound.
It does not combine a prefix at one fuel with a cold preparation at another fuel.
At every larger common fuel, the exact prefix and preparation equations remain valid.
The shared-scan equation retains its actual entered Core, framed cache, caller and queries.

For each actual narrowed row, the source narrowing theorem proves original-row membership.
The filter projection then computes the literal own-class allocation and prepared inputs.
The candidate derives the singleton `CachedOwn.prepare` observation.
It also derives the first source goal input and its terminal suspended bucket.
These facts remove the supplied `prepared` and `selected` observations from the first-goal chain.
They do not assert that later sibling rows execute after a preceding stop.

Zero work fuel retains the literal prefix representative-fuel stop.
An Empty original root cannot enter the live branch.
The live branch contains a proof that the original root is nonempty.
The Empty branch also includes pruning of a nonempty original root.
The bound is sufficient and need not be minimal.
Smaller positive budgets retain the literal worker outcomes.

The next missing operation is the actual first shared visitor/child dispatch outcome.
The produced shared scan exposes its row visitor in order.
The derived own preparation exposes the first terminal goal input.
The current candidate does not force child success or identify later descendants with that goal.
It does not prove whole-worker completion, a global source-position theorem, semantic typing,
or denotational intersection from atom closure.
The full original target remains open.

No Haskell source changed. No Haskell fix was identified.

