# ROWS admission for the actual own prefix

2026-11-15 02:39 CET. Uncompiled. Root owns validation.

Root approved the verified combined60 source as the baseline.
Its hash is `8216836f9bf1f78353593b9cb9428685f3b5bcf3c7173582347153630ade5825`.
The earlier Owner53 helper blocks are unchanged in that baseline.

The old ordinary-row producer uses whole `nodeReserved` once.
It projects `reserved.2 attempted.length indexLt` to get the current row reservation.
Its forecast inclusion uses the existing row schedule and monotonicity.
That part does not use node admission.
The selected-own producer uses its child admission only at the ordinary-row producer call.

The new `identity_ordinary_row_prefix_reservation_of_row` takes that row reservation directly.
It keeps the original producer body once.
The old helper remains an exact-header compatibility wrapper.
It derives the row reservation from its original node admission and calls the new helper.

The new `identity_actual_source_selected_own_current_of_rows` takes the existing ROWS admission.
The actual `IdentityActualSourceCurrent` already contains this admission as `.2.2.2`.
The source row counts prove `attempted.length < root.limit`.
The ROWS admission supplies the reservation at that exact ordered index.
The new ordinary-row helper then produces the own cache and inner Current.
The selected-own body is also kept once.
Its old child-admission header remains a compatibility wrapper.
That wrapper drops the unused fallback admission with `admission.2`.

The full ROWS induction can therefore use its actual Current.
It does not need the original child Current or whole original node admission.
The call-site sketch shows that projection.
It is not a new worker premise.

Both old helper headers remain byte-identical.
The packet contains the original header bytes and their hashes.
The transformation changes only those two helper blocks.
It preserves the root, source origin, earlier-row run, ordered attempted rows,
caller and query endpoints, cache, ancestor ledger, continuation, seed, bounds,
heap forecasts, output, and strict work decrease.
It does not enlarge a fuel, heap bound or reservation count.
All original full targets remain unchanged.

This packet does not assemble the ROWS induction or claim the full worker/model theorem.
Root must check the factor and connect the existing ROWS branch.

No live source changed. No compiler, Git or board operation ran.
No Haskell source changed. No Haskell fix was identified.
No file was written under `/tmp`.

