from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import tempfile

root = Path('/home/tritlo/Code/mcfta')
base = root / 'lean/restart-evidence'
control = base / '20261118-retained-source-gate-skip-publication-control-draft'
stage_control = base / '20261118-retained-source-gate-skip-staging-control-draft'
work = base / '20261118-retained-source-gate-skip-work'
runtime = base / '20261118-retained-source-gate-skip-publication'
prior_work = base / '20261117-numerical-source-callbacks-work'
prior_run = base / '20261117-numerical-seed-closure-publication'
prior_archive = base / '20261118-actual-query-sequence-seeds-checkpoint'
source_commit = '1a3de82aec4bab8cc6b21012103e6311a951b266'
assert Path(__file__).resolve().parent == work.resolve()
archive_control = base / '20261118-retained-source-gate-skip-checkpoint-control-draft'
assert Path(__file__).read_bytes() == (archive_control / 'prepare-checkpoint-controls.py').read_bytes()
assert runtime.is_dir(), 'The actual passed publication must exist.'
sha = lambda data: hashlib.sha256(data).hexdigest()
bound = set()

def verify(path, record):
    data = path.read_bytes()
    assert sha(data) == (record['sha256'] if isinstance(record, dict) else record), str(path)
    if isinstance(record, dict) and 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    bound.add(path)
    return data

for name, record in json.loads((control / 'MANIFEST.json').read_text())['files'].items():
    verify(control / name, record)
bound.add(control / 'MANIFEST.json')
for name, record in json.loads((control / 'ACTUAL-INPUT-PINS.json').read_text()).items():
    verify(root / name, record)
for name, record in json.loads((stage_control / 'MANIFEST.json').read_text())['files'].items():
    verify(stage_control / name, record)
bound.add(stage_control / 'MANIFEST.json')
stage_bytes = (work / 'SOURCES-NORMAL-STAGING.json').read_bytes()
assert stage_bytes == (control / 'EXPECTED-STAGE.json').read_bytes()
stage = json.loads(stage_bytes)
assert stage['status'] == 'ACTUALLY STAGED BY ROOT AFTER VERIFIED TERMINAL PASS'
assert stage['source_baseline'] == source_commit and stage['normal_Source_changed'] and not stage['published']
assert (stage['source_files'], stage['audit_imports'], stage['audit_reports'], stage['independent_reports']) == (6279, 5279, 726, 321)
assert (stage['fresh_reports'], stage['inherited_reports'], stage['combined_reports']) == (2, 518, 520)
assert stage['owner_preflight_reports_fresh_this_batch'] == 0 and stage['resource_owner_reports_inherited'] == 264
bound.add(work / 'SOURCES-NORMAL-STAGING.json')
overrides = stage['baseline_overrides']
assert set(overrides) == {'lean/MicroCFTA/Audit.lean', 'lean/MicroCFTA/SourceSynthesisCurrentRootEmptyCheckGate.lean'}

def historical(name, record):
    # Only the Gate owner and Audit changed. Their exact old bytes are past data.
    return verify(root / overrides.get(name, name), record)

private_control = base / stage['private_control']
verify(private_control / 'MANIFEST.json', stage['private_control_manifest_sha256'])
selected_bytes = verify(private_control / 'SELECTION.json', stage['private_selection_sha256'])
assert selected_bytes == (control / 'CHECK-SELECTION.json').read_bytes()
selected = json.loads(selected_bytes)
assert selected['compile_order'] == stage['compile_order'] and len(selected['components']) == 2
private_run = base / stage['private_run']
receipt_path = work / stage['private_verified_receipt']
receipt = json.loads(verify(receipt_path, stage['private_receipt_sha256']))
assert receipt['actual_terminal'] and receipt['actual_terminal_exit'] == 0
assert receipt['actual_session'] == 15994 and receipt['source_baseline'] == source_commit
checked = json.loads(verify(private_run / 'checked.json', receipt['checked_sha256']))
assert json.loads(verify(private_run / 'results.json', receipt['results_sha256'])) == checked
assert receipt['checks'] == checked['checks'] and len(checked['checks']) == 2 and all(checked['passed'])
assert checked['proof_credit'] and checked['both_selected_FIRST_headers_exact']
assert checked['actual_printed_public_axiom_reports'] == 2 and checked['actual_definition_declaration_checks'] == 0
assert checked['limits'] == {'memory.max': '8589934592', 'memory.high': '8589934592', 'memory.swap.max': '0'}
assert [item['name'] for item in checked['checks']] == selected['compile_order']
assert all(item['exit'] == 0 and item['total_axiom_reports'] == 1 and not item['diagnostics']
    and not item['sorryAx'] and not item['nonstandard_axioms'] for item in checked['checks'])
private_pins = json.loads(verify(private_run / 'source-pins.json', receipt['source_pins_sha256']))
assert len(private_pins) == receipt['pins_independently_reverified'] == 6338
for name, record in private_pins.items():
    historical(name, record)
bound.update(private_run / (item['name'] + '.txt') for item in checked['checks'])
baseline_path = work / 'baseline-source-pins.json'
baseline = json.loads(baseline_path.read_text())
assert len(baseline) == 6278
for name, record in baseline.items():
    historical(name, record)
new_source = 'lean/MicroCFTA/SourceSynthesisCurrentRetainedSharedEmptySkip.lean'
assert new_source not in baseline
current = sorted((root / 'lean/MicroCFTA').glob('*.lean'))
assert {str(path.relative_to(root)) for path in current} == set(baseline) | {new_source}
assert len(set(baseline) - set(overrides)) == 6276
# Bind the actual prior Source publication and the pushed immutable checkpoint.
push = json.loads((prior_work / 'PUSH-VERIFIED.json').read_text())
prior_source = json.loads((prior_work / 'SOURCE-COMMIT.json').read_text())
prior_publication = json.loads((prior_work / 'PUBLICATION-VERIFIED.json').read_text())
assert push['source_commit'] == prior_source['source_commit'] == source_commit
assert push['checkpoint_commit'] == push['remote_commit']
assert push['actual_push_terminal'] and push['actual_push_terminal_exit'] == 0
assert push['actual_remote_check_terminal'] and push['actual_remote_check_terminal_exit'] == 0
assert push['postpush_current_tree_verifier_terminal_exit'] == 0
assert prior_source['actual_terminal'] and prior_source['actual_terminal_exit'] == 0
assert prior_publication['actual_terminal'] and prior_publication['actual_terminal_exit'] == 0
assert prior_publication['actual_session'] == prior_source['publication_actual_session'] == 10938
assert [x['total_axiom_reports'] for x in prior_publication['checks']] == [724, 15, 319, 724, 724]
assert prior_publication['combined_reports'] == 518 and prior_publication['resource_reports_inherited'] == 264
verify(prior_archive / 'manifest.json', push['archive_manifest_sha256'])
subprocess.run(['git', 'merge-base', '--is-ancestor', push['checkpoint_commit'], 'HEAD'], cwd=root, check=True)
prior_checked = json.loads((prior_run / 'checked.json').read_text())
assert prior_checked['all_five_gates_passed']
assert (prior_checked['source_files'], prior_checked['independent_reports'], prior_checked['resource_and_component_probes']) == (6278, 319, 518)
for name, digest in json.loads((prior_run / 'source-pins.json').read_text()).items():
    historical(name, digest)
bound.update([prior_work / 'PUSH-VERIFIED.json', prior_work / 'SOURCE-COMMIT.json',
    prior_work / 'PUBLICATION-VERIFIED.json', prior_work / 'PUBLICATION-ACTUAL-RUN.json',
    prior_run / 'checked.json', prior_run / 'source-pins.json', prior_run / 'IndependentProbes.lean',
    prior_archive / 'manifest.json', prior_archive / 'verify.py', prior_archive / 'archived-inputs.json'])
raw_sources = {}
public = b''
for item, original in zip(stage['components'], selected['components']):
    assert all(item[key] == value for key, value in original.items())
    packet = base / item['packet']
    manifest = json.loads(verify(packet / 'MANIFEST.json', item['manifest_sha256']))
    for name, record in manifest['files'].items():
        verify(packet / name, record)
    for name in ['SOURCE-PINS.json', 'DEPENDENCY-PINS.json']:
        if (packet / name).exists():
            for path, record in json.loads((packet / name).read_text()).items():
                historical(path, record)
    raw = verify(root / item['source_path'], {'sha256': item['raw_sha256'], 'bytes': item['raw_bytes']})
    assert raw == (packet / item['source']).read_bytes()
    declarations = raw
    if item['kind'] == 'existing_owner_EOF':
        before = verify(root / item['old_snapshot'], {'sha256': item['owner_sha256'], 'bytes': item['owner_bytes']})
        declarations = verify(packet / item['append'], item['append_sha256'])
        assert raw == before + declarations
    assert b'#print axioms ' not in raw and b'#check ' not in raw
    assert not re.search(rb'set_option\s+(maxHeartbeats|maxRecDepth|warningAsError|linter\.)', declarations)
    assert not re.findall(rb'^private theorem ', declarations, re.M)
    assert not re.findall(rb'^private def ', declarations, re.M)
    header = verify(packet / item['header'], item['header_sha256'])
    start = raw.index(header.splitlines()[0])
    assert raw[start:raw.index(b' := by', start)].rstrip() == header.rstrip()
    probe = verify(packet / item['probe'], item['probe_sha256'])
    assert (private_run / 'source/MicroCFTA' / (item['module'] + '.lean')).read_bytes() == raw + b'\n' + probe
    bound.add(private_run / 'source/MicroCFTA' / (item['module'] + '.lean'))
    raw_sources[item['module']] = raw
    public += probe
assert public == (work / 'PUBLIC-PROBES.lean.txt').read_bytes() == (control / 'EXPECTED-PUBLIC-PROBES.lean.txt').read_bytes()
assert public.count(b'#print axioms ') == 2 and b'#check ' not in public
imports = (work / 'IMPORTS.lean.txt').read_bytes()
assert imports == (control / 'EXPECTED-IMPORTS.lean.txt').read_bytes() and len(imports) == 63
old_audit = verify(root / overrides['lean/MicroCFTA/Audit.lean'], {'sha256': stage['old_audit_sha256'], 'bytes': stage['old_audit_bytes']})
assert old_audit.count(b'#print axioms ') == 724
assert (root / 'lean/MicroCFTA/Audit.lean').read_bytes() == imports + old_audit + b'\n' + public
assert (root / 'lean/MicroCFTA/Audit.lean').read_bytes().count(b'#print axioms ') == 726
assert sum(line.startswith(b'import ') for line in (root / 'lean/MicroCFTA/Audit.lean').read_bytes().splitlines()) == 5279
prior_independent = (prior_run / 'IndependentProbes.lean').read_bytes()
assert prior_independent.count(b'#print axioms ') == 319 and imports not in prior_independent
owner_name = 'lean/MicroCFTA/SourcePruningEnumerationSharedEagerReservation.lean'
owner_sha = sha((root / owner_name).read_bytes())
assert owner_sha == baseline[owner_name]
for name in ['strict-bind.py.txt', 'publication-driver.py.txt', 'shadow-compile.py.txt']:
    ast.parse((control / name).read_text())
normal_objects = root / 'lean/.lake/build/lib/lean/MicroCFTA'
assert normal_objects.is_dir()

import gzip

archive = base / '20261118-retained-source-gate-skip-checkpoint'
board_prefix = 'current-board-retained-source-gate-skip-'
read = lambda path: json.loads(path.read_text())
git = lambda *args: subprocess.check_output(['git', *args], cwd=root)
for name, record in read(archive_control / 'MANIFEST.json')['files'].items():
    verify(archive_control / name, record)
for name, record in read(archive_control / 'SOURCE-PINS.json').items():
    verify(root / name, record)
bindings = read(archive_control / 'prior-bindings.json')
assert bindings['prior_checkpoint'] == push['checkpoint_commit']
source_receipt = read(work / 'SOURCE-COMMIT.json')
code = source_receipt['source_commit']
assert code == 'fc345af6e51dd1e813fed83423f25c3228b78874'
assert source_receipt['parent'] == push['checkpoint_commit']
assert source_receipt['actual_terminal'] and source_receipt['actual_terminal_exit'] == 0
assert source_receipt['private_actual_session'] == receipt['actual_session'] == 15994
assert source_receipt['publication_actual_session'] == 73094
assert source_receipt['both_public_FIRST_headers_exact'] and source_receipt['old_gate_owner_prefix_byte_exact']
assert not source_receipt['joint_finite_completion_proved'] and not source_receipt['haskell_changed']
assert git('rev-parse', 'HEAD').decode().strip() == code
assert git('rev-parse', code + '^').decode().strip() == push['checkpoint_commit']
assert git('branch', '--show-current').decode().strip() == 'formalize'
assert not git('status', '--porcelain', '--untracked-files=no')
changed = {item['source_path'] for item in stage['components']} | {'lean/MicroCFTA/Audit.lean'}
assert len(changed) == 3 and set(source_receipt['files']) == changed
assert set(git('diff', '--name-only', push['checkpoint_commit'], code).decode().splitlines()) == changed
for name in changed:
    assert git('show', code + ':' + name) == (root / name).read_bytes(), name
for name in changed - {new_source}:
    assert git('show', push['checkpoint_commit'] + ':' + name) == (root / overrides[name]).read_bytes(), name
# All three root documents must be unchanged before any archive or document write.
for name in ['NEXT-PROMPT.md', 'HANDOFF.md', 'FINDINGS.md']:
    assert (root / name).read_bytes() == git('show', code + ':' + name), name
report = read(runtime / 'checked.json')
publication = read(work / 'PUBLICATION-VERIFIED.json')
actual = read(work / 'PUBLICATION-ACTUAL-RUN.json')
assert publication['actual_session'] == actual['actual_session'] == 73094
assert publication['actual_terminal'] and publication['actual_terminal_exit'] == 0
assert actual['actual_terminal'] and actual['actual_terminal_exit'] == 0
assert publication['runtime'] == actual['runtime'] == runtime.name
assert publication['checks'] == report['checks']
assert [item['total_axiom_reports'] for item in report['checks']] == [726, 2, 321, 726, 726]
assert [(item['axiom_groups'], item['axiom_free_reports']) for item in report['checks']] == [(720, 6), (2, 0), (318, 3), (720, 6), (720, 6)]
assert all(item['exit'] == 0 and not item['diagnostics'] and not item['sorryAx']
    and not item['nonstandard_axioms'] and item['declaration_checks'] == 0 for item in report['checks'])
assert report['all_five_gates_passed'] and report['source_pins_unchanged']
assert (report['source_files'], report['direct_audit_imports'], report['individual_reports'], report['independent_reports']) == (6279, 5279, 726, 321)
assert (report['fresh_reports'], report['inherited_reports'], report['combined_reports']) == (2, 518, 520)
assert report['new_public_theorems'] == report['new_theorem_declarations'] == 2
assert report['new_private_theorems'] == report['new_prop_definitions'] == 0
assert report['resource_owner_reports_inherited'] == 264 and report['owner_preflight_reports_fresh_this_batch'] == 0
assert report['audited_theorems'] == publication['audited_theorems'] == source_receipt['audited_theorems'] == 100191
assert report['source_retained_available_gate_proved'] and report['actual_shared_enabled_skip_proved']
assert not report['all_original_eager_worker_query_admissions_proved']
assert not report['native_inhabitance_proved'] and not report['joint_finite_completion_proved'] and not report['haskell_changed']
public_pins = read(runtime / 'source-pins.json')
for name, digest in public_pins.items():
    verify(root / name, digest)
assert publication['pins_independently_reverified'] == len(public_pins) == 7859
assert sha((runtime / 'source-pins.json').read_bytes()) == publication['source_pins_sha256']
assert sha((runtime / 'checked.json').read_bytes()) == publication['checked_sha256']
source_pins = {name: digest for name, digest in public_pins.items() if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
assert len(source_pins) == 6279
for name, field in [('manifest.json', 'prior_manifest_sha256'), ('checkpoint.json', 'prior_checkpoint_json_sha256')]:
    data = (prior_archive / name).read_bytes()
    assert sha(data) == bindings[field]
    assert git('show', push['checkpoint_commit'] + ':' + str((prior_archive / name).relative_to(root))) == data
prior_checkpoint_data = read(prior_archive / 'checkpoint.json')
assert prior_checkpoint_data['checked_code'] == bindings['prior_source_commit'] == source_commit
assert prior_checkpoint_data['resource_and_component_probes'] == 518
old_pins = json.loads(gzip.decompress((prior_archive / 'source-pins.json.gz').read_bytes()))
assert baseline == {name: digest for name, digest in old_pins.items() if name.startswith('lean/MicroCFTA/') and name.endswith('.lean')}
for name, digest in old_pins.items():
    historical(name, digest)
for name in ['shell.nix', 'lean/lean-toolchain', 'lean/lakefile.toml', 'lean/lake-manifest.json']:
    assert old_pins[name] == public_pins[name]
request = read(work / (board_prefix + 'request.json'))
canonical = read(work / (board_prefix + 'canonical.json'))
assert canonical['verified']
post = canonical.get('post', canonical)
assert post['id'] == request['request_id']
assert type(post['sequence']) is int and post['sequence'] > 0
for key, expected in [('author', request['username']), ('thread_id', request['thread_id']),
        ('post_type', request['post_type']), ('content', request['content']), ('metadata', request['metadata'])]:
    assert post[key] == expected, key
assert post['metadata']['source'] == code
cleanup = read(work / 'combined-terminal-cleanup-result.json')
assert cleanup['all_owned_terminal_only'] and cleanup['all_current_batch_actual_runs_terminal']
assert cleanup['normal_cache_preserved'] and cleanup['unknown_tmp_entries_preserved']
assert cleanup['no_cache_data_copied'] and not cleanup['live_process_references']
assert not cleanup['process_scan_errors'] and cleanup['all_targets_removed']
actual_runs = [(15994, '20261118-retained-source-gate-skip-check'), (73094, runtime.name)]
assert len(cleanup['removed_targets']) == 2
paths = []
for item, (session, name) in zip(cleanup['removed_targets'], actual_runs):
    assert item['actual_session'] == session and item['runtime'] == name
    assert item['path'] == read(base / name / 'objects.json')['path']
    assert item['owned_terminal_only'] and item['normal_cache_preserved'] and item['unknown_tmp_entries_preserved']
    assert not item['live_process_references'] and not item['process_scan_errors']
    assert not Path(item['path']).exists() and not Path(item['path']).is_symlink()
    paths.append(item['path'])
assert len(set(paths)) == 2
assert cleanup['removed_regular_bytes'] == sum(item['regular_bytes_removed'] for item in cleanup['removed_targets']) == 1135312
assert cleanup['removed_symlinks'] == sum(item['symlinks_removed'] for item in cleanup['removed_targets']) == 12622
assert cleanup['prior_cumulative_removed_bytes'] == 6565688965
assert cleanup['prior_cumulative_removed_bytes'] + cleanup['removed_regular_bytes'] == cleanup['cumulative_removed_bytes'] == 6566824277
assert cleanup['normal_cache_targets'] == 6313 and cleanup['initial_private_cleanup_normal_cache_targets'] == 6312
start = read(work / 'START.json')
assert start['manual_work_explicitly_authorized'] and not start['joint_finite_completion_proved']
assert start['persistent_goal_control_status'] == 'paused'
assert start['expected_checks'] == start['expected_public_reports'] == 2
resume = read(work / 'RESUME-AUTHORIZATION.json')
assert resume['manual_work_explicitly_authorized'] and resume['earlier_usage_pause_lifted']
assert "Keep going. We'll use a reset if needed." in resume['authorizing_instructions']
assert resume['persistent_goal_control_status'] == 'paused'
assert not resume['goal_operation_performed'] and not resume['goal_completion_claimed']
usage = read(work / 'USAGE.json')
percent = usage['rate_limits']['primary']['used_percent']
assert type(percent) in [int, float] and 0 <= percent <= 100
assert usage['current_usage_not_measured'] and usage['earlier_usage_pause_lifted_by_user_resume']
assert percent == 81 and '17:53:' in usage['checked_at']
# The handoff is read when Root executes this controller, after Root finalizes it.
handoff = (work / 'LIVE-HANDOFF.md').read_text()
assert code in handoff and 'open' in handoff.lower()
roots = read(archive_control / 'selection-roots.json')
assert len(roots) == len(set(roots)) == 10
additional = read(archive_control / 'archive-additional-roots.json')
assert len(additional) == 4
for item in additional:
    assert item['current_batch_theorem_credit'] == 0 and not item['private_runtime_selected']
    packet = base / item['root']
    manifest = read(packet / item['manifest'])
    verify(packet / item['manifest'], item['sha256'])
    entries = manifest['files'].items() if isinstance(manifest['files'], dict) else [(entry['file'], entry) for entry in manifest['files']]
    for name, record in entries:
        verify(packet / name, record)
    if (packet / 'SOURCE-PINS.json').exists():
        pin_data = read(packet / 'SOURCE-PINS.json')
        if 'files' in pin_data:
            source_entries = [(entry['file'], entry) for entry in pin_data['files']]
        elif 'pins' in pin_data:
            source_entries = pin_data['pins'].items()
        else:
            source_entries = pin_data.items()
        for name, record in source_entries:
            digest = record['sha256'] if isinstance(record, dict) else record
            current_path = root / name
            if current_path.is_file() and sha(current_path.read_bytes()) == digest:
                verify(current_path, record)
            else:
                historical(name, record)
    roots.append(item['root'])
rejected = read(work / 'NEXT-INCOMING-NAME-PREFLIGHT-REJECTED.json')
repaired = read(work / 'NEXT-INCOMING-NAME-REPAIR-VERIFIED.json')
assert rejected['manifest_sha256'] == '11fae624201cafa5dce65bfd97ed51534e047571357d20921288f4cb3378b75b'
assert repaired['repair_manifest_sha256'] == 'cd47332060205709bc3355e0f2a28b51bdcf68830ce1707c9a1b3aee2e91021f'
assert not rejected['compiler_run'] and not repaired['compiler_run']
assert rejected['theorem_credit'] == repaired['theorem_credit'] == 0
assert repaired['raw_source_byte_exact'] and repaired['existing_owner_byte_exact'] and repaired['new_module_name_available']
original_packet = base / rejected['candidate']
repair_packet = base / repaired['repair_packet']
original_raw = (original_packet / 'SourcePruningEnumerationSharedIncomingQueryResources.lean').read_bytes()
repair_raw = (repair_packet / 'SourcePruningEnumerationSharedIncomingQueryEventResources.lean').read_bytes()
assert original_raw == repair_raw and sha(repair_raw) == repaired['raw_source_sha256']
assert (original_packet / 'FIRST-HEADER.lean.txt').read_bytes() == (repair_packet / 'FIRST-HEADER.lean.txt').read_bytes()
assert not (root / 'lean/MicroCFTA/SourcePruningEnumerationSharedIncomingQueryEventResources.lean').exists()
assert len(roots) == len(set(roots)) == 14
assert prior_archive.name not in roots
assert all((base / name).is_dir() and not (base / name).is_symlink() for name in roots)
assert all('gate-skip' in name or name in {item['packet'] for item in stage['components']}
    or name in {item['root'] for item in additional} for name in roots)
for item in read(archive_control / 'original-header-files.json'):
    assert sha((root / item['path']).read_bytes()) == sha((root / item['original']).read_bytes()) == item['sha256']
selected_roots = sorted(str((base / name).relative_to(root)) for name in roots)
assert not archive.exists()
tree = hashlib.sha256()
for name, digest in sorted(source_pins.items()):
    tree.update(name.encode() + b'\0' + digest.encode() + b'\n')
config = dict(report)
config.update(checked_code=code, prior_checkpoint=push['checkpoint_commit'], public_run=str(runtime), public_gates=5,
    explicit_reports=726, board_prefix=board_prefix, board_post_id=post['id'], board_sequence=post['sequence'],
    source_tree_sha256=tree.hexdigest(), old_other_Source_files_byte_exact=6276,
    old_gate_owner_exact_prefix_bytes=5721, old_audit_contiguous_bytes_preserved=433976, old_audit_exact_offset=63,
    known_cumulative_tmp_removed_bytes=cleanup['cumulative_removed_bytes'],
    cleanup_receipt='combined-terminal-cleanup-result.json', removed_regular_bytes=cleanup['removed_regular_bytes'],
    removed_symlinks=cleanup['removed_symlinks'], historical_primary_usage_percent=percent,
    historical_primary_usage_checked_at=usage['checked_at'], current_usage_not_measured=True,
    prior_immutable_archive=prior_archive.name, prior_manifest_sha256=bindings['prior_manifest_sha256'],
    actual_private_session=15994, actual_publication_session=73094,
    old_usage_pause_reintroduced=False, persistent_goal_control_status='paused',
    work_authorized_by_explicit_user_resume=True, goal_active=False, goal_completion_claimed=False,
    existing_resource_FieldsThrough_observers_exported=True,
    original_per_event_worker_resource_attachment_proved=False,
    original_worker_admissions_proved=False, native_inhabitance_proved=False,
    joint_finite_completion_proved=False, compiled_haskell_correspondence_proved=False, haskell_changed=False,
    additional_frozen_roots=additional, additional_frozen_roots_theorem_credit=0,
    original_incoming_filename_collision_rejected_before_compiler=True,
    incoming_filename_only_repair_preserves_entire_raw_and_FIRST=True,
    future_worker_attachment_runtimes_selected=False)
skipped = sorted(str(path.relative_to(root)) for path in base.iterdir()
    if path.is_dir() and path.name.startswith(('20261117-', '20261118-')) and str(path.relative_to(root)) not in selected_roots)
review = {'selected_roots': 14, 'base_roots': 10, 'additional_frozen_roots': additional,
    'additional_frozen_roots_theorem_credit': 0, 'fresh_public_reports': 2,
    'inherited_reports': 518, 'combined_reports': 520,
    'new_public_theorems': 2, 'new_private_theorems': 0, 'new_theorem_declarations': 2,
    'new_Prop_definitions': 0, 'Prop_declaration_checks': 0, 'Prop_axiom_credit': 0,
    'resource_owner_reports_inherited': 264, 'current_batch_failures_preserved': [],
    'successful_private_and_public_runs_preserved': [15994, 73094],
    'all_root_documents_preserved_as_suffix': True,
    'existing_resource_FieldsThrough_observers_exported': True,
    'future_worker_attachment_runtimes_selected': False, 'joint_finite_completion_proved': False}
note = (archive_control / 'checkpoint-note.md').read_text()
normalized_note = ' '.join(note.lower().split())
assert 'historical' in normalized_note and 'current usage was not measured' in normalized_note
for key, value in {'THEOREMS': report['audited_theorems'], 'REMOVED': cleanup['removed_regular_bytes'],
        'SYMLINKS': cleanup['removed_symlinks'], 'CLEANUP': cleanup['cumulative_removed_bytes'],
        'USAGE': percent, 'BOARD': post['sequence']}.items():
    note = note.replace('{{' + key + '}}', str(value))
assert set(re.findall(r'\{\{(.*?)\}\}', note)) == {'TIME', 'TREE', 'CODE'}
outputs = {'checkpoint-config.json': config, 'archive-roots.json': selected_roots,
    'skipped-published-roots.json': skipped, 'selection-review.json': review}
assert all(not (work / name).exists() for name in outputs)
# No archive or Work write occurs before every preceding guard passes.
for name, value in outputs.items():
    (work / name).write_text(json.dumps(value, indent=2) + '\n')
(work / 'checkpoint-note.md').write_text(note)
print(json.dumps({'checked_code': code, 'archive': archive.name, 'roots': 14,
    'board_sequence': post['sequence'], 'fresh_public_reports': 2, 'inherited_reports': 518,
    'combined_reports': 520, 'current_usage_not_measured': True}))
