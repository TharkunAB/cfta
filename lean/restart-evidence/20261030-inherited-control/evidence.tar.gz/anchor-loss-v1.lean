import MicroCFTA.SourceEqualityInheritedIteration
import MicroCFTA.SourceEqualityNormalizationInitial

namespace MicroCFTA.InheritedAnchorLossProbe
open EqualityNormalize SourceEqualityClassOrder
open SourceEqualityInheritedPayload SourceEqualityNormalizationCarrier

private def ownRaw : Constraints := [[[0], [1, 0, 0]]]
private def seedRaw : Constraints := [[[0, 0], [0, 1]]]
private def combinedRaw : Constraints :=
  [[[0], [1, 0, 0]], [[0, 0], [0, 1], [1, 0, 0, 0], [1, 0, 0, 1]]]
private def original : List Path := ownRaw.flatten ++ seedRaw.flatten
private def ownPayload := recordsOf ownRaw
private def seedPayload := recordsOf seedRaw
private def combinedPayload := recordsOf combinedRaw

private theorem read_own : SourceEqualityPhysicalPayload.read (some ownRaw) = .ok ownPayload := by
  decide +kernel

private theorem read_seed : SourceEqualityPhysicalPayload.read (some seedRaw) = .ok seedPayload := by
  decide +kernel

private theorem wellFormed_of_reference (raw : Constraints) (fuel : Nat)
    (payload : SourceEqualityPrecheck.Constraint)
    (normalized : mkEqConstraints fuel raw = .normalized raw)
    (read : SourceEqualityPhysicalPayload.read (some raw) = .ok payload) :
    SourceEqualityDescend.WellFormed payload := by
  apply read_wellFormed (some raw) ?_ payload read
  intro output same
  cases same
  exact SourceEqualityGuardReadback.normalized normalized

private theorem initial_common : Common 4 original [0, 1] (ownRaw ++ seedRaw) := by
  have included : ∀ path ∈ members (ownRaw ++ seedRaw), path ∈ original := by
    intro path member
    simpa [members, original] using member
  have common := SourceEqualityNormalizationInitial.prepare_common_of_original original included
  convert common using 1 <;> decide +kernel

private theorem not_anchored : ¬ EqualityTermination.Anchored original [[[0, 0, 0], [0, 0, 1]]] := by
  intro anchored
  obtain ⟨path, present, initial⟩ := anchored [[0, 0, 0], [0, 0, 1]] (by simp)
  have selected : path = [0, 0, 0] ∨ path = [0, 0, 1] := by simpa using present
  rcases selected with rfl | rfl <;> simpa [original, ownRaw, seedRaw] using initial

/-- Actual combination and physical descent can lose all original class anchors. -/
theorem payload_anchor_loss :
    Common 4 [[0], [1, 0, 0], [0, 0], [0, 1]] [0, 1]
      [[[0], [1, 0, 0]], [[0, 0], [0, 1]]] ∧
    ∃ own inherited combined : SourceEqualityPrecheck.Constraint,
      SourceEqualityPhysicalPayload.read (some [[[0], [1, 0, 0]]]) = .ok own ∧
      SourceEqualityPhysicalPayload.read (some [[[0, 0], [0, 1]]]) = .ok inherited ∧
      SourceEqualityDescend.WellFormed own ∧ SourceEqualityDescend.WellFormed inherited ∧
      combine inherited own = .ok combined ∧
      classes (SourceEqualityDescend.descend combined 1) = some [[[0, 0, 0], [0, 0, 1]]] ∧
      ¬ EqualityTermination.Anchored [[0], [1, 0, 0], [0, 0], [0, 1]]
        [[[0, 0, 0], [0, 0, 1]]] := by
  refine ⟨initial_common, ownPayload, seedPayload, combinedPayload, read_own, read_seed, ?_, ?_, ?_, ?_, not_anchored⟩
  · exact wellFormed_of_reference ownRaw 1 ownPayload (by decide +kernel) read_own
  · exact wellFormed_of_reference seedRaw 1 seedPayload (by decide +kernel) read_seed
  · apply SourceEqualityInheritedIteration.combineReference_exact 4 seedPayload ownPayload (.ok combinedPayload)
    decide +kernel
  · decide +kernel

end MicroCFTA.InheritedAnchorLossProbe
