# Inherited payload operations and recursive control

Full goal ACTIVE. Read final-documents/lean/notes-current-inherited-control.md.
Audit 4700/82627 and public 1075/89 pass. Four current strict sources match.
Three modules add seven public laws and three definitions. All 498 prior
protected and 835 native inputs match. Current protected baseline is 501.
Completed bounded normalization and payload references equal actual operations.
Two kernel proofs show loss of original anchors and escape of the original
length-20 word carrier after nineteen finite payload combine/descent cycles.
These are not admitted worker traces. Both exact public Haskell fixtures pass.
The shared-constraint fixture forces all returned tree structures and reaches
G fourth. No Haskell source changed. FINDINGS records a conditional SCS repair
candidate and the corrected Node/Mu and separate-descent analysis.
Actual worker/control bounds across all earlier alternatives, higher original
input gates, sufficient resources, whole coverage/order/stops and Haskell
correspondence remain open. Preserve the full goal and optimized interned core.
Retain all twelve failed proof drafts/diagnostics and separate administrative
commit-preflight failures. No failed axiom report is an accepted theorem.
Four owned bundles have 257 verified pins. Source-only alternatives stay marked.
All 33 commands and 94 input snapshots remain. Every regular payload is archived
without filtering. Keep this area immutable. The verifier runs no Lean/Haskell.
