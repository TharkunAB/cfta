import MicroCFTA.SourceEqualityInheritedIteration

open MicroCFTA MicroCFTA.EqualityNormalize MicroCFTA.SourceEqualityClassOrder

example : mkEqConstraints 1 [[[0], [1, 0, 0]]] = .normalized [[[0], [1, 0, 0]]] := by cbv

example : SourceEqualityPhysicalPayload.read (some [[[0], [1, 0, 0]]]) =
    .ok (recordsOf [[[0], [1, 0, 0]]]) := by cbv

example : mkEqConstraints 4 [[[0, 0], [0, 1]], [[0], [1, 0, 0]]] =
    .normalized [[[0], [1, 0, 0]], [[0, 0], [0, 1], [1, 0, 0, 0], [1, 0, 0, 1]]] := by cbv
