
/-- Actual normalized physical readback is finite and derives all inherited representation facts. -/
theorem read_complete (equalities : Option Constraints) (cached : Cached equalities) :
    ∃ payload, SourceEqualityPhysicalPayload.read equalities = .ok payload ∧ WellFormed payload ∧
      ∀ term : Term Symbol, SourceEqualityPrecheck.Sat term payload ↔ Sat term equalities := by
  obtain ⟨payload, built, _, exact⟩ := SourceEqualityPhysicalPayload.complete (Symbol := Symbol) equalities cached
  exact ⟨payload, built, read_wellFormed equalities cached payload built, exact⟩

/-- The actual source combiner uses inherited records first and local records second. -/
noncomputable def combine (inherited own : SourceEqualityPrecheck.Constraint) : Except String SourceEqualityPrecheck.Constraint :=
  SourceEqualityPhysicalPayload.read (SourceCompactGuards.combineEqualities (classes inherited) (classes own))

/-- Source combination derives finite coherent physical output and exact conjunction without an input normal-form premise. -/
theorem combine_complete (inherited own : SourceEqualityPrecheck.Constraint) :
    ∃ combined, combine inherited own = .ok combined ∧ WellFormed combined ∧
      ∀ term : Term Symbol, SourceEqualityPrecheck.Sat term combined ↔
        SourceEqualityPrecheck.Sat term inherited ∧ SourceEqualityPrecheck.Sat term own := by
  obtain ⟨combined, built, valid, exact⟩ := read_complete (Symbol := Symbol)
    (SourceCompactGuards.combineEqualities (classes inherited) (classes own)) (combine_cached _ _)
  refine ⟨combined, built, valid, ?_⟩
  intro term
  exact (exact term).trans ((SourceEqualityPCSGuard.combine_sat _ _ term).trans (and_congr (classes_sat inherited term) (classes_sat own term)))

/-- Every actual completed source combination has the same derived physical invariant and exact meaning. -/
theorem combine_exact {inherited own combined : SourceEqualityPrecheck.Constraint} (done : combine inherited own = .ok combined) :
    WellFormed combined ∧ ∀ term : Term Symbol, SourceEqualityPrecheck.Sat term combined ↔
      SourceEqualityPrecheck.Sat term inherited ∧ SourceEqualityPrecheck.Sat term own := by
  obtain ⟨actual, built, valid, exact⟩ := combine_complete (Symbol := Symbol) inherited own
  have same : actual = combined := Except.ok.inj (built.symm.trans done)
  subst actual
  exact ⟨valid, exact⟩

/-- Completed source combination has exact readback to the existing combined-constraint worker. -/
theorem combine_readback (inherited own : SourceEqualityPrecheck.Constraint) :
    combine inherited own = SourceEqualityPhysicalPayload.read (SymbolicEqualityBridge.resultClasses (SourceEqualityPrecheck.combine inherited own)) := by
  cases inherited with
  | none => rfl
  | some inherited =>
      cases own with
