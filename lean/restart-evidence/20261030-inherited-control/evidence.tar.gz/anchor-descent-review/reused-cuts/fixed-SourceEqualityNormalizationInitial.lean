theorem prepare_common_of_original (original : List EqualityNormalize.Path)
    {classes : Constraints} (included : ∀ path ∈ members classes, path ∈ original) :
    Common (EqualityTrie.pathBudget original) original original.flatten.eraseDups (prepare classes) := by
  refine ⟨?_, ?_, ?_⟩
  · intro path member
    have bound := EqualityTrie.pathBudget_sufficient original path
      (included path (prepared_member_original member))
    exact .short (by simp)
      (by simpa only [List.length_nil, Nat.zero_add] using Nat.le_of_lt bound)
  · intro paths present
    obtain ⟨anchor, inClass, _, _, _⟩ := prepare_active classes paths present
    exact ⟨anchor, inClass,
      included anchor (prepared_member_original ((mem_members _ _).mpr ⟨paths, present, inClass⟩))⟩
  · intro path member index atIndex
    simp only [List.mem_eraseDups, List.mem_flatten]
    exact ⟨path, included path (prepared_member_original member), atIndex⟩
