/-- Source zipWith passes each child the constraints descended through its zero-based position. -/
def walk (call : SourceEqualityPrecheck.Constraint → Value Symbol Guard → NativeState width Symbol Guard → Result width Symbol Guard (Value Symbol Guard) Observation)
    (payload : SourceEqualityPrecheck.Constraint) : Nat → List (Value Symbol Guard) → NativeState width Symbol Guard →
      Result width Symbol Guard (List (Value Symbol Guard)) Observation
  | _, [], state => .done (.ok []) state
  | index, value :: values, state =>
      (call (SourceEqualityDescend.descend payload index) value state).bind fun result middle =>
        (walk call payload (index + 1) values middle).bind fun results after => .done (.ok (result :: results)) after

/-- Actual contradiction skips all recursive calls; other payloads execute the literal indexed traversal. -/
def run (call : SourceEqualityPrecheck.Constraint → Value Symbol Guard → NativeState width Symbol Guard → Result width Symbol Guard (Value Symbol Guard) Observation)
    (payload : SourceEqualityPrecheck.Constraint) (values : List (Value Symbol Guard)) (state : NativeState width Symbol Guard) :
    Result width Symbol Guard (List (Value Symbol Guard)) Observation :=
  match payload with
