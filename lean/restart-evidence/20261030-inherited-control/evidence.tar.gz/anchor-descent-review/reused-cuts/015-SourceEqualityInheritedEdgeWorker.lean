noncomputable def descendants [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)]
    (call : SourceEqualityPrecheck.Constraint → Value Symbol Guard → NativeState width Symbol Guard →
      SourceEqualityInheritedChildren.Result width Symbol Guard (Value Symbol Guard) Observation)
    (edge : EdgeValue Symbol Guard) (inherited : SourceEqualityPrecheck.Constraint) (before : NativeState width Symbol Guard) : Result width Observation :=
  match SourceEqualityPhysicalPayload.own edge.entry.key.constraint with
  | .error message => .done (.error message) before
  | .ok own => match SourceEqualityInheritedPayload.combine inherited own with
    | .error message => .done (.error message) before
    | .ok payload => match SourceEqualityInheritedChildren.run call payload edge.children before with
      | .incomplete observation => .children observation
      | .done (.error message) middle => .done (.error message) middle
      | .done (.ok values) middle =>
          let built := run (makeEdge edge.entry.key.symbol edge.entry.key.constraint values) middle.machine.heap
          .done (.ok built.1) (advanceHeap middle built.2)
