def Common (gap : Nat) (anchors : List (List Nat)) (alphabet : List Nat)
    (classes : Constraints) : Prop :=
  SegmentedState gap classes ∧ Anchored anchors classes ∧ UsesAlphabet alphabet classes
