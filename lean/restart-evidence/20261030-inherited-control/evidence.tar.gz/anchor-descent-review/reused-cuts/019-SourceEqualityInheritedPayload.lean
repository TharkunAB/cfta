namespace MicroCFTA.SourceEqualityInheritedPayload
open Language EqualityNormalize SourceEqualityClassOrder SourceEqualityGuardReadback
open SourceEqualityDescend (WellFormed)

/-- Read the ordered class path sets from a physical constraint, retaining contradiction. -/
def classes (input : SourceEqualityPrecheck.Constraint) : Option Constraints := input.map (List.map Record.paths)

