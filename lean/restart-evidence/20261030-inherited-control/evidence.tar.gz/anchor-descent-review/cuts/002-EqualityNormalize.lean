def descendClass (index : Nat) (paths : Class) : Class := (EqualityTrie.tailsAt index paths).eraseDups

/-- Descend every class and discard classes that no longer impose an equality. -/
def eqConstraintsDescend (index : Nat) (classes : Constraints) : Constraints :=
  prepare (classes.map (descendClass index))

/-- Class descent is exactly the restriction to paths starting at one child. -/
theorem mem_descendClass (index : Nat) (paths : Class) (suffix : Path) :
    suffix ∈ descendClass index paths ↔ index :: suffix ∈ paths := by
  simp [descendClass, EqualityTrie.mem_tailsAt]

/-- Descended constraints express precisely the surviving same-child equality pairs. -/
