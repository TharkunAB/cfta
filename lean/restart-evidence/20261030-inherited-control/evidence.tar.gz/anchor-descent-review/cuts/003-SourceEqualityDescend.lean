theorem record_wellFormed (index : Nat) (original : Record) (coherent : Coherent original) (ascending : Ascending original.trie)
    (output : Record) (found : record index original = some output) :
    Coherent output ∧ Ascending output.trie ∧ Nontrivial output.paths := by
  dsimp only [record] at found
  split at found
  · rename_i kept
    have same : fromTrie (pathTrieDescend original.trie index) = output := Option.some.inj found
    rw [← same]
    have valid := descend_valid original.trie coherent.1 index
    have sorted := descend_ascending original.trie ascending index
    exact ⟨fromTrie_coherent _ valid sorted, sorted, (EqualitySaturation.pathTrieHasAtLeastTwoPaths_nontrivial _ valid).mp kept⟩
  · cases found

/-- Descent preserves the actual physical inherited-payload invariant. -/
theorem descend_wellFormed (input : SourceEqualityPrecheck.Constraint) (wellFormed : WellFormed input) (index : Nat) :
    WellFormed (descend input index) := by
  cases input with
  | none => simp [descend, WellFormed]
  | some originals =>
      cases originals with
      | nil => simp [descend, WellFormed]
      | cons first rest =>
          intro outputs same output member
          have identical : records index (first :: rest) = outputs := Option.some.inj same
          rw [← identical] at member
          obtain ⟨original, included, found⟩ := List.mem_filterMap.mp ((records_perm index (first :: rest)).mem_iff.mp member)
          have valid := wellFormed (first :: rest) rfl original included
          exact record_wellFormed index original valid.1 valid.2.1 output found

