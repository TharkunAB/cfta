
/-- Physical inherited payloads have coherent ascending tries and nontrivial classes. -/
def WellFormed (input : SourceEqualityPrecheck.Constraint) : Prop :=
  ∀ originals, input = some originals → ∀ original ∈ originals,
    Coherent original ∧ Ascending original.trie ∧ Nontrivial original.paths

/-- Ascending valid trie enumeration already has the canonical source path-set order. -/
theorem canonical_fromTrie (trie : Trie) (valid : Valid trie) (ascending : Ascending trie) :
    canonicalClass (fromPathTrie trie) = fromPathTrie trie := by
  have unique := supported_nodup _ (fromPathTrie_supported trie valid)
  have perm : (canonicalClass (fromPathTrie trie)).Perm (fromPathTrie trie) :=
    (List.perm_ext_iff_of_nodup (canonicalClass_nodup _) unique).mpr (fun path => mem_canonicalClass path _)
  exact perm.eq_of_pairwise (fun _ _ _ _ first second => List.le_antisymm first second)
    (canonicalClass_ordered _) ((fromPathTrie_increasing trie ascending).imp (fun before => List.le_of_lt before))

/-- Literal source trie reconstruction derives every physical class field invariant. -/
theorem fromTrie_coherent (trie : Trie) (valid : Valid trie) (ascending : Ascending trie) : Coherent (fromTrie trie) :=
  ⟨valid, canonical_fromTrie trie valid ascending, fun _ => Iff.rfl⟩

/-- Every actual successfully constructed class record has an ascending trie. -/
theorem recordOf_ascending (paths : Class) (output : Record) (built : recordOf paths = some output) : Ascending output.trie := by
  cases found : toPathTrie paths.eraseDups with
  | none => simp [recordOf, found] at built
  | some trie =>
      have same : output = ⟨trie, canonicalClass paths⟩ := by simpa only [recordOf, found, Option.map_some, Option.some.injEq] using built.symm
      rw [same]
      exact build_ascending _ _ _ found

/-- Successful physical payload construction derives ascending tries without an added input contract. -/
theorem recordsOf_ascending (classes : Constraints) (outputs : List Record) (built : recordsOf classes = some outputs) :
    ∀ output ∈ outputs, Ascending output.trie := by
  induction classes generalizing outputs with
  | nil => cases built; simp
  | cons first rest ih =>
      cases head : recordOf first with
      | none => simp [recordsOf, head] at built
      | some output =>
          cases tail : recordsOf rest with
          | none => simp [recordsOf, head, tail] at built
          | some remaining =>
              have same : output :: remaining = outputs := by simpa [recordsOf, head, tail] using built
              subst outputs
              intro current member
              rcases List.mem_cons.mp member with rfl | member
              · exact recordOf_ascending first current head
              · exact ih remaining tail current member

/-- Actual source sorting changes no retained class occurrence. -/
theorem records_perm (index : Nat) (originals : List Record) :
    (records index originals).Perm (originals.filterMap (record index)) := by
  dsimp only [records]
  split
  · simp_all
  · simp_all
  · exact SourceListSort.sortBy_perm _ _

/-- The actual helper returns precisely the same-child suffix pairs of one original class. -/
theorem record_pairs (index : Nat) (original : Record) (coherent : Coherent original) (output : Record)
    (found : record index original = some output) :
    ∀ suffix, suffix ∈ output.paths ↔ index :: suffix ∈ original.paths := by
  dsimp only [record] at found
  split at found
  · have same : fromTrie (pathTrieDescend original.trie index) = output := Option.some.inj found
    rw [← same]
    exact fun suffix => (descend_exact original.trie coherent.1 index suffix).trans (coherent.2.2 _)
  · cases found

/-- Every kept descended record derives coherent fields, ascending maps, and nontrivial suffix paths. -/
theorem record_wellFormed (index : Nat) (original : Record) (coherent : Coherent original) (ascending : Ascending original.trie)
    (output : Record) (found : record index original = some output) :
    Coherent output ∧ Ascending output.trie ∧ Nontrivial output.paths := by
  dsimp only [record] at found
  split at found
