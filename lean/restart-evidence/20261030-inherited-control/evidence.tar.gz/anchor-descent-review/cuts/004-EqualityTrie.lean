
/-- Remove one selected first index and omit every other path. -/
def suffixOf (index : Nat) : Path → Option Path
  | [] => none
  | key :: suffix => if key = index then some suffix else none

/-- One constructor group, in the original path order. -/
def tailsAt (index : Nat) (paths : List Path) : List Path := paths.filterMap (suffixOf index)

/-- Distinct child indices present in the input. -/
def childKeys (paths : List Path) : List Nat :=
  (paths.filterMap List.head?).eraseDups.mergeSort (fun left right => left ≤ right)

/-- A group contains exactly the suffixes selected by its first index. -/
theorem mem_tailsAt (index : Nat) (paths : List Path) (suffix : Path) :
    suffix ∈ tailsAt index paths ↔ index :: suffix ∈ paths := by
  simp only [tailsAt, List.mem_filterMap]
  constructor
  · rintro ⟨path, member, selected⟩
