def Anchored (anchors : List (List Nat)) (classes : Constraints) : Prop :=
  ∀ paths ∈ classes, ∃ path, path ∈ paths ∧ path ∈ anchors
