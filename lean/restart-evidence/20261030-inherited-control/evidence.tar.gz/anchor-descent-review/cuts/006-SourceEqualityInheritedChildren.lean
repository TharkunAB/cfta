  match payload with
  | none => .done (.ok (values.map (fun _ => .empty))) state
  | some records => walk call (some records) 0 values state

/-- Every completed indexed graph keeps the exact recursive call receipt and next native state. -/
inductive Walk (call : SourceEqualityPrecheck.Constraint → Value Symbol Guard → NativeState width Symbol Guard → Result width Symbol Guard (Value Symbol Guard) Observation)
    (payload : SourceEqualityPrecheck.Constraint) : Nat → List (Value Symbol Guard) → NativeState width Symbol Guard →
