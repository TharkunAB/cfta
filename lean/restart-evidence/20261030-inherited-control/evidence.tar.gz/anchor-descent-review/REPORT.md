# Anchor loss under inherited combination and indexed descent

Status: source-only mathematical review. The Lean draft is uncompiled.
Timestamp: 2026-10-30 03:29 CET.

The proposed recurrence is mathematically feasible. The same original own equality can generate longer inherited paths after child-one descent. Descent discards the class that carried the original anchor. Thus Common with the same original anchor list does not follow from Common before descent. This is a payload-level mathematical obstruction. It is not an admitted native execution or a runtime defect.

## Exact source operations

SourceEqualityInheritedPayload.combine uses inherited records FIRST and own records SECOND. It reads their path classes, applies combineEqualities, and constructs physical records from the result. The relevant actual normalization order is therefore inherited ++ own. The reverse order should not be substituted without its own actual equation or an existing agreement theorem.

SourceEqualityDescend.record descends the physical trie at the selected child. It keeps a record only when pathTrieHasAtLeastTwoPaths returns true. Its fromTrie constructor reads the resulting path set. records filters these optional results and sorts the retained records, with exact empty and singleton shortcuts. The physical operation performs no further normalization.

The existing record_pairs theorem describes each actually retained coherent record by the exact indexed suffix biconditional. record_wellFormed and descend_wellFormed preserve coherence, ascending tries, and nontriviality. They do not preserve a common original anchor list or segmentation gap.

SourceEqualityInheritedEdgeWorker.descendants obtains the current edge's own equality, combines it with inherited input, and calls InheritedChildren.run on the combined payload. The child traversal starts at index zero and runs earlier children before later children. Child one is reached only after child zero completes. On successful rebuild, the worker uses the original edge.entry.key.constraint. It does not replace that stored own guard with the inherited payload.

The list-level eqConstraintsDescend operation is also explicit: it maps descendClass, then calls prepare to discard trivial classes. It is useful for the small mathematical witness. It is not silently identified with physical record descent in this report.

## Original seed and recurrence

Write 0^n for n repeated zero indices. For n at least one, use:

```
C1 = {0, 100}
Pn = {0^n2, 0^n3}
Hn = Pn union {1 0^(n+1)2, 1 0^(n+1)3}
```

The expected canonical normalization of either operand order is C1 together with Hn. Inherited-first is the order required by the actual combine helper.

For C1, recorded extensions of base0 supply exactly the two suffixes 0^(n-1)2 and 0^(n-1)3. Extending its replacement100 produces the two new Hn paths. Completion joins these generated pairs through the existing Pn class. In Hn there is no strict recorded extension of an Hn member: its two zero-prefix paths differ at their last index, its two one-prefix paths differ at their last index, and the two groups start at different indices. Repeating congruence generation adds only pairs already contained in Hn. Neither C1 nor Hn contains a strict-prefix pair within its own class. Thus there is one strict congruence step and then a fixed point at the class-set level.

Descend at child1. C1 leaves only path00, so its physical record is discarded. Hn leaves exactly the two paths of P(n+1), so that record remains. This gives the candidate inherited recurrence. The source normalization equations, physical readback equations, and all caller gates still need their own checked proofs. This owner did not evaluate those equations.

## Smaller binary witness

The delimiter indices2 and3 are not required. The binary seed has smaller arity and smaller computed word domains:

```
C1 = {0, 100}
B0 = {00, 01}
Bk = {0^(k+1)0, 0^(k+1)1}
Ek = Bk union {1 0 p | p in Bk}
```

For every k at least zero, the same class-set argument predicts normalized classes C1 and Ek. Child1 drops C1's singleton00 and turns Ek into B(k+1). The alphabet remains exactly within {0,1}. Each surviving path gains one index.

The own replacement100 is minimal for this form of positive length growth. A replacement10 followed by child1 descent would add no net index. More generally, replacing initial0 by 1 followed by r zeros and then descending child1 adds r minus one zeros. The given replacement has r=2.

## Immediate Common failure and finite-bound distinction

Use the original path list I = [0,100,00,01]. Its path budget is4, its flattened alphabet is{0,1}, and its length is4. Both initial classes have the computed Common certificate. The expected first normal form has classes C1 and {00,01,1000,1001}.

After child1 descent, the only surviving class is B1={000,001}. Neither path belongs to I. Therefore Anchored I [B1] is false. Common g I A [B1] is false for every choice of g and A, because Common includes that anchor predicate.

This first failure does NOT refute the finite word carrier itself. The initial bound is4*(4+1)=20, and B1 still lies within that length bound. To leave the word carrier, the full recurrence must continue. Bk has paths of length k+2. At k=19 the length is21. An abstract family of these classes is not contained in any fixed finite word-length bound, and a fixed finite anchor list cannot meet every later class. Actual repeated execution remains a separate admission obligation.

The failure does not contradict the checked normalize_append_carrier theorem. That theorem preserves Common through normalization when its operands already carry the same certificates. Indexed descent is a different operation and removes anchors. It also does not contradict the fixed projected-guard carrier: that earlier statement explicitly excludes physical inherited payloads.

## Finite satisfying terms

The recurrence does not rely on a local contradiction. Binary models can satisfy C1 and Bk for each k. Let L be a leaf and B be a binary constructor. A full binary tree u of depth k+1 has equal leaves at both fork paths after its outer placement. The term Node[u,Node[Node[u,L],L]] satisfies C1 and the corresponding binary fork class.

There are also finite terms that satisfy the same own equality at every node of an arbitrarily long finite right spine. Let a0=B(L,L), and a(k+1)=B(ak,L). For a fixed finite N, set vN=Stop(aN,L). For k<N, set vk=Rec(ak,v(k+1)). Then vk@0=ak and vk@100=v(k+1)@00=ak, so every Rec node satisfies C1. At vk the propagated Bk fork paths lead to the two equal leaves of a0.

This suggests the semantic grammar S=L|B(S,S) and R=Stop(S,S)[Top]|Rec(S,R)[C1]. Stop and Rec use distinct symbols. This avoids having a top alternative with the same constructor symbol trivially cover the recursive alternative. The grammar is only a source/input candidate here. No encoded native graph or admitted native run has been verified by this owner.

## Draft and actionable theorem target

BinaryAnchorDescent-UNTESTED.lean has107 lines,4545 bytes, and SHA256 `281c5658929a85d59ed246e8332296074a8e3c7fcee71b8ac69fec8481954241`. It contains complete source-only proof drafts for initial computed Common, concrete list-level indexed descent, immediate anchor/Common failure, family path length, the generic lifted suffix, and the abstract family's failure of fixed anchor/word-length bounds. It contains no normalization equation and no native admission theorem. It uses no placeholder, custom axiom, or linter suppression. The bounded decide +kernel tactic appears only as source text; this owner did not execute it.

A useful generic ACTUAL-PAYLOAD theorem would take k and actual successful PhysicalPayload.read observations for some[Bk] and some[C1]. It would derive an actual combined payload from InheritedPayload.combine inherited own, and prove:

```
InheritedPayload.classes (SourceEqualityDescend.descend combined 1)
  = some [B(k+1)]
```

The theorem must prove the actual successful normalization equation and canonical output order. It must then prove the physical readback, validity/coherence, singleton drop, retained two-path test, and resulting singleton-record ordering. None of those output facts should be taken as a future worker or resource supplier. Input read observations are local constructor observations, and their existence can be derived from the class admission.

For native execution, further gates remain: construct the actual finite graph and seed; show its cached own equality remains C1 at the selected recursive edges; prove native precheck and query effects preserve the required row; complete earlier child0 work; and discharge the actual memo, repeated-handle, Mu, fuel, and stop behavior. An abstract path recurrence does not establish that those gates allow every iteration. In particular, repeated-key or recursion boundaries can return partial completion. This report claims no native counterexample, global coverage failure, or runtime defect. No Haskell fix or defect was identified.

## Provenance and write halt

Six new bounded cuts and nine reused frozen cuts are recorded with complete source/copy bytes, SHA256 values, and exact requested/actual endpoints. All identities and literal cuts were rechecked. No whole old source was acquired. SourceEqualityDescend has a combined1–131/167-line scope, which is honestly charged as one near-whole old-source acquisition. Other old scopes are smaller; the largest is46/119 lines of InheritedPayload. This remains within the two-source limit. The initial/Common helpers were reused as exact small cuts from their frozen sources.

One symbol-discovery command named nonexistent EqualityChildProjection.lean and returned exit2. Its 142-line, approximately4642-token declaration output exceeded a3500-token display limit. The exact full declaration output and missing-path diagnostic were recovered to separate files. The relevant list-descent definitions were found in EqualityNormalize780–791 and acquired exactly. No proof display was truncated. No requested/actual endpoint overrun occurred. Source scopes that begin or end inside unrelated declarations remain explicit.

This owner ran no Lean/compiler, evaluator, native, Git, network, board, or subagent command. All writes are in this owned directory. The repository and all prior frozen bundles remain unchanged. The bundle is sealed with a write halt. Root owns equation checks, integration, compilation, and any later operational claim.
