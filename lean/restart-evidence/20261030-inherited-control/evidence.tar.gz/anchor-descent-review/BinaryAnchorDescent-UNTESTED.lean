import MicroCFTA.SourceEqualityNormalizationInitial
import MicroCFTA.SourceEqualityDescend

/-!
# List-level anchor loss under indexed descent

This source-only draft has not been compiled.
It does not prove a concrete normalization equation or a native caller admission.
-/
namespace MicroCFTA.BinaryAnchorDescentReview
open EqualityNormalize EqualityTermination SourceEqualityNormalizationCarrier

def ownClass : Class := [[0], [1, 0, 0]]

def branch : Nat → Nat → EqualityNormalize.Path
  | 0, last => [0, last]
  | count + 1, last => 0 :: branch count last

def fork (count : Nat) : Class := [branch count 0, branch count 1]

def expanded (count : Nat) : Class :=
  fork count ++ (fork count).map (fun path => 1 :: 0 :: path)

def originalPaths : List EqualityNormalize.Path := ownClass ++ fork 0

/-- The original two classes have the computed common certificates. -/
theorem initial_common :
    Common (EqualityTrie.pathBudget originalPaths) originalPaths
      originalPaths.flatten.eraseDups [ownClass, fork 0] := by
  have included : ∀ path ∈ members [ownClass, fork 0], path ∈ originalPaths := by
    intro path member
    simpa [members, originalPaths] using member
  have common := SourceEqualityNormalizationInitial.prepare_common_of_original originalPaths included
  simpa [prepare, nontrivialB, ownClass, fork, branch] using common

/-- Indexed list descent drops the singleton own class and keeps both new suffixes. -/
theorem concrete_indexed_descent :
    eqConstraintsDescend 1 [ownClass, expanded 0] = [fork 1] := by
  decide +kernel

/-- The first surviving class contains no path from the original anchor list. -/
theorem next_not_anchored : ¬ Anchored originalPaths [fork 1] := by
  intro anchored
  obtain ⟨path, present, original⟩ := anchored (fork 1) (by simp)
  have selected : path = [0, 0, 0] ∨ path = [0, 0, 1] := by
    simpa [fork, branch] using present
  rcases selected with rfl | rfl
  · simpa [originalPaths, ownClass, fork, branch] using original
  · simpa [originalPaths, ownClass, fork, branch] using original

/-- No gap or alphabet repairs the lost original-anchor certificate. -/
theorem next_not_common (gap : Nat) (alphabet : List Nat) :
    ¬ Common gap originalPaths alphabet [fork 1] := by
  intro common
  exact next_not_anchored common.2.1

/-- The actual list-level indexed projection breaks the original anchor predicate. -/
theorem concrete_projection_breaks_anchors :
    ¬ Anchored originalPaths (eqConstraintsDescend 1 [ownClass, expanded 0]) := by
  rw [concrete_indexed_descent]
  exact next_not_anchored

/-- Every family successor adds exactly one child index. -/
theorem branch_length (count last : Nat) : (branch count last).length = count + 2 := by
  induction count with
  | zero => rfl
  | succ count ih =>
      simp only [branch, List.length_cons, ih]
      omega

/-- The original fork has no child-one path. -/
theorem branch_misses_child_one (count last : Nat) :
    EqualityTrie.suffixOf 1 (branch count last) = none := by
  cases count <;> rfl

/-- Each generated path descends to the next longer fork path. -/
theorem lifted_branch_descends (count last : Nat) :
    EqualityTrie.suffixOf 1 (1 :: 0 :: branch count last) = some (branch (count + 1) last) := by
  rfl

/-- A fixed finite anchor list cannot meet every longer family member. -/
theorem fork_not_anchored_of_long (anchors : List EqualityNormalize.Path) (count : Nat)
    (long : EqualityTrie.pathBudget anchors ≤ count + 2) :
    ¬ Anchored anchors [fork count] := by
  intro anchored
  obtain ⟨path, present, original⟩ := anchored (fork count) (by simp)
  have length : path.length = count + 2 := by
    have selected : path = branch count 0 ∨ path = branch count 1 := by
      simpa [fork] using present
    rcases selected with rfl | rfl
    · exact branch_length count 0
    · exact branch_length count 1
  have short := EqualityTrie.pathBudget_sufficient anchors path original
  omega

/-- No fixed finite word-length bound contains the whole abstract family. -/
theorem fork_not_within_short (alphabet : List Nat) (bound count : Nat)
    (long : bound < count + 2) : ¬ EqualitySaturation.Within (words alphabet bound) [fork count] := by
  intro included
  have present : branch count 0 ∈ members [fork count] :=
    (mem_members _ _).mpr ⟨fork count, by simp, by simp [fork]⟩
  have short := ((words_correct alphabet bound (branch count 0)).mp
    (included (branch count 0) present)).1
  rw [branch_length] at short
  omega

end MicroCFTA.BinaryAnchorDescentReview
