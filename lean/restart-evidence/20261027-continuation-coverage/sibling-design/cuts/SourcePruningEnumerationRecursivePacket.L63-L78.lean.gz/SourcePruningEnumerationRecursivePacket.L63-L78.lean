theorem receipt_packet (originalCore : Core) (target : Nat) (fragment : Fragments.Fragment Symbol)
    (after : Cached) (level : Nat → Nat) (frontier : Nat)
    (context : Context formulas solver inventory caller memos)
    (admitted : SourcePruningEnumerationNativeBranchCompletion.Admitted target
      (.complete fragment caller memos.query after))
    (history : SourcePruningEnumerationNativeBranchCompletion.FragmentHistory originalCore
      (.complete fragment caller memos.query after))
    (pending : EnumerationReferences.PendingReferences after.core)
    (ordered : EnumerationOrder.Stratified originalCore level frontier)
    (bounded : ∀ group ∈ metadata.pending, SourcePruningPartialMatch.PendingBound originalCore.counter group) :
    Packet formulas solver inventory caller memos metadata after := by
  obtain ⟨nextLevel, afterOrder⟩ := history.2.2 level frontier ordered
  refine ⟨context, admitted.2.1, pending, admitted.1, ⟨nextLevel, frontier + 1, afterOrder⟩, ?_⟩
  intro group member entry listed
  exact Nat.lt_of_lt_of_le (bounded group member entry listed) history.1

