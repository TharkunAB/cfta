# Actual current-domain diagonal composition

Status: READ/REUSE audit. No theorem in this packet was compiled. Proposed headers have no proof credit. This packet changes no source or prior packet.

## Result

The shortest normalized path is:

```
U/R at D
  enter d at the ACTUAL current cache
B/R at actual D+d
  right-reference read of the full original U
B/U at the SAME actual D+d handle
  rightMu; enter e at the ACTUAL current cache
B/B at an actual domain with key D+d+e
  ordered row product, replacing original R by cutoff d
open product X with X.free = [intersection d]
  optional e is unused because e != d
SAME X at the exact returned state
  outer optional d recloses X to the full original stored U
```

Here U is `.mu entry body depth ordinary`, R is `.reference (.interned entry.identity)`, u is `entry.identity`, b is the original body entry identity, d is `pair u u`, and e is `pair b u`. D is the original literal entry of U/full original P. The old and actual caches must remain distinct.

For this diagonal path the OLD global Top row law is sufficient for the row results. R/R at the terminal key is literally pure cutoff d. Closed markers satisfy its closed-self clause. The selected nonterminal UR/RR clauses in ReferenceTopRow are needed by the other, body-first path; they are unnecessary for these terminal diagonal rows.

There are two separate missing adapters. The small structural adapter admits ANY actual handle with the same terminal key. The material semantic adapter produces the open B/B node result, including ready node-cache hits. The existing global Top node law has only closed-self and pure clauses. It does not state the open B/B product shape.

## Domain identity boundary

`SourceRecursiveIntersectionSchedule.entered_key` proves the returned structural key for any valid current cache. Apply it to the actual current cache and to the source's synthetic terminal cache. Transitivity gives key equality.

It does not give equality of interned domain handles. `Environment.enter` calls `IntersectionEmptyDomain.make`, which allocates a nonempty domain from the current cache supply. If another key is allocated first, two independent valid caches can assign different handles to the same key. The source's let-bound terminal allocation is not an actual execution receipt by itself.

Exact handle replay is available when the particular earlier allocation really precedes the later cache:

```lean
SourceRecursiveIntersectionKernel.make_domain_replay
  (before after : Cache.State DomainKey) (key : DomainKey)
  (valid : Cache.Valid before)
  (growth : Cache.Extends (IntersectionEmptyDomain.make before key).2.table after.table) :
  IntersectionEmptyDomain.make after key =
    ((IntersectionEmptyDomain.make before key).1, after)
```

The required extension begins AFTER that exact allocation. Growth from the original cache before the allocation is insufficient. An actual checked Trace supplies `Extension.domains` for its real prefixes through `checked_trace_extension`. `enter_prefix_common_operands` also gives the actual entered Domain at the continuation. These APIs do not certify a synthetic allocation which never occurred.

A second exact route uses two representations in one valid current cache. Transport an actual earlier `Represents` with `SourceRecursiveIntersectionDomainAllocation.represents_mono` or `Domain.grows`. Then `IntersectionEmptyDomain.identity_exact` turns equal keys into equal identities. The key equality plus identity equality gives the full Interned equality; `NodeRequest.components` or `EdgeRequest.components` then gives exact request equality. Both representation premises must have genuine producers.

`entered_domain_equivalent` and `run_domain_equivalent` concern the kernel schedule's semantic execution. They do not identify native request values, memo keys, cells, or handles.

Do not rewrite an arbitrary `compileNode` value using only equal domain keys. Non-pure branches capture the full domain handle in child requests. For a selected repeated branch the output is pure and the handle disappears. The structural adapter below proves that specific fact and does not need general compiler congruence.

## Minimal structural adapter

The following is the complete proposed header. Every input binder is copied byte-for-byte from the public diagonal adapter. The conclusion quantifies over the actual handle. No availability, result, model, cache-history, or child-law supplier is added.

```lean
theorem current_stored_universe_diagonal_shortcut_inputs_at_same_key
    [DecidableEq Symbol] [DecidableEq (EdgeKey Symbol Guard)] {width : Nat}
    (lib : Library) (query : Query) (signed : Int) (whole : Expression)
    (accepted : SourceSynthesisCurrentConstruction.firstOrderRaw lib query signed = .ok whole)
    (rootValue : Value Symbol Guard) (sourceHeap : InternedConstructorTemplates.State Symbol Guard)
    (built : InternedFreshOrdinaryConstruction.build (ordinarySymbols whole) [] empty =
      .done rootValue sourceHeap)
    (key : NodeKey) (entry : Interned NodeKey) (body depth ordinary : Value Symbol Guard)
    (stored : sourceHeap.nodeRecords key = some (.mu entry body depth ordinary))
    (heap : InternedConstructorTemplates.State Symbol Guard) (facts : Facts heap) (growth : Grows sourceHeap heap)
    (domains : Cache.State IntersectionFlatMemoKeyDomain.DomainKey) (cacheValid : Cache.Valid domains)
    (pattern : Value Symbol Guard) (_patternAvailable : Available heap pattern)
    (_patternClosed : pattern.free = []) (patternId : Nat)
    (_patternIdentity : identity pattern = some patternId)
    (_patternKind : tag pattern = 1 ∨ tag pattern = 3) :
    ∃ (bodyEntry : Interned NodeKey) (bodyRows : List (EdgeValue Symbol Guard)),
      body = .node bodyEntry bodyRows 0 [.interned entry.identity] ∧
      let universeValue : Value Symbol Guard := .mu entry body depth ordinary
      let referenceValue : Value Symbol Guard := .reference (.interned entry.identity)
      let original := SourceRecursiveIntersectionEnvironment.enter domains IntersectionEmptyDomain.emptyKey
        universeValue pattern entry.identity patternId
      let diagonalFirst := SourceRecursiveIntersectionEnvironment.enter original.2 original.1.key
        universeValue referenceValue entry.identity entry.identity
      let diagonalTerminal := SourceRecursiveIntersectionEnvironment.enter diagonalFirst.2 diagonalFirst.1.key
        body universeValue bodyEntry.identity entry.identity
      ∀ (actualDomain : Interned IntersectionFlatMemoKeyDomain.DomainKey),
        actualDomain.key = diagonalTerminal.1.key →
        ∀ row ∈ bodyRows,
          All₂ (fun (children : Value Symbol Guard × Value Symbol Guard) (value : Value Symbol Guard) =>
            SourceCurrentAllocatedNativeTopRowQueryGlobalLaws.KnownResult
              ⟨actualDomain, children.1, children.2⟩ value)
            (row.children.zip row.children)
            (row.children.map (input (replacement (.interned entry.identity)
              (repeatedValue (pair entry.identity entry.identity)))))
```

Proof route: reuse AuxiliaryCutoffQueries to identify the original body rows and historical R/R repeated(d) decision. Reuse BodyChildClassification and the equation for the same body to identify all original row lists. For a literal R, rewrite only the `decision actualDomain.key R R` expression by the key equation, then compile that selected branch to pure cutoff d. For a closed marker, use the existing closed-self KnownResult clause and `input_closed`. Induct over the literal child list to retain its self-zip, map, order, and every duplicate occurrence.

No actualDomain representation or current cache validity is needed for this structural conclusion. An actual query still gets readiness and key safety from the original InputsThrough plan and its genuine prefix.

The same handle distinction applies one level earlier. SourceDiagonalFirstBodyReferenceRead currently selects the literal historical D+d handle. An actual outer d entry can also return a different handle with that key. Its key-aware structural/read adapter must retain the SAME full source premise block and derive:

```
For every actualDd with actualDd.key = historicalDd.1.key:
  u belongs to names actualDd.key,
  e does not belong to actualDd.key.seen,
  decision actualDd.key B R = rightReference,
  compileNode <actualDd,B,R> = compileReference actualDd u B false,
  for every actual current with Facts current.heap and Grows COLD sourceHeap current.heap:
    read current.heap u = some FULL original U,
    step (code (compileNode <actualDd,B,R>)) current
      = yielded (code (requestNode actualDd B U)) current.
```

This transports the selected decision, binding names, and original stored read. It recompiles at the actualDd handle. It never rewrites the full request to the historical one. The current right-read producer already contains the required source freshness proof and actual read proof; factor or reuse those arguments rather than introduce a domain-history premise. The exact abstract-domain read-step pattern is already present privately in both source reference-read modules.

A useful companion source selection fact is:

```
For the SAME complete source premises and original body:
  decision actualDd.key B U = rightMu,
  compileNode <actualDd,B,U> = compileMu actualDd B U,
  for every current cache with Cache.Valid current,
    let actualTerminal = enter current actualDd.key B U b u;
    actualTerminal.1.key = historicalDde.1.key,
    decision actualTerminal.1.key B B = ordinary,
    compileNode <actualTerminal.1,B,B> =
      compileRows actualTerminal.1 bodyRows bodyRows.
```

`actualDd.key = historicalDd.1.key` suffices. B/U has the same identity pair e as B/R. The source right-read producer proves e is fresh at the diagonal-first key. For B/B, b!=u excludes `(b,b)` from d, e, and the original `(u,patternId)` pair. B is open with free list `[interned u]`, so reset and closed-self do not intercept ordinary B/B. These are literal control facts, not semantic child results. The source read producer's body/P read-identity argument already deals with the retained original pair; do not silently drop that original entry.

## Minimal raw open-product rule

Retain the complete source input context from the structural header, including the full original P and original stored body/depth/ordinary values. Choose the SAME original `bodyEntry`, `bodyRows`, and body equation. Let actualDomain have key equal to historical D+d+e, let `request = <actualDomain,B,B>`, and let `rewrite = input (replacement (interned u) (repeatedValue d))`. These are displayed abbreviations, not new parameters or predicates.

The exact proposed raw-rule inputs and conclusion are:

```lean
(original before after : Checked width)
(parentFuel bodySteps : Nat) (result : Value Symbol Guard)
(finishNext : Value Symbol Guard → Code Symbol Guard (Value Symbol Guard))
(physical : Physical original.native)
(sourceGrowth : Grows sourceHeap original.native.machine.heap)
(operationsValid : SourceEqualityConstraintMemoAllocation.Valid original.operations)
(plan : InputsThrough parentFuel (.code (.node request .pure)) original)
(fields : FieldsThrough parentFuel (.code (.node request .pure)) original)
(entered : Steps 1 (.code (.node request .pure)) original
  (.code ((compileNode request).bind finishNext)) before)
(smaller : bodySteps < parentFuel)
(actual : Steps bodySteps (.code (compileNode request)) before (.code (.pure result)) after)
(edges : ∀ (child : EdgeRequest Symbol Guard)
  (childNext : EdgeValue Symbol Guard → Code Symbol Guard (Value Symbol Guard))
  (childBefore childAfter : Checked width) (used count : Nat)
  (childValue : EdgeValue Symbol Guard),
  0 < used → used + count ≤ parentFuel →
  Steps used (.code (.node request .pure)) original
    (.code ((requestEdge child.domain child.left child.right).bind childNext)) childBefore →
  Steps count (.code (requestEdge child.domain child.left child.right)) childBefore
    (.code (.pure childValue)) childAfter →
  SourceCurrentAllocatedNativeTopRowQueryGlobalLaws.EdgeResult child childValue) :
∃ (productEntry : Interned NodeKey) (products : List (EdgeValue Symbol Guard)),
  result = .node productEntry (canonicalEdges products) 0
    [.intersection d.1 d.2] ∧
  All₂ (fun (source : EdgeValue Symbol Guard) target =>
    target.children = source.children.map rewrite ∧
    target.entry.key = ⟨source.entry.key.symbol,
      (source.children.map rewrite).map Value.referenceOf, top⟩)
    bodyRows products ∧
  Physical after.native ∧
  Extension original.native.machine after.native.machine ∧
  Available after.native.machine.heap result ∧
  (∀ row ∈ products, EdgeResident after.native.machine.heap row) ∧
  SourceRecursiveIntersectionMaybeMu.maybeMu d result after.native.machine.heap =
    .done U after.native.machine.heap ∧
  SourceEqualityNativeDemand.step (.code (.optionalBinder d result .pure)) after =
    .yielded (.code (.pure U)) after
```

The `edges` input is the existing genuine smaller-query callback of SourceQueryInduction, scoped to this exact parent execution. It is not a supplied future result law. The new source instantiation must obtain it from its strong-fuel IH. It gives row results for warm ready hits and evaluated children at their actual endpoints. It retains the original strict outer fuel decrease and captured finish continuation.

Reuse `prefix_operations_before_bind` to derive Physical, source growth, Operations.Valid, and bound/unbound plans at the actual first state. Derive the physical raw body Trace from the ORIGINAL InputsThrough and the raw Steps. Rewrite only the actual B/B compiler to compileRows. Lift each row prefix with the real `finishNext` to the original parent query. Apply the edge callback at the SAME raw count; no recursive IH receives an extra pure-observation step.

The existing `current_open_body_product_of_smaller_queries` then supplies the exact product shape, original ordered readback, availability, residency, constructor endpoint, and reclosure. Its local execute premise can use `trace_done (bodySteps)` at fuel `bodySteps+1`. This is a local observation of the existing raw trace, not a call to the global IH at a larger budget. Each edge query's local `count+1` observation must similarly stay local; its IH is invoked at the actual raw count and lifted original prefix.

Do not reduce this to row membership or a canonical-set equality alone. Reclosure uses the exact full-key readback, singleton free metadata, residency, and complete original U record. The existing product theorem already retains the full constructor endpoint with rawRows/middle/count; preserve those receipts in an implementation wrapper instead of discarding or reconstructing them.

## Query and Mu composition boundary

The existing product theorem already proves the conditional product shape under genuine smaller edge laws. The missing raw wrapper connects those callbacks to the ORIGINAL node-query prefix and budget; it must not be counted as a newly proved product theorem in this audit.

The raw rule alone does not prove the B/B QUERY law at a warm ready node cell. `node_query_result_of_body_induction` has a separate prior Returned premise for that case. Current global Top/ReferenceTop histories do not contain the open-product shape as a node result clause. Add that concrete source-qualified implication to the SAME existing node law and prove it from empty whole memo state with SourceQueryInduction. Keep the edge law's existing TopRowResult and mismatch clauses. Qualify B/B by its full original body operands and terminal structural key, or instantiate one actual selected terminal handle with genuine common-cache representations; do not infer request equality from keys alone. This is a source-specific law extension, not a new cache framework or future model supplier.

At B/U, reuse `MuSource.enter_prefix` (it is orientation-neutral) with identities b,u. Split the actual trace with `steps_bind_inverse`. The child is the actual B/B request at the returned handle. Its product-shape clause gives free list `[intersection d]`. Since b!=u, e!=d. Apply `MaybeMu.unused e result`, retain the exact one-step optional-binder state, and use pure-trace determinism for the complete returned endpoint. `left_mu_cutoff_trace_result` cannot be applied unchanged: its selected branch is leftMu and it requires a literal-pure child equation; this child is an open ordinary product and the selected branch is rightMu. Reuse its split/count proof pattern, not its stronger premises.

At B/R, reuse the source right-read equation and `RawReferenceReplay.reference_trace_result_of_actual_read`; its generic raw callback can return the SAME product value. The corresponding source node-history clause must cover warm B/R hits as well. At outer U/R, the actual d entry yields that B/R child. Apply the EXISTING `stored_open_product_optional_reclosure` at its actual returned state. It returns the full original U and leaves the full state unchanged.

Reverse R/B, U/B, and R/U calls first take the real swap branch. `reset_swap_body_of_outer_query_induction` retains the original continuation and smaller supplied budget. B/B is symmetric. Do not treat reversed query keys or parent counts as equal by commutativity. Both operand orders need their actual prefix or the exact swap adapter.

The global query induction must retain both Returned laws at every endpoint, including blocked/error and post-finish/pre-pure states. The raw result law applies to completed raw Steps only. The original noStop/all-outcome worker objective and earlier emissions after a later stop are unchanged. No part of this plan constructs one compatible finite assignment for the original root, or proves complete C/M admission or Haskell correspondence.

## Pinned reuse points

All pointers below refer to the exact source bytes read for this audit. Their hashes are evidence pins, not validation claims.

- `lean/MicroCFTA/SourceRecursiveIntersectionCompile.lean` SHA256 `ec6f7b8726e12c94e7931024078c2e6dabc55a216a3f8ff6ea98befa4f00dfeb`.
  - Line 28: `def compileMu`.
  - Line 37: `def compileReference`.
  - Line 54: `def compileRows`.
  - Line 59: `def compileNode`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeDiagonalShortcutInputs.lean` SHA256 `8d75442f4ae4e1d9c0c0092733f7325c673b68707fc3641355c33a9ab92bdc5b`.
  - Line 32: `theorem current_stored_universe_diagonal_shortcut_inputs`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeAuxiliaryCutoffQueries.lean` SHA256 `1d0b5b945fb9db7af460d94b40ea75fbf027a44f95e29201fdab92fd1dcacaa2`.
  - Line 129: `theorem current_stored_universe_auxiliary_cutoff_queries`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeSourceDiagonalFirstBodyReferenceRead.lean` SHA256 `f92ca30e36d019343661626f3a4be63c855c2c9544d03f9499605821d11ffd20`.
  - Line 55: `theorem current_stored_universe_diagonal_first_body_reference_read`.
- `lean/MicroCFTA/SourceRecursiveIntersectionDomainEquivalence.lean` SHA256 `edbe5b391674e2ce612e5731bda483ef6f7e655509bcaeb9c78bd9a7f38c456f`.
  - Line 33: `theorem entered_key`.
  - Line 41: `theorem entered_domain_equivalent`.
- `lean/MicroCFTA/SourceRecursiveIntersectionReplayEffects.lean` SHA256 `cdf7241b1948fd108179f79491f0cfac02d42f618639c67176a4d721a8405af6`.
  - Line 38: `theorem make_domain_replay`.
- `lean/MicroCFTA/SourceRecursiveIntersectionDomainAllocation.lean` SHA256 `480bbf11d7411c11c76b31ff4449b0a3c70168feeb7f2bdedd0df4eca63a34ba`.
  - Line 78: `theorem represents_mono`.
  - Line 113: `theorem Trace.returned`.
- `lean/MicroCFTA/IntersectionEmptyDomain.lean` SHA256 `5e775374d77afda0bfdebfcf456dcec1f75250615f9779e92906cd3bb5b095ed`.
  - Line 67: `theorem identity_exact`.
- `lean/MicroCFTA/SourceRecursiveIntersectionKernelFacts.lean` SHA256 `3d357ba3752609d4c9d6c46e871535de8c22db56b1a834da29b58c526dfb2ac0`.
  - Line 19: `structure Extension`.
  - Line 45: `theorem Domain.grows`.
- `lean/MicroCFTA/SourceCurrentNativeEnterCommonOperand.lean` SHA256 `38c95362d5cef9f45ea923dfa7f95e6b3cd11a6a37bc05c9e68f0812c0a44b65`.
  - Line 28: `theorem checked_trace_extension`.
  - Line 45: `theorem enter_prefix_common_operands`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeTopRowQueryGlobalLaws.lean` SHA256 `3672cc88bb55955d58df6401c991c135f654f2da6116004492e7ea6bace83dc2`.
  - Line 28: `def KnownResult`.
  - Line 34: `def TopRowResult`.
  - Line 72: `theorem query_returned_and_raw_results`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeReferenceTopRowQueryGlobalLaws.lean` SHA256 `c5196b0033d90ccc9117c9ba33a6aae06f4b5ae04a8be7b04bf6b06379f507f9`.
  - Line 29: `def KnownResult`.
  - Line 84: `theorem query_returned_and_raw_results`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeSourceQueryInduction.lean` SHA256 `43663d27c86071339764e4fc3e61fc81e0ad69d8666a5b502fc2dc765407c899`.
  - Line 85: `theorem query_returned_and_raw_results`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativePrefixOperations.lean` SHA256 `6e6d6cba370aed45adb6c786df2f0312dbb249f2b2e031d5aed6901c1534259b`.
  - Line 85: `theorem prefix_operations_before_bind`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeDiagonalProductReadback.lean` SHA256 `c25f139e1c1c85c3f882f417a748cc45f19a138b23603a46549449375a758cca`.
  - Line 33: `theorem diagonal_product_of_smaller_queries`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeOpenBodyProduct.lean` SHA256 `6e0fd66875fc89812ae22c2f04601fe3de8223d0321387b17eb4e611e3ed01c5`.
  - Line 37: `theorem current_open_body_product_of_smaller_queries`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeOpenBodyMetadata.lean` SHA256 `bf3172ba1febe9d7933d92efbf9aec2a50dd495ebf55db7dda005f48bae8f537`.
  - Line 47: `theorem current_transformed_body_metadata_after_growth`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeOpenProductReclosure.lean` SHA256 `38915c390141f5c7b420732507d2627c35bdf2077856b26e08f66fb287bb18f6`.
  - Line 29: `theorem stored_open_product_optional_reclosure`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeMuSource.lean` SHA256 `ea90c7ca44ddfbe62fca1c6644726cd9cea84edac0fb56a4cb2506fe4a7bed0b`.
  - Line 20: `theorem enter_prefix`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeRawReferenceReplay.lean` SHA256 `7d9339395f13a6439e5732371051642ee83eee5d7010d9c8f9786e9511cbfdfd`.
  - Line 21: `theorem reference_trace_result_of_actual_read`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeRawMuCutoffReplay.lean` SHA256 `b3e2b80e902357ca4c5e10c6716995decd97e8fd24f5fd35a5f68b5125edcd34`.
  - Line 49: `theorem left_mu_cutoff_trace_result`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeNodeQueryResult.lean` SHA256 `140b8c4622441fac2f5b5214d8f5c308216fee020910055efc1db04875b95fda`.
  - Line 23: `theorem node_query_result_of_body_induction`.
- `lean/MicroCFTA/SourceCurrentAllocatedNativeResetSwapBodyReturned.lean` SHA256 `5174563650d17ac914cd9bc270b94681b9e6464c7202ab915cd7353f821866df`.
  - Line 23: `theorem reset_swap_body_of_outer_query_induction`.
- `lean/MicroCFTA/SourceRecursiveIntersectionThunkReadback.lean` SHA256 `a4580c833ed8f9d1195f4cadb0e5d3c6005b38b0340b6dc52b693d297357bef2`.
  - Line 15: `theorem NodeRequest.components`.
  - Line 24: `theorem EdgeRequest.components`.
- `lean/restart-evidence/20261115-returned-reset-and-open-adapter-closure-audit/ORIGINAL-coupled-fuel-header.lean.txt` SHA256 `71ec7b552d73f5ac5bd7a8120e09fb9c57455286135241a4a49e9785a8635375`.
- `lean/restart-evidence/20261114-shared-child-resources-and-atom-steps/runs/mcfta-same-branch-clear-causal-review-20261114-1659/RELATION-TARGET.md` SHA256 `27f43faf2d8ad79d05aea36c72dca159118629f63b75736795abab41d0125183`.

Audit timestamp: 2026-11-15 14:41:53 CET. No compiler or runtime was used. No live source, Git, board, Haskell, or /tmp changes were made.
