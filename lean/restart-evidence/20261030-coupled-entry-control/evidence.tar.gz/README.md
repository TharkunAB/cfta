# Original-input startup and fixed-depth enumeration

Full goal ACTIVE. Read final-documents/lean/notes-current-coupled-entry-control.md.
Eight new public laws in five modules derive original Lean startup and both
fixed-D stable resource results. Actual raw entry rows, shared captured prefixes
and opaque complete/rejected/stopped outer+candidate caches preserve paths.
Complete permits recursive exhaustion. Original sufficient D for an intended
finite ordered prefix through all earlier alternatives remains the main gap.
Policy/carrier conditions, global coverage, public APIs and Haskell remain open.
Existing cold equality completion/exact preservation and older targets remain.
Audit4717/82766, public1130/95 and six matching strict inputs pass. All eight new
axiom reports contain only standard axioms. Protected513/native835 old inputs
remain exact; current protected518. All36 commands(21pass/15failed drafts or
diagnostics) and143 source snapshots remain. Three frozen source-only reviews
verify291 payload pins. All reports and all new public output were read in full.
Both native acquisition overruns, malformed diagnostic, failed bootstrap/schema
operations, clipped-output recoveries and every marked version remain explicit.
Final canonical public source is public-v2.lean at this evidence root. Both
earlier complete public outputs are exact prefixes. The runner is unchanged.
No Haskell source changed or new defect/fix was established. FINDINGS preserves
all earlier repairs and conditional SCS/runtime scope. Main was refreshed unchanged.
Every regular payload is archived without filtering. Keep this area immutable.
Independent reconstruction and source/pin checks execute no Lean or Haskell.
Continue in a fresh writable evidence area. The full goal remains active.
