# Root review and control boundary

All eight new public types and all three new complete definition prints were
read. The first public tail was read in four contiguous character cuts. The
second tail was read in full. Both earlier complete readbacks are exact byte
prefixes. All new proof bodies were read as complete source or complete immutable
version diffs. Every final production source matches its strict input copy.

The current claim is original-input fixed-D stabilization and OutcomeResources
for both actual workers. Complete permits exhausted stops. OutcomeResources does
not constrain the stopped reason. It can use a retained prefix resource witness
at an absent endpoint. The remaining main control problem is sufficient original
D for the intended finite ordered prefix, including every earlier alternative.
Selected-edge membership and length policies alone do not prove edge coverage.
Public API, live-cache and Haskell correspondence remain open. No Haskell source
changed, no native command was run, and no new Haskell defect/fix was established.

All three source-only reports were read completely. Initial admission has two
whole old sources. The native review has six whole/near-whole sources against
four authorized. Both overruns remain explicit: whole PrefixHistory51L, and
aggregate PrefixAdmission128/152L. The Prepared review has two whole/near-whole
sources: PreparedRecursive120L and PreparedFiniteResources81L. Its earlier
recursive-body cut is a revalidated frozen reuse. Owner snapshots include opaque
background inputs; archived copies do not imply semantic review of those inputs.

All 36 actual compiler commands are terminal. They retain 21 passes, 15 failed
draft/diagnostic checks, 143 input snapshots and the unchanged runner. Failed
diagnostic V6 used a Nat where Reference was required; its elaborator recovery
terms are not a checked proof. V7 corrected that binder. Expanded terms located
the generated-matcher mismatch. V9 evaluates actual constructors and the actual
terminal flag at the actual return equation. It names no generated matcher.

The first whole V2 opaque log display crossed the context limit. An early Root
feedback message described it as fully read before the complete bounded reread.
The complete 12416-byte log was subsequently read in two contiguous cuts before
this review and sealing. The raw artifact remains exact. Other relied-on clipped
definition cuts were recovered by bounded rereads. A broad archive filename
listing was clipped; it supplied navigation only. The initial report's clipped
middle was recovered, then all three final reports were read in full separately.

Bootstrap first copied a read-only prior directory and failed to add its missing
canonical public source. The following runner also lacked its plan, before any
compiler ran. Both complete tracebacks remain. Only the new copy was made
writable temporarily, repaired with the exact canonical prior public source,
then returned to read-only mode. The frozen prior evidence stayed unchanged.
Wrong guessed module filenames and navigation failures supplied no proof body.
Keep all failed and uncompiled versions, scope ledgers, EOF clamps and full logs.

The first Root pin verifier expected report_sha256 in every owner's seal. Native
stores that hash in its pinned REPORT record. The failed script and full schema
incident remain. The corrected verifier checks the report record, optional seal
hash and exact file set. All three bundles now pass with291 payload pins.

All prior513 protected proof sources and835 native inputs remain exact. All
prior4712 Lean source bodies remain exact except additive Audit imports, whose
complete old body is an exact suffix. Current protected518, Lean4717. Current
main was fetched again and remains bd5a406a6a3f84b7e3ae0906082783911509df83.
Goal ACTIVE. No pause or completion was requested or recorded in this turn.
